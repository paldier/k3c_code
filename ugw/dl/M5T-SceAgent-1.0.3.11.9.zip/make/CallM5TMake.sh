#!/bin/bash
#===============================================================================
#
#   Copyright(c) 2015 Media5 Corporation ("Media5")
#
#  NOTICE:
#   This document contains information that is confidential and proprietary to
#   Media5.
#
#   Media5 reserves all rights to this document as well as to the Intellectual
#   Property of the document and the technology and know-how that it includes
#   and represents.
#
#   This publication cannot be reproduced, neither in whole nor in part, in any
#   form whatsoever without prior written approval by Media5.
#
#   Media5 reserves the right to revise this publication and make changes at
#   any time and without the obligation to notify any person and/or entity of
#   such revisions and/or changes.
#
#===============================================================================
szArgs=''
if [[ ${*} = *clean* ]]
then
    szArgs+=' clean'
fi

# Variables which must be available from within m5tmake
export aszSceAgentFlags

# Complete build from sources
pushd ${szSceAgentDir}'/M5T/M5TSceAgent/Makefiles'
${szSceAgentDir}'/M5T/M5TMake/Sources/M5tMake/m5tmake' -i m5tmake.lantiq.cfg -t NA:Linux_mips_gcc -v ${szArgs}
resRC=$?
popd

if [[ $resRC != 0 ]]
then 
    echo -e "\e[0;31mMedia5 ERROR: m5tmake failed to build the M5T SCE Agent!\e[0m"
fi

exit $resRC
