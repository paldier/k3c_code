#ifndef _INC_DECT_DRV_IF
#define _INC_DECT_DRV_IF

#include "DEFINE.H"

#include "SYSDEF.H"
#include "TYPEDEF.H"

#include "fhmac.h"
//#include "drv_dect.h"

int DectDrvIfInit(void);
int DectDrvIfShut(void);
void write_to_hmac_ioctl(BYTE procid, BYTE msgnr
                  ,BYTE param1, BYTE param2, BYTE param3, BYTE param4
                  ,BYTE param5, BYTE param6, FPTR pdata, BYTE inc);

//void write_FU10_data_to_hmac_ioctl(BYTE lln,unsigned short len,FPTR data);

void wrtie_to_debug_info_ioctl(BYTE info_id, BYTE rw_indicator, BYTE inc, FPTR pdata);

int read_from_hmac_ioctl(HMAC_QUEUES *data);


int read_debug_from_module_ioctl(DECT_MODULE_DEBUG_INFO *data);


void get_pmid_from_hmac_ioctl(BYTE * data);
void get_enc_state_from_hmac_ioctl(BYTE * data);
void set_knl_state_to_hmac_ioctl(BYTE * data);
void trigger_cosic_driver_for_osc( BYTE *data );

extern int dect_drv_fd;
#endif  //_INC_DECT_DRV_IF
