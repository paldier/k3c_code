/******************************************************************************

                              Copyright (c) 2009
                            Lantiq Deutschland GmbH
                     Am Campeon 3; 85579 Neubiberg, Germany

  For licensing information, see the file 'LICENSE' in the root folder of
  this software module.

******************************************************************************/
#ifndef DRV_DECT_C
#define DRV_DECT_C

/* =======================================================================
 * Include Files
 * ======================================================================= */
#ifdef LINUX
//#include <linux/module.h>

//#include <linux/kernel.h>   /* printk() */
//#include <linux/slab.h>
//#include <linux/fs.h>       /* everything... */
#include <linux/errno.h>    /* error codes */
#include <linux/types.h>    /* size_t */
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/poll.h>
#include <linux/ioport.h>
#include <linux/vmalloc.h>
#include <linux/delay.h>
#include <linux/sched.h>
#include <linux/param.h>
#include <linux/timer.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/semaphore.h>
#include <asm/irq.h>

#include <linux/mm.h>
#include <linux/spinlock.h>
#include <asm/dec/system.h>
#include <asm/bitops.h>
#include <linux/version.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/fs.h>       /* everything... */
#include <linux/gpio.h>
#ifdef CONFIG_LTT
#include <linux/sched.h>
#include <asm/atomic.h>
#include <linux/marker.h>
#include <linux/inetdevice.h>
#include <net/sock.h>
#include <ltt/ltt-facility-select-default.h>
#include <ltt/ltt-facility-select-network_ip_interface.h>
#include <ltt/ltt-facility-network.h>
#include <ltt/ltt-facility-socket.h>
#include <ltt/ltt-facility-network_ip_interface.h>
#endif


#include <linux/wait.h>
#include <linux/signal.h>
//#include <linux/smp_lock.h> //not found in 3.8.10
/* little / big endian */
#include <asm/byteorder.h>
#include <asm/dec/system.h>

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
#include <lantiq_soc.h> 
#ifdef DECT_USE_USIF
#include <lantiq_usif_spi.h>
#else
#include <lantiq_ssc.h>
#endif
#include <lantiq_irq.h> 
#include <linux/gpio.h>
#include <linux/of.h>
#include <linux/of_irq.h>
#include <linux/of_gpio.h>
#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/of_platform.h>
#include <linux/of_address.h>


#elif defined CONFIG_AMAZON_S

#include <asm/amazon_s/amazon_s.h>
#include <asm/amazon_s/irq.h>
#include <asm/amazon_s/amazon_s_ssc.h>

#elif defined CONFIG_DANUBE

#include <asm-mips/ifx/danube/danube.h>
#include <asm-mips/ifx/danube/irq.h>
#include <asm-mips/ifx/ifx_gpio.h>
#include <asm/ifx/ifx_ssc.h>
#include <asm-mips/ifx/ifx_led.h>
const int dect_gpio_module_id = IFX_GPIO_MODULE_DECT;


#elif defined CONFIG_AR9
#include <ar9/ar9.h>
#include <ar9/irq.h>
#include <ltq_gpio.h>
#include <ltq_ssc.h>
const int dect_gpio_module_id = IFX_GPIO_MODULE_DECT;
#elif defined CONFIG_AR10
#include <ar10/ar10.h>
#include <ar10/irq.h>
#include <ltq_gpio.h>
#ifdef DECT_USE_USIF
#include <ltq_usif_spi.h>
#else
#include <ltq_ssc.h>
#endif
const int dect_gpio_module_id = IFX_GPIO_MODULE_DECT;
#elif defined CONFIG_VR9
#include <vr9/vr9.h>
#include <vr9/irq.h>
#include <ltq_gpio.h>
#ifdef DECT_USE_USIF
#include <ltq_usif_spi.h>
#else
#include <ltq_ssc.h>
#endif
const int dect_gpio_module_id = IFX_GPIO_MODULE_DECT;
#endif


#include "lib_bufferpool.h"
//#include "SYSDEF.H"
//#include "TYPEDEF.H"
//#include "TYPEDEF_CP.H"
//#include "FMAC_DEF.H"
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,10,00)
#include<ltq_gptu.h>
#endif
#ifdef CONFIG_SMP 
#include <asm/spinlock.h>
#endif

#include "drv_tapi_io.h"
#include "drv_tapi_kio.h"
#endif /* LINUX */
#ifdef SUPERTASK
#ifdef _INFXR9
#include "ifx_types.h"
#include "vr9.h"
#include "irq.h"
#include "ifx_gpio.h"
#include "ifx_ssc.h"
#include "mtmacro.h"
#else
#include "danube_hw.h"
#include "irq.h"
#include "ifx_ssc_defines.h"
#include "ifx_ssc.h"
#endif

#include "sys_timer.h"
#endif /* SUPERTASK */

#include "lib_bufferpool.h"
#include "fmbc.h"
#include "drv_dect.h"
#include "drv_dect_cosic_drv.h"
#include "fdebug.h"

#ifdef LINUX
MODULE_AUTHOR("LANTIQ");
MODULE_DESCRIPTION("DECT Driver");
MODULE_LICENSE("GPL");
#endif

/* =======================================================================
 * External Reference
 * ======================================================================= */
extern modem_dbg_stats modem_stats;
extern modem_dbg_lbn_stats lbn_stats[6];
extern dect_version version; 
extern gw_dbg_stats gw_stats;
extern unsigned int vuiDbgSendFlags;
extern int viSPILockedCB;
extern int iCosicMode; /* Tx = 0, Rx = 1 */
#ifdef LINUX
#define printk(...)
#ifdef CONFIG_SMP
	#define CONFIG_SMP2
	#define CONFIG_SMP4
	 spinlock_t IntEdgFlgLock;
	 spinlock_t IOCTL_TASKET_Lock;
#ifdef CONFIG_SMP4
	 spinlock_t DECT_TAPI_Lock;
#endif
#endif

//extern int ifx_ssc_cs_high_port1(unsigned int pin);
//extern int ifx_ssc_cs_low_port1(unsigned int pin);
extern atomic_t vuiGwDbgFlag;
extern x_IFX_Mcei_Buffer xMceiBuffer[MAX_MCEI];
extern int viSPILocked;
////extern int FirstLock;
#ifdef CONFIG_DANUBE
extern void *g_dect_isdn_fxs_reset_trigger;
#endif
#endif /* LINUX */
#ifdef SUPERTASK
extern unsigned int vuiGwDbgFlag;
extern volatile int ichipCSRxCount;
extern volatile int ichipCSCount;
extern volatile int ichipCSTxCount;
#endif /* SUPERTASK */

extern void EnableGwDebugStats(void);
extern void DisableGwDebugStats(void);
extern void ResetGwDebugStats(void);
extern void GetModemDebugStats(void);
extern void ResetModemDebugStats(void);
extern int WriteDbgPkts(unsigned char debug_info_id, unsigned char rw_indicator, unsigned char CurrentInc, unsigned char *G_PTR_buf);
#ifdef LINUX
extern void ifx_sscCosicLock(void);
extern int ifx_ssc_cs_low(u32 pin);
extern int ifx_ssc_cs_high(u32 pin);
#endif
#ifdef SUPERTASK
extern int ifx_sscCosicLock(void);
#endif

/* =======================================================================
 * Definitions
 * ======================================================================= */
#ifdef LINUX
#define ENHANCED_DELAY
#endif

#define DECT_DRV_MAJOR             213
#define DECT_DRV_MINOR_0           0
#define DECT_DRV_MINOR_1           1

#define DECT_DEVICE_NAME "dect_drv"
#define DECT_VERSION "6.1.0.0"
#define MAX_SEND_BUFFER_COUNT  		80
#define MAX_RECEIVED_BUFFER_COUNT	80

#define MAX_DEBUG_INFO_COUNT	    10

#ifdef LINUX
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
	int DECT_IRQ_NUM=-1,DECT_CS=-1,IFX_DECT_RST=-1,IFX_DECT_SPI_CS=-1;
#elif defined(TWINPASS)
#define DECT_IRQ_NUM    INT_NUM_IM4_IRL30
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT0_POS
#elif defined(CONFIG_AMAZON_S)
// connect JP73 2 and 3  GPIO39 Using P2.7---> EXIN 3--> IM1_IRL0
#define DECT_IRQ_NUM    INT_NUM_IM1_IRL0
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT2_POS//FIXME CS pin, now configure as SPI_CS3
#elif defined(CONFIG_DANUBE)
#define DECT_IRQ_NUM    INT_NUM_IM1_IRL2
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT5_POS
#elif  defined CONFIG_IFX_GW188
#define DECT_IRQ_NUM    INT_NUM_IM1_IRL0
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT0_POS//Not used
#elif defined CONFIG_AR9
//connect JP73 2 and 3  GPIO39 Using P2.7---> EXIN 3--> IM1_IRL0
#define DECT_IRQ_NUM    INT_NUM_IM1_IRL0
#ifdef  CONFIG_AR9_NAND
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT3_POS//FIXME CS pin, now configure as SPI_CS3
#else
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT2_POS//FIXME CS pin, now configure as SPI_CS3
#endif
#elif defined CONFIG_AR10
//GPIO9 ->Connection and IRQ number to be checked
#define DECT_IRQ_NUM    INT_NUM_IM1_IRL2
#ifdef DECT_USE_USIF 
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT0_POS//SPI_CS5 for USIF aswell??
#else
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT5_POS//GPIO9-SPI_CS5
#endif
#elif defined CONFIG_VR9
//connect JP61 1 and 2  GPIO9 Using P0.9---> EXIN 5--> IM1_IRL2
#define DECT_IRQ_NUM    INT_NUM_IM1_IRL2
#ifdef DECT_USE_USIF 
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT0_POS//FIXME CS pin, now configure as SPI_CS3
#else
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT1_POS//FIXME CS pin, now configure as SPI_CS3
#endif
#endif

#ifdef CONFIG_AMAZON_S
#define ifx_sscAllocConnection amazon_s_sscAllocConnection
#define ifx_sscFreeConnection  amazon_s_sscFreeConnection
#define ifx_ssc_cs_low  amazon_s_ssc_cs_low
#define ifx_ssc_cs_high  amazon_s_ssc_cs_high
#endif
#endif /* LINUX */
#ifdef SUPERTASK
#ifndef _INFXR9
#define DECT_IRQ_NUM    INT_NUM_IM0_IRL26
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT3_POS
#else
//Radvajesh connect JP61 1 and 2  GPIO9 Using P0.9---> EXIN 5--> IM1_IRL2
#define DECT_IRQ_NUM    INT_NUM_IM3_IRL31
#define DECT_CS IFX_SSC_WHBGPOSTAT_OUT4_POS//ctc FIXME CS pin, now configure as SPI_CS5
#endif

#define DECT_STACK_WAITGROUP_ID	3
#define DRIVER_STACK_EVT		0x0002
#define DBG_STACK_EVT			0x0004
#endif /* SUPERTASK */

/* =======================================================================
 * Enumerations/Type definitions
 * ======================================================================= */

/* =======================================================================
 * Local Variables
 * ======================================================================= */
static int open_dect_count = 0;
static int iPlatform = 0;

#define DECT_GRX500 1
#define DECT_AR10 2
#define DECT_GRX390 3


/*RECEIVED BUFFER */
HMAC_QUEUES send_to_stack_buf[MAX_RECEIVED_BUFFER_COUNT];
static int send_to_stack_buf_r_count = 0;
static int send_to_stack_buf_w_count = 0;
static unsigned int uiOverflow_r;
static unsigned int uiOverflow_w;

/* SEND BUFFER */
HMAC_QUEUES send_to_lmac_buf[MAX_SEND_BUFFER_COUNT];
static int send_to_lmac_buf_r_count = 0;
static int send_to_lmac_buf_w_count = 0;

/* SEND DEBUG BUFFER */
DECT_MODULE_DEBUG_INFO send_to_debug_info_buf[MAX_DEBUG_INFO_COUNT];
static int send_to_debug_info_buf_r_count = 0;
static int send_to_debug_info_buf_w_count = 0;

/* RECEIVE DEBUG BUFFER */
DECT_MODULE_DEBUG_INFO receive_to_debug_info_buf[MAX_DEBUG_INFO_COUNT];
static int receive_to_debug_info_buf_r_count = 0;
static int receive_to_debug_info_buf_w_count = 0;

#ifdef LINUX
static int create_dir = 0;

#if CONFIG_PROC_FS
static struct proc_dir_entry *dect_proc_dir;
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,0))
#ifndef ARRAY_SIZE
   #define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#endif /* ARRAY_SIZE */

static void dect_drv_read_version_proc(struct seq_file *s);
static void dect_drv_read_gw_stats_proc(struct seq_file *s);
static void dect_drv_read_modem_stats_proc(struct seq_file *s);
static void dect_drv_read_channel_stats_proc(struct seq_file *s);
static ssize_t dect_drv_gw_write_proc(struct file *file, const char __user *buffer,size_t count, loff_t *data);
static ssize_t dect_drv_modem_write_proc(struct file *file, const char __user *buffer,size_t count, loff_t *data);

/* single call read proc entry callback function */
typedef void (*proc_single_callback_t)(struct seq_file *);
/* multiple call read proc entry callback function */
typedef int (*proc_callback_t)(struct seq_file *, int);
/* used to get the number of times multiple call read proc entry callback
 * function should be called to get the full output (typically equals number
 * of devices). The number returned by this function is assigned to nMaxPos
 * field of proc_file_entry structure.  */
typedef int (*proc_init_callback_t)(void);
/* write function */
typedef ssize_t (*proc_write_t)(struct file *file, const char __user *buffer,
   size_t count, loff_t *data);


struct proc_entry {
   char *name;
   proc_single_callback_t single_callback;
   proc_callback_t callback;
   proc_init_callback_t init_callback;
   proc_write_t write_function;
   struct file_operations ops;
};


static struct proc_entry proc_entries[] = {
   {"version",                   dect_drv_read_version_proc, NULL, NULL, NULL},
   {"gw-stats",                 	dect_drv_read_gw_stats_proc, NULL, NULL, dect_drv_gw_write_proc},
   {"modem-stats",               dect_drv_read_modem_stats_proc, NULL, NULL, dect_drv_modem_write_proc},
   {"channel-stats",        		dect_drv_read_channel_stats_proc, NULL, NULL, NULL},
};

static int DECT_seq_single_show(struct seq_file *s, void *v)
{
   struct proc_entry *p = s->private;

   p->single_callback(s);
   return 0;
}

static int DECT_proc_single_open(struct inode *inode, struct file *file)
{
   return single_open(file, DECT_seq_single_show, PDE_DATA(inode));
}

static void DECT_proc_entry_create(struct proc_dir_entry *parent_node,
              struct proc_entry *proc_entry)
{
   mode_t mode = S_IFREG | S_IRUGO;

   memset(&proc_entry->ops, 0, sizeof(struct file_operations));
   proc_entry->ops.owner = THIS_MODULE;

   if (proc_entry->single_callback)
   {
      proc_entry->ops.open = DECT_proc_single_open;
      proc_entry->ops.release = single_release;
   }
#if 0 
	else
   {
      proc_entry->ops.open = DECT_proc_open;
      proc_entry->ops.release = DECT_proc_release;
   }
#endif
   proc_entry->ops.read = seq_read;
   proc_entry->ops.write = proc_entry->write_function;
   if (proc_entry->write_function != NULL)
      mode |= S_IWUGO;
   proc_entry->ops.llseek = seq_lseek;

   proc_create_data(proc_entry->name, mode, parent_node, &proc_entry->ops,
      proc_entry);
}


static int proc_EntriesInstall(void)
{
	int i;

   dect_proc_dir = proc_mkdir("driver/dect", NULL);

   if (dect_proc_dir != NULL)
   {
		for (i = 0; i < ARRAY_SIZE(proc_entries); i++)
         DECT_proc_entry_create(dect_proc_dir, &proc_entries[i]);
	}

	return 0;
}


#else
static struct proc_dir_entry *dect_version_file,*dect_gw_stats_file,*dect_modem_stats_file;
static struct proc_dir_entry *dect_channel_stats_file;
int dect_drv_read_proc(char *page, char **start, off_t off,
			int count, int *eof, void *data);
int dect_drv_read_version_proc(char *buf);
int dect_drv_read_gw_stats_proc(char *buf);
int dect_drv_read_modem_stats_proc(char *buf);
int dect_drv_read_channel_stats_proc(char *buf);
int dect_drv_write_proc(struct file *file,const char *buffer,unsigned long count,void *data);

#endif
#endif
#endif /* LINUX */

/* =======================================================================
 * Global Variables
 * ======================================================================= */
int viCSStatus=0;
int Dect_excpFlag = 0;

unsigned char vucDriverMode;
unsigned char vucReadBuffer[MAX_READ_BUFFFERS][COSIC_LOADER_PACKET_SIZE];
unsigned char vucWriteBuffer[MAX_WRITE_BUFFERS][COSIC_LOADER_PACKET_SIZE];
unsigned short vu16ReadBufHead;
unsigned short vu16ReadBufTail;
unsigned short vu16WriteBufHead;
unsigned short vu16WriteBufTail;

BUFFERPOOL *pTapiWriteBufferPool;

#ifdef LINUX
#ifdef ENHANCED_DELAY
unsigned int vuiDealy=1;
#endif
int viDisableIrq;
int iIrqStatus=1;
wait_queue_head_t Dect_WakeupList;
int dect_gpio_intnum = -1; /* valiable interrupt number */
IFX_SSC_HANDLE *spi_dev_handler=NULL;
#endif /* LINUX */
#ifdef SUPERTASK
int cosic_monitor_timer=0;
int cosic_MP_flag=0;
int dect_gpio_intnum = DECT_IRQ_NUM; /* valiable interrupt number */
IFX_SSC_HANDLE spi_dev_handler;
#endif /* SUPERTASK */


/* =======================================================================
 * Local Function Prototypes
 * ======================================================================= */
u32 ssc_dect_cs(u32 on, u32 cs_data);
u32 ssc_dect_cs_toggle(void);

#ifdef LINUX
#if CONFIG_PROC_FS
#if (LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0))
int dect_drv_read_proc(char *page, char **start, off_t off, int count, int *eof, void *data);

int dect_drv_read_version_proc(char *buf);
int dect_drv_read_gw_stats_proc(char *buf);
int dect_drv_read_modem_stats_proc(char *buf);
int dect_drv_read_channel_stats_proc(char *buf);

int dect_drv_write_proc(struct file *file,const char *buffer,unsigned long count,void *data);
#endif
#endif
#endif /* LINUX */

/* =======================================================================
 * Function Definitions
 * ======================================================================= */
#ifdef LINUX
#ifdef CONFIG_LTT
void probe_cosic_event(const char *format, ...)
{
   va_list ap;
   unsigned long iPktCount;
   const char *mystr;
 
   va_start(ap, format);
   iPktCount = va_arg(ap,typeof(iPktCount));
   mystr = va_arg(ap, typeof(mystr));
   // printk(KERN_INFO "iPktCount %lu, string %s\n", iPktCount, mystr);
   /* Call tracer */
   trace_socket_call(4, iPktCount);
}

void probe_tapi_event(const char *format, ...)
{
   va_list ap;
   unsigned long iPktCount;
   const char *mystr;
 
   va_start(ap, format);
   iPktCount = va_arg(ap,typeof(iPktCount));
   mystr = va_arg(ap, typeof(mystr));
   // printk(KERN_INFO "iPktCount %lu, string %s\n", iPktCount, mystr);
   /* Call tracer */
   if(strcmp(mystr,"1")==0){
      trace_socket_call(1, iPktCount);
   }
   else if(strcmp(mystr,"2")==0){
      trace_socket_call(2, iPktCount);
   }
   else{
      trace_socket_call(3, iPktCount);
   }
}
#endif
#endif /* LINUX */

/*******************************************************************************
Description:	HMAC to stack data
Arguments: 
Note: 
*******************************************************************************/
void Dect_SendtoStack(HMAC_QUEUES* data)
{
   #ifdef CONFIG_SMP2
      unsigned long flags;
   #endif

#ifdef LINUX
#ifdef CONFIG_LTT
   int i,j;
#endif
#endif
#ifdef SUPERTASK
   BLOCK_PREEMPTION;
#endif

   #ifdef CONFIG_SMP2
      spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   #endif

   memcpy((unsigned char*)&send_to_stack_buf[send_to_stack_buf_w_count++], data, sizeof(HMAC_QUEUES));
   if (send_to_stack_buf_w_count == MAX_RECEIVED_BUFFER_COUNT)
	{
      send_to_stack_buf_w_count = 0;
		if(send_to_stack_buf_r_count == 0)
   	{
#ifdef LINUX
#ifdef CONFIG_LTT
      	//OSGI dump packets
      	for(i=0; i< MAX_RECEIVED_BUFFER_COUNT; i++){
         	//printk("MSG:%d R/WCount:%d",send_to_stack_buf[i].MSG, send_to_stack_buf_w_count);
         	for(j=0;j<20;j++){
            	//printk("[0x%x]",send_to_stack_buf[i].G_PTR_buf[j]);
         	}
         	//printk("\n");
      	}
#endif
#endif
      	memset(&send_to_stack_buf[0], 0x00, sizeof(send_to_stack_buf));
 
		}
   	#ifdef CONFIG_SMP2
      	spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   	#endif
      	printk("Critical Error!!! to stack buffer overflow11!! Erase all data\n");
		return;
	}

   if ((send_to_stack_buf_w_count == send_to_stack_buf_r_count) && (send_to_stack_buf_r_count !=0))
   {
#ifdef LINUX
#ifdef CONFIG_LTT
      //OSGI dump packets
      for(i=0; i< MAX_RECEIVED_BUFFER_COUNT; i++){
         //printk("MSG:%d R/WCount:%d",send_to_stack_buf[i].MSG, send_to_stack_buf_w_count);
         for(j=0;j<20;j++){
           // printk("[0x%x]",send_to_stack_buf[i].G_PTR_buf[j]);
         }
         //printk("\n");
      }
#endif
#endif
      memset(&send_to_stack_buf[0], 0x00, sizeof(send_to_stack_buf));
      send_to_stack_buf_r_count = 0;
      send_to_stack_buf_w_count = 0;    
   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif
      printk("Critical Error!!! to stack buffer overflow!! Erase all data\n");
		return;
   }
   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif
   Dect_excpFlag = 1;
   #ifdef LINUX
	wake_up_interruptible(&Dect_WakeupList);
	#endif
	#ifdef SUPERTASK
	UNBLOCK_PREEMPTION;
	setgrp(DECT_STACK_WAITGROUP_ID, DRIVER_STACK_EVT);
	#endif
}

/*******************************************************************************
Description:	HMAC to lmac data
Arguments: 
Note: 
*******************************************************************************/
void Dect_SendtoLMAC(HMAC_QUEUES* data)
{
	#ifdef CONFIG_SMP2
		unsigned long flags;
	#endif
#ifdef LINUX
   if(viDisableIrq==2){
      return;
   }
#endif
	#ifdef CONFIG_SMP2
   	spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
	#endif
   memcpy((unsigned char*)&send_to_lmac_buf[send_to_lmac_buf_w_count++], data, sizeof(HMAC_QUEUES));
   if (send_to_lmac_buf_w_count == MAX_SEND_BUFFER_COUNT)
   {
      send_to_lmac_buf_w_count = 0;
      uiOverflow_w++;
   }

   if ((send_to_lmac_buf_w_count == send_to_lmac_buf_r_count)&&(uiOverflow_r == uiOverflow_w-1))
   {
      //printk("Critical Error!!! to lmac buffer overflow!! Erase all data\n");
      memset(&send_to_lmac_buf[0], 0x00, sizeof(send_to_lmac_buf));
      send_to_lmac_buf_r_count = 0;
      send_to_lmac_buf_w_count = 0;
      uiOverflow_w=0;
      uiOverflow_r=0;
   }

	#ifdef CONFIG_SMP2
   	spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
	#endif
}

/*******************************************************************************
Description:	Get data for Cosic drvier
Arguments: 
Note: 
*******************************************************************************/
HMAC_LMAC_RETURN_VALUE Dect_Drv_Get_Data(HMAC_QUEUES* data)
{
   #ifdef CONFIG_SMP2
      unsigned long flags;
   #endif

   HMAC_LMAC_RETURN_VALUE nRet = DECT_DRV_HMAC_BUF_EMPTY;

   #ifdef CONFIG_SMP2
      spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   #endif
  
   if (send_to_lmac_buf_r_count != send_to_lmac_buf_w_count)
   {
      memcpy(data, (unsigned char*)&send_to_lmac_buf[send_to_lmac_buf_r_count], sizeof(HMAC_QUEUES));
      memset((unsigned char*)&send_to_lmac_buf[send_to_lmac_buf_r_count], 0x00, sizeof(HMAC_QUEUES));
      send_to_lmac_buf_r_count++;

      if (send_to_lmac_buf_r_count == MAX_SEND_BUFFER_COUNT)
      {
         send_to_lmac_buf_r_count = 0;
         uiOverflow_r++;
      }
    
      if (send_to_lmac_buf_r_count != send_to_lmac_buf_w_count)
         nRet = DECT_DRV_HMAC_BUF_MORE; //have more data
      else
         nRet = DECT_DRV_HMAC_BUF_LAST; //this data is last
   }

   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif 
 
   return nRet;
}
#ifdef LINUX
EXPORT_SYMBOL(Dect_Drv_Get_Data);
#endif



/*******************************************************************************
Description:	HMAC to stack data
Arguments: 
Note: 
*******************************************************************************/
void Dect_DebugSendtoApplication(DECT_MODULE_DEBUG_INFO* data)
{
   #ifdef CONFIG_SMP2
      unsigned long flags;
      spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   #endif
   memcpy((unsigned char*)&receive_to_debug_info_buf[receive_to_debug_info_buf_w_count++], data, sizeof(DECT_MODULE_DEBUG_INFO));
   if (receive_to_debug_info_buf_w_count == MAX_DEBUG_INFO_COUNT)
      receive_to_debug_info_buf_w_count = 0;

   if (receive_to_debug_info_buf_w_count == receive_to_debug_info_buf_r_count)
   {
      //printk("Critical Error!!! to application buffer overflow!! Erase all data\n");
      memset(&receive_to_debug_info_buf[0], 0x00, sizeof(receive_to_debug_info_buf));
      receive_to_debug_info_buf_r_count = 0;
      receive_to_debug_info_buf_w_count = 0;    
   }

   Dect_excpFlag = 1;

   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif

#ifdef LINUX
   wake_up_interruptible(&Dect_WakeupList);
#endif
#ifdef SUPERTASK
   setgrp(DECT_STACK_WAITGROUP_ID, DBG_STACK_EVT);
#endif
}


/*******************************************************************************
Description:	HMAC to lmac data
Arguments: 
Note: 
*******************************************************************************/
void Dect_DebugSendtoModule(DECT_MODULE_DEBUG_INFO* data)
{
   #ifdef CONFIG_SMP2
      unsigned long flags;
   #endif
	#ifdef LINUX
   	if(viDisableIrq==2){
      	return;
   	}
	#endif

   #ifdef CONFIG_SMP2
      spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   #endif

   memcpy((unsigned char*)&send_to_debug_info_buf[send_to_debug_info_buf_w_count++], data, sizeof(DECT_MODULE_DEBUG_INFO));
   if (send_to_debug_info_buf_w_count == MAX_DEBUG_INFO_COUNT)
      send_to_debug_info_buf_w_count = 0;

   if (send_to_debug_info_buf_w_count == send_to_debug_info_buf_r_count)
   {
      //printk("Critical Error!!! to debug buffer overflow!! Erase all data\n");
      memset(&send_to_debug_info_buf[0], 0x00, sizeof(send_to_debug_info_buf));
      send_to_debug_info_buf_r_count = 0;
      send_to_debug_info_buf_w_count = 0;    
   }

   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif
}

/*******************************************************************************
Description:	Get data for Cosic drvier
Arguments: 
Note: 
*******************************************************************************/
HMAC_LMAC_RETURN_VALUE Dect_Debug_Get_Data(DECT_MODULE_DEBUG_INFO* data)
{
   #ifdef CONFIG_SMP2
      unsigned long flags;
   #endif

   HMAC_LMAC_RETURN_VALUE nRet = DECT_DRV_HMAC_BUF_EMPTY;

   #ifdef CONFIG_SMP2
      spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   #endif
  
   if (send_to_debug_info_buf_r_count != send_to_debug_info_buf_w_count)
   {
      memcpy(data, (unsigned char*)&send_to_debug_info_buf[send_to_debug_info_buf_r_count], sizeof(DECT_MODULE_DEBUG_INFO));
      memset((unsigned char*)&send_to_debug_info_buf[send_to_debug_info_buf_r_count], 0x00, sizeof(DECT_MODULE_DEBUG_INFO));
      send_to_debug_info_buf_r_count++;

      if (send_to_debug_info_buf_r_count == MAX_DEBUG_INFO_COUNT)
         send_to_debug_info_buf_r_count = 0;

      if (send_to_debug_info_buf_r_count != send_to_debug_info_buf_w_count)
         nRet = DECT_DRV_HMAC_BUF_MORE; //have more data
      else
         nRet = DECT_DRV_HMAC_BUF_LAST; //this data is last
   }

   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif
   return nRet;
}
#ifdef LINUX
EXPORT_SYMBOL(Dect_Debug_Get_Data);
#endif

void Reset_Hmac_Debug_buffer(void)
{
   #ifdef CONFIG_SMP2
      unsigned long flags;
   #endif

   #ifdef CONFIG_SMP2
      spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   #endif

   memset(&send_to_lmac_buf, 0x00, sizeof(send_to_lmac_buf));
   send_to_lmac_buf_r_count = 0;
   send_to_lmac_buf_w_count = 0;

   memset(&send_to_stack_buf, 0x00, sizeof(send_to_stack_buf));
   send_to_stack_buf_r_count = 0;
   send_to_stack_buf_w_count = 0;

   memset(&send_to_debug_info_buf, 0x00, sizeof(send_to_debug_info_buf));
   send_to_debug_info_buf_r_count = 0;
   send_to_debug_info_buf_w_count = 0;

   memset(&receive_to_debug_info_buf, 0x00, sizeof(receive_to_debug_info_buf));
   receive_to_debug_info_buf_r_count = 0;
   receive_to_debug_info_buf_w_count = 0;


   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif
}

#ifdef LINUX
/*
 * Forwards for our methods.
 */
int dect_drv_open   (struct inode *inode, struct file *filp);
int dect_drv_release(struct inode *inode, struct file *filp);
long dect_drv_ioctl  (struct file *filp, unsigned int cmd, unsigned long arg);
int dect_drv_poll   (struct file *file, poll_table *wait);
int dect_drv_write  (struct file *file_p, char *buf, size_t count, loff_t *ppos);
int dect_drv_read   (struct file *file_p, char *buf, size_t count, loff_t *ppos);

/* 
 * The operations for device node handled.
 */
struct file_operations dect_drv_fops =
{
    owner:
        THIS_MODULE,
    read:
        dect_drv_read,
    write:
        (void*)dect_drv_write,
    poll: 
        (void*)dect_drv_poll,
    unlocked_ioctl:
        (void*) dect_drv_ioctl,
    open:
        dect_drv_open,
    release:
        dect_drv_release
};
#endif /* LINUX */

/*******************************************************************************
Description:
Arguments:
Note:
*******************************************************************************/
#ifdef LINUX
int dect_drv_read(struct file *file_p, char *buf, size_t count, loff_t *ppos)
#endif
#ifdef SUPERTASK
int dect_drv_read(char *buf, int count, void *ppos)
#endif
{
  return 0;
}

/*******************************************************************************
Description:
Arguments:
Note:
*******************************************************************************/
#ifdef LINUX
int dect_drv_write(struct file *file_p, char *buf, size_t count, loff_t *ppos)
#endif
#ifdef SUPERTASK
int dect_drv_write(char *buf, int count, void *ppos)
#endif
{
  return 0;
}

/*******************************************************************************
Description:
   The function for the system call "select".
Arguments:
Note:
*******************************************************************************/
#ifdef LINUX
int dect_drv_poll(struct file *file_p, poll_table *wait)
#endif
#ifdef SUPERTASK
int dect_drv_poll()
#endif
{
   int ret = 0;
   #ifdef CONFIG_SMP2
      unsigned long flags;
   #endif

   #ifdef LINUX
   /* install the poll queues of events to poll on */
   poll_wait(file_p, &Dect_WakeupList, wait);
   #endif

   #ifdef CONFIG_SMP2
      spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   #endif

   if ((Dect_excpFlag)&&(vucDriverMode == DECT_DRV_SET_LOADER_MODE)){
      if ( vu16ReadBufHead != vu16ReadBufTail )
      {
         #ifdef LINUX
         ret |= (POLLIN | POLLRDNORM);
         #endif
         #ifdef SUPERTASK
		  	ret = 1;
         #endif
      }
      Dect_excpFlag = 0;

   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif
      return ret;
   }

   if (send_to_stack_buf_w_count != send_to_stack_buf_r_count)
   {
      #ifdef LINUX
      ret |= (POLLIN | POLLRDNORM);
      #endif
      #ifdef SUPERTASK
      ret = 1;
      #endif
      Dect_excpFlag = 0;
   }

   if (receive_to_debug_info_buf_w_count != receive_to_debug_info_buf_r_count)
   {
      #ifdef LINUX
      ret |= (POLLOUT | POLLRDNORM);
      #endif
      #ifdef SUPERTASK
      ret = ret|(0x02);
      #endif
      Dect_excpFlag = 0;
   }

   #ifdef SUPERTASK
   if (send_to_debug_info_buf_w_count != send_to_debug_info_buf_r_count)
   {
      ret = ret|(0x04);
      Dect_excpFlag = 0;
   }
   if (send_to_lmac_buf_w_count != send_to_lmac_buf_r_count)
   {
      ret = ret|(0x08);
      Dect_excpFlag = 0;
   }
   #endif

   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif

   return ret;
}

/*******************************************************************************
Description:
   Handle IOCTL commands.
Arguments:
Note:
*******************************************************************************/
#ifdef LINUX
long dect_drv_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
#endif
#ifdef SUPERTASK
int dect_drv_ioctl(unsigned int cmd, unsigned long arg)
#endif
{
   int res;
   unsigned short u16Len;
   unsigned char* pucBuf;

	//printk("\n IOCTL %d\n",cmd);
#if 1
	if(vucDriverMode ==  DECT_DRV_SET_APP_MODE_CoC_RQ)
	{
		/*No need to respond with CoC dummy pkt as we have valid data and don't want to enter CoC. 
			So change state and no need to toggle CS as not yet entered CoC confirm state*/
	   vucDriverMode = DECT_DRV_SET_APP_MODE;
	}
	else if(vucDriverMode ==  DECT_DRV_SET_APP_MODE_CoC_CNF)
	{
	   /*Toggle CS to indicate MODEM to come out of CoC*/
	   ssc_dect_cs_toggle();
	   vucDriverMode = DECT_DRV_SET_APP_MODE;	 									
	   printk("\nToggling CS to come out of CoC\n");
	}
#endif
   switch(cmd)
   {
      #ifdef LINUX
      case DECT_DRV_SHUTDOWN:
	      dect_drv_release(NULL,filp);
         break;
      #endif

      case DECT_DRV_TRIGGER_COSIC_DRV:
         {
            unsigned char data[2];

            #ifdef LINUX
            copy_from_user ( data, (unsigned char *)arg, sizeof( data ) );
            #endif
            #ifdef SUPERTASK
            memcpy(data,(unsigned char *)arg,sizeof(data));
            #endif
            if( (data[ 0 ] == 1) && (data[ 1 ] == 1) )
            {
               gp_onu_disable_external_interrupt( );
            }
            trigger_cosic_driver( );
         }
         break;  

      case DECT_DRV_TO_HMAC_MSG :
         {
            #ifdef LINUX
            HMAC_QUEUES value;

            copy_from_user ((HMAC_QUEUES *)&value, (HMAC_QUEUES *)arg, sizeof (HMAC_QUEUES));
            #endif
			#if 0
            if(vucDriverMode ==  DECT_DRV_SET_APP_MODE_CoC_RQ)
      		{
   				/*No need to respond with CoC dummy pkt as we have valid data and don't want to enter CoC. 
   					So change state and no need to toggle CS as not yet entered CoC confirm state*/
               vucDriverMode = DECT_DRV_SET_APP_MODE;
            }
            else if(vucDriverMode ==  DECT_DRV_SET_APP_MODE_CoC_CNF)
            {
           	   /*Toggle CS to indicate MODEM to come out of CoC*/
           	   ssc_dect_cs_toggle();			  
           	   ssc_dect_cs_toggle();    
			   printk("\nToggling CS to come out of CoC\n");
            }
			#endif
            #ifdef LINUX
          	DECODE_HMAC(&value);
          	#endif
          	#ifdef SUPERTASK
            DECODE_HMAC((HMAC_QUEUES *)arg);
          	#endif
         }
         break;

      case DECT_DRV_FROM_HMAC_MSG :
      	res = 0;
      	#ifdef SUPERTASK
         BLOCK_PREEMPTION;
      	#endif

         while(1)
      	{
			   #ifdef CONFIG_SMP2
     		 		unsigned long flags;
					HMAC_QUEUES send_to_stack_buf_local;
      			spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   			#endif

      	   if (send_to_stack_buf_r_count != send_to_stack_buf_w_count)
      	   {
			   	#ifdef CONFIG_SMP2
               	memcpy ((unsigned char *)&send_to_stack_buf_local, (unsigned char*)&send_to_stack_buf[send_to_stack_buf_r_count], sizeof(HMAC_QUEUES));
					#else
      	      #ifdef LINUX
               copy_to_user ((void *)arg, (unsigned char*)&send_to_stack_buf[send_to_stack_buf_r_count], sizeof(HMAC_QUEUES));
               #endif
               #endif
               #ifdef SUPERTASK
               memcpy ((unsigned char *)arg, (unsigned char*)&send_to_stack_buf[send_to_stack_buf_r_count], sizeof(HMAC_QUEUES));
               #endif
               memset((unsigned char*)&send_to_stack_buf[send_to_stack_buf_r_count], 0x00, sizeof(HMAC_QUEUES));
               send_to_stack_buf_r_count++;
      	  
      		   if (send_to_stack_buf_r_count == MAX_RECEIVED_BUFFER_COUNT)
      		      send_to_stack_buf_r_count = 0;

				   #ifdef CONFIG_SMP2
      				spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
               	copy_to_user ((void *)arg, (unsigned char*)&send_to_stack_buf_local, sizeof(HMAC_QUEUES));
   				#endif

      			arg += sizeof(HMAC_QUEUES);
      			res++;
      	   }
      	   else
      	   {
				   #ifdef CONFIG_SMP2
      				spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   				#endif
      		   if(res == 0)
      		   {
      		      #ifdef SUPERTASK
                  UNBLOCK_PREEMPTION;
      		      #endif
      			   return -1;
      			}
      		   else
      		   {
                  #ifdef SUPERTASK
                  UNBLOCK_PREEMPTION;
                  #endif
      			   return res;
      			}
      	   }
      	}
         break;

      case DECT_DRV_GET_PMID :
         {
            unsigned char data[4];

            copy_from_user (data, (unsigned char *)arg, 4);
            Get_Used_Pmid(data[0], &data[1]);
            copy_to_user ((void *)arg, data, 4);
         }
         break;

   #ifdef CONFIG_REPEATER_SUPPORT
      case DECT_DRV_GET_REP_PMID :
         {
            unsigned char data[5];

            copy_from_user (data, (unsigned char *)arg, 5);
            Get_Used_Rep_Pmid(data[0], data[1], &data[2]);
            copy_to_user ((void *)arg, data, 5);
         }
         break;

      case DECT_DRV_GET_REP_NUM :
         {
            unsigned char data[2];

            copy_from_user (data, (unsigned char *)arg, 2);
            Get_Used_Rep_Num(data[0], &data[1]);
            copy_to_user ((void *)arg, data, 2);
         }
         break;
   #endif
   
      case DECT_DRV_GET_ENC_STATE :
         {
            unsigned char data[2];

            copy_from_user (data, (unsigned char *)arg, sizeof (data));
            data[1] = Get_Enc_State(data[0]);
            copy_to_user ((void *)arg, data, sizeof (data));        
         }
         break;
      
      case DECT_DRV_SET_KNL_STATE :
         {
            unsigned char data[2];

            copy_from_user (data, (unsigned char *)arg, sizeof (data));
            Set_KNL_State(data[0], data[1]);
         }
         break;

      case DECT_DRV_DEBUG_INFO:
         {
            #ifdef LINUX
            DECT_MODULE_DEBUG_INFO value;

            copy_from_user ((DECT_MODULE_DEBUG_INFO *)&value, (DECT_MODULE_DEBUG_INFO *)arg, sizeof (DECT_MODULE_DEBUG_INFO));
            DECODE_DEBUG_TO_MODULE(&value);
            #endif
            #ifdef SUPERTASK
            DECODE_DEBUG_TO_MODULE((DECT_MODULE_DEBUG_INFO *)arg);
            #endif
         }
         break;

      case DECT_DRV_DEBUG_INFO_FROM_MODULE:
      	res = 0;

      	while(1)
      	{
			   #ifdef CONFIG_SMP2
      			unsigned long flags;
					DECT_MODULE_DEBUG_INFO receive_to_debug_info_buf_local;
					spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   			#endif
      	   if (receive_to_debug_info_buf_r_count != receive_to_debug_info_buf_w_count)
      	   {
			   #ifdef CONFIG_SMP2
      		   memcpy((unsigned char*)&receive_to_debug_info_buf_local, 
								(unsigned char*)&receive_to_debug_info_buf[receive_to_debug_info_buf_r_count], 
																sizeof(DECT_MODULE_DEBUG_INFO));
				#else
      		   copy_to_user ((void *)arg, (unsigned char*)&receive_to_debug_info_buf[receive_to_debug_info_buf_r_count], sizeof(DECT_MODULE_DEBUG_INFO));
				#endif
      		   memset((unsigned char*)&receive_to_debug_info_buf[receive_to_debug_info_buf_r_count], 0x00, sizeof(DECT_MODULE_DEBUG_INFO));
      		   receive_to_debug_info_buf_r_count++;
      	  
      		   if (receive_to_debug_info_buf_r_count == MAX_DEBUG_INFO_COUNT)
      		      receive_to_debug_info_buf_r_count = 0;

				   #ifdef CONFIG_SMP2
     					spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
     		   		copy_to_user ((void *)arg, (unsigned char*)&receive_to_debug_info_buf_local, sizeof(DECT_MODULE_DEBUG_INFO));
  					#endif
      		   arg += sizeof(DECT_MODULE_DEBUG_INFO);
      		   res++;
      	   }
      	   else
      	   {
				   #ifdef CONFIG_SMP2
      				spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   				#endif
      		   if(res == 0)
      			   return -1;
      		   else
      			   return res;
      	   }
      	}
      	break;

      case DECT_DRV_SET_LOADER_MODE:
		{
			#ifdef CONFIG_SMP2
      		unsigned long flags;
				spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   		#endif
         vucDriverMode = DECT_DRV_SET_LOADER_MODE;
         vu16ReadBufHead = vu16ReadBufTail = vu16WriteBufHead = vu16WriteBufTail = 0;
         memset(vucReadBuffer,0,sizeof(vucReadBuffer));
         memset(vucWriteBuffer,0,sizeof(vucWriteBuffer));

   		#ifdef CONFIG_SMP2
      		spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   		#endif
		/* 4. reset pin setting high */
         ssc_dect_haredware_reset(1);
         #ifdef LINUX
         /*printk("Moving to LOADER MODE\n");*/
         #endif
         #ifdef SUPERTASK
         /* Fw_DOWNLOAD Init*/
         vu16ReadBufHead = vu16ReadBufTail = vu16WriteBufHead = vu16WriteBufTail = 0;
         memset(vucReadBuffer,0,sizeof(vucReadBuffer));
         memset(vucWriteBuffer,0,sizeof(vucWriteBuffer));
         cosic_printf("DOWNLOADING COSIC FIRMWARE\n");
         #endif
		}
         break;

      case DECT_DRV_SET_APP_MODE:
         vucDriverMode = DECT_DRV_SET_APP_MODE;
         #ifdef LINUX
         /*printk("Moving to APP MODE\n");*/
         #endif
         #ifdef SUPERTASK
         cosic_printf("DOWNLOAD COMPLETE Moving to APP MODE\n");
         #endif
         break;

      case DECT_DRV_FW_WRITE:
		{
   		#ifdef CONFIG_SMP2
      		unsigned long flags;
				unsigned char vucWriteBuffer_local[COSIC_LOADER_PACKET_SIZE]={0};
   		#endif	
         #ifdef LINUX
         copy_from_user((void*)(&u16Len),(void*)arg,2); //read len
         //printk(": Write buffer len=%d\n",u16Len);
         #endif
         #ifdef SUPERTASK
         memcpy((void*)(&u16Len),(void*)arg,2); //read len
         #endif
         if( u16Len < COSIC_LOADER_PACKET_SIZE ) {
   		#ifdef CONFIG_SMP2
            copy_from_user((void*)vucWriteBuffer_local, (void*)arg, u16Len+2);
				spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
            memcpy((void*)vucWriteBuffer[vu16WriteBufHead], (void*)vucWriteBuffer_local, u16Len+2);
			#else
            #ifdef LINUX
            copy_from_user((void*)vucWriteBuffer[vu16WriteBufHead], (void*)arg, u16Len+2);
            #endif
         #endif
            #ifdef SUPERTASK
            memcpy((void*)vucWriteBuffer[vu16WriteBufHead], (void*)arg, u16Len+2);
            #endif
            ++vu16WriteBufHead;
            if(vu16WriteBufHead == MAX_READ_BUFFFERS)
            {
               vu16WriteBufHead=0;
            }
            if( vu16WriteBufHead == vu16WriteBufTail )
            {
               printk(": Write buffer full\n");
               ++vu16WriteBufTail;
               if(vu16WriteBufTail == MAX_READ_BUFFFERS)
                  vu16WriteBufTail = 0;
            }
   			#ifdef CONFIG_SMP2
      			spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   			#endif
         }// packet size check
			}
         break;

      case DECT_DRV_FW_READ:
		{
   		#ifdef CONFIG_SMP2
      		unsigned long flags;
      		spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   		#endif
         //If data available, copy to user buffer
         if( vu16ReadBufHead != vu16ReadBufTail )
         {
            pucBuf = vucReadBuffer[vu16ReadBufTail];
            u16Len = ((*pucBuf) << 8) + (*(pucBuf+1));
            ++vu16ReadBufTail;
            if(vu16ReadBufTail == MAX_READ_BUFFFERS)
               vu16ReadBufTail = 0;
         }
         #ifdef CONFIG_SMP2
         spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
         #endif

         #ifdef LINUX
         /*DEBUG_MSG(COSIC_LOADER_NAME ": ReadBufer(Head=%d Tail=%d) Tail Buf Len=%d\n", vu16ReadBufHead,vu16ReadBufTail,u16Len);*/
         copy_to_user((void*)arg, pucBuf,u16Len+2); //+2 including len field
         #endif

         #ifdef SUPERTASK
         memcpy((void*)arg, pucBuf,u16Len+2); //+2 including len field
         #endif

		}
      break;

#ifdef LINUX
   	case DECT_DRV_IRQ_CTRL:
         {
            unsigned char  data;
            copy_from_user ( &data, (unsigned char *)arg, 1);
#undef printk
            printk("Entering inside DECT_DRV_IRQ_CTRL with value %d\n",data);
            if(data==1)//Enable IRQ
            {
               viDisableIrq = 0;
               #if 1
               if(iIrqStatus==0){
                  enable_irq(dect_gpio_intnum);
                  iIrqStatus=1;
               }
               else{
                  break;
               }
               #else
               gp_onu_enable_external_interrupt();	  
               #endif
            }else{//Disable IRQ
               viDisableIrq=1;	
            }
         }
         break;

   	case DECT_DRV_ENABLE:
         {
            unsigned char  data;

            copy_from_user ( &data, (unsigned char *)arg, 1);
            printk("Entering inside DECT_DRV_ENABLE with value %d\n",data);
            if(data==1){
   				#ifdef CONFIG_SMP2
      				unsigned long flags;
						spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   				#endif
               vu16ReadBufHead = vu16ReadBufTail = vu16WriteBufHead = vu16WriteBufTail = 0;
               memset(vucReadBuffer,0,sizeof(vucReadBuffer));
               memset(vucWriteBuffer,0,sizeof(vucWriteBuffer));

				   #ifdef CONFIG_SMP2
      				spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   				#endif
               //ssc_dect_haredware_reset(1);
               ifx_sscCosicLock();
            }else{
               if(spi_dev_handler != NULL)
               {
						#ifdef CONFIG_SMP
							{
								unsigned long flags;
   							spin_lock_irqsave(&IntEdgFlgLock,flags);
						#endif
                  		if(viSPILocked)
                  		{
									#ifdef CONFIG_SMP
   									spin_unlock_irqrestore(&IntEdgFlgLock,flags);
									#endif
                     		ifx_sscAsyncUnLock(spi_dev_handler);
									#ifdef CONFIG_SMP
									   spin_lock_irqsave(&IntEdgFlgLock,flags);
									#endif
                     		viSPILocked=0;
									#ifdef CONFIG_SMP
   									spin_unlock_irqrestore(&IntEdgFlgLock,flags);
									#endif
                  		}
				#ifdef CONFIG_SMP
								else
								{
   									spin_unlock_irqrestore(&IntEdgFlgLock,flags);
								}	
						}	
				#endif
               }

#ifdef CONFIG_SMP
	{
		unsigned long flags;
   	spin_lock_irqsave(&IntEdgFlgLock,flags);
#endif
               vucDriverMode=0;
               ////FirstLock=1;
#ifdef CONFIG_SMP
   spin_unlock_irqrestore(&IntEdgFlgLock,flags);
	}
#endif
               ssc_dect_haredware_reset(0);
            }
         }
      	break;
#endif /* LINUX */

      default:
         break;
   }
  
  return 0;
}

/*function to toggle Chip Select PIN required to come out of CoC*/
u32 ssc_dect_cs_toggle()
{
//		printk("\n Toggle!!!!!  \n"); 
   if(viCSStatus)
   {
      #ifdef LINUX
      #if defined(CONFIG_IFX_GW188)||defined(CONFIG_AR10)
      ifx_gpio_output_clear(IFX_DECT_SPI_CS, dect_gpio_module_id);
      #else
	#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
//        if (of_machine_is_compatible("lantiq,ar10"))   
//			if ((of_machine_is_compatible("lantiq,ar10")) || (of_machine_is_compatible("lantiq,grx390")))
			if ((iPlatform == DECT_AR10) || (iPlatform == DECT_GRX390))
        { 
//		printk("\n Toggle 0 \n"); 
                gpio_set_value (DECT_CS, 0);   
        }  
			#if 0
			else if (iPlatform == DECT_GRX500) 
			{
      		//ifx_ssc_cs_low_port1(DECT_CS);
      		//printk("\n Toggle  DECT_GRX500 H2L!!!!!  \n");
      		ifx_ssc_cs_low(DECT_CS);
			}
			#endif
        else   
	#endif
	{
      		ifx_ssc_cs_low(DECT_CS);			
	}
      #endif
      #endif /* LINUX */
      #ifdef SUPERTASK
      ifx_ssc_cs_low(DECT_CS);
      #endif /* SUPERTASK */
      viCSStatus=IFX_DECT_OFF;
   }
   else
   {
      #ifdef LINUX
      #if defined(CONFIG_IFX_GW188)||defined(CONFIG_AR10)
      ifx_gpio_output_set(IFX_DECT_SPI_CS, dect_gpio_module_id);
      #else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
//	if (of_machine_is_compatible("lantiq,ar10")) 
//	if ((of_machine_is_compatible("lantiq,ar10")) || (of_machine_is_compatible("lantiq,grx390")))
	 if ((iPlatform == DECT_AR10) || (iPlatform == DECT_GRX390))
	{
//		printk("\n Toggle 1 \n"); 
		gpio_set_value (DECT_CS, 1);
	}
	#if 0
   else if (iPlatform == DECT_GRX500)
   {
			//ifx_ssc_cs_high_port1(DECT_CS);
			//printk("\n Toggle  DECT_GRX500 L2H!!!!!  \n");
			ifx_ssc_cs_high(DECT_CS);
	}
   #endif
	else
#endif
	{
			ifx_ssc_cs_high(DECT_CS);
	}
      #endif
      #endif /* LINUX */
      #ifdef SUPERTASK
      ifx_ssc_cs_high(DECT_CS);
      #endif /* SUPERTASK */
      viCSStatus=IFX_DECT_ON;
	}
	return 0;
}

u32 ssc_dect_cs(u32 on, u32 cs_data)
{
	#ifdef CONFIG_SMP
		unsigned long flags;
   	spin_lock_irqsave(&IntEdgFlgLock,flags);
	#endif
   //printk("\nCSCB\n");
   if(viSPILockedCB)
   {

		#ifdef CONFIG_SMP
   		spin_unlock_irqrestore(&IntEdgFlgLock,flags);
		#endif

      #ifdef SUPERTASK
  	   ichipCSCount++;
      #endif

      if (iCosicMode == 0) /* Tx */
      {
    //     printk("\nCS->low\n");
         #ifdef LINUX
         #ifdef ENHANCED_DELAY
         udelay(vuiDealy);		 /*Testing delay before toggle */
         #endif
         #if defined(CONFIG_IFX_GW188)||defined(CONFIG_AR10)
  	      //	printk("\n-Bala -CS->low CS number %d \n",IFX_DECT_SPI_CS);
         ifx_gpio_output_clear(IFX_DECT_SPI_CS, dect_gpio_module_id);
         #else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
	//if (of_machine_is_compatible("lantiq,ar10")) 
//	if ((of_machine_is_compatible("lantiq,ar10")) || (of_machine_is_compatible("lantiq,grx390")))
	if ((iPlatform == DECT_AR10) || (iPlatform == DECT_GRX390))
	{
      //   printk("\nCS->low1\n");
		gpio_set_value (DECT_CS, 0);
	}
   #if 0
   else if (iPlatform == DECT_GRX500)
   {
			//ifx_ssc_cs_low_port1(DECT_CS);
			ifx_ssc_cs_low(DECT_CS);
   }
   #endif
	else
#endif
	{
			ifx_ssc_cs_low(DECT_CS);
	}

         #endif
         #endif /* LINUX */
         #ifdef SUPERTASK
         #ifdef _INFXR9
         ifx_ssc_cs_low(DECT_CS);
         #else
         *DANUBE_GPIO_P0_OUT &= ~(1<<14);    //GPIO14
         #endif
         #endif /* SUPERTASK */
			viCSStatus=IFX_DECT_OFF;/*store the CS state; required for ssc_dect_cs_toggle*/
         #ifdef LINUX
         udelay(20);		 /*delay change 8 -> 10 */
         #endif
         #ifdef SUPERTASK
         sysUDelay(20); //50
         ichipCSTxCount++;
         #endif
      }
      else /* Rx */
      {
  	      //printk("\nCS->High\n");
  	      #ifdef LINUX
         #ifdef ENHANCED_DELAY
         udelay(vuiDealy);		 /*Testing delay before toggle */
         #endif
         #if defined(CONFIG_IFX_GW188)||defined(CONFIG_AR10)
         //printk("\n-Bala -CS->High CS number %d \n",IFX_DECT_SPI_CS);
         ifx_gpio_output_set(IFX_DECT_SPI_CS, dect_gpio_module_id);
         #else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
	//if (of_machine_is_compatible("lantiq,ar10")) 
	//if ((of_machine_is_compatible("lantiq,ar10")) || (of_machine_is_compatible("lantiq,grx390")))
	if ((iPlatform == DECT_AR10) || (iPlatform == DECT_GRX390))
	{
  	  //    printk("\nCS->High1\n");
		gpio_set_value (DECT_CS, 1);
	}
	#if 0
	else if (iPlatform == DECT_GRX500)
   {
			//ifx_ssc_cs_high_port1(DECT_CS);
			ifx_ssc_cs_high(DECT_CS);
   }
	#endif
	else
#endif
	{
			ifx_ssc_cs_high(DECT_CS);
	}
         #endif
         #endif /* LINUX */
         #ifdef SUPERTASK
         #ifdef _INFXR9
         ifx_ssc_cs_high(DECT_CS);
         #else
         *DANUBE_GPIO_P0_OUT |= (1<<14);     //GPIO14
         #endif			
         #endif /* SUPERTASK */
         viCSStatus=IFX_DECT_ON;/*store the CS state; required for ssc_dect_cs_toggle*/
         #ifdef LINUX
         udelay(20);		 /*delay change 8 -> 10 */
         #endif
         #ifdef SUPERTASK
         sysUDelay(20);//50
         ichipCSRxCount++;
         #endif
      }

		#ifdef CONFIG_SMP
   		spin_lock_irqsave(&IntEdgFlgLock,flags);
		#endif

      viSPILockedCB=0;

		#ifdef CONFIG_SMP
   		spin_unlock_irqrestore(&IntEdgFlgLock,flags);
		#endif
   }
	else
	{
		#ifdef CONFIG_SMP
   		spin_unlock_irqrestore(&IntEdgFlgLock,flags);
		#endif
	}
   return 0;
}

/* dect hard ware reset pin control function */
int ssc_dect_haredware_reset(int on)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
   if(on)
	gpio_set_value (IFX_DECT_RST, 1);
   else
	gpio_set_value (IFX_DECT_RST, 0);
     
#else
   if(on)
   {
      #ifdef LINUX
      #ifdef CONFIG_AMAZON_S
      #ifdef UTA
      *(AMAZON_S_GPIO_P3_OUT) = (*AMAZON_S_GPIO_P3_OUT) | (1<<5);
      #else
      *(AMAZON_S_GPIO_P1_OUT) = (*AMAZON_S_GPIO_P1_OUT) | (1<<6);
      #endif	  
      #elif defined (CONFIG_AR9) || defined (CONFIG_VR9)
      ifx_gpio_output_set(IFX_DECT_RST, dect_gpio_module_id);
      #endif
      #endif /* LINUX */
      #ifdef SUPERTASK
      //Demo board use GPIO20 as reset
      //   *(DANUBE_GPIO_P1_OUT) = (*DANUBE_GPIO_P1_OUT)| 0x00000010;
      #ifdef _INFXR9
      ifx_gpio_output_set(IFX_DECT_RST, IFX_GPIO_MODULE_DECT);
      #else
      DECT_Reset(1);
      #endif
      #endif /* SUPERTASK */
   }
   else
   {
      #ifdef LINUX
      #ifdef CONFIG_AMAZON_S
      #ifdef UTA
      *(AMAZON_S_GPIO_P3_OUT) = (*AMAZON_S_GPIO_P3_OUT) & (~(1<<5));
      #else
      *(AMAZON_S_GPIO_P1_OUT) = (*AMAZON_S_GPIO_P1_OUT) & (~(1<<6));
      #endif	  
      #elif defined (CONFIG_AR9) || defined (CONFIG_VR9)
      ifx_gpio_output_clear(IFX_DECT_RST, dect_gpio_module_id);
      #endif
      #endif /* LINUX */
      #ifdef SUPERTASK
      //Demo board use GPIO20 as reset
      //   *(DANUBE_GPIO_P1_OUT) = (*DANUBE_GPIO_P1_OUT) & (~0x00000010);
      #ifdef _INFXR9
      ifx_gpio_output_clear(IFX_DECT_RST, IFX_GPIO_MODULE_DECT);
      #else
      DECT_Reset(0);
      #endif
      #endif /* SUPERTASK */
   }
#endif
   return 0;
}
#ifdef LINUX
EXPORT_SYMBOL(ssc_dect_haredware_reset);
#endif

/*******************************************************************************
Description:
   Open the Dect driver.
Arguments:
Note:
*******************************************************************************/
#ifdef SUPERTASK
int cosic_module_init=0;
extern int  vinetic_drv_init;
int pid_check_DECT_event=-1;
void check_DECT_event();
#endif

#ifdef LINUX
int dect_drv_open(struct inode *inode, struct file *filp)
#endif
#ifdef SUPERTASK
int dect_drv_open()
#endif
{
   #ifdef LINUX
   unsigned int num;
   #endif

   #ifdef SUPERTASK
   #ifndef _INFXR9
   iprintf(">>>>>>>>>>>>>>>> DECT Driver: dect_drv_open() Reset COSIC DECT again...\n");
   DECT_Reset(0); //Reset COSIC DECT again.
   SPI_access_wait(1);  //For suspend ISDN SPI access.
   //dlytsk(cur_task,DLY_SECS,5);
   dlytsk(cur_task,DLY_SECS,1);
   #endif
   #endif /* SUPERTASK */

   if (open_dect_count)
      return -1;

   #ifdef LINUX
   dect_gpio_intnum = DECT_IRQ_NUM;
   num = MINOR(inode->i_rdev);
   if (num > DECT_DRV_MINOR_1)
   {
      printk("DECT Driver: Minor number error!\n");
      return -1;
   }
	////FirstLock =1;   
   //printk(DECT_DEVICE_NAME " : Device open (%d, %d)\n\n", MAJOR(inode->i_rdev), MINOR(inode->i_rdev));
   #endif

   open_dect_count++;

   /* Use filp->private_data to point to the device data. */
   filp->private_data = (void *)num;
#ifdef CONFIG_SMP
	spin_lock_init(&IntEdgFlgLock);
	spin_lock_init(&IOCTL_TASKET_Lock);
#ifdef CONFIG_SMP4
	spin_lock_init(&DECT_TAPI_Lock);
#endif 
#endif 
   /* Initialize a wait_queue list for the system poll function. */ 
   init_waitqueue_head(&Dect_WakeupList);
   HMAC_INIT();
   #ifdef LINUX
   vucDriverMode=0;
   #endif

   Reset_Hmac_Debug_buffer();
          
   #ifdef LINUX
	atomic_set(&vuiGwDbgFlag,1);
	#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
	gpio_request (IFX_DECT_RST, "dect-reset");
	gpio_direction_output (IFX_DECT_RST, 0);

	//if (of_machine_is_compatible("lantiq,ar10")) 
//	if ((of_machine_is_compatible("lantiq,ar10")) || (of_machine_is_compatible("lantiq,grx390")))
	if ((iPlatform == DECT_AR10) || (iPlatform == DECT_GRX390))
	{
		gpio_request (DECT_CS, "dect-cs");
		gpio_direction_output (DECT_CS, 0);
	}
	

#else	
   Dect_int_GPIO_init();
#endif

   {
      IFX_SSC_CONFIGURE_t ssc_cfg = {0};

      ssc_cfg.baudrate     = 4000000; // TODO: baudrate is int valiable????
      #ifdef LINUX
      ssc_cfg.csset_cb     = (int (*)(u32,IFX_CS_DATA))ssc_dect_cs;
      #endif
      #ifdef SUPERTASK
      ssc_cfg.csset_cb     = (void*)ssc_dect_cs;
      #endif
      ssc_cfg.cs_data      = DECT_CS;
      ssc_cfg.fragSize	 = 512;
      ssc_cfg.maxFIFOSize  = 512;
      ssc_cfg.ssc_mode     = IFX_SSC_MODE_3;
      #ifdef LINUX
      ssc_cfg.ssc_prio = IFX_SSC_PRIO_ASYNC;
#ifdef DECT_USE_USIF
    printk ("DECT: Setting Half Duplex for USIF..\n");
    ssc_cfg.maxFIFOSize  = 512;
    ssc_cfg.duplex_mode  = LANTIQ_USIF_SPI_HALF_DUPLEX;
#endif
#if defined(CONFIG_AR10)
#ifdef DECT_USE_USIF
      ssc_cfg.maxFIFOSize  = 512;
      ssc_cfg.duplex_mode  = IFX_USIF_SPI_HALF_DUPLEX;
#endif
#endif
      #endif /* LINUX */
      #ifdef SUPERTASK
      ssc_cfg.ssc_prio     = IFX_SSC_PRIO_HIGH;
      #endif /* SUPERTASK */
      spi_dev_handler = ifx_sscAllocConnection(DECT_DEVICE_NAME, &ssc_cfg);

      if (spi_dev_handler == NULL)
      {
         printk("failed to register spi device \n");
         return -1;
      }
   }

   

	/* Initialize the buffer pools */
   #ifndef USE_VOICE_BUFFERPOOL
   pTapiWriteBufferPool = bufferPoolInit(sizeof(TAPI_VOICE_WRITE_BUFFER), MAX_TAPI_BUFFER_CNT,5);

   if(pTapiWriteBufferPool == NULL)
   {
      printk("Error initilizing the write buffer pool\n");
   }
   #endif

   #ifdef LINUX
   if(!create_dir){

  create_dir++;
      #if CONFIG_PROC_FS

  //printk ("DECT: Initialising the proc..\n");

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,0))
  //printk ("DECT: Initialising the proc higher Kernel..\n");
	proc_EntriesInstall();
#else
      dect_proc_dir = proc_mkdir("driver/dect", NULL);

      if (dect_proc_dir != NULL)
      {
         dect_version_file = create_proc_read_entry("version", S_IFREG|S_IRUGO, dect_proc_dir,
                                                    dect_drv_read_proc, dect_drv_read_version_proc);
         if(dect_version_file != NULL)
         {
            #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
            dect_version_file->owner = THIS_MODULE;
            #endif
         }
         
         dect_gw_stats_file = create_proc_entry("gw-stats", 0644, dect_proc_dir);
         if(dect_gw_stats_file != NULL)
         {
            #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
            dect_gw_stats_file->owner = THIS_MODULE;
            #endif
            dect_gw_stats_file->data = dect_drv_read_gw_stats_proc;
            dect_gw_stats_file->read_proc = dect_drv_read_proc;
            dect_gw_stats_file->write_proc = dect_drv_write_proc;
         }
         
         dect_modem_stats_file = create_proc_entry("modem-stats", 0644, dect_proc_dir);
         if(dect_modem_stats_file != NULL)
         {
            #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
            dect_modem_stats_file->owner = THIS_MODULE;
            #endif
            dect_modem_stats_file->data = dect_drv_read_modem_stats_proc;
            dect_modem_stats_file->read_proc = dect_drv_read_proc;
            dect_modem_stats_file->write_proc = dect_drv_write_proc;
         }
         
         dect_channel_stats_file = create_proc_entry("channel-stats", 0644, dect_proc_dir);
         if(dect_channel_stats_file != NULL)
         {
            #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,30)
            dect_channel_stats_file->owner = THIS_MODULE;
            #endif
            dect_channel_stats_file->data = dect_drv_read_channel_stats_proc;
            dect_channel_stats_file->read_proc = dect_drv_read_proc;
            dect_channel_stats_file->write_proc = dect_drv_write_proc;
         }
      }
#endif
      #endif /* CONFIG_PROC_FS */
   }
   #endif /* LINUX */

   /* Fw_DOWNLOAD Init*/

   #ifdef CONFIG_SMP2
      unsigned long flags;
		spin_lock_irqsave(&IOCTL_TASKET_Lock,flags);
   #endif
   vu16ReadBufHead = vu16ReadBufTail = vu16WriteBufHead = vu16WriteBufTail = 0;
   memset(vucReadBuffer,0,sizeof(vucReadBuffer));
   memset(vucWriteBuffer,0,sizeof(vucWriteBuffer));

   #ifdef CONFIG_SMP2
      spin_unlock_irqrestore(&IOCTL_TASKET_Lock,flags);
   #endif

  //printk ("DECT: start_tapiThread\n");
   /* COSIC TAPI read THREAD */
   start_tapiThread();
  
   /* COSIC DRIVER THREAD */
  //printk ("DECT: start_COSIC Thread\n");
   start_cosicThread();
  //printk ("DECT: IRQ Request %d\n",dect_gpio_intnum);
   #ifdef LINUX
	#if 0
	if (iPlatform == DECT_GRX500)
	{
		if (gpio_request(31, "dummy_int") < 0)
			pr_err("gpio_request failed for pin 1\n");
		#if 0
		else
			pr_info ("gpio_request passed\n");
		#endif

		if (gpio_direction_input(31) < 0)
			pr_err("gpio_direction_input failed for pin 1\n");
		#if 0
		else
		pr_info ("gpio_direction input passed\n");
		#endif
	}
	#endif

   if( !request_irq( dect_gpio_intnum , Dect_GPIO_interrupt, IRQF_DISABLED, "dect", NULL))
   { 
  	//printk ("DECT: After IRQ Request\n");
      gp_onu_enable_external_interrupt();
		//printk ("DECT:request_irq passed: so enabled the external interrupt\n");
      iIrqStatus=1;	  
   } 
   else 
   { 
      printk("can't get assigned irq %d\n",dect_gpio_intnum);
      printk(" prnioport can't get assigned irq n");
      dect_gpio_intnum = -1;
   }
  //printk ("DECT: After IRQ Request\n");
#if 0
  	#ifdef LINUX
   		ifx_sscCosicLock();
   	#endif
#endif
   
   #endif /* LINUX */
   #ifdef SUPERTASK
   IrqConnect(dect_gpio_intnum ,0, Dect_GPIO_interrupt, NULL, NULL);
   IrqEnable(dect_gpio_intnum);
   gp_onu_enable_external_interrupt();

   if (cosic_MP_flag==1)
   {
      extern int  ipnt_enable;
      extern char disablePstnDetect;
      ipnt_enable=1;
      cosic_printf_onoff(1);
      iprintf(">>>>>>>>>>>>>>>>>>> SKIP ISDN/PSTN function Now for COSIC MP Testing...\n");
      EnableISDN(0);
      disablePstnDetect=1;
      cosic_module_init=1;
      //dect_mp_test_reset();
      IFX_DECT_DIAG_ModemDiagnostics(1);
   }
   else
   {
      //pid_check_DECT_event=runtsk(120,check_DECT_event,10240);
      IFX_DECT_AgentInit();
      //    pid_check_DECT_event=runtsk(120,check_DECT_event,0xB000);
      pid_check_DECT_event=runtsk(120,check_DECT_event,0xC000);
      cosic_module_init=1;
   }
   EnableGwDebugStats();
   #endif /* SUPERTASK */

   return 0;
}

/*******************************************************************************
Description:
   Close the Dect driver.
Arguments:
Note:
*******************************************************************************/
#ifdef LINUX
int dect_drv_release(struct inode *inode, struct file *filp)
#endif
#ifdef SUPERTASK
int dect_drv_release()
#endif
{
   #ifdef LINUX
   #if 0
	/*printk("\n"DECT_DEVICE_NAME " : Device release (%d, %d)\n\n", MAJOR(inode->i_rdev), MINOR(inode->i_rdev));*/
	if (--open_dect_count == 0)
	{
	}
   #endif

   stop_cosicThread();
   stop_tapiThread();
   if(open_dect_count)
   {
      ////FirstLock =1;
      ssc_dect_haredware_reset(0);
      if(dect_gpio_intnum != -1 ) 
      {
         disable_irq(dect_gpio_intnum);
         free_irq(dect_gpio_intnum , NULL); 
         dect_gpio_intnum = -1;
         #ifdef CONFIG_DANUBE
         ifx_gptu_timer_free(TIMER2A);
         #endif
      }
      if(spi_dev_handler != NULL)
      {
			#ifdef CONFIG_SMP
			{
				unsigned long flags;
   			spin_lock_irqsave(&IntEdgFlgLock,flags);
			#endif
         if(viSPILocked)
         {
			#ifdef CONFIG_SMP
   			spin_unlock_irqrestore(&IntEdgFlgLock,flags);
			#endif
            ifx_sscAsyncUnLock(spi_dev_handler);

			#ifdef CONFIG_SMP
   			spin_lock_irqsave(&IntEdgFlgLock,flags);
			#endif
            viSPILocked=0;
			#ifdef CONFIG_SMP
   			spin_unlock_irqrestore(&IntEdgFlgLock,flags);
			#endif

         }
			#ifdef CONFIG_SMP
			else
			{
   			spin_unlock_irqrestore(&IntEdgFlgLock,flags);
			}
			}
			#endif		 
         ifx_sscFreeConnection(spi_dev_handler);
         spi_dev_handler = NULL;
      }
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)
	gpio_free(IFX_DECT_RST);/*SBB:TBD Only COSIC Reset?*/
#else	
      ifx_gpio_deregister(IFX_GPIO_MODULE_DECT);
#endif

      #if CONFIG_PROC_FS
      if (create_dir)
      {
         remove_proc_entry("version",dect_proc_dir);
         remove_proc_entry("gw-stats",dect_proc_dir);
         remove_proc_entry("modem-stats",dect_proc_dir);
         remove_proc_entry("channel-stats",dect_proc_dir);
         remove_proc_entry("driver/dect",NULL);
         create_dir=0;
      }
      #endif /*CONFIG_PROC_FS*/
      vucDriverMode=0;
      open_dect_count = 0;
   }/*if (open_dect_count)*/
   #endif /* LINUX */
   #ifdef SUPERTASK
   printk("\n"DECT_DEVICE_NAME " : Device release ()\n\n");
   if (--open_dect_count == 0)
   {
   }
   //ifx_ssc_deregister_spi_dev(DECT_DEVICE_NAME);

   if(dect_gpio_intnum != -1 )
   {
      IrqDisable(dect_gpio_intnum);
      IrqDisconnect(dect_gpio_intnum);
	  if(viSPILocked)
     {
       ifx_sscAsyncUnLock(spi_dev_handler);
	   viSPILocked = 0;
     }
      ifx_sscFreeConnection(spi_dev_handler);
      dect_gpio_intnum = -1;
   }
   printk("\nDect_gpio_intnum=%d Stop\n",dect_gpio_intnum);
   stop_cosicThread();
   stop_tapiThread();

   // stop_kthread(&cosic_drv_kthread);
   printk("\nStop Cosic drv Thread\n");
   printk("I don't die! merong!\n");
   #endif

   return 0;
}

/*******************************************************************************
Description:
   register Dect driver to kernel
Arguments:
Note:
*******************************************************************************/
int dect_drv_init(void)
{
   #ifdef LINUX
   int result;

   result = register_chrdev(DECT_DRV_MAJOR, DECT_DEVICE_NAME, &dect_drv_fops);

   if (result < 0)
   {
      printk(KERN_INFO "DECT Driver: Unable to get major %d\n", DECT_DRV_MAJOR);
      return result;
   }
   #ifdef CONFIG_LTT
   result = marker_set_probe("cosic_event", "long %lu string %s", probe_cosic_event);
   if (!result){
      printk("Unable to set cosic marker\n");
      goto cleanup;
   }

   result = marker_set_probe("tapi_event", "long %lu string %s", probe_tapi_event);
   if (!result){
      printk("Unable to set tapi marker\n");
      goto cleanup;
   }

   return 0;
   cleanup:
   marker_remove_probe(probe_cosic_event);
   marker_remove_probe(probe_tapi_event);
   #endif
   #endif /* LINUX */

   return 0;
}

/*******************************************************************************
Description:
   clean up the DECT driver.
Arguments:
Note:
*******************************************************************************/
void dect_drv_cleanup(void)
{
   #ifdef LINUX
   #ifdef CONFIG_LTT
   marker_remove_probe(probe_cosic_event);
   marker_remove_probe(probe_tapi_event);
   #endif
   unregister_chrdev(DECT_DRV_MAJOR, DECT_DEVICE_NAME);
   
   #if 0 /* Commented for having sync with open */
   stop_cosicThread();
   stop_tapiThread();
   if(dect_gpio_intnum != -1 )
   {
      free_irq(dect_gpio_intnum , NULL);
      dect_gpio_intnum = -1;
      #ifdef CONFIG_DANUBE
      ifx_gptu_timer_free(TIMER2A);
      #endif
   } 
   #endif
   #if 0 /*CONFIG_PROC_FS*/
   remove_proc_entry("version",dect_proc_dir);
   remove_proc_entry("gw-stats",dect_proc_dir);
   remove_proc_entry("modem-stats",dect_proc_dir);
   remove_proc_entry("channel-stats",dect_proc_dir);
   
   remove_proc_entry("driver/dect",NULL);
   create_dir--;
   #endif
   #endif /* LINUX */
   #ifdef SUPERTASK
   if (dect_gpio_intnum != -1)
   {
      IrqDisconnect(dect_gpio_intnum);
   }
   #endif /* SUPERTASK */
}

#ifdef LINUX
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,00)

static int ltqdect_driver_probe(struct platform_device *pdev)
{
//	struct resource *res_irq=NULL;
	struct device_node *node = pdev->dev.of_node;
	//printk("\n ltqdect_driver_probe!!!!!!!!!!!\n");
#if 0
	if ((of_machine_is_compatible("lantiq,grx500")))
	{
		const unsigned int  *ptrDECT_INT=NULL;
		iPlatform = DECT_GRX500;
		ptrDECT_INT = of_get_property(node, "lantiq,dect-spi-int", NULL);
   	if (ptrDECT_INT)
       		DECT_IRQ_NUM=*ptrDECT_INT;
		else
		{
			printk("\n Could not read DECT SPI Interrupt from DTS!!!!!!!!!!!\n");
			return -ENODEV;
		}

	}
	else
#endif
	{
		DECT_IRQ_NUM = irq_of_parse_and_map(node, 0);
	}
	if (of_machine_is_compatible("lantiq,ar10")) 
	{
		iPlatform = DECT_AR10;
	}
	else if (of_machine_is_compatible("lantiq,grx390")) 
	{
		iPlatform = DECT_GRX390;
	}
	
/*         res_irq = platform_get_resource(pdev, IORESOURCE_IRQ, 2);
	if(!res_irq)
	{
		printk("\n Could not read DECT External INT from DTS!!!!!!!!!!!\n");
		return -ENODEV;
	}
	else
	DECT_IRQ_NUM=res_irq->start;
*/
         //DECT_IRQ_NUM= INT_NUM_IM1_IRL0+2;

	//if (of_machine_is_compatible("lantiq,ar10"))
	if ((of_machine_is_compatible("lantiq,ar10")) || (of_machine_is_compatible("lantiq,grx390")))
	{

		DECT_CS = of_get_named_gpio(node, "lantiq,dect-cs", 0);
		if (!gpio_is_valid(DECT_CS)) { 
		printk("\n Could not read DECT CS from DTS!!!!!!!!!!!\n");
		return -ENODEV;
		}
	}
	else
	{
		const unsigned int  *ptrDECT_CS=NULL;
		ptrDECT_CS = of_get_property(node, "lantiq,dect-cs", NULL);
   	if (ptrDECT_CS)
       		DECT_CS=*ptrDECT_CS;
		else
		{
			printk("\n Could not read DECT Chip select from DTS!!!!!!!!!!!\n");
			return -ENODEV;
		}
	}

        // DECT_CS=IFX_SSC_WHBGPOSTAT_OUT1_POS;


	IFX_DECT_RST = of_get_named_gpio(node, "gpio-reset", 0);
	if (!gpio_is_valid(IFX_DECT_RST)) { 
		printk("\n Could not read DECT RESET GPIO from DTS!!!!!!!!!!!\n");
		return -ENODEV;
	}
	
	printk("\n ltqdect_driver_probe : INT = %u, CS= %u, RESET=%u \n",DECT_IRQ_NUM,DECT_CS, IFX_DECT_RST);
         //IFX_DECT_RST= 200 + 14;

	dect_drv_init();
	return 0;
}

static int ltqdect_driver_remove(struct platform_device *pdev)
{
	printk("\n ltqdect_driver_remove!!!!!!!!!!!\n");
	dect_drv_cleanup();
	return 0;
}

/*!
   \brief This function is called when the driver is removed from the kernel
  with the rmmod command. The driver unregisters itself with its bus
  driver.
*/
static const struct of_device_id ltqdect_match[] = {
        { .compatible = "lantiq,ltqdect"},
        {},
};
MODULE_DEVICE_TABLE(of, ltqdect_match);

static struct platform_driver ltqdect_driver = {
        .probe = ltqdect_driver_probe,
        .remove = ltqdect_driver_remove,
        .driver = {
                .name = "lantiq,ltqdect",
                .owner = THIS_MODULE,
                .of_match_table = ltqdect_match,
        },
};
module_platform_driver(ltqdect_driver); 
#else
module_init(dect_drv_init);
module_exit(dect_drv_cleanup);
#endif
#endif
#ifdef SUPERTASK
//Used for show the latest FW build date time
int getBuildDate(int i, char *BuildDayStr)
{
   if (i==0)
   {
      strcpy(BuildDayStr, __DATE__);	//20:34:59
   }
   else
   {
      strcpy(BuildDayStr, __TIME__);	//20:34:59
   }
}
#endif

#if ((LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)) && CONFIG_PROC_FS && defined(LINUX)  ) || defined(SUPERTASK)
#ifdef LINUX
int dect_drv_read_proc(char *page, char **start, off_t off,
								int count, int *eof, void *data)
{
	int len;
	int (*fn)(char *buf);
	if (data != NULL)
	{
		fn = data;
		len = fn(page);
	}
	else
		return 0;

	if (len <= off+count)
		*eof = 1;

	*start = page + off;

	len -= off;

	if (len > count)
		len = count;

	if (len < 0)
		len = 0;

	return len;

}
#endif
					
int dect_drv_read_version_proc(char *buf)
{
   int len=0,len1=0,len2=0;
   char buf1[20],buf2[20];

	strcpy(version.ucDrvVersion,DECT_VERSION);
   len1=sprintf(buf1,"%x.%x.%x",(version.ucCosicSwVersion[0] >> 4),\
                (version.ucCosicSwVersion[0] & 0x0f),version.ucCosicSwVersion[1]);
   len2=sprintf(buf2,"%x.%x.%x",(version.ucBmcFwVersion[0] >> 4),\
                (version.ucBmcFwVersion[0] & 0x0f),version.ucBmcFwVersion[1]);
	len = sprintf(buf, "\nModules          Version \
                       \nCOSIC s/w         %s \
                       \nBMC f/w           %s \
                       \nGW COSIC driver   %s \n", \
                       buf1,buf2,version.ucDrvVersion);
   gw_stats.uiLastOprn = DBG_READ_GW_VERSION;
   gw_stats.uiLastOprnStatus = DBG_SUCCESS;
   return len;
}

int dect_drv_read_gw_stats_proc(char *buf)
{
   int len=0,len1=0,len2=0,i=0;
   #ifdef LINUX
   int iNumCalls=0;
   #endif
   char oprn[20],mode[15],status[10],buf1[200],buf2[200],gw_dbg_status[10];
   char *b1=buf1,*b2=buf2;

   #ifdef LINUX
   if(atomic_read(&vuiGwDbgFlag)==1)
   #endif
   #ifdef SUPERTASK
   if(vuiGwDbgFlag==1)
   #endif
   {
      strcpy(gw_dbg_status,"Enabled");
   }
   else
   {
      strcpy(gw_dbg_status,"Disabled");
   }

   switch(gw_stats.uiLastOprn)
   {
      case DBG_READ_GW_STATS :
         strcpy(oprn,"READ gw-stats");
         break;
      case DBG_READ_MODEM_STATS :
         strcpy(oprn,"READ modem-stats");
         break;
      case DBG_READ_GW_VERSION :
         strcpy(oprn,"READ version");
         break;
      case DBG_RESET_GW_STATS :
         strcpy(oprn,"RESET gw-stats");
         break;
      case DBG_RESET_MODEM_STATS :
         strcpy(oprn,"RESET modem-stats");
         break;
      case DBG_REQ_MODEM_STATS:
         strcpy(oprn,"GET modem-stats");
         break;
      case DBG_GW_STATS_EN:
         strcpy(oprn,"ENABLE gw-stats");
         break;
      case DBG_GW_STATS_DIS:
         strcpy(oprn,"DISABLE gw-stats");
         break;
      default:
         strcpy(oprn,"NONE");
         break;
   }

   switch(gw_stats.uiLastOprnStatus)
   {
      case DBG_SUCCESS :
         strcpy(status,"SUCCESS");
         break;
      case DBG_FAIL :
         strcpy(status,"FAIL");
         break;
      case DBG_PENDING :
         strcpy(status,"PENDING");
         break;
   }

   switch(vucDriverMode)
   {
      case DECT_DRV_SET_APP_MODE :
         strcpy(mode,"App");
         break;
      case DECT_DRV_SET_LOADER_MODE :
         strcpy(mode,"Boot");
         break;
      case DECT_DRV_SET_APP_MODE_CoC_RQ :
         strcpy(mode,"App-CoC-RQ");
         break;
      case DECT_DRV_SET_APP_MODE_CoC_CNF :
         strcpy(mode,"App-CoC");
         break;
   }

   for(i=0;i<10;i++)
   {
      b1+=len1;
      if(i == 9)
         len1=sprintf(b1,"\t%d+",i+1);
      else
         len1=sprintf(b1,"\t%d",i+1);
   }
   b1[len1]='\0';

   for(i=0;i<10;i++)
   {
      b2+=len2;
      len2=sprintf(b2,"\t%d",gw_stats.auiIntLossSeq[i]);
   }
   b2[len2]='\0';

   #ifdef LINUX
   for(i=0;i<MAX_MCEI;i++)
   {
      if(xMceiBuffer[i].iKpiChan != 0xFF)
      {
         iNumCalls++;
      }
   }
   #endif

   #ifdef LINUX
   len = sprintf(buf, "\nGW debug : %s \
                       \nLast Debug operation : %s status : %s \
                       \nTime stamp of this stats : %lu \
                       \nTotal interrupts received by gw : %u \
                       \nRising Interrupts count before RxCB : %u \
                       \nRising Interrupts count before TxCB : %u \
                       \nUnlock at falling edge count : %u \
                       \nKPI write fail count : %u \
                       \nCorrupted SPI packet receive count : %u \
                       \nGW COSIC Driver Mode : %s \
                        \nGW CoC Req Count from Modem : %u \ 
                       \nNum Active Calls : %u  \
                       \nInterrupt loss sequence stats: \
                       \n%s\n%s\n", \
                       gw_dbg_status,oprn,status,jiffies,gw_stats.uiInt,gw_stats.uiLossRx, \
                       gw_stats.uiLossTx,gw_stats.uiUnLockFallEdge, \
                       gw_stats.uiKpi,gw_stats.uiInvSpi,mode,gw_stats.uiCoCReqFromModem,iNumCalls,buf1,buf2);
   #endif
   #ifdef SUPERTASK
   len = sprintf(buf, "\nGW debug : %s \
                       \nTime stamp of GW Stats : %lu \
                       \nLast Debug operation : %s status : %s \
                       \nTotal interrupts received by gw : %u \
                       \nRising Interrupts count before RxCB : %u \
                       \nRising Interrupts count before TxCB : %u \
                       \nUnlock at falling edge count : %u \
                       \nKPI write fail count : %u \
                       \nCorrupted SPI packet receive count : %u \
                       \nGW COSIC Driver Mode : %s \
                       \nInterrupt loss sequence stats: \
                       \n%s\n%s\n", \
                       gw_dbg_status,get_sys_time(),oprn,status,gw_stats.uiInt,gw_stats.uiLossRx, \
                       gw_stats.uiLossTx,gw_stats.uiUnLockFallEdge, \
                       gw_stats.uiKpi,gw_stats.uiInvSpi,mode,buf1,buf2);
   #endif
	gw_stats.uiLastOprn = DBG_READ_GW_STATS;
	gw_stats.uiLastOprnStatus = DBG_SUCCESS;
	return len;
}

#ifdef LINUX
int dect_drv_read_channel_stats_proc(char *buf)
{
   int len =0;

   IFX_TAPI_KIO_HANDLE kHandle1, kHandle2, kHandle3, kHandle4, kHandle5, kHandle6;
   IFX_TAPI_DECT_STATISTICS_t xStat1, xStat2, xStat3, xStat4, xStat5, xStat6;
   kHandle1 = ifx_tapi_kopen("/dev/vmmc11");
   kHandle2 = ifx_tapi_kopen("/dev/vmmc12");
   kHandle3 = ifx_tapi_kopen("/dev/vmmc13");
   kHandle4 = ifx_tapi_kopen("/dev/vmmc14");
   kHandle5 = ifx_tapi_kopen("/dev/vmmc15");
   kHandle6 = ifx_tapi_kopen("/dev/vmmc16");
   memset(&xStat1, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
   memset(&xStat2, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
   memset(&xStat3, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
   memset(&xStat4, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
   memset(&xStat5, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
   memset(&xStat6, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
   ifx_tapi_kioctl(kHandle1, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat1);
   ifx_tapi_kclose(kHandle1);
   ifx_tapi_kioctl(kHandle2, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat2);
   ifx_tapi_kclose(kHandle2);
   ifx_tapi_kioctl(kHandle3, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat3);
   ifx_tapi_kclose(kHandle3);
   ifx_tapi_kioctl(kHandle4, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat4);
   ifx_tapi_kclose(kHandle4);
   ifx_tapi_kioctl(kHandle5, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat5);
   ifx_tapi_kclose(kHandle5);
   ifx_tapi_kioctl(kHandle6, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat6);
   ifx_tapi_kclose(kHandle6);
   len = sprintf(buf, "\nChannel               : \t1\t2\t3\t4\t5\t6 \
                       \nNumber Of Upstream Packet   : \t%d\t%d\t%d\t%d\t%d\t%d  \
                       \nNumber Of Downstream Packet : \t%d\t%d\t%d\t%d\t%d\t%d  \
                       \nNumber Of SID packets : \t%d\t%d\t%d\t%d\t%d\t%d  \
                       \nNumber Of PLC packets : \t%d\t%d\t%d\t%d\t%d\t%d  \
                       \nOverRun               : \t%d\t%d\t%d\t%d\t%d\t%d  \
                       \nUnderRun              : \t%d\t%d\t%d\t%d\t%d\t%d  \
                       \nNumber Of Invalid packets : \t%d\t%d\t%d\t%d\t%d\t%d  \
                       \n", \
                       xStat1.nPktUp,xStat2.nPktUp,xStat3.nPktUp,xStat4.nPktUp,xStat5.nPktUp,xStat6.nPktUp, \
                       xStat1.nPktDown,xStat2.nPktDown,xStat3.nPktDown,xStat4.nPktDown,xStat5.nPktDown,xStat6.nPktDown, \
                       xStat1.nSid,xStat2.nSid,xStat3.nSid,xStat4.nSid,xStat5.nSid,xStat6.nSid, \
                       xStat1.nPlc,xStat2.nPlc,xStat3.nPlc,xStat4.nPlc,xStat5.nPlc,xStat6.nPlc, \
                       xStat1.nOverflows,xStat2.nOverflows,xStat3.nOverflows,xStat4.nOverflows,xStat5.nOverflows,xStat6.nOverflows, \
                       xStat1.nUnderflows, xStat2.nUnderflows, xStat3.nUnderflows,xStat4.nUnderflows,xStat5.nUnderflows,xStat6.nUnderflows, \
                       xStat1.nInvalid, xStat2.nInvalid, xStat3.nInvalid,xStat4.nInvalid,xStat5.nInvalid,xStat6.nInvalid);
	return len;
}
#endif /* LINUX */

int dect_drv_read_modem_stats_proc(char *buf)
{
   int len=0,len1=0,len2=0,len3=0,len4=0,len5=0,/*len6=0,*/len7=0,i=0,tmp[MAX_MCEI]={0};
   char buf1[200],status[20],BadAX[100],Q1Q2BadA[100],BadZ[100],FHO[100],SHO[100],/*RSSI[100],*/SyncErr[100];
   char *b1=buf1,*b2=status,*b3=BadAX,*b4=Q1Q2BadA,*b5=BadZ,*b7=SHO,*b6=FHO,/**b8=RSSI,*/*b9=SyncErr;

   #if 0
   for(i=0;i<MAX_MCEI;i++)
   {
      printk("\nLBN%d = %d   %d\n",i,Mcei_Table[i].lbn_1,Mcei_Table[i].lbn_2);
   }
   #endif

   for(i=0;i<MAX_MCEI;i++)
   {
      b1+=len1;
      len1=sprintf(b1,"\t%d",i);
   }
   b1[len1]='\0';

	len1=0;
   /*Check for MCEI active or not & store the status in tmp */
   for(i=0;i<MAX_MCEI;i++)
   {
      if (Mcei_Table[i].lbn_1 != NO_LBN)
      {
         tmp[Mcei_Table[i].lbn_1]=1;
      }	
      if (Mcei_Table[i].lbn_2 != NO_LBN)
      {
         tmp[Mcei_Table[i].lbn_2]=1;
      }	
   }

	for(i=0;i<MAX_MCEI;i++)
	{
		b2+=len1;
		/*Check for MCEI active or not*/
		if(tmp[i])
		{
			len1=sprintf(b2,"\t%s","A");
		}
		else
		{	
			len1=sprintf(b2,"\t%s","NA");
		}
	}
   b2[len1]='\0';

   len1=0;
   for(i=0;i<6;i++)
   {
      b3+=len1;
      len1=sprintf(b3,"\t%d",lbn_stats[i].uiBadAXCRC);
      b4+=len2;
      len2=sprintf(b4,"\t%d",lbn_stats[i].uiQ1Q2BadACRC);
      b5+=len3;
      len3=sprintf(b5,"\t%d",lbn_stats[i].uiBadZCRC);
      b6+=len4;
      len4=sprintf(b6,"\t%d",lbn_stats[i].uiFailedHO);
      b7+=len5;
      len5=sprintf(b7,"\t%d",lbn_stats[i].uiSuccessHO);
      /*
      b8+=len6;
      len6=sprintf(b8,"\t%d",lbn_stats[i].uiRSSI);
      */
      b9+=len7;
      len7=sprintf(b9,"\t%d",lbn_stats[i].uiSyncErr);
   }
   b3[len1]='\0';
   b4[len2]='\0';
   b5[len3]='\0';
   b6[len4]='\0';
   b7[len5]='\0';
   //b8[len6]='\0';
   b9[len7]='\0';

   #ifdef LINUX
   len = sprintf(buf, "\nSPI Timeout Counter for Tx                        : %u/%u  \
                       \nSPI Timeout Counter for Rx                        : %u/%u  \
                       \nStack Queue Overflow Counter                      : %u/%u  \
                       \nNot Serviced SPI Interrupt Counter                : %u/%u  \
                       \nDummy Bearer Change Counter                       : %u/%u	 \
                       \n\nLBN stats   :        \
                       \n\n\t\t\t%s \
                       \n status                       %s \
                       \n Bad A field CRC counter      %s \
                       \n Q2=0 counter                 %s \
                       \n Bad Z field CRC counter      %s \
                       \n Failed Handovers             %s \
                       \n Successful handovers         %s \
                       \n Number of sync errors        %s \n ",    																						 \
                       modem_stats.uiSpiTimeOutTxCC,modem_stats.uiSpiTimeOutTxTC,   \
                       modem_stats.uiSpiTimeOutRxCC,modem_stats.uiSpiTimeOutRxTC,   \
                       modem_stats.uiStackOverFlowCC,modem_stats.uiStackOverFlowTC, \
                       modem_stats.uiNonSrvcSpiIntCC,modem_stats.uiNonSrvcSpiIntTC, \
                       modem_stats.uiDummyBearerChangeCC,modem_stats.uiDummyBearerChangeTC, \
                       buf1,status,BadAX,Q1Q2BadA,BadZ,FHO,SHO,/*RSSI,*/SyncErr);
   #endif
   #ifdef SUPERTASK
   len = sprintf(buf, "\nTime Stamp of Modem Stats  : %lu   \
                       \nSPI Timeout Counter for Tx                        : %u/%u  \
                       \nSPI Timeout Counter for Rx                        : %u/%u  \
                       \nStack Queue Overflow Counter                      : %u/%u  \
                       \nNot Serviced SPI Interrupt Counter                : %u/%u  \
                       \nDummy Bearer Change Counter                       : %u/%u	 \
                       \n\nLBN stats   :        \
                       \n\n\t\t\t%s \
                       \n status                       %s \
                       \n Bad A field CRC counter      %s \
                       \n Q2=0 counter                 %s \
                       \n Bad Z field CRC counter      %s \
                       \n Failed Handovers             %s \
                       \n Successful handovers         %s \
                       \n Number of sync errors        %s \n ",    																						 \
                       modem_stats.TimeStamp,modem_stats.uiSpiTimeOutTxCC,modem_stats.uiSpiTimeOutTxTC,   \
                       modem_stats.uiSpiTimeOutRxCC,modem_stats.uiSpiTimeOutRxTC,   \
                       modem_stats.uiStackOverFlowCC,modem_stats.uiStackOverFlowTC, \
                       modem_stats.uiNonSrvcSpiIntCC,modem_stats.uiNonSrvcSpiIntTC, \
                       modem_stats.uiDummyBearerChangeCC,modem_stats.uiDummyBearerChangeTC, \
                       buf1,status,BadAX,Q1Q2BadA,BadZ,FHO,SHO,/*RSSI,*/SyncErr);
   #endif
   gw_stats.uiLastOprn = DBG_READ_MODEM_STATS;
   gw_stats.uiLastOprnStatus = DBG_SUCCESS;
   return len;
}

#ifdef LINUX
int dect_drv_write_proc(struct file *file,const char *buffer,unsigned long count,void *data)
{
   #ifdef ENHANCED_DELAY
   int len=count;
   #else
   int len=1;
   #endif
   char kdata[10]= {0};

   if(copy_from_user(&kdata, buffer, len)) 
   {
      printk("\ncopy from user failed in proc system\n");
      return -EFAULT;
   }

	switch(kdata[0] - '0')
   {
      case 0:
      {
         if(data == dect_drv_read_gw_stats_proc)
         {
            DisableGwDebugStats();
         }
         break;
      }
      case 1:
      {
         if(data == dect_drv_read_gw_stats_proc)
         {
            EnableGwDebugStats();
         }
         else if(data == dect_drv_read_modem_stats_proc)
         {
            GetModemDebugStats();
            /*Since info id 6,7,8 debug pkts are sent by above fn*/
            vuiDbgSendFlags |= PROC_MODEM_DBG6_SEND;
            vuiDbgSendFlags |= PROC_MODEM_DBG7_SEND;
            vuiDbgSendFlags |= PROC_MODEM_DBG8_SEND;
         }
         break;
      }
      case 2:
      {
         if(data == dect_drv_read_gw_stats_proc)
         {
            ResetGwDebugStats();
         }
         else if(data == dect_drv_read_modem_stats_proc)
         {
            ResetModemDebugStats();
            /*Since info id 6debug pkt is sent by above fn*/
            vuiDbgSendFlags |= PROC_MODEM_DBG6_SEND;
         }
         break;
      }
      default:
      {
         #ifdef ENHANCED_DELAY
         if(len < 4)
         {
            printk("\nWRONG input from proc file system = %d\n",((int)kdata));
         }
         else
         {
            vuiDealy = (kdata[1]-'0')*100+(kdata[2]-'0')*10+(kdata[3]-'0');
            printk("Dealy is %d\n", vuiDealy);
         }
         #else
         printk("\nWRONG input from proc file system = %d\n",kdata);
         #endif
      }
   }
   return count;
}
#endif /* LINUX */
#endif /* (CONFIG_PROC_FS && defined(LINUX)) || defined(SUPERTASK) */
#if ((LINUX_VERSION_CODE >= KERNEL_VERSION(3,10,0)) && CONFIG_PROC_FS && defined(LINUX)  )
static void dect_drv_read_version_proc(struct seq_file *s)
{
	int len1=0,len2=0;
	char buf1[20],buf2[20];
	strcpy(version.ucDrvVersion,DECT_VERSION);
	len1=sprintf(buf1,"%x.%x.%x",(version.ucCosicSwVersion[0] >> 4),\
							(version.ucCosicSwVersion[0] & 0x0f),version.ucCosicSwVersion[1]);
	len2=sprintf(buf2,"%x.%x.%x",(version.ucBmcFwVersion[0] >> 4),\
							(version.ucBmcFwVersion[0] & 0x0f),version.ucBmcFwVersion[1]);
	seq_printf(s, "\nModules          Version \
											\nCOSIC s/w         %s \
											\nBMC f/w           %s \
											\nGW COSIC driver   %s \n", \
											buf1,buf2,version.ucDrvVersion);
	gw_stats.uiLastOprn = DBG_READ_GW_VERSION;
	gw_stats.uiLastOprnStatus = DBG_SUCCESS;
}

static void dect_drv_read_gw_stats_proc(struct seq_file *s)
{
	int len1=0,len2=0,i=0,iNumCalls=0;
	char oprn[20],mode[15],status[10],buf1[200],buf2[200],gw_dbg_status[10];
	char *b1=buf1,*b2=buf2;
	if(atomic_read(&vuiGwDbgFlag)==1)
	{
		strcpy(gw_dbg_status,"Enabled");
	}
	else
	{
		strcpy(gw_dbg_status,"Disabled");
	}
  switch(gw_stats.uiLastOprn)
	{
		case DBG_READ_GW_STATS :
			strcpy(oprn,"READ gw-stats");
    break;
  	case DBG_READ_MODEM_STATS :
			strcpy(oprn,"READ modem-stats");
    break;
  	case DBG_READ_GW_VERSION :
			strcpy(oprn,"READ version");
    break;
  	case DBG_RESET_GW_STATS :
			strcpy(oprn,"RESET gw-stats");
    break;
  	case DBG_RESET_MODEM_STATS :
			strcpy(oprn,"RESET modem-stats");
    break;
  	case DBG_REQ_MODEM_STATS:
			strcpy(oprn,"GET modem-stats");
    break;
  	case DBG_GW_STATS_EN:
			strcpy(oprn,"ENABLE gw-stats");
    break;
  	case DBG_GW_STATS_DIS:
			strcpy(oprn,"DISABLE gw-stats");
    break;
  	default:
			strcpy(oprn,"NONE");
	}
  switch(gw_stats.uiLastOprnStatus)
	{
		case DBG_SUCCESS :
			strcpy(status,"SUCCESS");
    break;
		case DBG_FAIL :
			strcpy(status,"FAIL");
    break;
		case DBG_PENDING :
			strcpy(status,"PENDING");
    break;
	}
	switch(vucDriverMode)
	{
		case DECT_DRV_SET_APP_MODE :
			strcpy(mode,"App");
    break;
		case DECT_DRV_SET_LOADER_MODE :
			strcpy(mode,"Boot");
    break;
		case DECT_DRV_SET_APP_MODE_CoC_RQ :
			strcpy(mode,"App-CoC-RQ");
    break;
		case DECT_DRV_SET_APP_MODE_CoC_CNF :
			strcpy(mode,"App-CoC");
    break;
	}
	for(i=0;i<10;i++)
	{
		b1+=len1;
		if(i == 9)
			len1=sprintf(b1,"\t%d+",i+1);
		else
			len1=sprintf(b1,"\t%d",i+1);
	}
  b1[len1]='\0';
	for(i=0;i<10;i++)
	{
		b2+=len2;
		len2=sprintf(b2,"\t%d",gw_stats.auiIntLossSeq[i]);
	}
  b2[len2]='\0';
  for(i=0;i<MAX_MCEI;i++)
  {
    if(xMceiBuffer[i].iKpiChan != 0xFF){
      iNumCalls++;
    }
  }

 seq_printf(s, "\nGW debug : %s \
								\nLast Debug operation : %s status : %s \
								\nTime stamp of this stats : %lu \
								\nTotal interrupts received by gw : %u \
								\nRising Interrupts count before RxCB : %u \
								\nRising Interrupts count before TxCB : %u \
								\nUnlock at falling edge count : %u \
								\nKPI write fail count : %u \
								\nCorrupted SPI packet receive count : %u \
								\nGW COSIC Driver Mode : %s \
								\nGW CoC Req Count from Modem : %u \ 
								\nNum Active Calls : %u  \
								\nInterrupt loss sequence stats: \
								\n%s\n%s\n", \
								gw_dbg_status,oprn,status,jiffies,gw_stats.uiInt,gw_stats.uiLossRx, \
								gw_stats.uiLossTx,gw_stats.uiUnLockFallEdge, \
							  gw_stats.uiKpi,gw_stats.uiInvSpi,mode,gw_stats.uiCoCReqFromModem,iNumCalls,buf1,buf2);
	gw_stats.uiLastOprn = DBG_READ_GW_STATS;
	gw_stats.uiLastOprnStatus = DBG_SUCCESS;
}

static void dect_drv_read_channel_stats_proc(struct seq_file *s)
{
  IFX_TAPI_KIO_HANDLE kHandle1, kHandle2, kHandle3, kHandle4, kHandle5, kHandle6;
  IFX_TAPI_DECT_STATISTICS_t xStat1, xStat2, xStat3, xStat4, xStat5, xStat6;
	kHandle1 = ifx_tapi_kopen("/dev/vmmc11");
	kHandle2 = ifx_tapi_kopen("/dev/vmmc12");
	kHandle3 = ifx_tapi_kopen("/dev/vmmc13");
	kHandle4 = ifx_tapi_kopen("/dev/vmmc14");
	kHandle5 = ifx_tapi_kopen("/dev/vmmc15");
	kHandle6 = ifx_tapi_kopen("/dev/vmmc16");
  memset(&xStat1, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
  memset(&xStat2, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
  memset(&xStat3, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
  memset(&xStat4, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
  memset(&xStat5, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
  memset(&xStat6, 0, sizeof(IFX_TAPI_DECT_STATISTICS_t));
  ifx_tapi_kioctl(kHandle1, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat1);
  ifx_tapi_kclose(kHandle1);
  ifx_tapi_kioctl(kHandle2, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat2);
  ifx_tapi_kclose(kHandle2);
  ifx_tapi_kioctl(kHandle3, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat3);
  ifx_tapi_kclose(kHandle3);
  ifx_tapi_kioctl(kHandle4, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat4);
  ifx_tapi_kclose(kHandle4);
  ifx_tapi_kioctl(kHandle5, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat5);
  ifx_tapi_kclose(kHandle5);
  ifx_tapi_kioctl(kHandle6, IFX_TAPI_DECT_STATISTICS_GET, (void*)&xStat6);
  ifx_tapi_kclose(kHandle6);
	seq_printf(s, "\nChannel               : \t1\t2\t3\t4\t5\t6 \
								\nNumber Of Upstream Packet   : \t%u\t%u\t%u\t%u\t%u\t%u  \
								\nNumber Of Downstream Packet : \t%u\t%u\t%u\t%u\t%u\t%u  \
								\nNumber Of SID packets : \t%u\t%u\t%u\t%u\t%u\t%u  \
								\nNumber Of PLC packets : \t%u\t%u\t%u\t%u\t%u\t%u  \
								\nOverRun               : \t%u\t%u\t%u\t%u\t%u\t%u  \
								\nUnderRun              : \t%u\t%u\t%u\t%u\t%u\t%u  \
								\nNumber Of Invalid packets : \t%u\t%u\t%u\t%u\t%u\t%u  \
								\n", \
							  xStat1.nPktUp,xStat2.nPktUp,xStat3.nPktUp,xStat4.nPktUp,xStat5.nPktUp,xStat6.nPktUp, \
							  xStat1.nPktDown,xStat2.nPktDown,xStat3.nPktDown,xStat4.nPktDown,xStat5.nPktDown,xStat6.nPktDown, \
							  xStat1.nSid,xStat2.nSid,xStat3.nSid,xStat4.nSid,xStat5.nSid,xStat6.nSid, \
							  xStat1.nPlc,xStat2.nPlc,xStat3.nPlc,xStat4.nPlc,xStat5.nPlc,xStat6.nPlc, \
							  xStat1.nOverflows,xStat2.nOverflows,xStat3.nOverflows,xStat4.nOverflows,xStat5.nOverflows,xStat6.nOverflows, \
                xStat1.nUnderflows, xStat2.nUnderflows, xStat3.nUnderflows,xStat4.nUnderflows,xStat5.nUnderflows,xStat6.nUnderflows, \
                xStat1.nInvalid, xStat2.nInvalid, xStat3.nInvalid,xStat4.nInvalid,xStat5.nInvalid,xStat6.nInvalid);
}


static void dect_drv_read_modem_stats_proc(struct seq_file *s)
{
	int len1=0,len2=0,len3=0,len4=0,len5=0,/*len6=0,*/len7=0,i=0,tmp[MAX_MCEI]={0};
	char buf1[200],status[20],BadAX[100],Q1Q2BadA[100],BadZ[100],FHO[100],SHO[100],/*RSSI[100],*/SyncErr[100];
	char *b1=buf1,*b2=status,*b3=BadAX,*b4=Q1Q2BadA,*b5=BadZ,*b7=SHO,*b6=FHO,/**b8=RSSI,*/*b9=SyncErr;
#if 0
	for(i=0;i<MAX_MCEI;i++)
	{
		printk("\nLBN%d = %d   %d\n",i,Mcei_Table[i].lbn_1,Mcei_Table[i].lbn_2);
	}
#endif
	for(i=0;i<MAX_MCEI;i++)
	{
		b1+=len1;
		len1=sprintf(b1,"\t%d",i);
	}
  b1[len1]='\0';
	len1=0;
	/*Check for MCEI active or not & store the status in tmp */
	for(i=0;i<MAX_MCEI;i++)
	{
		if (Mcei_Table[i].lbn_1 != NO_LBN)
		{
			tmp[Mcei_Table[i].lbn_1]=1;
		}	
		if (Mcei_Table[i].lbn_2 != NO_LBN)
		{
			tmp[Mcei_Table[i].lbn_2]=1;
		}	
	}
	for(i=0;i<MAX_MCEI;i++)
	{
		b2+=len1;
		/*Check for MCEI active or not*/
		if(tmp[i])
		{
			len1=sprintf(b2,"\t%s","A");
		}
		else
		{	
			len1=sprintf(b2,"\t%s","NA");
		}
	}
  b2[len1]='\0';
	len1=0;
	for(i=0;i<6;i++)
	{
		b3+=len1;
		len1=sprintf(b3,"\t%d",lbn_stats[i].uiBadAXCRC);
		b4+=len2;
		len2=sprintf(b4,"\t%d",lbn_stats[i].uiQ1Q2BadACRC);
		b5+=len3;
		len3=sprintf(b5,"\t%d",lbn_stats[i].uiBadZCRC);
		b6+=len4;
		len4=sprintf(b6,"\t%d",lbn_stats[i].uiFailedHO);
		b7+=len5;
		len5=sprintf(b7,"\t%d",lbn_stats[i].uiSuccessHO);
		/*
		b8+=len6;
		len6=sprintf(b8,"\t%d",lbn_stats[i].uiRSSI);
		*/
		b9+=len7;
		len7=sprintf(b9,"\t%d",lbn_stats[i].uiSyncErr);
	}
  b3[len1]='\0';
  b4[len2]='\0';
  b5[len3]='\0';
  b6[len4]='\0';
  b7[len5]='\0';
  //b8[len6]='\0';
  b9[len7]='\0';
	seq_printf(s, "\nSPI Timeout Counter for Tx                        : %u/%u  \
											\nSPI Timeout Counter for Rx                        : %u/%u  \
											\nStack Queue Overflow Counter                      : %u/%u  \
											\nNot Serviced SPI Interrupt Counter                : %u/%u  \
											\nDummy Bearer Change Counter                       : %u/%u	 \
											\n\nLBN stats   :        \
											\n\n\t\t\t%s \
											\n status                       %s \
											\n Bad A field CRC counter      %s \
											\n Q2=0 counter                 %s \
											\n Bad Z field CRC counter      %s \
											\n Failed Handovers             %s \
											\n Successful handovers         %s \
											\n Number of sync errors        %s \n ",    																						 \
											modem_stats.uiSpiTimeOutTxCC,modem_stats.uiSpiTimeOutTxTC,   \
											modem_stats.uiSpiTimeOutRxCC,modem_stats.uiSpiTimeOutRxTC,   \
											modem_stats.uiStackOverFlowCC,modem_stats.uiStackOverFlowTC, \
											modem_stats.uiNonSrvcSpiIntCC,modem_stats.uiNonSrvcSpiIntTC, \
											modem_stats.uiDummyBearerChangeCC,modem_stats.uiDummyBearerChangeTC, \
											buf1,status,BadAX,Q1Q2BadA,BadZ,FHO,SHO,/*RSSI,*/SyncErr);
	gw_stats.uiLastOprn = DBG_READ_MODEM_STATS;
	gw_stats.uiLastOprnStatus = DBG_SUCCESS;
}

static ssize_t dect_drv_modem_write_proc(struct file *file, const char __user *buffer,size_t count, loff_t *data)
{
#ifdef ENHANCED_DELAY
  int len=count;
#else
  int len=1;
#endif
  char kdata[10]= {0};
  if(copy_from_user(&kdata, buffer, len)) 
  {
    printk("\ncopy from user failed in proc system\n");
    return -EFAULT;
  }

  printk("\n dect_drv_modem_write_proc: digit=%d \n",kdata[0] - '0');

	switch(kdata[0] - '0')
  {
    case 1:
    {
				GetModemDebugStats();
				/*Since info id 6,7,8 debug pkts are sent by above fn*/
				vuiDbgSendFlags |= PROC_MODEM_DBG6_SEND;
				vuiDbgSendFlags |= PROC_MODEM_DBG7_SEND;
				vuiDbgSendFlags |= PROC_MODEM_DBG8_SEND;
      break;
    }
    case 2:
    {
				ResetModemDebugStats();
				/*Since info id 6debug pkt is sent by above fn*/
				vuiDbgSendFlags |= PROC_MODEM_DBG6_SEND;
      break;
    }
    default:
    {
#ifdef ENHANCED_DELAY
       if(len < 4){
         printk("\nWRONG input from proc file system = %d\n",((int)kdata));
       }
       else{
         vuiDealy = (kdata[1]-'0')*100+(kdata[2]-'0')*10+(kdata[3]-'0');
         printk("Dealy is %d\n", vuiDealy);
       }
#else
       printk("\nWRONG input from proc file system = %d\n",kdata);
#endif
    }
  }
  return count;
}


static ssize_t dect_drv_gw_write_proc(struct file *file, const char __user *buffer,size_t count, loff_t *data)
{
#ifdef ENHANCED_DELAY
  int len=count;
#else
  int len=1;
#endif
  char kdata[10]= {0};
  if(copy_from_user(&kdata, buffer, len)) 
  {
    printk("\ncopy from user failed in proc system\n");
    return -EFAULT;
  }

  printk("\n dect_drv_gw_write_proc: digit=%d \n",kdata[0] - '0');

	switch(kdata[0] - '0')
  {
    case 0:
    {
				DisableGwDebugStats();
      break;
    }
    case 1:
    {
				EnableGwDebugStats();
      
      break;
    }
    case 2:
    {
				ResetGwDebugStats();
      break;
    }
    default:
    {
#ifdef ENHANCED_DELAY
       if(len < 4){
         printk("\nWRONG input from proc file system = %d\n",((int)kdata));
       }
       else{
         vuiDealy = (kdata[1]-'0')*100+(kdata[2]-'0')*10+(kdata[3]-'0');
         printk("Dealy is %d\n", vuiDealy);
       }
#else
       printk("\nWRONG input from proc file system = %d\n",kdata);
#endif
    }
  }
  return count;
}





#endif

#endif /* DRV_DECT_C */

