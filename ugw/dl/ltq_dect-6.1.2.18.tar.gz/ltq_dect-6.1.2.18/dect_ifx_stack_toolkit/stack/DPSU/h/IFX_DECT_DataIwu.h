/*
 * =====================================================================================
 *
 *       Filename:  IFX_DECT_DataIwu.h
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  Tuesday 18 November 2008 10:35:53  IST
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  
 *        Company:  IFIN
 *
 * =====================================================================================
 */

/*! \file IFX_DECT_DataIwu.h
    \brief This file stores structures,macros,enumerations and API prototypes 
	       useful for Data Packet Service Unit(DPSU).
*/

#ifndef __IFX_DECT_DATA_IWU_H__
#define __IFX_DECT_DATA_IWU_H__

/** \ingroup DECT_SS_1_1
    \defgroup Data Packet Service Unit is used for data call between FT and PT.
    \brief This file contains structures for storing session/connection information,
           enums for the states of handset and DPRS events and macros.
*/
/*@{*/

/*! \brief IFX_DECT_MAX_DATACON Maximum Connections Permitted per Session. */
#define IFX_DECT_MAX_DATACON 6
#ifndef LTQ_RAW_DPSU
/*! \brief IFX_DECT_MAX_SUOTACON Maximum SUOTA Connections Permitted. */
#ifdef ULE_SUPPORT
#define IFX_DECT_MAX_SUOTACON 255
#else
#define IFX_DECT_MAX_SUOTACON 6
#endif
#endif
/*! \brief IFX_DECT_MAX_DATASESS Maximum number of sessions per Data Application. */
#define IFX_DECT_MAX_DATASESS 1

/*! \brief IFX_DECT_DPSU_MAX_BUFFERSIZE Maximum Size of each Data Buffer received 
     from FT Application/sent to PT. */
#ifdef LTQ_RAW_DPSU
#define IFX_DECT_DPSU_MAX_BUFFERSIZE 513
#else
#define IFX_DECT_DPSU_MAX_BUFFERSIZE 513
//#define IFX_DECT_DPSU_MAX_BUFFERSIZE 124
//#define IFX_DECT_DPSU_MAX_BUFFERSIZE 1488
#endif

/*! \brief IFX_DECT_DPSU_MAX_WINDOWSIZE Maximum size of the window to be exchanged in http 
 */
#ifdef LTQ_RAW_DPSU
#define IFX_DECT_DPSU_MAX_WINDOWSIZE 2048
#else
#define IFX_DECT_DPSU_MAX_WINDOWSIZE 12000
#endif
#ifndef LTQ_RAW_DPSU
/*! \brief IFX_DECT_DPSU_MAX_REQ_BUFF_SIZE Maximum size of the window to be exchanged in http 
*/
#define IFX_DECT_DPSU_MAX_REQ_BUFF_SIZE 512

/*! \brief IFX_DECT_DPSU_IS_SEQ_OCTET sequence octet is present or not 
 */
#define IFX_DECT_DPSU_IS_SEQ_OCTET  (1 << 7)

/*! \brief IFX_DECT_DPSU_DGMEP_MORE_BIT next octet follows 
 */
#define IFX_DECT_DPSU_DGMEP_MORE_BIT  (1 << 7)

/*! \brief IFX_DECT_DPSU_MAX_APPLN applications are supported 
 */
#define IFX_DECT_DPSU_MAX_APPLN  6

/*! \brief IFX_DECT_DPSU_MAX_DATA_PER_PKT in URL Indication Msg 
 */
#define IFX_DECT_DPSU_MAX_DATA_PER_PKT  56
/*! \brief IFX_DECT_DPSU_VALIDATE_GMCI applications are supported 
 */
#define IFX_DECT_DPSU_VALIDATE_GMCI  0x7F
#endif
/*! \brief Mapping between Handset and Instance Number. */
extern char8 acHandsetMap[IFX_DECT_MAX_DATACON];


/*! \brief Call Type. */
#define IFX_DECT_DPSU_DATA_CALL                            0x01

/*! \brief Codec Used.Narrowband/Wideband. */
#define IFX_DECT_DPSU_NARROWBAND_CALL                      0x00


/*! \brief CODING STANDARD.Parameter in IWU Attributes Information Element. */
#define IFX_DECT_DPSU_PROFILE_DEFINED_CODING               0x01

/*! \brief Profile,Parameter in IWU Attributes Information Element.*/
#define IFX_DECT_DPSU_DPRS                                 0x00

/*! \brief PROFILE SUBTYPEi,Parameter in IWU Attributes Information Element. */
#define IFX_DECT_DPSU_DGMEP_PROFILE_SUBTYPE                0x08

/*! \brief An octet.*/
#define IFX_DECT_OCTET                                     0x08

/*! \brief To post Enable Data message to DECT Stack. */
#define IFX_DECT_DPSU_ENABLE                               0x0F

#ifndef LTQ_RAW_DPSU
/*! \def IFX_DECT_DPSU_LINK_PRESENT
    \brief Macro that specifies whether a link already exists i.e. there is
           an ongoing call.
*/
#define IFX_DECT_DPSU_LINK_PRESENT 1

/*! \def IFX_DECT_DPSU_NO_LINK_PRESENT
 *     \brief Macro that specifies that a link does not exist.
 *     */
#define IFX_DECT_DPSU_NO_LINK_PRESENT 0

#endif
/*! \enum e_IFX_DECT_DPSU_States
   \brief An enumeration defining different DPSU states for a connection.
*/

typedef enum{
  IFX_DECT_DPSU_IDLE,       /*!< DPSU capable of receiving incoming requests.*/
  IFX_DECT_DPSU_PENDING,    /*!< DPSU waiting due to pending request/setup arrived from PT.*/
  IFX_DECT_DPSU_CONNECTED,  /*!< DPSU received a flow-in message from Stack.*/
  IFX_DECT_DPSU_ACTIVE,     /*!< DPSU is capable of transmitting/receiving messages.*/
}e_IFX_DECT_DPSU_States;
#ifndef LTQ_RAW_DPSU
/*! \enum e_IFX_DECT_SUOTA_Command
   \brief An enumeration defining different SUOTA command.
*/

typedef enum{
  IFX_DECT_SUOTA_CMD_VERSION_INDICATION,       /*!< Version Indication.*/
  IFX_DECT_SUOTA_CMD_VERSION_AVAILABLE,    /*!< Version Available.*/
  IFX_DECT_SUOTA_CMD_URL_INDICATION,  /*!< URL Indication.*/
  IFX_DECT_SUOTA_CMD_NACK,     /*!< Negative Acknowledgement.*/
}e_IFX_DECT_SUOTA_Command;

/*! \enum e_IFX_DECT_SUOTA_Version
   \brief An enumeration defining different SUOTA command.
*/

typedef enum{
  IFX_DECT_SUOTA_SW_VID = 0x01,       /*!< Software Version Identifier.*/
  IFX_DECT_SUOTA_HW_VID = 0x02,    /*!< Hardware Version Identifier.*/  
}e_IFX_DECT_SUOTA_Version;

/*! \enum e_IFX_DECT_SUOTA_States
   \brief An enumeration defining different DPSU states for a connection.
*/

typedef enum{
  IFX_DECT_SUOTA_IDLE,       /*!< Idle */
  IFX_DECT_SUOTA_INDICATION,       /*!< Received Version Indication.*/
  IFX_DECT_SUOTA_WAIT_FOR_URL,    /*!< Waiting for URL.*/
  IFX_DECT_SUOTA_INITIATED,  /*!< SUOTA Initiated.*/
  IFX_DECT_SUOTA_IN_PROCESS,     /*!< Available Version to PP.*/
}e_IFX_DECT_SUOTA_States;

/** x_IFX_DECT_DPSU_DGmepControl structure stores the information pertaining to 
    DGMEP protocol for a connection.
*/
typedef struct {  
  uchar8  ucIsChop;  /*!< Chopping Enable/Disable */
  uchar8  ucIsSeq;   /*!< Sequencing Enable/Disable */
  uchar8  ucGMCI;    /*!< GMCI number */
  uint16  unAppId;   /*!< Application Protocol ID */
}x_IFX_DECT_DPSU_DGmepControl;
               			      
typedef struct {  
  uchar8 ucNoOfCtrlSet;   
  x_IFX_DECT_DPSU_DGmepControl xDgmepCtrl;
}x_IFX_DECT_DPSU_DGmepControlSet;
#endif
/** x_IFX_DECT_ConnectionInfo Structure stores connection Information for each handset.*/ 
  
typedef struct{
   uint32 uiPrivateData;           /*!< Private Data specific to Data Application used to identify connection. */
   uchar8 ucHandset;               /*!< Dect Portable Terminal Identity. */
   uchar8 ucInstance;              /*!< Incarnation Number. */
   char8 acBuff[IFX_DECT_DPSU_MAX_WINDOWSIZE];            /*!< Data Buffer storing data coming from Voip Network via FT Application. */
   uint16 uiRXbyte;                /*!< Bytes of data received from Voip network. */
   uint16 uiTXbyte;                /*!< Bytes of data transmitted to PT. */   
   e_IFX_DECT_DPSU_States eState;  /*!<State of a handset. */
#ifndef LTQ_RAW_DPSU   
   uchar8 ucRSN;  /*!<Received Sequence Number */
   uint16 unReqByte; /*! Bytes of data received from PP  */
   char8 acReqBuff[IFX_DECT_DPSU_MAX_REQ_BUFF_SIZE];/*!< Data Buffer storing data coming from PP. */
   
   uchar8 ucSSN;  /*!<Send Sequence Number */
   x_IFX_DECT_DPSU_DGmepControl xDgmep;  /*!<DGMEP protocol information */
	 uint32 uiMaxSDUSize;
   uint32 uiTotalRXbyte;                /*!< Bytes of data received from Voip network. */
   uint32 uiTotalTXbyte;                /*!< Bytes of data transmitted to PT. */   
#endif   
}x_IFX_DECT_DPSU_ConnectionInfo;

/** x_IFX_DECT_DPSUSesionType structure stores  session Information of DECT 
    endpoint to service data requests. */

typedef struct{
   uchar8 acProtocol_ID;                                                 /*!< Protocol Identifier. */
   x_IFX_DECT_DPSU_CallBks xCallBks;                             /*!< CallBacks of the protocol. */
   x_IFX_DECT_DPSU_ConnectionInfo xConnectionList[IFX_DECT_MAX_DATACON]; /*!< Connection Info per handset. */
}x_IFX_DECT_DPSU_DataSessionType;
#ifndef LTQ_RAW_DPSU
typedef struct {      
  uint16 unEMC;     
  char8  acHwVer[20];       
  char8  acSwVer[20];    
  char8  acUrl[IFX_DECT_SUOTA_MAX_URL_LEN];      
  uchar8 ucFileNum;   
  char8 user_interaction;	
  e_IFX_DECT_SUOTA_Reason eReason;     	
}x_IFX_DECT_SUOTA_VersionInfo;

/** x_IFX_DECT_DPSU_SuotaSession structure stores  session Information of DECT 
    endpoint to service data requests. */

typedef struct{
  uchar8 ucHandsetId;           /*!< Handset Identifier. */
  uchar8 ucUrl1ToFollow;   /*!< Number of URL Indication msg which contains the URL. */
  uint16 unUrlLen;  /*!< Total length of the URL received. */
  e_IFX_DECT_SUOTA_States eState;  /*!< State of SUOTA. */
  x_IFX_DECT_SUOTA_VersionInfo xVerInfo; /*!< Version Info */
  x_IFX_DECT_SUOTA_CallBks xCallBks;//Not used?? delete?
}x_IFX_DECT_DPSU_SuotaSession;
#endif
/*! \enum e_IFX_DECT_DPSU_Events
   \brief An enumeration defining DPRS events from DECT Stack.
*/

typedef enum{
 IFX_DECT_DPSU_INIT_CALL,         /*!< Incoming Call. */
 IFX_DECT_DPSU_ACCEPT_CALL,          /*!< Accept Call coming from PT. */
 IFX_DECT_DPSU_REJECT_CALL,          /*!< Reject Call. */
 IFX_DECT_DPSU_TX,                   /*!< Send Data to IP Stack. */
 IFX_DECT_DPSU_RX_READY,             /*!< Recv From IP Stack Ready. */
 IFX_DECT_DPSU_RX,                   /*!< Recv from IP Stack. */         
 IFX_DECT_DPSU_CLOSE_CALL,           /*!< Close Data Connection from FT/PT. */
}e_IFX_DECT_DPSU_Events;

/** \brief x_IFX_DECT_RouteData structure contains information retrieved from U and 
           C Plane for issuing Callbacks. */

typedef struct{
 e_IFX_DECT_DPSU_Events eEvent;      /*!< DECT Stack Event. */
 uchar8 ucInstance;                  /*!< Incarnation Number. */
 char8 *pcData;                      /*!< Pointer to Data Buffer. */
 int32 iLen;                         /*!< Length of data buffer. */
 uchar8 ucHandset;                   /*!< Handset Number. */
 uchar8 ucProtocolID;                /*!< Protocol Identifier. */
 uint32 uiIEHdl;                     /*!< Information Element Handle. */
 uchar8 ucNoBuffers;                 /*!< Number of Data Buffers. */
 uint16 uiBufferLen;                 /*!< Length of Data Buffer. */
}x_IFX_DECT_DPSU_RouteData; 

/** \brief x_IFX_DECT_FrameData structure contains C and U Plane Information to be 
     sent to PT. */ 

typedef struct{
 e_IFX_DECT_DPSU_Events eEvent;              /*!< DECT STack Event. */
 uchar8 ucInstance;                          /*!< Incarnation Number. */
 char8 acData[IFX_DECT_DPSU_MAX_BUFFERSIZE]; /*!< Data Buffer. */
 int32 iLen;                                 /*!< Length of data buffer. */
 uchar8 ucHandset;                           /*!< Handset Number. */
 e_IFX_DECT_RelType eReason;                 /*!< Reason for failure. */
 uint32 uiIEHdl;                             /*!< Information Element handle. */
}x_IFX_DECT_DPSU_FrameData;
 
/*! \brief IFX_DECT_DPSU_FrameOutgoingPkts function processes messages received from Data IWU.
           Messages framed are sent to PT.
    \param[in] pxFrame is a pointer to a structure containing eEvent,ucInstance,pcData,iLen,
               ucHandset,eReason and uiIEHdl.
    \return IFX_SUCCESS or IFX_FAILURE.
*/
  
e_IFX_Return IFX_DECT_DPSU_FrameOutgoingPkts(x_IFX_DECT_DPSU_FrameData *pxFrame);

/*! \brief IFX_DECT_DPSU_SendReleaseMsgToStacks is an internal function.If the routing of incoming
     message fails it sends back close connection to DECT stack.
    \param[in] pxIpcMsg pointer to C Plane IPC Message.
	\param[in] eReason Reason for failure.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_SendReleaseMsgToStack(IN x_IFX_DECT_IPC_Msg* pxIpcMsg,
                                                 IN e_IFX_DECT_RelType eReason);

/*! \brief IFX_DECT_DPSU_GetProtocolID is an internal function used to extract Protocol Identifier
     from incoming IPC Message from PT.
    \param[in] puiIEHdl Information Element Handler.
    \param[out] pucProtocolID Protocol Identifier.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_GetProtocolID(IN uint32 *puiIEHdl,
                                         OUT uchar8 *pucProtocolID);

/*! \brief IFX_DECt_DPSU_ValidateProtoID is an internal function used to validate Protocol Identifier
     as one of those permitted by standards.
    \param[in] ucProtocolID Protocol Identifier.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

extern e_IFX_Return IFX_DECT_DPSU_ValidateProtoID(IN uchar8 ucProtocolID);

/*! \brief IFX_DECT_DPSU_ProcessCPlaneMsg function processes messages received from DECT stack.
    \param[in] pxIpcMsg Pointer to DECT IPC message struct.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ProcessCPlaneMsg(IN x_IFX_DECT_IPC_Msg *pxIpcMsg);

/*! \brief IFX_DECT_DPSU_ProcessUPlaneMsg processes messages received from DECT stack.
    \param[in] pxUPlaneIpcMsg Pointer to DECT U Plane IPC message struct.
    \return IFX_SUCCESS or IFX_FAILURE.
 */

e_IFX_Return IFX_DECT_DPSU_ProcessUPlaneMsg(IN x_IFX_DECT_IPC_Msg_u *pxUPlaneIpcMsg);

/*! \brief Get Free Connection Index for a Session Index.
    \param[in] iSessionIndex Session Index.
    \return Connection Index or IFX_FAILURE.
*/

int32 IFX_DECT_DPSU_GetFreeConnectionIndex(IN int32 iSessionIndex);

/*! \brief Get Matching Connection Index for a Session Index.
    \param[in] iSessionIndex Session Index.
	\param[in] ucHandset Handset Number.
	\return Connection Index or IFX_FAILURE.
*/
int32 IFX_DECT_DPSU_GetMatchConnectionIndex(IN int32 iSessionIndex,
                                           IN uchar8 ucHandset);
			
/*! \brief Get Matching Session Index based on Protocol Identifier for C Plane.
    \param[in] ucProtocolID Protocol Identifier.
    \return Connection Index or IFX_FAILURE.
*/

int32 IFX_DECT_DPSU_GetMatchSessionIndex_CPlane(IN uchar8 ucProtocolID);

/*! \brief  Get Free Session Index.
    \return Session Index or IFX_FAILURE.
*/

int32 IFX_DECT_DPSU_GetFreeSessionIndex();

/*! \brief Get Matching Session on the basis of Incarnation Number for U Plane.
    \param[in] ucInstance Incarnation Number.
    \return Session Index of IFX_FAILURE.
*/

int32 IFX_DECT_DPSU_GetMatchSessionIndex_UPlane(IN uchar8 ucInstance);

/*! \brief Called by the Dect Interface unit after checking for the PT registration
            and extracting the protocol and handset number.
    \param[in] pxRoute pointer to a structure containing eEvent,ucInstance,pcData,iLen,
               ucHandset,ucProtocolID,uiIEHdl,ucNoBuffers,uiBufferLen.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_RouteIncomingPkts(x_IFX_DECT_DPSU_RouteData *pxRoute);

/*! \brief API to send data buffer to PT when flow in message arrives.
    \param[in] ucInstance Instance Number.
	\param[in] ucHandset Handset Number.
    \param[in] uiDataHdl is connection handle.
	\return IFX_SUCCESS or IFX_FAILURE.
*/
				
e_IFX_Return IFX_DECT_DPSU_GetBuffer(IN uchar8 ucInstance,
                                     IN uchar8 ucHandset,
                                     IN uint32 uiDataHdl);
									 

/*! \brief IFX_DECT_DPSU_ReleaseConnectionResources is used to free Connection
           by releasing allocated resources.
    \param[in] uiCallHdl Connection handle.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ReleaseConnectionResources(IN uint32 uiCallHdl);
#ifndef LTQ_RAW_DPSU
/*! \brief IFX_DECT_DPSU_CheckPD is used to determine the SUOTA commands in 
           FACILITY message
    \param[in] pxIPCMsg pointer to IPC message.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_CheckPD(x_IFX_DECT_IPC_Msg *pxIPCMsg);
#endif
#endif /*__IFX_DECT_DATA_IWU_H__*/ 
