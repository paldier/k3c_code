#ifndef __IFX_DECT_USUHEADER_H__
#define __IFX_DECT_USUHEADER_H__

/** \ingroup DECT_TOOLKIT_API
    \defgroup USU_API Utility Service Unit
	\brief This group contains the Utility Service Unit (USU) functions 
		   of the DECT Toolkit.  It provides a set of procedures:\n
		   1> For Encoding Date/Time,Event Notification and Call Information IEs.\n
		   2> For processing IPC Message from DECT Stack sent by PT.\n
		   3> For releasing incarnation number after notification. \n
*/
/* @{ */
										   
/*! \def IFX_DECT_USU_LINK_PRESENT
    \brief Macro that specifies whether a link already exists i.e. there is
           an ongoing call.
*/

#define IFX_DECT_USU_LINK_PRESENT 1

/*! \def IFX_DECT_USU_NO_LINK_PRESENT
 *     \brief Macro that specifies that a link does not exist.
 *     */

#define IFX_DECT_USU_NO_LINK_PRESENT 0

/*! \def IFX_DECT_USU_RF_ON
    \brief Macro that specifies that RF is on.
*/

#define IFX_DECT_USU_RF_ON 1


/*! \def IFX_DECT_USU_RF_OFF
    \brief Macro that specifies that RF is off.
*/

#define IFX_DECT_USU_RF_OFF 0


/*! \brief The API IFX_DECT_USU_HandleRF enables or disables RF.
    \param[in] ucRFState indicates whether to switch on/off RF.
	\return IFX_SUCCESS or IFX_FAILURE
*/
	   
e_IFX_Return IFX_DECT_USU_HandleRF(IN uchar8 ucRFState);


/*! \brief The Api IFX_DECT_USU_EncodeTimeDate helps encode TimeDate Information 
           Element and add it to the IPC message to be sent to PT.
    \param[in] pcTimeDate pointer to the structure containing TimeDate Information.
    \param[in] ucTimeDateLen size of the TimeDate structure.
	  \param[out] pointer to acData in IPC Message.
	  \return IFX_SUCCESS or IFX_FAILURE.
*/
						   
e_IFX_Return IFX_DECT_USU_EncodeTimeDate(IN uchar8 *pcTimeDate,
                                         IN uchar8 ucTimeDateLen,
                                         OUT uchar8 *pcData);


/*! \brief API IFX_DECT_EncodeEventNotify encodes Event Notification Information
           Element and adds it to the IPC Message to be sent to PT.
    \param[in] pxEventList pointer to structure containing Event and Line Information.
    \param[out] pcData pointer to acData in IPC Message.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_USU_EncodeEventNotify(IN x_IFX_DECT_USU_EventList *pxEventList,
                                            IN uint32 uiIEHdl);

/*! \brief The Api IFX_DECT_EncodeCallInformation encodes Call Information
           IE and appends it to the IPC Message to be sent to PT.It contains
           Line/Call Information.
    \param[in] pxIdList pointer to structure containing Event and Line Information.
    \param[out] pcData pointer to acData in IPC Message.
    \return IFX_SUCCESS or IFX_FAILURE;
*/

e_IFX_Return IFX_DECT_USU_EncodeCallInformation(IN x_IFX_DECT_USU_EventList *pxIdList,
                                                IN uint32 uiIEHdl);


/*! \brief The Api IFX_DECT_USU_FetchTimeDateInfo obtains TimeDate Information from the
           IPC Message and returns it in the form of a structure.
    \param[in] pxIpcMesg pointer to IPC Message.
    \param[out] pxTimeDate pointer to structure containing TimeDate Info.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_USU_FetchTimeDateInfo(IN x_IFX_DECT_IPC_Msg *pxIpcMesg,
                                            OUT x_IFX_DECT_USU_TimeDate *pxTimeDate );

/*! \brief The Api IFX_DECT_USU_ProcessStkMesg processes IPC Message coming
           from the stack.
    \param[in] pxIpcMesg pointer to IPC Message.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_USU_ProcessStkMesg(IN x_IFX_DECT_IPC_Msg *pxIpcMesg);

/*! \brief The Api IFX_DECT_USU_ReleaseInstance helps to free instance number procured 
           during any of event notification events.
    \param[in] ucIsLink specifies whether a link exists or not.
	  \param[in] ucInstance Incarnation Number.
	  \return IFX_SUCCESS or IFX_FAILURE.
*/
					   
e_IFX_Return IFX_DECT_USU_ReleaseInstance(IN uchar8 ucIsLink,
                                          IN uchar8 ucInstance,
										  IN uchar8 ucHandset);
#ifdef FW_DOWNLOAD
extern uchar8 vucLoaderMode;
/*!
    \brief Structure describing the frame of the loader protocol.
*/
typedef struct{
  uchar8 aucLen[2];
  uchar8 ucTag;
	uchar8 ucStart;
	uchar8 aucOpcode[2];
	uchar8 aucSize[2];
	uchar8 aucData[517];
	uchar8 ucCRC;
}x_IFX_DECT_LoaderFrame;


#define DECT_DRV_SET_LOADER_MODE 0x09 // To Loader Mode
#define DECT_DRV_SET_APP_MODE 0x0A // To Normal working mode
#define DECT_DRV_FW_WRITE 0x0B // To write firmware
#define DECT_DRV_FW_READ 0x0C // To Read write confirmation

//e_IFX_Return IFX_DECT_ReceivedFwDownloadStatus(x_IFX_DECT_LoaderFrame *pxFrame);
#endif

#endif /* __IFX_DECT_USUHEADER_H__ */

