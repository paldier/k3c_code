/**************************************************************************
**   FILE NAME     : IFX_DECT_LAU.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_LAU.h
    \brief This file contains the List Access Unit (LAU) Procedures.  
                The LAU is the module that provides a set of procedures
                to manage the lists between the PP and the FP.	
*/

/** \ingroup DECT_TOOLKIT_MODULES
       \defgroup LAU_MODULE List Access Unit
       \brief The List Access Unit manages the list handling needs.
       All the lists described in the CAT iq 2.0 are supported by the
       LAU.  The LAU implements all the list access commands as 
       specified in the CAT iq 2.0.  The interface provided by the
       LAU is listed in the chapter on Toolkit API.  The examples
       chapter provides source code example illustrating the usage
       of the LAU interface.
*/
/* @{ */
/* @} */
#ifndef __IFX_DECT_LAU_H__
#define __IFX_DECT_LAU_H__

/** \ingroup DECT_TOOLKIT_API
    \defgroup LAU_API List Access Unit
    \brief This group contains the List Access Unit (LAU) functions 
            of the DECT Toolkit.  It provides a set of procedures that allow \n
	  1> Operations to be performed on the defined lists.\n
	  2> All operations listed in the CAT iq 2.0 are supported and so are 
                 the lists described in CAT iq 2.0.\n
             3> The callback functions are designed in a way to implicitly manage
                   the response to list commands.\n
             4> Separate encoding and decoding functions are provided to
                   manage the construction and deconstruction of data packets.
*/
/* @{ */
/*! \def IFX_DECT_LAU_MAX_SESS_PER_HS
    \brief Macro that defines the maximum number of Sessions per handset.
 */
#define IFX_DECT_LAU_MAX_SESS_PER_HS 4

/*! \def IFX_DECT_LAU_MAX_SORTING_FIELDS
    \brief Macro that defines the maximum number of sorting fields in a buffer.
 */
#define IFX_DECT_LAU_MAX_SORTING_FIELDS 254         /*!< Maximum number of Sorting fields */

/*! \def IFX_DECT_LAU_MAX_SUPPORTED_LISTS
    \brief Macro that defines the maximum number of supported lists within the LAU.
 */
#define IFX_DECT_LAU_MAX_SUPPORTED_LISTS 65         /*!< Maximum number of Supported Lists */
/*! \def IFX_DECT_LAU_MAX_HS
    \brief Macro that defines the maximum number of Handsets that could be registered.
 */
#define IFX_DECT_LAU_MAX_HS 6

/*! \def IFX_DECT_LAU_MAX_PROP_LIST
    \brief Macro that defines the maximum number of proprietary lists that is supported.
 */
#define IFX_DECT_LAU_MAX_PROP_LIST 5


//#define DRAFT17
#define PIN
/*****************************************************************************
 * Data Structures for Call Lists
 ******************************************************************************/

/*! \def IFX_DECT_LAU_MAX_NUMBER_LEN
    \brief Macro that defines the maximum length of a Caller/Callee number.
 */
#define IFX_DECT_LAU_MAX_NUMBER_LEN         32  /*!< Maximum length of Caller/Callee number */

/*! \def IFX_DECT_LAU_MAX_NAME_LEN
    \brief Macro that defines the maximum length of a caller/callee name.
 */
#define IFX_DECT_LAU_MAX_NAME_LEN           32  /*!< Maximum length of Caller/Callee name */

/*! \def IFX_DECT_LAU_MAX_DATE_LEN
    \brief Macro that defines the maximum length of a date string.  DD-MM-YYYY
 */
#define IFX_DECT_LAU_MAX_DATE_LEN           10  /*!< Maximum length of date string */

/*! \def IFX_DECT_LAU_MAX_TIME_LEN
    \brief Macro that defines the maximum length of a time string.  HH:MM
 */
#define IFX_DECT_LAU_MAX_TIME_LEN           5   /*!< Maximum length of time string */

/*! \def IFX_DECT_LAU_MAX_LINE_NAME_LEN
    \brief Macro that defines the maximum length of a line name.
 */
#define IFX_DECT_LAU_MAX_LINE_NAME_LEN      16  /*!< Maximum length of line name */

/*! \def IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES
    \brief Macro that defines the maximum number of entries in a Call List.
 */
#define IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES      20  /*!< Maximum number of entries in a Call List */

/*! \def IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES
    \brief Macro that defines the maximum number of entries in a Contact List.
 */
#define IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES    50  /*!< Maximum number of entries in a Contact List */

/*! \def IFX_DECT_LAU_MAX_ALL_CALL_LIST_ENTRIES
    \brief Macro that defines the maximum number of entries in a Call List.
 */
#define IFX_DECT_LAU_MAX_ALL_CALL_LIST_ENTRIES      60  /*!< Maximum number of entries in a Call List */

/*! \def IFX_DECT_LAU_MAX_ALL_INCOMING_CALL_LIST_ENTRIES
    \brief Macro that defines the maximum number of entries in a Call List.
 */
#define IFX_DECT_LAU_MAX_ALL_INCOMING_CALL_LIST_ENTRIES    40  /*!< Maximum number of entries in a Call List */

/*! \def IFX_DECT_LAU_LIST_OF_SUPPORTED_LIST
    \brief Macro that defines the type for the List of supported List.
 */
#define IFX_DECT_LAU_LIST_OF_SUPPORTED_LIST      0  /*!< List of supported List */


/*! \def IFX_DECT_LAU_CALL_LIST_TYPE_MISSED
    \brief Macro that defines the type for the Missed Call List.
 */
#define IFX_DECT_LAU_CALL_LIST_TYPE_MISSED      1  /*!< Missed Call List */

/*! \def IFX_DECT_LAU_CALL_LIST_TYPE_ACCEPTED
    \brief Macro that defines the type for the Accepted Call List.
 */
#define IFX_DECT_LAU_CALL_LIST_TYPE_ACCEPTED    3  /*!< Accepted Call List */

/*! \def IFX_DECT_LAU_CALL_LIST_TYPE_OUTGOING
    \brief Macro that defines the type for the Outgoing Call List.
 */
#define IFX_DECT_LAU_CALL_LIST_TYPE_OUTGOING    2  /*!< Outgoing Call List */

/*! \def IFX_DECT_LAU_ALL_CALL_LIST
    \brief Macro that defines the type for the All Call List.
 */
#define IFX_DECT_LAU_ALL_CALL_LIST 4 /*!< All Call List */

/*! \def IFX_DECT_LAU_CONTACT_LIST
    \brief Macro that defines the type for the contact List.
 */
#define  IFX_DECT_LAU_CONTACT_LIST 5 /*!< Contact List */

/*! \def IFX_DECT_LAU_SYSTEM_SETTING_LIST
    \brief Macro that defines the type for the System settings List.
 */
#define IFX_DECT_LAU_SYSTEM_SETTING_LIST 7 /*!< DECT System Setting List */

/*! \def IFX_DECT_LAU_LINE_SETTING_LIST
    \brief Macro that defines the type for the Line setting List.
 */
#define IFX_DECT_LAU_LINE_SETTING_LIST 8 /*!< Line Settings List */

/*! \def IFX_DECT_LAU_INTERNAL_NAME_LIST
    \brief Macro that defines the type for the Internal name list.
 */
#define IFX_DECT_LAU_INTERNAL_NAME_LIST 6 /*!< Internal Names List */

/*! \def IFX_DECT_LAU_ALL_INCOMING_CALL_LIST
    \brief Macro that defines the type for the All Incoming Calls list.
 */
#define IFX_DECT_LAU_ALL_INCOMING_CALL_LIST 9 /*!< All Incoming Call List */

/*****************************************************************************
 * Field Identifiers for Call Lists - Missed Call List
 ******************************************************************************/
/*! \def IFX_DECT_LAU_CL_MISSED_NUMBER
    \brief Macro that defines the "Number" Field identifier within the Missed call list.
 */
#define IFX_DECT_LAU_CL_MISSED_NUMBER           0x01  /*!< Missed Call List: Number */
 
/*! \def IFX_DECT_LAU_CL_MISSED_NAME
    \brief Macro that defines the "Name" Field identifier within the Missed call list.
 */
#define IFX_DECT_LAU_CL_MISSED_NAME             0x02  /*!< Missed Call List: Name */
 
/*! \def IFX_DECT_LAU_CL_MISSED_DATE_TIME
    \brief Macro that defines the "Date and Time" Field identifier within the Missed call list.
 */
#define IFX_DECT_LAU_CL_MISSED_DATE_TIME        0x03  /*!< Missed Call List: Date and Time */

/*! \def IFX_DECT_LAU_CL_MISSED_NEW
    \brief Macro that defines the "New" Field identifier within the Missed call list.
 */
#define IFX_DECT_LAU_CL_MISSED_NEW              0x04  /*!< Missed Call List: New */

/*! \def IFX_DECT_LAU_CL_MISSED_LINE_NAME
    \brief Macro that defines the "Line Name" Field identifier within the Missed call list.
 */
#define IFX_DECT_LAU_CL_MISSED_LINE_NAME        0x05  /*!< Missed Call List: Line Name*/

/*! \def IFX_DECT_LAU_CL_MISSED_LINE_ID
    \brief Macro that defines the "Line Id" Field identifier within the Missed call list.
 */
#define IFX_DECT_LAU_CL_MISSED_LINE_ID          0x06  /*!< Missed Call List: Line Id */

/*! \def IFX_DECT_LAU_CL_MISSED_NUM_CALLS
    \brief Macro that defines the "Number of Calls" Field identifier within the Missed call list.
 */
#define IFX_DECT_LAU_CL_MISSED_NUM_CALLS        0x07  /*!< Missed Call List: Number of Calls */
 
/*****************************************************************************
 * Field Identifiers for Call Lists - Outgoing Call List
 ******************************************************************************/
/*! \def IFX_DECT_LAU_CL_OUTGOING_NUMBER
    \brief Macro that defines the "Number" Field identifier within the Outgoing call list.
 */
#define IFX_DECT_LAU_CL_OUTGOING_NUMBER         0x01  /*!< Outgoing Call List: Number */
 
/*! \def IFX_DECT_LAU_CL_OUTGOING_NAME
    \brief Macro that defines the "Name" Field identifier within the Outgoing call list.
 */
#define IFX_DECT_LAU_CL_OUTGOING_NAME           0x02  /*!< Outgoing Call List: Name */

/*! \def IFX_DECT_LAU_CL_OUTGOING_DATE_TIME
    \brief Macro that defines the "Date and Time" Field identifier within the Outgoing call list.
 */
#define IFX_DECT_LAU_CL_OUTGOING_DATE_TIME      0x03  /*!< Outgoing Call List: Date and Time */

/*! \def IFX_DECT_LAU_CL_OUTGOING_LINE_NAME
    \brief Macro that defines the "Line Name" Field identifier within the Outgoing call list.
 */
#define IFX_DECT_LAU_CL_OUTGOING_LINE_NAME      0x04  /*!< Outgoing Call List: Line Name */

/*! \def IFX_DECT_LAU_CL_OUTGOING_LINE_ID
    \brief Macro that defines the "Line Id" Field identifier within the Outgoing call list.
 */
#define IFX_DECT_LAU_CL_OUTGOING_LINE_ID        0x05  /*!< Outgoing Call List: Line Id */

/*****************************************************************************
 * Field Identifiers for Call Lists - Incoming Call List
 ******************************************************************************/
/*! \def IFX_DECT_LAU_CL_INCOMING_NUMBER
    \brief Macro that defines the "Number" Field identifier within the Incoming call list.
 */
#define IFX_DECT_LAU_CL_INCOMING_NUMBER         0x01  /*!< Incoming Call List: Number */
 
/*! \def IFX_DECT_LAU_CL_INCOMING_NAME
    \brief Macro that defines the "Name" Field identifier within the Incoming call list.
 */
#define IFX_DECT_LAU_CL_INCOMING_NAME           0x02  /*!< Incoming Call List: Name */

/*! \def IFX_DECT_LAU_CL_INCOMING_DATE_TIME
    \brief Macro that defines the "Date and Time" Field identifier within the Incoming call list.
 */
#define IFX_DECT_LAU_CL_INCOMING_DATE_TIME      0x03  /*!< Incoming Call List: Date and Time */

/*! \def IFX_DECT_LAU_CL_INCOMING_LINE_NAME
    \brief Macro that defines the "Line Name" Field identifier within the Incoming call list.
 */
#define IFX_DECT_LAU_CL_INCOMING_LINE_NAME      0x04  /*!< Incoming Call List: Line Name */

/*! \def IFX_DECT_LAU_CL_INCOMING_LINE_ID
    \brief Macro that defines the "Line Id" Field identifier within the Incoming call list.
 */
#define IFX_DECT_LAU_CL_INCOMING_LINE_ID        0x05  /*!< Incoming Call List: Line Id */
 
/*****************************************************************************
 * Field Identifiers for Call Lists - All Call List
 ******************************************************************************/
/*! \def IFX_DECT_LAU_CL_ALL_CALL_TYPE
    \brief Macro that defines the "Call Type" Field identifier within the All Calls list.
 */
#define IFX_DECT_LAU_CL_ALL_CALL_TYPE           0x01  /*!< All Calls List: Call Type */
 
/*! \def IFX_DECT_LAU_CL_ALL_CALL_NUMBER
    \brief Macro that defines the "Number" Field identifier within the All Calls list.
 */
#define IFX_DECT_LAU_CL_ALL_CALL_NUMBER         0x02  /*!< All Calls List: Number */
 
/*! \def IFX_DECT_LAU_CL_ALL_CALL_NAME
    \brief Macro that defines the "Name" Field identifier within the all calls list.
 */
#define IFX_DECT_LAU_CL_ALL_CALL_NAME           0x03  /*!< All Calls List: Name */

/*! \def IFX_DECT_LAU_CL_ALL_CALL_DATE_TIME
    \brief Macro that defines the "Date and Time" Field identifier within the all calls list.
 */
#define IFX_DECT_LAU_CL_ALL_CALL_DATE_TIME      0x04  /*!< All Calls List: Date and Time */

/*! \def IFX_DECT_LAU_CL_ALL_CALL_LINE_NAME
    \brief Macro that defines the "Line Name" Field identifier within the all calls list.
 */
#define IFX_DECT_LAU_CL_ALL_CALL_LINE_NAME      0x05  /*!< All Calls List: Line Name */

/*! \def IFX_DECT_LAU_CL_ALL_CALL_LINE_ID
    \brief Macro that defines the "Line Id" Field identifier within the all calls list.
 */
#define IFX_DECT_LAU_CL_ALL_CALL_LINE_ID        0x06  /*!< All Calls List: Line Id */

/*****************************************************************************
 * Field Identifiers for Call Lists - All Incoming Call List
 ******************************************************************************/
/*! \def IFX_DECT_LAU_CL_ALL_INCOMING_NUMBER
    \brief Macro that defines the "Number" Field identifier within the All Incoming calls list.
 */
#define IFX_DECT_LAU_CL_ALL_INCOMING_NUMBER           0x01  /*!< All Incoming Calls List: Number */
 
/*! \def IFX_DECT_LAU_CL_ALL_INCOMING_NAME
    \brief Macro that defines the "Name" Field identifier within the All Incoming calls list.
 */
#define IFX_DECT_LAU_CL_ALL_INCOMING_NAME             0x02  /*!< All Incoming Calls List: Name */
 
/*! \def IFX_DECT_LAU_CL_ALL_INCOMING_DATE_TIME
    \brief Macro that defines the "Date and Time" Field identifier within the All Incoming calls list.
 */
#define IFX_DECT_LAU_CL_ALL_INCOMING_DATE_TIME        0x03  /*!< All Incoming Calls List: Date and Time */

/*! \def IFX_DECT_LAU_CL_ALL_INCOMING_NEW
    \brief Macro that defines the "New" Field identifier within the All Incoming calls list.
 */
#define IFX_DECT_LAU_CL_ALL_INCOMING_NEW              0x04  /*!< All Incoming Calls List: New */

/*! \def IFX_DECT_LAU_CL_ALL_INCOMING_LINE_NAME
    \brief Macro that defines the "Line Name" Field identifier within the All Incoming calls list.
 */
#define IFX_DECT_LAU_CL_ALL_INCOMING_LINE_NAME        0x05  /*!< All Incoming Calls List: Line Name*/

/*! \def IFX_DECT_LAU_CL_ALL_INCOMING_LINE_ID
    \brief Macro that defines the "Line Id" Field identifier within the All Incoming calls list.
 */
#define IFX_DECT_LAU_CL_ALL_INCOMING_LINE_ID        0x06  /*!< All Incoming Calls List: Line Id */

/*! \def IFX_DECT_LAU_CL_ALL_INCOMING_NUM_CALLS
    \brief Macro that defines the "Number of Calls" Field identifier within the All Incoming calls list.
 */
#define IFX_DECT_LAU_CL_ALL_INCOMING_NUM_CALLS        0x07  /*!< All Incoming Calls List: Number of Calls */

/*!
    \brief Structure describing the Missed call list Entry.
*/
typedef struct
{
    int16 nEntryId;/*!< Entry Identifier */
	uchar8 ucInternal;/*!< If Internal number set to 0x20 else to 0x00 */
	char8 acCallerNum[IFX_DECT_LAU_MAX_NUMBER_LEN]; /*!< Calling Party Number */
    char8 acCallerName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< Calling Party Name */
    x_IFX_DECT_USU_TimeDate xTimeDate; /*!< Date and time of missed call */
    boolean bNew; /*!< New or Old Entry */
    char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]; /*!< Line Name */
    uchar8 ucLineId; /*!< Line Id */
    uchar8 ucNoOfCalls; /*!< Number of Calls */
} x_IFX_DECT_LAU_MissedCallListEntry;

/*!
    \brief Structure describing the Missed call list.
*/
typedef struct
{
    char8 cNoOfEntries; /*!< Number of entries */
    x_IFX_DECT_LAU_MissedCallListEntry axMissedCallList[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES]; /*!< Missed call list */
} x_IFX_DECT_LAU_MissedCallList;

/*!
    \brief Structure describing the Outgoing call list Entry.
*/
typedef struct
{
    int16 nEntryId;/*!< Entry Identifier */
	uchar8 ucInternal;/*!< If Internal number set to 0x20 else to 0x00 */
    char8 acCalledNum[IFX_DECT_LAU_MAX_NUMBER_LEN]; /*!< Called Party Number */
    char8 acCalledName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< Called Party Name */
    x_IFX_DECT_USU_TimeDate xTimeDate; /*!< Date and time of outgoing call */
    char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]; /*!< Line Name */
    uchar8 ucLineId; /*!< Line Id */
} x_IFX_DECT_LAU_OutgoingCallListEntry;

/*!
    \brief Structure describing the Outgoing call list.
*/
typedef struct
{
    char8 cNoOfEntries; /*!< Number of entries */
    x_IFX_DECT_LAU_OutgoingCallListEntry axOutgoingCallList[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES]; /*!< Outgoing call list */
} x_IFX_DECT_LAU_OutgoingCallList;

/*!
    \brief Structure describing the Incoming call list Entry.
*/
typedef struct
{
    int16 nEntryId;/*!< Entry Identifier */
	uchar8 ucInternal;/*!< If Internal number set to 0x20 else to 0x00 */
    char8 acCallerNum[IFX_DECT_LAU_MAX_NUMBER_LEN]; /*!< Calling Party Number */
    char8 acCallerName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< Calling Party Name */
    x_IFX_DECT_USU_TimeDate xTimeDate; /*!< Date and time of incoming call */
    char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]; /*!< Line Name */
    uchar8 ucLineId; /*!< Line Id */
} x_IFX_DECT_LAU_IncomingCallListEntry;

/*!
    \brief Structure describing the Incoming call list.
*/
typedef struct
{
    char8 cNoOfEntries; /*!< Number of entries */
    x_IFX_DECT_LAU_IncomingCallListEntry axIncomingCallList[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES]; /*!< Incoming call list */
} x_IFX_DECT_LAU_IncomingCallList;

/*!
    \brief Structure describing the All call list Entry.
*/
typedef struct
{
    int16 nEntryId;/*!< Entry Identifier */
    char8 cCallListType; /*!< Call List Type , one of IFX_DECT_LAU_CALL_LIST_TYPE_* */
	uchar8 ucInternal;/*!< If Internal number set to 0x20 else to 0x00 */
    char8 acNum[IFX_DECT_LAU_MAX_NUMBER_LEN]; /*!< Calling/Called Party Number */
    char8 acName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< Calling/Called Party Name */
    x_IFX_DECT_USU_TimeDate xTimeDate; /*!< Date and time of call */
    char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]; /*!< Line Name */
    uchar8 ucLineId; /*!< Line Id */
} x_IFX_DECT_LAU_AllCallListEntry;

/*!
    \brief Structure describing the All call list.
*/
typedef struct
{
    char8 cNoOfEntries; /*!< Number of entries */
    x_IFX_DECT_LAU_AllCallListEntry axAllCallList[IFX_DECT_LAU_MAX_ALL_CALL_LIST_ENTRIES]; /*!< All call list */
} x_IFX_DECT_LAU_AllCallList;


/*!
    \brief Structure describing the All Incoming call list Entry.
*/

//typedef x_IFX_DECT_LAU_MissedCallListEntry x_IFX_DECT_LAU_AllIncomingCallListEntry;

typedef struct
{
    int16 nEntryId;/*!< Entry Identifier */
  	uchar8 ucInternal;/*!< If Internal number set to 0x20 else to 0x00 */
	  char8 acCallerNum[IFX_DECT_LAU_MAX_NUMBER_LEN]; /*!< Calling Party Number */
    char8 acCallerName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< Calling Party Name */
    x_IFX_DECT_USU_TimeDate xTimeDate; /*!< Date and time of call */
    boolean bNew; /*!< New or Old Entry */
    char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]; /*!< Line Name */
    uchar8 ucLineId; /*!< Line Id */
    uchar8 ucNoOfCalls; /*!< Number of Calls */
} x_IFX_DECT_LAU_AllIncomingCallListEntry;

/*!
    \brief Structure describing the All Incoming call list.
*/
typedef struct

{
    char8 cNoOfEntries; /*!< Number of entries */
    x_IFX_DECT_LAU_AllIncomingCallListEntry axAllIncomingCallList[IFX_DECT_LAU_MAX_ALL_INCOMING_CALL_LIST_ENTRIES]; 
             /*!< All Incoming call list */
} x_IFX_DECT_LAU_AllIncomingCallList;

/*****************************************************************************
 * Field Identifiers for Contact Lists - Contact List
 ******************************************************************************/
/*! \def IFX_DECT_LAU_CON_LIST_NAME
    \brief Macro that defines the "Name" Field identifier within the contacts list.
 */
#define IFX_DECT_LAU_CON_LIST_NAME           0x01  /*!< Contacts List: Name */

/*! \def IFX_DECT_LAU_CON_LIST_FIRST_NAME
    \brief Macro that defines the "First Name" Field identifier within the contacts list.
 */
#define IFX_DECT_LAU_CON_LIST_FIRST_NAME     0x02  /*!< Contacts List: First Name */

/*! \def IFX_DECT_LAU_CON_LIST_NUMBER
    \brief Macro that defines the "Contact Number" Field identifier within the contacts list.
 */
#define IFX_DECT_LAU_CON_LIST_NUMBER         0x03  /*!< Contacts List: Contact Number */

/*! \def IFX_DECT_LAU_CON_LIST_MELODY
    \brief Macro that defines the "Associated Melody" Field identifier within the contacts list.
 */
#define IFX_DECT_LAU_CON_LIST_MELODY         0x04  /*!< Contacts List: Associated Melody */

/*! \def IFX_DECT_LAU_CON_LIST_LINE_ID
    \brief Macro that defines the "Line Id" Field identifier within the contacts list.
 */
#define IFX_DECT_LAU_CON_LIST_LINE_ID        0x05  /*!< Contacts List: Line Id */

/*****************************************************************************
 * Field Identifiers for Contact Lists - Internal Names List
 ******************************************************************************/
/*! \def IFX_DECT_LAU_INT_NAME_LIST_NUMBER
    \brief Macro that defines the "Number" Field identifier within the internal names list.
 */
#define IFX_DECT_LAU_INT_NAME_LIST_NUMBER         0x01  /*!< Internal Names List: Number */

/*! \def IFX_DECT_LAU_INT_NAME_LIST_NAME
    \brief Macro that defines the "Name" Field identifier within the internal names list.
 */
#define IFX_DECT_LAU_INT_NAME_LIST_NAME           0x02  /*!< Internal Names List: Name */

/*! \def IFX_DECT_LAU_INT_NAME_LIST_CALL_INTERCEPT
    \brief Macro that defines the "Call Interception" Field identifier within the internal names list.
 */
#define IFX_DECT_LAU_INT_NAME_LIST_CALL_INTERCEPT           0x03  /*!< Internal Names List: Call Interception */

/*! \def IFX_DECT_LAU_MAX_CONTACT_TYPE
    \brief Macro that defines the maximum contact numbers possible for one contact name.
 */
#define IFX_DECT_LAU_MAX_CONTACT_TYPE 5 /*!< Maximum Contact types*/

/*! \def IFX_DECT_LAU_CONTACT_DEFAULT
    \brief Macro that defines the default contact type.
 */
#define IFX_DECT_LAU_CONTACT_DEFAULT                0x20 /*!< Default Contact type */

/*! \def IFX_DECT_LAU_CONTACT_OWN
    \brief Macro that defines the own contact type.
 */
#define IFX_DECT_LAU_CONTACT_OWN                    0x10 /*!< Own Contact type */

/*! \def IFX_DECT_LAU_CONTACT_FIXED
    \brief Macro that defines the fixed contact type.
 */
#define IFX_DECT_LAU_CONTACT_FIXED                  0x08 /*!< Fixed Contact type */

/*! \def IFX_DECT_LAU_CONTACT_MOBILE
    \brief Macro that defines the mobile contact type.
 */
#define IFX_DECT_LAU_CONTACT_MOBILE                 0x04 /*!< Mobile Contact type */

/*! \def IFX_DECT_LAU_CONTACT_WORK
    \brief Macro that defines the work contact type.
 */
#define IFX_DECT_LAU_CONTACT_WORK                   0x02 /*!< Work Contact type */

/*!
    \brief Structure describing the Contact number field.
*/
typedef struct
{
	char8 ctype; /*!< Default/Own/Fixed/Mobile/Work*/
    char8 acNumber[IFX_DECT_LAU_MAX_NUMBER_LEN]; /*!< Contact Number */
} x_IFX_DECT_LAU_ContactNumber;

/*!
    \brief Structure describing the complete Contact number entry.
*/
typedef struct 
{
  uchar8 ucNoOfContactNumbers;/*!< Number of entries */
  x_IFX_DECT_LAU_ContactNumber xNum[IFX_DECT_LAU_MAX_CONTACT_TYPE]; /*!< Contact numbers for all types */
}x_IFX_DECT_LAU_ContactNumberEntry;


/*! \def IFX_DECT_LAU_CL_LNAME
    \brief Macro that defines the Contact Last Name.
 */
#define IFX_DECT_LAU_CL_LNAME   0x0001 /*!< Last Name */

/*! \def IFX_DECT_LAU_CL_FNAME
    \brief Macro that defines the Contact First Name.
 */
#define IFX_DECT_LAU_CL_FNAME   0x0002 /*!< First Name */

/*! \def IFX_DECT_LAU_CL_NUM
    \brief Macro that defines the Contact Number.
 */
#define IFX_DECT_LAU_CL_NUM     0x0004 /*!< Contact Number */

/*! \def IFX_DECT_LAU_CL_ASCMEL
    \brief Macro that defines the Associated Melody.
 */
#define IFX_DECT_LAU_CL_ASCMEL  0x0008 /*!< Associated Melody */

/*! \def IFX_DECT_LAU_CL_LINEID
    \brief Macro that defines the Line Id.
 */
#define IFX_DECT_LAU_CL_LINEID  0x0010 /*!< Line Id */

/*! \def IFX_DECT_LAU_IL_NUM
    \brief Macro that defines the Internal name list Number field.
*/
#define IFX_DECT_LAU_IL_NUM  0x0001 /*!< Internal name list Number field */

/*! \def IFX_DECT_LAU_IL_FNAME
    \brief Macro that defines the Internal name list Name field.
*/
#define IFX_DECT_LAU_IL_FNAME   0x0002 /*!< Internal name list Name field*/

/*! \def IFX_DECT_LAU_IL_INTERCEPTION
    \brief Macro that defines the Internal name list Call Interception field.
*/
#define IFX_DECT_LAU_IL_INTERCEPTION 0x0004 /*!< Internal name list Intercept field*/

/*! \def IFX_DECT_LAU_IL_FNAME_PIN
    \brief Macro that defines the Contact First Name.
 */
#define IFX_DECT_LAU_IL_FNAME_PIN   0x00020000 /*!< First Name */

/*! \def IFX_DECT_LAU_IL_NUM_PIN
    \brief Macro that defines the Contact Number.
 */
#define IFX_DECT_LAU_IL_NUM_PIN     0x00010000/*!< Contact Number */

/*! \def IFX_DECT_LAU_IL_INTERCEPTION_PIN
    \brief Macro that defines the Call Interception.
*/
#define IFX_DECT_LAU_IL_INTERCEPTION_PIN  0x00040000 /*!< Call Interception */


/*!
    \brief Structure describing the Contact list Entry.
*/
typedef struct
{
    uint32 uiEditField;/*!< Mark Editable fiels in the list */
    char8 acLastName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< Last Name */
    char8 acFirstName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< First Name */
    x_IFX_DECT_LAU_ContactNumberEntry xNumber; /*!< Contact Number list */
    uchar8 ucAssocMelody; /*!< Associated Melody */
	uchar8 ucSubType;/*!< Line Subtype either "Relating to =" or "All Lines = " */
    uchar8 ucLineId; /*!< Line Id */
    int16 nEntryId;/*!< Entry Identifier */
} x_IFX_DECT_LAU_ContactListEntry; 

/*!
    \brief Structure describing the Contact list.
*/
typedef struct
{
    uint16 unNoOfEntries; /*!< Number of entries */
    x_IFX_DECT_LAU_ContactListEntry axContactList[IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES]; /*!< Contact list */
} x_IFX_DECT_LAU_ContactList;

/*!
    \brief Structure describing the Contact list Entry.
*/
typedef struct
{
  uint32 uiEditField; /*!< Edit options */
	char8 acTermIdNum[IFX_DECT_LAU_MAX_NUMBER_LEN]; /*!< Terminal Id Number */
	 uchar8 acName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< Internal Name */
	 uchar8 ucOwn;/*!< If Own number set to 0x20 else to 0x00 */
   int16 nEntryId;/*!< Entry Identifier */
   uchar8 ucCallIntercept; /*!< Call Intercept option */
} x_IFX_DECT_LAU_IntNameListEntry;

/*!
    \brief Structure describing the Internal Names list.
*/
typedef struct
{
    char8 cNoOfEntries; /*!< Number of entries */
    x_IFX_DECT_LAU_IntNameListEntry axIntNameList[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES]; /*!< Internal Names list */
} x_IFX_DECT_LAU_IntNameList; 
 
/*****************************************************************************
 * Data Structures for DECT System Setting List
 ******************************************************************************/
 
/*****************************************************************************
 * Field Identifiers for System Setting List
 ******************************************************************************/
/*! \def IFX_DECT_LAU_SYS_SET_LIST_PIN
    \brief Macro that defines the "PIN Code" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_PIN           0x01  /*!< System Settings List: PIN Code */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_CLOCK_MASTER
    \brief Macro that defines the "Clock Master" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_CLOCK_MASTER  0x02  /*!< System Settings List: Clock Master */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_BASE_RESET
    \brief Macro that defines the "Base Reset" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_BASE_RESET    0x03  /*!< System Settings List: Base Reset */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_IPADD_TYPE
    \brief Macro that defines the "IP Address type" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_IPADD_TYPE    0x04  /*!< System Settings List: IP Address type */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_IPADD_VALUE
    \brief Macro that defines the "IP Address value" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_IPADD_VALUE   0x05  /*!< System Settings List: IP Address value */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_IPADD_SUBNET
    \brief Macro that defines the "IP Address subnet" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_IPADD_SUBNET  0x06  /*!< System Settings List: IP Address subnet */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_IPADD_GW
    \brief Macro that defines the "IP Address gateway" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_IPADD_GW      0x07  /*!< System Settings List: IP Address gateway */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_IPADD_DNS
    \brief Macro that defines the "IP Address dns" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_IPADD_DNS     0x08  /*!< System Settings List: IP Address dns */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_FW_VER
    \brief Macro that defines the "Firmware Version" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_FW_VER        0x09  /*!< System Settings List: Firmware Version */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_EE_VER
    \brief Macro that defines the "EEPROM Version" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_EE_VER        0x0A  /*!< System Settings List: EEPROM Version */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_HW_VER
    \brief Macro that defines the "Hardware Version" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_HW_VER        0x0B  /*!< System Settings List: Hardware Version */

/*! \def IFX_DECT_LAU_SYS_SET_LIST_EMISSION_MODE
    \brief Macro that defines the "Emission Mode" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_EMISSION_MODE        0x0C  /*!< System Settings List: Emission Mode */
/*! \def IFX_DECT_LAU_SYS_SET_LIST_NEW_PIN
    \brief Macro that defines the "New PIN Code" Field identifier within the System Settings list.
 */
#define IFX_DECT_LAU_SYS_SET_LIST_NEW_PIN        0x0D  /*!< System Settings List: New PIN Code */
/*****************************************************************************
 * Other Definitions
 ******************************************************************************/

/*! \def IFX_DECT_LAU_MAX_PIN_LEN
    \brief Macro that defines the maximum length of a PIN.
 */
#define IFX_DECT_LAU_MAX_PIN_LEN            9  /*!< Maximum length of PIN */

/*! \def IFX_DECT_LAU_MAX_VERSION_LEN
    \brief Macro that defines the maximum length of Version Information.
 */
#define IFX_DECT_LAU_MAX_VERSION_LEN        128  /*!< Maximum length of Version Information */
/*! \def IFX_DECT_LAU_CLOCK_MASTER_FP
    \brief Macro that defines the FP as the clock master.
 */
#define IFX_DECT_LAU_CLOCK_MASTER_FP        0x30  /*!< Clock master is FP */
 
/*! \def IFX_DECT_LAU_CLOCK_MASTER_PP
    \brief Macro that defines the PP as the clock master.
 */
#define IFX_DECT_LAU_CLOCK_MASTER_PP        0x31  /*!< Clock master is PP */ 

/*! \def IFX_DECT_LAU_BASE_RESET_NO
    \brief Macro that defines no resetting of the base from PP.
 */
#define IFX_DECT_LAU_BASE_RESET_NO          0x30  /*!< No Reset Base from PP */

/*! \def IFX_DECT_LAU_BASE_RESET_YES
    \brief Macro that defines the resetting of the base from PP.
 */
#define IFX_DECT_LAU_BASE_RESET_YES         0x31  /*!< Reset Base from PP */

/*! \def IFX_DECT_LAU_FP_ADD_CFG_DHCP
    \brief Macro that defines that the IP Address of the FP is obtained using DHCP.
 */
#define IFX_DECT_LAU_FP_ADD_CFG_DHCP       1  /*!< FP IP Address is obtained through DHCP */

/*! \def IFX_DECT_LAU_FP_ADD_CFG_STATIC
    \brief Macro that defines that the IP Address of the FP is obtained using Static configuration.
 */
#define IFX_DECT_LAU_FP_ADD_CFG_STATIC     2  /*!< FP IP Address is obtained through Static Config */

/*! \def IFX_DECT_LAU_FP_ADD_TYPE_IPV4
    \brief Macro that defines that the IP Address type of the FP is IPv4.
 */
#define IFX_DECT_LAU_FP_ADD_TYPE_IPV4      1  /*!< FP IP Address type is IPv4 */

/*! \def IFX_DECT_LAU_FP_ADD_TYPE_IPV6
    \brief Macro that defines that the IP Address type of the FP is IPv6.
 */
#define IFX_DECT_LAU_FP_ADD_TYPE_IPV6      2  /*!< FP IP Address type is IPv6 */

/*! \def IFX_DECT_LAU_IP_ADD_IPV4_LEN
    \brief Macro that defines that the IPv4 Address length.
 */
#define IFX_DECT_LAU_IP_ADD_IPV4_LEN       15  /*!< IPv4 address length */

/*! \def IFX_DECT_LAU_IP_ADD_IPV6_LEN
    \brief Macro that defines that the IPv6 Address length.
 */
#define IFX_DECT_LAU_IP_ADD_IPV6_LEN       32  /*!< IPv6 address length */

/*!
    \brief Union describing the IPv4 and IPv6 addresses.
*/
typedef union
{
    char8 cIPv4Address[IFX_DECT_LAU_IP_ADD_IPV4_LEN]; /*!< IPv4 Address */
    char8 cIPv6Address[IFX_DECT_LAU_IP_ADD_IPV6_LEN]; /*!< IPv6 Address */
} ux_IFX_DECT_LAU_IP_Address;

/*!
    \brief Structure describing the IPv4 and IPv6 addresses.
*/
typedef struct
{
    char8 cIPAddType; /*!< IP Address type, v4 or v6, one of IFX_DECT_LAU_FP_ADD_TYPE_* */
    ux_IFX_DECT_LAU_IP_Address uxIPAddress; /*!< Union of v4 and v6 IP address */
} x_IFX_DECT_LAU_IP_Address;

/* 
      Subnet mask, GW IP Address and DNS server have the
      same structure as the IP Address.  Since the doxygen
      stylesheet gives some problems while generating framemaker
      documentation, we have defined them as independent
      structures
*/      

/*!
    \brief Structure describing the Subnet mask.
*/
typedef struct
{
    char8 cIPAddType; /*!< IP Address type, v4 or v6, one of IFX_DECT_LAU_FP_ADD_TYPE_* */
    ux_IFX_DECT_LAU_IP_Address uxIPAddress; /*!< Union of v4 and v6 IP address */
} x_IFX_DECT_LAU_SubnetMask;

/*!
    \brief Structure describing the Gateway IP Address.
*/
typedef struct
{
    char8 cIPAddType; /*!< IP Address type, v4 or v6, one of IFX_DECT_LAU_FP_ADD_TYPE_* */
    ux_IFX_DECT_LAU_IP_Address uxIPAddress; /*!< Union of v4 and v6 IP address */
} x_IFX_DECT_LAU_GwAddress;

/*!
    \brief Structure describing the DNS Server.
*/
typedef struct
{
    char8 cIPAddType; /*!< IP Address type, v4 or v6, one of IFX_DECT_LAU_FP_ADD_TYPE_* */
    ux_IFX_DECT_LAU_IP_Address uxIPAddress; /*!< Union of v4 and v6 IP address */
} x_IFX_DECT_LAU_DNSServer;

/*! \def IFX_DECT_LAU_SSE_PIN
    \brief Macro that defines the System PIN.
 */
#define IFX_DECT_LAU_SSE_PIN           0x0001 /*!< System PIN */

/*! \def IFX_DECT_LAU_SSE_CLKMSTR
    \brief Macro that defines the Clock Master.
 */
#define IFX_DECT_LAU_SSE_CLKMSTR       0x0002 /*!< Clock Master */

/*! \def IFX_DECT_LAU_SSE_BASERESET
    \brief Macro that defines the Base Reset Option.
 */
#define IFX_DECT_LAU_SSE_BASERESET     0x0004 /*!< Base Reset Option */

/*! \def IFX_DECT_LAU_SSE_BASEIPCFG
    \brief Macro that defines the Base IP Address Configuration
 */
#define IFX_DECT_LAU_SSE_BASEIPCFG     0x0008 /*!< Base IP Address Configuration */

/*! \def IFX_DECT_LAU_SSE_BASEIP
    \brief Macro that defines the Base IP Address.
 */
#define IFX_DECT_LAU_SSE_BASEIP        0x0010 /*!< Base IP Address */

/*! \def IFX_DECT_LAU_SSE_BASESUBNET
    \brief Macro that defines the Base Subnet Address.
 */
#define IFX_DECT_LAU_SSE_BASESUBNET    0x0020 /*!< Base Subnet Address */

/*! \def IFX_DECT_LAU_SSE_BASEGW
    \brief Macro that defines the Base Gateway Address.
 */
#define IFX_DECT_LAU_SSE_BASEGW        0x0040 /*!< Base Gateway Address */

/*! \def IFX_DECT_LAU_SSE_BASEDNS
    \brief Macro that defines the Base DNS Address.
 */
#define IFX_DECT_LAU_SSE_BASEDNS       0x0080 /*!< Base DNS Address */

/*! \def IFX_DECT_LAU_SSE_BASEFWVER
    \brief Macro that defines the Base Firmware Version.
 */
#define IFX_DECT_LAU_SSE_BASEFWVER     0x0100 /*!< Base Firmware Version */

/*! \def IFX_DECT_LAU_SSE_BASEEPROMVER
    \brief Macro that defines the Base EEPROM Version.
 */
#define IFX_DECT_LAU_SSE_BASEEPROMVER  0x0200 /*!< Base EEPROM Version */

/*! \def IFX_DECT_LAU_SSE_BASEHWVER
    \brief Macro that defines the Base Hardware Version.
 */
#define IFX_DECT_LAU_SSE_BASEHWVER     0x0400 /*!< Base Hardware Version */

/*! \def IFX_DECT_LAU_SSE_NEWPIN
    \brief Macro that defines the New Base Pin
 */
#define IFX_DECT_LAU_SSE_NEWPIN     0x1000 /*!< New Base Pin */

/*! \def IFX_DECT_LAU_SSE_NEM
    \brief Macro that defines the Emission Mode.
 */
#define IFX_DECT_LAU_SSE_NEM    0x0800 /*!< Emission Mode */
/*! \def IFX_DECT_LAU_SSE_PIN
    \brief Macro that defines the System PIN.
 */
#define IFX_DECT_LAU_SSE_PIN_PIN           0x00010000 /*!< System PIN */

/*! \def IFX_DECT_LAU_SSE_CLKMSTR
    \brief Macro that defines the Clock Master.
 */
#define IFX_DECT_LAU_SSE_CLKMSTR_PIN       0x00020000 /*!< Clock Master */

/*! \def IFX_DECT_LAU_SSE_BASERESET
    \brief Macro that defines the Base Reset Option.
 */
#define IFX_DECT_LAU_SSE_BASERESET_PIN     0x00040000 /*!< Base Reset Option */

/*! \def IFX_DECT_LAU_SSE_BASEIPCFG
    \brief Macro that defines the Base IP Address Configuration
 */
#define IFX_DECT_LAU_SSE_BASEIPCFG_PIN     0x00080000 /*!< Base IP Address Configuration */

/*! \def IFX_DECT_LAU_SSE_BASEIP
    \brief Macro that defines the Base IP Address.
 */
#define IFX_DECT_LAU_SSE_BASEIP_PIN        0x00100000 /*!< Base IP Address */

/*! \def IFX_DECT_LAU_SSE_BASESUBNET
    \brief Macro that defines the Base Subnet Address.
 */
#define IFX_DECT_LAU_SSE_BASESUBNET_PIN    0x00200000 /*!< Base Subnet Address */

/*! \def IFX_DECT_LAU_SSE_BASEGW
    \brief Macro that defines the Base Gateway Address.
 */
#define IFX_DECT_LAU_SSE_BASEGW_PIN        0x00400000 /*!< Base Gateway Address */

/*! \def IFX_DECT_LAU_SSE_BASEDNS
    \brief Macro that defines the Base DNS Address.
 */
#define IFX_DECT_LAU_SSE_BASEDNS_PIN       0x00800000 /*!< Base DNS Address */

/*! \def IFX_DECT_LAU_SSE_BASEFWVER
    \brief Macro that defines the Base Firmware Version.
 */
#define IFX_DECT_LAU_SSE_BASEFWVER_PIN     0x01000000 /*!< Base Firmware Version */

/*! \def IFX_DECT_LAU_SSE_BASEEPROMVER
    \brief Macro that defines the Base EEPROM Version.
 */
#define IFX_DECT_LAU_SSE_BASEEPROMVER_PIN  0x02000000 /*!< Base EEPROM Version */

/*! \def IFX_DECT_LAU_SSE_BASEHWVER
    \brief Macro that defines the Base Hardware Version.
 */
#define IFX_DECT_LAU_SSE_BASEHWVER_PIN     0x04000000 /*!< Base Hardware Version */
/*! \def IFX_DECT_LAU_SSE_NEWPIN
    \brief Macro that defines the New Base Pin
 */
#define IFX_DECT_LAU_SSE_NEWPIN_PIN     0x10000000 /*!< New Base Pin */

/*! \def IFX_DECT_LAU_SSE_NEM
    \brief Macro that defines the Emission Mode.
 */
#define IFX_DECT_LAU_SSE_NEM_PIN    0x08000000 /*!< Emission Mode */
/*!
    \brief Structure describing the System Settings list.
*/
typedef struct
{
    uint32 uiEditField;/*!< Mark Editable fiels in the list */
    char8 acPIN[IFX_DECT_LAU_MAX_PIN_LEN]; /*!< PIN code */
    char8 cClockMaster; /*!< Clock master, one of IFX_DECT_LAU_CLOCK_MASTER_* */
    char8 cBaseReset; /*!< Base Reset, one of IFX_DECT_LAU_BASE_RESET_ */
    char8 cBaseIPAddCfg; /*!< IP Address Configuration, one of IFX_DECT_LAU_FP_ADD_CFG_* */
    x_IFX_DECT_LAU_IP_Address xBaseIPAdd; /*!< IP Address of the FP */
    x_IFX_DECT_LAU_SubnetMask xBaseSubnetMask; /*!< Subnet mask of the FP */
    x_IFX_DECT_LAU_GwAddress  xBaseGwIPAdd; /*!< Gateway address of the FP */
    x_IFX_DECT_LAU_DNSServer  xBaseDNSServerAdd; /*!< DNS Server address of the FP */
    char8 acBaseFwVersion[IFX_DECT_LAU_MAX_VERSION_LEN]; /*!< Base Firmware Version */
    char8 acBaseEepromVersion[IFX_DECT_LAU_MAX_VERSION_LEN]; /*!< Base Eeprom Version */
    char8 acBaseHwVersion[IFX_DECT_LAU_MAX_VERSION_LEN]; /*!< Base Hardware Version */
    char8 acNewPIN[IFX_DECT_LAU_MAX_PIN_LEN]; /*!< New Base PIN */
    char8 cEmissionMode; /*!< No Emission Mode */

} x_IFX_DECT_LAU_SystemSettingsList;

/*****************************************************************************
 * Data Structures for Line Setting List
 ******************************************************************************/

/*****************************************************************************
 * Field Identifiers for Line Setting List
 ******************************************************************************/
/*! \def IFX_DECT_LAU_LINE_SET_LIST_LINE_NAME
    \brief Macro that defines the "Line Name" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_LINE_NAME     0x01  /*!< Line Settings List: Line Name */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_LINE_ID
    \brief Macro that defines the "Line Id" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_LINE_ID       0x02  /*!< Line Settings List: Line Id */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_ATTACH_PP
    \brief Macro that defines the "Attached Handsets" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_ATTACH_PP     0x03  /*!< Line Settings List: Attached Handsets */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_DIAL_PREFIX
    \brief Macro that defines the "Dialing Prefix" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_DIAL_PREFIX   0x04  /*!< Line Settings List: Dialing Prefix */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_MELODY
    \brief Macro that defines the "Melody" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_MELODY        0x05  /*!< Line Settings List: Melody */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_VOLUME
    \brief Macro that defines the "Volume" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_VOLUME        0x06  /*!< Line Settings List: Volume */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_BLOCK_NUM
    \brief Macro that defines the "Blocked Number" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_BLOCK_NUM     0x07  /*!< Line Settings List: Blocked Number */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_CALL_MODE
    \brief Macro that defines the "Call Mode" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_CALL_MODE     0x08  /*!< Line Settings List: Call Mode */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_CALL_INTRU
    \brief Macro that defines the "Call Intrusion" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_CALL_INTRU    0x09  /*!< Line Settings List: Call Intrusion */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_PERM_CLIR
    \brief Macro that defines the "Permanent CLIR" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_PERM_CLIR     0x0A  /*!< Line Settings List: Permanent CLIR */

/*! \def IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_U
    \brief Macro that defines the "Call Forward Unconditional" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_U      0x0B  /*!< Line Settings List: Call Forward Unconditional*/
/*! \def IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N
    \brief Macro that defines the "Call Forward No answer" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N      0x0C  /*!< Line Settings List: Call Forward No Answer*/
/*! \def IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_B
    \brief Macro that defines the "Call Forward Busy" Field identifier within the Line Settings list.
 */
#define IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_B      0x0D  /*!< Line Settings List: Call Forward Busy*/
/*****************************************************************************
 * Other structures
 ******************************************************************************/
/*! \def IFX_DECT_LAU_HANDSET_1
    \brief Macro that defines the Handset  1.
 */
#define IFX_DECT_LAU_HANDSET_1        1  /*!< Handset No. 1 */ 

/*! \def IFX_DECT_LAU_MAX_LINES
    \brief Macro that defines the maximum lines.
 */
#define IFX_DECT_LAU_MAX_LINES 10 /*!< Max Lines*/

/*! \def IFX_DECT_LAU_HANDSET_2
    \brief Macro that defines the Handset 2.
 */
#define IFX_DECT_LAU_HANDSET_2        2  /*!< Handset No. 2 */ 

/*! \def IFX_DECT_LAU_HANDSET_3
    \brief Macro that defines the Handset  3.
 */
#define IFX_DECT_LAU_HANDSET_3        3  /*!< Handset No. 3 */ 

/*! \def IFX_DECT_LAU_HANDSET_4
    \brief Macro that defines the Handset  4.
 */
#define IFX_DECT_LAU_HANDSET_4        4  /*!< Handset No. 4 */ 

/*! \def IFX_DECT_LAU_HANDSET_5
    \brief Macro that defines the Handset  5.
 */
#define IFX_DECT_LAU_HANDSET_5        5  /*!< Handset No. 5 */ 

/*! \def IFX_DECT_LAU_HANDSET_6
    \brief Macro that defines the Handset  6.
 */
#define IFX_DECT_LAU_HANDSET_6        6  /*!< Handset No. 6 */ 
  
/*! \def IFX_DECT_LAU_MAX_ATTACHED_PP
    \brief Macro that defines the maximum number of attached handsets.
 */
#define IFX_DECT_LAU_MAX_ATTACHED_PP        6  /*!< Maximum attached handsets */ 

/*! \def IFX_DECT_LAU_MAX_BLOCKED_NUMBERS
    \brief Macro that defines the maximum telphone numbers that can be blocked.
 */
#define IFX_DECT_LAU_MAX_BLOCKED_NUMBERS 10

/*! \def IFX_DECT_LAU_MAX_BLOCKED_LIST_SIZE
    \brief Macro that defines the maximum number of the blocked number list.
 */
#define IFX_DECT_LAU_MAX_BLOCKED_LIST_SIZE  6  /*!< Maximum size of the blocked number list */ 
 
/*! \def IFX_DECT_LAU_CALL_MODE_SINGLE
    \brief Macro that defines the Single Call Mode.
 */
#define IFX_DECT_LAU_CALL_MODE_SINGLE       0x30  /*!< Single Call Mode */  

/*! \def IFX_DECT_LAU_CALL_MODE_MULTIPLE
    \brief Macro that defines the Multiple Call Mode.
 */
#define IFX_DECT_LAU_CALL_MODE_MULTIPLE     0x31  /*!< Multiple Call Mode */  

/*! \def IFX_DECT_LAU_CALL_INTRUSION_BLOCK
    \brief Macro that defines the value for blocking Call Intrusion.
 */
#define IFX_DECT_LAU_CALL_INTRUSION_BLOCK   0x30  /*!< Block Call Intrusion */  

/*! \def IFX_DECT_LAU_CALL_INTRUSION_ALLOW
    \brief Macro that defines the value for allowing Call Intrusion.
 */
#define IFX_DECT_LAU_CALL_INTRUSION_ALLOW   0x31  /*!< Allow Call Intrusion */  

/*! \def IFX_DECT_LAU_CLIR_DEACTIVATE
    \brief Macro that defines the deactivation value for caller id restriction.
 */
#define IFX_DECT_LAU_CLIR_DEACTIVATE        0x30  /*!< Deactivate Caller ID Restriction */  

/*! \def IFX_DECT_LAU_CLIR_ACTIVATE
    \brief Macro that defines the activation value for caller id restriction.
 */
#define IFX_DECT_LAU_CLIR_ACTIVATE          0x31  /*!< Activate Caller ID Restriction */  

/*! \def IFX_DECT_LAU_FEAT_CODE_LEN
    \brief Macro that defines the code length for the CLIR .
 */
#define IFX_DECT_LAU_FEAT_CODE_LEN          6  /*!< Maximum Feature Code Length */  

/*! \def IFX_DECT_LAU_CF_ON
    \brief Macro that defines Call Forward Status.
 */
#define IFX_DECT_LAU_CF_ON   0x31 /*!< Call Forward ON */
/*! \def IFX_DECT_LAU_CF_OFF
    \brief Macro that defines Call Forward status.
 */
#define IFX_DECT_LAU_CF_OFF     0x30 /*!< Call Forward OFF */

/*!
    \brief Structure describing the attached handsets.
*/
typedef struct
{
    char8 cNoOfPP; /*!< Number of attached PP's */
    char8 acAttachedPP[IFX_DECT_LAU_MAX_ATTACHED_PP]; /*!< Number of each attached PP's */
} x_IFX_DECT_LAU_AttachedPP;

/*!
    \brief Structure describing the blocked numbers.
*/
typedef struct
{
    uchar8 ucNoOfNumbers; /*!< Number of blocked numbers */
    char8 acNumList[IFX_DECT_LAU_MAX_BLOCKED_NUMBERS][IFX_DECT_LAU_MAX_BLOCKED_LIST_SIZE]; /*!< Number List */
} x_IFX_DECT_LAU_BlockedNumberList;

/*!
    \brief Structure describing the CLIR information.
*/
typedef struct
{
    uchar8 ucCLIRStatus; /*!< Activated or Deactivated, one of  IFX_DECT_LAU_CLIR_* */
    uchar8 ucCLIRCode[IFX_DECT_LAU_FEAT_CODE_LEN]; /*!< CLIR Code, 0-9, *, #, ENQ and NACK */
	uchar8 ucCLIRDeactCode[IFX_DECT_LAU_FEAT_CODE_LEN]; /*!< CLIR Deactivation code */
} x_IFX_DECT_LAU_CLIRInfo;

/*!
    \brief Structure describing the Call Forward information.
*/
typedef struct
{
 uchar8 ucNoOfSec;  /*!< Call forward wait for number of seconds*/
 uchar8 ucStatus;  /*!< Call forward ON/OFF*/
 uchar8 acCFAct[IFX_DECT_LAU_FEAT_CODE_LEN]; /*!< CF Activation code */
 uchar8 acCFDeAct[IFX_DECT_LAU_FEAT_CODE_LEN]; /*!< CF DeActivation code */
 uchar8 ucCFNum[IFX_DECT_LAU_MAX_NUMBER_LEN]; /*!< CF Target number */
} x_IFX_DECT_LAU_CFInfo;

/*! \def IFX_DECT_LAU_LSE_LINENAME
    \brief Macro that defines the IFX_DECT_LAU_LSE_LINENAME.
 */
#define IFX_DECT_LAU_LSE_LINENAME   0x0001 /*!< List Name */

/*! \def IFX_DECT_LAU_LSE_LINEID
    \brief Macro that defines the IFX_DECT_LAU_LSE_LINEID.
 */
#define IFX_DECT_LAU_LSE_LINEID     0x0002 /*!< Line Identifier */

/*! \def IFX_DECT_LAU_LSE_ASCMEL
    \brief Macro that defines the IFX_DECT_LAU_LSE_ASCMEL.
 */
#define IFX_DECT_LAU_LSE_ASCMEL     0x0010 /*!< Associated Melody  */

/*! \def IFX_DECT_LAU_LSE_ATCHPP
    \brief Macro that defines the IFX_DECT_LAU_LSE_ATCHPP.
 */
#define IFX_DECT_LAU_LSE_ATCHPP     0x0004 /*!< Attached PP */

/*! \def IFX_DECT_LAU_LSE_DIALPREFIX
    \brief Macro that defines the IFX_DECT_LAU_LSE_DIALPREFIX.
 */
#define IFX_DECT_LAU_LSE_DIALPREFIX 0x0008 /*!< Dial Prefix */

/*! \def IFX_DECT_LAU_LSE_VOL
    \brief Macro that defines the IFX_DECT_LAU_LSE_VOL.
 */
#define IFX_DECT_LAU_LSE_VOL        0x0020 /*!< Volume */

/*! \def IFX_DECT_LAU_LSE_BLOCKNUM
    \brief Macro that defines the IFX_DECT_LAU_LSE_BLOCKNUM.
 */
#define IFX_DECT_LAU_LSE_BLOCKNUM   0x0040 /*!< Blocked Number */

/*! \def IFX_DECT_LAU_LSE_CALLMODE
    \brief Macro that defines the IFX_DECT_LAU_LSE_CALLMODE.
 */
#define IFX_DECT_LAU_LSE_CALLMODE   0x0080 /*!< Call Mode */

/*! \def IFX_DECT_LAU_LSE_INTR
    \brief Macro that defines the IFX_DECT_LAU_LSE_INTR.
 */
#define IFX_DECT_LAU_LSE_INTR       0x0100 /*!< Call Intrusion */

/*! \def IFX_DECT_LAU_LSE_CLIR
    \brief Macro that defines the IFX_DECT_LAU_LSE_CLIR.
 */
#define IFX_DECT_LAU_LSE_CLIR       0x0200 /*!< CLIR */

/*! \def IFX_DECT_LAU_LSE_CFU
    \brief Macro that defines the IFX_DECT_LAU_LSE_CFU.
 */
#define IFX_DECT_LAU_LSE_CFU       0x0400 /*!< Call forward Unconditional*/

/*! \def IFX_DECT_LAU_LSE_CFN
    \brief Macro that defines the IFX_DECT_LAU_LSE_CFN.
 */
#define IFX_DECT_LAU_LSE_CFN			0x0800 /*!< Call forward NoAnswer*/

/*! \def IFX_DECT_LAU_LSE_CFB
    \brief Macro that defines the IFX_DECT_LAU_LSE_CFB.
 */
#define IFX_DECT_LAU_LSE_CFB			0x1000 /*!< Call forward Busy*/


/*! \def IFX_DECT_LAU_LSE_LINENAME
    \brief Macro that defines the IFX_DECT_LAU_LSE_LINENAME.
 */
/*! \def IFX_DECT_LAU_LSE_LINENAME*/
#define IFX_DECT_LAU_LSE_LINENAME_PIN   0x00010000 /*!< List Name */

/*! \def IFX_DECT_LAU_LSE_LINEID
    \brief Macro that defines the IFX_DECT_LAU_LSE_LINEID.
 */
#define IFX_DECT_LAU_LSE_LINEID_PIN     0x00020000 /*!< Line Identifier */

/*! \def IFX_DECT_LAU_LSE_ASCMEL
    \brief Macro that defines the IFX_DECT_LAU_LSE_ASCMEL.
 */
#define IFX_DECT_LAU_LSE_ASCMEL_PIN     0x00100000 /*!< Associated Melody  */

/*! \def IFX_DECT_LAU_LSE_ATCHPP
    \brief Macro that defines the IFX_DECT_LAU_LSE_ATCHPP.
 */
#define IFX_DECT_LAU_LSE_ATCHPP_PIN     0x00040000 /*!< Attached PP */

/*! \def IFX_DECT_LAU_LSE_DIALPREFIX
    \brief Macro that defines the IFX_DECT_LAU_LSE_DIALPREFIX.
 */
#define IFX_DECT_LAU_LSE_DIALPREFIX_PIN	 0x00080000 /*!< Dial Prefix */

/*! \def IFX_DECT_LAU_LSE_VOL
    \brief Macro that defines the IFX_DECT_LAU_LSE_VOL.
 */
#define IFX_DECT_LAU_LSE_VOL_PIN        0x00200000 /*!< Volume */

/*! \def IFX_DECT_LAU_LSE_BLOCKNUM
    \brief Macro that defines the IFX_DECT_LAU_LSE_BLOCKNUM.
 */
#define IFX_DECT_LAU_LSE_BLOCKNUM_PIN   0x00400000 /*!< Blocked Number */

/*! \def IFX_DECT_LAU_LSE_CALLMODE
    \brief Macro that defines the IFX_DECT_LAU_LSE_CALLMODE.
 */
#define IFX_DECT_LAU_LSE_CALLMODE_PIN   0x00800000 /*!< Call Mode */

/*! \def IFX_DECT_LAU_LSE_INTR
    \brief Macro that defines the IFX_DECT_LAU_LSE_INTR.
 */
#define IFX_DECT_LAU_LSE_INTR_PIN       0x01000000 /*!< Call Intrusion */

/*! \def IFX_DECT_LAU_LSE_CLIR
    \brief Macro that defines the IFX_DECT_LAU_LSE_CLIR.
 */
#define IFX_DECT_LAU_LSE_CLIR_PIN       0x02000000 /*!< CLIR */

/*! \def IFX_DECT_LAU_LSE_CFU_PIN
    \brief Macro that defines the IFX_DECT_LAU_LSE_CFU_PIN.
 */
#define IFX_DECT_LAU_LSE_CFU_PIN       0x04000000 /*!< Call forward Unconditional*/
/*! \def IFX_DECT_LAU_LSE_CFB_PIN
    \brief Macro that defines the IFX_DECT_LAU_LSE_CFB_PIN.
 */
#define IFX_DECT_LAU_LSE_CFB_PIN      0x08000000 /*!< Call forward Busy*/

/*! \def IFX_DECT_LAU_LSE_CFN_PIN
    \brief Macro that defines the IFX_DECT_LAU_LSE_CFN_PIN.
 */
#define IFX_DECT_LAU_LSE_CFN_PIN      0x10000000 /*!< Call forward NoAnswer*/
/*!
    \brief Structure describing the Line Settings list entry.
*/

typedef struct
{
    uint32 uiEditField;/*!< Mark Editable fiels in the list */
	int16 nEntryId;/*!< Entry Identifier */
	char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]; /*!< Line Name */
    uchar8 ucLineId; /*!< Line Id */
    uchar8 ucAssocMelody; /*!< Associated Melody */    
    x_IFX_DECT_LAU_AttachedPP xAttachedPP; /*!< Attached handsets */
    uchar8 ucDialPrefix; /*!< Dial Prefix */
    uchar8 ucVolume; /*!< Volume, in the range 0x30 to 0x39*/
    x_IFX_DECT_LAU_BlockedNumberList xBlockNumList; /*!< Numbers in the blocked list */
    uchar8 ucCallMode; /*!< Call Mode, one of IFX_DECT_LAU_CALL_MODE_* */
	uchar8 ucCallIntrusion;/*!< Call Intrusion  */
    x_IFX_DECT_LAU_CLIRInfo xCLIRInfo; /*!< CLIR Information */
	  x_IFX_DECT_LAU_CFInfo xCFInfoU; /*!< Call Forward Unconditional */
	  x_IFX_DECT_LAU_CFInfo xCFInfoN; /*!< Call Forward No Answer */
    x_IFX_DECT_LAU_CFInfo xCFInfoB; /*!< Call Forward Busy */
	}x_IFX_DECT_LAU_LineSettingsEntry;
/*!
    \brief Structure describing the Line Settings list entry.
*/
typedef struct
{
	uchar8 ucNoOfLines;/*!< Max Lines*/
    x_IFX_DECT_LAU_LineSettingsEntry axLineEntry[IFX_DECT_LAU_MAX_LINES];/*!< Line Entry*/
} x_IFX_DECT_LAU_LineSettingsList;

 
/*****************************************************************************
 * Data Structures for List Access Functions
 ******************************************************************************/
/*! \enum e_IFX_DECT_LAU_ListId
    \brief Enum containing the List Identifiers.
*/
typedef enum
{
	IFX_DECT_LAU_SUPPORTED = 0, 		/*!< No List */
    IFX_DECT_LAU_MISSED_CALLS = 1, 		/*!< Missed Call List */
	IFX_DECT_LAU_OUTGOING_CALLS = 2, 	/*!< Outgoing Call List */
    IFX_DECT_LAU_INCOMING_ACCEPT_CALLS = 3, /*!< Incoming accepted Call List */
    IFX_DECT_LAU_ALL_CALLS = 4, 		/*!< All Calls List */
    IFX_DECT_LAU_CONTACTS = 5, 			/*!< Contacts List */
    IFX_DECT_LAU_INTERNAL_NAMES = 6, 	/*!< Internal names List */
    IFX_DECT_LAU_SYS_SETTINGS = 7, 		/*!< System Setting List */
    IFX_DECT_LAU_LINE_SETTINGS = 8, 	/*!< Line Setting List */
    IFX_DECT_LAU_ALL_INCOMING_CALLS = 9, /*!< All Incoming Calls List */
   	#ifdef LTQ_DT_SUPPORT
		IFX_DT_LAU_RSS_CHANNEL_LIST=128,/*!< ALL Rss Channel list */ 
   	IFX_DT_LAU_NET_PHONE_BOOK=131,/*!<ALL Email Account List */
   	IFX_DT_LAU_EMAIL_ACCOUNT_LIST=132,/*!<ALL Email Account List */
   	#endif
		//IFX_DECT_LAU_PROPRIETARY = 64 		/*!< Proprietary List */
} e_IFX_DECT_LAU_ListId;

/*! \def IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE
    \brief Macro that defines the maximum number of fields of a list that can be sent in a message.
 */
#define IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE           13  /*!< Maximum number of fields in a message */

/*****************************************************************************
 * Data Structures for List Access Protocol Primitives
 ******************************************************************************/
/*! \def IFX_DECT_LAU_CMD_SESS_START_REQ
    \brief Macro that defines the Start Session Request List Access Command.
 */
#define IFX_DECT_LAU_CMD_SESS_START_REQ           0x00  /*!< Start Session Request */

/*! \def IFX_DECT_LAU_CMD_SESS_START_CFM
    \brief Macro that defines the Start Session Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_SESS_START_CFM           0x01  /*!< Start Session Confirm */

/*! \def IFX_DECT_LAU_CMD_SESS_END_REQ
    \brief Macro that defines the End Session Request List Access Command.
 */
#define IFX_DECT_LAU_CMD_SESS_END_REQ             0x02  /*!< End Session Request */

/*! \def IFX_DECT_LAU_CMD_SESS_END_CFM
    \brief Macro that defines the End Session Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_SESS_END_CFM             0x03  /*!< End Session Confirm */

/*! \def IFX_DECT_LAU_CMD_FIELD_QUERY_REQ
    \brief Macro that defines the Query Field Request List Access Command.
 */
#define IFX_DECT_LAU_CMD_FIELD_QUERY_REQ          0x04  /*!< Query Field Request */

/*! \def IFX_DECT_LAU_CMD_FIELD_QUERY_CFM
    \brief Macro that defines the Query Field Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_FIELD_QUERY_CFM          0x05  /*!< Query Field Confirm */

/*! \def IFX_DECT_LAU_CMD_ENTRIES_READ_REQ
    \brief Macro that defines the Read Entries Request List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRIES_READ_REQ         0x06  /*!< Read Entries Request */

/*! \def IFX_DECT_LAU_CMD_ENTRIES_READ_CFM
    \brief Macro that defines the Read Entries Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRIES_READ_CFM         0x07  /*!< Read Entries Confirm */

/*! \def IFX_DECT_LAU_CMD_ENTRY_EDIT_REQ
    \brief Macro that defines the Edit Entry Request List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRY_EDIT_REQ           0x08  /*!< Edit Entry Request */

/*! \def IFX_DECT_LAU_CMD_ENTRY_EDIT_CFM
    \brief Macro that defines the Edit Entry Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRY_EDIT_CFM           0x09  /*!< Edit Entry Confirm */

/*! \def IFX_DECT_LAU_CMD_ENTRY_SAVE_REQ
    \brief Macro that defines the Save Entry Request List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRY_SAVE_REQ           0x0A  /*!< Save Entry Request */

/*! \def IFX_DECT_LAU_CMD_ENTRY_SAVE_CFM
    \brief Macro that defines the Save Entry Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRY_SAVE_CFM           0x0B  /*!< Save Entry Confirm */

/*! \def IFX_DECT_LAU_CMD_ENTRY_DELETE_REQ
    \brief Macro that defines the Delete Entry Request List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRY_DELETE_REQ         0x0C  /*!< Delete Entry Request */

/*! \def IFX_DECT_LAU_CMD_ENTRY_DELETE_CFM
    \brief Macro that defines the Delete Entry Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRY_DELETE_CFM         0x0D  /*!< Delete Entry Confirm */

/*! \def IFX_DECT_LAU_CMD_LIST_DELETE_REQ
    \brief Macro that defines the Delete List Request List Access Command.
 */
#define IFX_DECT_LAU_CMD_LIST_DELETE_REQ          0x0E  /*!< Delete List Request */

/*! \def IFX_DECT_LAU_CMD_LIST_DELETE_CFM
    \brief Macro that defines the Delete List Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_LIST_DELETE_CFM          0x0F  /*!< Delete List Confirm */

/*! \def IFX_DECT_LAU_CMD_ENTRIES_SEARCH_REQ
    \brief Macro that defines the Search Entries Request List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRIES_SEARCH_REQ       0x10  /*!< Search Entries Request */

/*! \def IFX_DECT_LAU_CMD_ENTRIES_SEARCH_CFM
    \brief Macro that defines the Search Entries Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_ENTRIES_SEARCH_CFM       0x11  /*!< Search Entries Confirm */

/*! \def IFX_DECT_LAU_CMD_NACK
    \brief Macro that defines the Negative Acknowledgement List Access Command.
 */
#define IFX_DECT_LAU_CMD_NACK                     0x12  /*!< Negative Acknowledgement */

/*! \def IFX_DECT_LAU_CMD_DATA_PKT
    \brief Macro that defines the Data Packet List Access Command.
 */
#define IFX_DECT_LAU_CMD_DATA_PKT                 0x13  /*!< Data Packet */

/*! \def IFX_DECT_LAU_CMD_DATA_PKT_LAST
    \brief Macro that defines the Data Packet Last List Access Command.
 */
#define IFX_DECT_LAU_CMD_DATA_PKT_LAST            0x14  /*!< Data Packet Last */

#ifdef LTQ_DT_SUPPORT
/*! \def IFX_DECT_LAU_CMD_SESS_MOVE_REQ
    \brief Macro that defines the Move Session List Access Command.
 */
#define IFX_DECT_LAU_CMD_SESS_MOVE_REQ             0x80  /*!< Proprietary */

/*! \def IFX_DECT_LAU_CMD_SESS_MOVE_CFM
    \brief Macro that defines the Move Session Confirm List Access Command.
 */
#define IFX_DECT_LAU_CMD_SESS_MOVE_CFM             0x81  /*!< Proprietary */
#endif

/*! \def IFX_DECT_LAU_CMD_PROPRIETARY
    \brief Macro that defines the Proprietary List Access Command.
 */
#define IFX_DECT_LAU_CMD_PROPRIETARY              0xFF  /*!< Proprietary */
 
 /*!
    \brief Structure describing the Start Session Request Command Parameters
*/
typedef struct
{
    e_IFX_DECT_LAU_ListId eListId;      /*!< List Identifier */
    uchar8 ucNoOfSortingFields;         /*!< Number of sorting fields */
    uchar8 aucSortingFields[IFX_DECT_LAU_MAX_SORTING_FIELDS]; /*!< Sorting fields list */
} x_IFX_DECT_LAU_SessionStartReq;
 
/*! \def IFX_DECT_LAU_SESS_START_REJ_REASON_NO_RESOURCES
    \brief Macro that defines the "No Resources" reject reason.
 */
#define IFX_DECT_LAU_SESS_START_REJ_REASON_NO_RESOURCES     0x00  /*!< No Resources */

/*! \def IFX_DECT_LAU_SESS_START_REJ_REASON_IN_USE
    \brief Macro that defines the "List already in use" reject reason.
 */
#define IFX_DECT_LAU_SESS_START_REJ_REASON_IN_USE           0x01  /*!< List already in use */

/*! \def IFX_DECT_LAU_SESS_START_REJ_REASON_NO_SUPPORT
    \brief Macro that defines the "List not supported" reject reason.
 */
#define IFX_DECT_LAU_SESS_START_REJ_REASON_NO_SUPPORT       0x02  /*!< List not supported */
 
/*! \def IFX_DECT_LAU_SESS_START_REJ_MAX_SESS_REACHED
    \brief Macro that defines the "Max Sessions Reached" reject reason.
 */
#define IFX_DECT_LAU_SESS_START_REJ_MAX_SESS_REACHED       0x03  /*!< Max Sessions reached */

/*!
    \brief Structure describing the Start Session Confirm Command Parameters
*/
typedef struct
{
    e_IFX_DECT_LAU_ListId eListId;      /*!< List Identifier */
    int16 nNoOfAvailEntries; /*!< Number of available entries in the list */
    uchar8 ucRejectReason; /*!< Reason for rejecting the start session request, one of IFX_DECT_LAU_SESS_START_REJ_REASON_* */
    uchar8 ucNoOfSortingFields;         /*!< Number of sorting fields */
    uchar8 aucSortingFields[IFX_DECT_LAU_MAX_SORTING_FIELDS]; /*!< Sorting fields list */
} x_IFX_DECT_LAU_SessionStartCfm; 

/*!
    \brief Structure describing the Query Fields Confirm Command Parameters
*/
typedef struct
{
    uchar8 ucNoOfEditableFields;        /*!< Number of editable fields */
    uchar8 aucEditableFields[IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE]; /*!< Editable fields list */
    uchar8 ucNoOfUneditableFields;        /*!< Number of Uneditable fields */
    uchar8 aucUneditableFields[IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE]; /*!< Uneditable fields list */
} x_IFX_DECT_LAU_FieldQueryCfm; 

/*! \def IFX_DECT_LAU_LIST_ORDER_ASC
    \brief Macro that defines the ascending order of a list of entries.
 */
#define IFX_DECT_LAU_LIST_ORDER_ASC     0x00  /*!< Ascending Order */

/*! \def IFX_DECT_LAU_LIST_ORDER_DES
    \brief Macro that defines the descending order of a list of entries.
 */
#define IFX_DECT_LAU_LIST_ORDER_DES     0x80  /*!< Descending Order */

/*!
    \brief Structure describing the Read Entries Request Command Parameters
*/
typedef struct
{
    int16 nStartIndex;        /*!< Start Index, 0 for the last entry */
    uchar8 ucNoOfReqFields;     /*!< Number of requested Entries */
    uchar8 ucOrder;             /*!< Ascending or Descending order, one of IFX_DECT_LAU_LIST_ORDER_* */ 
    uchar8 ucMarkEntriesReq;   /*!< 0x7F - Reset Read Status(Mark as Read),0xFF - Set Read Status(Mark as Unread),
                                    0x00 - Leave Read Status Unchanged. */  
    uchar8 aucFieldIdsList[IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE]; /*!< List of fields identifiers */
} x_IFX_DECT_LAU_EntryReadReq; 

/*!
    \brief Structure describing the Read Entries Confirm Command Parameters
*/
typedef struct
{
    int16 nStartIndex;        /*!< Start Index */
    uchar8 ucNoOfDeliveredEntries;/*!< Number of delivered entries */
} x_IFX_DECT_LAU_EntryReadCfm; 

/*!
    \brief Structure describing the Edit Entry Request Command Parameters
*/
typedef struct
{
    int16  nEntryId;        /*!< Entry Identifier */
	uchar8 ucNoOfReqFields;     /*!< Number of requested fields */
    uchar8 aucFieldIdsList[IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE]; /*!< List of fields identifiers */
} x_IFX_DECT_LAU_EntryEditReq; 

/*!
    \brief Structure describing the Save Entry Request Command Parameters
*/
typedef struct
{
    int16 nEntryId;        /*!< Entry Identifier */
} x_IFX_DECT_LAU_EntrySaveReq; 

/*!
    \brief Structure describing the Save Entry Confirm Command Parameters
*/
typedef struct
{
    int16 nEntryId;        /*!< Entry Identifier */
    int16 nPostionIndex;  /*!< Postion Index */
    int16 nAvailEntries; /*!< Total number of available entries */
} x_IFX_DECT_LAU_EntrySaveCfm; 

/*!
    \brief Structure describing the Delete Entry Request Command Parameters
*/
typedef struct
{
    int16 nEntryId;        /*!< Entry Identifier */
} x_IFX_DECT_LAU_EntryDeleteReq; 

/*!
    \brief Structure describing the Delete Entry Confirm Command Parameters
*/
typedef struct
{
    int16 nAvailEntries;  /*!< Total number of available entries */
} x_IFX_DECT_LAU_EntryDeleteCfm; 

/*!
    \brief Structure describing the Search Entries Request Command Parameters
*/
typedef struct
{
    uchar8 ucMatchingOption;        /*!< Number of Matching options */
    char8 cSearchValue[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< Search criterion */
    uchar8 ucNoOfReqFields;        /*!< Number of requested fields */
    uchar8 aucFieldIdsList[IFX_DECT_LAU_MAX_FIELDS_IN_MESSAGE]; /*!< List of fields identifiers */
	uint32 uiCounter; /*!< Number of entries requested*/
   uchar8 ucMarkEntriesReq; /*!< Flag to set/reset Read Status for all read entries*/
} x_IFX_DECT_LAU_EntrySearchReq; 

/*!
    \brief Structure describing the Search Entries Confirm Command Parameters
*/
typedef struct
{
    int16 nStartIndex ;      /*!< Start Index */
    uchar8 ucCounter;        /*!< Number of returned entries */
} x_IFX_DECT_LAU_EntrySearchCfm; 

/* No command parameters are required for the following list commands
 *  End Session Request
 *  End Session Confirm
 *  Query Fields Request
 *  Edit Entry Confirm 
 *  Delete List Request
 *  Delete List Confirm
  */

#ifdef LTQ_DT_SUPPORT
/*!
    \brief Structure describing the Start Session Confirm Command Parameters
*/
typedef struct
{
    int16 nSessionId;
    int16 nNoOfAvailEntries; /*!< Number of available entries in the list */
    uchar8 ucRejectReason; /*!< Reason for rejecting the move session request, one of IFX_DECT_LAU_SESS_MOVE_REJ_REASON_* */
    uchar8 ucNoOfSortingFields;         /*!< Number of sorting fields */
    uchar8 aucSortingFields[IFX_DECT_LAU_MAX_SORTING_FIELDS]; /*!< Sorting fields list */
}x_IFX_DECT_LAU_SessionMoveCfm;

 /*!
    \brief Structure describing the Move Session Request Command Parameters
*/
typedef struct
{
    int16 nSessionId;
    uint32 uiSubListId;      /*!< Entry Identifier to go to sublist, 0 to go to tree list */
    uchar8 ucNoOfSortingFields;         /*!< Number of sorting fields */
    uchar8 aucSortingFields[IFX_DECT_LAU_MAX_SORTING_FIELDS]; /*!< Sorting fields list */
}x_IFX_DECT_LAU_SessionMoveReq;
#endif
  

/*!
    \brief Structure describing the Proprietary Confirm Command Parameters
*/
typedef struct
{
    int16 nLen;
    uchar8 aucProprietaryData[IFX_DECT_LAU_MAX_SORTING_FIELDS]; /*!< Proprietary Data */
}x_IFX_DECT_LAU_ProprietaryCfm;

  
/*!
    \brief Union containing the List Parameters in requests/responses from/to PP
*/
typedef union
{
    x_IFX_DECT_LAU_SessionStartReq      xSessionStartReq; /*!< Start Session Request Parameters */
    x_IFX_DECT_LAU_SessionStartCfm      xSessionStartCfm; /*!< Start Session Confirm Parameters */
    x_IFX_DECT_LAU_FieldQueryCfm        xFieldQueryCfm;   /*!< Query Fields Confirm Parameters */
    x_IFX_DECT_LAU_EntryReadReq         xEntryReadReq;    /*!< Read Entry Request Parameters */
    x_IFX_DECT_LAU_EntryReadCfm         xEntryReadCfm;    /*!< Read Entry Confirm Parameters */
    x_IFX_DECT_LAU_EntryEditReq         xEntryEditReq;    /*!< Edit Entry Request Parameters */
    x_IFX_DECT_LAU_EntrySaveReq         xEntrySaveReq;    /*!< Save Entry Request Parameters */    
    x_IFX_DECT_LAU_EntrySaveCfm         xEntrySaveCfm;    /*!< Save Entry Confirm Parameters */
    x_IFX_DECT_LAU_EntryDeleteReq       xEntryDeleteReq;  /*!< Delete Entry Request Parameters */
    x_IFX_DECT_LAU_EntryDeleteCfm       xEntryDeleteCfm;  /*!< Delete Entry Confirm Parameters */
    x_IFX_DECT_LAU_EntrySearchReq       xEntrySearchReq;  /*!< Search Entry Request Parameters */
    x_IFX_DECT_LAU_EntrySearchCfm       xEntrySearchCfm;  /*!< Search Entry Confirm Parameters */
	#ifdef LTQ_DT_SUPPORT
		x_IFX_DECT_LAU_SessionMoveReq       xSessionMoveReq;  /*!< Move Session Request Parameters */
		x_IFX_DECT_LAU_SessionMoveCfm       xSessionMoveCfm; /*!< Move Session Confirm Parameters */
	#endif
	//x_IFX_DECT_LAU_ProprietaryCfm       xProprietaryCfm;  /*!< Search Entry Confirm Parameters */
} ux_IFX_DECT_LAU_ListCommands;

/*! \enum e_IFX_DECT_LAU_NackReason
    \brief Enum containing the reasons for rejecting a command.
*/
typedef enum
{
	IFX_DECT_LAU_NACK_REASON_INVALID_RANGE = 0, /*!< Invalid Range */
    IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE = 1, /*!< Entry not available */
	IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM = 2, /*!< Invalid Session Number */
    IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS = 3, /*!< Temporarily not possible */
    IFX_DECT_LAU_NACK_REASON_FORMAT_INCORRECT = 4, /*!< Entry format incorrect */
    IFX_DECT_LAU_NACK_REASON_INVALID_START_IDX= 5, /*!< Invalid Start Index */
    IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP = 6, /*!< Procedure not supported */
    IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW= 7, /*!< Procedure not allowed */
    IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT=8, /*!< Content not accepted */
    IFX_DECT_LAU_NACK_REASON_LIST_FULL     =  9, /*!< List full */
	IFX_DECT_LAU_NACK_REASON_PIN_INCORRECT = 10,/*!< Incorrect Pin*/
	IFX_DECT_LAU_NACK_REASON_PIN_REQUIRED = 11,/*!< PIN Required*/
} e_IFX_DECT_LAU_NackReason;

/*!
    \brief Structure containing the List Parameters in requests/responses from/to PP
*/
typedef struct
{
    uchar8 ucListCmd;   /*!< List Command, one of IFX_DECT_LAU_CMD_* */
    
    /* Common Fields */
    int16 nSessionId; /*!< Session Identifier */
    
    /* Command specific fields */
    ux_IFX_DECT_LAU_ListCommands uxListCmd; /*!< Command Parameters */
    
    /* Reasons for negative response */
    e_IFX_DECT_LAU_NackReason eNackReason; /*!< Reason for rejecting a command and sending NACK */
} x_IFX_DECT_LAU_ListCommands;

/* ****************************************************************************
 * Missed Call Event - Subtypes
 * ****************************************************************************/
/*! \def IFX_DECT_LAU_MISSED_CALL_SUB_TYPE_UNKNOWN
    \brief Macro that specifies the Unknown Sub type for the Missed Call Event.
 */
#define IFX_DECT_LAU_MISSED_CALL_SUB_TYPE_UNKNOWN    0 /*!< Unknown Sub type for the Missed Call Event */

/*! \def IFX_DECT_LAU_MISSED_CALL_SUB_TYPE_VOICE_CALL
    \brief Macro that specifies the Voice Call Sub type for the Missed Call Event.
 */
#define IFX_DECT_LAU_MISSED_CALL_SUB_TYPE_VOICE_CALL 1 /*!< Voice Call Sub type for the Missed Call Event */

/*****************************************************************************
 * Functions 
 ******************************************************************************/
/*! \brief  This function is used initialize the LAU with the set of
                   lists supported in the FT application.  If a list is not 
                   supported, the DECT TK itself send a negative response
                   to any query from PT seeking to setup a session for the
                   list.  This function also enables the DECT Stack at the FP
                   indicate it's list capabilities by setting the a36 bit.
        \param[in] puiLists Array containing the list identifiers for the lists 
                           supported by the DECT TK/FT application.
        \param [in] uiEMCVal EMC value to be used list confirmation responses
        \return IFX_SUCCESS / IFX_FAILURE
*/

e_IFX_Return IFX_DECT_LAU_Init(IN uint32 *puiLists,
                               IN uint32 uiEMCVal);

/*! \brief  This function is used terminate a list access session by the FT application.
        \param[in] nSessId Session Identifier for the session.  The Session Id is invalid
                           after the function executes.
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_LAU_SessionEnd(IN int16 nSessId);
									
/*! \brief  This function is used to send a response to a Save Entry Request by the FT application.
                   The Save Entry Request is different from other requests in that it has a
                   entry payload carried in a separate data packet.  Unlike the other requests,
                   the confirmation response cannot be automatically sent by the DECT TK.
                   Hence a separate function is provided to the FT application.  The FT application
                   shall process the received data packet, apply the changes and invoke this
                   function to send the save entry confirm response.
        \param[in] pxOutCmd List command parameters for the response
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_LAU_EntrySave(IN x_IFX_DECT_LAU_ListCommands *pxOutCmd);

/*! \brief  This function is used send a negative acknowledgement from the FT application.
        \param[in] nSessId Session Identifier for the session.  
        \param[in] eReason Reason for the negative acknowledgement
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_LAU_NackSend(IN int16 nSessId,
                                   IN e_IFX_DECT_LAU_NackReason eReason);
                                   


/*! \brief  This function is used send a data packet from the FT application.
        \param[in] nSessId Session Identifier for the session.  
        \param[in] unDataLen Length of the data buffer
        \param[in] pucData Data buffer obtained after encoding the list content
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_LAU_DataPktSend(IN int16 nSessId,
                                      IN uint16 unDataLen, 
                                      IN uchar8 *pucData);

/*! \brief  This function is used encode the payload part of the Data packet from the FT application.
                   This function needs to be called by the FT application to send a response to
                   a read entries request or a edit entry request or a search entries request.
                   The DECT TK manages the data packet classification, whether these
                   are intermediate packets or the last packet.
        \param[in] nSessId Used to encode based on the entry IDs requested
        \param[in] ucListCmdType Command Type of the data payload
        \param[in] pvPayloadStruct Pointer to the data payload in the structure form
        \param[out] punPayloadSize Pointer to the Size of the encoded data payload
        \param[out] pucDataPayload Encoded data payload
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_LAU_DataPktPayloadEncode(IN int16 nSessId,
                                               IN uchar8 ucListCmdType,
                                               IN void * pvPayloadStruct,
                                               OUT uint16 *punPayloadSize,
                                               OUT char8 *pucDataPayload);

/*! \brief  This function is used decode the payload part of the Data packet from the FT application.
                   This function needs to be called by the FT application to completely
                   decode the save entry request from the PT.
        \param[in] ucListCmdType Command Type of the data payload
        \param[out] pvPayloadStruct Pointer to the data payload in the structure form
        \param[in] unPayloadSize Size of the data payload
        \param[in] pucDataPayload Data payload
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_LAU_DataPktPayloadDecode(IN uchar8 ucListCmdType,
                                               OUT void * pvPayloadStruct,
                                               IN uint16 unPayloadSize,
                                               IN uchar8 *pucDataPayload);

/*! \brief  This function gets the associated session IDs given a Call Id.
        \param[in] ucHandsetId Handset Identifier   
        \param[in] ucCallId Call Identifier   
        \param[out] anSessId Associated seesion Identifiers
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return
IFX_DECT_LAU_AssocSessIdGet(IN uchar8 ucHandsetId,
                            IN uchar8 ucCallId,
                            OUT int16 anSessId[IFX_DECT_LAU_MAX_SESS_PER_HS]);
							
                                               
/* ****************************************************************************
 * List related Notification Functions
 * ****************************************************************************/
/*! \brief  This function is used to send a missed call notification to the PT.  
                   This function shall be invoked by the FT application when it detects
                   a missed call and enters the missed call information into the Missed
                   Call List.  This function composes a FACILITY based notification
                   message and sends to the PT.
        \param[in] ucHandsetId Handset Identifier
        \param[in] ucLineId Line Identifier             
        \param[in] ucSubType Subtype of the Missed Call Event        
        \param[out] ucNoOfUnreadMissedCalls Number of Unread missed calls
        \param[out] ucNoOfMissedCallListEntries Total Number of entries in the Missed call list
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_LAU_MissedCallNotify(IN uchar8 ucHandsetId,
                                           IN uchar8 ucLineId,
                                           IN uchar8 ucSubType,
                                           IN uchar8 ucNoOfUnreadMissedCalls,
                                           IN uchar8 ucNoOfMissedCallListEntries);
                                           
/*! \brief  This function is used to send a list change notification to the PT.  
                   This function shall be invoked by the FT application when it detects
                   modifications being made to any list.  This function composes a 
                   FACILITY based notification message and sends to the PT.
        \param[in] ucHandsetId Handset Identifier
        \param[in] ucLineId Line Identifier                   
        \param[out] eListId List Identifier to which modifications are being made
        \param[out] ucNoOfListEntries Total Number of entries in the list
        \return IFX_SUCCESS / IFX_FAILURE
*/                                           
e_IFX_Return IFX_DECT_LAU_ListChangeNotify(IN uchar8 ucHandsetId,
                                           IN uchar8 ucLineId,
                                           IN e_IFX_DECT_LAU_ListId eListId,
                                           IN uchar8 ucNoOfListEntries);
/* ****************************************************************************
 * Callback Functions
 * ****************************************************************************/
/*! \brief  This callback function is used to inform the FT application of
                   an incoming start session request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info (Start Session)
                   request from the DECT Protocol stack.
                   The DECT TK fills in the command parameters from the Start Session.
                   The DECT TK generates a Session Identifier and sends it within
                   the InCmd.  The command parameters for the Start Session
                   Confirm command are to be filled in by the FT application and sent
                   within the OutCmd. The DECT TK automatically responds to the
                   Start Session Request command by sending a Start Session Confirm
                   response.  The data from the OutCmd is used in construction of the
                   response.
	\param[in] ucHandsetId Handset Identifier of source PT
           \param[in] pxInCmd List command parameters in the request
          \param[out] pxOutCmd List command parameters for the response
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_SessionStart)(IN uchar8 ucHandsetId,
			 								  IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                               OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);

/*! \brief  This callback function is used to inform the FT application of
                   an incoming end session request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-IWU (End Session)
                   request from the DECT Protocol stack.
                   The End session command does not carry parameters, hence no
                   InCmd and OutCmd is used.
	\param[in] nSessId Session Identifier
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_SessionEnd)(IN int16 nSessId);

/*! \brief  This callback function is used to inform the FT application of
                   link release request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a CC-RELEASE or sends CC-RELEASE 
                   request from/to the DECT Protocol stack. This callback can be used to reset the 
                   PIN Protection feature or local data cleanup for that handset.
    \param[in] ucHandsetId Handset Identifier of source PT
    \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_LinkReleased)(IN uchar8 ucHandsetId);
													
/*! \brief  This callback function is used to inform the FT application of
                   an incoming query fields request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info (Query Fields)
                   request from the DECT Protocol stack.
                   The DECT TK fills in the command parameters from the Query Fields Request.
                   The DECT TK encapsulates the Session Identifier and sends it within
                   the InCmd.  The command parameters for the Query Fields
                   Confirm command are to be filled in by the FT application and sent
                   within the OutCmd. The DECT TK automatically responds to the
                   Query Fields Request command by sending a Query Fields Confirm
                   response.  The data from the OutCmd is used in construction of the
                   response.
           \param[in] pxInCmd List command parameters in the request
          \param[out] pxOutCmd List command parameters for the response
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_FieldQuery)(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                                    OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);

/*! \brief  This callback function is used to inform the FT application of
                   a read entries request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info (Read Entries)
                   request from the DECT Protocol stack.
                   The DECT TK fills in the command parameters from the Read Entries Request.
                   The DECT TK encapsulates the Session Identifier and sends it within
                   the InCmd.  The command parameters for the Read Entries
                   Confirm command are to be filled in by the FT application and sent
                   within the OutCmd. The DECT TK automatically responds to the
                   Read Entries Request command by sending a Read Entries Confirm
                   response.  The data from the OutCmd is used in construction of the
                   response.  Apart from the confirmation response, data packets
                   shall be sent directly from the FT application.
           \param[in] pxInCmd List command parameters in the request
          \param[out] pxOutCmd List command parameters for the response
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.    
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_EntryRead)(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                                   OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);
                                                    
/*! \brief  This callback function is used to inform the FT application of
                   a edit entry request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info (Edit Entry)
                   request from the DECT Protocol stack.
                   The DECT TK fills in the command parameters from the Edit Entry Request.
                   The DECT TK encapsulates the Session Identifier and sends it within
                   the InCmd.  The command parameters for the Edit Entry
                   Confirm command are to be filled in by the FT application and sent
                   within the OutCmd. The DECT TK automatically responds to the
                   Edit Entry Request command by sending a Edit Entry Confirm
                   response.  The data from the OutCmd is used in construction of the
                   response.  Apart from the confirmation response, data packets
                   shall be sent directly from the FT application.
           \param[in] pxInCmd List command parameters in the request
          \param[out] pxOutCmd List command parameters for the response
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.    
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_EntryEdit)(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                                   OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);
                                                    
/*! \brief  This callback function is used to inform the FT application of
                   a edit entry request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info (Save Entry)
                   request from the DECT Protocol stack.
                   The DECT TK fills in the command parameters from the Save Entry Request.
                   The DECT TK encapsulates the Session Identifier and sends it within
                   the InCmd.  The FT application has to wait for the Data packet 
                   carrying the entry contents.  After receiving the data packet.
                   the FT application shall save the entry and respond by invoking
                   the IFX_DECT_LAU_EntrySave function.  Alternatively,
                   a Nack may also be sent by invoking IFX_DECT_LAU_SendNack
                   function.
           \param[in] pxInCmd List command parameters in the request
          \param[out] pxOutCmd List command parameters for the response. Always NULL.
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.
               If IFX_PENDING is returned, the DECT TK shall not send a
               Save Entry Confirmation response.               
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_EntrySave)(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                                   OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);

/*! \brief  This callback function is used to inform the FT application of
                   a delete entry request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info (Delete Entry)
                   request from the DECT Protocol stack.
                   The DECT TK fills in the command parameters from the Delete Entry Request.
                   The DECT TK encapsulates the Session Identifier and sends it within
                   the InCmd.  Before invoking this callback, DECT TK ensure the
                   delete entry request is not issued to the "List of Lists" or the
                   "DECT System Settings List".  In those cases, the DECT TK itself
                   sends a Nack response.  The command parameters for the Delete Entry
                   Confirm command are to be filled in by the FT application and sent
                   within the OutCmd. The DECT TK automatically responds to the
                   Delete Entry Request command by sending a Delete Entry Confirm
                   response.  The data from the OutCmd is used in construction of the
                   response.  Apart from the confirmation response, data packets
                   shall be sent directly from the FT application.
           \param[in] pxInCmd List command parameters in the request
          \param[out] pxOutCmd List command parameters for the response
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command. 
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_EntryDelete)(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                                     OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);

/*! \brief  This callback function is used to inform the FT application of
                   a delete list request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info (Delete List)
                   request from the DECT Protocol stack.
                   The DECT TK fills in the command parameters from the Delete List Request.
                   The DECT TK encapsulates the Session Identifier and sends it within
                   the InCmd.  Before invoking this callback, DECT TK ensure the
                   delete list request is not issued to the "List of Lists" or the
                   "DECT System Settings List".  In those cases, the DECT TK itself
                   sends a Nack response.  The command parameters for the Delete List
                   Confirm command are to be filled in by the FT application and sent
                   within the OutCmd. The DECT TK automatically responds to the
                   Delete List Request command by sending a Delete List Confirm
                   response.  The data from the OutCmd is used in construction of the
                   response.  Apart from the confirmation response, data packets
                   shall be sent directly from the FT application.
           \param[in] pxInCmd List command parameters in the request
          \param[out] pxOutCmd List command parameters for the response
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.    
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_ListDelete)(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                                    OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);

/*! \brief  This callback function is used to inform the FT application of
                   a Search entries request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info (Search Entries)
                   request from the DECT Protocol stack.
                   The DECT TK fills in the command parameters from the Search Entries Request.
                   The DECT TK encapsulates the Session Identifier and sends it within
                   the InCmd.  The command parameters for the Search Entries
                   Confirm command are to be filled in by the FT application and sent
                   within the OutCmd. The DECT TK automatically responds to the
                   Search Entries Request command by sending a Search Entries Confirm
                   response.  The data from the OutCmd is used in construction of the
                   response.  Apart from the confirmation response, data packets
                   shall be sent directly from the FT application.
           \param[in] pxInCmd List command parameters in the request
          \param[out] pxOutCmd List command parameters for the response
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.    
*/ 
typedef	e_IFX_Return (*pfn_IFX_DECT_LAU_EntrySearch)(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                                     OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);
                                                    
/*! \brief  This callback function is used to inform the FT application of
                   the availability of data packet(s) from the PT.  This callback function
                   is invoked by the DECT TK after it receives a set of Data packets,
                   IWU-Info (Data Packets).  The DECT TK reassembles all the 
                   received data packets into a data payload buffer and gives it
                   to the FT application.  The FT application shall use the decode
                   function of the DECT TK to decode the data payload buffer into
                   a data structure.  The size of the data buffer is passed to the
                   FT application.
          \param[in] nSessId Session Identifier for the session
          \param[in] unDataLen Size of the data payload buffer
          \param[in] pucData Data Payload Buffer
	\return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
*/               
typedef e_IFX_Return (*pfn_IFX_DECT_LAU_DataPktRecv)(IN uint32 nSessId,
                                                     IN uint16 unDataLen,
                                                     IN uchar8 *pucData);

#ifdef LTQ_DT_SUPPORT
/* Call backs**/
/*! \brief  This callback function is used to inform the FT application of
                   an incoming move session request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info (Move Session)
                   request from the DECT Protocol stack.
                   The DECT TK fills in the command parameters from the Move Session.
                   The DECT TK Encapuslate Session Identifier and sends it within
                   the InCmd.  The command parameters for the Move Session
                   Confirm command are to be filled in by the FT application and sent
                   within the OutCmd. The DECT TK automatically responds to the
                   Move Session Request command by sending a Move Session Confirm
                   response.  The data from the OutCmd is used in construction of the
                   response.
  \param[in] ucHandsetId Handset Identifier of source PT
           \param[in] pxInCmd List command parameters in the request
  \return IFX_SUCCESS / IFX_FAILURE / IFX_PENDING / IFX_PROCESSED
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.
*/
typedef e_IFX_Return (*pfn_IFX_DECT_LAU_SessionMove)(IN x_IFX_DECT_LAU_ListCommands *pxInCmd, OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);
#endif
                                                    


/* Call backs**/
/*! \brief  This callback function is used to inform the FT application of
                   an incoming proprietary request from the PT.  This callback function
                   is invoked by the DECT TK when it receives a IWU-Info with proprietary  
                   cmd request from the DECT Protocol stack.
                   The Application should parse and interpret the message
                   as per understanding and send the any proprietary
                   response (Confirmation, reject) through below TK API
                   IFX_DECT_LAU_Proprietary_RespSend()
                   
  \param[in] ucHandset Handset Identifier of source PT
           \param[in] *pucBuff Pointer to Proprietary buff
           \param[in] iLen lenth of Proprietary data
  \return IFX_SUCCESS / IFX_FAILURE 
    \note The function returning error will prompt the DECT TK to send
               a negative acknowledgment for the command.
*/
typedef e_IFX_Return (*pfn_IFX_DECT_HandleProprietaryCmds)(IN uchar8 ucHandset,IN uchar8 *pucBuff,IN int32 iLen);
                     

                                                    
/*!
    \brief Structure containing callback functions for LAU related procedures.
The callback functions listed in the structure need to be implemented within 
the FT application and registered with the DECT TK.
*/
typedef struct 
{
    pfn_IFX_DECT_LAU_SessionStart pfnSessionStart; /*!< Callback for notifying an Start Session Request from PT*/
    pfn_IFX_DECT_LAU_SessionEnd   pfnSessionEnd;/*!< Callback for notifying an End Session Request from PT*/
    pfn_IFX_DECT_LAU_FieldQuery   pfnFieldQuery; /*!< Callback for notifying a Query Fields Request from PT*/
    pfn_IFX_DECT_LAU_EntryRead    pfnEntryRead; /*!< Callback for notifying a Read Entries Request from PT*/
    pfn_IFX_DECT_LAU_EntryEdit    pfnEntryEdit; /*!< Callback for notifying a Edit Entry Request from PT*/    
    pfn_IFX_DECT_LAU_EntrySave    pfnEntrySave; /*!< Callback for notifying a Save Entry Request from PT*/    
    pfn_IFX_DECT_LAU_EntryDelete  pfnEntryDelete; /*!< Callback for notifying a Delete Entry Request from PT*/     
    pfn_IFX_DECT_LAU_ListDelete   pfnListDelete; /*!< Callback for notifying a Delete List Request from PT*/
    pfn_IFX_DECT_LAU_EntrySearch  pfnEntrySearch; /*!< Callback for notifying a Read Entries Request from PT*/   
    pfn_IFX_DECT_LAU_DataPktRecv  pfnDataPktRecv; /*!< Callback for notifying availability of Data Packet(s) from PT*/
    pfn_IFX_DECT_LAU_LinkReleased pfnLinkRelease; /*!< Callback for notifying link release from either side */
#ifdef LTQ_DT_SUPPORT
		pfn_IFX_DECT_LAU_SessionMove pfnSessionMove;/*!< Callback for notifying a move session from PT */
#endif
	pfn_IFX_DECT_HandleProprietaryCmds pfnHandleProprietaryCmds; /*!< Callback to handle Proprietary cmds */
} x_IFX_DECT_LAU_CallBks;

//#ifdef LTQ_DT_SUPPORT
typedef struct{
         e_IFX_DECT_LAU_ListId ucListId;
        uint16 unSupportedFieldMap;
}x_IFX_DECT_PROP_LAU_Info;
//#endif

/*! \brief  This function is used to send confirmation to the PP. This is used to
            handle scenarios where the application does not have enough information
			when returning from the call back
        \param[in] pxInCmd Array containing the list commands 
                           supported by the DECT TK/FT application.
        \return IFX_SUCCESS / IFX_FAILURE
	\note If the user uses this API inside the call back the return value of the call
	      back should be IFX_PROCESSED. 
		  If the user wishes to use this API and does not want to respond using the call
		  back outcmd then he has to return IFX_PENDING
*/
e_IFX_Return IFX_DECT_LAU_ConfirmationSend(x_IFX_DECT_LAU_ListCommands *pxInCmd);

/*! \brief  This function is used to send Proprietary Response to the PP. 
         \param[in] ucHandset Handset Identifier of source PT
           \param[in] *pucBuff Pointer to Proprietary buff
           \param[in] iLen lenth of Proprietary data
  \return IFX_SUCCESS / IFX_FAILURE 
	
*/
e_IFX_Return IFX_DECT_LAU_Proprietary_RespSend(IN uchar8 ucHandset,IN uchar8 *pucBuff,IN int32 iLen);



/*! \brief  This function is used to register callback functions with the LAU for
             notifying call related events to the FT application.\n
	The FT application shall call this function during initialization.
	 \param[in] pxLAUCallBks Structure containing the callback functions
	 \return IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_DECT_LAU_CallBksRegister(IN x_IFX_DECT_LAU_CallBks *pxLAUCallBks);

/* @} */
#endif /* __IFX_DECT_LAU_H__*/
							 

