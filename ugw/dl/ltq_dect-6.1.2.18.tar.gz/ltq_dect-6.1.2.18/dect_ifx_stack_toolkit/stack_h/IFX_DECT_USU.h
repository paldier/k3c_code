/**************************************************************************
**   FILE NAME     : IFX_DECT_USU.h
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-09-2008
**   AUTHOR        : 
**   DESCRIPTION   : Function prototypes for DECT Call Control
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software is granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
/*! \file IFX_DECT_USU.h
    \brief This file contains the Utility Service Unit (USU) Procedures.  
                The USU is a collection of procedures that provide
                utility functions to the FT application.  In general, the 
                procedures described in the USU do not fall under
                any of the SU's supported within the DECT TK.
*/

/** \ingroup DECT_TOOLKIT_MODULES
       \defgroup USU_MODULE Utility Service Unit
       \brief The Utility Service Unit is a collection of procedures that provide
                utility functions to the FT application.  In general, the 
                procedures described in the USU do not fall under
                any of the SU's supported within the DECT TK.  The procedures
                implemented within the USU are both CAT iq 1.0 and 2.0 complaint.
*/
/* @{ */
/* @} */

#ifndef __IFX_DECT_USU_H__
#define __IFX_DECT_USU_H__

/** \ingroup DECT_TOOLKIT_API
    \defgroup USU_API Utility Service Unit
    \brief This group contains the Utility Service Unit (USU) functions 
            of the DECT Toolkit.  It provides a set of procedures:\n
     1> For managing the Date/Time synchronisation between FP and PP\n
     2> For managing the Generic event handling from FP to PP.\n
     3> For managing the Voice mail notification \n
     4> For managing encryption during calls
   */
/* @{ */

/*! \def IFX_DECT_USU_MAX_EVENTS
    \brief Macro that specifies the maximum number of events in the Event List.
 */
#define IFX_DECT_USU_MAX_EVENTS 3 /*!< Maximum number of events in the Event List */

/*! \def IFX_DECT_USU_MAX_IDENTIFIERS
    \brief Macro that specifies the maximum number of Identifiers in Identifier List.
*/

#define IFX_DECT_USU_MAX_IDENTIFIERS 10

/*!
    \brief Structure describing the Event.
*/
typedef struct
{
    uchar8 ucEventType; /*!< Event Type */
    uchar8 ucEventSubtype; /*!< Event Subtype */
    uint16 unEventMultiplicity; /*!< Event Multiplicity */
} x_IFX_DECT_USU_Event; 

/*!
    \brief Structure describing the Event List.
*/
typedef struct
{
    uchar8 ucNoOfEvents; /*!< Number of Events */
    x_IFX_DECT_USU_Event axEvent[IFX_DECT_USU_MAX_EVENTS]; /*!< Events List */
    char8 acLineId[IFX_DECT_USU_MAX_IDENTIFIERS];/*!<Array of 7-bit Line Id values */
    uchar8 ucIsAllLines; /*!<ucIsAllLines =1,Line SubType is All.
                                          =0,Line SubType is Relating-To. */ 
    uchar8 ucNoOfLineId; /*!< Number Of Line Identifiers */
} x_IFX_DECT_USU_EventList; 

/*!
    \brief Structure describing the Time and Date Info.
*/
typedef struct
{
    uchar8 ucYear; /*!< Date: Year */    
    uchar8 ucMonth; /*!< Date: Month */    
    uchar8 ucDay; /*!< Date: Day */
    uchar8 ucHour; /*!< Time: Hour */
    uchar8 ucMinutes; /*!< Time: Minutes */
    uchar8 ucSeconds; /*!< Time: Seconds */
    uchar8 ucTimeZone; /*!< Time: TimeZone */
    
} x_IFX_DECT_USU_TimeDate; 

/*!
    \brief External Variable for Download indication.
*/
extern uchar8 vucDownloadBmcOnBootInd;

/* ****************************************************************************
 * Notification Functions
 * ****************************************************************************/
/*! \brief  This function is used to send a voice mail notification to the PT.  
                   This function shall be invoked by the FT application when it receives
                   information from the network that a voice mail has been recorded. 
                   For e.g., the caller was redirected to the voice mail service, where
                   he recorded his message.  This function composes a FACILITY based notification
                   message and sends to the PT.
        \param[in] ucHandsetId Handset Identifier
        \param[in] cLineId Line Identifier
        \param[in] ucNoOfUnreadMails Number of Unread voice mails
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_USU_VoiceMesgWaitingNotify(IN uchar8 ucHandsetId,
                                                 IN char8 cLineId,
                                                 IN uchar8 ucNoOfUnreadMails);
                                                 
/*! \brief  This function is used to send a generic event notification to the PT.  
                   This function shall be invoked by the FT application when an event
                   that needs to be sent to the PP is receved by the FT.
                   The FT application needs to fill-in the fields of the Events list and
                   invoke this function.  For CAT iq 2.0 procedures, individual
                   event notification procedures are helpful.  It would not be
                   required for the application user to use this procedure as long as the 
                   specific event based notifications (e.g Missed call, Voice mail, etc)
                   are available within the DECT TK. This function composes a FACILITY
                   based notification message and sends to the PT.
        \param[in] ucHandsetId Handset Identifier
        \param[in] pxEventList Event List
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_USU_GenericEventNotify(IN uchar8 ucHandsetId,
                                             IN x_IFX_DECT_USU_EventList *pxEventList);
 
/*! \brief  This function is used to synchronise the Date and Time
         between FT and PT.  The FT application invokes this function
         when it needs the PT to synchronise its time and date with that
         of the PT.  Typically, the FT application shall attempt to sync
         the time and date when the handset attaches to the FT.  There 
         may be other occasions when the FT invokes this function.
         The DECT TK retrieves the FT system time and date using the
         gettimeofday system call. 
        \param[in] ucHandsetId Handset Identifier
        \param[in] pxTimeDate Time and Date information
        \return IFX_SUCCESS / IFX_FAILURE
*/
e_IFX_Return IFX_DECT_USU_DateTimeSync(IN uchar8 ucHandsetId, 
                                       IN x_IFX_DECT_USU_TimeDate *pxTimeDate);

/*! \brief  This function is used to encrypt a call from
                   the FT application. 
        \param[in] ucHandsetId Handset Identifier
        \param[in] bOnOff Turn On/Off encryption. IFX_ON to turn on encryption, 
                           IFX_OFF to turn off encryption
        \return IFX_SUCCESS / IFX_FAILURE
*/                                       
e_IFX_Return IFX_DECT_USU_Cipher(IN uchar8 ucHandsetId,
                                 IN boolean bOnOff);

/*! \brief  This function is used to switch on/off the DECT RF. 
        \param[in] bOnOff Turn On/Off RF. 0 to turn on RF, 
                           1 to turn off RF
        \return IFX_SUCCESS / IFX_FAILURE
*/                                       
e_IFX_Return IFX_DECT_USU_RFConfig(IN boolean bOnOff);

/*! \brief  This function is used to DECT Version information. 
    \return IFX_SUCCESS / IFX_FAILURE
*/                                       
void IFX_DECT_USU_PrintVersion();


/*! \brief This Callback is used to synchronize Date and Time between FT and PT by 
           notifying the FT Application of the Time-Date of PT.PT sends its Time 
           and Date information to FT via a FACILITY based notification.
           This callback function is invoked by the DECT TK when it receives 
           TimeDate information of PT from the DECT Protocol stack.
    \param[in] ucHandsetId Handset Identifier.
    \param[in] pxTimeDate Time and Date Information. 
    \return IFX_SUCCESS / IFX_FAILURE.
*/

typedef e_IFX_Return (*pfn_IFX_DECT_USU_DateTimeSync)(IN uchar8 ucHandsetId,
                                                      IN x_IFX_DECT_USU_TimeDate *pxTimeDate);
													  
/*! \brief 
		This Callback is used to obtain the response to a XRAM query
		   posted earlier.  The FT Application registers this Callback 
		   function with the DECT TK to obtain the response of a XRAM query.
		   The DECT TK, upon request from the FT Application
		   would have posted a XRAM query to the modem.  The DECT TK
		   sends the request to the modem and returns.  When the response is
		   received, this callback is invoked.  The result of the query is
		   filled in the pMsg.
    \param[in] pMsg Pointer to the debug message.
    \return IFX_SUCCESS / IFX_FAILURE.
*/
													  
typedef e_IFX_Return (*pfn_IFX_DECT_USU_XRAM)(IN uchar8 *pMsg);

#ifdef FW_DOWNLOAD
/*! \brief  This function is used to download the firmware files to the Cosic Modem. 
                   The FT application shall invoke this function when it needs to download 
                   the firmware files to the modem. Typically, this function is called by 
                   the FT application during the boot/initialization time when the modem 
                   needs to be initialized. This function takes care to segment the firmware 
                   contents into different chunks, sequences the chunks and delivers the 
                   chunks to the Cosic Driver. The Cosic Driver in turn uses the SPI interface 
                   to deliver the chunks to the Cosic Modem. This function uses the modem 
                   bootloader commands to manage the download. Since the download is 
                   expected to take some time, this function shall return immediately with 
                   a return value of IFX_PENDING. Upon completion of the download the 
                   DECT TK shall invoke the pfn_IFX_DECT_USU_ModemFirmwareDownload 
                   callback function to communicate the download status to the FT application. 
                   If there is an error in the Path or in the names of the firmware files, 
                   this function returns an error immediately. 
        \param[in] pcPath Path where the firmware files are stored in the filesystem.
        \param[in] pcBmcFwFileName Name of the BMC Firmware file. If no name is provided, default shall be assumed. 
        \param[in] pcUserApplnFileName Name of the User Application file. If no name is provided, default shall be assumed.
        \return IFX_SUCCESS / IFX_FAILURE
*/                                 
e_IFX_Return  IFX_DECT_USU_ModemFirmwareDownload (IN char8 *pcPath, IN char8 *pcBmcFwFileName, IN char8 *pcUserApplnFileName);
 
/*! \brief This callback function is used to inform the FT application on the 
                   status of the Firmware download. The DECT TK invokes this function 
                   either upon successfully completing the download of the firmware 
                   files to the modem or upon detection of an error during the 
                   downloading process. 
              \param[in] ucStatus  Status of the FW download (IFX_SUCCESS/IFX_FAILURE)  
              \return IFX_SUCCESS / IFX_FAILURE
*/
typedef e_IFX_Return(* pfn_IFX_DECT_USU_ModemFirmwareDownload)(IN uchar8 ucStatus);  

#endif

#ifdef ENABLE_ENCRYPTION
/*! \brief  This callback function is used to inform the FT application about the 
                   confirmation of the Cipher change request . The DECT TK  
                   invokes this callback function when it receives a FP_CIPHER_ON_CFM_MM
                   with the ciphering status.  Please refer to the flow
                   diagrams for the sequence involved.
    \param[in] ucCipherStatus IFX_TRUE/IFX_FALSE  
*/ 
typedef   void (*pfn_IFX_DECT_USU_CipherCfm)(IN uchar8 ucCipherStatus);

#endif



/*! \brief Structure defining Utility Service Unit Callbacks that are supplied 
           by the FT application.
*/

typedef struct{

  pfn_IFX_DECT_USU_DateTimeSync pfn_USU_DateTimeSync;/*!<Callback for notifying PT Time-Date to FT for Time-Date Synchronization. */
  pfn_IFX_DECT_USU_XRAM pfn_USU_XRAM; /*!<Callback for notifying the response to a XRAM query */
#ifdef FW_DOWNLOAD
  pfn_IFX_DECT_USU_ModemFirmwareDownload pfn_USU_FirmwareDownloadStatus;/*!< Callback for notifying the status of firmware download*/
#endif
#ifdef ENABLE_ENCRYPTION
  pfn_IFX_DECT_USU_CipherCfm pfn_USU_CipherCfm; /*!< Callback for notifying the status of Cipher request*/
#endif
}x_IFX_DECT_USU_CallBks;

/*! \brief The API IFX_DECT_USU_RegisterCallBks registers callbacks for
           Utility Service Unit.
*/
 
e_IFX_Return IFX_DECT_USU_RegisterCallBks(IN x_IFX_DECT_USU_CallBks *pxUSUCallBks);

/* @} */
#endif /* __IFX_DECT_USU_H__*/
                      

