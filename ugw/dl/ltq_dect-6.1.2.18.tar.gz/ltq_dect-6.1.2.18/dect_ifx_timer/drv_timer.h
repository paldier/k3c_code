/******************************************************************************

		        	Copyright (c) 2006
			     Infineon Technologies AG
			Am Campeon 1-12, 85579 Neubiberg, Germany

    This program is under dual licence. You can use it as Lantiq   
    Deutschland GmbH licensed or consider it as is free software; you 
    can redistribute it and/or modify it under the terms 
    of the GNU General Public License as published by 
    the Free Software Foundation; either version 2 of the License, or 
    (at your option) any later version. 


*******************************************************************************/

#ifndef _TIMER_DRV_H_
#define _TIMER_DRV_H_

#define TIMER_DRV_IDLE        0x00
#define TIMER_DRV_RUNNING     0x01
#define TIMER_DRV_MODE_CHANGE 0x02
#define TIMER_DRV_SHUT        0x03



extern int Cosic_modem_monitoring_timer_ctrl(int iState);
#endif /* _TIMER_DRV_H_ */

