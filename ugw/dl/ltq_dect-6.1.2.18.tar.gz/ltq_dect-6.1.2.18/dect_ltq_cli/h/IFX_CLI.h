/**************************************************************************
**   FILE NAME       : ifx_cli.h
**   PROJECT         : TAPIDEMO Phone
**   MODULES         : Config Module
**   SRC VERSION     : V0.1
**   DATE            : 23-06-2004
**   AUTHOR          : Radvajesh.M
**   DESCRIPTION     :
**   FUNCTIONS       :
**   COMPILER        : gcc
**   REFERENCE       : Coding guide lines for VSS ,
**
**   COPYRIGHT       : Copyright ) 2004 Infineon Technologies AG
**                     St. Martin Strasse 53; 81669 M|nchen, Germany
**                     Any use of this Software is subject to the conclusion
**                     of a respective License Agreement.Without such a
**                     License Agreement no rights to the Software are granted.
**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
* ***********************************************************************/
#ifndef __IFX_CLI_H__
#define __IFX_CLI_H__
typedef enum {
       /* CLI-->Tapidemo*/
	     IFX_CLI_DIAG_MODE,
       IFX_CLI_MODEM_RESET,
       IFX_CLI_SET_BMC_REQ,
	     IFX_CLI_SET_OSC_REQ,
       IFX_CLI_SET_TBR6_REQ,
       IFX_CLI_SET_RFPI_REQ,
       IFX_CLI_SET_XRAM_REQ,
       IFX_CLI_SET_GFSK_REQ,
       IFX_CLI_SET_RFMODE_REQ,
			 IFX_CLI_SET_FREQ_REQ,
       IFX_CLI_SET_TPC_REQ,
       IFX_CLI_GET_BMC_REQ,
       IFX_CLI_GET_XRAM_REQ,
       IFX_CLI_GET_TPC_REQ,
       /* TAPIDEMO-->CLI*/
       IFX_CLI_GET_BMC_IND,
       IFX_CLI_GET_XRAM_IND,
       IFX_CLI_GET_TPC_IND,
}e_IFX_CLI_Events;

typedef struct 
{
  e_IFX_CLI_Events Event;
  union{
		uchar8 ucIsDiag;
    x_IFX_DECT_TransmitPowerParam xTPCParams;
    struct {
      uint16 uiAddr;
      char8  acBuffer[10];
      uchar8 ucLength_Maccess;
    }xRam;
    x_IFX_DECT_BMCRegParams xBMC;
    uint16 unGfskValue;
    struct {
      uchar8 ucRFMode;
      uchar8 ucChannelNumber;
      uchar8 ucSlotNumber;
    }xRFMode;
    struct {
      uint16 uiOscTrimValue;
      uchar8 ucP10Status;
    }xOsc;
    uchar8 ucIsTBR6;
    char8  acRFPI[5];
    struct {
      uchar8 ucFreqTx;
      uchar8 ucFreqRx;
      uchar8 ucFreqRange;
    }xFreq;
  }xCLI;
}x_IFX_CLI_Cmd;

typedef enum{
				IFX_CLI_DECT = 1,                  
				IFX_CLI_VOIP,
}e_IFX_CLI_MainMenu;

typedef enum{
			IFX_CLI_DECT_DIAG = 1,
			IFX_CLI_DECT_CONFIG, 
}e_IFX_CLI_DectMenu;

typedef enum{
		IFX_CLI_DECT_DIAG_TPC = 1,
		IFX_CLI_DECT_DIAG_BMC,
		IFX_CLI_DECT_DIAG_XRAM,
		IFX_CLI_DECT_DIAG_RFMODE,
		IFX_CLI_DECT_DIAG_OSC,
		IFX_CLI_DECT_DIAG_GFSK, 																
		IFX_CLI_DECT_DIAG_RFPI,
		IFX_CLI_DECT_DIAG_RESET_MODEM,
		IFX_CLI_DECT_DIAG_COUNTRY_SETTINGS,
		IFX_CLI_DECT_DIAG_TBR6,
		IFX_CLI_DECT_DIAG_SAVE_TO_FLASH,
		IFX_CLI_DECT_DIAG_GET_XRAM,
		IFX_CLI_DECT_DIAG_GET_BMC,
		IFX_CLI_DECT_DIAG_GET_TPC,
}e_IFX_CLI_DECT_DiagMenu;


/*displayMenu
 Displays the menus upto the menus at the bottom most level

 Arguments ::
 list - list of menu items
 size - size of the list
 */
void displayMenu(char **list,int size);

/*commonMenu
 Displays the menus common to all menus	at the bottom most level

 Arguments ::
 id - helps to identify the option to start with for the common menus
 */
void commonMenu(int id);

typedef enum{
	      IFX_CLI_CHAR,
	      IFX_CLI_INT16,
	      IFX_CLI_UNSIGNED_CHAR,
}e_IFX_CLI_DateType;

/* getInput Function
 
 	 Reads the input from user and validates

	 Arguments ::
	 type - helps in specifyin the type to validate	and its an Enum "e_IFX_CLI_DataType"
 */
int getInput(e_IFX_CLI_DateType type);


#endif /*__IFX_CLI_H__*/

