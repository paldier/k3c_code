/**************************************************************************
**   FILE NAME       : IFX_Config.h
**   PROJECT         : TAPIDEMO Phone
**   MODULES         : Config Module
**   SRC VERSION     : V0.1
**   DATE            : 23-06-2004
**   AUTHOR          : Radvajesh.M
**   DESCRIPTION     :
**   FUNCTIONS       :
**   COMPILER        : gcc
**   REFERENCE       : Coding guide lines for VSS ,
**
**   COPYRIGHT       : Copyright ) 2004 Infineon Technologies AG
**                     St. Martin Strasse 53; 81669 M|nchen, Germany
**                     Any use of this Software is subject to the conclusion
**                     of a respective License Agreement.Without such a
**                     License Agreement no rights to the Software are granted.
**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
* ***********************************************************************/
#ifndef __IFX_CONFIG_H__
#define __IFX_CONFIG_H__

/* Function Protypes*/
PUBLIC int32
IFX_CM_SetRcCfgData (IN const char8 * pFileName,
                     IN const char8 * pTag,
                     IN int nDataCount,
                     OUT const char8 * pData, ...);
PUBLIC int32
IFX_CM_GetRcCfgData(IN char8 *pFileName,
                    IN char8 *pTag,
                    IN char8 *pData,
                    OUT char8 *pRetValue);


void ifx_setrc_Tpc(x_IFX_DECT_TransmitPowerParam *pxTPCParams);
void ifx_getrc_Tpc(x_IFX_DECT_TransmitPowerParam *pxTPCParams);

void ifx_setrc_Bmc(x_IFX_DECT_BMCRegParams *pxBMC);
void ifx_getrc_Bmc(x_IFX_DECT_BMCRegParams *pxBMC);

void ifx_getrc_Freq(uchar8 *pucFreqTx, uchar8 *pucFreqRx, uchar8 *pucFreqRange);
void ifx_setrc_Freq(uchar8 ucFreqTx, uchar8 ucFreqRx, uchar8 ucFreqRange);

void ifx_getrc_Osc(uint16 *puiOscTrimValue, uchar8 *pucP10Status);
void ifx_setrc_Osc(uint16 uiOscTrimValue, uchar8 ucP10Status);

void ifx_getrc_Gfsk(uint16 *puiGfskValue);
void ifx_setrc_Gfsk(uint16 uiGfskValue);


void ifx_getrc_Rfpi(uchar8 *pcRFPI);
void ifx_setrc_Rfpi(uchar8 *pcRFPI);


void ifx_getrc_RfMode(uchar8 *pucRFMode , uchar8 *pucChannelNumber,uchar8 *pucSlotNumber);
void ifx_setrc_RfMode(uchar8 ucRFMode , uchar8 ucChannelNumber,uchar8 ucSlotNumber);



#define IFX_CM_MAX_TAG_LEN  64
#define IFX_CM_MAX_BUFF_LEN 5192
#define IFX_CM_BUF_SIZE_50K 10240
#define IFX_CM_MAX_FILENAME_LEN 256
#define IFX_CM_FILE_RC_CONF  "/flash/rc.conf"
#define IFX_CM_FILE_DECT_RC_CONF  "/flash/dect_rc.conf"
/* BMC params */
#define IFX_CM_TAG_BMC "BmcParams"
#define IFX_CM_TAG_BMC_RSSIFREE "BmcParams_0_RssiFreeLevel"
#define IFX_CM_TAG_BMC_RSSIBUSY "BmcParams_0_RssiBusyLevel"
#define IFX_CM_TAG_BMC_BRLIMIT "BmcParams_0_BearerChgLimit"
#define IFX_CM_TAG_BMC_DEFANT "BmcParams_0_DefaultAntenna"
#define IFX_CM_TAG_BMC_WOPNSF "BmcParams_0_WOPNSF"
#define IFX_CM_TAG_BMC_WWSF "BmcParams_0_WWSF"
#define IFX_CM_TAG_BMC_DRONCTRL "BmcParams_0_CNTUPCtrlReg"
#define IFX_CM_TAG_BMC_DVAL "BmcParams_0_DelayReg"
#define IFX_CM_TAG_BMC_HOFRAME "BmcParams_0_HandOverEvalper"
#define IFX_CM_TAG_BMC_SYNCMODE "BmcParams_0_SYNCMCtrlReg"
/* TPC params */
#define IFX_CM_TAG_TPC "TransPower"

#endif /*__IFX_CONFIG_H__*/

