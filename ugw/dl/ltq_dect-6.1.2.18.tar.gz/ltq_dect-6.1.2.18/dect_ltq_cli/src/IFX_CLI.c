/**************************************************************************
 **   SRC_FILE          : IFX_CLI.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT Cli Interface
 **   SRC VERSION       : v0.1
 **   DATE              : 8th Oct 2007
 **   AUTHOR            : Voip GW Team
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
#define boolean int
#include<stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <fcntl.h>
#include <sys/reboot.h>
#include <linux/reboot.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/wait.h>
#include "ifx_common_defs.h"
#include "IFX_DECT_Stack.h"
#include <strings.h>
#include <stddef.h>
#include <sys/types.h>
#include <sys/socket.h>         
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>            
#include <unistd.h>
#include <sys/select.h>         
#include <sys/un.h>
#include <errno.h>
#include <fcntl.h>
#include "IFX_CLI.h"
#include "IFX_Config.h"
#define MURALI
#ifndef MURALI
#include <execinfo.h>
#include <signal.h>
#endif
int32 viToDectAppFd;                 //Read FD
int32 viFromDectAppFd;               //Write FD

struct sockaddr_un FILE_name;
int32 size;
int32 arg,arg1;
int32 iReadLength;


int choice=0;
int previous=0; 
int clearState=0;
int invalidChoice=0;
int prevChoice=0;
int x=1;

void LtqScanf(char *fmt,int *pvar)
{
  char a[50],*ptr;
  int n=50;
  ptr=a;
  getline(&ptr,&n,stdin);
  sscanf(ptr,fmt,pvar);
  return;
}

#ifndef MURALI
void handler(int sig) 
{
	void *array[10];
	size_t size;
  // get void*'s for all entries on the stack
	size = backtrace(array, 10);

	// print out all the frames to stderr
	fprintf(stderr, "Error: signal %d:\n", sig);
	backtrace_symbols_fd(array, size, 2);
	exit(1);
} /* void handler(int sig) */
#endif



WaitForData()
{
  x_IFX_CLI_Cmd xCLICmd;
  fd_set xReadFdS;
  fd_set xWriteFdS;
  fd_set xExceptFdS;
  int32 iRead=0;
  while(1){
    FD_ZERO(&xReadFdS);
		FD_ZERO(&xWriteFdS);
		FD_SET(viFromDectAppFd, &xReadFdS);// cosic drvier
    select(FD_SETSIZE, &xReadFdS, &xWriteFdS, NULL, NULL);
    if (FD_ISSET (viFromDectAppFd, &xReadFdS))
    {
      iRead=read (viFromDectAppFd, &xCLICmd, sizeof (x_IFX_CLI_Cmd));
			if(iRead >0){
        printf(" The Responce from the Modem received\n");
				switch(xCLICmd.Event){
					case IFX_CLI_GET_BMC_IND:
			      printf(" The Get Request for BMC Register read arrived\n");	
										printf("\t\t\t\t\tBMC PARAMETERS\n\n");
										printf("\t\t\t\t\tRSSI Free Level    \t\t%x\n",xCLICmd.xCLI.xBMC.ucRSSIFreeLevel);
										printf("\t\t\t\t\tRSSI Busy Level    \t\t%x\n",xCLICmd.xCLI.xBMC.ucRSSIBusyLevel);
										printf("\t\t\t\t\tBearer chg Lim     \t\t%x\n",xCLICmd.xCLI.xBMC.ucBearerChgLim);
										printf("\t\t\t\t\tDelay Reg          \t\t%x\n",xCLICmd.xCLI.xBMC.ucDelayReg);
										printf("\t\t\t\t\tDefault Antenna    \t\t%x\n",xCLICmd.xCLI.xBMC.ucDefaultAntenna);
										printf("\t\t\t\t\tDRON Ctrl Reg      \t\t%x\n",xCLICmd.xCLI.xBMC.ucCNTUPCtrlReg);
										printf("\t\t\t\t\tWOPNSF            \t\t%x\n",xCLICmd.xCLI.xBMC.ucWOPNSF);
										printf("\t\t\t\t\tWWSF              \t\t%x\n",xCLICmd.xCLI.xBMC.ucWWSF);
								  	printf("\t\t\t\t\tGen Mode Ctrl 12  \t\t%x\n",xCLICmd.xCLI.xBMC.ucSYNCMCtrlReg);
										printf("\t\t\t\t\tHand Over Eval Per\t\t%x\n",xCLICmd.xCLI.xBMC.ucHandOverEvalper);
										printf("\t\t\t\t\tGENMUTCTRL0       \t\t%x\n",xCLICmd.xCLI.xBMC.ucGENMUTCTRL0);
										printf("\t\t\t\t\tGENMUTCTRL1       \t\t%x\n",xCLICmd.xCLI.xBMC.ucGENMUTCTRL1);
										printf("\t\t\t\t\tEXTMUTCTRL0       \t\t%x\n",xCLICmd.xCLI.xBMC.ucEXTMUTCTRL0);
	
						return;
					case IFX_CLI_GET_XRAM_IND:
			      printf(" The Get Request for	Xram Read Arrived\n");
                   	printf("\t\t\t\t\tXRAM PARAMETERS\n\n");
										printf("\t\t\t\t\tAddress          \t\t%x\n",xCLICmd.xCLI.xRam.uiAddr);
										printf("\t\t\t\t\tByte 0           \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[0]);
										printf("\t\t\t\t\tByte 1           \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[1]);
										printf("\t\t\t\t\tByte 2           \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[2]);
										printf("\t\t\t\t\tByte 3           \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[3]);
										printf("\t\t\t\t\tByte 4           \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[4]);
										printf("\t\t\t\t\tByte 5           \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[5]);
										printf("\t\t\t\t\tByte 6           \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[6]);
										printf("\t\t\t\t\tByte 7           \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[7]);
										printf("\t\t\t\t\tByte 8          \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[8]);
										printf("\t\t\t\t\tByte 9          \t\t%x\n",xCLICmd.xCLI.xRam.acBuffer[9]);
										printf("\t\t\t\t\tLength Maccess  \t\t%x\n",xCLICmd.xCLI.xRam.ucLength_Maccess);
						return;
					case IFX_CLI_GET_TPC_IND:
			      printf(" The Get Request for	TPC Read Arrived\n");
										printf("\t\t\t\t\tTRANSMIT POWER PARAMETERS\n\n");
										printf("\t\t\t\t\tTune Digit Ref\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTuneDigitalRef);
										printf("\t\t\t\t\tPA Bias Ref\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPABiasRef);
								 		printf("\t\t\t\t\tPower Offset 0\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[0]);
										printf("\t\t\t\t\tPower Offset 1\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[1]);
										printf("\t\t\t\t\tPower Offset 2\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[2]);
										printf("\t\t\t\t\tPower Offset 3\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[3]);
										printf("\t\t\t\t\tPower Offset 4\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[4]);
										printf("\t\t\t\t\tTD 1          \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTD1);
										printf("\t\t\t\t\tTD 2          \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTD2);
										printf("\t\t\t\t\tTD 3         \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTD3);
										printf("\t\t\t\t\tPA 1         \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPA1);
										printf("\t\t\t\t\tPA 2         \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPA2);
										printf("\t\t\t\t\tPA 3         \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPA3);
										printf("\t\t\t\t\tSW Power Mode\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucSWPowerMode);
										printf("\t\t\t\t\tTXPOW 0      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_0);
										printf("\t\t\t\t\tTXPOW 1      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_1);
										printf("\t\t\t\t\tTXPOW 2      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_2);
										printf("\t\t\t\t\tTXPOW 3      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_3);
										printf("\t\t\t\t\tTXPOW 4      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_4);
										printf("\t\t\t\t\tTXPOW 5      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_5);
										printf("\t\t\t\t\tDB Pow       \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucDBPOW);
										printf("\t\t\t\t\tTune Digital \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTuneDigital);
										printf("\t\t\t\t\tTxBias       \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTxBias);
						return;
				}
       }
    }
  }

}
int main()
{

	x_IFX_CLI_Cmd xCLICmd;
char *mainMenu[] = {"MAIN MENU",
                   "DECT",
                    "VOIP"
                   };

char *dectMenu[] = {
"DECT MENU",
"Diagnostics",
"Configuration"};

char *diagnosticsMenu[] = {
"DIAGNOSTICS MENU",
"Transmit Power Param",
"BMC Parameters",
"XRAM Parameters",
"RF Mode",
"OSC Trim Values",
"GFSK Values",
"RFPI Parameters",
"Reset Modem",
"Country Settings",
"TBR6",
"Save To Flash",
"XRAM Get",
"BMC Get",
"TPC Get"};


	//char b[256];
	char a[16][128]={0};
  int32 iLoop = 0;
#ifndef MURALI
	signal(SIGSEGV, handler);
#endif	
	viToDectAppFd = socket (PF_UNIX, SOCK_DGRAM,(int32) NULL);
	if (viToDectAppFd < 0)
	{
		perror ("To CLI Socket creation error");
	  return IFX_FAILURE;
	}                           
								 
  viFromDectAppFd = socket (PF_UNIX, SOCK_DGRAM,(int32) NULL);
	if (viFromDectAppFd < 0)
	{
		perror ("From CLI Socket creation error");
		return IFX_FAILURE;
	}                           

  FILE_name.sun_family = AF_UNIX;//PF_FILE;
	strcpy (FILE_name.sun_path, "/tmp/ToCli");
	size = offsetof (struct sockaddr_un, sun_path) +strlen (FILE_name.sun_path) + 1;

	if (bind (viFromDectAppFd, (struct sockaddr *) &FILE_name, size) < 0)
	{
		perror ("From CLI socket Bind error");         
		return IFX_FAILURE;
	}
	
	FILE_name.sun_family = AF_UNIX;//PF_FILE;
	strcpy (FILE_name.sun_path, "/tmp/FromCli");
	size = offsetof (struct sockaddr_un, sun_path) +strlen (FILE_name.sun_path) + 1;

/*	if(bind (viToDectAppFd, (struct sockaddr *) &FILE_name, size) < 0)
	{
	  perror ("To CLI Socket Bind error");         
	  return IFX_FAILURE;
	}*/
	
  
  arg1 = fcntl (viToDectAppFd, F_GETFL, NULL);
  arg1 |= O_NONBLOCK;
  fcntl (viToDectAppFd, F_SETFL, arg1);
   
  arg1 = fcntl (viFromDectAppFd, F_GETFL, NULL);
  arg1 |= O_NONBLOCK;
  fcntl (viFromDectAppFd, F_SETFL, arg1);
 

xCLICmd.Event =IFX_CLI_DIAG_MODE;
xCLICmd.xCLI.ucIsDiag =1;
sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);

while(1)									//to repeat till exit is selected
{
						do    					//to support Previous menu
						{							
								previous=0;				
							 	displayMenu(diagnosticsMenu,14); //Displays diagnosticsMenu
								system("clear");	
							do {
								switch(choice)
								{
									case IFX_CLI_DECT_DIAG_TPC:
										xCLICmd.Event = IFX_CLI_GET_TPC_REQ;
										/* Get existing values */
                    ifx_getrc_Tpc(&xCLICmd.xCLI.xTPCParams);
										printf("\t\t\t\t\tTRANSMIT POWER PARAMETERS\n\n");
										printf("\t\t\t\t1\tTune Digit Ref\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTuneDigitalRef);
										printf("\t\t\t\t2\tPA Bias Ref\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPABiasRef);
								 		printf("\t\t\t\t3\tPower Offset 0\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[0]);
										printf("\t\t\t\t4\tPower Offset 1\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[1]);
										printf("\t\t\t\t5\tPower Offset 2\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[2]);
										printf("\t\t\t\t6\tPower Offset 3\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[3]);
										printf("\t\t\t\t7\tPower Offset 4\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPowerOffset[4]);
										printf("\t\t\t\t8\tTD 1          \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTD1);
										printf("\t\t\t\t9\tTD 2          \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTD2);
										printf("\t\t\t\t10\tTD 3         \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTD3);
										printf("\t\t\t\t11\tPA 1         \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPA1);
										printf("\t\t\t\t12\tPA 2         \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPA2);
										printf("\t\t\t\t13\tPA 3         \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucPA3);
										printf("\t\t\t\t14\tSW Power Mode\t\t%x\n",xCLICmd.xCLI.xTPCParams.ucSWPowerMode);
										printf("\t\t\t\t15\tTXPOW 0      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_0);
										printf("\t\t\t\t16\tTXPOW 1      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_1);
										printf("\t\t\t\t17\tTXPOW 2      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_2);
										printf("\t\t\t\t18\tTXPOW 3      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_3);
										printf("\t\t\t\t19\tTXPOW 4      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_4);
										printf("\t\t\t\t20\tTXPOW 5      \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTXPOW_5);
										printf("\t\t\t\t21\tDB Pow       \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucDBPOW);
									//	printf("\t\t\t\t22\tTune Digital \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTuneDigital);
										printf("\t\t\t\t22\tTxBias       \t\t%x\n",xCLICmd.xCLI.xTPCParams.ucTxBias);
										commonMenu(22);
                    if(invalidChoice||previous )break;									  
										if(choice == 1 || choice == 23){
											printf("\t\t\t\t Enter Tune Digital Reference:");
											xCLICmd.xCLI.xTPCParams.ucTuneDigitalRef=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
										if(choice == 2 || choice == 23){
											printf("\t\t\t\t Enter PA Bias:");
											xCLICmd.xCLI.xTPCParams.ucPABiasRef=getInput(IFX_CLI_UNSIGNED_CHAR);				                  }
                    if(choice == 3 || choice == 23){
											printf("\t\t\t\t Enter Power Offset 0:");
											xCLICmd.xCLI.xTPCParams.ucPowerOffset[0]=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 4 || choice == 23){
											printf("\t\t\t\t Enter Power Offset 1:");
											xCLICmd.xCLI.xTPCParams.ucPowerOffset[1]=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 5 || choice == 23){
											printf("\t\t\t\t Enter Power Offset 2:");
											xCLICmd.xCLI.xTPCParams.ucPowerOffset[2]=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 6 || choice == 23){
											printf("\t\t\t\t Enter Power Offset 3:");
											xCLICmd.xCLI.xTPCParams.ucPowerOffset[3]=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 7 || choice == 23){
											printf("\t\t\t\t Enter Power Offset 4:");
											xCLICmd.xCLI.xTPCParams.ucPowerOffset[4]=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 8 || choice == 23){
											printf("\t\t\t\t Enter TD1:");
											xCLICmd.xCLI.xTPCParams.ucTD1=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 9 || choice == 23){
											printf("\t\t\t\t Enter TD2:");
											xCLICmd.xCLI.xTPCParams.ucTD2=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 10 || choice == 23){
											printf("\t\t\t\t Enter TD3:");
											xCLICmd.xCLI.xTPCParams.ucTD3=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 11 || choice == 23){
											printf("\t\t\t\t Enter PA1:");
											xCLICmd.xCLI.xTPCParams.ucPA1=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 12 || choice == 23){
											printf("\t\t\t\t Enter PA2:");
											xCLICmd.xCLI.xTPCParams.ucPA2=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 13 || choice == 23){
											printf("\t\t\t\t Enter PA3:");
											xCLICmd.xCLI.xTPCParams.ucPA3=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 14 || choice == 23){
											printf("\t\t\t\t Enter SW Power Mode:");
											xCLICmd.xCLI.xTPCParams.ucSWPowerMode=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 15 || choice == 23){
											printf("\t\t\t\t Enter TX Power 0:");
											xCLICmd.xCLI.xTPCParams.ucTXPOW_0=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 16 || choice == 23){
											printf("\t\t\t\t Enter TX Power 1:");
											xCLICmd.xCLI.xTPCParams.ucTXPOW_1=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 17 || choice == 23){
											printf("\t\t\t\t Enter TX Power 2:");
											xCLICmd.xCLI.xTPCParams.ucTXPOW_2=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 18 || choice == 23){
											printf("\t\t\t\t Enter TX Power 3:");
											xCLICmd.xCLI.xTPCParams.ucTXPOW_3=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 19 || choice == 23){
											printf("\t\t\t\t Enter TX Power 4:");
											xCLICmd.xCLI.xTPCParams.ucTXPOW_4=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 20 || choice == 23){
											printf("\t\t\t\t Enter TX Power 5:");
											xCLICmd.xCLI.xTPCParams.ucTXPOW_5=getInput(IFX_CLI_UNSIGNED_CHAR);
										}	
                    if(choice == 21 || choice == 23){
											printf("\t\t\t\t Enter DB Power :");
											xCLICmd.xCLI.xTPCParams.ucDBPOW=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    /*if(choice == 22 || choice == 23){
											printf("\t\t\t\t Enter Tune Digital:");
											xCLICmd.xCLI.xTPCParams.ucTuneDigital=getInput(IFX_CLI_UNSIGNED_CHAR);
										}*/
                    if(choice == 22 || choice == 23){
											printf("\t\t\t\t Enter Tx Bias:");
											xCLICmd.xCLI.xTPCParams.ucTxBias=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                  ifx_setrc_Tpc(&xCLICmd.xCLI.xTPCParams);
									xCLICmd.Event = IFX_CLI_SET_TPC_REQ;
									sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);


									break;
									case IFX_CLI_DECT_DIAG_BMC:
										xCLICmd.Event = IFX_CLI_GET_BMC_REQ;
										/* Get Existing Values */
                    ifx_getrc_Bmc(&xCLICmd.xCLI.xBMC);
										printf("\t\t\t\t\tBMC PARAMETERS\n\n");
										printf("\t\t\t\t1\tRSSI Free Level    \t\t%x\n",xCLICmd.xCLI.xBMC.ucRSSIFreeLevel);
										printf("\t\t\t\t2\tRSSI Busy Level    \t\t%x\n",xCLICmd.xCLI.xBMC.ucRSSIBusyLevel);
										printf("\t\t\t\t3\tBearer chg Lim     \t\t%x\n",xCLICmd.xCLI.xBMC.ucBearerChgLim);
										printf("\t\t\t\t4\tDelay Reg          \t\t%x\n",xCLICmd.xCLI.xBMC.ucDelayReg);
										printf("\t\t\t\t5\tDefault Antenna    \t\t%x\n",xCLICmd.xCLI.xBMC.ucDefaultAntenna);
										printf("\t\t\t\t6\tDRON Ctrl Reg      \t\t%x\n",xCLICmd.xCLI.xBMC.ucCNTUPCtrlReg);
										printf("\t\t\t\t7\tWOPNSF            \t\t%x\n",xCLICmd.xCLI.xBMC.ucWOPNSF);
										printf("\t\t\t\t8\tWWSF              \t\t%x\n",xCLICmd.xCLI.xBMC.ucWWSF);
								  	printf("\t\t\t\t9\tGen Mode Ctrl 12  \t\t%x\n",xCLICmd.xCLI.xBMC.ucSYNCMCtrlReg);
										printf("\t\t\t\t10\tHand Over Eval Per\t\t%x\n",xCLICmd.xCLI.xBMC.ucHandOverEvalper);
										commonMenu(11);
                    if(invalidChoice||previous )break;									  
										if(choice == 1 || choice == 12){ 
											printf("\t\t\t\t Enter RSSI Free Level:");
											xCLICmd.xCLI.xBMC.ucRSSIFreeLevel=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 2 || choice == 12){ 
											printf("\t\t\t\t Enter RSSI Busy Level:");
											xCLICmd.xCLI.xBMC.ucRSSIBusyLevel=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 3 || choice == 12) {
											printf("\t\t\t\t Enter Bearer Change Limit:");
											xCLICmd.xCLI.xBMC.ucBearerChgLim=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 4 || choice == 12) {
											printf("\t\t\t\t Enter Delay Register:");
											xCLICmd.xCLI.xBMC.ucDelayReg=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 5 || choice == 12) {
											printf("\t\t\t\t Enter Default Antenna:");
											xCLICmd.xCLI.xBMC.ucDefaultAntenna=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 6 || choice == 12) {
											printf("\t\t\t\t Enter DRON Cotrol Reg:");
											xCLICmd.xCLI.xBMC.ucCNTUPCtrlReg=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 7 || choice == 12) {
											printf("\t\t\t\t Enter WOPNSF:");
											xCLICmd.xCLI.xBMC.ucWOPNSF=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 8 || choice == 12) {
											printf("\t\t\t\t Enter WWSF:");
											xCLICmd.xCLI.xBMC.ucWWSF=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 9 || choice == 12) {
											printf("\t\t\t\t Enter SyncGenral Mode Control:");
											xCLICmd.xCLI.xBMC.ucSYNCMCtrlReg=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 10 || choice == 12) {
											printf("\t\t\t\t Enter Handover Evaluation period:");
											xCLICmd.xCLI.xBMC.ucHandOverEvalper=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    ifx_setrc_Bmc(&xCLICmd.xCLI.xBMC);
										xCLICmd.Event = IFX_CLI_SET_BMC_REQ;
									sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);
										
	  							break;

									case IFX_CLI_DECT_DIAG_XRAM:
										printf("\t\t\t\t\tXRAM PARAMETERS\n\n");
										printf("\t\t\t\t1\tAddress          \t\t\n");
										commonMenu(1);
                    if(invalidChoice||previous )break;									  
										printf("\t\t\t\tEnter Address:");
										if(choice == 1 || choice == 2) 
											xCLICmd.xCLI.xRam.uiAddr=getInput(IFX_CLI_INT16);
                    printf("\t\t\t\tEnter 1st Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[0]=getInput(IFX_CLI_UNSIGNED_CHAR);
                    printf("\t\t\t\tEnter 2nd Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[1]=getInput(IFX_CLI_UNSIGNED_CHAR);
                    printf("\t\t\t\tEnter 3rd Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[2]=getInput(IFX_CLI_UNSIGNED_CHAR);
                    printf("\t\t\t\tEnter 4th Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[3]=getInput(IFX_CLI_UNSIGNED_CHAR);
                    printf("\t\t\t\tEnter 5th Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[4]=getInput(IFX_CLI_UNSIGNED_CHAR);
                    printf("\t\t\t\tEnter 6th Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[5]=getInput(IFX_CLI_UNSIGNED_CHAR);
                    printf("\t\t\t\tEnter 7th Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[6]=getInput(IFX_CLI_UNSIGNED_CHAR);
                    printf("\t\t\t\tEnter 8th Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[7]=getInput(IFX_CLI_UNSIGNED_CHAR);
                    printf("\t\t\t\tEnter 9th Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[8]=getInput(IFX_CLI_UNSIGNED_CHAR);
                    printf("\t\t\t\tEnter 10th Bytes:"); 
										xCLICmd.xCLI.xRam.acBuffer[9]=getInput(IFX_CLI_UNSIGNED_CHAR);
                   printf("The address is %x and the 5th byte is %x\n",
                           xCLICmd.xCLI.xRam.uiAddr,xCLICmd.xCLI.xRam.acBuffer[5]);
											xCLICmd.xCLI.xRam.ucLength_Maccess=10;
										xCLICmd.Event = IFX_CLI_SET_XRAM_REQ;
									sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);

									break;
									case IFX_CLI_DECT_DIAG_RFMODE:
                   ifx_getrc_RfMode(&xCLICmd.xCLI.xRFMode.ucRFMode,
										     &xCLICmd.xCLI.xRFMode.ucChannelNumber,
												 &xCLICmd.xCLI.xRFMode.ucSlotNumber);
									  printf("\t\t\t\t\tRF MODE\n\n");
										printf("\t\t\t\t1\tRF Mode          \t\t%x\n",xCLICmd.xCLI.xRFMode.ucRFMode);
										printf("\t\t\t\t2\tChannel Number   \t\t%x\n",xCLICmd.xCLI.xRFMode.ucChannelNumber);
										printf("\t\t\t\t3\tSlot Number      \t\t%x\n",xCLICmd.xCLI.xRFMode.ucSlotNumber);
										commonMenu(3);	
                    if(invalidChoice||previous )break;									  
										
										if(choice == 1 || choice == 4){
											printf("\t\t\t\tEnter RF Mode:");
											xCLICmd.xCLI.xRFMode.ucRFMode=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 2 || choice == 4){
											printf("\t\t\t\tEnter Channel Number:");
											xCLICmd.xCLI.xRFMode.ucChannelNumber=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 3 || choice == 4){
											printf("\t\t\t\tEnter Slot Number:");
											xCLICmd.xCLI.xRFMode.ucSlotNumber=getInput(IFX_CLI_UNSIGNED_CHAR);
										}

                    ifx_setrc_RfMode(xCLICmd.xCLI.xRFMode.ucRFMode,
												             xCLICmd.xCLI.xRFMode.ucChannelNumber,
																		 xCLICmd.xCLI.xRFMode.ucSlotNumber);

									  xCLICmd.Event = IFX_CLI_SET_RFMODE_REQ;
									  sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,
												   (struct sockaddr *) &FILE_name,size);
									break;
									case IFX_CLI_DECT_DIAG_OSC:
	                  ifx_getrc_Osc(&xCLICmd.xCLI.xOsc.uiOscTrimValue,
												          &xCLICmd.xCLI.xOsc.ucP10Status);
										printf("\t\t\t\t\tOSC TRIM VALUES\n\n");
										printf("\t\t\t\t1\tOSC Trim Value   \t\t%x\n",xCLICmd.xCLI.xOsc.uiOscTrimValue);
										printf("\t\t\t\t2\tP10Status        \t\t%x\n",xCLICmd.xCLI.xOsc.ucP10Status);
										commonMenu(2);
                    if(invalidChoice||previous )break;									  

										if(choice == 1 || choice == 3){
											printf("\t\t\t\tEnter 16bit Osc Trim Values:");
											xCLICmd.xCLI.xOsc.uiOscTrimValue=getInput(IFX_CLI_INT16);
										}
                    if(choice == 2 || choice == 3){
											printf("\t\t\t\tEnter p10 Status:");
											xCLICmd.xCLI.xOsc.ucP10Status=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    ifx_setrc_Osc(xCLICmd.xCLI.xOsc.uiOscTrimValue,
												xCLICmd.xCLI.xOsc.ucP10Status);
										xCLICmd.Event = IFX_CLI_SET_OSC_REQ;
									sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);

									break;
									case IFX_CLI_DECT_DIAG_GFSK:
                    ifx_getrc_Gfsk(&xCLICmd.xCLI.unGfskValue);
									printf("\t\t\t\t\tGFSK VALUE\n\n");
										printf("\t\t\t\t1\tGFSK Value       \t\t%x\n",xCLICmd.xCLI.unGfskValue);
										commonMenu(1);
                    if(invalidChoice||previous )break;									  

										if(choice == 1 || choice == 2){
										  printf("\t\t\t\tEnter GFSK VALUE:");
											xCLICmd.xCLI.unGfskValue=getInput(IFX_CLI_INT16);
										}
										ifx_setrc_Gfsk(xCLICmd.xCLI.unGfskValue);
	  										xCLICmd.Event = IFX_CLI_SET_GFSK_REQ;
									sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);


									break;
									case IFX_CLI_DECT_DIAG_RFPI:
                 ifx_getrc_Rfpi(xCLICmd.xCLI.acRFPI);   
								 printf("\t\t\t\t\tRFPI PARAMETERS\n\n");
                    printf("\t\t\t\t1\tByte 0           \t\t%x\n",xCLICmd.xCLI.acRFPI[0]);
                    printf("\t\t\t\t2\tByte 1           \t\t%x\n",xCLICmd.xCLI.acRFPI[1]);
                    printf("\t\t\t\t3\tByte 2           \t\t%x\n",xCLICmd.xCLI.acRFPI[2]);
                    printf("\t\t\t\t4\tByte 3           \t\t%x\n",xCLICmd.xCLI.acRFPI[3]);
                    printf("\t\t\t\t5\tByte 4           \t\t%x\n",xCLICmd.xCLI.acRFPI[4]);
										commonMenu(5);
                    if(invalidChoice||previous )break;									  

										if(choice == 1 || choice == 6){
                      printf("\t\t\t\t\t Enter Byte 0:");
										  xCLICmd.xCLI.acRFPI[0]=getInput(IFX_CLI_CHAR);
										}
										if(choice == 2 || choice == 6){
                      printf("\t\t\t\t\t Enter Byte 1:");
											xCLICmd.xCLI.acRFPI[1]=getInput(IFX_CLI_CHAR);
										}
										if(choice == 3 || choice == 6){
                      printf("\t\t\t\t\t Enter Byte 2:");
											xCLICmd.xCLI.acRFPI[2]=getInput(IFX_CLI_CHAR);
										}
										if(choice == 4 || choice == 6){
                      printf("\t\t\t\t\t Enter Byte 3:");
											xCLICmd.xCLI.acRFPI[3]=getInput(IFX_CLI_CHAR);
										}
										if(choice == 5 || choice == 6){
                      printf("\t\t\t\t\t Enter Byte 4:");
											xCLICmd.xCLI.acRFPI[4]=getInput(IFX_CLI_CHAR);
										}
                 ifx_setrc_Rfpi(xCLICmd.xCLI.acRFPI);   
										xCLICmd.Event = IFX_CLI_SET_RFPI_REQ;
									sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);

									break;
									case IFX_CLI_DECT_DIAG_RESET_MODEM:
										
										xCLICmd.Event = IFX_CLI_MODEM_RESET;
									sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);

										
									break;
									case IFX_CLI_DECT_DIAG_COUNTRY_SETTINGS:


                  ifx_getrc_Freq(&xCLICmd.xCLI.xFreq.ucFreqTx,
										 	&xCLICmd.xCLI.xFreq.ucFreqRx,
										 	&xCLICmd.xCLI.xFreq.ucFreqRange);
								 	 printf("\t\t\t\t\tCOUNTRY SETTINGS\n\n");
										printf("\t\t\t\t1\tFreq Tx Offset   \t\t%x\n",xCLICmd.xCLI.xFreq.ucFreqTx);
										printf("\t\t\t\t2\tFreq Rx Offset   \t\t%x\n",xCLICmd.xCLI.xFreq.ucFreqRx);
										printf("\t\t\t\t3\tFreq Range       \t\t%x\n",xCLICmd.xCLI.xFreq.ucFreqRange);
										commonMenu(3);
                    if(invalidChoice||previous )break;									  

										if(choice == 1 || choice == 4){
										  printf("\t\t\t\t\t Enter Freq Tx Offset:");
											xCLICmd.xCLI.xFreq.ucFreqTx=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 2 || choice == 4){
										  printf("\t\t\t\t\t Enter Freq Rx Offset:");
											xCLICmd.xCLI.xFreq.ucFreqRx=getInput(IFX_CLI_UNSIGNED_CHAR);
										}
                    if(choice == 3 || choice == 4){
										  printf("\t\t\t\t\t Enter Freq Range:");
											xCLICmd.xCLI.xFreq.ucFreqRange=getInput(IFX_CLI_UNSIGNED_CHAR);
										}

                  ifx_setrc_Freq(xCLICmd.xCLI.xFreq.ucFreqTx,
										 	xCLICmd.xCLI.xFreq.ucFreqRx,
										 	xCLICmd.xCLI.xFreq.ucFreqRange);
									 										xCLICmd.Event = IFX_CLI_SET_FREQ_REQ;
									sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);

									break;
									case IFX_CLI_DECT_DIAG_TBR6:
									{
										printf("\t\t\t\t\t TBR6 ON(1)/OFF(0):");
										xCLICmd.xCLI.ucIsTBR6=getInput(IFX_CLI_UNSIGNED_CHAR);
									  xCLICmd.Event = IFX_CLI_SET_TBR6_REQ;
									  sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);
                  }
									break;
									case IFX_CLI_DECT_DIAG_SAVE_TO_FLASH /*11*/:
									     system("/etc/rc.d/backup");
                    break;
                  case IFX_CLI_DECT_DIAG_GET_XRAM /*12*/:
										xCLICmd.Event = IFX_CLI_GET_XRAM_REQ;
										printf("\t\t\t\t\tXRAM PARAMETERS\n\n");
										printf("\t\t\t\t1\tEnter the Address\t\t\n");
										xCLICmd.xCLI.xRam.uiAddr=getInput(IFX_CLI_INT16);
										xCLICmd.xCLI.xRam.ucLength_Maccess=10;
                    printf("The address Entered is %x\n",xCLICmd.xCLI.xRam.uiAddr);
									  sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);
                    WaitForData();
                    break;
                  case IFX_CLI_DECT_DIAG_GET_BMC /*13*/:
										xCLICmd.Event = IFX_CLI_GET_BMC_REQ;
									  sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);
                    WaitForData();
                   break;
                  case IFX_CLI_DECT_DIAG_GET_TPC /*14*/:
										xCLICmd.Event = IFX_CLI_GET_TPC_REQ;
									  sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);
                    WaitForData();
                   break;
									default:
										printf("\t\t\t\t\tDefault\n\n");
										clearState=1;
		               	displayMenu(diagnosticsMenu,14);
								}
							if(invalidChoice)
										choice=prevChoice;
							      invalidChoice =0;
							}while(invalidChoice);
						}while(previous==1);
}
xCLICmd.Event =IFX_CLI_DIAG_MODE;
xCLICmd.xCLI.ucIsDiag =0;
sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);
close(viToDectAppFd);
close(viFromDectAppFd);
sleep(2);
return 0;
}
void displayMenu(char **menu,int size)
{
int menuItem=1;
x_IFX_CLI_Cmd xCLICmd;
system("clear");
if(clearState != 0)
{
clearState=0;
}
choice =0;
//  printf("\t\t\t\t\tCLI\n\n");
	printf("\n\n\t\t\t\t    %s\n",menu[0]);
	for(menuItem=1;menuItem<=size;menuItem++)
	{
		printf("\t\t\t\t%d\t%s\n",menuItem,menu[menuItem]);
	}
	printf("\t\t\t\t%d\tExit\n",menuItem);
	printf("\t\t\t\tSelect an option :: ");
  LtqScanf("%d",&choice);
	printf("\t\t\t\t%d\t choice \n",choice);
	if(choice == size+1)
	{
		system("clear");
    xCLICmd.Event =IFX_CLI_DIAG_MODE;
    xCLICmd.xCLI.ucIsDiag =0;
    sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);
		unlink("/tmp/ToCli");
		sleep(2);
		exit(0);
	}
}
void commonMenu(int id)
{
x_IFX_CLI_Cmd xCLICmd;
prevChoice=choice;	
printf("\t\t\t\t%d\tSET ALL\n",id+1);
printf("\t\t\t\t%d\tPrevious Menu\n",id+2);
printf("\t\t\t\t%d\tEXIT\n\n",id+3);
printf("\t\t\t\tSelect an option :: ");
LtqScanf("%d",&choice);
system("clear");
if(choice == id+3)
	{
 		system("clear");
    xCLICmd.Event =IFX_CLI_DIAG_MODE;
    xCLICmd.xCLI.ucIsDiag =0;
    sendto(viToDectAppFd,&xCLICmd,sizeof(xCLICmd),0,(struct sockaddr *) &FILE_name,size);
		unlink("/tmp/ToCli");
		sleep(2);
		exit(0);
	
 	}
else if(choice == id+2)
  {
		previous=1; 					//make it common true/false
	}
else if(choice > id+3)
		{
		invalidChoice=1;
		}
}
int getInput(e_IFX_CLI_DateType type)
{
int validity=0;
switch(type)
{
case IFX_CLI_INT16:
	do{
		//if( validity != 0 )
			printf("Enter a value between 0 & 65535 ::");
		LtqScanf("%x",&validity);
	 }while(validity >= 0 || validity <= 65535 );
	break;
case IFX_CLI_CHAR:
	 do{
		 //if( validity != 0 )
		   printf("Enter a value between 0 & 127 ::");
		 LtqScanf("%x",&validity);
	 }while( validity >= 0 || validity <= 127 );
	break;
case IFX_CLI_UNSIGNED_CHAR:
	 do{
		 //if( validity != 0 )
		   printf("Enter a value between 0 & 255 ::");
		 LtqScanf("%x",&validity);
	 }while( validity >= 0 || validity <= 255 );
  break;
}
return 	validity;
}

