// =============================================================================
/*!
 * \file       inc/hanfun/agent.h
 *
 * This file contains the definitions for Lantiq's HAN-FUN Agent.
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================
#ifndef HF_AGENT_H
#define HF_AGENT_H

#include "hanfun/agent/config.h"
#include "hanfun/agent/version.h"

// =============================================================================
// Defines
// =============================================================================

#define HF_AGENT_SOCKET_PATH   "/tmp/hanfun"

#ifndef HF_SOCKET_FLAGS
   #define HF_SOCKET_FLAGS     SOCK_STREAM
#endif

// =============================================================================
// HAN-FUN Agent C API
// =============================================================================

#ifdef __cplusplus
extern "C"
{
#endif

typedef int boolean;
#include <ltq-voip-common/ifx_common_defs.h>
#include <ltq-dect/IFX_DECT_ULE.h>
#include <ltq-dect/IFX_DECT_MU.h>

#define __LINUX__   1
#include <ltq-voip-common/ifx_debug.h>

extern uchar8 vucDectAgnetModId;

extern void IFX_DECT_ULE_GetPVCConnectedDevices (uint8_t *size, x_IFX_DECT_ULE_Device_IPUI *buffer);

// =============================================================================
// IFX_HANFUN_Initialize
// =============================================================================
/*!
 * Initialize the HAN-FUN Agent.
 *
 * This function setups the server listening on the UNIX socket to receive the
 * connection.
 *
 * @retval IFX_SUCCESS  if initialization was OK,
 * @retval IFX_FAILURE  otherwise.
 */
// =============================================================================
e_IFX_Return IFX_HANFUN_Initialize ();

// =============================================================================
// IFX_HANFUN_Teardown
// =============================================================================
/*!
 * Release the system resources allocated by the HAN-FUN Agent.
 */
// =============================================================================
void IFX_HANFUN_Teardown ();

// =============================================================================
// IFX_HANFUN_Notify
// =============================================================================
/*!
 * This function is used to report the DECT ULE Toolkit events to the HAN-FUN
 * transport layer.
 *
 * @param [in] ucInstanceId  the PP ID that the event is for.
 * @param [in] pxULENotify   a pointer to structure containing the event information.
 *
 * @retval IFX_SUCCESS  if everything was OK,
 * @retval IFX_FAILURE  otherwise.
 */
// =============================================================================
e_IFX_Return IFX_HANFUN_Notify (uchar8 ucInstanceId, x_IFX_DECT_ULE_NotifyEvent *pxULENotify);

// =============================================================================
// IFX_HANFUN_ReceiveData
// =============================================================================
/*!
 * This function is used to send data received by the ULE stack (packet mode)
 * to the HAN-FUN transport layer.
 *
 * @param [in] ucInstanceId   the PP ID that the data is from.
 * @param [in] unSize         the number of bytes in the message.
 * @param [in] pData          a pointer to the buffer containing the received data.
 *
 * @retval IFX_SUCCESS  if everything was OK,
 * @retval IFX_FAILURE  otherwise.
 */
// =============================================================================
e_IFX_Return IFX_HANFUN_ReceiveData (uchar8 ucInstanceId, uint16 unSize, void *pData);

// =============================================================================
// IFX_HANFUN_ReceiveMessage
// =============================================================================
/*!
 * This function is used to send data received by the ULE stack (circuit mode)
 * to the HAN-FUN transport layer.
 *
 * @param [in] ucInstanceId   the PP ID that the data is from.
 * @param [in] unSize         the number of bytes in the message.
 * @param [in] pData          a pointer to the buffer containing the received data.
 *
 * @retval IFX_SUCCESS  if everything was OK,
 * @retval IFX_FAILURE  otherwise.
 */
// =============================================================================
e_IFX_Return IFX_HANFUN_ReceiveMessage (uchar8 ucInstanceId, uint16 unSize, void *pData);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus

   #include <hanfun.h>

   #include "debug.h"

   #include <vector>
   #include <deque>

namespace HF
{
   /*!
    * Top-level namespace for the classes implementing the HAN-FUN Agent.
    */
   namespace Agent
   {
      /*!
       * Helper struct that describes the version implemented by the HAN-FUN
       * application.
       */
      struct Version
      {
         uint8_t core;        //!< HAN-FUN Core Services & Interfaces version.
         uint8_t profiles;    //!< HAN-FUN Profiles version.
         uint8_t interfaces;  //!< HAN-FUN Interfaces version.
      };

      /*!
       * This class represents a byte array.
       *
       * The method in this class are used to serialize the messages to be sent over the
       * network, converting between the host's endianness and the big-endian network format.
       */
      struct ByteArray:public std::vector <uint8_t>
      {
         /*!
          * Create a byte array with the given initial size.
          *
          * @param size the initial size of the byte array.
          */
         ByteArray(size_t size = 0);

         /*!
          * Create a byte array with the given initial data.
          *
          * @param data    data to initialize the byte array with.
          * @param size    size in bytes of the data.
          */
         ByteArray(const uint8_t data[], const size_t size);

         /*!
          * Create byte array from the values in the given list.
          *
          * @param raw  values to add to the byte array.
          */
         ByteArray(std::initializer_list <uint8_t> raw):vector (raw)
         {}

         //! Destructor
         virtual ~ByteArray() {}

         /*!
          * Write a byte into the array at the given \c offset.
          *
          * @param [in] offset  offset to write the byte to.
          * @param [in] data    byte value to write to the array.
          *
          * @return  number of bytes written (1).
          */
         size_t write (size_t offset, uint8_t data);

         /*!
          * Write a word in the big endian format into the
          * array at the given \c offset.
          *
          * \warning If the host is NOT big-endian the value will
          *          be converted before being written.
          *
          * @param [in] offset  offset to write the word to.
          * @param [in] data    word value to write to the array.
          *
          * @return  number of bytes written (2).
          */
         size_t write (size_t offset, uint16_t data);

         /*!
          * Write a double-word in big endian format into the
          * array at the given \c offset.
          *
          * \warning If the host is NOT big-endian the value will
          *          be converted before being written.
          *
          * @param [in] offset  offset to write the double-word to.
          * @param [in] data    double-word value to write to the array.
          *
          * @return  number of bytes written (4).
          */
         size_t write (size_t offset, uint32_t data);

         //! \see  ByteArray::write (size_t, uint8_t)
         size_t write (size_t offset, bool data)
         {
            return write (offset, static_cast <uint8_t>(data));
         }

         /*!
          * Read the byte at \c offset into \c data.
          *
          * @param [in]  offset  offset to read the byte from.
          * @param [out] data    reference to save the read value to.
          *
          * @return  number of bytes read (1).
          */
         size_t read (size_t offset, uint8_t &data) const;

         /*!
          * Read the word in big-endian format at \c offset into \c data.
          *
          * \warning If the host is NOT big-endian the value will
          *          be converted to the host's Endianness.
          *
          * @param [in]  offset  offset to read the word from.
          * @param [out] data    reference to save the read value to.
          *
          * @return  number of bytes read (2).
          */
         size_t read (size_t offset, uint16_t &data) const;

         /*!
          * Read the double-word in big-endian format at \c offset into \c data.
          *
          * \warning If the host is NOT big-endian the value will
          *          be converted to the host's Endianness.
          *
          * @param [in]  offset  offset to read the double-word from.
          * @param [out] data    reference to save the read value to.
          *
          * @return  number of bytes read (4).
          */
         size_t read (size_t offset, uint32_t &data) const;

         //! \see  ByteArray::read (size_t, uint8_t)
         size_t read (size_t offset, bool &data) const
         {
            uint8_t temp;
            size_t  result = read (offset, temp);

            data = (temp & 0x01) != 0;

            return result;
         }

         /*!
          * Check if the array as at least \c expected bytes
          * available from the given \c offset.
          *
          * @param offset     the offset from where to start counting.
          * @param expected   the number of byte required.
          *
          * @retval  true if enough data is available,
          * @retval  false otherwise.
          */
         bool available (size_t offset, size_t expected) const
         {
            return expected <= available (offset);
         }

         /*!
          * Return the number of data bytes available from the given \c offset.
          *
          * @param offset     the offset from where to start counting.
          *
          * @return  number of data bytes available from the given \c offset.
          */
         size_t available (size_t offset) const
         {
            return (size () >= offset ? size () - offset : 0);
         }

         bool operator ==(const ByteArray &other)
         {
            return (this->size () == other.size () &&
                    std::equal (this->begin (), this->end (), other.begin ()));
         }

         bool operator !=(const ByteArray &other)
         {
            return !(*this == other);
         }

         /*!
          * Extend the byte array by the given size.
          *
          * This is the same as calling : array.reserve(array.size() + _size)
          *
          * @param [in] _size number of bytes to extent the array by.
          */
         void extend (size_t _size)
         {
            vector <uint8_t>::reserve (size () + _size);
         }
      };

      // =============================================================================
      // Message API
      // =============================================================================

      /*!
       * Parent class for message exchanged by the HAN-FUN Agent.
       */
      struct Message
      {
         typedef uint8_t size_type;

         /*!
          * Message types.
          */
         typedef enum _Type
         {
            UNKNOWN            = 0x00, //!< Unknown Message
            HELLO              = 0x10, //!< Hello Message
            HELLO_REPLY        = 0x11, //!< Hello Reply Message
            REGISTRATION_START = 0x20, //!< Registration Start Message
            REGISTRATION_STOP  = 0x21, //!< Registration Stop Message
            DEREGISTER_DEVICE  = 0x22, //!< De-register Device Message
            CONNECTED          = 0x30, //!< Connected Event Message
            DISCONNECTED       = 0x31, //!< Disconnected Event Message
            DATA               = 0x32  //!< Data Message
         } Type;

         uint8_t _size;    //!< Size read from the ByteArray when unpacking.
         uint8_t type;     //!< Message Type.

         Message(uint8_t _type = UNKNOWN):
            type (_type)
         {}

         virtual ~Message()
         {}

         virtual size_type size () const;

         size_type         pack (HF::Agent::ByteArray &array, size_type offset = 0) const;

         size_type         unpack (HF::Agent::ByteArray const &array, size_type offset = 0);
      };

      /*!
       * This class represents an HELLO message.
       */
      struct Hello:public Message
      {
         uint16_t emc;

         Version  version;

         Hello(uint16_t _emc = 0, uint8_t _core = HF::CORE_VERSION,
               uint8_t _profiles = HF::PROFILES_VERSION,
               uint8_t _interfaces = HF::INTERFACES_VERSION):
            Message (HELLO), emc (_emc), version (
               {
                  _core, _profiles, _interfaces
               }
                                                 )
         {}

         virtual ~Hello()
         {}

         size_type size () const;

         size_type pack (HF::Agent::ByteArray &array, size_type offset = 0) const;

         size_type unpack (HF::Agent::ByteArray const &array, size_type offset = 0);
      };

      /*!
       * This class represents an HELLO_REPLY message.
       */
      struct HelloReply:public Message
      {
         uint8_t rfpi[IFX_DECT_MAX_RFPI_LEN];

         HelloReply():
            Message (HELLO_REPLY)
         {}

         HelloReply(uint8_t _rfpi[]):
            Message (HELLO_REPLY)
         {
            memcpy (this->rfpi, _rfpi, IFX_DECT_MAX_RFPI_LEN);
         }

         virtual ~HelloReply()
         {}

         size_type size () const;

         size_type pack (HF::Agent::ByteArray &array, size_type offset = 0) const;

         size_type unpack (HF::Agent::ByteArray const &array, size_type offset = 0);
      };

      /*!
       * This class represents an REGISTRATION_START message.
       */
      struct RegistrationStart:public Message
      {
         uint16_t timeout;

         RegistrationStart(uint16_t _timeout = 0):
            Message (REGISTRATION_START), timeout (_timeout)
         {}

         size_type size () const;

         size_type pack (HF::Agent::ByteArray &array, size_type offset = 0) const;

         size_type unpack (HF::Agent::ByteArray const &array, size_type offset = 0);
      };

      /*!
       * This class represents an REGISTRATION_STOP message.
       */
      struct RegistrationStop:public Message
      {
         RegistrationStop():
            Message (REGISTRATION_STOP)
         {}

         size_type unpack (HF::Agent::ByteArray const &array, size_type offset = 0);
      };

      /*!
       * This is the parent class for all messages that address a particular
       * device.
       */
      struct DeviceMessage:public Message
      {
         uint16_t device;

         DeviceMessage(uint8_t _type, uint16_t _device = 0):
            Message (_type), device (_device)
         {}

         virtual ~DeviceMessage()
         {}

         size_type size () const;

         size_type pack (HF::Agent::ByteArray &array, size_type offset = 0) const;

         size_type unpack (HF::Agent::ByteArray const &array, size_type offset = 0);
      };

      /*!
       * This class represents an DEREGISTER message.
       */
      struct DeregisterDevice:public DeviceMessage
      {
         DeregisterDevice(uint16_t _device = 0):
            DeviceMessage (DEREGISTER_DEVICE, _device)
         {}

         virtual ~DeregisterDevice()
         {}
      };

      /*!
       * This message represents a CONNECTED message.
       */
      struct Connected:public DeviceMessage
      {
         uint8_t ipui[IFX_DECT_IPUI_SIZE];

         Connected(uint16_t _device, uint8_t _ipui[IFX_DECT_IPUI_SIZE]):
            DeviceMessage (CONNECTED, _device)
         {
            memset (this->ipui, 0xFF, sizeof(this->ipui));
            memcpy (this->ipui, _ipui, IFX_DECT_IPUI_SIZE);
         }

         Connected(uint16_t _device = 0):
            DeviceMessage (CONNECTED, _device)
         {}

         size_type size () const;

         size_type pack (HF::Agent::ByteArray &array, size_type offset = 0) const;

         size_type unpack (HF::Agent::ByteArray const &array, size_type offset = 0);
      };

      /*!
       * This message represents a DISCONNECTED message.
       */
      struct Disconnected:public DeviceMessage
      {
         Disconnected(uint16_t _device = 0):
            DeviceMessage (DISCONNECTED, _device)
         {}

         virtual ~Disconnected()
         {}
      };

      /*!
       * This message represents a DATA message.
       */
      struct Data:public DeviceMessage
      {
         HF::Agent::ByteArray payload;

         Data(uint16_t _device = 0):
            DeviceMessage (DATA, _device)
         {}

         Data(uint16_t _device, HF::Agent::ByteArray &_payload):
            DeviceMessage (DATA, _device), payload (_payload)
         {}

         Data(uint16_t _device, uint16_t size):
            DeviceMessage (DATA, _device), payload (size)
         {}

         size_type size () const;

         size_type pack (HF::Agent::ByteArray &array, size_type offset = 0) const;

         size_type unpack (HF::Agent::ByteArray const &array, size_type offset = 0);
      };

      // =============================================================================
      // API
      // =============================================================================

      /*!
       * Top-level class for the HAN-FUN Agent implementation.
       */
      class Abstract
      {
         public:

         template<typename T>
         bool send (T &msg) const
         {
            HF::Agent::ByteArray buffer (msg.size ());

            msg.pack (buffer);

            return write (buffer);
         }

         bool receive ()
         {
            HF::Agent::ByteArray buffer;

            if (!read (buffer))
            {
               LOG (ERROR) << "Could not read from socket !!" << NL;
               return false;
            }

            handle (buffer);

            return true;
         }

         protected:

         // =============================================================================
         // Events
         // =============================================================================

         /*!
          * Handle incoming message.
          *
          * @param [in] data  reference to a ByteArray containing the incomming data.
          */
         void handle (HF::Agent::ByteArray &data);

         /*!
          *
          * @param msg
          */
         virtual void handle (Hello &msg)
         {
            UNUSED (msg);
            LOG (ERROR)
               << __PRETTY_FUNCTION__ << " : This should not be called !";
         }

         /*!
          *
          * @param msg
          */
         virtual void handle (HelloReply &msg)
         {
            UNUSED (msg);
            LOG (ERROR)
               << __PRETTY_FUNCTION__ << " : This should not be called !";
         }

         /*!
          *
          * @param msg
          */
         virtual void handle (RegistrationStart &msg)
         {
            UNUSED (msg);
            LOG (ERROR)
               << __PRETTY_FUNCTION__ << " : This should not be called !";
         }

         /*!
          *
          * @param msg
          */
         virtual void handle (RegistrationStop &msg)
         {
            UNUSED (msg);
            LOG (ERROR)
               << __PRETTY_FUNCTION__ << " : This should not be called !";
         }

         /*!
          *
          * @param msg
          */
         virtual void handle (DeregisterDevice &msg)
         {
            UNUSED (msg);
            LOG (ERROR)
               << __PRETTY_FUNCTION__ << " : This should not be called !";
         }

         /*!
          *
          * @param msg
          */
         virtual void handle (Connected &msg)
         {
            UNUSED (msg);
            LOG (ERROR)
               << __PRETTY_FUNCTION__ << " : This should not be called !";
         }

         /*!
          *
          * @param msg
          */
         virtual void handle (Disconnected &msg)
         {
            UNUSED (msg);
            LOG (ERROR)
               << __PRETTY_FUNCTION__ << " : This should not be called !";
         }

         /*!
          *
          * @param msg
          */
         virtual void handle (Data &msg)
         {
            UNUSED (msg);
            LOG (ERROR)
               << __PRETTY_FUNCTION__ << " : This should not be called !";
         }

         // =============================================================================
         // Helper methods.
         // =============================================================================

         /*!
          * Write the contents of \c buffer into the socket descriptor, \c fd.
          *
          * @param [IN] fd       the socket descriptor.
          * @param [IN] buffer   buffer with the data to write to.
          *
          * @retval  true     if the write succeed,
          * @retval  false    otherwise.
          */
         bool write (int fd, HF::Agent::ByteArray &buffer) const;

         virtual bool write (HF::Agent::ByteArray &buffer) const = 0;

         /*!
          * Read contents in the socket descriptor \c fd into the \c buffer.
          *
          * @param [IN]  fd       the socket descriptor.
          * @param [OUT] buffer   the buffer to read the data into.
          *
          * @retval  true     if the read was succeed,
          * @retval  false    otherwise.
          */
         bool read (int fd, HF::Agent::ByteArray &buffer) const;

         virtual bool read (HF::Agent::ByteArray &buffer) const = 0;
      };

      /*!
       * HAN-FUN Agent implementation : Server side.
       */
      struct Server:public Abstract
      {
         bool               inited;

         int                fd;
         int                client;

         std::set <uint8_t> devices;

         std::deque <Data>  messages;

         Server():
            inited (false), fd (-1), client (-1)
         {}

         virtual ~Server()
         {
            destroy ();
         }

         // =============================================================================
         // API
         // =============================================================================

         void initialize ();

         void destroy ();

         bool accept ();

         void connected (uint8_t device, uint8_t ipui[IFX_DECT_IPUI_SIZE]);

         void disconnected (uint8_t device);

         protected:

         // =============================================================================
         // Events
         // =============================================================================

         using Abstract::handle;

         void handle (Hello &msg);

         void handle (RegistrationStart &msg);

         void handle (RegistrationStop &msg);

         void handle (DeregisterDevice &msg);

         void handle (Data &msg);

         // =============================================================================
         // Helper Functions
         // =============================================================================

         bool write (HF::Agent::ByteArray &buffer) const
         {
            LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

            if (this->client != -1)
            {
               LOG (TRACE) << "[HANFUN] Writing to socket !" << NL;
               return Abstract::write (this->client, buffer);
            }
            else
            {
               return false;
            }
         }

         bool read (HF::Agent::ByteArray &buffer) const
         {
            LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

            if (this->client != -1)
            {
               return Abstract::read (this->client, buffer);
            }
            else
            {
               return false;
            }
         }
      };

      // Forward declaration.
      struct Link;

      /*!
       * HAN-FUN Agent implementation : Client Size.
       */
      struct Client:public Abstract, public HF::Devices::Concentrator::Transport
      {
         const uint16_t emc;

         int            fd; //!< Socket descriptor to send/receive messages from.

         Client(uint16_t _emc = 0):
            emc (_emc)
         {}

         virtual ~Client()
         {
            destroy ();
         }

         void initialize ();

         void destroy ();

         using Abstract::receive;

         bool registration_start (uint16_t timeout);

         bool registration_stop ();

         void deregister (uint16_t address);

         protected:

         void handle (HelloReply &msg);

         void handle (Connected &msg);

         void handle (Disconnected &msg);

         void handle (Data &msg);

         Link *find_by_id (uint16_t id);

         bool write (HF::Agent::ByteArray &buffer) const
         {
            if (this->fd != -1)
            {
               return Abstract::write (this->fd, buffer);
            }
            else
            {
               return false;
            }
         }

         bool read (HF::Agent::ByteArray &buffer) const
         {
            if (this->fd != -1)
            {
               return Abstract::read (this->fd, buffer);
            }
            else
            {
               return false;
            }
         }
      };

      /*!
       * HAN-FUN Agent's HF::Transport::Link implementation.
       */
      struct Link:public HF::Transport::AbstractLink
      {
         const uint16_t      id;

         const HF::UID::DECT ipui;

         const Client        *client;

         Link(uint16_t _id, HF::UID::DECT &_ipui, Client *_client):
            HF::Transport::AbstractLink (), id (_id), ipui (_ipui), client (_client)
         {}

         virtual ~Link() {}

         void send (HF::Common::ByteArray &array);

         const HF::UID::UID uid () const
         {
            return HF::UID::UID((HF::UID::DECT *) &ipui);
         }

         HF::Transport::Layer const *transport () const
         {
            return client;
         }
      };

   }  // namespace Agent

}  // namespace HF

// =============================================================================
// Helper Functions for unit testing.
// =============================================================================

   #ifndef NDEBUG
void IFX_HANFUN_Server (HF::Agent::Server *server);
   #endif

#endif

#endif /* HF_AGENT_H */
