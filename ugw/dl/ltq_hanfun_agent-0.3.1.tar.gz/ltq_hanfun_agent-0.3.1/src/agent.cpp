// =============================================================================
/*!
 * \file       src/agent.c
 *
 * This file contains the implementation of the agent
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================

#include <iomanip>
#include <string>       // std::string
#include <sstream>      // std::stringstream, std::stringbuf

#include <cinttypes>

#include <assert.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <limits.h>

/* According to POSIX.1-2001 */
#include <sys/select.h>

/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

//#define HF_LOG_LEVEL   HF_LOG_TRACE_LEVEL
#include "hanfun/agent.h"

#include "external.h"

// =============================================================================
// Defines
// =============================================================================

// =============================================================================
// Global Variables.
// =============================================================================

#ifdef NDEBUG
static HF::Agent::Server g_server;
   #define hf_agent   g_server
#else
static HF::Agent::Server *g_server = nullptr;
   #define hf_agent   (*g_server)
#endif

// =============================================================================
// Helper functions.
// =============================================================================

static e_IFX_Return IFX_HF_Socket_Callback (int32 iFd)
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
             "[HANFUN] <Socket_Callback> ", iFd);

   if (iFd == hf_agent.fd)
   {
      if (!hf_agent.accept ())
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, "[HANFUN] Accept error : %s",
                   strerror (errno));
         return IFX_FAILURE;
      }

      x_IFX_MSGRTR_FdInfo fdInfo;

      fdInfo.uiFd       = (uint32) hf_agent.client;
      fdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;

      // Add server to message router.
      IFX_MSGRTR_FdCallBackRegister (&fdInfo, 1, IFX_HF_Socket_Callback);
   }
   else if (iFd == hf_agent.client)
   {
      if (!hf_agent.receive ())
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "[HANFUN] Could not read from socket !", "");

         x_IFX_MSGRTR_FdInfo fdInfo;

         fdInfo.uiFd       = (uint32) hf_agent.client;
         fdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;

         IFX_MSGRTR_FdUnregister (&fdInfo);

         hf_agent.client = -1;

         return IFX_FAILURE;
      }
   }

   return IFX_SUCCESS;
}

// =============================================================================
// IFX_HAN_FUN_ResetPVC
// =============================================================================
/*!
 *
 */
// =============================================================================
static void IFX_HANFUN_ResetPVC (uint8_t device)
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <ResetPVC>");

   // Reset connection to the device.
   if (IFX_SUCCESS != IFX_DECT_ULE_ResetPVC (device))
   {
      IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, "[HANFUN] Failed to reset the PVC.");
   }
}

// =============================================================================
// HAN-FUN Agent API
// =============================================================================

// =============================================================================
// IFX_HANFUN_Initialize
// =============================================================================
/*!
 *
 */
// =============================================================================
extern "C" e_IFX_Return IFX_HANFUN_Initialize ()
{
   // This makes sure that multiple calls to this function release previous held
   // resources.
   IFX_HANFUN_Teardown ();

   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Initialize>");

   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_NORMAL, IFX_DBG_STR, "[HANFUN] Agent version : %s", HF_AGENT_VERSION);

#ifdef NDEBUG
   g_server = HF::Agent::Server ();
#endif

   hf_agent.initialize ();

   if (hf_agent.inited)
   {
      x_IFX_MSGRTR_FdInfo fdInfo;

      fdInfo.uiFd       = (uint32) hf_agent.fd;
      fdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;

      // Add server to message router.
      IFX_MSGRTR_FdCallBackRegister (&fdInfo, 1, IFX_HF_Socket_Callback);

      return IFX_SUCCESS;
   }

   return IFX_FAILURE;
}

extern "C" void IFX_HANFUN_Teardown ()
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Teardown>");

   if (!(hf_agent.inited))
   {
      return;
   }

   x_IFX_MSGRTR_FdInfo fdInfo;

   fdInfo.uiFd       = (uint32) hf_agent.client;
   fdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;

   IFX_MSGRTR_FdUnregister (&fdInfo);

   fdInfo.uiFd       = (uint32) hf_agent.fd;
   fdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;

   IFX_MSGRTR_FdUnregister (&fdInfo);

   hf_agent.destroy ();
}

// =============================================================================
// IFX_HANFUN_Notify
// =============================================================================
/*!
 *
 */
// =============================================================================
extern "C" e_IFX_Return IFX_HANFUN_Notify (uchar8 ucInstanceId, x_IFX_DECT_ULE_NotifyEvent *pxULENotify)
{
   UNUSED (ucInstanceId);
   UNUSED (pxULENotify);

   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
             "[HANFUN] <Notification> DEVICE ID: ", ucInstanceId);

   switch (pxULENotify->eEvent)
   {
      case IFX_DECT_ULE_DEVICE_ATTACHED:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "[HANFUN] <Notification> DEVICE_ATTACHED");
         break;
      }

      case IFX_DECT_ULE_DEVICE_CPLANE_CONNECTED:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "[HANFUN] <Notification> IFX_DECT_ULE_DEVICE_CPLANE_CONNECTED");
         break;
      }

      case IFX_DECT_ULE_DEVICE_CPLANE_DISCONNECTED:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "[HANFUN] <Notification> IFX_DECT_ULE_DEVICE_CPLANE_DISCONNECTED");
         break;
      }

      case IFX_DECT_ULE_DEVICE_PVC_CONNECTED:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "[HANFUN] <Notification> DEVICE_VC_CONNECTED");

         hf_agent.connected (ucInstanceId, pxULENotify->uxNotify.acipui_array);

         break;
      }

      case IFX_DECT_ULE_DEVICE_PVC_DISCONNECTED:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> DEVICE_VC_DISCONNECTED");

         hf_agent.disconnected (ucInstanceId);

         break;
      }

      case IFX_DECT_ULE_EXP_DATACON_CONNECTED:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> EXP_DATACON_CONNECTED");
         break;
      }

      case IFX_DECT_ULE_HF_ATTRIBUTES:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> HF_ATTRIBUTES");
         // TODO Handle the HAN-FUN Attributes coming from the device.
         break;
      }

      case IFX_DECT_ULE_DATA_SENT_SUCCESS:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> DATA_SENT_SUCCESS");

         if (!hf_agent.messages.empty ())
         {
            HF::Agent::Data &data = hf_agent.messages.front ();
            IFX_DECT_ULE_DataSend ((uchar8) data.device, data.payload.size (),
                                   (void *) data.payload.data ());
            hf_agent.messages.pop_front ();
         }

         break;
      }

      case IFX_DECT_ULE_DATA_SENT_FAIL:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> DATA_SENT_SUCCESS");

         IFX_HANFUN_ResetPVC (ucInstanceId);

         break;
      }

      case IFX_DECT_ULE_DATA_SENT_FAIL_TIMEOUT:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> DATA_SENT_FAIL_TIMEOUT");

         IFX_HANFUN_ResetPVC (ucInstanceId);

         break;
      }

      case IFX_DECT_ULE_UPDATE_SUBS_INFO:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> ULE_UPDATE_SUBS_INFO");

         break;
      }

      case IFX_DECT_ULE_BPAGE_SUCCESS:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> BPAGE_SUCCESS");
         break;
      }

      case IFX_DECT_ULE_BPAGE_FAIL:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> BPAGE_FAIL");

         IFX_HANFUN_ResetPVC (ucInstanceId);

         break;
      }

      case IFX_DECT_ULE_BPAGE_FAIL_TIMEOUT:
      {
         IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] <Notification> BPAGE_FAIL_TIMEOUT");

         IFX_HANFUN_ResetPVC (ucInstanceId);

         break;
      }
   }

   return IFX_SUCCESS;
}

// =============================================================================
// HAN_FUN_ReceiveData
// =============================================================================
/*!
 *
 */
// =============================================================================
extern "C" e_IFX_Return IFX_HANFUN_ReceiveData (uchar8 ucInstanceId, uint16 unSize, void *pData)
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT, "[HANFUN] <ReceiveData> DEVICE ID: ", ucInstanceId);

   IFX_DECT_ULE_ReleaseExpConnection (ucInstanceId, IFX_DECT_ULE_NORMAL, 0);
   // IFX_DECT_ULE_ReleaseExpConnection(ucInstanceId, IFX_DECT_ULE_SETUP_AGAIN, 200);

   if (unSize == 0)
   {
      return IFX_SUCCESS;
   }

   uchar8 *pucData = (uchar8 *) pData;

   std::stringstream ss;

   ss << "[HANFUN] <ReceiveData>" << (int) ucInstanceId << " -> ";

   ss << std::hex << std::setw (2) << std::setfill ('0');

   for (int i = 0; i < unSize; i++)
   {
      ss << (int) pucData[i] << " ";
   }

   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, ss.str ().c_str ());

   HF::Agent::Data data (ucInstanceId, unSize);

   memcpy (data.payload.data (), pucData, unSize);

   return hf_agent.send (data) ? IFX_SUCCESS : IFX_FAILURE;
}

// =============================================================================
// HAN_FUN_ReceiveMessage
// =============================================================================
/*!
 *
 */
// =============================================================================
extern "C" e_IFX_Return IFX_HANFUN_ReceiveMessage (uchar8 ucInstanceId, uint16 unSize, void *pData)
{
   UNUSED (ucInstanceId);
   UNUSED (unSize);
   UNUSED (pData);

   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT, "[HANFUN] <ReceiveMessage> DEVICE ID: ", ucInstanceId);

   return IFX_SUCCESS;
}

// =============================================================================
// Unit Testing Helpers
// =============================================================================

#ifndef NDEBUG

// =============================================================================
// IFX_HANFUN_Server
// =============================================================================
/*!
 *
 */
// =============================================================================
void IFX_HANFUN_Server (HF::Agent::Server *server)
{
   g_server = server;
}

#endif
