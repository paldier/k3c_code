// =============================================================================
/*!
 * \file       src/client.cpp
 *
 * This file contains the implementation of the HAN-FUN Agent, client side.
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================
#include <cinttypes>

#include <assert.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <limits.h>

/* According to POSIX.1-2001 */
#include <sys/select.h>

/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include <hanfun.h>
#include <hanfun/debug.h>

#include "hanfun/agent.h"

using namespace HF::Agent;

// =============================================================================
// HF::Agent::Link
// =============================================================================

// =============================================================================
// Link::send
// =============================================================================
/*!
 *
 */
// =============================================================================
void Link::send (HF::Common::ByteArray &array)
{
   Data data (id);

   data.payload = HF::Agent::ByteArray (array.size ());

   std::copy (array.begin (), array.end (), data.payload.begin ());

   client->send (data);
}

// =============================================================================
// HF::Agent::Client
// =============================================================================

// =============================================================================
// Client::initialize
// =============================================================================
/*!
 *
 */
// =============================================================================
void Client::initialize ()
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   // Client initialization.
   if ((this->fd = socket (AF_UNIX, SOCK_STREAM, 0)) == -1)
   {
      LOG (ERROR) << __PRETTY_FUNCTION__ << " > Socket error : " << strerror (errno) << NL;
      this->fd = -1;
   }

   struct sockaddr_un addr;

   memset (&addr, 0, sizeof(addr));
   addr.sun_family = AF_UNIX;
   strncpy (addr.sun_path, HF_AGENT_SOCKET_PATH, sizeof(addr.sun_path) - 1);

   if (connect (this->fd, (struct sockaddr *) &addr, sizeof(addr)) == -1)
   {
      LOG (ERROR) << __PRETTY_FUNCTION__ << " > Connect error : " << strerror (errno) << NL;
      this->fd = -2;
   }

   // Send Hello Message.
   Hello msg (emc);

   send (msg);
}

// =============================================================================
// Client::destroy
// =============================================================================
/*!
 *
 */
// =============================================================================
void Client::destroy ()
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   if (this->fd != -1)
   {
      close (this->fd);
      this->fd = -1;
   }

   HF::Devices::Concentrator::Transport::destroy ();
}

// =============================================================================
// Client::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Client::handle (HelloReply &msg)
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   uid (new HF::UID::DECT (msg.rfpi));
}

// =============================================================================
// Client::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Client::handle (Connected &msg)
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   HF::UID::DECT ipui (msg.ipui);

   Link *link = new Link (msg.device, ipui, this);

   this->add (link);
}

// =============================================================================
// Client::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Client::handle (Disconnected &msg)
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   Link *link = find_by_id (msg.device);

   if (link != nullptr)
   {
      remove (link);
   }
}

// =============================================================================
// Client::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Client::handle (Data &msg)
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   Link *link = find_by_id (msg.device);

   if (link != nullptr)
   {
      HF::Common::ByteArray payload (msg.payload.size ());

      std::copy (msg.payload.begin (), msg.payload.end (), payload.begin ());

      HF::Transport::AbstractLayer::receive (link, payload);
   }
   else
   {
      LOG (ERROR) << "No link for device : " << msg.device << "!!" << NL;
   }
}

// =============================================================================
// Client::find_by_id
// =============================================================================
/*!
 *
 */
// =============================================================================
Link *Client::find_by_id (uint16_t id)
{
   auto it = std::find_if (links.begin (), links.end (), [id](HF::Transport::Link *link) {
                              return static_cast <HF::Agent::Link *>(link)->id == id;
                           }
                          );

   if (it != links.end ())
   {
      return static_cast <HF::Agent::Link *>(*it);
   }

   return nullptr;
}

// =============================================================================
// Client::registration
// =============================================================================
/*!
 *
 */
// =============================================================================
bool Client::registration_start (uint16_t timeout)
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   RegistrationStart msg (timeout);
   return send (msg);
}

// =============================================================================
// Client::registration_stop
// =============================================================================
/*!
 *
 */
// =============================================================================
bool Client::registration_stop ()
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   RegistrationStop msg;
   return send (msg);
}

// =============================================================================
// Client::deregister
// =============================================================================
/*!
 *
 */
// =============================================================================
void Client::deregister (uint16_t address)
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   Link *link = static_cast <Link *>(find (address));

   if (link != nullptr)
   {
      DeregisterDevice msg (link->id);
      send (msg);
   }
   else
   {
      LOG (WARN) << "No link found for address : " << address << NL;
   }
}
