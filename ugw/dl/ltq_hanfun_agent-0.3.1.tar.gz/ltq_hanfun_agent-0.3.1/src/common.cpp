// =============================================================================
/*!
 * \file       src/common.cpp
 *
 * This file contains the implementation for the common functionality.
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================
#include <algorithm>

#include <cinttypes>

#include <assert.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <limits.h>

/* According to POSIX.1-2001 */
#include <sys/select.h>

/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

//#define HF_LOG_LEVEL HF_LOG_LEVEL_TRACE
#include "hanfun/agent.h"

using namespace HF::Agent;

// =============================================================================
// Defines
// =============================================================================

/*
 * Fail fast when in debug mode.
 *
 * This allows unit tests to exit the read methods when no data is
 * available on the socket.
 */
#ifndef NDEBUG
   #undef TEMP_FAILURE_RETRY
   #define TEMP_FAILURE_RETRY(expression)   expression

   #define READ_FLAG_STAGE_1   MSG_PEEK | MSG_NOSIGNAL | MSG_DONTWAIT
   #define READ_FLAG_STAGE_2   MSG_NOSIGNAL | MSG_DONTWAIT

#else

   #define READ_FLAG_STAGE_1   MSG_PEEK | MSG_NOSIGNAL
   #define READ_FLAG_STAGE_2   MSG_NOSIGNAL

#endif

#define BYTE_1_MASK            0x000000FF
#define BYTE_2_MASK            0x0000FF00
#define BYTE_3_MASK            0x00FF0000
#define BYTE_4_MASK            0xFF000000

// =============================================================================
// API
// =============================================================================

// =============================================================================
// ByteArray
// =============================================================================

ByteArray::ByteArray(size_t size):vector (size, 0)
{}

ByteArray::ByteArray(const uint8_t data[], const size_t size):vector (size, 0)
{
   memcpy (this->data (), data, size);
}

// =============================================================================
// ByteArray::write
// =============================================================================
/*!
 *
 */
// =============================================================================
size_t ByteArray::write (size_t offset, uint8_t data)
{
   at (offset) = data;
   return sizeof(uint8_t);
}

// =============================================================================
// ByteArray::write
// =============================================================================
/*!
 *
 */
// =============================================================================
size_t ByteArray::write (size_t offset, uint16_t data)
{
   at (offset)     = (data & BYTE_2_MASK) >> 8;
   at (offset + 1) = (data & BYTE_1_MASK);

   return sizeof(uint16_t);
}

// =============================================================================
// ByteArray::write
// =============================================================================
/*!
 *
 */
// =============================================================================
size_t ByteArray::write (size_t offset, uint32_t data)
{
   at (offset)     = (data & BYTE_4_MASK) >> 24;
   at (offset + 1) = (data & BYTE_3_MASK) >> 16;
   at (offset + 2) = (data & BYTE_2_MASK) >> 8;
   at (offset + 3) = (data & BYTE_1_MASK);

   return sizeof(uint32_t);
}

// =============================================================================
// ByteArray::read
// =============================================================================
/*!
 *
 */
// =============================================================================
size_t ByteArray::read (size_t offset, uint8_t &data) const
{
   data = at (offset);
   return sizeof(uint8_t);
}

// =============================================================================
// ByteArray::read
// =============================================================================
/*!
 *
 */
// =============================================================================
size_t ByteArray::read (size_t offset, uint16_t &data) const
{
   data = ((uint16_t) at (offset)) << 8 | at (offset + 1);

   return sizeof(uint16_t);
}

// =============================================================================
// ByteArray::read
// =============================================================================
/*!
 *
 */
// =============================================================================
size_t ByteArray::read (size_t offset, uint32_t &data) const
{
   data  = ((uint32_t) at (offset)) << 24;
   data |= ((uint32_t) at (offset + 1)) << 16;
   data |= ((uint32_t) at (offset + 2)) << 8;
   data |= ((uint32_t) at (offset + 3));

   return sizeof(uint32_t);
}

// =============================================================================
// Messages API
// =============================================================================

// =============================================================================
// Message
// =============================================================================

// =============================================================================
// Message::size
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Message::size () const
{
   return sizeof(type) + sizeof(_size);
}

// =============================================================================
// Message::pack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Message::pack (HF::Agent::ByteArray &array, size_type offset) const
{
   Message::size_type start = offset;

   Message::size_type _size = this->size () - sizeof(this->_size);

   offset += array.write (offset, _size);
   offset += array.write (offset, this->type);

   return offset - start;
}

// =============================================================================
// Message::unpack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Message::unpack (HF::Agent::ByteArray const &array, size_type offset)
{
   Message::size_type start = offset;

   assert (this->size () <= (array.size () - offset));

   offset += array.read (offset, this->_size);

   uint8_t type;

   offset += array.read (offset, type);

   assert ((this->type == UNKNOWN) || (this->type != UNKNOWN && this->type == type));

   this->type = type;

   return offset - start;
}

// =============================================================================
// Hello Message.
// =============================================================================

// =============================================================================
// Hello::size
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Hello::size () const
{
   return Message::size () + sizeof(emc) + 3 * sizeof(uint8_t);
}

// =============================================================================
// Hello::pack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Hello::pack (HF::Agent::ByteArray &array, size_type offset) const
{
   size_type start = offset;

   offset += Message::pack (array, offset);

   offset += array.write (offset, this->emc);

   offset += array.write (offset, this->version.core);
   offset += array.write (offset, this->version.profiles);
   offset += array.write (offset, this->version.interfaces);

   return offset - start;
}

// =============================================================================
// Hello::unpack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Hello::unpack (HF::Agent::ByteArray const &array, size_type offset)
{
   size_type start = offset;

   offset += Message::unpack (array, offset);

   offset += array.read (offset, this->emc);

   offset += array.read (offset, this->version.core);
   offset += array.read (offset, this->version.profiles);
   offset += array.read (offset, this->version.interfaces);

   return offset - start;
}

// =============================================================================
// Hello Reply
// =============================================================================

// =============================================================================
// HelloReply::size
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type HelloReply::size () const
{
   return Message::size () + IFX_DECT_MAX_RFPI_LEN;
}

// =============================================================================
// HelloReply::pack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type HelloReply::pack (HF::Agent::ByteArray &array, size_type offset) const
{
   size_type start = offset;

   offset += Message::pack (array, offset);

   for (uint8_t i = 0; i < IFX_DECT_MAX_RFPI_LEN; i++)
   {
      offset += array.write (offset, rfpi[i]);
   }

   return offset - start;
}

// =============================================================================
// HelloReply::unpack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type HelloReply::unpack (HF::Agent::ByteArray const &array, size_type offset)
{
   size_type start = offset;

   offset += Message::unpack (array, offset);

   for (uint8_t i = 0; i < IFX_DECT_MAX_RFPI_LEN; i++)
   {
      offset += array.read (offset, rfpi[i]);
   }

   return offset - start;
}

// =============================================================================
// Registration Start
// =============================================================================

// =============================================================================
// RegistrationStart::size
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type RegistrationStart::size () const
{
   return Message::size () + sizeof(timeout);
}

// =============================================================================
// RegistrationStart::pack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type RegistrationStart::pack (HF::Agent::ByteArray &array, size_type offset) const
{
   size_type start = offset;

   offset += Message::pack (array, offset);

   offset += array.write (offset, this->timeout);

   return offset - start;
}

// =============================================================================
// RegistrationStart::unpack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type RegistrationStart::unpack (HF::Agent::ByteArray const &array, size_type offset)
{
   size_type start = offset;

   offset += Message::unpack (array, offset);

   offset += array.read (offset, this->timeout);

   return offset - start;
}

// =============================================================================
// Registration Stop
// =============================================================================

// =============================================================================
// RegistrationStop::unpack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type RegistrationStop::unpack (HF::Agent::ByteArray const &array, size_type offset)
{
   size_type start = offset;

   offset += Message::unpack (array, offset);

   return offset - start;
}

// =============================================================================
// DeviceMessage
// =============================================================================

// =============================================================================
// DeviceMessage::size
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type DeviceMessage::size () const
{
   return Message::size () + sizeof(device);
}

// =============================================================================
// DeviceMessage::pack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type DeviceMessage::pack (HF::Agent::ByteArray &array, size_type offset) const
{
   size_type start = offset;

   offset += Message::pack (array, offset);

   offset += array.write (offset, this->device);

   return offset - start;
}

// =============================================================================
// DeviceMessage::unpack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type DeviceMessage::unpack (HF::Agent::ByteArray const &array, size_type offset)
{
   size_type start = offset;

   offset += Message::unpack (array, offset);

   offset += array.read (offset, this->device);

   return offset - start;
}

// =============================================================================
// Connected
// =============================================================================

// =============================================================================
// Connected::size
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Connected::size () const
{
   return DeviceMessage::size () + IFX_DECT_IPUI_SIZE;
}

// =============================================================================
// Connected::pack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Connected::pack (HF::Agent::ByteArray &array, size_type offset) const
{
   size_type start = offset;

   offset += DeviceMessage::pack (array, offset);

   for (uint8_t i = 0; i < IFX_DECT_IPUI_SIZE; i++)
   {
      offset += array.write (offset, ipui[i]);
   }

   return offset - start;
}

// =============================================================================
// Connected::unpack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Connected::unpack (HF::Agent::ByteArray const &array, size_type offset)
{
   size_type start = offset;

   offset += DeviceMessage::unpack (array, offset);

   for (uint8_t i = 0; i < IFX_DECT_IPUI_SIZE; i++)
   {
      offset += array.read (offset, ipui[i]);
   }

   return offset - start;
}

// =============================================================================
// Data
// =============================================================================

// =============================================================================
// Data::size
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Data::size () const
{
   return DeviceMessage::size () + sizeof(uint16_t) + payload.size ();
}

// =============================================================================
// Data::pack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Data::pack (HF::Agent::ByteArray &array, size_type offset) const
{
   size_type start = offset;

   offset += DeviceMessage::pack (array, offset);

   uint16_t _size = payload.size ();

   offset += array.write (offset, _size);

   copy (payload.begin (), payload.end (), array.begin () + offset);

   offset += payload.size ();

   return offset - start;
}

// =============================================================================
// Data::unpack
// =============================================================================
/*!
 *
 */
// =============================================================================
Message::size_type Data::unpack (HF::Agent::ByteArray const &array, size_type offset)
{
   size_type start = offset;

   offset += DeviceMessage::unpack (array, offset);

   uint16_t _size = 0;

   offset += array.read (offset, _size);

   auto begin = array.begin () + offset;
   auto end   = begin + _size;

   this->payload = HF::Agent::ByteArray (_size);

   copy (begin, end, this->payload.begin ());

   offset += _size;

   return offset - start;
}

// =============================================================================
// HF::Agent::Abstract
// =============================================================================

// =============================================================================
// HF::Agent::Abstract::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Abstract::handle (HF::Agent::ByteArray &buffer)
{
   LOG (TRACE) << __PRETTY_FUNCTION__ << NL;

   Message hdr;

   hdr.unpack (buffer);

   switch (hdr.type)
   {
      case Message::HELLO:
      {
         Hello msg;
         msg.unpack (buffer);

         handle (msg);

         break;
      }

      case Message::HELLO_REPLY:
      {
         HelloReply msg;
         msg.unpack (buffer);

         handle (msg);

         break;
      }

      case Message::REGISTRATION_START:
      {
         RegistrationStart msg;
         msg.unpack (buffer);

         handle (msg);

         break;
      }

      case Message::REGISTRATION_STOP:
      {
         RegistrationStop msg;
         msg.unpack (buffer);

         handle (msg);

         break;
      }

      case Message::DEREGISTER_DEVICE:
      {
         DeregisterDevice msg;
         msg.unpack (buffer);

         handle (msg);

         break;
      }

      case Message::CONNECTED:
      {
         Connected msg;
         msg.unpack (buffer);

         handle (msg);

         break;
      }

      case Message::DISCONNECTED:
      {
         Disconnected msg;
         msg.unpack (buffer);

         handle (msg);

         break;
      }

      case Message::DATA:
      {
         Data msg;
         msg.unpack (buffer);

         handle (msg);

         break;
      }
      case Message::UNKNOWN:
      default:
      {
         LOG (ERROR) << "Invalid message type !" << NL;
         break;
      }
   }
}

// =============================================================================
// Abstract::write
// =============================================================================
/*!
 *
 */
// =============================================================================
bool Abstract::write (int fd, HF::Agent::ByteArray &buffer) const
{
   int count  = 0;
   int offset = 0;
   int nbytes = 0;

   for (count = buffer.size (), offset = 0; count > 0; count -= nbytes, offset += nbytes)
   {
      nbytes = TEMP_FAILURE_RETRY (::send (fd, buffer.data () + offset, count, MSG_NOSIGNAL));

      if (nbytes < 0)
      {
         if (errno == EAGAIN)
         {
            LOG (TRACE) << __PRETTY_FUNCTION__ << " : " << strerror (errno) << NL;
            nbytes = 0;
         }
         else
         {
            LOG (ERROR) << __PRETTY_FUNCTION__ << " : " << strerror (errno) << NL;
            return false;
         }
      }
   }

   return true;
}

// =============================================================================
// Abstract::read
// =============================================================================
/*!
 *
 */
// =============================================================================
bool Abstract::read (int fd, HF::Agent::ByteArray &buffer) const
{
   int count = sizeof(HF::Agent::Message::size_type);

   buffer.resize (count);

   int nbytes = TEMP_FAILURE_RETRY (recv (fd, buffer.data (), count, READ_FLAG_STAGE_1));

   if (nbytes <= 0)
   {
      goto _end;
   }

   HF::Agent::Message::size_type size;
   buffer.read (0, size);

   count += (int) size;

   buffer = HF::Agent::ByteArray (count);

   nbytes = TEMP_FAILURE_RETRY (recv (fd, buffer.data (), count, READ_FLAG_STAGE_2));

   if (nbytes <= 0)
   {
      _end:

      if (nbytes < 0)
      {
         LOG (ERROR) << __PRETTY_FUNCTION__ << " : " << strerror (errno) << NL;
      }

      return false;
   }

   return true;
}
