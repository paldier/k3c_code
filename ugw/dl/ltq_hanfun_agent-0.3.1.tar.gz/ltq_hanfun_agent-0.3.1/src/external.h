// =============================================================================
/*!
 * \file       src/external.h
 *
 * This file contains the forward declarations of functions that are external to
 * the HAN-FUN Agent.
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================

#ifndef HF_AGENT_EXTERNAL_H
#define HF_AGENT_EXTERNAL_H

extern "C"
{
   // =============================================================================
   // Forward declarations : Message Router
   // =============================================================================

   typedef enum
   {
      IFX_MSGRTR_READ_TYPE      = 1, /*!< Indicates the read FD */
      IFX_MSGRTR_WRITE_TYPE     = 2, /*!< Indicates the write FD */
      IFX_MSGRTR_EXCEPTION_TYPE = 4, /*!< Indicates the exception FD */
   } e_IFX_MSGRTR_FdType;

   typedef struct
   {
      uint32              uiFd;       /*!< The Fd that has to be added to the select*/
      e_IFX_MSGRTR_FdType eFdSetType; /*!< Read/Write/Exception set*/

   } x_IFX_MSGRTR_FdInfo;

   typedef e_IFX_Return (*pfn_IFX_MSGRTR_FdCallback) (int32 iFd);

   e_IFX_Return IFX_MSGRTR_FdCallBackRegister (x_IFX_MSGRTR_FdInfo *paxFdInfo, uchar8 ucNumFds,
                                               pfn_IFX_MSGRTR_FdCallback pfnFdCallback);

   e_IFX_Return IFX_MSGRTR_FdUnregister (x_IFX_MSGRTR_FdInfo *pxFdInfo);
}

#endif /* HF_AGENT_EXTERNAL_H */
