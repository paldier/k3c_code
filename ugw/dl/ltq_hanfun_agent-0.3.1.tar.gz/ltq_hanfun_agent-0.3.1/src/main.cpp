// =============================================================================
/*!
 * \file       src/main.cpp
 *
 * This file contains the implementation of the main
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================

#include <stdlib.h>
#include <assert.h>
#include <unistd.h>

#include <errno.h>

#include <hanfun/application.h>

#include "hanfun/agent.h"

// =============================================================================
// Defines
// =============================================================================

//! Example application registration timeout. 10m
#define REGISTRATION_TIMEOUT   60000

// =============================================================================
// Global Variables
// =============================================================================

static HF::Agent::Client *g_client;

// =============================================================================
// Helper Functions.
// =============================================================================

// =============================================================================
// HF::Application::Registration
// =============================================================================
/*!
 *
 */
// =============================================================================
bool HF::Application::Registration (bool mode)
{
   if (mode)
   {
      return g_client->registration_start (REGISTRATION_TIMEOUT);
   }
   else
   {
      return g_client->registration_stop ();
   }
}

// =============================================================================
// HF::Application::Deregister
// =============================================================================
/*!
 *
 */
// =============================================================================
void HF::Application::Deregister (uint16_t address)
{
   g_client->deregister (address);
}

// =============================================================================
// HF::Application::Saved
// =============================================================================
/*!
 *
 */
// =============================================================================
void HF::Application::Saved ()
{
   LOG (INFO) << "Application configuration saved !" << NL;

   // Call configuration backup script.
   system ("/etc/rc.d/backup_dect_config");
}

// =============================================================================
// HF::Application::Restored
// =============================================================================
/*!
 *
 */
// =============================================================================
void HF::Application::Restored ()
{
   LOG (INFO) << "Application configuration restored !" << NL;
}

// =============================================================================
// MAIN
// =============================================================================

int main (int argc, char **argv)
{
   UNUSED (argc);
   UNUSED (argv);

   HF::Agent::Client client;

   g_client = &client;

   HF::Application::Initialize (client);

   if (client.fd < 0)
   {
      LOG (ERROR) << "Could not initialize transport layer !!!" << NL;
      return -1;
   }

   bool quit = false;

   HF::Application::Handle ("h");

   do {
      fd_set readfds;
      FD_ZERO (&readfds);

      // Add stdin.
      FD_SET (0, &readfds);

      // Add transport socket.
      FD_SET (client.fd, &readfds);

      if (TEMP_FAILURE_RETRY (select (client.fd + 1, &readfds, NULL, NULL, NULL)) < 0)
      {
         LOG (ERROR) << "Select Error : " << strerror (errno) << NL;
         return -1;
      }

      // Read command from stdin
      if (FD_ISSET (0, &readfds))
      {
         std::string command;
         std::getline (std::cin, command);
         quit = HF::Application::Handle (command);
      }

      // Read from transport socket.
      if (FD_ISSET (client.fd, &readfds))
      {
         quit = !client.receive ();
      }

   } while (!quit);

   return 0;
}
