// =============================================================================
/*!
 * \file       src/server.cpp
 *
 * This file contains the implementation of the HAN-FUN Agent, the server side.
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================

#include <cinttypes>

#include <assert.h>
#include <errno.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <limits.h>

/* According to POSIX.1-2001 */
#include <sys/select.h>

/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include "hanfun/agent.h"

using namespace HF::Agent;

// =============================================================================
// API
// =============================================================================

// =============================================================================
// Server::initialize
// =============================================================================
/*!
 *
 */
// =============================================================================
void Server::initialize ()
{
   // Server initialization.
   struct sockaddr_un addr;

   if ((this->fd = socket (AF_UNIX, HF_SOCKET_FLAGS, 0)) == -1)
   {
      IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "[HANFUN] Socket error : %s", strerror (errno));
      return;
   }

   memset (&addr, 0, sizeof(addr));
   addr.sun_family = AF_UNIX;
   strncpy (addr.sun_path, HF_AGENT_SOCKET_PATH, sizeof(addr.sun_path) - 1);

   unlink (HF_AGENT_SOCKET_PATH);

   if (bind (this->fd, (struct sockaddr *) &addr, sizeof(addr)) == -1)
   {
      IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "[HANFUN] Bind error : %s", strerror (errno));
      close (this->fd);
      return;
   }

   // Only support one connection at a time.
   if (listen (this->fd, 0) == -1)
   {
      IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "[HANFUN] listen error : %s", strerror (errno));
      close (this->fd);
      return;
   }

   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "[HANFUN] Initialized !!");

   this->inited = true;
}

// =============================================================================
// Server::destroy
// =============================================================================
/*!
 *
 */
// =============================================================================
void Server::destroy ()
{
   if (!(this->inited))
   {
      return;
   }

   if (this->client != -1)
   {
      close (this->client);
   }

   if (this->fd != -1)
   {
      close (this->fd);
   }

   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "[HANFUN] Destroyed !!");

   this->inited = false;
}

// =============================================================================
// Server::accept
// =============================================================================
/*!
 *
 */
// =============================================================================
bool Server::accept ()
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Accepting socket connection !");
   return (this->client = ::accept (this->fd, NULL, NULL)) != -1;
}

void Server::connected (uint8_t device, uint8_t ipui[IFX_DECT_IPUI_SIZE])
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT, "[HANFUN] Device", device);

   HF::Agent::Connected msg (device, ipui);

   devices.insert (device);

   send (msg);
}

void Server::disconnected (uint8_t device)
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT, "[HANFUN] Device", device);

   HF::Agent::Disconnected msg (device);

   devices.erase (device);

   send (msg);
}

// =============================================================================
// Server::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Server::handle (Hello &msg)
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] Hello !!");

   // Read EMC and version.

   x_IFX_DECT_ULE_HF_Attributes attrs;

   attrs.axHFVer[0].ucProtoID      = 0x01;             // XXX What is this value ?
   attrs.axHFVer[0].ucProtoVer     = msg.version.core; // XXX HF Protocol has same version as core.
   attrs.axHFVer[0].ucCoreVer      = msg.version.core;
   attrs.axHFVer[0].ucProfVer      = msg.version.profiles;
   attrs.axHFVer[0].ucInterfaceVer = msg.version.interfaces;
   attrs.axHFVer[0].uiEMC          = msg.emc;
   // XXX attrs.uiMaxSDU_F2P = ???? What should be this value ?
   // XXX attrs.uiMaxSDU_P2F = ???? What should be this value ?

   IFX_DECT_ULE_ConfigureHF_Attributes (&attrs);

   // Send Hello Reply.
   HelloReply reply;

   // Read RFPI from DECT TK.
   IFX_DECT_GetRFPI (reply.rfpi);

   send (reply);

   // Check if any devices are connected.
   uint8_t count;
   x_IFX_DECT_ULE_Device_IPUI connected_devices[IFX_DECT_MAX_ULE_DEVICES];

   IFX_DECT_ULE_GetPVCConnectedDevices (&count, connected_devices);

   for (uint8_t i = 0; i < count; i++)
   {
      this->connected (connected_devices[i].ucDeviceId, connected_devices[i].acipui_array);
   }
}

// =============================================================================
// Server::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Server::handle (RegistrationStart &msg)
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] Registration Start !!!");

   IFX_DECT_MU_RegistrationAllow (msg.timeout, NULL);
}

// =============================================================================
// Server::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Server::handle (RegistrationStop &msg)
{
   UNUSED (msg);

   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] Registration Stop !!!");
   IFX_DECT_MU_RegistrationAllow (0, NULL);
}

// =============================================================================
// Server::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Server::handle (DeregisterDevice &msg)
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "[HANFUN] De-register Device ", msg.device);

   IFX_DECT_MU_UNRegister (false, msg.device);
}

// =============================================================================
// Server::handle
// =============================================================================
/*!
 *
 */
// =============================================================================
void Server::handle (Data &msg)
{
   IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT, "[HANFUN] Data to device :", msg.device);

   // Device is not connected. Drop message.
   if (devices.find (msg.device) == devices.end ())
   {
      IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, "[HANFUN] Device not connected !!");
      IFX_DBGA (vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, "[HANFUN] Dropping packet.");
      return;
   }

   // No messages queued. Send immediately.
   if (messages.empty ())
   {
      IFX_DECT_ULE_DataSend ((uchar8) msg.device, msg.payload.size (), (void *) msg.payload.data ());
   }
   else  // Queue the message for delivery.
   {
      messages.push_back (msg);
   }
}
