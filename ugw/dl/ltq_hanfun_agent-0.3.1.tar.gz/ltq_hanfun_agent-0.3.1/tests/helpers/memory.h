// =============================================================================
/*!
 * \file       tests/helpers/memory.h
 *
 * This file is used to make the used STL classes work with CppUTest memory leak
 * functionality.
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================

#ifndef HF_MEMORY_HELPER_H
#define HF_MEMORY_HELPER_H

#include <forward_list>
#include "CppUTest/MemoryLeakDetectorMallocMacros.h"

#endif /* HF_MEMORY_HELPER_H */
