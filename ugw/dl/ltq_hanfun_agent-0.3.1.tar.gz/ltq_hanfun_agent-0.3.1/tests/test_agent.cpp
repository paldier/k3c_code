// =============================================================================
/*!
 * \file       tests/test_agent.cpp
 *
 * This file contains the implementation of the test_agent
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================
#include "test_helper.h"

// =============================================================================
// Helper Classes
// =============================================================================

namespace
{
   struct Endpoint:public HF::Transport::Endpoint
   {
      void connected (HF::Transport::Link *link)
      {
         UNUSED (link);
         mock ("Endpoint").actualCall ("connected");
      }

      void disconnected (HF::Transport::Link *link)
      {
         std::stringstream ss;
         ss << link;

         mock ("Endpoint").actualCall ("disconnected"); // .withParameter("link", ss.str().c_str());
      }

      void receive (HF::Protocol::Packet &packet, HF::Common::ByteArray &payload, uint16_t offset)
      {
         UNUSED (offset);

         mock ("Endpoint").actualCall ("receive").withParameter ("link", packet.link);

         // Copy payload byte array to check in test.

         HF::Common::ByteArray *buffer = new HF::Common::ByteArray (payload);

         mock ("Endpoint").setData ("payload", buffer);
      }
   };

   struct Server:public HF::Agent::Server
   {
      virtual ~Server()
      {}

      void handle (HF::Agent::Hello &msg)
      {
         mock ("Server").actualCall ("handle::hello");
         HF::Agent::Server::handle (msg);
      }

      void handle (HF::Agent::RegistrationStart &msg)
      {
         mock ("Server").actualCall ("handle::registration_start");
         HF::Agent::Server::handle (msg);
      }

      void handle (HF::Agent::RegistrationStop &msg)
      {
         mock ("Server").actualCall ("handle::registration_stop");
         HF::Agent::Server::handle (msg);
      }

      void handle (HF::Agent::DeregisterDevice &msg)
      {
         mock ("Server").actualCall ("handle::deregister");
         HF::Agent::Server::handle (msg);
      }

      void handle (HF::Agent::Data &msg)
      {
         mock ("Server").actualCall ("handle::data");
         HF::Agent::Server::handle (msg);
      }
   };

   struct Client:public HF::Agent::Client
   {
      Client(uint16_t _emc = 0)
         :HF::Agent::Client(_emc)
      {}

      virtual ~Client()
      {}

      void handle (HF::Agent::HelloReply &msg)
      {
         mock ("Client").actualCall ("handle::hello_reply");

         char *rfpi = new char[IFX_DECT_MAX_RFPI_LEN];
         memcpy (rfpi, msg.rfpi, IFX_DECT_MAX_RFPI_LEN);

         mock ("Client").setData ("RFPI", rfpi);

         HF::Agent::Client::handle (msg);
      }

      void handle (HF::Agent::Connected &msg)
      {
         mock ("Client").actualCall ("handle::connected");
         HF::Agent::Client::handle (msg);
      }

      void handle (HF::Agent::Disconnected &msg)
      {
         mock ("Client").actualCall ("handle::disconnected");
         HF::Agent::Client::handle (msg);
      }

      void handle (HF::Agent::Data &msg)
      {
         mock ("Client").actualCall ("handle::data");
         HF::Agent::Client::handle (msg);
      }

      using HF::Agent::Client::find_by_id;
   };

}  // namespace

// =============================================================================
// HAN-FUN Agent Tests
// =============================================================================

//! Test HAN-FUN Initialization.
TEST_GROUP (AgentInit)
{
   Server *server;
   Client *client;

   TEST_SETUP ()
   {
      server = new Server ();
      client = new Client (0x5A5A);

      IFX_HANFUN_Server (server);

      mock ().ignoreOtherCalls ();
   }

   TEST_TEARDOWN ()
   {
      client->destroy ();

      CHECK_TRUE (client->fd == -1);

      IFX_HANFUN_Teardown ();

      delete client;
      delete server;

      mock ().clear ();
   }
};

//! Test HAN-FUN Agent initialization - call flow.
TEST (AgentInit, CallFlow)
{
   mock ("ifx_voip").expectOneCall ("IFX_MSGRTR_FdCallBackRegister");

   LONGS_EQUAL (IFX_SUCCESS, IFX_HANFUN_Initialize ());

   mock ("ifx_voip").checkExpectations ();

   client->initialize ();
   CHECK_TRUE (client->fd != -1);

   Select::Entry *agent_s =
      (Select::Entry *) mock ("ifx_voip").getData ("Select::Entry").getPointerValue ();

   // Should accept the client connection.
   mock ("ifx_voip").expectOneCall ("IFX_MSGRTR_FdCallBackRegister");

   CHECK_TRUE (agent_s->run ());

   mock ("ifx_voip").checkExpectations ();

   Select::Entry *agent_c =
      (Select::Entry *) mock ("ifx_voip").getData ("Select::Entry").getPointerValue ();

   const char *rfpi = "\x00\x73\x70\x00\x10";
   mock ("ifx_voip").setData ("RFPI", rfpi);

   // Should read the Hello message & send reply back.
   mock ("Server").expectOneCall ("handle::hello");
   mock ("ifx_voip").expectOneCall ("IFX_DECT_GetRFPI");

   mock ("ifx_voip").setData ("IFX_DECT_ULE_GetPVCConnectedDevices::size", 0);
   mock ("ifx_voip").expectOneCall ("IFX_DECT_ULE_GetPVCConnectedDevices");

   mock ("Client").expectOneCall ("handle::hello_reply");

   CHECK_TRUE (agent_c->run ());
   CHECK_TRUE (client->receive ());

   mock ().checkExpectations ();

   const char *rfpi_c = mock ("Client").getData ("RFPI").getStringValue ();

   CHECK_TRUE (memcmp (rfpi, rfpi_c, IFX_DECT_MAX_RFPI_LEN) == 0);

   delete[] rfpi_c;

   delete agent_s;
   delete agent_c;
}

//! Test HAN-FUN Agent initialization - call flow.
TEST (AgentInit, CallFlow2)
{
   LONGS_EQUAL (IFX_SUCCESS, IFX_HANFUN_Initialize ());

   client->initialize ();
   CHECK_TRUE (client->fd != -1);

   Select::Entry *agent_s =
      (Select::Entry *) mock ("ifx_voip").getData ("Select::Entry").getPointerValue ();

   // Should accept the client connection.
   CHECK_TRUE (agent_s->run ());

   Select::Entry *agent_c =
      (Select::Entry *) mock ("ifx_voip").getData ("Select::Entry").getPointerValue ();

   const char *rfpi = "\x00\x73\x70\x00\x10";
   mock ("ifx_voip").setData ("RFPI", rfpi);

   // Should read the Hello message & send reply back.
   x_IFX_DECT_ULE_Device_IPUI devices[2] =
   {
      {0x5A, {0x12, 0x34, 0x56, 0x78, 0x9A}
      },
      {0xAA, {0x9A, 0x78, 0x56, 0x34, 0x12}
      }
   };

   mock ("ifx_voip").setData ("IFX_DECT_ULE_GetPVCConnectedDevices::size", 2);
   mock ("ifx_voip").setData ("IFX_DECT_ULE_GetPVCConnectedDevices::devices", devices);
   mock ("ifx_voip").expectOneCall ("IFX_DECT_ULE_GetPVCConnectedDevices");

   mock ("Client").expectNCalls (2, "handle::connected");

   CHECK_TRUE (agent_c->run ());
   CHECK_TRUE (client->receive ());
   CHECK_TRUE (client->receive ());
   CHECK_TRUE (client->receive ());

   mock ().checkExpectations ();

   const char *rfpi_c = mock ("Client").getData ("RFPI").getStringValue ();

   CHECK_TRUE (memcmp (rfpi, rfpi_c, IFX_DECT_MAX_RFPI_LEN) == 0);

   delete[] rfpi_c;

   delete agent_s;
   delete agent_c;
}

// =============================================================================
// Test Commands & Events.
// =============================================================================

TEST_BASE (Agent)
{
   Server *server;
   Client *client;

   Endpoint ep;

   const char *rfpi = "\x00\x73\x70\x00\x10";

   TEST_SETUP ()
   {
      mock ().ignoreOtherCalls ();

      ep     = Endpoint ();

      server = new Server ();
      client = new Client (0x5A5A);

      IFX_HANFUN_Server (server);

      client->add (&ep);

      server->initialize ();
      client->initialize ();

      assert (server->accept ());

      mock ("ifx_voip").setData ("RFPI", rfpi);
      mock ("ifx_voip").setData ("IFX_DECT_ULE_GetPVCConnectedDevices::size", 0);

      assert (server->receive ());
      assert (client->receive ());

      const char *rfpi_c = mock ("Client").getData ("RFPI").getStringValue ();

      delete[] rfpi_c;
   }

   TEST_TEARDOWN ()
   {
      delete client;
      delete server;

      mock ().clear ();
   }
};

//! Test commands and events.
TEST_GROUP_BASE (AgentTests, Agent)
{};

TEST (AgentTests, RegistrationStart)
{
   mock ("Server").expectOneCall ("handle::registration_start");
   mock ("ifx_voip").expectOneCall ("IFX_DECT_MU_RegistrationAllow").withParameter ("timeout", 0x5A5A);

   client->registration_start (0x5A5A);
   CHECK_TRUE (server->receive ());

   mock ().checkExpectations ();
}

TEST (AgentTests, RegistrationStop)
{
   mock ("Server").expectOneCall ("handle::registration_stop");

   client->registration_stop ();
   CHECK_TRUE (server->receive ());

   mock ().checkExpectations ();
}

TEST (AgentTests, Deregister)
{
   uint8_t device  = 1;
   uint8_t address = 0xA5;

   mock ("Server").expectOneCall ("handle::deregister");
   mock ("ifx_voip").expectOneCall ("IFX_DECT_MU_UNRegister").withParameter ("handset", 1);

   HF::UID::DECT ipui;

   HF::Agent::Link *link = new HF::Agent::Link (device, ipui, nullptr);
   link->address (address);

   client->add (link);

   client->deregister (address);
   CHECK_TRUE (server->receive ());

   mock ().checkExpectations ();
}

TEST (AgentTests, Connected)
{
   uint8_t device = 0xA5;

   mock ("Endpoint").expectOneCall ("connected");
   mock ("Client").expectOneCall ("handle::connected");

   HF::UID::DECT ipui;

   ipui[0] = 0x51;
   ipui[1] = 0x52;
   ipui[2] = 0x53;
   ipui[3] = 0x54;
   ipui[4] = 0x55;

   x_IFX_DECT_ULE_NotifyEvent evt;

   evt.eEvent = IFX_DECT_ULE_DEVICE_PVC_CONNECTED;

   for (uint8_t i = 0; i < HF::UID::DECT::length (); i++)
   {
      evt.uxNotify.acipui_array[i] = ipui[i];
   }

   IFX_HANFUN_Notify (device, &evt);

   CHECK_TRUE (client->receive ());

   mock ().checkExpectations ();

   HF::Agent::Link *link = client->find_by_id (device);

   CHECK_TRUE (link != nullptr);

   CHECK_TRUE (ipui == link->ipui);
}

TEST (AgentTests, Disconnected)
{
   uint8_t device = 0xA5;

   HF::UID::DECT ipui;

   ipui[0] = 0x51;
   ipui[1] = 0x52;
   ipui[2] = 0x53;
   ipui[3] = 0x54;
   ipui[4] = 0x55;

   x_IFX_DECT_ULE_NotifyEvent evt;

   evt.eEvent = IFX_DECT_ULE_DEVICE_PVC_CONNECTED;

   for (uint8_t i = 0; i < HF::UID::DECT::length (); i++)
   {
      evt.uxNotify.xSubscInfo.acipui_array[i] = ipui[i];
   }

   IFX_HANFUN_Notify (device, &evt);

   CHECK_TRUE (client->receive ());

   HF::Agent::Link *link = client->find_by_id (device);

   memset (&evt, 0, sizeof(x_IFX_DECT_ULE_NotifyEvent));

   mock ("Endpoint").expectOneCall ("disconnected");
   mock ("Client").expectOneCall ("handle::disconnected");

   evt.eEvent = IFX_DECT_ULE_DEVICE_PVC_DISCONNECTED;

   IFX_HANFUN_Notify (device, &evt);

   CHECK_TRUE (client->receive ());

   mock ().checkExpectations ();

   link = client->find_by_id (device);

   CHECK_FALSE (link != nullptr);
}

// =============================================================================
// Test Data communication.
// =============================================================================

TEST_GROUP_BASE (AgentData, Agent)
{
   uint8_t device;

   HF::Common::ByteArray array;

   TEST_SETUP ()
   {
      Agent::setup ();

      device = 0xA5;

      // Make sure the device is connected.
      HF::UID::DECT ipui;

      ipui[0] = 0x51;
      ipui[1] = 0x52;
      ipui[2] = 0x53;
      ipui[3] = 0x54;
      ipui[4] = 0x55;

      x_IFX_DECT_ULE_NotifyEvent evt;

      evt.eEvent = IFX_DECT_ULE_DEVICE_PVC_CONNECTED;

      for (uint8_t i = 0; i < HF::UID::DECT::length (); i++)
      {
         evt.uxNotify.xSubscInfo.acipui_array[i] = ipui[i];
      }

      IFX_HANFUN_Notify (device, &evt);

      CHECK_TRUE (client->receive ());

      array =
      {
         0x7A, 0xAA,                         // Source device Address.
         0x55,                               // Source unit.
         0xF5, 0x55,                         // Destination device Address.
         0xAA,                               // Destination unit.
         0x00, 0x00,                         // Transport header.
         0xCC,                               // Application Reference.
         HF::Protocol::Message::COMMAND_REQ, // Message Type.
         0xFA, 0xAA, 0x55,                   // Interface Address.
         0x00, 0x01,                         // Payload length.
         0xAB,                               // Payload data.
      };
   }

   TEST_TEARDOWN ()
   {
      Agent::teardown ();
   }
};

TEST (AgentData, DataFromDevice)
{
   HF::Agent::Link *link = client->find_by_id (device);

   mock ("Endpoint").expectOneCall ("receive").withParameter ("link", link);
   mock ("Client").expectOneCall ("handle::data");

   LONGS_EQUAL (IFX_SUCCESS, IFX_HANFUN_ReceiveData (device, array.size (), array.data ()));

   CHECK_TRUE (client->receive ());

   mock ().checkExpectations ();

   HF::Common::ByteArray *buffer = (HF::Common::ByteArray *) mock ("Endpoint").getData ("payload").getPointerValue ();

   CHECK_EQUAL (array, *buffer);

   delete buffer;
}

/*!
 * Test sending to device.
 *
 * Conditions :
 *
 *  - device is connected;
 *  - no more messages exist in the queue;
 *
 * Expected :
 *
 *  - should call DECT TK to send message to device.
 */
TEST (AgentData, DataToDevice_Senario1)
{
   mock ("Server").expectOneCall ("handle::data");
   mock ("ifx_voip").expectOneCall ("IFX_DECT_ULE_DataSend").withParameter ("id", device).
      withParameter ("size", (int) array.size ());

   HF::Agent::Link *link = client->find_by_id (device);

   link->send (array);

   CHECK_TRUE (server->receive ());

   mock ().checkExpectations ();

   void *data = mock ("ifx_voip").getData ("data").getPointerValue ();

   HF::Common::ByteArray buffer ((uint8_t *) data, array.size ());

   CHECK_EQUAL (array, buffer);

   // Deallocate the data.
   free (data);
}

/*!
 * Test sending to device.
 *
 * Conditions :
 *
 *  - device is not connected;
 *
 * Expected :
 *
 *  - should not call DECT TK to send message to device.
 */
TEST (AgentData, DataToDevice_Senario2)
{
   mock ("Server").expectOneCall ("handle::data");
   mock ("ifx_voip").expectNCalls (0, "IFX_DECT_ULE_DataSend");

   server->disconnected (device);

   HF::Agent::Link *link = client->find_by_id (device);

   link->send (array);

   CHECK_TRUE (server->receive ());

   mock ().checkExpectations ();
}

/*!
 * Test sending to device.
 *
 * Conditions :
 *
 *  - device is connected;
 *  - messages exist in the queue.
 *
 *  Expected :
 *
 *   - should not call DECT TK to send message to device;
 *   - should queue the message for delivery.
 */
TEST (AgentData, DataToDevice_Senario3)
{
   mock ("Server").expectOneCall ("handle::data");
   mock ("ifx_voip").expectNCalls (0, "IFX_DECT_ULE_DataSend");

   HF::Agent::Data data;

   server->messages.push_back (data);

   uint8_t size          = server->messages.size ();

   HF::Agent::Link *link = client->find_by_id (device);

   link->send (array);

   CHECK_TRUE (server->receive ());

   mock ().checkExpectations ();

   LONGS_EQUAL (size + 1, server->messages.size ());
}

/*!
 * Test sending to device.
 *
 * Conditions :
 *
 *  - device is connected.
 *  - messages exist in the queue.
 *  - the last message was delivered successfully.
 *
 *  Expected :
 *
 *   - should call DECT TK to send message to device;
 *   - should remove the message from the queue.
 */
TEST (AgentData, DataToDevice_Senario4)
{
   mock ("ifx_voip").expectOneCall ("IFX_DECT_ULE_DataSend").ignoreOtherParameters ();

   HF::Agent::Data data (device);

   server->messages.push_back (data);
   server->messages.push_back (data);
   server->messages.push_back (data);

   uint8_t size = server->messages.size ();

   x_IFX_DECT_ULE_NotifyEvent evt;
   evt.eEvent = IFX_DECT_ULE_DATA_SENT_SUCCESS;

   IFX_HANFUN_Notify (device, &evt);

   mock ().checkExpectations ();

   LONGS_EQUAL (size - 1, server->messages.size ());
}

/*!
 * Test sending to device.
 *
 * Conditions :
 *
 *  - device is connected.
 *  - messages exist in the queue.
 *  - the last message was delivered successfully.
 *
 *  Expected :
 *
 *   - should remove a message from the queue.
 *   - should call DECT TK to send message to device;
 */
TEST (AgentData, DataToDevice_Senario5)
{
   mock ("ifx_voip").expectOneCall ("IFX_DECT_ULE_DataSend").withParameter ("id", device).
      ignoreOtherParameters ();

   HF::Agent::Data data (device);

   server->messages.push_back (data);

   uint8_t size = server->messages.size ();

   x_IFX_DECT_ULE_NotifyEvent evt;
   evt.eEvent = IFX_DECT_ULE_DATA_SENT_SUCCESS;

   IFX_HANFUN_Notify (device, &evt);

   mock ().checkExpectations ();

   LONGS_EQUAL (size - 1, server->messages.size ());
}

/*!
 * Test sending to device.
 *
 * Conditions :
 *
 *  - device is connected.
 *  - the last message was not delivered successfully.
 *
 *  Expected :
 *
 *   - should call DECT TK API to reset the PVC;
 */
TEST (AgentData, DataToDevice_Senario6)
{
   mock ("ifx_voip").expectOneCall ("IFX_DECT_ULE_ResetPVC").withParameter ("id", device);

   x_IFX_DECT_ULE_NotifyEvent evt;
   evt.eEvent = IFX_DECT_ULE_DATA_SENT_FAIL;

   IFX_HANFUN_Notify (device, &evt);

   mock ().checkExpectations ();

   mock ("ifx_voip").expectOneCall ("IFX_DECT_ULE_ResetPVC").withParameter ("id", device + 2);

   evt.eEvent = IFX_DECT_ULE_DATA_SENT_FAIL_TIMEOUT;

   IFX_HANFUN_Notify (device + 2, &evt);

   mock ().checkExpectations ();
}
