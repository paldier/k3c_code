// =============================================================================
/*!
 * \file       tests/test_helper.cpp
 *
 * This file contains helper functions used the tests.
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================
#include <iostream>

#include <assert.h>
#include <stdlib.h>

#include "CppUTest/CommandLineTestRunner.h"

#include "test_helper.h"

#include "../src/external.h"

// =============================================================================
// Defines
// =============================================================================

// =============================================================================
// Helper Functions
// =============================================================================

SimpleString StringFrom (const HF::Common::ByteArray &array)
{
   SimpleString result = "";

   for (size_t i = 0; i < array.size (); i++)
   {
      result += StringFromFormat ("%02X ", array[i]);
   }

   return result;
}

SimpleString StringFrom (const HF::Agent::ByteArray &array)
{
   SimpleString result = "";

   for (size_t i = 0; i < array.size (); i++)
   {
      result += StringFromFormat ("%02X ", array[i]);
   }

   return result;
}

std::ostream &operator <<(std::ostream &os, std::uint8_t val)
{
   return os << static_cast <int>(val);
}

// =============================================================================
// Stubs
// =============================================================================

extern "C" e_IFX_Return IFX_MSGRTR_FdCallBackRegister (x_IFX_MSGRTR_FdInfo *paxFdInfo,
                                                       uchar8 ucNumFds,
                                                       pfn_IFX_MSGRTR_FdCallback pfnFdCallback)
{
   assert (ucNumFds == 1);

   mock ("ifx_voip").actualCall ("IFX_MSGRTR_FdCallBackRegister");

   Select::Entry *entry = new Select::Entry;

   entry->fd = paxFdInfo->uiFd;
   entry->cb = pfnFdCallback;

   mock ("ifx_voip").setData ("Select::Entry", entry);

   return IFX_SUCCESS;
}

extern "C" e_IFX_Return IFX_MSGRTR_FdUnregister (x_IFX_MSGRTR_FdInfo *pxFdInfo)
{
   UNUSED (pxFdInfo);

   mock ("ifx_voip").actualCall ("IFX_MSGRTR_FdUnregister");

   return IFX_SUCCESS;
}

extern "C" void IFX_DBG_Log (uint8_t ucModuleId, uint8_t ucDbgLvl, const char *pucFuncName,
                             char *pucStr, ...)
{
   UNUSED (ucModuleId);
   UNUSED (ucDbgLvl);
   UNUSED (pucFuncName);
   UNUSED (pucStr);
#if 0
   va_list args;
   va_start (args, pucStr);

   printf ("%02d:%02d:%s:", ucModuleId, ucDbgLvl, pucFuncName);
   vprintf (pucStr, args);

   va_end (args);
#endif
   mock ("ifx_voip").actualCall ("IFX_DBG_Log");
}

extern "C" e_IFX_Return IFX_DECT_MU_RegistrationAllow (uint32 uiTime, char8 *pcBaseName)
{
   UNUSED (pcBaseName);

   mock ("ifx_voip").actualCall ("IFX_DECT_MU_RegistrationAllow").withIntParameter ("timeout", uiTime);

   return IFX_SUCCESS;
}

extern "C" e_IFX_Return IFX_DECT_MU_UNRegister (uchar8 isAll, uchar8 ucHandset)
{
   UNUSED (isAll);

   mock ("ifx_voip").actualCall ("IFX_DECT_MU_UNRegister").withIntParameter ("handset", ucHandset);

   return IFX_SUCCESS;
}

extern "C" e_IFX_Return IFX_DECT_ULE_DataSend (uchar8 ucInstanceId, uint16 unSize, void *pData)
{
   UNUSED (ucInstanceId);
   UNUSED (unSize);
   UNUSED (pData);

   mock ("ifx_voip").actualCall ("IFX_DECT_ULE_DataSend").withIntParameter ("id", ucInstanceId).
      withIntParameter ("size", unSize);

   // Copy data to check it at the test.
   if (unSize != 0)
   {
      void *data = calloc (unSize, sizeof(uint8_t));

      memcpy (data, pData, unSize);

      mock ("ifx_voip").setData ("data", data);
   }

   return IFX_SUCCESS;
}

extern "C" e_IFX_Return IFX_DECT_ULE_ResetPVC (uchar8 ucInstanceId)
{
   mock ("ifx_voip").actualCall ("IFX_DECT_ULE_ResetPVC").withIntParameter ("id", ucInstanceId);
   return IFX_SUCCESS;
}

extern "C" e_IFX_Return IFX_DECT_ULE_ConfigureHF_Attributes (x_IFX_DECT_ULE_HF_Attributes *pxHFAttr)
{
   UNUSED (pxHFAttr);

   mock ("ifx_voip").actualCall ("IFX_DECT_ULE_ConfigureHF_Attributes");

   return IFX_SUCCESS;
}

extern "C" void IFX_DECT_GetRFPI (uchar8 *pucRfpi)
{
   mock ("ifx_voip").actualCall ("IFX_DECT_GetRFPI");

   const char *rfpi = mock ("ifx_voip").getData ("RFPI").getStringValue ();

   if (rfpi != nullptr)
   {
      memcpy (pucRfpi, rfpi, IFX_DECT_MAX_RFPI_LEN);
   }
   else
   {
      memset (pucRfpi, 0, IFX_DECT_MAX_RFPI_LEN);
   }
}

extern "C" e_IFX_Return IFX_DECT_ULE_ReleaseExpConnection (uchar8 ucInstanceId,
                                                           e_IFX_DECT_ULE_Release_Reason eReason,
                                                           uchar8 ucInfofield)
{
   UNUSED (ucInstanceId);
   UNUSED (eReason);
   UNUSED (ucInfofield);

   mock ("ifx_voip").actualCall ("IFX_DECT_ULE_ConfigureHF_Attributes").
      withParameter ("id", ucInstanceId).withParameter ("reason", (int) eReason);

   return IFX_SUCCESS;
}

extern "C" void IFX_DECT_ULE_GetPVCConnectedDevices (uint8_t *size,
                                                     x_IFX_DECT_ULE_Device_IPUI *buffer)
{
   mock ("ifx_voip").actualCall ("IFX_DECT_ULE_GetPVCConnectedDevices");

   *size = mock ("ifx_voip").getData ("IFX_DECT_ULE_GetPVCConnectedDevices::size").getIntValue ();

   if (*size != 0)
   {
      x_IFX_DECT_ULE_Device_IPUI *temp = (x_IFX_DECT_ULE_Device_IPUI *) mock ("ifx_voip").getData (
         "IFX_DECT_ULE_GetPVCConnectedDevices::devices").getPointerValue ();

      memcpy (buffer, temp, *size * sizeof(x_IFX_DECT_ULE_Device_IPUI));
   }
}

// =============================================================================
// Main
// =============================================================================

int main (int ac, char **av)
{
   return CommandLineTestRunner::RunAllTests (ac, av);
}
