// =============================================================================
/*!
 * \file       tests/test_helper.h
 *
 * This file contains the definition of helper classes used for testing.
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================
#ifndef HF_TEST_HELPER_H
#define HF_TEST_HELPER_H

#include <string.h>
#include <sstream>
#include <algorithm>
#include <iostream>

#include <map>

#include <unistd.h>

#include "CppUTest/TestHarness.h"
#include "CppUTestExt/MockSupport.h"

#include "hanfun/agent.h"

// =============================================================================
// Helper Test Functions
// =============================================================================

SimpleString StringFrom (const HF::Common::ByteArray &array);

SimpleString StringFrom (const HF::Agent::ByteArray &array);

std::ostream &operator <<(std::ostream &os, std::uint8_t val);

// =============================================================================
// Helper Test Classes
// =============================================================================

namespace Select
{
   typedef e_IFX_Return (*callback_t) (int32_t fd);

   struct Entry
   {
      int32_t    fd;
      callback_t cb;

      bool       run ()
      {
         return cb (fd) == IFX_SUCCESS;
      }
   };

}  // namespace Select

#endif /* HF_TEST_HELPER_H */
