// =============================================================================
/*!
 * \file       /Lana/tests/test_messages.cpp
 *
 * This file contains the implementation of the test_messages
 *
 * \version    0.3.1
 *
 * \copyright  Copyright (c) 2014 Lantiq Deutschland GmbH
 *
 * For licensing information, see the file 'LICENSE' in the root folder of
 * this software module.
 */
// =============================================================================
#include <cinttypes>

#include "test_helper.h"

#include <hanfun/common.h>

// =============================================================================
//
// =============================================================================

using namespace HF::Agent;

TEST_GROUP (Messages)
{};

TEST (Messages, Abstract)
{
   Message msg;

   LONGS_EQUAL (Message::UNKNOWN, msg.type);
   LONGS_EQUAL (2, msg.size ());

   msg.type = Message::DATA;

   ByteArray payload (msg.size () + 6);

   msg.pack (payload, 3);

   ByteArray expected {0x00, 0x00, 0x00,
                       0x01,  // Size
                       Message::DATA,
                       0x00,
                       0x00, 0x00};

   CHECK_EQUAL (expected, payload);

   payload = ByteArray {0x00, 0x00, 0x00,
                        0x01,  // Size
                        Message::CONNECTED,
                        0x00, 0x00, 0x00};

   msg = Message ();

   msg.unpack (payload, 3);

   LONGS_EQUAL (0x01, msg._size);

   LONGS_EQUAL (Message::CONNECTED, msg.type);
}

TEST (Messages, Hello)
{
   Hello msg (0x5AA5, 0xF1, 0xF2, 0xF3);

   LONGS_EQUAL (2 * sizeof(uint8_t) + sizeof(uint16_t) + 3 * sizeof(uint8_t), msg.size ());
   LONGS_EQUAL (Message::HELLO, msg.type);

   ByteArray payload (msg.size () + 6);

   msg.pack (payload, 3);

   ByteArray expected {0x00, 0x00, 0x00,
                       0x06,              // Size
                       Message::HELLO,    // Message Type
                       0x5A, 0xA5,        // EMC
                       0xF1, 0xF2, 0xF3,  // Versions : Core, Profiles, Interfaces.
                       0x00, 0x00, 0x00};

   CHECK_EQUAL (expected, payload);

   payload = ByteArray {0x00, 0x00, 0x00,
                        0x06,              // Size
                        Message::HELLO,    // Message Type
                        0x5A, 0xA5,        // EMC
                        0x1A, 0x2B, 0x3C,  // Versions : Core, Profiles, Interfaces.
                        0x00, 0x00, 0x00};

   msg = Hello ();

   msg.unpack (payload, 3);

   LONGS_EQUAL (0x06, msg._size);

   LONGS_EQUAL (Message::HELLO, msg.type);

   LONGS_EQUAL (0x5AA5, msg.emc);

   LONGS_EQUAL (0x1A, msg.version.core);
   LONGS_EQUAL (0x2B, msg.version.profiles);
   LONGS_EQUAL (0x3C, msg.version.interfaces);
}

TEST (Messages, HelloReply)
{
   uint8_t rfpi[IFX_DECT_MAX_RFPI_LEN];
   rfpi[0] = 0x1A;
   rfpi[1] = 0x2B;
   rfpi[2] = 0x3C;
   rfpi[3] = 0x4D;
   rfpi[4] = 0x5E;

   HelloReply msg (rfpi);

   LONGS_EQUAL (2 * sizeof(uint8_t) + IFX_DECT_MAX_RFPI_LEN, msg.size ());

   LONGS_EQUAL (Message::HELLO_REPLY, msg.type);

   ByteArray payload (msg.size () + 6);

   msg.pack (payload, 3);

   ByteArray expected {0x00, 0x00, 0x00,
                       0x06,                          // Size
                       Message::HELLO_REPLY,          // Message Type
                       0x1A, 0x2B, 0x3C, 0x4D, 0x5E,  // RFPI
                       0x00, 0x00, 0x00};

   CHECK_EQUAL (expected, payload);

   payload = ByteArray {0x00, 0x00, 0x00,
                        0x06,                          // Size
                        Message::HELLO_REPLY,          // Message Type
                        0xE5, 0xD4, 0xC3, 0xB2, 0xA1,  // RFPI
                        0x00, 0x00, 0x00};

   msg = HelloReply ();

   msg.unpack (payload, 3);

   LONGS_EQUAL (0x06, msg._size);

   LONGS_EQUAL (Message::HELLO_REPLY, msg.type);

   LONGS_EQUAL (0xA1, msg.rfpi[4]);
   LONGS_EQUAL (0xB2, msg.rfpi[3]);
   LONGS_EQUAL (0xC3, msg.rfpi[2]);
   LONGS_EQUAL (0xD4, msg.rfpi[1]);
   LONGS_EQUAL (0xE5, msg.rfpi[0]);
}

TEST (Messages, RegistrationStart)
{
   RegistrationStart msg (0x5A5A);

   LONGS_EQUAL (2 * sizeof(uint8_t) + sizeof(uint16_t), msg.size ());

   LONGS_EQUAL (Message::REGISTRATION_START, msg.type);

   ByteArray payload (msg.size () + 6);

   msg.pack (payload, 3);

   ByteArray expected {0x00, 0x00, 0x00,
                       0x03,                          // Size
                       Message::REGISTRATION_START,   // Message Type
                       0x5A, 0x5A,                    // Timeout.
                       0x00, 0x00, 0x00};

   CHECK_EQUAL (expected, payload);

   payload = ByteArray {0x00, 0x00, 0x00,
                        0x03,                          // Size
                        Message::REGISTRATION_START,   // Message Type
                        0xA5, 0xA5,                    // Timeout.
                        0x00, 0x00, 0x00};

   msg = RegistrationStart ();

   msg.unpack (payload, 3);

   LONGS_EQUAL (0x03, msg._size);

   LONGS_EQUAL (Message::REGISTRATION_START, msg.type);

   LONGS_EQUAL (0xA5A5, msg.timeout);
}

TEST (Messages, RegistrationStop)
{
   RegistrationStop msg;

   LONGS_EQUAL (2 * sizeof(uint8_t), msg.size ());

   LONGS_EQUAL (Message::REGISTRATION_STOP, msg.type);

   ByteArray payload (msg.size () + 6);

   msg.pack (payload, 3);

   ByteArray expected {0x00, 0x00, 0x00,
                       0x01,                         // Size
                       Message::REGISTRATION_STOP,   // Message Type
                       0x00, 0x00, 0x00};

   CHECK_EQUAL (expected, payload);

   payload = ByteArray {0x00, 0x00, 0x00,
                        0x01,                         // Size
                        Message::REGISTRATION_STOP,   // Message Type
                        0x00, 0x00, 0x00};

   msg = RegistrationStop ();

   msg.unpack (payload, 3);

   LONGS_EQUAL (0x01, msg._size);

   LONGS_EQUAL (Message::REGISTRATION_STOP, msg.type);
}

TEST (Messages, DeregisterDevice)
{
   DeregisterDevice msg (0x5A5A);

   LONGS_EQUAL (2 * sizeof(uint8_t) + sizeof(uint16_t), msg.size ());

   LONGS_EQUAL (Message::DEREGISTER_DEVICE, msg.type);

   ByteArray payload (msg.size () + 6);

   msg.pack (payload, 3);

   ByteArray expected {0x00, 0x00, 0x00,
                       0x03,                          // Size
                       Message::DEREGISTER_DEVICE,    // Message Type
                       0x5A, 0x5A,                    // Timeout.
                       0x00, 0x00, 0x00};

   CHECK_EQUAL (expected, payload);

   payload = ByteArray {0x00, 0x00, 0x00,
                        0x03,                         // Size
                        Message::DEREGISTER_DEVICE,   // Message Type
                        0xA5, 0xA5,                   // Timeout.
                        0x00, 0x00, 0x00};

   msg = DeregisterDevice (0);

   msg.unpack (payload, 3);

   LONGS_EQUAL (0x03, msg._size);

   LONGS_EQUAL (Message::DEREGISTER_DEVICE, msg.type);

   LONGS_EQUAL (0xA5A5, msg.device);
}

TEST (Messages, Connected)
{
   uint8_t ipui[IFX_DECT_IPUI_SIZE];
   ipui[0] = 0x1A;
   ipui[1] = 0x2B;
   ipui[2] = 0x3C;
   ipui[3] = 0x4D;
   ipui[4] = 0x5E;

   Connected msg (0x5A5A, ipui);

   LONGS_EQUAL (2 * sizeof(uint8_t) + sizeof(uint16_t) + IFX_DECT_IPUI_SIZE, msg.size ());

   LONGS_EQUAL (Message::CONNECTED, msg.type);

   ByteArray payload (msg.size () + 6);

   msg.pack (payload, 3);

   ByteArray expected {0x00, 0x00, 0x00,
                       0x08,                          // Size
                       Message::CONNECTED,            // Message Type
                       0x5A, 0x5A,                    // Device ID.
                       0x1A, 0x2B, 0x3C, 0x4D, 0x5E,  // RFPI
                       0x00, 0x00, 0x00};

   CHECK_EQUAL (expected, payload);

   payload = ByteArray {0x00, 0x00, 0x00,
                        0x08,                            // Size
                        Message::CONNECTED,              // Message Type
                        0xA5, 0xA5,                      // Device ID.
                        0xE5, 0xD4, 0xC3, 0xB2, 0xA1,    // IPUI
                        0x00, 0x00, 0x00};

   msg = Connected (0);

   msg.unpack (payload, 3);

   LONGS_EQUAL (0x08, msg._size);

   LONGS_EQUAL (Message::CONNECTED, msg.type);

   LONGS_EQUAL (0xA5A5, msg.device);

   LONGS_EQUAL (0xA1, msg.ipui[4]);
   LONGS_EQUAL (0xB2, msg.ipui[3]);
   LONGS_EQUAL (0xC3, msg.ipui[2]);
   LONGS_EQUAL (0xD4, msg.ipui[1]);
   LONGS_EQUAL (0xE5, msg.ipui[0]);
}

TEST (Messages, Disconnected)
{
   Disconnected msg (0x5A5A);

   LONGS_EQUAL (2 * sizeof(uint8_t) + sizeof(uint16_t), msg.size ());

   LONGS_EQUAL (Message::DISCONNECTED, msg.type);

   ByteArray payload (msg.size () + 6);

   msg.pack (payload, 3);

   ByteArray expected {0x00, 0x00, 0x00,
                       0x03,                       // Size
                       Message::DISCONNECTED,      // Message Type
                       0x5A, 0x5A,                 // Timeout.
                       0x00, 0x00, 0x00};

   CHECK_EQUAL (expected, payload);

   payload = ByteArray {0x00, 0x00, 0x00,
                        0x03,                   // Size
                        Message::DISCONNECTED,  // Message Type
                        0xA5, 0xA5,             // Timeout.
                        0x00, 0x00, 0x00};

   msg = Disconnected (0);

   msg.unpack (payload, 3);

   LONGS_EQUAL (0x03, msg._size);

   LONGS_EQUAL (Message::DISCONNECTED, msg.type);

   LONGS_EQUAL (0xA5A5, msg.device);
}

TEST (Messages, Data)
{
   ByteArray data {0x01, 0x02, 0x03, 0x04, 0x05,
                   0x06, 0x07, 0x08, 0x09, 0x0A};

   Data msg (0x5A5A, data);

   LONGS_EQUAL (2 * sizeof(uint8_t) + 2 * sizeof(uint16_t) + data.size (), msg.size ());

   LONGS_EQUAL (Message::DATA, msg.type);

   ByteArray payload (msg.size () + 6);

   msg.pack (payload, 3);

   ByteArray expected {0x00, 0x00, 0x00,
                       0x0F,                             // Size
                       Message::DATA,                    // Message Type
                       0x5A, 0x5A,                       // Device ID.
                       0x00, 0x0A,                       // Payload Size
                       0x01, 0x02, 0x03, 0x04, 0x05,     // Payload
                       0x06, 0x07, 0x08, 0x09, 0x0A,
                       0x00, 0x00, 0x00};

   CHECK_EQUAL (expected, payload);

   payload = ByteArray {0x00, 0x00, 0x00,
                        0x0D,                            // Size
                        Message::DATA,                   // Message Type
                        0xA5, 0xA5,                      // Device ID.
                        0x00, 0x0A,                      // Payload Size
                        0x01, 0x02, 0x03, 0x04, 0x05,    // Payload
                        0x06, 0x07, 0x08, 0x09, 0x0A,
                        0x00, 0x00, 0x00};

   msg = Data (0);

   msg.unpack (payload, 3);

   LONGS_EQUAL (0x0D, msg._size);

   LONGS_EQUAL (Message::DATA, msg.type);

   LONGS_EQUAL (0xA5A5, msg.device);

   LONGS_EQUAL (10, msg.payload.size ());

   CHECK_EQUAL (data, msg.payload);
}
