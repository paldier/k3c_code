Thelib.zip is the zipped Java executable + the libraries. Should be runnable after unpacking.

The UleDemo.zip is the netbeans project. One can use it in Netbenas to modify the code.
