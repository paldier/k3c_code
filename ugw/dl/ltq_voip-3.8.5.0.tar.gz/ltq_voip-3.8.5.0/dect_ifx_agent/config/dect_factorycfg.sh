#!/bin/sh

rm -f /ramdisk/flash/dect_rc.conf
/bin/rm -rf /tmp/dect-tmp
mkdir /tmp/dect-tmp
cd /tmp/dect-tmp/

/usr/sbin/read_img dectconfig /tmp/dect-tmp/dect.tar.gz 2>/dev/null

tar -xzf dect.tar.gz 2>/dev/null
rm -f dect.tar.gz
rm -f dect_rc.conf
cp -f /etc/dect_rc.conf.gz /tmp/dect-tmp/
/bin/gunzip -f /tmp/dect-tmp/dect_rc.conf.gz 2>/dev/null
tar -czf dect.tar.gz * 2>/dev/null
/usr/sbin/upgrade dect.tar.gz dectconfig 0 0 2>/dev/null

cp -f /etc/dect_rc.conf.gz /ramdisk/flash/
/bin/gunzip -f /ramdisk/flash/dect_rc.conf.gz 2>/dev/null
cd - 2>/dev/null
/bin/rm -rf /tmp/dect-tmp

#sleep 4
#reboot

