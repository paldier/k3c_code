/**************************************************************************
 **   SRC_FILE          : IFX_DECT_ContentDownload.h
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT DATA IWU
 **   SRC VERSION       : v0.1
 **   DATE              : 8th Oct 2007
 **   AUTHOR            : Aniketh
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
/*! \file IFX_DECT_ContentDownload.h
    \brief FT Application
*/


#ifndef __IFX_DECT_CONTENT_DOWNLOAD_H__
#define __IFX_DECT_CONTENT_DOWNLOAD_H__

#include <netinet/in.h>
#include "IFX_DECT_SUOTA.h"
/** \ingroup DECT_SS_1_1
    \defgroup FT Application acts as an interface between the DECT Toolkit and the Data App.
    \brief This file stores structures,macros,enumerations and API prototypes 
	   and callback function definitions useful for FT Application to meet
	   DPSU requirements.
*/
/*@{*/

/*! \brief IFX_DECTAPP_CD_REQ_MAXBUFLEN Maximum length of request buffer.
           Request is made by PT. 
*/

#define IFX_DECTAPP_CD_REQ_MAXBUFLEN 2048


/*! \brief IFX_DECTAPP_CD_RSP_MAXBUFLEN Maximum Response Buffer length 
           from the server.
*/

#define IFX_DECTAPP_CD_RESP_MAXBUFLEN 2048


/*! \brief IFX_DECTAPP_CD_MAX_CONN Maximum number of connections available.
           Equal to maximum number of handsets.
*/

#define IFX_DECTAPP_CD_MAX_CONN 6

#ifdef ULE_SUPPORT
#define IFX_DECTAPP_SUOTA_MAX_CONN 255  // >= 6 HS + 190 ULE + 30 REPEATER
#else
#define IFX_DECTAPP_SUOTA_MAX_CONN 6
#endif

#define IFX_DECTAPP_SUOTA_MAX_URL_LEN  250 //IFX_DECT_SUOTA_MAX_URL_LEN

#define IFX_DECTAPP_MAX_RECV_MGMT_URL 4

#define IFX_DECTAPP_MAX_MGMT_URL_LENGTH 250 

#define IFX_DECTAPP_MAX_MGMT_HEADER_LENGTH 200 

#define IFX_DECTAPP_SUOTA_RESP_MAXBUFLEN (IFX_DECTAPP_MAX_MGMT_HEADER_LENGTH + (IFX_DECTAPP_MAX_RECV_MGMT_URL * IFX_DECTAPP_MAX_MGMT_URL_LENGTH))


/*! \brief typedef for thread function.*/
typedef void *(*THREAD_RTN_PTR)(void*);


/*! \brief enum describing status of connection.*/

typedef enum{
        IFX_DECTAPP_CD_IDLE,
        IFX_DECTAPP_CD_CLOSED,
	IFX_DECTAPP_CD_HTTP10CLOSED,
        IFX_DECTAPP_CD_UNSPEC_OPEN,
        IFX_DECTAPP_CD_HTTP11,
        IFX_DECTAPP_CD_HTTP10,
        }e_IFX_DECTAPP_CD_ConnFlag;



 

/*! \brief enum describing events on SOCK FD.*/

typedef enum {
       IFX_DECTAPP_CD_ADD_SOCK_FD,
       IFX_DECTAPP_SUOTA_ADD_SOCK_FD,
       IFX_DECTAPP_CD_WRITE_SOCK_FD,//
       IFX_DECTAPP_CD_REMOVE_SOCK_FD,
       IFX_DECTAPP_SUOTA_REMOVE_SOCK_FD,
       IFX_DECTAPP_CD_EXIT_APP,
       IFX_DECTAPP_CD_DATA_CALL_INIT,
       IFX_DECTAPP_CD_DEFAULT
}e_IFX_DECTAPP_CD_Events;

/*! \brief enum describing status of SUOTA connection.*/

typedef enum{
  IFX_DECTAPP_SUOTA_IDLE,  
  IFX_DECTAPP_SUOTA_VER_INDICATION,
  IFX_DECTAPP_SUOTA_URL_SEND,
  IFX_DECTAPP_SUOTA_CONNECTED,  
  IFX_DECTAPP_SUOTA_MAX,
}e_IFX_DECTAPP_SUOTA_Status;

typedef struct {    
  char8  acNewSwVer[20+1];  
  uchar8 ucNoOfUrl;
  uchar8 ucSendIndex;
  char8  acRecvUrlList[IFX_DECTAPP_MAX_RECV_MGMT_URL][IFX_DECTAPP_MAX_MGMT_URL_LENGTH];
  char8 user_interaction;
  uint16 unDelayMin;
  uint32 uiSwTotalSize;
}x_IFX_DECTAPP_SUOTA_MgMtRecvUrl;

typedef struct {      
  uint16 unEMC;     
  char8  acHwVer[20];       
  char8  acSwVer[20];    
  char8  acUrl[IFX_DECTAPP_SUOTA_MAX_URL_LEN];      
  uchar8 ucFileNum;   
  char8 user_interaction;
  e_IFX_DECT_SUOTA_Reason eReason;     	
}x_IFX_DECTAPP_SUOTA_VersionInfo;

/*! 
    \brief Structure containing the Software Version information that are stored in
      the SUOTA application. 
*/
typedef struct {
  uchar8 ucHandsetId;  
  uchar8 IsAvail;
  
  int32 SockFd;                      /*!< Socket FD*/
  struct sockaddr_in Serv_Addr;      /*!< Address for socket*/
  e_IFX_DECTAPP_SUOTA_Status eStatus;  /*!< status of the session*/
  uchar8 cbRespBuf[IFX_DECTAPP_SUOTA_RESP_MAXBUFLEN];
  int cbRespBuf_len;
  int chunklen;
  uint32 uiTimerId;
  //char8 acUrlList[IFX_DECTAPP_MAX_NO_URL][IFX_DECTAPP_MAX_URL_LENGTH];
  x_IFX_DECTAPP_SUOTA_VersionInfo xVerInfo; /*!< Version information to contact Management server */
  x_IFX_DECTAPP_SUOTA_MgMtRecvUrl xRecvUrl;
  
}x_IFX_DECTAPP_SUOTA_SessionInfo;

typedef enum
{
  IFX_DECTAPP_EVENT_SUOTA,
  IFX_DECTAPP_EVENT_CD
} e_IFX_DECTAPP_EventType;

/** x_IFX_DECT_ConnectionStruct structure stores the information pertaining to 
    a connection.
*/
typedef struct
{
 int32 iSessionId;                  /*!< Call Handle*/
 int32 SockFd;                      /*!< Socket FD*/
 struct sockaddr_in Serv_Addr;      /*!< Address for socket*/
 e_IFX_DECTAPP_CD_ConnFlag status;  /*!< status of the connection*/

 /*!< TCP handling Parameters */
 uint32 iCode;                      /*!< response code*/
 
 /*!< REQ Parameters*/
 char8 cbReqBuf[IFX_DECTAPP_CD_REQ_MAXBUFLEN];     /*!< Buffer for holding get request*/
 int32 iReqBufLen;                  /*!< length of the request buffer*/
 
 /*!< RESP Parameters*/
 char8 cbRespBuf[IFX_DECTAPP_CD_RESP_MAXBUFLEN];   /*!< response buffer*/
 int32 iRespBufLen;                 /*!< length of the response from server*/
 
 uchar8 IsUsed;                     /*!< Indicates whether this connection is free or used*/
 int32 iAppDataLen;                 /*!< total length of data to be recvd from server*/
 uchar8 ucState;                    /*Fort the first socket recv set to 1 and reset to zero when rcv length equl to total len*/
}x_IFX_DECTAPP_CD_ConnectionStruct;

typedef struct
{
  e_IFX_DECTAPP_EventType eEventTyp;
  e_IFX_DECTAPP_CD_Events Event;
  union {
    x_IFX_DECTAPP_CD_ConnectionStruct *pxConnId;
    x_IFX_DECTAPP_SUOTA_SessionInfo *pxSuotaId;
  } ux_IntEvent;
} x_IFX_DECTAPP_EventData;





/*! \brief The API IFX_DECTAPP_CD_Init initializes the FT Application and spawns
           a new thread for it.
    \return IFX_SUCCESS or IFX_FAILURE.
*/    

e_IFX_Return IFX_DECT_DPSU_Init (void *);


/*! \brief IFX_DECT_DPSU_CallInitiate,this callback function is issued when the PT
           initiates a Data Call to communicate with the Download Server.
    \param[in] uiCallHdl unique Connection handle.
    \param[in] ucHandsetId Handset Number.
    \param[in] uiIEHdl Information Element handle.
    \param[out] pucRejectReason Reason for Call reject.
    \param[out] puiPrivateData data specific to app used to uniquely identify 
                a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_CallInitiate (IN uint32 uiCallHdl,
                                         IN uchar8 ucHandsetId,
                                         IN uint32 uiIEHdl,
                                         OUT uchar8 *pucRejectReason,
                                         OUT uint32 *puiPrivateData);


/*! \brief IFX_DECT_DPSU_DataSendToIP callback function is called when there 
           is a request from the PT for the download server and the application 
           needs to connect to the server.
    \param[in] uiCallHdl Connection handle identifying a connection.
    \param[in] pcBuff Request buffer from PT. 
    \param[in] iLen Length of the buffer.
    \param[in] uiPrivateData identifies unique connection,application specific.
    \return IFX_SUCCESS or IFX_FAILURE.
*/    
    
e_IFX_Return IFX_DECT_DPSU_DataSendToIP (IN uint32 uiCallHdl,
                                              IN char8 *pcBuff, 
		                              IN int32 iLen,
                                              IN uint32 uiPrivateData);
			    

/*! \brief IFX_DECT_DPSU_CallRelease callback function is called once the DECT 
           stack closes the connection.
    \param[in] uiCallHdl unique Connection Handle.
    \param[in] uiIEHdl Information Element Handle.
    \param[in] eReason Reason for Release.
    \param[in] uiPrivateData data specific to app used to uniquely identify
               a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ReleaseCall( IN uint32 uiCallHdl,
                                        IN uint32 uiIEHdl,
                                        IN e_IFX_DECT_RelType eReason,
                                        IN uint32 uiPrivateData);


#if 1
/*! \brief API IFX_DECT_DPSU_ShutDectDataApp is invoked to shut down the 
           application completely.
    \param[in] Discard Null value.
    \return IFX_SUCCESS or iFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ShutDectDataApp (void *Discard);

#endif


/*! \brief IFX_DECTAPP_CD_Thread_Function executes in thread context.It is the
           entry function for FT Application.
    \return IFX_SUCCESS or IFX_FAILURE.
*/	

e_IFX_Return IFX_DECTAPP_CD_Thread_Function();


/*! \brief IFX_DECTAPP_CD_HTTP_GetVersion API is used to get the HTTP version from 
           the HTTP Get request message.
    \param[in] pcBuff pointer to get request buffer.
    \param[in] iBufLen length of buffer.
    \param[out] HTTP version number 1.0 or 1.1
    \return IFX_SUCCESS or IFX_FAILURE.
*/	

e_IFX_Return IFX_DECTAPP_CD_HTTP_GetVersion (IN char8 *pcBuff, 
               				     IN int32 iBufLen, 
					     OUT int32 *iHTTP);


/*! \brief The API IFX_DECTAPP_CD_HTTP_GetCode gets the code of an HTTP Response 
           message.The code extracted from the response message is returned.
    \param[in] pcBuff pointer to buffer containing response from server.
    \param[in] iBufLen Length of response buffer.
    \param[in] iCode Code of the response.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECTAPP_CD_HTTP_GetCode (IN char8 *pcBuff, 
             				  IN int32 iBufLen, 
					  OUT int32 *iCode);


/*! \brief The API IFX_DECTAPP_CD_Strcmp compares two strings upto length given
           by iLen(including blank spaces,if any).
	\param[in] acA[] String to be compared.
	\param[in] acB[] String to be compared.
	\param[in] iLen length upto which the strings need to be compared.
    \return 0 or 1.Return value 0 indicates strings are equal and 1 indicates 
	        they are unequal.          
*/

int32 IFX_DECTAPP_CD_Strcmp (IN char8 acA[], 
	      		     IN char8 acB[], 
			     IN int32 iLen);


/*! \brief API ContDownInit is used to initialize ContentDownload and create 
           placeholders for callback functions.
    \return IFX_SUCCESS or IFX_FAILURE;       
*/

e_IFX_Return IFX_DECT_ContDownInit();


/*! \brief API IFX_DECTAPP_CD_HTTP_GetURL is used to get the URL from GET request
           HTTP message.
    \param[in] pcBuff GET request buffer.
    \param[in] iBufLen length of buffer.
    \param[out] pcURL extracted URL.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECTAPP_CD_HTTP_GetURL (IN char8 *pcBuff, 
				         IN int32 iBufLen ,
					 OUT char8 *pcURL);



/*! \brief API IFX_DECTAPP_CD_atoaddr accepts address in dotted decimal as well 
           as in string notation and extracts port address.
    \param[in] pcAddress pointer to string containing address.
    \param[out] piPort Port Address.
    \return socket address of server or 0.    

*/

int32 IFX_DECTAPP_CD_atoaddr (IN char8 *pcAddress,
                              OUT uint32 *piPort);

#endif /*IFX_DECT_CONTENT_DOWNLOAD_H_*/ 
