/**************************************************************************
 **   SRC_FILE          : IFX_DECT_ContentDownload.h
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT DATA IWU
 **   SRC VERSION       : v0.1
 **   DATE              : 8th Oct 2007
 **   AUTHOR            : Aniketh
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
#ifdef LTQ_OSGI_POWER_OUTLET
/*! \file IFX_DECT_ContentDownload.h
    \brief FT Application
*/

#ifndef __IFX_DECT_OSGI_CONTENT_DOWNLOAD_H__
#define __IFX_DECT_OSGI_CONTENT_DOWNLOAD_H__

#include <netinet/in.h>
/** \ingroup DECT_SS_1_1
    \defgroup FT Application acts as an interface between the DECT Toolkit and the Data App.
    \brief This file stores structures,macros,enumerations and API prototypes 
	   and callback function definitions useful for FT Application to meet
	   DPSU requirements.
*/
/*@{*/

/*! \brief IFX_DECTAPP_CD_REQ_MAXBUFLEN Maximum length of request buffer.
           Request is made by PT. 
*/

#define IFX_DECTAPP_CD_REQ_MAXBUFLEN 3000


/*! \brief IFX_DECTAPP_CD_RSP_MAXBUFLEN Maximum Response Buffer length 
           from the server.
*/

#define IFX_DECTAPP_CD_RESP_MAXBUFLEN 65535


/*! \brief IFX_DECTAPP_CD_MAX_CONN Maximum number of connections available.
           Equal to maximum number of handsets.
*/

#define IFX_DECTAPP_CD_MAX_CONN 6

/*! \brief typedef for thread function.*/
typedef void *(*THREAD_RTN_PTR)(void*);


/*! \brief enum describing status of connection.*/

typedef enum{
        IFX_DECTAPP_CD_IDLE,
        IFX_DECTAPP_CD_CLOSED,
		IFX_DECTAPP_CD_HTTP10CLOSED,
        IFX_DECTAPP_CD_UNSPEC_OPEN,
        IFX_DECTAPP_CD_HTTP11,
        IFX_DECTAPP_CD_HTTP10,
        }e_IFX_DECTAPP_CD_ConnFlag;


/** x_IFX_DECT_ConnectionStruct structure stores the information pertaining to 
    a connection.
*/
typedef struct
{
 int32 iSessionId;                  /*!< Call Handle*/
 int32 SockFd;                      /*!< Socket FD*/
 struct sockaddr_in Serv_Addr;      /*!< Address for socket*/
 e_IFX_DECTAPP_CD_ConnFlag status;  /*!< status of the connection*/

 /*!< TCP handling Parameters */
 uint32 iCode;                      /*!< response code*/
 
 /*!< REQ Parameters*/
 char8 cbReqBuf[IFX_DECTAPP_CD_REQ_MAXBUFLEN];     /*!< Buffer for holding get request*/
 int32 iReqBufLen;                  /*!< length of the request buffer*/
 
 /*!< RESP Parameters*/
 char8 cbRespBuf[IFX_DECTAPP_CD_RESP_MAXBUFLEN];   /*!< response buffer*/
 int32 iRespBufLen;                 /*!< length of the response from server*/
 
 uchar8 IsDevice; // Connection with a DECT Power Plug, or handset
 uchar8 DeviceId; // For plugs an ID is assigned upon sending hello message
 uchar8 Status; // In which state is the device
 
 uchar8 IsUsed;                     /*!< Indicates whether this connection is free or used*/
}x_IFX_DECTAPP_CD_ConnectionStruct;
 

/*! \brief enum describing events on SOCK FD.*/

typedef enum {
       IFX_DECTAPP_CD_ADD_SOCK_FD,
       IFX_DECTAPP_CD_WRITE_SOCK_FD,//
       IFX_DECTAPP_CD_REMOVE_SOCK_FD,
       IFX_DECTAPP_CD_EXIT_APP,
       IFX_DECTAPP_CD_DATA_CALL_INIT,
       IFX_DECTAPP_CD_DEFAULT
}e_IFX_DECTAPP_CD_Events;


/** x_IFX_DECT_Message structure encapsulates event and connection Information*/

typedef struct 
{
  e_IFX_DECTAPP_CD_Events Event;
  x_IFX_DECTAPP_CD_ConnectionStruct *pxConnId;
}x_IFX_DECTAPP_CD_Message;


/*! \brief The API IFX_DECTAPP_CD_Init initializes the FT Application and spawns
           a new thread for it.
    \return IFX_SUCCESS or IFX_FAILURE.
*/    

e_IFX_Return IFX_DECT_DPSU_Init (void *);


/*! \brief IFX_DECT_DPSU_CallInitiate,this callback function is issued when the PT
           initiates a Data Call to communicate with the Download Server.
    \param[in] uiCallHdl unique Connection handle.
    \param[in] ucHandsetId Handset Number.
    \param[in] uiIEHdl Information Element handle.
    \param[out] pucRejectReason Reason for Call reject.
    \param[out] puiPrivateData data specific to app used to uniquely identify 
                a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_CallInitiate (IN uint32 uiCallHdl,
                                         IN uchar8 ucHandsetId,
                                         IN uint32 uiIEHdl,
                                         OUT uchar8 *pucRejectReason,
                                         OUT uint32 *puiPrivateData);


/*! \brief IFX_DECT_DPSU_DataSendToIP callback function is called when there 
           is a request from the PT for the download server and the application 
           needs to connect to the server.
    \param[in] uiCallHdl Connection handle identifying a connection.
    \param[in] pcBuff Request buffer from PT. 
    \param[in] iLen Length of the buffer.
    \param[in] uiPrivateData identifies unique connection,application specific.
    \return IFX_SUCCESS or IFX_FAILURE.
*/    
    
e_IFX_Return IFX_DECT_DPSU_DataSendToIP (IN uint32 uiCallHdl,
                                              IN char8 *pcBuff, 
		                              IN int32 iLen,
                                              IN uint32 uiPrivateData);
			    

/*! \brief IFX_DECT_DPSU_CallRelease callback function is called once the DECT 
           stack closes the connection.
    \param[in] uiCallHdl unique Connection Handle.
    \param[in] uiIEHdl Information Element Handle.
    \param[in] eReason Reason for Release.
    \param[in] uiPrivateData data specific to app used to uniquely identify
               a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ReleaseCall( IN uint32 uiCallHdl,
                                        IN uint32 uiIEHdl,
                                        IN e_IFX_DECT_RelType eReason,
                                        IN uint32 uiPrivateData);


/*! \brief IFX_DECTAPP_CD_Thread_Function executes in thread context.It is the
           entry function for FT Application.
    \return IFX_SUCCESS or IFX_FAILURE.
*/	

e_IFX_Return IFX_DECTAPP_CD_Thread_Function();



/*! \brief IFX_DECTAPP_CD_HTTP_GetVersion API is used to get the HTTP version from 
           the HTTP Get request message.
    \param[in] pcBuff pointer to get request buffer.
    \param[in] iBufLen length of buffer.
    \param[out] HTTP version number 1.0 or 1.1
    \return IFX_SUCCESS or IFX_FAILURE.
*/	

e_IFX_Return IFX_DECTAPP_CD_HTTP_GetVersion (IN char8 *pcBuff, 
               				     IN int32 iBufLen, 
					     OUT int32 *iHTTP);


/*! \brief The API IFX_DECTAPP_CD_HTTP_GetCode gets the code of an HTTP Response 
           message.The code extracted from the response message is returned.
    \param[in] pcBuff pointer to buffer containing response from server.
    \param[in] iBufLen Length of response buffer.
    \param[in] iCode Code of the response.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECTAPP_CD_HTTP_GetCode (IN char8 *pcBuff, 
             				  IN int32 iBufLen, 
					  OUT int32 *iCode);


/*! \brief The API IFX_DECTAPP_CD_Strcmp compares two strings upto length given
           by iLen(including blank spaces,if any).
	\param[in] acA[] String to be compared.
	\param[in] acB[] String to be compared.
	\param[in] iLen length upto which the strings need to be compared.
    \return 0 or 1.Return value 0 indicates strings are equal and 1 indicates 
	        they are unequal.          
*/

int32 IFX_DECTAPP_CD_Strcmp (IN char8 acA[], 
	      		     IN char8 acB[], 
			     IN int32 iLen);


/*! \brief API ContDownInit is used to initialize ContentDownload and create 
           placeholders for callback functions.
    \return IFX_SUCCESS or IFX_FAILURE;       
*/

e_IFX_Return IFX_DECT_ContDownInit();


/*! \brief API IFX_DECTAPP_CD_HTTP_GetURL is used to get the URL from GET request
           HTTP message.
    \param[in] pcBuff GET request buffer.
    \param[in] iBufLen length of buffer.
    \param[out] pcURL extracted URL.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECTAPP_CD_HTTP_GetURL (IN char8 *pcBuff, 
				         IN int32 iBufLen ,
					 OUT char8 *pcURL);



/*! \brief API IFX_DECTAPP_CD_atoaddr accepts address in dotted decimal as well 
           as in string notation and extracts port address.
    \param[in] pcAddress pointer to string containing address.
    \param[out] piPort Port Address.
    \return socket address of server or 0.    

*/

int32 IFX_DECTAPP_CD_atoaddr (IN char8 *pcAddress,
                              OUT uint32 *piPort);
							  
e_IFX_Return IFX_DECT_DPSU_HandleIncommingData (IN uint32 uiCallHdl, IN char8 *pcBuff, IN int32 iLen, IN uint32 uiPrivateData);
e_IFX_Return IFX_DECTAPP_AIM_GetConnectedDevices(OUT char8* devs);
e_IFX_Return IFX_DECTAPP_AIM_SendDeviceList(int32* sessionId);
e_IFX_Return IFX_DECTAPP_AIM_PrintConnInfo();
e_IFX_Return IFX_DECTAPP_AIM_CalcDeviceId(uchar8* devId);
e_IFX_Return IFX_DECTAPP_AIM_HandleSubscription(uchar8 devId);
e_IFX_Return IFX_DECTAPP_AIM_HandleDeviceMessage(x_IFX_DECTAPP_CD_ConnectionStruct * connStruct, uchar8* msgPtr);
e_IFX_Return IFX_DECTAPP_AIM_HandleSetStatus(uchar8 devId, uchar8 status);

#endif /*IFX_DECT_OSGI_CONTENT_DOWNLOAD_H_*/ 
#endif /*LTQ_OSGI_POWER_OUTLET*/ 
