/** RSS -Feeds field identifiers */
#ifndef __IFX_DT_LAU_H__
#define __IFX_DT_LAU_H__

#define IFX_DECT_MW_EVT_STYPE_RSS 0x81
#define IFX_DECT_MW_EVT_STYPE_SMS 0x82
#define IFX_DECT_MW_EVT_STYPE_EMAIL 0x83


#define IFX_DT_LAU_MAX_PROP_LISTS 5
#define IFX_DT_MAX_EDITABLE 10 
#define IFX_DT_MAX_UNEDITABLE 10 

#define IFX_DT_LEVEL_TREE_LIST 0
#define IFX_DT_LEVEL_SUB_LIST 1
#define IFX_DT_LEVEL_SUB_SUBLIST 2

#define IFX_DT_MAX_TEXT_SEGMENT_LENGTH 250 

#define IFX_DT_TEXT_SEGMENT_LENGTH 250 

#define IFX_EDITABLE_FIELD 0xC0
#define IFX_NON_EDITABLE_FIELD 0x80
#define IFX_COMPL_VALUE 0x7F

#define IFX_DT_LAU_RSS_CHNL_TITLE      						0x01
#define IFX_DT_LAU_RSS_CHNL_TYPE 										0x02
#define IFX_DT_LAU_RSS_CHNL_URL 										0x03
#define IFX_DT_LAU_RSS_CHNL_UNREAD_MSGS 						0x04
#define IFX_DT_LAU_RSS_CHNL_TOTAL_MSGS 							0x05
#define IFX_DT_LAU_RSS_CHNL_ATTACHED_HANDSETS 			0x06
#define IFX_DT_LAU_RSS_CHNL_UPDATE_TIME 						0x07

#define IFX_DT_LAU_RSS_CHNL_ENTRY_DATE_TIME 				0x01
#define IFX_DT_LAU_RSS_CHNL_ENTRY_READ_STATUS 			0x02
#define IFX_DT_LAU_RSS_CHNL_ENTRY_TITLE 						0x03
#define IFX_DT_LAU_RSS_CHNL_ENTRY_URL 							0x04

#define IFX_DT_LAU_RSS_CHNL_ENTRY_TEXT 							0x01

#define IFX_MAX_URL_LEN 128
#define IFX_MAX_TEXT_LEN  512 
#define IFX_MAX_TITLE_LEN 64
#define IFX_MAX_NUM_OF_SUB_ENTRIES 10
#define IFX_MAX_NUM_OF_CHANNELS 10
#define IFX_MAX_NUM_OF_MAIL_ENTRIES 10
#define IFX_MAX_NUM_OF_MAIL_ACCOUNTS 10 
#define IFX_DECT_LAU_MAX_ZIP_LEN 10
#define IFX_MAX_NET_PHONE_BOOK_ENTRIES 10
typedef enum {
  IFX_DT_MSG=0x20, /*!< Messaging channel */
  IFX_DT_READ=0x00 /*!< Reading channel  */
}e_IFX_RSS_ChannelType;

typedef enum{
	IFX_DT_FAX=1,
	IFX_DT_MOBILE=4,
	IFX_DT_FIXED=8
}e_IFX_PHONE_NUMBER_TYPE;

/*!
    \brief Structure describing the Time and Date Info.
*/
typedef struct
{
    uchar8 ucYear[4]; /*!< Date: Year */
    uchar8 ucMonth[2]; /*!< Date: Month */
    uchar8 ucDay[2]; /*!< Date: Day */
} x_IFX_DECT_Date;

typedef struct
{
    uchar8 ucHr[2]; /*!<Hour */
    uchar8 ucMin[2]; /*!< Min */
   // uchar8 ucSec[2]; /*!< Seconds */
}x_IFX_DT_Time;

typedef struct{
	x_IFX_DECT_Date xDate; 
	x_IFX_DT_Time xTime;
}x_IFX_DT_DateTime;

/******************
Data structures
**********************/
typedef struct{
int16 nEntryId; /* Entry ID of Text segment Entry */
uchar8  ucText[IFX_DT_TEXT_SEGMENT_LENGTH]; /* Entry Text */
}x_IFX_TEXT_SUB_ENTRY;

typedef struct{
uchar8 ucNumOfEntries; /*!< Number of Sublist entries */
x_IFX_TEXT_SUB_ENTRY axSubTextEntiries[IFX_MAX_NUM_OF_SUB_ENTRIES];
}x_IFX_SUB_SUBLIST;

typedef x_IFX_SUB_SUBLIST x_IFX_RSS_SUB_SUBLIST;
 
/* Rss Feeds Entry(Sub-List) Data structure */

typedef struct 
{
int16 nEntryId; /* Entry ID of RSS Entry */
x_IFX_DECT_USU_TimeDate xTimeDate; /* Date and time of Entry */
x_IFX_DT_DateTime xDateTime; /* Date and time Entry */
uchar8 bStatus;/*! Status - Read/UnRead */
uchar8  ucTitle[IFX_MAX_TITLE_LEN]; /* RSS Entry Tittle */
uchar8  ucText[IFX_DT_MAX_TEXT_SEGMENT_LENGTH * IFX_MAX_NUM_OF_SUB_ENTRIES]; /* RSS Entry Text */
uchar8 ucURL[IFX_MAX_URL_LEN]; /* Rss Entry URL */
}x_IFX_RSS_SUBLIST;

typedef struct
{
 uchar8 ucNumOfEntries; /*!< Number of Sublist entries */
 x_IFX_RSS_SUBLIST axChannelEntries[IFX_MAX_NUM_OF_SUB_ENTRIES];
}x_IFX_RSS_SUBLISTFEEDS;

/* Rss-Feeds Channel Data Structutre */

typedef struct 
{
	int16 nEntryId; /* Channel Entry ID */
	uchar8 ucChannelTitle[IFX_MAX_TITLE_LEN]; /* Channel Tittle */
	e_IFX_RSS_ChannelType eChannelType; /* Channel Type */
	uchar8 ucChannelURL[IFX_MAX_URL_LEN];	 /* Channel URL */
	x_IFX_DECT_LAU_AttachedPP xAttachedPP; /* Attached Handset's */
	uchar8 ucUnreadMsgCount; /* RSS Channel Unread Message Count */
	uchar8 ucTotalMsgCount; /* Rss Channel Total Message Count */
	uint32 uiUpdateIntrvl; /* Update Interval */
}x_IFX_RSS_CHANNEL;

/* Rss-Feeds Data Structure */

typedef struct
{
 uchar8 ucNumOfChannels; /*!< Number of Chanels */
 x_IFX_RSS_CHANNEL axChannelList[IFX_MAX_NUM_OF_CHANNELS];/*Channel list */
}x_IFX_RSS_FEEDS;


/***
 * Email related Fields & Data structures
*/
#define IFX_DT_LAU_EMAIL_ACC_NAME                  0x01
#define IFX_DT_LAU_EMAIL_ACC_UNREAD_MSGS           0x02
#define IFX_DT_LAU_EMAIL_ACC_TOTAL_MSGS            0x03
#define IFX_DT_LAU_EMAIL_ACC_ADDRESS               0x04
#define IFX_DT_LAU_EMAIL_ACC_ATTACHED_HANDSETS     0x05
#define IFX_DT_LAU_EMAIL_ACC_UPDATE_TIME           0x06

#define IFX_DT_LAU_EMAIL_ENTRY_READ_STATUS         0x01
#define IFX_DT_LAU_EMAIL_ENTRY_DATE_TIME           0x02
#define IFX_DT_LAU_EMAIL_ENTRY_ADDRESS             0x03
#define IFX_DT_LAU_EMAIL_ENTRY_SUBJECT             0x04

#define IFX_DT_LAU_EMAIL_ENTRY_TEXT                0x01

/* E-Mail Inbox Entry Data Structure */
typedef struct
{
	int16 nEntryId; /* Entry ID */
	uchar8 ucFromAddress[IFX_MAX_URL_LEN]; /* Email From Address */
	uchar8 ucSubject[IFX_MAX_TITLE_LEN]; /* Email Subject */
	uchar8 ucMessage[IFX_DT_MAX_TEXT_SEGMENT_LENGTH * IFX_MAX_NUM_OF_SUB_ENTRIES];/* Email Text */
	x_IFX_DECT_USU_TimeDate xTimeDate;/* Email Date and Time */
	x_IFX_DT_DateTime xDateTime; /* Date and time Entry */
	uchar8 bStatus; /* Email Read Status */
}x_IFX_EMAIL_INBOX_ENTRY;

typedef struct
{
 uchar8 ucNumOfEntries; /*!< Number of Email entries*/
	 uint32 uiEditField;
	x_IFX_EMAIL_INBOX_ENTRY axInboxEntries[IFX_MAX_NUM_OF_MAIL_ENTRIES];
}x_IFX_EMAIL_INBOXENTRIES;

/* E-Mail Inbox/Account  Data Structure */
typedef struct
{
	int16 nEntryId; /*Entry ID */
	uint32 uiEditField;/*!< Mark Editable fiels in the list */
	uchar8 ucAccountName[IFX_MAX_TITLE_LEN]; /* Email Account Name */
	uchar8 ucUnreadMsgs; /* Number of unRead E-Mails */
	uchar8 ucTotalMsgs; /* Total Number of E-Mails */
	uchar8 ucEmailAddress[IFX_MAX_URL_LEN]; /* Account Email ID */
  x_IFX_DECT_LAU_AttachedPP xAttachedPP; /* Attached handset list */
	uint32	uiUpdateTime;/* Account updatation time */
}x_IFX_EMAIL_ACCOUNT;

/* E-Mail Data Structure */

typedef struct
{
 uchar8 ucNumOfAccounts; /*!< Number of Configured Email Accounts*/
	uint32 uiEditField;
 x_IFX_EMAIL_ACCOUNT axMailAccounts[IFX_MAX_NUM_OF_MAIL_ACCOUNTS];/*Account list */
}x_IFX_EMAIL;


int32 IFX_DT_LAU_EncodeRSS(IN int16 nSessId, IN uchar8 ucHSId,IN x_IFX_RSS_FEEDS* pRssList, 
															OUT uint16* puiPayloadSize,OUT uchar8* pucDataPayload);

int32 IFX_DT_LAU_EncodeRSSChannel(IN int16 nSessId, IN uchar8 ucHSId, IN x_IFX_RSS_SUBLISTFEEDS* pRssSublist,
     OUT uint16* pPayloadSize,OUT uchar8* pDataPayload);



int32 IFX_DT_LAU_EncodeEmailAccountList(IN int16 nSessId, IN uchar8 ucHSId,IN x_IFX_EMAIL* pEmailList,
																OUT uint16* puiPayloadSize, OUT uchar8* pucDataPayload);

int32 IFX_DT_LAU_EncodeEmailList(IN int16 nSessId, IN uchar8 ucHSId, IN x_IFX_EMAIL_INBOXENTRIES* pEmailList,
     														OUT uint16* pPayloadSize,OUT uchar8* pDataPayload);


#define IFX_DT_LAU_NET_PHONE_BOOK_LAST_NAME  0x01
#define IFX_DT_LAU_NET_PHONE_BOOK_FIRST_NAME 0x02
#define IFX_DT_LAU_NET_PHONE_BOOK_NUMBER     0x03
#define IFX_DT_LAU_NET_PHONE_BOOK_CITY       0x04
#define IFX_DT_LAU_NET_PHONE_BOOK_ZIP        0x05
#define IFX_DT_LAU_NET_PHONE_BOOK_STREET     0x06
#define IFX_DT_LAU_NET_PHONE_BOOK_BDATE      0x07

/* Net Phone book phone Entry Data Structure */
typedef struct
{
  int16 nEntryId; /* Entry ID */
	uint32 uiEditField;/*!< Mark Editable fields in the list */
  char8 acLastName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< Last Name */
  char8 acFirstName[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< First Name */
	char8 acCity[IFX_DECT_LAU_MAX_NAME_LEN];/*!< City Name */
	char8 acStreet[IFX_DECT_LAU_MAX_NAME_LEN]; /*!< State Name */
	char8 acZip[IFX_DECT_LAU_MAX_ZIP_LEN]; /*!< Zip code */
	x_IFX_DECT_LAU_ContactNumberEntry xNumber; /*!< Contact Number list */	
	x_IFX_DECT_Date xBirthDay;
}x_IFX_NET_PHONE_BOOK_ENTRY;


typedef struct
{
  uchar8 unNoOfEntries; /*!< Number of Phone Book entries*/
  x_IFX_NET_PHONE_BOOK_ENTRY axPhoneBookEntries[IFX_MAX_NET_PHONE_BOOK_ENTRIES];
}x_IFX_NET_PHONE_BOOK;

e_IFX_Return IFX_DT_LAU_EncodeNetPhoneBook(IN int16 nSessId, IN uchar8 ucHSId, IN x_IFX_NET_PHONE_BOOK *pPhoneBook,
                   OUT uint16* punPayloadSize, OUT uchar8* pucDataPayload);

e_IFX_Return IFX_DT_TreeList_DataPktPayloadEncode( IN int16 nSessId,
                                   IN uchar8 ucListCmdType,
                   IN void* pvPayloadStruct,
                   OUT uint16* punPayloadSize,
                   OUT char8* pucDataPayload);

e_IFX_Return IFX_DT_SubList_DataPktPayloadEncode( IN int16 nSessId,
                                   IN uchar8 ucListCmdType,
                   IN void* pvPayloadStruct,
                   OUT uint16* punPayloadSize,
                   OUT char8* pucDataPayload);

e_IFX_Return IFX_DECTAPP_isProprietaryList(IN uchar8 pucListId);

uchar8 IFX_DECTAPP_getListAccessListId(IN uchar8 pucListId);

e_IFX_Return IFX_DT_Get_TreeList_EditUnEditFields(IN uchar8 pucListId,
                             OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);

e_IFX_Return IFX_DT_Get_TreeList_SortingFields(IN uchar8 pucListId,
                             OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);
e_IFX_Return IFX_DT_Get_SubList_EditUnEditFields(IN uchar8 pucListId,
                             OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);

e_IFX_Return IFX_DT_Get_SubSubList_EditUnEditFields(IN uchar8 pucListId,
                             OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd);

void IFX_DT_PopulateSupportedFieldMap(IN OUT uint32 *puiList);
e_IFX_Return

IFX_DT_SubSubList_DataPktPayloadEncode( IN int16 nSessId,
                                   IN uchar8 ucListCmdType,
                   IN void* pvPayloadStruct,
                   OUT uint16* punPayloadSize,
                   OUT char8* pucDataPayload);
e_IFX_Return
IFX_DECT_LAU_DT_Notify(uchar8 ucHandsetId,uchar8 rss_count,uint16 RSSUnreadMsg,uchar8 mail_count,uint16 MailUnreadMsg);

e_IFX_Return
IFX_DECT_LAU_EmailNotify(uchar8 ucHandsetId,uchar8 rss_email,uint16 ucNoOfUnreadMsg);



#endif
