/**************************************************************************
 **   SRC_FILE          : IFX_DECT_COMMIF.c
 **   PROJECT           : DECT-OSGI IWU
 **   MODULES           : DECT DATA IWU
 **   SRC VERSION       : v1.0
 **   DATE              : 15th Dec 2010
 **   AUTHOR            : Sandor Plosz
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
#ifdef LTQ_OSGI_POWER_OUTLET
#include <stdlib.h>             
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stddef.h>
#include <sys/types.h>
#include <sys/socket.h>         
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>            
#include <unistd.h>
#include <sys/select.h>         
#include <sys/un.h>
#include <errno.h>
#include <fcntl.h>
#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_DPSU.h"
#include "ifx_debug.h"
#include "IFX_DECT_COMMIF.h"
//#include "IFX_DECT_GlobalInfo.h"

extern uchar8 vucDectAgnetModId;

#define a vucDectAgnetModId
#define b IFX_DBG_LVL_NORMAL
#define c IFX_DBG_STR
#define d IFX_DBG_STR

#undef printf
#define IFX_PRINT printf
#define DEBUG_APP 0

x_IFX_DECTAPP_COMMIF_ConnectionStruct connStruct[IFX_DECTAPP_COMMIF_MAX_CONN]; 

struct addrinfo sock_addrinfo, *sock_res;
struct sockaddr_storage client_addr;
socklen_t client_addr_size;
int if_socket_fd = -1, con_socket_fd = -1;

/*! \brief API ContDownInit is used to initialize ContentDownload and create 
           placeholders for callback functions.
    \return IFX_SUCCESS or IFX_FAILURE;       
*/
e_IFX_Return IFX_DECTAPP_COMMIF_Init()
{

  x_IFX_DECT_DPSU_CallBks xCallBks={0};
  pthread_t Thread;
  int i;
 
  IFX_DBGA (a,b,c," (v1.1) Init:Entry.");
  //Registering DPSU callbacks
  xCallBks.pfnCallInitiate= IFX_DECT_DPSU_CallInitiate;
  xCallBks.pfnDataSendToIP = IFX_DECT_DPSU_HandleIncommingData;
  xCallBks.pfnCallRelease =IFX_DECT_DPSU_ReleaseCall;

  if(IFX_DECT_DPSU_RegisterDataApp(1,&xCallBks) == IFX_FAILURE){

    IFX_DBGA (a,b,c," ERROR: RegisterDataApp failed.");
    return IFX_FAILURE;
  }   
  
  for(i=0;i< IFX_DECTAPP_COMMIF_MAX_CONN;i++) {
	  connStruct[i].conState = IFX_DECTAPP_CONN_STATE_UNUSED;
	  connStruct[i].iSessionId = 0;
  }

  //IFX_DBGA (a,b,c,"<DECT_COMMIF_App> Init:Successful. Creating new thread for the socket communication");
  if (pthread_create (&Thread, NULL,(THREAD_RTN_PTR)IFX_DECTAPP_COMMIF_Loop_Thread, NULL)){     
    IFX_DBGA (a,b,c," ERROR: creating new thread failed."); 
    return IFX_FAILURE;
  }  
  
  return IFX_SUCCESS;
}

e_IFX_Return IFX_DECTAPP_COMMIF_Loop_Thread()
{
  int read_bytes, i;
  char msg[300]; 
    
  memset(&sock_addrinfo, 0, sizeof sock_addrinfo);
  sock_addrinfo.ai_family = AF_INET ;  // use IPv4 or IPv6, whichever
  sock_addrinfo.ai_socktype = SOCK_STREAM;
  sock_addrinfo.ai_flags = AI_PASSIVE;     // fill in my IP for me
  
  getaddrinfo(NULL, IFX_DECTAPP_COMMIF_SOCKET_LISTEN_PORT, &sock_addrinfo, &sock_res);

  if_socket_fd = socket(sock_res->ai_family, sock_res->ai_socktype, sock_res->ai_protocol);
  if(if_socket_fd == -1)
  {
	perror("error opening socket");
	return -1;
  }
  
  if(bind(if_socket_fd, sock_res->ai_addr,sock_res->ai_addrlen) == -1)
  {
	perror("error binding socket");
	return -1;
  } 
  
  if(listen(if_socket_fd, 1) == -1)  
  {
	perror("error listening socket");
	return -1;
  }  
   
  client_addr_size = sizeof(client_addr);
  
  while(1) { 
	IFX_DBGA (a,b,c," Listening on socket for new connection...");
	con_socket_fd = accept(if_socket_fd, (struct sockaddr *)&client_addr, &client_addr_size); 
	if(con_socket_fd == -1)
	{
	  perror("error accepting socket");
	  continue;
	}  
	else IFX_DBGA (a,b,c," Incomming connection accepted, waiting for data...");

	while((read_bytes = recv(con_socket_fd, msg, sizeof(msg), 0)) > 0)
	{
	  if(IFX_DECTAPP_COMMIF_HandleIncomingData((unsigned char*)msg,read_bytes) == IFX_FAILURE)
	  {
		IFX_DBGA (a,b,c," Client sent invalid data, closing socket...!");
		close(con_socket_fd);
		break;
	  }
	}
	if(read_bytes == 0)	IFX_DBGA (a,b,c," Socket connection was terminated on the client!");  

	//Releasing any ongoing calls
	IFX_DBGA (a,b,c," Releasing any ongoing data calls...");
	for(i=0;i< IFX_DECTAPP_COMMIF_MAX_CONN;i++) {
		if(connStruct[i].conState > IFX_DECTAPP_CONN_STATE_UNUSED) {
			IFX_DECT_DPSU_CallRelease(connStruct[i].iSessionId,0,IFX_DECT_RELEASE_NORMAL);
			connStruct[i].conState = IFX_DECTAPP_CONN_STATE_UNUSED;
		}
	}
  }

  return IFX_FAILURE; 
}

e_IFX_Return IFX_DECTAPP_COMMIF_HandleIncomingData(uchar8* data, uint32 length)
{
  int i;
  int32 iSocIndex = IFX_DECTAPP_COMMIF_MAX_CONN;
  uchar8* dataPtr;
  
  #if(DEBUG_APP)
  printf("<DECT_COMMIF_App> Data arrived from the socket: ");
  for(i=0;i<length;i++)
    printf(" %x",data[i]);  
  printf("\n");
  #endif
  
  x_IFX_DECTAPP_COMMIF_Message *incomMessage = (x_IFX_DECTAPP_COMMIF_Message*) data;
  
  if(incomMessage->magic != IFX_DECTAPP_COMMIF_MAGIC)
  {
    IFX_DBGA (a,b,c," Incoming data does not start with IFX_DECTAPP_COMMIF_MAGIC!!! \n");
	IFX_DECTAPP_COMMIF_Send_Error(incomMessage, IFX_DECTAPP_COMMIF_MODULE_MAIN, IFX_DECTAPP_COMMIF_ERROR_INVALID_MAGIC);
    return IFX_FAILURE;
  }
  
  if(incomMessage->moduleID != IFX_DECTAPP_COMMIF_MODULE_DPSU)
  {
    IFX_DBGA (a,b,c," Invalid moduleID : %x in message!!! \n",incomMessage->moduleID);
	IFX_DECTAPP_COMMIF_Send_Error(incomMessage, IFX_DECTAPP_COMMIF_MODULE_MAIN, IFX_DECTAPP_COMMIF_ERROR_INVALID_MODULEID);
    return IFX_SUCCESS;
  }  
  
  switch(incomMessage->cmdType)
  {
  
	case IFX_DECTAPP_COMMIF_DPSU_CallInitiate_REQ: // This function is not implemented in the current application	
	{	
		IFX_DBGA (a,b,c," IFX_DECTAPP_COMMIF_DPSU_CallInitiate_REQ command in message ");
	}
	break;
	
	case IFX_DECTAPP_COMMIF_DPSU_CallRelease_REQ:
	{
		IFX_DBGA (a,b,c," IFX_DECTAPP_COMMIF_DPSU_CallRelease_REQ command in message ");
		for(i=0;i< IFX_DECTAPP_COMMIF_MAX_CONN;i++) {
			if((connStruct[i].iSessionId == incomMessage->callHdl) && (connStruct[i].conState > IFX_DECTAPP_CONN_STATE_UNUSED)) iSocIndex=i;
			//break;
		}
		
		if(iSocIndex == IFX_DECTAPP_COMMIF_MAX_CONN){
		  IFX_DBGA (a,b,c," ERROR: IFX_DECTAPP_COMMIF_DPSU_CallRelease_REQ from socket : No such connection!");
		  //break;
		}	

		connStruct[iSocIndex].iSessionId = 0;
		connStruct[iSocIndex].conState = IFX_DECTAPP_CONN_STATE_UNUSED;
		
		IFX_DECTAPP_PrintConnInfo();
		
		if(IFX_DECT_DPSU_CallRelease(incomMessage->callHdl,0,IFX_DECT_RELEASE_NORMAL) == IFX_SUCCESS);
		//	IFX_DECTAPP_COMMIF_Send_Return(incomMessage,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_RETURN_SUCCESS);
		//else IFX_DECTAPP_COMMIF_Send_Return(incomMessage,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_RETURN_FAILURE);
	}
	break;
	
	case IFX_DECTAPP_COMMIF_DPSU_DataSending:
	{
		dataPtr = data;
		IFX_DBGA (a,b,c," IFX_DECTAPP_COMMIF_DPSU_DataSending command in message");
		while(length>0) {
			//printf("<DECT_COMMIF_App> Sending message to %i \n",  incomMessage->callHdl);
			if(IFX_DECT_DPSU_DataSendToDECT ((int32)incomMessage->callHdl, (char8*)incomMessage->data, incomMessage->dataLength) == IFX_SUCCESS);
			length-=(incomMessage->dataLength+8);
			dataPtr = (data+incomMessage->dataLength+8);
			incomMessage = (x_IFX_DECTAPP_COMMIF_Message*) dataPtr;
			//printf("First byte: %x \n",*dataPtr);
		}
		
		//	IFX_DECTAPP_COMMIF_Send_Return(incomMessage,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_RETURN_SUCCESS);
		//else IFX_DECTAPP_COMMIF_Send_Return(incomMessage,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_RETURN_FAILURE);		
	}
	break;
	
	case IFX_DECTAPP_COMMIF_DPSU_CallAccept_REQ:
	{
		IFX_DBGA (a,b,c," IFX_DECTAPP_COMMIF_DPSU_CallAccept_REQ command in message ");
		//printf("<DECT_COMMIF_App> Call handle: %i\n",incomMessage->callHdl);
		
		for(i=0;i< IFX_DECTAPP_COMMIF_MAX_CONN;i++) {
			if((connStruct[i].iSessionId == incomMessage->callHdl) && (connStruct[i].conState == IFX_DECTAPP_CONN_STATE_PENDING)) iSocIndex=i;	
			//break;
		}
		
		if(iSocIndex == IFX_DECTAPP_COMMIF_MAX_CONN){
		  IFX_DBGA (a,b,c," ERROR: IFX_DECTAPP_COMMIF_DPSU_CallAccept_REQ from socket : No such connection!");
		  //break;
		}

		if(IFX_DECT_DPSU_CallAccept(incomMessage->callHdl, 0) == IFX_SUCCESS) 
			connStruct[iSocIndex].conState = IFX_DECTAPP_CONN_STATE_ACCEPTED;
		else IFX_DBGA (a,b,c," ERROR: IFX_DECT_DPSU_CallAccept() call returned failure!");
		
		IFX_DECTAPP_PrintConnInfo();
		
		//IFX_DECTAPP_COMMIF_Send_Return(incomMessage,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_RETURN_SUCCESS);
		//else IFX_DECTAPP_COMMIF_Send_Return(incomMessage,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_RETURN_FAILURE);		
	}
	break;
	
	default:
		IFX_DBGA (a,b,c," Warning! Invalid command in message \n ");
		//IFX_DECTAPP_COMMIF_Send_Error(incomMessage,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_COMMIF_ERROR_INVALID_COMMAND);
	break;
  }
  
  return IFX_SUCCESS;
  
}



/*! \brief IFX_DECT_DPSU_CallInitiate,this callback function is issued when the PT
           initiates a Data Call to communicate with the Download Server.
    \param[in] uiCallHdl unique Connection handle.
    \param[in] ucHandsetId Handset Number.
    \param[in] uiIEHdl Information Element handle.
    \param[out] pucRejectReason Reason for Call reject.
    \param[out] puiPrivateData data specific to app used to uniquely identify 
                a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_CallInitiate (IN uint32 uiCallHdl,
                                         IN uchar8 ucHandsetId,//
                                         IN uint32 uiIEHdl,
                                         OUT uchar8 *pucRejectReason,//
                                         OUT uint32 *puiPrivateData){


	int32 iSocIndex = IFX_DECTAPP_COMMIF_MAX_CONN;
	x_IFX_DECTAPP_COMMIF_ConnectionStruct *pxConnectionId = NULL;
	e_IFX_Return ret;
	int i;
	
	IFX_DBGA (a,b,c," Callbk CallInitiate : Entry.");
	//printf("-----HandsetId is: %x ----\n",ucHandsetId);
	//printf("-----SessionId is: %i ----\n",uiCallHdl);

	if((NULL == pucRejectReason) || (0 == uiCallHdl)){
		IFX_DBGA (a,b,c,
		" Callbk CallInitiate:puiPrivateData or pucRejectReason is null,or uiCallHdl is 0.");
		return IFX_FAILURE;
	}
	
	//Store connection data here as well for safety
	for(i=0;i<IFX_DECTAPP_COMMIF_MAX_CONN;i++) {
	  if(connStruct[i].conState == IFX_DECTAPP_CONN_STATE_UNUSED) iSocIndex=i;	
	  //break;
	}
	  
	if(iSocIndex == IFX_DECTAPP_COMMIF_MAX_CONN){
      IFX_DBGA (a,b,c," Callback CallInitiate : No free Connection!");
	  return IFX_FAILURE;
	}
	
	connStruct[iSocIndex].iSessionId = uiCallHdl;
	connStruct[iSocIndex].conState = IFX_DECTAPP_CONN_STATE_PENDING;
	
	IFX_DECTAPP_PrintConnInfo();
	
	pxConnectionId = &connStruct[iSocIndex];
	*puiPrivateData = (uint32) &connStruct[iSocIndex];		
	
	//Notify the other end of an incoming call
	x_IFX_DECTAPP_COMMIF_Message msg;
	IFX_DECTAPP_COMMIF_Fill_Message(&msg,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_COMMIF_DPSU_CallInitiate_IND,uiCallHdl);
	ret = IFX_DECTAPP_COMMIF_Write_Data((uchar8*)&msg,sizeof(x_IFX_DECTAPP_COMMIF_Message)-20); 

	IFX_DBGA (a,b,c," Callbk CallInitiate:Successful.");
	return IFX_SUCCESS;
}
    

/*! \brief IFX_DECT_DPSU_CallRelease callback function is called once the DECT 
           stack closes the connection.
    \param[in] uiCallHdl unique Connection Handle.
    \param[in] uiIEHdl Information Element Handle.
    \param[in] eReason Reason for Release.
    \param[in] uiPrivateData data specific to app used to uniquely identify
               a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ReleaseCall( IN uint32 uiCallHdl,
                                        IN uint32 uiIEHdl,
                                        IN e_IFX_DECT_RelType eReason,
                                        IN uint32 uiPrivateData){
   
   x_IFX_DECTAPP_COMMIF_ConnectionStruct *pxConnectionId = (x_IFX_DECTAPP_COMMIF_ConnectionStruct*) uiPrivateData;
   
   IFX_DBGA (a,b,c," Callbk CallRelease : Entry."); 
   
   uiIEHdl = 0;
   if((0 == uiCallHdl) || (0 == uiPrivateData)){     
     IFX_DBGA (a,b,c," Callbk CallRelease : uiCallHdl or uiPrivateData is 0.");
     return IFX_FAILURE;
   }

   pxConnectionId->conState = IFX_DECTAPP_CONN_STATE_UNUSED;    
   pxConnectionId->iSessionId = 0;
   
   IFX_DECTAPP_PrintConnInfo();
   
   //Notify the other end of a data call release
   x_IFX_DECTAPP_COMMIF_Message msg;
   IFX_DECTAPP_COMMIF_Fill_Message(&msg,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_COMMIF_DPSU_CallRelease_IND,uiCallHdl);
   IFX_DECTAPP_COMMIF_Write_Data((uchar8*)&msg,sizeof(x_IFX_DECTAPP_COMMIF_Message)-20);   

   IFX_DBGA (a,b,c," Callbk CallRelease : Successful.");
   return IFX_SUCCESS;
}



//This function handles all the incomming data packets
e_IFX_Return IFX_DECT_DPSU_HandleIncommingData (IN uint32 uiCallHdl, IN char8 *pcBuff, IN int32 iLen, IN uint32 uiPrivateData)
{
  int32 i = 0;
  uchar8* pcTempBuff; 
    
  //IFX_DBGA (a,b,c, "<DECT_COMMIF_App>Callbk IFX_DECT_DPSU_HandleIncommingData entry");

  if((NULL == pcBuff) || (0 == uiCallHdl) ){ 
	IFX_DBGA (a,b,c, " ERROR: uiCallHdl or pcBuff is NULL!! ");
    return IFX_FAILURE;
  }
  
  pcTempBuff = (uchar8*) pcBuff;    
 
  //Debug print the data
  #if(DEBUG_APP)
  printf("<DECT_COMMIF_App> Callbk IFX_DECT_DPSU_HandleIncommingData, received data from DECT (CallHdl: %i): ", uiCallHdl);
  for(i=0;i<iLen;i++){
	printf("%x ",pcTempBuff[i]);
	if( (i>0) && (i%10 == 0)){
		printf("\n");
	}
  }
  printf("\n");
  #endif
    
  //IFX_DECTAPP_AIM_PrintConnInfo();
  
  //Forward message to the orher side of the communication interface
  x_IFX_DECTAPP_COMMIF_Message msg;
  IFX_DECTAPP_COMMIF_Fill_Message(&msg,IFX_DECTAPP_COMMIF_MODULE_DPSU,IFX_DECTAPP_COMMIF_DPSU_DataSending,uiCallHdl); 
  msg.dataLength = iLen;
  for(i=0;i<iLen;i++) msg.data[i] = pcTempBuff[i];
    
  IFX_DECTAPP_COMMIF_Write_Data((uchar8*)&msg,sizeof(x_IFX_DECTAPP_COMMIF_Message)-20+iLen);
  
  return IFX_SUCCESS;
}



e_IFX_Return IFX_DECTAPP_COMMIF_Write_Data(uchar8* data, uint32 length)
{
	int i;	
	i=0;
	
	if (send(con_socket_fd, data, length, 0) == -1) {
      IFX_DBGA (a,b,c, "  WARNING: no reader on the other side, ignoring message! \n");
      return IFX_FAILURE;
    }

	#if(DEBUG_APP)
	printf("<DECT_COMMIF_App> COMMIF_Write_Data: data sent on socket: ");
	for(i=0;i<length;i++)
		printf(" %x",data[i]);  
	printf("\n");
	#endif

	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECTAPP_COMMIF_Send_Return(x_IFX_DECTAPP_COMMIF_Message* origMsg, IFX_DECTAPP_COMMIF_MODULES moduleID, IFX_DECTAPP_ReturnType returnType)
{
    x_IFX_DECTAPP_COMMIF_Message newMsg;
	
    newMsg.magic = IFX_DECTAPP_COMMIF_MAGIC;
	newMsg.moduleID = moduleID;
	newMsg.cmdType = IFX_DECT_COMMIF_Return;
	newMsg.callHdl = 0;
	newMsg.dataLength = 1;
    newMsg.data[0] = returnType;
    IFX_DECTAPP_COMMIF_Write_Data((uchar8*)&newMsg,sizeof(x_IFX_DECTAPP_COMMIF_Message)-20);
	
	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECTAPP_COMMIF_Send_Error(x_IFX_DECTAPP_COMMIF_Message* origMsg, IFX_DECTAPP_COMMIF_MODULES moduleID, IFX_DECTAPP_COMMIF_ErrorType errorType)
{
    x_IFX_DECTAPP_COMMIF_Message newMsg;
	
	newMsg.magic = IFX_DECTAPP_COMMIF_MAGIC;
	newMsg.moduleID = moduleID;
    newMsg.cmdType = IFX_DECT_COMMIF_ERROR;
	newMsg.callHdl = 0;
	newMsg.dataLength = 1;
    newMsg.data[0] = errorType;
	
    IFX_DECTAPP_COMMIF_Write_Data((uchar8*)&newMsg,sizeof(newMsg)-20);
	
	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECTAPP_FIND_CALLID(uint32* callHdl, x_IFX_DECTAPP_COMMIF_ConnectionStruct* connStruct)
{
	int i;

	for(i=0;i< IFX_DECTAPP_COMMIF_MAX_CONN;++i){
	  if(connStruct[i].iSessionId==*callHdl){
	    connStruct = &connStruct[i];
		return IFX_SUCCESS;
	  }
	}
	
	return IFX_FAILURE;	
}


e_IFX_Return IFX_DECTAPP_COMMIF_Fill_Message(x_IFX_DECTAPP_COMMIF_Message* msg, 
											 IFX_DECTAPP_COMMIF_MODULES moduleID, 
											 IFX_DECTAPP_COMMIF_DPSU_Commands cmdType, 
											 uint32 callHdl) {

	msg->magic = IFX_DECTAPP_COMMIF_MAGIC;
	msg->moduleID = moduleID;
	msg->cmdType = cmdType;
	msg->callHdl = callHdl;
	msg->dataLength = 0;
	
	return IFX_SUCCESS;										 
											 
}

//Print application debug info
e_IFX_Return IFX_DECTAPP_PrintConnInfo()
{		
	#if(DEBUG_APP)
	int iLoop = 0;
	
	printf("\n--------------------------------------------------\n\t Connection# \t CallHdl \t State \n");
	for (iLoop = 0; iLoop < IFX_DECTAPP_COMMIF_MAX_CONN; iLoop++)
	{		      
		printf("\t   %i \t\t  %i \t \t %x \n",iLoop,connStruct[iLoop].iSessionId,connStruct[iLoop].conState);		
	} 
	printf("----------------------------------------------------\n\n ");
	
	#endif
	return IFX_SUCCESS;
}
#endif
