/**************************************************************************
 **   SRC_FILE          : IFX_DECT_ContentDownload.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT DATA IWU
 **   SRC VERSION       : v0.1
 **   DATE              : 28th Sep 2010/latest version
 **   AUTHOR            : 
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
#ifndef LTQ_OSGI_POWER_OUTLET
#define _GNU_SOURCE
#include <stdlib.h>             
#include <stdio.h>
#include <string.h>
#include <stddef.h>
#include <sys/types.h>
#include <sys/socket.h>         
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>            
#include <unistd.h>
#include <sys/select.h>         
#include <sys/un.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "ifx_debug.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_DPSU.h"
#include "IFX_DECT_ContentDownload.h"
#include <errno.h>
#include "ixml.h"
#define SPP_ARENDI 1

extern uchar8 vucDectAgnetModId;

pthread_t SUOTA_Thread;
unsigned int uiSUOTAvalue_ptr=0,*puiSUOTAvalue_ptr=NULL;
#define a vucDectAgnetModId
//#define b IFX_DBG_TYPE_CONSOLE
#define b IFX_DBG_LVL_NORMAL
#define c IFX_DBG_LVL_NORMAL
#define d IFX_DBG_STR

//#define IFX_DBGA(ucModuleId, ucDbgLvl, unMsgId, ...)
//#define IFX_DBGC(ucModuleId, ucDbgLvl, unMsgId,...)

#define printf(...)

char8 vacFPURL1[250]="";
char8 vacMsgBody[500]="";
x_IFX_DECTAPP_CD_ConnectionStruct vaxsoc_sock[IFX_DECTAPP_CD_MAX_CONN];
x_IFX_DECTAPP_SUOTA_SessionInfo vaxSuotaSess[IFX_DECTAPP_SUOTA_MAX_CONN];
x_IFX_DECTAPP_EventData vxCallIntnlSocket;
static uchar8 vucWrite;
#ifdef CD_TEST
static int32 aiFd[10][2] = {{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1},{-1,-1}};
#endif

fd_set vxGlobalReadFdS;
fd_set vxGlobalWriteFdS;  
fd_set vxGlobalExceptFdS;

int32 viInternalSockFd;
struct sockaddr_un vFILE_name;

int32 iHTTP;//check to be included in structure.
int32 size;//same as above.
//int32 SocIndex;
int32 arg,arg1;
int32 viReadLength;//same

e_IFX_Return IFX_DECTAPP_HTTP_GetHostNameFromUrl(char* psHostName, 
                                             const char* psUrl );
e_IFX_Return IFX_DECTAPP_SUOTA_VersionIndication (IN uchar8 ucHandsetId,											  
                                      IN x_IFX_DECT_SUOTA_VersionIndicationInfo *pxVerInfo);

#define IFX_DECTAPP_HTTP_SkipTill(pString, iLen, cChar) \
  { \
    while(*pString != cChar && iLen > 0) { \
      ++pString; \
      --iLen;    \
    } \
  }
  
e_IFX_Return 
IFX_DECTAPP_SUOTA_Const_5XX(uint16 uiResp,char8* pcMsgBody)
{
  time_t t;
	char8 str[30], acDate[30];
	time(&t);
	strcpy(acDate,ctime(&t));
	acDate[strlen(acDate)-1] = 0;
	switch(uiResp){
		case 500:
			strcpy(str,"Internal Server Error");
			break;
		case 501:
			strcpy(str,"Not Implemented");
			break;
		case 502:
			strcpy(str,"Bad Gateway");
			break;
		case 503:
			strcpy(str,"Service Unavailable");
			break;
		case 504:
			strcpy(str,"Gateway Timeout");
			break;
		case 505:
			strcpy(str,"HTTP Version Not Supported");
			break;
		default:
			return 1;
			break;
	}
	sprintf(pcMsgBody,"HTTP/1.1 %d %s\r\n"
			              "Date: %s\r\n"
										"Server: Lantiq CPE Light HTTP Server\r\n"
										"X-Powered: PHP/5.3.1\r\n"
			              "Content-Length: 0\r\n"
										"Connection: Close\r\n"
										"Content-Type: text/html\r\n"
										"\r\n",uiResp,str,acDate);
	return 0;
}
#if 0
e_IFX_Return
IFX_DECTAPP_ReqRetrans(x_IFX_DECTAPP_CD_ConnectionStruct pxConnectionId)
{
  char8 acHost[250]="";
  uint32 uiPort = 0;
  if(IFX_DECTAPP_CD_HTTP_GetURL (pxConnectionId->cbReqBuf,pxConnectionId->iReqBufLen,acHost) == IFX_FAILURE){

    IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "<ContentDownload>Get URL failed.");
    return IFX_FAILURE;
  }
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        "<ContentDownload>Opening a new external socket in non-blocking mode.");
	pxConnectionId->SockFd = socket (AF_INET, SOCK_STREAM, 0);

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
    "<ContentDownload>Socket is",pxConnectionId->SockFd);

  arg = fcntl (pxConnectionId->SockFd, F_GETFL, NULL);
  arg |= O_NONBLOCK;
  fcntl (pxConnectionId->SockFd, F_SETFL, arg);
    
  bzero ((char *) (&pxConnectionId->Serv_Addr), sizeof (pxConnectionId->Serv_Addr));

  pxConnectionId->Serv_Addr.sin_family = AF_INET;
  pxConnectionId->Serv_Addr.sin_addr.s_addr = IFX_DECTAPP_CD_atoaddr (acHost,&uiPort);
  pxConnectionId->Serv_Addr.sin_port = htons (uiPort);

  if (connect(pxConnectionId->SockFd,(const struct sockaddr *)&pxConnectionId->Serv_Addr,
                 sizeof (pxConnectionId->Serv_Addr)) < 0){
		      
    if (errno == EINPROGRESS){
		  FD_SET (pxConnectionId->SockFd, &vxGlobalWriteFdS);
      FD_SET (pxConnectionId->SockFd, &vxGlobalExceptFdS);
    }else{
    }
  }

}
#endif

e_IFX_Return IFX_DECTAPP_SUOTA_3xxHandle(IN uchar8 ucHandsetId,											  
                                      IN x_IFX_DECT_SUOTA_VersionIndicationInfo *pxVerInfo)
{
  char8 acURL[IFX_DECT_SUOTA_MAX_URL_LEN] = {'\0'};
  uint32 portno = 0;
  x_IFX_DECTAPP_SUOTA_SessionInfo *pxSuotaInfo = NULL;

  IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entry.");
  
  /*Initial Checks*/

  #ifdef ULE_SUPPORT
  if((ucHandsetId ==0)||(ucHandsetId > 224)){
    IFX_DBGC(a,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Incorrect Handset Id");
    return IFX_FAILURE;
  }  
  #else
  if((ucHandsetId ==0)||(ucHandsetId >IFX_DECT_MAX_HS) ){
    IFX_DBGC(a,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Incorrect Handset Id");
    return IFX_FAILURE;
  }  
  #endif
    
  pxSuotaInfo = &vaxSuotaSess[ucHandsetId-1];
  pxSuotaInfo->IsAvail=1;
  
  printf("Sw: %s Hw: %s EMC: %02X, FileNum:%d Reason: %d\n",
               pxVerInfo->acSwIdentifier,
               pxVerInfo->acHwVerIden,
               pxVerInfo->unEMC,
               pxVerInfo->ucFileNum,
               pxVerInfo->eReason);
  printf("3XX URL: %s\n",pxVerInfo->acSendUrl);

    pxSuotaInfo->ucHandsetId = ucHandsetId;
	  memcpy(&pxSuotaInfo->xVerInfo , pxVerInfo, sizeof(x_IFX_DECT_SUOTA_VersionIndicationInfo));	
    
    
	  memset(&pxSuotaInfo->xRecvUrl, 0, sizeof(x_IFX_DECTAPP_SUOTA_MgMtRecvUrl));
    IFX_DECTAPP_HTTP_GetHostNameFromUrl(acURL, 
                                pxSuotaInfo->xVerInfo.acUrl );
    IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_ATA_STRING_INFO,
               "<SUOTA>Host is:",acURL);
	  IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
      "Opening a new external socket in non-blocking mode to handle 3xx.");
	  pxSuotaInfo->SockFd = socket (AF_INET, SOCK_STREAM, 0);
		pxSuotaInfo->cbRespBuf_len=0;
        pxSuotaInfo->chunklen=0;
	
	IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
        "Socket is",pxSuotaInfo->SockFd);

    arg = fcntl (pxSuotaInfo->SockFd, F_GETFL, NULL);
    arg |= O_NONBLOCK;
    fcntl (pxSuotaInfo->SockFd, F_SETFL, arg);
    
    bzero ((char *) (&pxSuotaInfo->Serv_Addr), sizeof (pxSuotaInfo->Serv_Addr));

    pxSuotaInfo->Serv_Addr.sin_family = AF_INET;
    pxSuotaInfo->Serv_Addr.sin_addr.s_addr = IFX_DECTAPP_CD_atoaddr (acURL,&portno);
	  pxSuotaInfo->Serv_Addr.sin_port = htons (portno);
    
	  pxSuotaInfo->eStatus = IFX_DECTAPP_SUOTA_URL_SEND;
	
	  /*  Post the event to the internal socket */
    vxCallIntnlSocket.Event = IFX_DECTAPP_SUOTA_ADD_SOCK_FD;
    vxCallIntnlSocket.ux_IntEvent.pxSuotaId = pxSuotaInfo;
    //vxCallIntnlSocket.ux_IntEvent.pxConnId = NULL;
    
    IFX_DBGA (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
            "Posting Event and SuotaId to Internal Socket.");
    sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
          (struct sockaddr *) &vFILE_name, size);
	
   
  IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
          "IFX_DECTAPP_SUOTA_3xxHandle:Successful.");
  return IFX_SUCCESS;
}


int IFX_DECT_GetURL_3xx(char *response1,char *url)
{
   char *ptr,*ptr1;
   char response[2000];
	 if(response1 == NULL)
	 {
       return IFX_FAILURE;
	 }
   strcpy(response,response1);
   ptr=strstr(response,"302");
   if(ptr != NULL)
   {
     ptr1=strstr(response,"Content-Length");
		 if(ptr1 != NULL)
     {
       *ptr1='\0';
		 }
     ptr=strstr(response,"http:");
     if(ptr != NULL)
     {
        strcpy(url,ptr);
        printf("*********3xx URL %s\n",url);
	      return IFX_SUCCESS;
     }
	 }
	 return IFX_FAILURE;
}


e_IFX_Return 
IFX_DECTAPP_SUOTA_Const_4XX(uint16 uiResp,char8* pcMsgBody)
{
	uint16 uiContentLength = 0;
  time_t t;
	char8 str[30], acDate[30], acContent[50];
	time(&t);
	strcpy(acDate,ctime(&t));
	acDate[strlen(acDate)-1] = 0;
	switch(uiResp){
		case 401:
			strcpy(str,"Unauthorized");
			break;
		case 403:
			strcpy(str,"Forbidden");
			break;
		case 404:
			strcpy(str,"Not Found");
			strcpy(acContent,"404 Not Found\n");
			uiContentLength = strlen(acContent);
			break;
		case 408:
			strcpy(str,"Request Timeout");
			break;
		default:
			return 1;
			break;
	}
	sprintf(pcMsgBody,"HTTP/1.1 %d %s\r\n"
			              "Date: %s\r\n"
										"Server: Lantiq CPE Light HTTP Server\r\n"
										"X-Powered: PHP/5.3.1\r\n"
			              "Content-Length: %d\r\n"
										"Connection: Close\r\n"
										"Content-Type: text/html\r\n"
										"\r\n"
										"%s",uiResp,str,acDate,uiContentLength,acContent);
	return 0;
}




e_IFX_Return IFX_DECTAPP_HTTP_GetHostNameFromUrl(char* psHostName, 
                                             const char* psUrl )
{
  int16 iUrlLen;

  iUrlLen = strlen(psUrl);

  if ( 'h' == *psUrl || 'H' == *psUrl ) {
    /* skip HTTP:*/
    IFX_DECTAPP_HTTP_SkipTill(psUrl,iUrlLen,'/');
    psUrl += 2;
    iUrlLen -= 2;
    //Debug_printf("After HTTP :: %s\r\n",psUrl);
  }

  if ( iUrlLen > 0 ) {

    if ( ('w' == *psUrl) | ('w' == *(psUrl+1)) | ('w' == *(psUrl+2))) {
      psUrl += 4;  //including .
      iUrlLen -= 4;
    }
   
    if ( iUrlLen > 0 ) {
      /* Copy host name */
      while( *psUrl != '/' && iUrlLen > 0 ) {
        *psHostName = *psUrl;
        ++psHostName;
        ++psUrl;
        --iUrlLen;      
      }
      *psHostName = '\0';
      return IFX_SUCCESS;
    } 
  }

  return IFX_FAILURE;
}

/*! \brief IFX_DECTAPP_SUOTA_ParseUrl parses the xml body content from management 
           server.             
    \param[in] pcMsgBody msg body received from management server
    \param[out] pxRecvUrl pointer to the object x_IFX_DECTAPP_SUOTA_MgMtRecvUrl     
    \return IFX_SUCCESS or IFX_FAILURE.
*/ 
e_IFX_Return
IFX_DECTAPP_SUOTA_ParseUrl(IN char8* pcMsgBody, 
                OUT x_IFX_DECTAPP_SUOTA_MgMtRecvUrl *pxRecvUrl)
{
  uint16 temp =0, i=0;
  char8 * pTemp = NULL;
  char8 * pTempEnd = NULL;
  IXML_Document *pxXmlDoc = NULL;
  IXML_NodeList *pxXmlNodeList = NULL;
  IXML_Node *pxXmlNode = NULL, *pxXmlFirstChildNode = NULL;
  
  IFX_DBGC (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entry.");
  if(pcMsgBody == NULL)
  {
    IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Null MsgBody");
    return IFX_FAILURE;
  }
  if(pxRecvUrl ==NULL)
	{
    IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Null Recv URL");
    return IFX_FAILURE;
	}
  pxRecvUrl->ucNoOfUrl = 0;
  //if (pcMsgBody != NULL) puts (pcMsgBody);
  pTemp = (char8 *)strstr(pcMsgBody,"<?xml");
  if(pTemp == NULL)
    return IFX_FAILURE;
  pTempEnd = (char8 *)strstr(pTemp,"</SUOTA>");
  if (pTempEnd != NULL){
    pTempEnd += 8;
    *pTempEnd = 0;
  }else{
    printf("\npTempEnd is NULL");
    return IFX_FAILURE;
  }
  printf("\nEntry URL1\n");
    temp = ixmlParseBufferEx(pTemp, &pxXmlDoc);
    if(temp != IXML_SUCCESS){
      IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "XML parsing failed!!!");
      return IFX_FAILURE;
    }
  printf("\nEntry URL2\n");
    pxXmlNodeList = ixmlDocument_getElementsByTagName(pxXmlDoc, "SUOTA");
    if(pxXmlNodeList == NULL){
      IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Null XML Node list");
      return IFX_FAILURE;
    }else{
      uint16 uiCount = 0;
      for(uiCount = 0; uiCount<ixmlNodeList_length(pxXmlNodeList); uiCount++){
        pxXmlNode = ixmlNodeList_item(pxXmlNodeList, uiCount);
        pxXmlNode = ixmlNode_getFirstChild(pxXmlNode);
        //printf("\nNode List length is %d",(uint16)ixmlNodeList_length(pxXmlNodeList));
        while(pxXmlNode != NULL){
          if (!strcmp(ixmlNode_getNodeName(pxXmlNode),"FileList")){
            pxXmlNode = ixmlNode_getFirstChild(pxXmlNode);
          }
					if(pxXmlNode != NULL)
					{
          	pxXmlFirstChildNode = ixmlNode_getFirstChild(pxXmlNode);
						if(pxXmlFirstChildNode !=NULL)
						{
          		printf("\n%s: %s",ixmlNode_getNodeName(pxXmlNode),
                            ixmlNode_getNodeValue(pxXmlFirstChildNode));
						}
					}else {
						printf("NULL Retrunded from FileList");
          pxXmlNode = ixmlNode_getNextSibling(pxXmlNode);
						continue;
					}

          if(!strcmp(ixmlNode_getNodeName(pxXmlNode),"SoftwareVersionId")){
            if(ixmlNode_getNodeValue(pxXmlFirstChildNode) != NULL){
              //strcpy(pxRecvUrl->acNewSwVer,ixmlNode_getNodeValue(pxXmlFirstChildNode));
						char buf[50];
						int i,j;

						strcpy(buf,ixmlNode_getNodeValue(pxXmlFirstChildNode));
						j=0;
						for(i=0;i<strlen(buf);i+=2) {
#if 0
						  char tmp[4]={0};
							tmp[0]=buf[i];
							tmp[1]=buf[i+1];
							pxRecvUrl->acNewSwVer[j]=atohi(tmp);
#endif
			char8 cLocal1 = 0, cLocal2 = 0;

			if (buf[i] <= '9' && buf[i] >= '0')
      	cLocal1 = buf[i]-'0';
    	else if (buf[i] <= 'z' && buf[i] >= 'a')
      	cLocal1 = buf[i]-'a' + 10;
    	else if (buf[i] <= 'Z' && buf[i] >= 'A')
      	cLocal1 = buf[i]-'A' + 10;

    	if (buf[i+1] <= '9' && buf[i+1] >= '0')
      	cLocal2 = buf[i+1]-'0';
    	else if (buf[i+1] <= 'z' && buf[i+1] >= 'a')
      	cLocal2 = buf[i+1]-'a' + 10;
    	else if (buf[i+1] <= 'Z' && buf[i+1] >= 'A')
      	cLocal2 = buf[i+1]-'A' + 10;

    pxRecvUrl->acNewSwVer[j]  = cLocal1*16 + cLocal2;

							j++;
						}
						if (j<sizeof(pxRecvUrl->acNewSwVer)) pxRecvUrl->acNewSwVer[j]='\0';
					}
          else
            return IFX_FAILURE;
        }else if (!strcmp(ixmlNode_getNodeName(pxXmlNode),"DelayMinutes")){
          pxRecvUrl->unDelayMin = atoi(ixmlNode_getNodeValue(pxXmlFirstChildNode));
		  }
				else if (!strcmp(ixmlNode_getNodeName(pxXmlNode),"UserInteraction")){
					if (strcasecmp(ixmlNode_getNodeValue(pxXmlFirstChildNode),"YES")==0)
						pxRecvUrl->user_interaction = 1;
					else
						pxRecvUrl->user_interaction = 0;
				}
        else if (!strcmp(ixmlNode_getNodeName(pxXmlNode),"SoftwareTotalSize")){
            pxRecvUrl->uiSwTotalSize = atoi(ixmlNode_getNodeValue(pxXmlFirstChildNode));
          }else if (pxRecvUrl->uiSwTotalSize && !strcmp(ixmlNode_getNodeName(pxXmlNode),"File")){
            strcpy(pxRecvUrl->acRecvUrlList[i++],ixmlNode_getNodeValue(pxXmlFirstChildNode));
            pxRecvUrl->ucNoOfUrl = i;
          }

          pxXmlNode = ixmlNode_getNextSibling(pxXmlNode);
        }
      }
    }
  IFX_DBGC (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Exit.");
  return IFX_SUCCESS;
}

/*! \brief IFX_DECTAPP_SUOTA_Const_FPURL1 constructs the FP_URL1 to connect to 
           the management server.             
    \param[in] pxVerInfo pointer to the object x_IFX_DECT_SUOTA_VersionIndicationInfo 
    \param[out] acFPURL1 pointer to the constructed FP_URL1    
    \return IFX_SUCCESS or IFX_FAILURE.
*/ 
e_IFX_Return 
IFX_DECTAPP_SUOTA_Const_FPURL1(IN x_IFX_DECT_SUOTA_VersionIndicationInfo *pxVerInfo, 
															 OUT char8 *acFPURL1)
{
	char8 *pcHost = NULL, *pcToken = NULL, *pcURL = NULL,*pos=NULL, pc3xxptr[250];
  char8 acDir[250] = {'\0'};
	char8 acHwVerIden[40]={'\0'};/*!< Hardware Version ID*/
	char8 acSwIdentifier[40]={'\0'};  /*!< Software Version Id*/
	int i=0,ret=0;
  if (pxVerInfo == NULL || acFPURL1 == NULL){
    IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "Null pointer");
    return IFX_FAILURE;
  }
  /*A handset software version is clearly identified by the parameters EMC, 
    SW Version identifier, and HW Version identifier, which can be used by 
	  the management server to assign a new software image.*/
	
  IFX_DBGA (a,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
      "Construct FP_URL1.");

 if ( (pcURL = (char8*)malloc(strlen(pxVerInfo->acSendUrl) +1)) == NULL){
		IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "Null pointer Malloc Failed");
		return IFX_FAILURE;
}
  strcpy(pcURL, pxVerInfo->acSendUrl);
  printf("\n pcURL = %s\n",pcURL);
  printf("\n SendURL = %s\n",pxVerInfo->acSendUrl);
  pcHost = strtok(pcURL,"/");
  printf("\n pcHost = %s\n",pcHost);
  pcHost = strtok(NULL,"/");
  printf("\n pcHost = %s\n",pcHost);
	//pcHost = (char*)strtok(NULL,"/");
  //printf("\n pcHost = %s\n",pcHost);
	strcpy(pc3xxptr,pxVerInfo->acSendUrl+strlen(pcHost)+7);
	printf("pc3xxptr is ==%s==pcHost len:%d==\n",pc3xxptr,strlen(pcHost));
  pcToken = strtok(NULL,"/");
  while (pcToken !=NULL){
  printf("\n pcToken = %s\n",pcToken);
    sprintf(acDir,"%s/%s",acDir,pcToken);
    pcToken = strtok(NULL,"/");
  }
#if SPP_ARENDI
  /*Need to convert IA5 string to hex codes for SWVid and HWVid*/
  pos=acSwIdentifier;
  /*Need to convert IA5 string to hex codes for SWVid and HWVid*/
  while(pxVerInfo->acSwIdentifier[i] != '\0')
  {
    ret=sprintf(pos,"%x",pxVerInfo->acSwIdentifier[i]);
    pos+=ret;
    i++;
  }
  *pos= '\0';


 pos=acHwVerIden;
  i=0;
  while(pxVerInfo->acHwVerIden[i] != '\0')
  {
    ret=sprintf(pos,"%x",pxVerInfo->acHwVerIden[i]);
    pos+=ret;
    i++;
  }
  *pos= '\0';
#endif
	memset(acFPURL1,0,250);
  printf("acDir:%s\n",acDir);
  //strcpy(acFPURL1,"GET /mgmt/info?EMC=1&SWVid=1&HWVid=10.1.1 HTTP/1.1\r\nHost: 10.1.1.68\r\nAccept:*/*\r\n\r\n");

	if(strstr(pxVerInfo->acSendUrl,"?EMC"))
	{
			printf(" IFX_DECTAPP_SUOTA_Const_FPURL1: Handling 3xx\n");
			//if (pxVerInfo->user_interaction){
				sprintf(acFPURL1,"GET %s HTTP/1.1\r\nHost:%s\r\nAccept:*/*\r\n\r\n",
						pc3xxptr,pcHost);
			//}
	printf("Now FPURL1 is %s\n",acFPURL1);
	}
	else{

  if (pxVerInfo->eReason){
#if SPP_ARENDI
	if (pxVerInfo->user_interaction){
		sprintf(acFPURL1,"GET %s/?EMC=%x&SWVid=%s&HWVid=%s&reason=%x&fileNumber=%x&UIS=1 HTTP/1.1\r\nHost:%s\r\nAccept:*/*\r\n\r\n",
			acDir,pxVerInfo->unEMC,acSwIdentifier,acHwVerIden,pxVerInfo->eReason,pxVerInfo->ucFileNum,pcHost);
	}
	else
	{
		sprintf(acFPURL1,"GET %s/?EMC=%x&SWVid=%s&HWVid=%s&reason=%x&fileNumber=%x HTTP/1.1\r\nHost:%s\r\nAccept:*/*\r\n\r\n",
			acDir,pxVerInfo->unEMC,acSwIdentifier,acHwVerIden,pxVerInfo->eReason,pxVerInfo->ucFileNum,pcHost);
	}
#else
    sprintf(acFPURL1,"GET %s?EMC=%d&SWVid=%s&HWVid=%s&Reason=%d&fileNumber=%d\r\nHost:%s\r\nAccept:*/*\r\n\r\n",
            acDir,pxVerInfo->unEMC,pxVerInfo->acSwIdentifier,pxVerInfo->acHwVerIden,pxVerInfo->eReason,
            pxVerInfo->ucFileNum,pcHost);
#endif
	}
	else{
#if SPP_ARENDI
	if (pxVerInfo->user_interaction){
		sprintf(acFPURL1,"GET %s/?EMC=%x&SWVid=%s&HWVid=%s&UIS=1 HTTP/1.1\r\nHost:%s\r\nAccept:*/*\r\n\r\n",
			acDir,pxVerInfo->unEMC,acSwIdentifier,acHwVerIden,pcHost);
	}
	else
	{
		sprintf(acFPURL1,"GET %s/?EMC=%x&SWVid=%s&HWVid=%s HTTP/1.1\r\nHost:%s\r\nAccept:*/*\r\n\r\n",
			acDir,pxVerInfo->unEMC,acSwIdentifier,acHwVerIden,pcHost);
	}
#else
    sprintf(acFPURL1,"GET %s?EMC=%d&SWVid=%s&HWVid=%s\r\nHost:%s\r\nAccept:*/*\r\n\r\n",acDir,pxVerInfo->unEMC,
                    pxVerInfo->acSwIdentifier,pxVerInfo->acHwVerIden,pcHost);
#endif
  }
	}
  printf("URL1 is %s\n",acFPURL1);
  free(pcURL);
  return IFX_SUCCESS;
}

#if 0
int32
IFX_DECTAPP_IsAnyConnUsed(ucHandsetId)
{
  x_IFX_DECTAPP_CD_ConnectionStruct *pxConnectionId = NULL;
	for(i=0;i< IFX_DECTAPP_CD_MAX_CONN;++i){
    if((pxConnectionId->ucHandsetId == ucHandsetId) )
    {
      
    }
  }

}
#endif


#ifdef CD_TEST
void printFD()
{
  int i;
  for(i=0;i<10;i++){
    printf("FD[%d] = %d %d\n",i,aiFd[i][0],aiFd[i][1]);
  }
}

void AddFd(int32 iFd,int32 iType)
{
  int i;
  printf("ADD FD\n");
  if(iFd == 0) printf("Adding 0\n");
  for(i=0;i<10;i++){
    if(aiFd[i][0]==-1){
      aiFd[i][0]=iFd;
      aiFd[i][1]=iType;
      printFD();
      break;
    }
  }
  if(i==10){
    printf("FD list is full\n");
    printFD();
  }
}

void ClearFd(int32 iFd,int32 iType)
{
  int i;
  printf("CLEAR FD\n");
  if(iFd == 0) printf("Clearing 0\n");
  for(i=0;i<10;i++){
    if((aiFd[i][0]==iFd)&&(aiFd[i][1]==iType)){
      aiFd[i][0]=-1;
      aiFd[i][1]=-1;
      printFD();
      break;
    }
  }
  if(i==10){
    printf("FD not in the list %d\n",iFd);
    printFD();
  }

}
#endif

/*! \brief IFX_DECTAPP_CD_Thread_Function executes in thread context.It is the
           entry function for FT Application.
    \return IFX_SUCCESS or IFX_FAILURE.
*/	

e_IFX_Return IFX_DECTAPP_CD_Thread_Function(){

  int32 iNoOfFds;
  int32 iRead = 0;
  uint32 iOptSize = 0;
  uint32 iOptVal = 0;
  int32 iLoop = 0;
  
  fd_set xReadFdS;
  fd_set xWriteFdS;
  fd_set xExceptFdS;
  
  x_IFX_DECTAPP_EventData xIntnlCall = {0};
     
  IFX_DBGC(a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "<ContentDownload>FT Application Thread function Entry.");
  viInternalSockFd = socket (PF_UNIX, SOCK_DGRAM,(int32) NULL);

  if (viInternalSockFd < 0)
  {
    perror ("Socket creation failed.");
	  IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "<ContentDownload>Exiting from thread");
    return IFX_FAILURE;
  }                           
 
  vFILE_name.sun_family = PF_FILE;
  strcpy (vFILE_name.sun_path, "/tmp/httpc_sock_file");
	system("rm -f /tmp/httpc_sock_file");
  
  //extern uchar8 vucDectAgnetModId;
  size = offsetof (struct sockaddr_un, sun_path) +strlen (vFILE_name.sun_path) + 1;

  if (bind (viInternalSockFd, (struct sockaddr *) &vFILE_name, size) < 0)
  {
    perror ("Bind failed.");         
    IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "<ContentDownload>Exiting from thread");
    return IFX_FAILURE;
  }
  
  arg1 = fcntl (viInternalSockFd, F_GETFL, NULL);
  arg1 |= O_NONBLOCK;
  fcntl (viInternalSockFd, F_SETFL, arg1);
  
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<ContentDownload>Socket bound successfully.");
  
#ifdef CD_TEST
  printf("=====InternalSockFd==== %d\n",viInternalSockFd);
  AddFd(viInternalSockFd,1);
#endif
  FD_SET (viInternalSockFd, &vxGlobalReadFdS);
  
  while (1){
     
    memcpy (&xReadFdS, &vxGlobalReadFdS, sizeof (fd_set));
    memcpy (&xWriteFdS, &vxGlobalWriteFdS, sizeof (fd_set));
    memcpy (&xExceptFdS, &vxGlobalExceptFdS, sizeof (fd_set));
	
	  IFX_DBGA(a,IFX_DBG_LVL_HIGH, IFX_DBG_INT,"<ContentDownload>Number of Read FDs set:",xReadFdS);
	  IFX_DBGA(a,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"<ContentDownload>Number of Write FDs set:",xWriteFdS);
	  IFX_DBGA(a,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"<ContentDownload>Number of Except FDs set:",xExceptFdS);

    IFX_DBGA(a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>Blocking on select");
    iNoOfFds = select (FD_SETSIZE, &xReadFdS, &xWriteFdS, &xExceptFdS, 0);
    IFX_DBGA(a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>Select Unblocked.");
    //IFX_DBGA(a,b,d,"<ContentDownload>Number of FdS Unblocked.",iNoOfFds);
    //printf("InternalSockFd %d\n",viInternalSockFd);
    if (iNoOfFds < 0){
	
      if (IFX_OS_FdIsSet (viInternalSockFd, &xReadFdS)){
        IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>Read Fault.");
      }		
#if 0	
      if (IFX_OS_FdIsSet (viInternalSockFd, &xWriteFdS)){
        IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>Write Fault.");
      }	
		
      if (IFX_OS_FdIsSet (viInternalSockFd, &xExceptFdS)){
	      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>Except Fault.");
      }	
#endif      
      if (errno == EBADF){
	      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>Invalid Fd.");
      }	

      if (errno == EINTR){
	      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>A signal was Caught.");
      }	
		
      if (errno == EINVAL){
	      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>FD_SETSIZE negative.");
      }
      
      if (errno == ENOMEM){
	      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>Unable to allocate memory.");
      }	
    }
    if (IFX_OS_FdIsSet (viInternalSockFd, &xReadFdS)){
	    
      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<ContentDownload>Internal SockFd Unblocked.");
      iRead=read (viInternalSockFd, &xIntnlCall, sizeof (x_IFX_DECTAPP_EventData));
      //printf("iRead %d size %d\n",iRead,sizeof (x_IFX_DECTAPP_EventData));
      while(iRead >0){
	      
        IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<ContentDownload>Switching Event occurred on Socket.");
        switch (xIntnlCall.Event){
		
          case IFX_DECTAPP_CD_DATA_CALL_INIT:
              
              IFX_DBGC (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                "<ContentDownload>Setup Arrived from PT.Invoking API CallAccept in TK.");
	            IFX_DECT_DPSU_CallAccept (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,0/*uiIEHdl*/);
              break;
	      
          case IFX_DECTAPP_CD_ADD_SOCK_FD:
         
              IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                 "<ContentDownload>Adding SockFd to write queue.",xIntnlCall.ux_IntEvent.pxConnId->SockFd);
#if 0
              AddFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,2);
              FD_SET (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalWriteFdS);
              AddFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,3);
              FD_SET (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalExceptFdS);
#endif
              if (connect
                (xIntnlCall.ux_IntEvent.pxConnId->SockFd,(const struct sockaddr *)&xIntnlCall.ux_IntEvent.pxConnId->Serv_Addr,
                 sizeof (xIntnlCall.ux_IntEvent.pxConnId->Serv_Addr)) < 0){
		      
                if (errno == EINPROGRESS){
			 
#ifdef CD_TEST
                  AddFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,2);
#endif
                  FD_SET (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalWriteFdS);

#ifdef CD_TEST
                  AddFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,3);
#endif
                  FD_SET (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalExceptFdS);
                }else{
                  memset(&vacMsgBody,0,sizeof(vacMsgBody));
                  IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                        "<ContentDownload>Connect failed.Sending 5XX message to stack.");
                  IFX_DECTAPP_SUOTA_Const_5XX(502, vacMsgBody);
                  IFX_DECT_DPSU_DataSendToDECT (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,
                                          vacMsgBody, strlen(vacMsgBody), strlen(vacMsgBody));
#if 0
                  IFX_DECT_DPSU_CallRelease (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,0/*uiIEHdl*/,
                                             IFX_DECT_RELEASE_ABNORMAL);
#endif
                   IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                            "<ContentDownload>Connect failed on socket.Clearing Fd");
#if 0
                   FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalWriteFdS);
#else
                   close (xIntnlCall.ux_IntEvent.pxConnId->SockFd);
#endif
                 }
              }
              break;
	      
		  case IFX_DECTAPP_SUOTA_ADD_SOCK_FD:
         
              IFX_DBGA (a,IFX_DBG_LVL_LOW,IFX_DBG_INT,
                "Adding SUOTA SockFd to write queue.",xIntnlCall.ux_IntEvent.pxSuotaId->SockFd);
#if 0
              FD_SET (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalWriteFdS);
#endif
              if (connect
                (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,
				  (const struct sockaddr *)&xIntnlCall.ux_IntEvent.pxSuotaId->Serv_Addr,
                   sizeof (xIntnlCall.ux_IntEvent.pxSuotaId->Serv_Addr)) < 0){
		      
                if (errno == EINPROGRESS){			 
#ifdef CD_TEST
                  AddFd(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,2);
#endif
                  FD_SET (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalWriteFdS);
							FD_SET (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalExceptFdS);
                }else{			
                  /* Send NACK */
                  IFX_DECT_SUOTA_SendNACK(xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId, 
				                  IFX_DECT_SUOTA_NACK_UNREACH_URL1);
                  IFX_DBGC (a,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                               "Connect failed on socket. Clearing Fd");
#if 0
                  FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalWriteFdS);
#else
                  close(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd);
#endif
              
                }
              }
              break;
			  
          case IFX_DECTAPP_CD_REMOVE_SOCK_FD:
        
              IFX_DBGC (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                      "<ContentDownload>Closing Connection on socket.");
	            //if(FD_ISSET(xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalReadFdS))
							{
		  
                IFX_DBGC (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
                       "<ContentDownload>Clearing Sockfd and closing it.");
#ifdef CD_TEST
                ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,1);
#endif
	              FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalReadFdS);
#ifdef CD_TEST
                ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,3);
#endif
	              FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalExceptFdS);
                close (xIntnlCall.ux_IntEvent.pxConnId->SockFd);
	            }
              xIntnlCall.ux_IntEvent.pxConnId->IsUsed=0;
              break;
			  
		case IFX_DECTAPP_SUOTA_REMOVE_SOCK_FD:
        
              IFX_DBGC (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                        "<SUOTA>Closing Connection on socket.");
	            if(FD_ISSET(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalReadFdS)){
		  
                IFX_DBGC (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                        "<SUOTA>Clearing Sockfd and closing it.");
#ifdef CD_TEST
                ClearFd(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,1);
#endif
	              FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalReadFdS);
                close (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd);
	            }
              xIntnlCall.ux_IntEvent.pxSuotaId->IsAvail=0;
              break;	  
	       
	  case IFX_DECTAPP_CD_EXIT_APP:
        
              IFX_DBGC (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                            "<ContentDownload>Exiting FT Application.");
              for (iLoop = 0; iLoop < IFX_DECTAPP_CD_MAX_CONN; iLoop++){
		      
                if (vaxsoc_sock[iLoop].IsUsed!=0){
						  
		              if(FD_ISSET(vaxsoc_sock[iLoop].SockFd, &vxGlobalReadFdS)){
			    
                    IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                       "<ContentDownload>Clearing the Sockfd and Closing it."
				                ,vaxsoc_sock[iLoop].SockFd);
#ifdef CD_TEST
                    ClearFd(vaxsoc_sock[iLoop].SockFd,1);
#endif
		                FD_CLR (vaxsoc_sock[iLoop].SockFd, &vxGlobalReadFdS);
            	      close (vaxsoc_sock[iLoop].SockFd);
		              }
		              vaxsoc_sock[iLoop].IsUsed=0;
		            }
  	          } 
              IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
                 "<ContentDownload>Closing the Internal Socket.");
	            close (viInternalSockFd);
							viInternalSockFd=0;
							strcpy(vacFPURL1,"");
							strcpy(vacMsgBody,"");
							memset(&vaxsoc_sock,0,sizeof(vaxsoc_sock));
							memset(&vaxSuotaSess,0,sizeof(vaxSuotaSess));
							memset(&vxCallIntnlSocket,0,sizeof(vxCallIntnlSocket));
							vucWrite=0;
							iHTTP=0;
							size=0;
							arg=arg1=0;
							viReadLength=0;
              unlink (vFILE_name.sun_path);
  			  puiSUOTAvalue_ptr=&uiSUOTAvalue_ptr;
			  pthread_exit(&puiSUOTAvalue_ptr);
              return IFX_SUCCESS;
              break;
      
          default:
        
              IFX_DBGC (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                "<ContentDownload>No specified event occurred on Socket.");
	            if(FD_ISSET(xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalReadFdS)){
#ifdef CD_TEST
                ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,1);
#endif
	              FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &xReadFdS);
              }
              break;
        }
	
        iRead=read (viInternalSockFd, &xIntnlCall, sizeof (x_IFX_DECTAPP_EventData));
      } 
      --iNoOfFds;
    }

	   for (iLoop = 0; (iNoOfFds != 0)&&(iLoop < IFX_DECTAPP_SUOTA_MAX_CONN); iLoop++){
    
	    if(vaxSuotaSess[iLoop].IsAvail != 0){
	   
        xIntnlCall.ux_IntEvent.pxSuotaId =&vaxSuotaSess[iLoop];
        if (IFX_OS_FdIsSet (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &xReadFdS)){ 
			
			    char8 cbRespBuf[IFX_DECTAPP_SUOTA_RESP_MAXBUFLEN];
			    x_IFX_DECT_SUOTA_VersionAvailableInfo xVerAvailInfo;
			            
          IFX_DBGC (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
              "<SUOTA>Response from server.Read FD unblocked.");
				  memset(cbRespBuf,0,sizeof(cbRespBuf)); 
          viReadLength = read (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,
                                 cbRespBuf, IFX_DECTAPP_SUOTA_RESP_MAXBUFLEN);

		      IFX_DBGA(a, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
                 "RESPONSE =", cbRespBuf);
#if 0
  int32 k=0;
  printf("Length of data from IP %d\n",viReadLength);
  for(k=0;k<viReadLength;k++){
    printf("%c",cbRespBuf[k]);
  }

#endif
						 
          if (viReadLength <= 0){
              
			      sleep(1);
           // printf("errno %s\n",strerror(errno));
            if((errno != EAGAIN/*Resource Temporarily Unavailable */) 
               || (errno != EINTR/* Interrupted by signal during read */))
            { 
              if (viReadLength == 0){
                IFX_DBGC (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
                      "<SUOTA>EOF");
              }else{
                printf("errno %s\n",strerror(errno));
                IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                        "<SUOTA>Read Error");
								
              }
              IFX_DBGC (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
                        "<SUOTA>Closing Read Fd.");
							FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalExceptFdS);
#ifdef CD_TEST
              ClearFd(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,1);
#endif
			        FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalReadFdS);
		          if(close(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd) == -1){
			  
                IFX_DBGC (a,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Error closing the socket.");
			        }
              /* Send NACK */
              IFX_DBGC (a,IFX_DBG_LVL_HIGH,IFX_DBG_STR," Send NACK.");
              IFX_DECT_SUOTA_SendNACK(xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId, 
				                     IFX_DECT_SUOTA_NACK_RETRY_CONN_REFUSED);
							
			      }
			      --iNoOfFds;
			      continue;
          }
          IFX_DBGA (a,IFX_DBG_LVL_LOW,IFX_DBG_INT,
                "Bytes read from the Socket.",viReadLength);
			
          /* Parse the response */
			    if(IFX_SUCCESS != IFX_DECTAPP_SUOTA_ParseUrl(cbRespBuf,
                          &xIntnlCall.ux_IntEvent.pxSuotaId->xRecvUrl))
          {
						/*Check for 3xx and Handle3xx*/
						char ac3xxUrl[125];

						if(IFX_SUCCESS == IFX_DECT_GetURL_3xx(cbRespBuf,ac3xxUrl))
						{
						   x_IFX_DECTAPP_SUOTA_SessionInfo *pxSuotaInfo = NULL;
						   x_IFX_DECT_SUOTA_VersionIndicationInfo xVerInfo;
						   pxSuotaInfo = &vaxSuotaSess[xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId-1];

							  /*Clear old FDS which are created for original URL. With 3xx we get new URL and create new socket & connection*/
								printf("<SUOTA>3xx recvd : Clear old connection from ReadFd and Close the connection.\n");
								FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalReadFdS);
								FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalExceptFdS);
								FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalWriteFdS);
						    close(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd);
					      xIntnlCall.ux_IntEvent.pxSuotaId->SockFd=-1;
					      xIntnlCall.ux_IntEvent.pxSuotaId->IsAvail=0;
					      --iNoOfFds;

						    memcpy(&xVerInfo, &(pxSuotaInfo->xVerInfo), sizeof(x_IFX_DECT_SUOTA_VersionIndicationInfo));
						    strcpy(xVerInfo.acSendUrl,ac3xxUrl);
								IFX_DECTAPP_SUOTA_3xxHandle(xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId,&xVerInfo);
                continue;
						}

            //IFX_DECTAPP_ErrorCheck(cbRespBuf,xIntnlCall.ux_IntEvent.pxSuotaId);
            /* Send NACK */
            IFX_DBGC (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Send NACK.");
            IFX_DECT_SUOTA_SendNACK(xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId, 
				                  IFX_DECT_SUOTA_NACK_COM_FORMAT_ERR);
          }
          else {
            memset(&xVerAvailInfo,0,sizeof(x_IFX_DECT_SUOTA_VersionAvailableInfo));
			      /* Send URL to PP*/	  
	          strcpy(&xVerAvailInfo.acNewSwIdentifier[0], 
                   xIntnlCall.ux_IntEvent.pxSuotaId->xRecvUrl.acNewSwVer);	        
            xVerAvailInfo.unDelayMin = xIntnlCall.ux_IntEvent.pxSuotaId->xRecvUrl.unDelayMin; 
			xVerAvailInfo.user_interaction = xIntnlCall.ux_IntEvent.pxSuotaId->xRecvUrl.user_interaction; 
            xVerAvailInfo.uiSwTotalSize = 
                   xIntnlCall.ux_IntEvent.pxSuotaId->xRecvUrl.uiSwTotalSize;  
            if(xVerAvailInfo.uiSwTotalSize) {
              strcpy(xVerAvailInfo.acUrl, xIntnlCall.ux_IntEvent.pxSuotaId->xRecvUrl.acRecvUrlList[xIntnlCall.ux_IntEvent.pxSuotaId->xRecvUrl.ucSendIndex++]);
            }
            IFX_DBGC (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                 "IFX_DECT_SUOTA_VersionAvailable invoked.");      
	          IFX_DECT_SUOTA_VersionAvailable(
                           xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId,  
                           &xVerAvailInfo);  
          }
			    IFX_DBGC (a,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<SUOTA>Clear from ReadFd and Close the connection.");
					FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalExceptFdS);
#ifdef CD_TEST
          ClearFd(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,1);
#endif
          FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalReadFdS);
          close (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd);	          
          xIntnlCall.ux_IntEvent.pxSuotaId->IsAvail=0;			
            
          --iNoOfFds;
			
         }else if (IFX_OS_FdIsSet (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &xWriteFdS)){
					  
		       iOptSize = sizeof(iOptVal); 
           IFX_DBGC (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                      "Connection unblocked in write FD.");
		   
           //printf ("<SUOTA>Request is: %s",vacFPURL1);
           if(getsockopt (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,SOL_SOCKET,SO_ERROR,
		                  &iOptVal,&iOptSize) != 0){
             IFX_DBGA (a,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"getsockopt failed.");
		       }
           if (iOptVal){
		     
			       IFX_DBGC (a,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                      "Send NACK to PP and clear the socket Fd.");	
             /* Send NACK */
             IFX_DECT_SUOTA_SendNACK(xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId, 
				                  IFX_DECT_SUOTA_NACK_RETRY_CONN_REFUSED);	
						FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalExceptFdS);
#ifdef CD_TEST
             ClearFd(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,2);
#endif
             FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalWriteFdS);
			       vaxSuotaSess[iLoop].IsAvail=0;
			 
		        }else{
		   
              arg = fcntl (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, F_GETFL, NULL);
              arg &= (~O_NONBLOCK);
              fcntl (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, F_SETFL, arg);
			  
#ifdef CD_TEST
              ClearFd(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,2);
#endif
              FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalWriteFdS);
#ifdef CD_TEST
              AddFd(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,1);
#endif
              FD_SET (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalReadFdS);              
						/* Construct FP_URL1 */
            if(IFX_DECTAPP_SUOTA_Const_FPURL1 (((x_IFX_DECT_SUOTA_VersionIndicationInfo *) &(xIntnlCall.ux_IntEvent.pxSuotaId->xVerInfo)), vacFPURL1) == IFX_FAILURE){
           				IFX_DBGC (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
                      "IFX_DECTAPP_SUOTA_Const_FPURL1 failed.");
								IFX_DECT_SUOTA_SendNACK(xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId,IFX_DECT_SUOTA_NACK_RETRY_CONN_REFUSED);		
								FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalReadFdS);
								FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalExceptFdS);
								close(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd);
								vaxSuotaSess[iLoop].IsAvail=0;
            }
              
			        if (vacFPURL1[0] != '\0'){
                IFX_DBGA (a,IFX_DBG_LVL_LOW,IFX_DBG_ATA_STRING_INFO,
                            "<SUOTA>FP_URL1:",vacFPURL1);
                if (!write (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,vacFPURL1,
                                     strlen(vacFPURL1))){
			            
                  IFX_DBGC (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                      "Send NACK to PP.");	
                  /* Send NACK */
                  IFX_DECT_SUOTA_SendNACK(xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId, IFX_DECT_SUOTA_NACK_RETRY_CONN_REFUSED);		
								FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalReadFdS);
								  
								FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalExceptFdS);
									close(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd);
								vaxSuotaSess[iLoop].IsAvail=0;
                  return IFX_FAILURE;
				  
                }
                //printf("State changed to URL_SEND\n");
	              xIntnlCall.ux_IntEvent.pxSuotaId->eStatus = IFX_DECTAPP_SUOTA_URL_SEND;
                bzero ((char *) (vacFPURL1),sizeof (vacFPURL1));
              }
            }
            --iNoOfFds;  
		  }
				else if (FD_ISSET (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &xExceptFdS)){
					unsigned int uiOptV = 0;
					unsigned int uiOptS = 0;
					printf("<SUOTA>Exception FD Unblocked!!\n");
						uiOptS = sizeof(uiOptV); 
						if(getsockopt (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd,SOL_SOCKET,SO_ERROR,(char*)&uiOptV,&uiOptS) != 0){
							printf("<SUOTA>getsockopt failed.\n");
						}
						FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalReadFdS);
						FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalWriteFdS);
						FD_CLR (xIntnlCall.ux_IntEvent.pxSuotaId->SockFd, &vxGlobalExceptFdS);
						close(xIntnlCall.ux_IntEvent.pxSuotaId->SockFd);
						IFX_DECT_SUOTA_SendNACK(xIntnlCall.ux_IntEvent.pxSuotaId->ucHandsetId,IFX_DECT_SUOTA_NACK_RETRY_CONN_REFUSED);		
						vaxSuotaSess[iLoop].IsAvail=0;
						--iNoOfFds;  
				} 
				if (iNoOfFds != 0){
					printf("iLoop %d Few unserved FDs pending:%d\n",iLoop,iNoOfFds);
				}
			}
		}	//for loop
    for (iLoop = 0; (iNoOfFds != 0)&&(iLoop < IFX_DECTAPP_CD_MAX_CONN); iLoop++){
    
	   if(vaxsoc_sock[iLoop].IsUsed != 0){
	   
         xIntnlCall.ux_IntEvent.pxConnId =&vaxsoc_sock[iLoop];
         if (IFX_OS_FdIsSet (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &xReadFdS)){ 
					  
            xIntnlCall.ux_IntEvent.pxConnId->iReqBufLen = 0;
            IFX_DBGC (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<ContentDownload>Response from server.Read FD unblocked.");
            
            viReadLength = read (xIntnlCall.ux_IntEvent.pxConnId->SockFd,
                                 xIntnlCall.ux_IntEvent.pxConnId->cbRespBuf, 
                                 IFX_DECTAPP_CD_RESP_MAXBUFLEN);
								 
            if (viReadLength <= 0){
			        //sleep(1);
              //printf("errno %s\n",strerror(errno));
              if((errno != EAGAIN/*Resource Temporarily Unavailable */) 
                 || (errno != EINTR/* Interrupted by signal during read */))
              { 
                if (viReadLength == 0){
                  IFX_DBGC (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
                      "<ContentDownload>EOF");
                }else{
                  printf("errno %s\n",strerror(errno));
                  IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                        "<ContentDownload>Read Error");
                }
                IFX_DBGC (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
                        "<ContentDownload1>Closing Read Fd.");

#if SPP_ARENDI
							if (viReadLength < 0){
							memset(&vacMsgBody,0,sizeof(vacMsgBody));
							IFX_DECTAPP_SUOTA_Const_5XX(500, vacMsgBody);
							IFX_DECT_DPSU_DataSendToDECT (xIntnlCall.ux_IntEvent.pxConnId->iSessionId, vacMsgBody, strlen(vacMsgBody), strlen(vacMsgBody));
							vaxsoc_sock[iLoop].IsUsed = 0;
							}
#endif
#ifdef SBBCHK								
			          xIntnlCall.ux_IntEvent.pxConnId->status = IFX_DECTAPP_CD_CLOSED;
#ifdef CD_TEST
                ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,1);
#endif
			          FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalReadFdS);
#ifdef CD_TEST
                ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,3);
#endif
			          FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalExceptFdS);
		            if(close(xIntnlCall.ux_IntEvent.pxConnId->SockFd) == -1){
                  IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                          "<ContentDownload>Error closing the socket.");
			          }
#endif //SBBCHK
              }
			        --iNoOfFds;
#if 0
              IFX_DECT_DPSU_CallRelease(xIntnlCall.ux_IntEvent.pxConnId->iSessionId,0/*uiIEHdl*/,IFX_DECT_RELEASE_NORMAL);
#endif
			        continue;
            }
            IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_INT,
                 "<ContentDownload>Bytes read from the Socket.",viReadLength);
			
            xIntnlCall.ux_IntEvent.pxConnId->iRespBufLen = viReadLength;
			
            IFX_DBGC (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<ContentDownload>Sending Data to DECT stack.IFX_DECT_DPSU_SendDataToDECT invoked.");
				  if(	xIntnlCall.ux_IntEvent.pxConnId->ucState == 0)
					{
						static char *p;
						xIntnlCall.ux_IntEvent.pxConnId->ucState=1;
						p=strcasestr(xIntnlCall.ux_IntEvent.pxConnId->cbRespBuf,"Content-Length");
						if(p!=NULL)
						{
							p=strchr(p,':');
							/*remove any leading spaces*/
							p++;
							while( *p == ' ') p++;
							xIntnlCall.ux_IntEvent.pxConnId->iAppDataLen = atoi(p);
							printf("HTTP content length= %d\n",xIntnlCall.ux_IntEvent.pxConnId->iAppDataLen);
							p=strstr(p,"\r\n\r\n");
							if(p!=NULL)
							{
								  p += 4;
									xIntnlCall.ux_IntEvent.pxConnId->iAppDataLen += (p - xIntnlCall.ux_IntEvent.pxConnId->cbRespBuf); 
									printf("HTTP Total responselength= %d\n",xIntnlCall.ux_IntEvent.pxConnId->iAppDataLen);
							}
							else
							{
								printf("pay load Not found\n");
							}

						}
						else
						{
								printf("Content length Not found\n");
								xIntnlCall.ux_IntEvent.pxConnId->iAppDataLen = xIntnlCall.ux_IntEvent.pxConnId->iRespBufLen;
						}
					}
            IFX_DECT_DPSU_DataSendToDECT (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,
                                          xIntnlCall.ux_IntEvent.pxConnId->cbRespBuf,
						xIntnlCall.ux_IntEvent.pxConnId->iRespBufLen,xIntnlCall.ux_IntEvent.pxConnId->iAppDataLen);
            IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "<ContentDownload>Extracting code for HTTP rsp,invoking IFX_DECTAPP_CD_HTTP_GetCode.");
            IFX_DECTAPP_CD_HTTP_GetCode(xIntnlCall.ux_IntEvent.pxConnId->cbRespBuf,
                                 xIntnlCall.ux_IntEvent.pxConnId->iRespBufLen,
                                 (int32 *)&xIntnlCall.ux_IntEvent.pxConnId->iCode);
            vucWrite =0;
            --iNoOfFds;
			
         }else if (IFX_OS_FdIsSet (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &xWriteFdS)){
					  
		       iOptSize = sizeof(iOptVal); 
           IFX_DBGC (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
                "<ContentDownload>Connection unblocked in write FD.");
		   
           if(getsockopt (xIntnlCall.ux_IntEvent.pxConnId->SockFd,SOL_SOCKET,SO_ERROR,
		                  &iOptVal,&iOptSize) != 0){
             IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "<ContentDownload>getsockopt failed.");
		       }
           if (iOptVal){
		   
             IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "<ContentDownload>Connect failed.Sending 5XX message to stack.");
             memset(&vacMsgBody,0,sizeof(vacMsgBody));
             IFX_DECTAPP_SUOTA_Const_5XX(502, vacMsgBody);
             IFX_DECT_DPSU_DataSendToDECT (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,
                                       vacMsgBody, strlen(vacMsgBody), strlen(vacMsgBody));
#if 0
             IFX_DECT_DPSU_CallRelease (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,
                                     0/*uiIEHdl*/,IFX_DECT_RELEASE_ABNORMAL);
#endif										
             IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                     "<ContentDownload>Connect failed.Clearing the write FD.");
#ifdef CD_TEST
             ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,2);
#endif
             FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalWriteFdS);
						FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalExceptFdS);
						if(close(xIntnlCall.ux_IntEvent.pxConnId->SockFd) == -1){
								printf("<ContentDownload>Error closing the socket.\n");
							}
			       vaxsoc_sock[iLoop].IsUsed=0;
			 
		       }else{
		   
              arg = fcntl (xIntnlCall.ux_IntEvent.pxConnId->SockFd, F_GETFL, NULL);
              arg &= (~O_NONBLOCK);
              fcntl (xIntnlCall.ux_IntEvent.pxConnId->SockFd, F_SETFL, arg);
			  
#ifdef CD_TEST
              ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,2);
#endif
              FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalWriteFdS);
#ifdef CD_TEST
              AddFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,1);
#endif
              FD_SET (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalReadFdS);
			  
              if (xIntnlCall.ux_IntEvent.pxConnId->status == IFX_DECTAPP_CD_HTTP10CLOSED){
			  
                IFX_DBGC (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                       "<ContentDownload>Status IFX_DECTAPP_CD_HTTP10CLOSED,invoking CallAccept API.");
                IFX_DECT_DPSU_CallAccept (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,
                                      0/*uiIEHdl*/);
              }
              xIntnlCall.ux_IntEvent.pxConnId->status = IFX_DECTAPP_CD_UNSPEC_OPEN;
              
			        if (xIntnlCall.ux_IntEvent.pxConnId->cbReqBuf[0] != '\0'){
			  
                IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>Request is:",
                                     xIntnlCall.ux_IntEvent.pxConnId->cbReqBuf);
                if (!write (xIntnlCall.ux_IntEvent.pxConnId->SockFd, xIntnlCall.ux_IntEvent.pxConnId->cbReqBuf,
                          xIntnlCall.ux_IntEvent.pxConnId->iReqBufLen)){
						  
                  IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                      "<ContentDownload>Write to Socket failed.Sending 5XX message to stack.");
#if 0
                  IFX_DECT_DPSU_CallRelease (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,0/*uiIEHdl*/,
                                             IFX_DECT_RELEASE_ABNORMAL);
#endif
                  memset(&vacMsgBody,0,sizeof(vacMsgBody));
                  IFX_DECTAPP_SUOTA_Const_5XX(502, vacMsgBody);
                  IFX_DECT_DPSU_DataSendToDECT (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,
                                       vacMsgBody, strlen(vacMsgBody),strlen(vacMsgBody));
								FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalReadFdS);
								FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalExceptFdS);
								if(close(xIntnlCall.ux_IntEvent.pxConnId->SockFd) == -1){
									printf("<ContentDownload>Error closing the socket.\n");
								}
								vaxsoc_sock[iLoop].IsUsed=0;
                  return IFX_FAILURE;
				  
                }else{
				
                  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                       "<ContentDownload>Extracting version information from HTTP req message.");
                  IFX_DECTAPP_CD_HTTP_GetVersion (xIntnlCall.ux_IntEvent.pxConnId->cbReqBuf,
                                        xIntnlCall.ux_IntEvent.pxConnId->iReqBufLen, &iHTTP);
                  if (iHTTP == 10){

				            IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                         "<ContentDownload>Version is 1.0");
                    xIntnlCall.ux_IntEvent.pxConnId->status = IFX_DECTAPP_CD_HTTP10;
					
                  }else if (iHTTP == 11){
				  
                    IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                              "<ContentDownload>Version is 1.1");
                    //printf("Version is 1.1. Change the status to IFX_DECTAPP_CD_HTTP11\n");
                    xIntnlCall.ux_IntEvent.pxConnId->status = IFX_DECTAPP_CD_HTTP11;
                   }
                }
                bzero ((char *) (xIntnlCall.ux_IntEvent.pxConnId->cbReqBuf),
                     sizeof (xIntnlCall.ux_IntEvent.pxConnId->cbReqBuf));
              }
            }
            --iNoOfFds;  
		  } else if (IFX_OS_FdIsSet (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &xExceptFdS)){
           uint32 uiOptV = 0;
           uint32 uiOptS = 0;

           IFX_DBGA (a,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
                     "<ContentDownload>Exception FD Unblocked!!");
					//if(vucWrite == 1)
           {
			       if (xIntnlCall.ux_IntEvent.pxConnId->cbRespBuf[0] != '\0'){
               IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
                       "<ContentDownload>NO Response from Server.");
             }
		         uiOptS = sizeof(uiOptV); 
             if(getsockopt (xIntnlCall.ux_IntEvent.pxConnId->SockFd,SOL_SOCKET,SO_ERROR,
		                  &uiOptV,&uiOptS) != 0){
               IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                            "<ContentDownload>getsockopt failed.");
		         }
             //printf("OptVal %d\n",uiOptV);
             IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "<ContentDownload>Clearing Fd and closing it.");
#ifdef CD_TEST
             ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,1);
#endif
	           FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalReadFdS);
#ifdef CD_TEST
             ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,2);
#endif
	           FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalWriteFdS);
#ifdef CD_TEST
             ClearFd(xIntnlCall.ux_IntEvent.pxConnId->SockFd,3);
#endif
	           FD_CLR (xIntnlCall.ux_IntEvent.pxConnId->SockFd, &vxGlobalExceptFdS);
             close (xIntnlCall.ux_IntEvent.pxConnId->SockFd);
			       xIntnlCall.ux_IntEvent.pxConnId->status = IFX_DECTAPP_CD_CLOSED;
             //xIntnlCall.pxConnId->IsUsed=0;
#if 1
             IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                   "<ContentDownload>No Response from server.Sending 4XX message to stack.");
             memset(&vacMsgBody,0,sizeof(vacMsgBody));
             IFX_DECTAPP_SUOTA_Const_4XX(408,vacMsgBody);
             IFX_DECT_DPSU_DataSendToDECT (xIntnlCall.ux_IntEvent.pxConnId->iSessionId,
                                     vacMsgBody, strlen(vacMsgBody),strlen(vacMsgBody));
#endif
  
             //IFX_DECTAPP_ReqRetrans(xIntnlCall.ux_IntEvent.pxConnId);
           }
           --iNoOfFds;  
      } 
		  if (iNoOfFds != 0){
						
            IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                   "<ContentDownload>Few unserved FDs pending:",iNoOfFds);
          }
       }
	   } //for loop
		  if (iNoOfFds != 0){
						
            IFX_DBGA (a,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
                 "Few unserved FDs pending:",iNoOfFds);
          }
		
  } //while(1)
} //IFX_DECTAPP_CD_Thread_Function()

/*************************  SUOTA CallBacks  *******************************/

/*! \brief IFX_DECTAPP_SUOTA_VersionIndication callback function is called when there 
           is a request from the PT for the management server and the application 
           needs to connect to the server.
    \param[in] ucHandsetId HandsetId.
    \param[in] pxVerInfo pointer to the object x_IFX_DECT_SUOTA_VersionIndicationInfo     
    \return IFX_SUCCESS or IFX_FAILURE.
*/    
    
e_IFX_Return IFX_DECTAPP_SUOTA_VersionIndication (IN uchar8 ucHandsetId,											  
                                      IN x_IFX_DECT_SUOTA_VersionIndicationInfo *pxVerInfo)
{
  char8 acURL[IFX_DECT_SUOTA_MAX_URL_LEN] = {'\0'};
  uint32 portno = 0;
  x_IFX_DECTAPP_SUOTA_SessionInfo *pxSuotaInfo = NULL;

  IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,"Entry.");
  
  /*Initial Checks*/
  #ifdef ULE_SUPPORT
  if((ucHandsetId ==0)||(ucHandsetId > 224)){
    IFX_DBGC(a,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Incorrect Handset Id");
    return IFX_FAILURE;
  }  
  #else
  if((ucHandsetId ==0)||(ucHandsetId >IFX_DECT_MAX_HS) ){
    IFX_DBGC(a,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Incorrect Handset Id");
    return IFX_FAILURE;
  }  
  #endif
    
  pxSuotaInfo = &vaxSuotaSess[ucHandsetId-1];
  pxSuotaInfo->IsAvail=1;
  
  printf("Sw: %s Hw: %s EMC: %02X, FileNum:%d Reason: %d\n",
               pxVerInfo->acSwIdentifier,
               pxVerInfo->acHwVerIden,
               pxVerInfo->unEMC,
               pxVerInfo->ucFileNum,
               pxVerInfo->eReason);
  printf("URL: %s\n",pxVerInfo->acSendUrl);

  /* Store the Version Indication info */
  if((pxVerInfo->ucFileNum == 1) && (pxVerInfo->eReason == IFX_DECT_SUOTA_SUCCESS))
  {
    IFX_DBGA (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
      "Version Indication Request for the first time.");
    /* For the first time Version Indication request came */
    pxSuotaInfo->ucHandsetId = ucHandsetId;
	  memcpy(&pxSuotaInfo->xVerInfo , pxVerInfo, sizeof(x_IFX_DECT_SUOTA_VersionIndicationInfo));	
    
    
	  memset(&pxSuotaInfo->xRecvUrl, 0, sizeof(x_IFX_DECTAPP_SUOTA_MgMtRecvUrl));
    IFX_DECTAPP_HTTP_GetHostNameFromUrl(acURL, 
                                pxSuotaInfo->xVerInfo.acUrl );
    IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_ATA_STRING_INFO,
               "<SUOTA>Host is:",acURL);
    //strcpy(acURL,"10.1.1.68");
#ifdef SBB	/*not required here. Constructed later*/
    /* Construct FP_URL1 */
    if(IFX_DECTAPP_SUOTA_Const_FPURL1 (pxVerInfo, vacFPURL1) == IFX_FAILURE){

      IFX_DBGA (a,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              " IFX_DECTAPP_SUOTA_Const_FPURL1 failed.");
      return IFX_FAILURE;
    }
	  //printf("FP_URL1: %s\n",vacFPURL1);
		/*IFX_DBGA(a, IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
           "URL =", vacFPURL1);*/
#endif
	  IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
      "Opening a new external socket in non-blocking mode.");
	  pxSuotaInfo->SockFd = socket (AF_INET, SOCK_STREAM, 0);
		pxSuotaInfo->cbRespBuf_len=0;
        pxSuotaInfo->chunklen=0;
	
	IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
        "Socket is",pxSuotaInfo->SockFd);

    arg = fcntl (pxSuotaInfo->SockFd, F_GETFL, NULL);
    arg |= O_NONBLOCK;
    fcntl (pxSuotaInfo->SockFd, F_SETFL, arg);
    
    bzero ((char *) (&pxSuotaInfo->Serv_Addr), sizeof (pxSuotaInfo->Serv_Addr));

    pxSuotaInfo->Serv_Addr.sin_family = AF_INET;
    pxSuotaInfo->Serv_Addr.sin_addr.s_addr = IFX_DECTAPP_CD_atoaddr (acURL,&portno);
	  pxSuotaInfo->Serv_Addr.sin_port = htons (portno);
    
	  pxSuotaInfo->eStatus = IFX_DECTAPP_SUOTA_URL_SEND;
	
	  /*  Post the event to the internal socket */
    vxCallIntnlSocket.Event = IFX_DECTAPP_SUOTA_ADD_SOCK_FD;
    vxCallIntnlSocket.ux_IntEvent.pxSuotaId = pxSuotaInfo;
    //vxCallIntnlSocket.ux_IntEvent.pxConnId = NULL;
    
    IFX_DBGA (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
            "Posting Event and SuotaId to Internal Socket.");
    sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
          (struct sockaddr *) &vFILE_name, size);
    return IFX_SUCCESS;
  }
	
  if(!strcmp(pxSuotaInfo->xVerInfo.acSwVer,pxVerInfo->acSwIdentifier))
  {
    if(pxVerInfo->ucFileNum == pxSuotaInfo->xVerInfo.ucFileNum + 1)
	  {
	    IFX_DBGA (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
            "Request for next Url. Retrieve locally and send to PP");
	    /* PP is asking for next URL */
      /* Retrieve next Url locally and send to PP */
	    x_IFX_DECT_SUOTA_VersionAvailableInfo xVerAvailInfo;
	    memset(&xVerAvailInfo,0,sizeof(x_IFX_DECT_SUOTA_VersionAvailableInfo));
	    strcpy(xVerAvailInfo.acNewSwIdentifier, pxSuotaInfo->xRecvUrl.acNewSwVer);	  
      strcpy(xVerAvailInfo.acUrl, pxSuotaInfo->xRecvUrl.acRecvUrlList[pxSuotaInfo->xRecvUrl.ucSendIndex++]);
      xVerAvailInfo.unDelayMin =  pxSuotaInfo->xRecvUrl.unDelayMin;  
      xVerAvailInfo.uiSwTotalSize =  pxSuotaInfo->xRecvUrl.uiSwTotalSize;  
  
	    IFX_DECT_SUOTA_VersionAvailable(ucHandsetId,  &xVerAvailInfo);                               
	    pxSuotaInfo->xVerInfo.ucFileNum++;
	  }
	  else if(pxVerInfo->ucFileNum == pxSuotaInfo->xVerInfo.ucFileNum)
	  {
	    /* May be the last download was not successful */
	    /* Need to contact the MS once again */
			{
    		IFX_DBGA (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
      		"Version Indication Request for the fal case.");
    		/* For the first time Version Indication request came */
    		pxSuotaInfo->ucHandsetId = ucHandsetId;
	  		memcpy(&pxSuotaInfo->xVerInfo , pxVerInfo, sizeof(x_IFX_DECT_SUOTA_VersionIndicationInfo));	
    
	 			memset(&pxSuotaInfo->xRecvUrl, 0, sizeof(x_IFX_DECTAPP_SUOTA_MgMtRecvUrl));
    		IFX_DECTAPP_HTTP_GetHostNameFromUrl(acURL, 
                                pxSuotaInfo->xVerInfo.acUrl );
    		IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_ATA_STRING_INFO,
               "<SUOTA>Host is:",acURL);
   	  	IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
      			"Opening a new external socket in non-blocking mode.");
	 			pxSuotaInfo->SockFd = socket (AF_INET, SOCK_STREAM, 0);
				pxSuotaInfo->cbRespBuf_len=0;
        pxSuotaInfo->chunklen=0;
	
				IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_INT,
        "Socket is",pxSuotaInfo->SockFd);

    		arg = fcntl (pxSuotaInfo->SockFd, F_GETFL, NULL);
    		arg |= O_NONBLOCK;
    		fcntl (pxSuotaInfo->SockFd, F_SETFL, arg);
    
    		bzero ((char *) (&pxSuotaInfo->Serv_Addr), sizeof (pxSuotaInfo->Serv_Addr));

    		pxSuotaInfo->Serv_Addr.sin_family = AF_INET;
    		pxSuotaInfo->Serv_Addr.sin_addr.s_addr = IFX_DECTAPP_CD_atoaddr (acURL,&portno);
	  		pxSuotaInfo->Serv_Addr.sin_port = htons (portno);
    
	  		pxSuotaInfo->eStatus = IFX_DECTAPP_SUOTA_URL_SEND;
	
	  		/*  Post the event to the internal socket */
    		vxCallIntnlSocket.Event = IFX_DECTAPP_SUOTA_ADD_SOCK_FD;
    		vxCallIntnlSocket.ux_IntEvent.pxSuotaId = pxSuotaInfo;
    		//vxCallIntnlSocket.ux_IntEvent.pxConnId = NULL;
    
    		IFX_DBGA (a,IFX_DBG_LVL_LOW,IFX_DBG_STR,
            "Posting Event and SuotaId to Internal Socket.");
    		sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
          (struct sockaddr *) &vFILE_name, size);
    		return IFX_SUCCESS;
  		}

	  }
  }   
  
  IFX_DBGA (a,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
          "IFX_DECTAPP_SUOTA_VersionIndication:Successful.");
  return IFX_SUCCESS;
}

/*! \brief IFX_DECTAPP_SUOTA_NACKRecv callback function is called when there 
           is a negative acknowledgement from the PT.           
    \param[in] uiCallHdl Connection handle identifying a connection.
    \param[in] pcBuff Request buffer from PT. 
    \param[in] iLen Length of the buffer.
    \param[in] uiPrivateData identifies unique connection,application specific.
    \return IFX_SUCCESS or IFX_FAILURE.
*/    
    
e_IFX_Return IFX_DECTAPP_SUOTA_NACKRecv (IN uchar8 ucHandsetId,
                                         IN e_IFX_DECT_SUOTA_NACKReason eNack)
{
  IFX_DBGA (a,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry.");
  vxCallIntnlSocket.Event = IFX_DECTAPP_SUOTA_REMOVE_SOCK_FD;

  IFX_DBGA (a,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Close connection to internal socket.");
	
  sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
            (struct sockaddr *) &vFILE_name, size);

  IFX_DBGA (a,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Callbk NACK:Successful.");
	return IFX_SUCCESS;
}

/********************* CallBacks for Content Download *******************************/

/*! \brief IFX_DECT_DPSU_CallInitiate,this callback function is issued when the PT
           initiates a Data Call to communicate with the Download Server.
    \param[in] uiCallHdl unique Connection handle.
    \param[in] ucHandsetId Handset Number.
    \param[in] uiIEHdl Information Element handle.
    \param[out] pucRejectReason Reason for Call reject.
    \param[out] puiPrivateData data specific to app used to uniquely identify 
                a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_CallInitiate (IN uint32 uiCallHdl,
                                         IN uchar8 ucHandsetId,//
                                         IN uint32 uiIEHdl,
                                         OUT uchar8 *pucRejectReason,//
                                         OUT uint32 *puiPrivateData){

  int32 i = 0;
  int32 iSocIndex = IFX_DECTAPP_CD_MAX_CONN;
  x_IFX_DECTAPP_CD_ConnectionStruct *pxConnectionId = NULL;

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<ContentDownload>Entry.");

  if((NULL == pucRejectReason) || (NULL == puiPrivateData) || (0 == uiCallHdl)){

    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
       "<ContentDownload>puiPrivateData or pucRejectReason is null,or uiCallHdl is 0.");
    return IFX_FAILURE;
  }
  uiIEHdl = 0;
  *pucRejectReason = 0;

	for(i=0;i< IFX_DECTAPP_CD_MAX_CONN;++i){
	  if(vaxsoc_sock[i].IsUsed==0){
	    iSocIndex=i;
      break;	
	  }
	}
  IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_INT,
           "No Of Used Connection:",iSocIndex);

	if(iSocIndex == IFX_DECTAPP_CD_MAX_CONN){

    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"<ContentDownload>No free Connection.");
    /*iSocIndex = IFX_DECTAPP_IsAnyConnUsed(ucHandsetId);
    IFX_DBGA (a,IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
             "iSocIndex",iSocIndex);*/
	  return IFX_FAILURE;
	}
	vaxsoc_sock[iSocIndex].IsUsed=1;
	
	pxConnectionId = &vaxsoc_sock[iSocIndex];

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
             "<ContentDownload>Connection Index",*pxConnectionId);
  *puiPrivateData = (uint32) &vaxsoc_sock[iSocIndex];
  
  pxConnectionId->iSessionId = uiCallHdl;
  pxConnectionId->status = IFX_DECTAPP_CD_IDLE;

  pxConnectionId->iReqBufLen=0;
  bzero((char*)pxConnectionId->cbReqBuf,sizeof(pxConnectionId->cbReqBuf));
  pxConnectionId->iRespBufLen=0;
  bzero((char*)pxConnectionId->cbRespBuf,sizeof(pxConnectionId->cbRespBuf));
  
  vxCallIntnlSocket.Event = IFX_DECTAPP_CD_DATA_CALL_INIT;
	vxCallIntnlSocket.ux_IntEvent.pxConnId = pxConnectionId;

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
     "<ContentDownload>Posting Event and ConnectionId to Internal Socket.");
  sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
          (struct sockaddr *) &vFILE_name, size);

  pxConnectionId->SockFd=0;
	IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>Successful.");
	return IFX_SUCCESS;
}

/*! \brief IFX_DECT_DPSU_SendDataOverIpStk callback function is called when there 
           is a request from the PT for the download server and the application 
           needs to connect to the server.
    \param[in] uiCallHdl Connection handle identifying a connection.
    \param[in] pcBuff Request buffer from PT. 
    \param[in] iLen Length of the buffer.
    \param[in] uiPrivateData identifies unique connection,application specific.
    \return IFX_SUCCESS or IFX_FAILURE.
*/    
    
e_IFX_Return IFX_DECT_DPSU_DataSendToIP (IN uint32 uiCallHdl,
                                              IN char8 *pcBuff, 
		                              IN int32 iLen,
                                              IN uint32 uiPrivateData){

  char8 acURL[250]="";
  char8 acURL1[250]="";
  uint32 portno = 0;
  uint32 portno1 = 0;
  //int32 i=0;
  x_IFX_DECTAPP_CD_ConnectionStruct *pxConnectionId = NULL;

  IFX_DBGA (a,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,"<ContentDownload>Entry.");

  if((NULL == pcBuff) || (0 == uiCallHdl) || (0 == uiPrivateData)){

    //printf("uiCallHdl or uiPrivateData is 0,or pcBuff is NULL.\n");
    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
    "<ContentDownload>uiCallHdl or uiPrivateData is 0,or pcBuff is NULL.");
    return IFX_FAILURE;
  }
#if 0
  printf("**");
  for(i=0;i<iLen;i++){
	  printf("%c",pcBuff[i]);
  }
  printf("**");
  printf("\n");
#endif
  pxConnectionId = (x_IFX_DECTAPP_CD_ConnectionStruct *) uiPrivateData;

  bzero ((char *)pxConnectionId->cbReqBuf, sizeof (pxConnectionId->cbReqBuf));
  memcpy (pxConnectionId->cbReqBuf, pcBuff, iLen);
  pxConnectionId->iReqBufLen = iLen;

  bzero((char*)pxConnectionId->cbRespBuf, sizeof(pxConnectionId->cbRespBuf));
  pxConnectionId->iRespBufLen=0;
	pxConnectionId->ucState=0;

  if(IFX_DECTAPP_CD_HTTP_GetURL (pcBuff,iLen,acURL) == IFX_FAILURE){

    IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "<ContentDownload>Get URL failed.");
    return IFX_FAILURE;
  }
  //printf("pxConnectionId->Serv_Addr.sin_addr.s_addr is %x\n",pxConnectionId->Serv_Addr.sin_addr.s_addr);
  strcpy(acURL1,acURL);
  IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_INT,
          "<ContentDownload>Connection Status",pxConnectionId->status);
  if((pxConnectionId->status == IFX_DECTAPP_CD_CLOSED)||(pxConnectionId->status == IFX_DECTAPP_CD_IDLE) ||
			(pxConnectionId->Serv_Addr.sin_addr.s_addr != IFX_DECTAPP_CD_atoaddr (acURL1,&portno1))){
      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
      "<ContentDownload>State is IDLE or CLOSED or previous connection exists.");
		
      if((pxConnectionId->status!=IFX_DECTAPP_CD_CLOSED)&&(pxConnectionId->status != IFX_DECTAPP_CD_IDLE)){
  		  IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
        "<ContentDownload>Previous Connection exists,closing it.");
        
        if(FD_ISSET(pxConnectionId->SockFd, &vxGlobalReadFdS)){
            IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_INT,
                "<ContentDownload>Clearing FD and closing it",
                pxConnectionId->SockFd);

#ifdef CD_TEST
          ClearFd(pxConnectionId->SockFd,1);
#endif
				  FD_CLR (pxConnectionId->SockFd, &vxGlobalReadFdS);
       	  close (pxConnectionId->SockFd);
			  }
  
			  vxCallIntnlSocket.Event=IFX_DECTAPP_CD_DEFAULT;
		    vxCallIntnlSocket.ux_IntEvent.pxConnId = pxConnectionId;

        IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "<ContentDownload>Posting Event and connectionId to Internal Socket.");

         sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
                (struct sockaddr *) &vFILE_name, size);
		  }

      IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
        "<ContentDownload>Opening a new external socket in non-blocking mode.");
		  pxConnectionId->SockFd = socket (AF_INET, SOCK_STREAM, 0);

      IFX_DBGA (a,IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
              "<ContentDownload>Socket is",pxConnectionId->SockFd);

      arg = fcntl (pxConnectionId->SockFd, F_GETFL, NULL);
      arg |= O_NONBLOCK;
      fcntl (pxConnectionId->SockFd, F_SETFL, arg);
    
      bzero ((char *) (&pxConnectionId->Serv_Addr), sizeof (pxConnectionId->Serv_Addr));

      pxConnectionId->Serv_Addr.sin_family = AF_INET;
		  pxConnectionId->Serv_Addr.sin_addr.s_addr = IFX_DECTAPP_CD_atoaddr (acURL,&portno);
		  pxConnectionId->Serv_Addr.sin_port = htons (portno);

      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<ContentDownload>Callbk SendDataOverIpStk:Invoking connect.");
      vxCallIntnlSocket.Event = IFX_DECTAPP_CD_ADD_SOCK_FD;
      vxCallIntnlSocket.ux_IntEvent.pxConnId = pxConnectionId;
    
      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<ContentDownload>Posting Event and connectionId to Internal Socket.");
      sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
          (struct sockaddr *) &vFILE_name, size);
  }
  else if((pxConnectionId->status!=IFX_DECTAPP_CD_CLOSED)&&(pxConnectionId->status != IFX_DECTAPP_CD_IDLE))
  {
  		  IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
        "<ContentDownload>Previous Connection exists,closing it.");
        
        //if(FD_ISSET(pxConnectionId->SockFd, &vxGlobalReadFdS))
				{
            IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_INT,
                "<ContentDownload>Clearing FD and closing it",
                pxConnectionId->SockFd);

#ifdef CD_TEST
          ClearFd(pxConnectionId->SockFd,1);
#endif

          vxCallIntnlSocket.Event = IFX_DECTAPP_CD_REMOVE_SOCK_FD;
          vxCallIntnlSocket.ux_IntEvent.pxConnId = pxConnectionId;
    
         IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<ContentDownload>Posting Event and connectionId to Internal Socket.");
        sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
          (struct sockaddr *) &vFILE_name, size);
				sleep(1);

#if 0

				  FD_CLR (pxConnectionId->SockFd, &vxGlobalReadFdS);
			    FD_CLR (pxConnId->SockFd, &vxGlobalExceptFdS);
       	  close (pxConnectionId->SockFd);
#endif
			  }
#if 0 
			  vxCallIntnlSocket.Event=IFX_DECTAPP_CD_DEFAULT;
		    vxCallIntnlSocket.ux_IntEvent.pxConnId = pxConnectionId;

        IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "<ContentDownload>Posting Event and connectionId to Internal Socket.");

         sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
                (struct sockaddr *) &vFILE_name, size);
#endif
      IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
        "<ContentDownload>Opening a new external socket in non-blocking mode.");
		  pxConnectionId->SockFd = socket (AF_INET, SOCK_STREAM, 0);

      IFX_DBGA (a,IFX_DBG_LVL_NORMAL, IFX_DBG_INT,
              "<ContentDownload>Socket is",pxConnectionId->SockFd);

      arg = fcntl (pxConnectionId->SockFd, F_GETFL, NULL);
      arg |= O_NONBLOCK;
      fcntl (pxConnectionId->SockFd, F_SETFL, arg);
    
      bzero ((char *) (&pxConnectionId->Serv_Addr), sizeof (pxConnectionId->Serv_Addr));

      pxConnectionId->Serv_Addr.sin_family = AF_INET;
		  pxConnectionId->Serv_Addr.sin_addr.s_addr = IFX_DECTAPP_CD_atoaddr (acURL,&portno);
		  pxConnectionId->Serv_Addr.sin_port = htons (portno);

      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<ContentDownload>Callbk SendDataOverIpStk:Invoking connect.");
      vxCallIntnlSocket.Event = IFX_DECTAPP_CD_ADD_SOCK_FD;
      vxCallIntnlSocket.ux_IntEvent.pxConnId = pxConnectionId;
      pxConnectionId->IsUsed=1;
    
      IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<ContentDownload>Posting Event and connectionId to Internal Socket.");
      sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
          (struct sockaddr *) &vFILE_name, size);


  }
  else if (pxConnectionId->status == IFX_DECTAPP_CD_HTTP10CLOSED){

    memcpy (pxConnectionId->cbReqBuf, pcBuff, iLen);
    IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "<ContentDownload>Opening an external socket in non blocking mode.");

    pxConnectionId->SockFd = socket (AF_INET, SOCK_STREAM, 0);

    arg = fcntl (pxConnectionId->SockFd, F_GETFL, NULL);
    arg |= O_NONBLOCK;
    fcntl (pxConnectionId->SockFd, F_SETFL, arg);

    IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
    "<ContentDownload>Reopening closed connection.");

    vxCallIntnlSocket.Event = IFX_DECTAPP_CD_ADD_SOCK_FD;
    vxCallIntnlSocket.ux_IntEvent.pxConnId = pxConnectionId;

    IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        "<ContentDownload>Posting event and connectionId to internal socket.");    
    sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
            (struct sockaddr *) &vFILE_name, size);
  
  }else{

    IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "<ContentDownload>Callbk SendDataOverIpStk:Posting GET request to external socket.");
    //printf("Writing to socket\n");
    if (!write (pxConnectionId->SockFd, pcBuff, iLen)){
      //printf("Write failed !!!");
			IFX_DECT_DPSU_CallRelease (pxConnectionId->iSessionId,
                                    0/*uiIEHdl*/,
                                    IFX_DECT_RELEASE_ABNORMAL);

			IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
         "<ContentDownload>Writing to external socket failed.");
			return IFX_FAILURE;
		}
    IFX_DBGA (a,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
         "<ContentDownload>Write Successful.");
    vucWrite=1;
     //printf("Write successful\n"); 
		if(IFX_DECTAPP_CD_HTTP_GetVersion (pxConnectionId->cbReqBuf,
                          pxConnectionId->iReqBufLen, &iHTTP) == IFX_FAILURE){

        IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "<ContentDownload>Callbk SendDataOverIpStk:Get Version failed.");
        return IFX_FAILURE;
      }  
		  if (iHTTP == 10){
         
         IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "<ContentDownload>Callbk SendDataOverIpStk:Version is 1.0");
			  pxConnectionId->status = IFX_DECTAPP_CD_HTTP10;
			
   	  }else if (iHTTP == 11){

        IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                   "<ContentDownload>Callbk SendDataOverIpStk:Version is 1.1");
			  pxConnectionId->status = IFX_DECTAPP_CD_HTTP11;
		  }
      bzero ((char *) (pxConnectionId->cbReqBuf), sizeof (pxConnectionId->cbReqBuf));
	}
   IFX_DBGA (a,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
               "<ContentDownload>Successful.");
   return IFX_SUCCESS;
}

/*! \brief IFX_DECT_DPSU_CallRelease callback function is called once the DECT 
           stack closes the connection.
    \param[in] uiCallHdl unique Connection Handle.
    \param[in] uiIEHdl Information Element Handle.
    \param[in] eReason Reason for Release.
    \param[in] uiPrivateData data specific to app used to uniquely identify
               a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ReleaseCall( IN uint32 uiCallHdl,//
                                        IN uint32 uiIEHdl,
                                        IN e_IFX_DECT_RelType eReason,//
                                        IN uint32 uiPrivateData){//

  uiIEHdl = 0;
  x_IFX_DECTAPP_CD_ConnectionStruct *pxConnectionId = NULL;

  if((0 == uiCallHdl) || (0 == uiPrivateData)){
     
    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "<ContentDownload>Callbk CallRelease:uiCallHdl or uiPrivateData is 0.");
    return IFX_FAILURE;
  }

  IFX_DBGA (a,IFX_DBG_LVL_LOW, IFX_DBG_STR,
              "<ContentDownload>Callbk CallRelease:Entry.");

  pxConnectionId = (x_IFX_DECTAPP_CD_ConnectionStruct *) uiPrivateData;
  vxCallIntnlSocket.Event = IFX_DECTAPP_CD_REMOVE_SOCK_FD;
  vxCallIntnlSocket.ux_IntEvent.pxConnId = pxConnectionId;

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<ContentDownload>Callbk CallRelease:Close connection to internal socket.");
	
  sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
            (struct sockaddr *) &vFILE_name, size);

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "<ContentDownload>Callbk CallRelease:Successful.");
	return IFX_SUCCESS;
}

/***********************************************************************/

#if 1
/*! \brief API IFX_DECT_DPSU_ShutDectDataApp is invoked to shut down the 
           application completely.
    \param[in] Discard Null value.
    \return IFX_SUCCESS or iFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ShutDectDataApp (void *Discard){

  IFX_DBGA (a,b,c,"<ContentDownload>ShutDectDataApp Entry.");
  vxCallIntnlSocket.Event = IFX_DECTAPP_CD_EXIT_APP;
  //vxCallIntnlSocket.pxConnId = NULL;
  
  IFX_DBGA (a,b,c,"<ContentDownload>ShutDectDataApp:Closing Connection.");
  sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0,
            (struct sockaddr *) &vFILE_name, size);

  puiSUOTAvalue_ptr=&uiSUOTAvalue_ptr;
  pthread_join(SUOTA_Thread, ((void **)&puiSUOTAvalue_ptr));  	

  IFX_DBGA (a,b,c,"<ContentDownload>ShutDectDataApp Successful."); 
	SUOTA_Thread=0;
  return IFX_SUCCESS;
}
#endif

/*! \brief IFX_DECTAPP_CD_HTTP_GetVersion API is used to get the HTTP version from 
           the HTTP Get request message.
    \param[in] pcBuff pointer to get request buffer.
    \param[in] iBufLen length of buffer.
    \param[out] HTTP version number 1.0 or 1.1
    \return IFX_SUCCESS or IFX_FAILURE.
*/	

e_IFX_Return IFX_DECTAPP_CD_HTTP_GetVersion (IN char8 *pcBuff, 
               				     IN int32 iBufLen, 
					     OUT int32 *iHTTP){
										 
  char8 acHTTP[9];
  int32 iReadLen = 0;

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>API GetVersion:Entry.");

  if((NULL == pcBuff) || (NULL == iHTTP)){

    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "<ContentDownload>API GetVersion:pcBuff or iHTTP is NULL.");
    return IFX_FAILURE;
  }
  while (!(isspace (*(pcBuff + iReadLen)))){
    
	iReadLen = iReadLen + 1;
  }
  iReadLen += 1;
  while (!(isspace (*(pcBuff + iReadLen)))){
    
	iReadLen = iReadLen + 1;
  }
  iReadLen = iReadLen + 1;
  strncpy (acHTTP, pcBuff + iReadLen, 8);
  acHTTP[8] = '\0';

  if (IFX_DECTAPP_CD_Strcmp ("HTTP/1.0", acHTTP, 8) == 0){
  
    *iHTTP = 10;
	
  }else if (IFX_DECTAPP_CD_Strcmp ("HTTP/1.1", acHTTP, 8) == 0){
    *iHTTP = 11;
   }
   IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "<ContentDownload>API GetVersion:Successful.");
   return IFX_SUCCESS;
}

/*! \brief The API IFX_DECTAPP_CD_HTTP_GetCode gets the code of an HTTP Response 
           message.The code extracted from the response message is returned.
    \param[in] pcBuff pointer to buffer containing response from server.
    \param[in] iBufLen Length of response buffer.
    \param[in] iCode Code of the response.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECTAPP_CD_HTTP_GetCode (IN char8 *pcBuff, 
             				  IN int32 iBufLen, 
					  OUT int32 *iCode){

  char8 acCode[4] = "";
  
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>API GetCode:Entry.");
   
  if((NULL == pcBuff) || (NULL == iCode)){

    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "<ContentDownload>API GetCode:pcBuff or iCode is NULL.");
    return IFX_FAILURE;
  }
  strncpy (acCode, pcBuff + 9, 3);
  acCode[3] = '\0';
  *iCode = atoi (acCode);
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>API GetCode:Successful.");
  return IFX_SUCCESS;
}

/*! \brief The API IFX_DECTAPP_CD_Strcmp compares two strings upto length given
           by iLen(including blank spaces,if any).
	\param[in] acA[] String to be compared.
	\param[in] acB[] String to be compared.
	\param[in] iLen length upto which the strings need to be compared.
    \return 0 or 1.Return value 0 indicates strings are equal and 1 indicates 
	        they are unequal.          
*/

int32 IFX_DECTAPP_CD_Strcmp (IN char8 acA[], 
	      		     IN char8 acB[], 
			     IN int32 iLen){

  int32 iFlag = 0;
  int32 i = 0;
  
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>API Strcmp:Entry.");
  for (i = 0; i < iLen; i++){
  
    if (acA[i] != acB[i]){

	   IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "<ContentDownload>API Strcmp:Strings Unequal.");
      iFlag = 1;
	  break;
    }
  }
  return iFlag;
}

/*! \brief The API IFX_DECTAPP_CD_atoaddr accepts address in form www.abcd.com 
           and aaa.bbb.ccc.ddd and returns the address in s_addr.
    \param[in] pcAddress String containing the address.
	\param[out] piPort Port Address.
	\return s_addr or 0. 
		   
*/

int32 IFX_DECTAPP_CD_atoaddr(IN char8 *pcAddress,OUT uint32 *piPort){

  struct hostent *host = NULL;
  STATIC struct in_addr saddr = {0};
  STATIC struct in_addr saddr1 = {0};
  //uint64  uinetaddr = 0;
  char8 *pcTemp = NULL;
  char8 acTemp[125] = "";
  char8 *p = NULL;
  int32 i = 5;

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>API atoaddr:Entry.");

  *piPort =0;
  p =  pcAddress + strlen(pcAddress);

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
          "<ContentDownload>API atoaddr:Length of address",strlen(pcAddress));
	
  while(*p!=':'){
    
	  acTemp[i] = *p;
	  p--;
	  i--;
	  if(i < 0){
     
	     *piPort =80;
	     break;
	  }
  }
  if(*piPort == 0){
	 *p = '\0';
	 *piPort = atoi(&acTemp[++i]);
  }
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
             "<ContentDownload>API atoaddr:Port number",*piPort);
  
	/*For address in form aaa.bbb.ccc.ddd. */

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
          "<ContentDownload>API atoaddr:Address Passed is",pcAddress);
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_INT,
        "<ContentDownload>API atoaddr:Length of Address Passed is",strlen(pcAddress));
	
  strcpy(acTemp,pcAddress);

  if(inet_aton (pcAddress,&saddr) != 0){
   
     //printf ("Address in s_addr is %x\n",saddr.s_addr);
     IFX_DBGA (a,b,d,"<ContentDownload>API atoaddr:Address in s_addr is",saddr.s_addr);
	  return saddr.s_addr;
		
  }
  
  /*For address in form "lab68.blr.infineon.com"*/
  
  host = gethostbyname (pcAddress);

  if (host != NULL){
	 
     pcTemp = (char8*)inet_ntoa(*(struct in_addr*)(host->h_addr));
	  
     saddr.s_addr = *((uint64*)(host->h_addr));
     
     IFX_DBGA (a,b,d,"<ContentDownload>API atoaddr:Network Address",pcTemp);
		
     //uinetaddr = *((uint64*)(host->h_addr_list[0]));
     
     if(inet_aton (pcTemp,&saddr1)!=0){
   
        IFX_DBGA (a,b,d,"<ContentDownload>API atoaddr:Address in s_addr is",saddr1.s_addr);
	return saddr1.s_addr;
     }
  }
  //printf ("Returning NULL.");
  IFX_DBGA (a,b,c,"<ContentDownload>API atoaddr:Returning NULL.");
  return 0;
}


/*! \brief API IFX_DECTAPP_CD_HTTP_GetURL is used to get the URL from GET request
           HTTP message.
    \param[in] pcBuff GET request buffer.
    \param[in] iBufLen length of buffer.
    \param[out] pcURL extracted URL.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECTAPP_CD_HTTP_GetURL (IN char8 *pcBuff, 
				         IN int32 iBufLen ,
					 OUT char8 *pcURL){
  int32 iUrlLen = 0;
  char8 *pcUrlPtr = NULL;
  char8 *pcTempBuff = NULL;
  int32 i = 0;

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "GetURL:Entry.");

  if((pcTempBuff = (char8 *)calloc((iBufLen+1),sizeof(char8)))== NULL){
			IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "Null pointer Malloc Failed");
			return IFX_FAILURE;
	}

  for(i = 0;i <= iBufLen; ++i){

    pcTempBuff[i]=tolower(pcBuff[i]);
  }
  
  pcUrlPtr=strstr(pcTempBuff,"host:");
  
  if(pcUrlPtr==NULL){
   
    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "GetURL:Host Missing.");
    free(pcTempBuff);
    return IFX_FAILURE;
  }
  pcUrlPtr += 5;
  
  while(isspace(*pcUrlPtr)){

    ++pcUrlPtr;
  }
  
  iUrlLen=0;
  while(*(pcUrlPtr+iUrlLen)!='\x0D'){

    ++iUrlLen;
  }
  *(pcURL+iUrlLen)='\0';
  strncpy(pcURL,pcUrlPtr,iUrlLen);
  
  free(pcTempBuff);

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
             "GetURL:URL is",pcURL);
 
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "GetURL:Successful.");
  return IFX_SUCCESS;

}

/*! \brief API ContDownInit is used to initialize ContentDownload and create 
           placeholders for callback functions.
    \return IFX_SUCCESS or IFX_FAILURE;       
*/
e_IFX_Return IFX_DECT_ContDownInit(){

  x_IFX_DECT_DPSU_CallBks xCallBks={0};

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>ContDownInit:Entry.");
  xCallBks.pfnCallInitiate= IFX_DECT_DPSU_CallInitiate;
  xCallBks.pfnDataSendToIP = IFX_DECT_DPSU_DataSendToIP;
  xCallBks.pfnCallRelease =IFX_DECT_DPSU_ReleaseCall;

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>RegisterDataApp invoked.");
  if(IFX_DECT_DPSU_RegisterDataApp(1,&xCallBks) == IFX_FAILURE){

    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                  "<ContentDownload>ContDownInit:RegisterDataApp failed.");
    return IFX_FAILURE;
  }    

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"<ContentDownload>ContDownInit:Successful.");
  return IFX_SUCCESS;
}

/*! \brief API IFX_DECTAPP_SUOTA_Init is used to initialize SUOTA and create 
           placeholders for callback functions.
    \return IFX_SUCCESS or IFX_FAILURE;       
*/
e_IFX_Return IFX_DECTAPP_SUOTA_Init (void *Discard){

  int32 i = 0;
  x_IFX_DECT_SUOTA_CallBks xCallBks={0};
  	
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry."); 
  for(i = 0; i < IFX_DECTAPP_SUOTA_MAX_CONN; i++){	
     vaxSuotaSess[i].IsAvail=0;
  }  

  xCallBks.pfnVerIndication = IFX_DECTAPP_SUOTA_VersionIndication;  
  xCallBks.pfnNack = IFX_DECTAPP_SUOTA_NACKRecv;
  
  if(IFX_DECT_SUOTA_RegisterCallBks(&xCallBks) == IFX_FAILURE){

    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "IFX_DECT_SUOTA_RegisterCallBks failed.");
    return IFX_FAILURE;
  } 
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Successful.");
  return IFX_SUCCESS;
}

/*! \brief The API IFX_DECTAPP_CD_Init initializes the FT Application and spawns
           a new thread for it.
    \return IFX_SUCCESS or IFX_FAILURE.
*/    

e_IFX_Return IFX_DECT_DPSU_Init (void *Discard){

  int32 i = 0;
  	
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"IFX_DECT_DPSU_Init Entry.");
	if(SUOTA_Thread)
	{
  	IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"DPSU thread already running.");
  	return IFX_SUCCESS;
	} 
  for(i = 0; i < IFX_DECTAPP_CD_MAX_CONN; i++){
	
     vaxsoc_sock[i].IsUsed=0;
  }
	
  FD_ZERO(&vxGlobalReadFdS);
  FD_ZERO(&vxGlobalWriteFdS);
  FD_ZERO(&vxGlobalExceptFdS);

  viInternalSockFd = socket (PF_UNIX, SOCK_DGRAM,(int32) NULL);

  if (viInternalSockFd < 0)
  {
    perror ("Socket creation failed.");
	  IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
          "<ContentDownload>Exiting from thread");
    return IFX_FAILURE;
  }                           
 
  vFILE_name.sun_family = PF_FILE;
  strcpy (vFILE_name.sun_path, "/tmp/httpc_sock_file");
	system("rm -f /tmp/httpc_sock_file");
  
  //extern uchar8 vucDectAgnetModId;
  size = offsetof (struct sockaddr_un, sun_path) +strlen (vFILE_name.sun_path) + 1;

  if (bind (viInternalSockFd, (struct sockaddr *) &vFILE_name, size) < 0)
  {
    perror ("Bind failed.");         
    IFX_DBGC (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "<ContentDownload>Exiting from thread");
    return IFX_FAILURE;
  }
  
  arg1 = fcntl (viInternalSockFd, F_GETFL, NULL);
  arg1 |= O_NONBLOCK;
  fcntl (viInternalSockFd, F_SETFL, arg1);
  
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<ContentDownload>Socket bound successfully.");
 

  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<ContentDownload>API IFX_DECT_DPSU_Init,creating new thread .");	
  if (pthread_create (&SUOTA_Thread, NULL,(THREAD_RTN_PTR)IFX_DECTAPP_CD_Thread_Function, NULL)){
     
    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "<ContentDownload>API IFX_DECT_DPSU_Init,creating new thread failed."); 
    return IFX_FAILURE;
  }
  if(IFX_DECT_ContDownInit(NULL) == IFX_FAILURE){

    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "<ContentDownload>ContDownInit:Init function failed.");
    return IFX_FAILURE;
  }
  if(IFX_DECTAPP_SUOTA_Init(NULL) == IFX_FAILURE){

    IFX_DBGA (a,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "<SUOTA>Init function failed.");
    return IFX_FAILURE;
  }
  IFX_DBGA (a,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<ContentDownload>API IFX_DECT_DPSU_Init successful.");
  return IFX_SUCCESS;
}
#endif
