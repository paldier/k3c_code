/**************************************************************************
 **   SRC_FILE          : IFX_DECT_ListAccess.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT Agent
 **   SRC VERSION       : v0.1
 **   DATE              : 8th May 2009
 **   AUTHOR            :
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_os.h"
#include "IFX_DECT_USU.h"
#include "IFX_DECT_LAU.h"
#include "IFX_DECT_ListAccess.h"
#ifdef  LTQ_DT_SUPPORT
#include "IFX_DT_LAU.h"
#include "IFX_DT_Data.h"
#endif

#define printf(...)
uchar8 vucMissCallReadStatusNtfyFlag = 0;  //For Missed Call Read Status Change Notification

x_IFX_DECT_ListInfo vaxListInfo[IFX_DECTAPP_MAX_DECT_ENDPTS][IFX_DECT_LAU_MAX_SESS_PER_HS];
int16 vnListLock[IFX_DECT_LAU_MAX_SUPPORTED_LISTS][IFX_DECTAPP_MAX_DECT_ENDPTS];
uchar8 vucNotifyIgnore[IFX_DECT_LAU_MAX_SUPPORTED_LISTS];
uchar8 vacAssocLines[IFX_DECTAPP_MAX_DECT_ENDPTS][IFX_DECTAPP_MAX_LINES+1];
uint16 vunContactsPerLine[IFX_DECTAPP_MAX_LINES];
uint16 vunCommonContactEntires=0;
x_IFX_DECT_PinEvalInfo vaxPinInfo;

uchar8 vacDefaultSortingFields[IFX_DECT_LAU_MAX_SUPPORTED_LISTS] = {IFX_DECT_LAU_CL_MISSED_DATE_TIME,
                                                                    IFX_DECT_LAU_CL_OUTGOING_DATE_TIME,
                                                                    IFX_DECT_LAU_CL_INCOMING_DATE_TIME,
                                                                    IFX_DECT_LAU_CL_ALL_CALL_DATE_TIME,
                                                                    IFX_DECT_LAU_CON_LIST_NAME,
																								            				IFX_DECT_LAU_INT_NAME_LIST_NUMBER,
                                                                    0,
																												            IFX_DECT_LAU_LINE_SET_LIST_LINE_ID,
																												            IFX_DECT_LAU_CL_ALL_INCOMING_DATE_TIME};

uchar8 vacEditableFields[IFX_DECT_LAU_MAX_SUPPORTED_LISTS][IFX_DECTAPP_MAX_EDITABLE] = {{0},{0},{0},{0},

	 {5,IFX_DECT_LAU_CON_LIST_NAME,IFX_DECT_LAU_CON_LIST_FIRST_NAME,IFX_DECT_LAU_CON_LIST_NUMBER,IFX_DECT_LAU_CON_LIST_NUMBER,
      IFX_DECT_LAU_CON_LIST_LINE_ID},
	 {2,IFX_DECT_LAU_INT_NAME_LIST_NAME,IFX_DECT_LAU_INT_NAME_LIST_CALL_INTERCEPT},
   {5,IFX_DECT_LAU_SYS_SET_LIST_PIN,IFX_DECT_LAU_SYS_SET_LIST_CLOCK_MASTER,IFX_DECT_LAU_SYS_SET_LIST_BASE_RESET,
	    IFX_DECT_LAU_SYS_SET_LIST_NEW_PIN,IFX_DECT_LAU_SYS_SET_LIST_EMISSION_MODE},
   {8,IFX_DECT_LAU_LINE_SET_LIST_LINE_NAME,IFX_DECT_LAU_LINE_SET_LIST_ATTACH_PP,IFX_DECT_LAU_LINE_SET_LIST_CALL_MODE,
      IFX_DECT_LAU_LINE_SET_LIST_PERM_CLIR,IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_U,IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_N,
      IFX_DECT_LAU_LINE_SET_LIST_CALL_FWD_B,IFX_DECT_LAU_LINE_SET_LIST_CALL_INTRU},
   {0}};
	                                                                           
uchar8 vacUnEditableFields[IFX_DECT_LAU_MAX_SUPPORTED_LISTS][IFX_DECTAPP_MAX_UNEDITABLE] = {

	 {7,IFX_DECT_LAU_CL_MISSED_NUMBER,IFX_DECT_LAU_CL_MISSED_NAME,IFX_DECT_LAU_CL_MISSED_DATE_TIME,
	    IFX_DECT_LAU_CL_MISSED_NEW,IFX_DECT_LAU_CL_MISSED_LINE_NAME,IFX_DECT_LAU_CL_MISSED_LINE_ID,
	    IFX_DECT_LAU_CL_MISSED_NUM_CALLS},
   {5,IFX_DECT_LAU_CL_OUTGOING_NUMBER,IFX_DECT_LAU_CL_OUTGOING_NAME,IFX_DECT_LAU_CL_OUTGOING_DATE_TIME,
	    IFX_DECT_LAU_CL_OUTGOING_LINE_NAME,IFX_DECT_LAU_CL_OUTGOING_LINE_ID},
	 {5,IFX_DECT_LAU_CL_INCOMING_NUMBER,IFX_DECT_LAU_CL_INCOMING_NAME,IFX_DECT_LAU_CL_INCOMING_DATE_TIME,
	    IFX_DECT_LAU_CL_INCOMING_LINE_NAME,IFX_DECT_LAU_CL_INCOMING_LINE_ID},
	 {6,IFX_DECT_LAU_CL_ALL_CALL_TYPE,IFX_DECT_LAU_CL_ALL_CALL_NUMBER,IFX_DECT_LAU_CL_ALL_CALL_NAME,
		  IFX_DECT_LAU_CL_ALL_CALL_DATE_TIME,IFX_DECT_LAU_CL_ALL_CALL_LINE_NAME,IFX_DECT_LAU_CL_ALL_CALL_LINE_ID},
	 {0},
   {1,IFX_DECT_LAU_INT_NAME_LIST_NUMBER},
	 {3,IFX_DECT_LAU_SYS_SET_LIST_FW_VER,IFX_DECT_LAU_SYS_SET_LIST_EE_VER,IFX_DECT_LAU_SYS_SET_LIST_HW_VER},
	 {1,IFX_DECT_LAU_LINE_SET_LIST_LINE_ID},
   {7,IFX_DECT_LAU_CL_ALL_INCOMING_NUMBER,IFX_DECT_LAU_CL_ALL_INCOMING_NAME,IFX_DECT_LAU_CL_ALL_INCOMING_DATE_TIME,
	    IFX_DECT_LAU_CL_ALL_INCOMING_NEW,IFX_DECT_LAU_CL_ALL_INCOMING_LINE_NAME,IFX_DECT_LAU_CL_ALL_INCOMING_LINE_ID,
	    IFX_DECT_LAU_CL_ALL_INCOMING_NUM_CALLS}}; 

extern e_IFX_Return IFX_DECT_GetEndptName(IN uchar8 ucHandSetId,
                                   OUT char8 *szEndptId);
extern e_IFX_Return 
IFX_CIF_EndptDefaultVLGet(IN char8* szEndptId,
 				                  OUT uchar8* pucLineId,
        			           OUT e_IFX_ReasonCode* peReason);
extern e_IFX_Return
IFX_CIF_GetContactListInfoFromVmapiObj(IN void *pxNew,
                                       OUT uchar8 *pucLineId,
                                       OUT uchar8 *pucNoOfEntries);

int32 IFX_DECTAPP_Compare1(IN uint32 uiEntryAddrA,IN uint32 uiEntryAddrB,
		                      IN uchar8 ucListId,
										  IN uchar8 ucIsCaseSense);

e_IFX_Return IFX_DECTAPP_IsHandSetIdValid(uchar8 pucHandSetId);
e_IFX_Return IFX_DECTAPP_IsListIdValid(uchar8 pucListId);

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_GetFreeSessionForHS
 *  Description     : This internal Api fetches free session for a handset. 
 *  Input Values    : ucHandSet - Handset Number
 *  Output Values   : puiSessHdl - Session Handle
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_GetFreeSessionForHS(IN uchar8 ucHandSet,OUT uint32 *puiSessHdl)
{
  int32 i = 0;


if(IFX_DECTAPP_IsHandSetIdValid(ucHandSet) == IFX_SUCCESS ){

  for(i=0;i<IFX_DECT_LAU_MAX_SESS_PER_HS;i++){

    if(vaxListInfo[ucHandSet-1][i].nSessId == 0){
	    *puiSessHdl = (uint32)&vaxListInfo[ucHandSet-1][i];
      return IFX_SUCCESS;  
    }  
  }
}
  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DECTAPP_GetFreeSessionForHS>No free Session for Handset available." );
  return IFX_FAILURE;				
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_ValidateSessionId
 *  Description     : This internal Api validates the session identifier 
 *  Input Values    : nSessionId - Session Identifier
 *  Output Values	  : puiSessHdl - Session Handle 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_ValidateSessionId(IN uint16 nSessionId,OUT uint32 *puiSessHdl){

   uchar8 ucHS = 0;
   uchar8 ucIdx = 0;

   ucHS = (nSessionId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS;
   ucIdx = nSessionId - ucHS*IFX_DECT_LAU_MAX_SESS_PER_HS - 1;
   if(vaxListInfo[ucHS][ucIdx].nSessId == nSessionId){
     *puiSessHdl = (uint32)&vaxListInfo[ucHS][ucIdx];
		 return IFX_SUCCESS;
   }
   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<IFX_DECTAPP_ValidateSessionId>Invalid Session ID." );
   return IFX_FAILURE;
}


/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_MoveSession
 *  Description     : This Api Moves  a List Access Session for the given PP
 *                    for the requested list and sends the number of list entries and
 *                    sorting fields used for the session.
 *  Input Values    : ucHandset - Handset Number
                      pxInCmd - It stores List id and Sorting Fields for this 
                                session sent by PP
 *  Output Values   : pxOutCmd - FP sends the number of Entries in the List,
                                 Sorting Fields and Session Id
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
#ifdef LTQ_DT_SUPPORT
e_IFX_Return IFX_DECTAPP_LAU_MoveSession(
                        IN x_IFX_DECT_LAU_ListCommands *pxInCmd, OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){
	uint32 uiSessHdl = 0;
  //uchar8 ucAvailEntries = 0;
  x_IFX_DECT_ListInfo *pxListInfo = NULL;
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
     "Entry" );

  if((NULL == pxInCmd) || (NULL == pxOutCmd)){

    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
             "Invalid Input Parameters: pxInCmd/pxOutCmd NULL." );
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
    goto Fail;
  }
	
  if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(pxInCmd->nSessionId,&uiSessHdl)){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Invalid session Id." );
    goto Fail;
  }
  pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;
	if(pxInCmd->uxListCmd.xSessionMoveReq.uiSubListId > 0 && pxListInfo -> nLevel == IFX_DT_LEVEL_TREE_LIST){
		pxListInfo -> ucSubListId = pxInCmd->uxListCmd.xSessionMoveReq.uiSubListId ;
		pxListInfo -> nLevel = IFX_DT_LEVEL_SUB_LIST;
		printf(" <Move session>  Tree List ( %x ) =>  SubList ( %d )\n",pxListInfo->ucListId, pxListInfo -> ucSubListId );
	}else if(pxInCmd->uxListCmd.xSessionMoveReq.uiSubListId > 0 && pxListInfo -> nLevel == IFX_DT_LEVEL_SUB_LIST){
		pxListInfo -> ucSubSubListId = pxInCmd->uxListCmd.xSessionMoveReq.uiSubListId;
		pxListInfo -> nLevel = IFX_DT_LEVEL_SUB_SUBLIST ;
		printf(" <Move session > Tree List id (%x ) =>  SubList (%d ) => SubSubList (%d)\n",pxListInfo->ucListId, pxListInfo -> ucSubListId, pxListInfo -> ucSubSubListId);
	}	else if( ! pxInCmd->uxListCmd.xSessionMoveReq.uiSubListId &&  pxListInfo -> nLevel == IFX_DT_LEVEL_SUB_SUBLIST ){
		printf(" < Move session > SubSubList => (%d ) => SubList (%d) of TreeList (%x)\n",pxListInfo -> ucSubSubListId,pxListInfo -> ucSubListId, pxListInfo->ucListId);
			pxListInfo ->	nLevel = IFX_DT_LEVEL_SUB_LIST;
			 pxListInfo -> ucSubSubListId = 0;
	}	else if(! pxInCmd->uxListCmd.xSessionMoveReq.uiSubListId && pxListInfo -> nLevel == IFX_DT_LEVEL_SUB_LIST){	
		printf(" <Move session >  SubList => (%d) To TreeList =>(%x)\n",pxListInfo -> ucSubListId, pxListInfo->ucListId);
			pxListInfo ->	nLevel = IFX_DT_LEVEL_TREE_LIST;
			pxListInfo -> ucSubListId=0;
	}else {
			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DECTAPP_LAU_MoveSession>Invalid Move Session Parameters....!!!" );
           printf("<IFX_DECTAPP_LAU_MoveSession>Invalid Move Session Parameters....!!!" );
			goto Fail;
	}


		
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
             "Session Id",pxListInfo->nSessId);
		//Get the count of Sub-List/Sub-SubList entires
  switch(pxListInfo -> nLevel){
			case IFX_DT_LEVEL_TREE_LIST:
				if(IFX_DECTAPP_InitProprietaryTreeList(pxListInfo) != IFX_SUCCESS){
      	  		pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_START_IDX;
		        	goto Fail;
				}
			break;

			case IFX_DT_LEVEL_SUB_LIST:
			if(IFX_DECTAPP_InitProprietarySubList(pxListInfo) != IFX_SUCCESS){
      	  pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_START_IDX;
        	goto Fail;
			}
			break;

			case IFX_DT_LEVEL_SUB_SUBLIST:
			if(IFX_DECTAPP_InitProprietarySubSubList(pxListInfo) != IFX_SUCCESS){
      	  pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_START_IDX;
        	goto Fail;
			}
			break;

			default:
				goto Fail;
	}
					pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_SESS_MOVE_CFM;
					pxOutCmd->nSessionId = pxInCmd->nSessionId;
  				pxOutCmd->uxListCmd.xSessionMoveCfm.nNoOfAvailEntries = pxListInfo->ucNoOfListEntries; //ucAvailEntries;
					//pxListInfo->ucNoOfListEntries = ucAvailEntries;
	
	return IFX_SUCCESS;

Fail:
   pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_NACK;
   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DECTAPP_LAU_MoveSession>Move Session Failure!!" );
   return IFX_FAILURE;
}
#endif
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_StartSession
 *  Description     : This Api initiates a List Access Session for the given PP
 *                    for the requested list and sends the number of list entries and
 *                    sorting fields used for the session.
 *  Input Values    : ucHandset - Handset Number
                      pxInCmd - It stores List id and Sorting Fields for this 
                                session sent by PP
 *  Output Values	  : pxOutCmd - FP sends the number of Entries in the List,
                                 Sorting Fields and Session Id
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_LAU_StartSession(IN uchar8 ucHandSet,
			                       IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                             OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){
  uint32 uiSessHdl = 0;
  uchar8 ucListId = 0;
  x_IFX_DECT_ListInfo *pxListInfo = NULL;

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	            "Entry" );
	
	if( NULL == pxOutCmd){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	            "Invalid out parameters: pxOutCmd NULL " );
		return IFX_FAILURE;
	}			
  if((NULL == pxInCmd) || (0 == ucHandSet) || (ucHandSet >IFX_DECTAPP_MAX_DECT_ENDPTS)){

    pxOutCmd->uxListCmd.xSessionStartCfm.ucRejectReason = IFX_DECT_LAU_SESS_START_REJ_REASON_NO_RESOURCES;
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	            "Invalid input parameters: pxInCmd/pxOutCmd NULL or invalid HS Id." );
		goto Fail;
  }

  if(IFX_FAILURE == IFX_DECTAPP_GetFreeSessionForHS(ucHandSet,&uiSessHdl)){
    
    pxOutCmd->uxListCmd.xSessionStartCfm.ucRejectReason = IFX_DECT_LAU_SESS_START_REJ_MAX_SESS_REACHED;
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	            "Invalid Session Id." );
		goto Fail;
  }
  pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;

  pxListInfo->nSessId = pxInCmd->nSessionId;
  pxListInfo->ucListId = pxInCmd->uxListCmd.xSessionStartReq.eListId;

	if(IFX_DECTAPP_IsListIdValid(pxListInfo->ucListId) != IFX_SUCCESS  ){
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	           "Invalid List Id",pxListInfo->ucListId);
	goto Fail;
	}
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	           "Session Id",pxListInfo->nSessId);

ucListId=pxListInfo->ucListId;
  if( pxInCmd->uxListCmd.xSessionStartReq.eListId != IFX_DECT_LAU_SYS_SETTINGS){
   	pxOutCmd->uxListCmd.xSessionStartCfm.ucNoOfSortingFields = 1;
#ifdef  LTQ_DT_SUPPORT
	if(IFX_DECTAPP_isProprietaryList(ucListId) == IFX_SUCCESS ){
					if(IFX_DT_Get_TreeList_SortingFields(ucListId,pxOutCmd) != IFX_SUCCESS){
        				IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "IFX_DT_Get_TreeList_SortingFields failed." );
						goto Fail;
				}
		}else{
	#endif
 					memcpy(pxOutCmd->uxListCmd.xSessionStartCfm.aucSortingFields,
         &vacDefaultSortingFields[ucListId-1],
         pxOutCmd->uxListCmd.xSessionStartCfm.ucNoOfSortingFields);
#ifdef  LTQ_DT_SUPPORT
		}
#endif
  }else{
   pxOutCmd->uxListCmd.xSessionStartCfm.ucNoOfSortingFields = 0;
  }
    if(vacAssocLines[ucHandSet-1][0] == '\0'){ 
      if(IFX_FAILURE == IFX_CIF_AssocLineIdsGet(ucHandSet,vacAssocLines[ucHandSet-1])){

        IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "IFX_CIF_AssocLineIdsGet failed." );
        pxOutCmd->uxListCmd.xSessionStartCfm.ucRejectReason = IFX_DECT_LAU_SESS_START_REJ_REASON_NO_RESOURCES;
	      pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
				goto Fail;
      }
    }
#ifdef LTQ_DT_SUPPORT
if(IFX_DECTAPP_isProprietaryList(ucListId) == IFX_SUCCESS ){
if(IFX_DECTAPP_InitProprietaryTreeList(pxListInfo /*&ucEntrycount*/) == IFX_FAILURE){
 pxOutCmd->uxListCmd.xSessionStartCfm.ucRejectReason = IFX_DECT_LAU_SESS_START_REJ_REASON_NO_RESOURCES;
     pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "IFX_DECTAPP_ListSort failed." );
     goto Fail;
  }
}else 
#endif

if(IFX_FAILURE == IFX_DECTAPP_ListSort(vacAssocLines[ucHandSet-1],pxListInfo)){
     pxOutCmd->uxListCmd.xSessionStartCfm.ucRejectReason = IFX_DECT_LAU_SESS_START_REJ_REASON_NO_RESOURCES;
     pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	            "IFX_DECTAPP_ListSort failed." );
		 goto Fail;
  }

  pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_SESS_START_CFM;
  pxOutCmd->nSessionId = pxInCmd->nSessionId;
  pxOutCmd->uxListCmd.xSessionStartCfm.eListId = pxInCmd->uxListCmd.xSessionStartReq.eListId;
  pxOutCmd->uxListCmd.xSessionStartCfm.nNoOfAvailEntries = pxListInfo->ucNoOfListEntries;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
			     "NumberOfAvailEntries =",
           pxOutCmd->uxListCmd.xSessionStartCfm.nNoOfAvailEntries);

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "Success" );
  return IFX_SUCCESS;

  Fail:
    pxOutCmd->nSessionId = 0;
    pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_NACK;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "Start Session Failure!!" );
    return IFX_FAILURE;  
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_FieldQuery
 *  Description     : This command from PP queries the fields supported in the 
 *                    entries of the given list in FP.The Api sends the supported
 *                    field identifiers grouped as editable and non-editable. 
 *  Input Values    : pxInCmd - PP sends the session Id for the query 
 *  Output Values	  : pxOutCmd - FP sends editable and non-editable field
 *                    identifiers with their respective counts.
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           : If multiple instances of a field are supported,the Field Id
                      is repeated as many times as many instances are supported.
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_LAU_FieldQuery(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                           OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){

  uint32 uiSessHdl = 0;
  x_IFX_DECT_ListInfo *pxListInfo = NULL;

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
	         "<IFX_DECTAPP_LAU_FieldQuery>Entry." );

	if( NULL == pxOutCmd){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Invalid out parameters: pxOutCmd NULL " );
    return IFX_FAILURE;
  }


  if(NULL == pxInCmd ){

    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
	         "<IFX_DECTAPP_LAU_FieldQuery>Invalid Input Parameters: pxInCmd NULL." );
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
		goto Fail;
  }

  if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(pxInCmd->nSessionId,&uiSessHdl)){
  
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_LAU_FieldQuery>Invalid Session Id." );
		goto Fail;
  }
  pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;
 
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "<IFX_DECTAPP_LAU_FieldQuery>Session ID=",pxInCmd->nSessionId);
						
  memset(pxOutCmd->uxListCmd.xFieldQueryCfm.aucEditableFields,0,
			   sizeof(pxOutCmd->uxListCmd.xFieldQueryCfm.aucEditableFields));
  memset(pxOutCmd->uxListCmd.xFieldQueryCfm.aucUneditableFields,0,
			   sizeof(pxOutCmd->uxListCmd.xFieldQueryCfm.aucUneditableFields));
uchar8 ucListId=pxListInfo->ucListId;

#ifdef  LTQ_DT_SUPPORT
if(IFX_DECTAPP_isProprietaryList(ucListId) == IFX_SUCCESS ){
//Checking for whether requesting for TreeList/SubList/Sub-SubList fields....
if(pxListInfo -> nLevel == IFX_DT_LEVEL_TREE_LIST ){
		if(IFX_DT_Get_TreeList_EditUnEditFields(ucListId,pxOutCmd) != IFX_SUCCESS){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DT_Get_TreeList_EditUnEditFields> Failure....." );
    goto Fail;
  }

}else if(pxListInfo -> nLevel == IFX_DT_LEVEL_SUB_LIST ){
	if(IFX_DT_Get_SubList_EditUnEditFields(pxListInfo->ucListId,pxOutCmd) != IFX_SUCCESS){
  	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "<IFX_DT_Get_SubList_EditUnEditFields> Failure....." );
		goto Fail;
	}
}else{ 
	if(IFX_DT_Get_SubSubList_EditUnEditFields(pxListInfo->ucListId,pxOutCmd) != IFX_SUCCESS){
  	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "<IFX_DT_Get_SubList_EditUnEditFields> Failure....." );
		goto Fail;
	}

}
}
#endif
#ifdef LTQ_DT_SUPPORT
 else {
#endif	
if(!vacEditableFields[ucListId-1][0]){
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields = 0;
	}else{
	  pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields = vacEditableFields[ucListId-1][0];	
    memcpy(pxOutCmd->uxListCmd.xFieldQueryCfm.aucEditableFields,&vacEditableFields[ucListId-1][1],
				   vacEditableFields[ucListId-1][0]);
	 }	

	if(!vacUnEditableFields[ucListId-1][0]){
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields = 0;
	}else{
	  pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields = vacUnEditableFields[ucListId-1][0];	
    memcpy(pxOutCmd->uxListCmd.xFieldQueryCfm.aucUneditableFields,&vacUnEditableFields[ucListId-1][1],
				   vacUnEditableFields[ucListId-1][0]);
	 }	
#ifdef LTQ_DT_SUPPORT
}
#endif	
  pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_FIELD_QUERY_CFM;
  pxOutCmd->nSessionId = pxInCmd->nSessionId;

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "<IFX_DECTAPP_LAU_FieldQuery>Success" );
  return IFX_SUCCESS;

  Fail:
	 pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_NACK;
   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "<IFX_DECTAPP_LAU_FieldQuery>Field Query Failure!!" );
	 return IFX_FAILURE;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_ReadEntries
 *  Description     : This Api is a read request for a specific list determined by
 *                    the session.The read request specifies the start index and the 
 *                    number of requested list entries.The respective entries/subset of
 *                    the fields of these entries as available are sent in a separate 
 *                    data packet in sorted order with the sorting fields determined 
 *                    during Session start.
 *                    The confirmation for read request indicates the actual start 
 *                    index and the counter.    
 *  Input Values    : pxInCmd - It includes session id,start index,counter 
 *                    and list of requested entry field identifiers along with
 *                    mark entries request used to set/reset read status for the 
 *                    entries.
 *  Output Values   : pxOutCmd - FP sends the start index and actual counter of the
 *                    entries sent.           
 *  Return Value    : IFX_PROCESSED/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_LAU_ReadEntries(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                            OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd)
{
  uint32 uiSessHdl = 0;
  uchar8 ucAvailEntries = 0;
  x_IFX_DECT_ListInfo *pxListInfo = NULL;

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
	   "Entry" );

 if( NULL == pxOutCmd){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Invalid out parameters: pxOutCmd NULL " );
    return IFX_FAILURE;
  }

  if((NULL == pxInCmd) ){

    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_NORMAL, IFX_DBG_STR,
	           "Invalid Input Parameters: pxInCmd NULL." );
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
		goto Fail;
  }
  if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(pxInCmd->nSessionId,&uiSessHdl)){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "Invalid session Id." );
    goto Fail;
  }
  pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "Session ID =",pxInCmd->nSessionId);
  pxOutCmd->nSessionId = pxInCmd->nSessionId;

  if((pxInCmd->uxListCmd.xEntryReadReq.nStartIndex > pxListInfo->ucNoOfListEntries)||
     (pxInCmd->uxListCmd.xEntryReadReq.nStartIndex < 0)){
	
     pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_START_IDX;
     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	           "Invalid start index." );
		 goto Fail;
  }

     IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_INT,
	           "InCmd Start Index is.",pxInCmd->uxListCmd.xEntryReadReq.nStartIndex );
  switch(pxInCmd->uxListCmd.xEntryReadReq.nStartIndex){

     case IFX_DECTAPP_LASTENTRY:
     IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_INT,
	           "Request for Last entry arrived, the available entries are.", pxListInfo->ucNoOfListEntries );
 
	  ucAvailEntries = (pxInCmd->uxListCmd.xEntryReadReq.ucOrder == IFX_DECTAPP_DIR_FWD)?1:
                          pxListInfo->ucNoOfListEntries;
         pxOutCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries =
                                           ((pxInCmd->uxListCmd.xEntryReadReq.ucNoOfReqFields > ucAvailEntries) ?
                                             ucAvailEntries : pxInCmd->uxListCmd.xEntryReadReq.ucNoOfReqFields);
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "Reading From backwards." );
         pxOutCmd->uxListCmd.xEntryReadCfm.nStartIndex = (pxInCmd->uxListCmd.xEntryReadReq.ucOrder == IFX_DECTAPP_DIR_FWD)?
 pxListInfo->ucNoOfListEntries:(ucAvailEntries-pxOutCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries+1);
			break;
 
     default:

         ucAvailEntries = (pxInCmd->uxListCmd.xEntryReadReq.ucOrder == IFX_DECTAPP_DIR_FWD)?
                          (pxListInfo->ucNoOfListEntries -
                          pxInCmd->uxListCmd.xEntryReadReq.nStartIndex +1):
                          (pxInCmd->uxListCmd.xEntryReadReq.nStartIndex); 

         pxOutCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries = 
                          ((pxInCmd->uxListCmd.xEntryReadReq.ucNoOfReqFields > ucAvailEntries) ?
		                        ucAvailEntries : pxInCmd->uxListCmd.xEntryReadReq.ucNoOfReqFields);

         pxOutCmd->uxListCmd.xEntryReadCfm.nStartIndex = (pxInCmd->uxListCmd.xEntryReadReq.ucOrder == IFX_DECTAPP_DIR_FWD)?
                                                         pxInCmd->uxListCmd.xEntryReadReq.nStartIndex:
                                                         (pxInCmd->uxListCmd.xEntryReadReq.nStartIndex
                                                        -pxOutCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries+1);
         break; 
  }

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "nStartIndex=",pxOutCmd->uxListCmd.xEntryReadCfm.nStartIndex);
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "ucAvailEntries=",ucAvailEntries);
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "ucNoOfReqFields=",pxInCmd->uxListCmd.xEntryReadReq.ucNoOfReqFields);
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "ucNoOfDeliveredEntries=",pxOutCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries);
						
  pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_ENTRIES_READ_CFM;

  pxInCmd->uxListCmd.xEntryReadReq.nStartIndex = pxOutCmd->uxListCmd.xEntryReadCfm.nStartIndex;
  pxInCmd->uxListCmd.xEntryReadReq.ucNoOfReqFields = pxOutCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries;
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "ucMarkEntriesReq=",pxInCmd->uxListCmd.xEntryReadReq.ucMarkEntriesReq);

  if((0 == pxOutCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries)||
			((0 != pxInCmd->uxListCmd.xEntryReadReq.ucMarkEntriesReq)&&
		 (pxInCmd->uxListCmd.xEntryReadReq.aucFieldIdsList[0] == '\0'))){

     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_ReadEntries>Mark Entries Bit is non-zero with no field Ids/Delivered entries zero." );
     pxOutCmd->uxListCmd.xEntryReadCfm.nStartIndex = 0;
     pxOutCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries = 0;
  }
 
  if( pxListInfo->ucNoOfListEntries == 0){
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_START_IDX;
	goto Fail;
 }
 
 IFX_DECT_LAU_ConfirmationSend(pxOutCmd);
  if((pxOutCmd->uxListCmd.xEntryReadCfm.ucNoOfDeliveredEntries == 0)||
			(pxInCmd->uxListCmd.xEntryReadReq.aucFieldIdsList[0] == '\0')){
    
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_ReadEntries>No data packet to be sent." );
    return IFX_PROCESSED;
  }
//Checking for request type : is for TreeList/SubList/SubSubList Entries....
#ifdef LTQ_DT_SUPPORT
if(IFX_DECTAPP_isProprietaryList(pxListInfo->ucListId) == IFX_SUCCESS ) {
	if(pxListInfo -> nLevel ==  IFX_DT_LEVEL_TREE_LIST )
  {
      if(IFX_FAILURE == IFX_DECTAPP_ReadTreeList(pxListInfo->ucListId,
                                         pxListInfo->pxSortedList,
                                         pxInCmd)){

      pxOutCmd->eNackReason = pxInCmd->eNackReason;
      IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
               "<IFX_DECTAPP_ReadSubListEntries>IFX_DECTAPP_ReadSubList failed." );
      goto Fail;
    }

  }else	if(pxListInfo -> nLevel ==  IFX_DT_LEVEL_SUB_LIST )
	{
			if(IFX_FAILURE == IFX_DECTAPP_ReadSubList(pxListInfo->ucListId,
																					pxListInfo -> ucSubListId,
                                         pxListInfo->pxSortedList,
                                         pxInCmd)){

    	pxOutCmd->eNackReason = pxInCmd->eNackReason;
    	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
      	       "<IFX_DECTAPP_ReadSubListEntries>IFX_DECTAPP_ReadSubList failed." );
    	goto Fail;
  	}

	}else if( pxListInfo -> nLevel ==  IFX_DT_LEVEL_SUB_SUBLIST ){
				if(IFX_FAILURE == IFX_DECTAPP_ReadSubSubList(pxListInfo->ucListId,
                                          pxListInfo -> ucSubListId,
                                         pxListInfo->pxSortedList,
                                         pxInCmd)){
    				pxOutCmd->eNackReason = pxInCmd->eNackReason;
				    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        	     "<IFX_DECTAPP_ReadSubSubListEntries>IFX_DECTAPP_ReadSubSubList failed." );
				    goto Fail;
  			}

}
}else 
#endif
if(IFX_FAILURE == IFX_DECTAPP_ReadList(pxListInfo->ucListId,
				                                 pxListInfo->pxSortedList, 
                                         pxInCmd)){

    pxOutCmd->eNackReason = pxInCmd->eNackReason;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_ReadEntries>IFX_DECTAPP_ReadList failed." );
		goto Fail;
  }
  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "Processed." );
  return IFX_PROCESSED;
 Fail:
   pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_NACK;
   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "Read Entries Failure!!" );
	 return IFX_FAILURE;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_SearchEntries
 *  Description     : The Api is a search request from the PP for a range of entries
 *                    that match the search criteria constituted by search string
 *                    and matching option(exact match or near match).Moreover,the 
 *                    counter specifies the range and the order.The corresponding
 *                    entries are sent in a separate data packet.
 *  Input Values    : pxInCmd - It indicates the search string and matching option
 *                    along with the counter,mark entries request and field identifiers
 *  Output Values   : pxOutCmd - The FP sends the start index and the number of entries
 *                    that match the search criteria 
 *  Return Value    : IFX_PROCESSED/ IFX_FAILURE
 *  Notes           :
****************************************************************************/
e_IFX_Return 
   IFX_DECTAPP_LAU_SearchEntries(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                 OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){

   uint32 uiSessHdl = 0;
   x_IFX_DECT_ListInfo *pxListInfo = NULL;

   IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<IFX_DECTAPP_LAU_SearchEntries>Entry");

 if( NULL == pxOutCmd){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Invalid out parameters: pxOutCmd NULL " );
    return IFX_FAILURE;
  }

   if((NULL == pxInCmd)){

     IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<IFX_DECTAPP_LAU_SearchEntries>Invalid input parameters: pxInCmd NULL.");
     pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
	 	 goto Fail;
   }
   if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(pxInCmd->nSessionId,&uiSessHdl)){

     pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
     IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
            "<IFX_DECTAPP_LAU_SearchEntries>Invalid Session ID.");
     goto Fail; 
   }
   pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;
   IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
            "<IFX_DECTAPP_LAU_SearchEntries>Session ID=",pxInCmd->nSessionId);
			   
   if(IFX_FAILURE == IFX_DECTAPP_SearchList(pxListInfo->nSessId,
                                           pxListInfo->ucListId,
																					 pxListInfo->pxSortedList,
                                           pxInCmd)){

     pxOutCmd->eNackReason = pxInCmd->eNackReason;
     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_LAU_SearchEntries>IFX_DECTAPP_SearchList failed" );
     goto Fail;
   }

   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_LAU_SearchEntries>Processed." );
   return IFX_PROCESSED;

   Fail:
     pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_NACK;
     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_LAU_SearchEntries>Search Entries Failure!!" );
     return IFX_FAILURE;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_EditEntries
 *  Description     : This Api is an edit request for an entry of a list from the 
 *                    PP.The PP sends the entry identifier of the entry along with 
 *                    a list of field identifiers that he intends to edit.The FP 
 *                    sends the corresponding entry in separate data packet.  
 *  Input Values    : pxInCmd - It contains entry identifer of the entry to be 
 *                    editted,session Identifier and the list of field identifiers.
 *  Output Values   : pxOutCmd - The FP sends the session identifier to confirm the 
 *                    entry is available.
 *                    The contents of the corresponding entry are sent in a separate 
 *                    data packet. 
 *  Return Value    : IFX_PROCESSED/ IFX_FAILURE
 *  Notes           : No error is reported if a non-editable field is requested via
 *                    edit entry request.
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_LAU_EditEntries(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                            OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){


  uint32 uiSessHdl = 0;
  uint32 uiTempSessHdl;
  uint32 i = 0;
  uchar8 *pnField = NULL;
  x_IFX_DECT_ListInfo *pxListInfo = NULL;

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "Entry." );
 if( NULL == pxOutCmd){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Invalid out parameters: pxOutCmd NULL " );
    return IFX_FAILURE;
  }


  if(NULL == pxInCmd){

    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "Invalid input parameters: pxInCmd" );
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
		goto Fail;
  }
  if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(pxInCmd->nSessionId,&uiSessHdl)){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "Invalid Session Id." );
    goto Fail;
  }
  pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
             "Session ID=",pxInCmd->nSessionId);

if(IFX_DECTAPP_IsListIdValid(pxListInfo->ucListId) !=IFX_SUCCESS ){
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
             "Invalid List Id",pxListInfo->ucListId);
  goto Fail;
  }


  if(IFX_FAILURE == IFX_DECTAPP_AllowEditSave(pxListInfo->ucListId)){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "IFX_DECTAPP_AllowEditSave failed." );
		goto Fail;
  }

  /*Checking if Entry is unlocked.If yes,lock it.*/

  for(i = 0; i<IFX_DECTAPP_MAX_DECT_ENDPTS ;i++){
    if((vnListLock[(pxListInfo->ucListId)-1][i] != 0) &&
      (IFX_FAILURE != IFX_DECTAPP_ValidateSessionId(vnListLock[(pxListInfo->ucListId)-1][i],&uiTempSessHdl))){
      IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "List is locked by another session." );
      if( pxInCmd->uxListCmd.xEntryEditReq.nEntryId == ((x_IFX_DECT_ListInfo *)uiTempSessHdl)->nEntryId){

        IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Entry is locked.Can't Edit." );
        pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
		  pxListInfo->uiFlags =2;
				goto Fail;
      }
    }
  }
  
  pxListInfo->uiFlags =0;
  printf("\n Entry Lock during edit.\n");
  printf("vnListLock[%d][%d]=%d\n",pxListInfo->ucListId-1,(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS,pxListInfo->nSessId);
  vnListLock[(pxListInfo->ucListId)-1][(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS] 
                 = pxListInfo->nSessId;

  /*Store Fields requested during edit.*/

  pnField = pxInCmd->uxListCmd.xEntryEditReq.aucFieldIdsList;
  while(*pnField != '\0'){
     pxListInfo->unFieldIds |= (uchar8)1 << ((*pnField)-1);
     pnField++;
  }

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
             "Entry ID=",pxInCmd->uxListCmd.xEntryEditReq.nEntryId);

  if(IFX_FAILURE == IFX_DECTAPP_EditList(pxListInfo->ucListId,
																				 pxListInfo->pxSortedList,
                                         &pxListInfo->nPositionId, 
                                         pxInCmd)){
 
    pxOutCmd->eNackReason = pxInCmd->eNackReason;
    printf("\n Free lock on edit fail.\n");
    vnListLock[(pxListInfo->ucListId)-1][(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS] = 0;
    printf("vnListLock[%d][%d]=%d\n",pxListInfo->ucListId-1,(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS,0);
		pxListInfo->unFieldIds = 0;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "IFX_DECTAPP_EditList failed." );
    goto Fail;
  }

  pxListInfo->nEntryId = pxInCmd->uxListCmd.xEntryEditReq.nEntryId;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
             "Entry ID=",pxListInfo->nEntryId);

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
             "Position ID=",pxListInfo->nPositionId);

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Processed." );
  return IFX_PROCESSED;

  Fail:
   pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_NACK;
   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
            "Edit Entries Failure!!" );
	 return IFX_FAILURE;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_SaveEntry
 *  Description     : This Api is a request from PP to save a new entry or a 
 *                    previously editted entry in the FP.PP sends the entry 
 *                    identifier, which is 0 in case of a new entry.
 *  Input Values    : pxInCmd - It contains the entry identifier.
 *  Output Values   : pxOutCmd - The FP needs to send the entry identifier,position
 *                    index of the entry with respect to the sorted list and the total
 *                    number of available entries to PP.
 *  Return Value    : IFX_PROCESSED/ IFX_FAILURE
 *  Notes           : The Save Confirmation is sent after receiving the contents
 *                    of the entry. 
 ****************************************************************************/
e_IFX_Return IFX_DECTAPP_LAU_SaveEntry(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                                       OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){

  uint32 uiSessHdl = 0;
  x_IFX_DECT_ListInfo *pxListInfo = NULL;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "Entry.");

 if( NULL == pxOutCmd){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Invalid out parameters: pxOutCmd NULL " );
    return IFX_FAILURE;
  }


  if(NULL == pxInCmd){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Invalid Input Parameters: pxInCmd/pxOutCmd NULL.");
		goto Fail;
  }
  if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(pxInCmd->nSessionId,&uiSessHdl)){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Invalid Session Id.");
		return IFX_FAILURE;
  }
  pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;
	if(pxListInfo == NULL){
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Invalid Session Id.");
		return IFX_FAILURE;
	}
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
               "Session ID=",pxInCmd->nSessionId);
 
  if( pxListInfo->uiFlags ==2){
     pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "IFX_DECTAPP_AllowEditSave failed." );
	     pxListInfo->uiFlags =0;
		 goto Fail;
  } 
  if(IFX_FAILURE == IFX_DECTAPP_AllowEditSave(pxListInfo->ucListId)){

     pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "IFX_DECTAPP_AllowEditSave failed." );
		 goto Fail;
  }
  
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           "EntryId during Save",
           pxInCmd->uxListCmd.xEntrySaveReq.nEntryId );

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_INT,
           "EntryId during Edit",
           pxListInfo->nEntryId );

  if(pxInCmd->uxListCmd.xEntrySaveReq.nEntryId != pxListInfo->nEntryId){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Entry ID different from previous Edit.Not allowed!" );
		goto Fail;
  }

	if(pxInCmd->uxListCmd.xEntrySaveReq.nEntryId != 0){
   if(IFX_FAILURE == IFX_DECTAPP_VerifyEditable(pxListInfo->ucListId,pxListInfo->unFieldIds)){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "IFX_DECTAPP_VerifyEditable failed." );
		goto Fail;
   }
	} 
  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Processed." );

  pxListInfo->uiFlags =0;
  return IFX_PROCESSED;

  Fail:
   pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_NACK;
			if(pxListInfo != NULL)
			pxListInfo->uiFlags = 1;
   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Save Entry Failure!!" );
	 return IFX_FAILURE;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_DataRecv
 *  Description     : This Api specifies that FP has received the editted entry 
 *                    or new entry contents.Some of the fields might need to be 
 *                    reset if the field length is 1.Only the fields indicated as 
 *                    editable are saved,rest are ignored by FP.If only a subset
 *                    of the fields requested during edit are changed,the rest 
 *                    of the fields remain unchanged in FP.
 *  Input Values    : uiSessId - Session Identifier
 *                    unDataLen - length of the entry contents
 *                    pucData - entry contents
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           : 1.The fields sent here might be a subset of the field list
 *                    sent during edit.
 *                    2.An empty 'last data packet' following save request indicates
 *                    that a previosly started edit procedure is aborted.  
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_LAU_DataRecv(IN uint32 uiSessId,
                         IN uint16 unDataLen,
                         IN uchar8* pucData)
{
  uint32 uiSessHdl = 0;
  x_IFX_DECT_LAU_ListCommands xOutCmd = {0}; 
  x_IFX_DECT_LAU_ListCommands xInCmd = {0}; 
  x_IFX_DECT_ListInfo *pxListInfo = NULL; 

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Entry." );

  if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(uiSessId,&uiSessHdl)){

    xOutCmd.eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Invalid Session Id." );
    return IFX_FAILURE;
  }
  pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;

 if(pxListInfo == NULL){
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "Invalid Session Id.");
    return IFX_FAILURE;
  }
 
 if(pxListInfo->uiFlags==1){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "SaveEntry request was rejected fro some reason." );
	 pxListInfo->uiFlags =0;
    return IFX_PROCESSED;
  }
  if((*pucData == '\0')&&(pxListInfo->nPositionId)){//Previous Edit Aborted.

    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                "Previous Edit Aborted." );

  xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_ENTRY_SAVE_CFM;
  xOutCmd.nSessionId = uiSessId;
  xOutCmd.uxListCmd.xEntrySaveCfm.nEntryId =  pxListInfo->nEntryId;
  xOutCmd.uxListCmd.xEntrySaveCfm.nPostionIndex = pxListInfo->nPositionId;
  xOutCmd.uxListCmd.xEntrySaveCfm.nAvailEntries = pxListInfo->ucNoOfListEntries;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "NoOfListEntries",pxListInfo->ucNoOfListEntries);
  IFX_DECT_LAU_ConfirmationSend(&xOutCmd);

	 pxListInfo->nEntryId = 0;
    pxListInfo->nPositionId = 0;

    /*Free lock.*/
    vnListLock[(pxListInfo->ucListId)-1][(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS] = 0;
    /*printf("vnListLock[%d][%d]=%d\n",
				pxListInfo->ucListId-1,(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS,0);*/
    return IFX_PROCESSED;
  }
  xInCmd.nSessionId = (int16)uiSessId;
  xInCmd.uxListCmd.xEntrySaveReq.nEntryId = pxListInfo->nEntryId;

	vucNotifyIgnore[pxListInfo->ucListId-1] = (uiSessId-1)/IFX_DECT_LAU_MAX_SESS_PER_HS +1;

  if(IFX_FAILURE == IFX_DECTAPP_SaveList(pxListInfo->ucListId,
                                         &pxListInfo->nPositionId,
																				 pxListInfo->pxSortedList,
																				 &pxListInfo->unFieldIds,
                                         unDataLen,
                                         pucData,      
                                         &xInCmd)){

    xOutCmd.eNackReason = xInCmd.eNackReason;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                       "SaveList failed." );
    /*Free lock.*/
    //printf("\n Free LOCk when entry save failed.\n"); 
    vnListLock[(pxListInfo->ucListId)-1][(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS] = 0;
    //printf("vnListLock[%d][%d]=%d\n",pxListInfo->ucListId-1,(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS,0);
    goto Fail;
  }

  if(!pxListInfo->nEntryId){
		/*Since Entry may be added in more than one line*/
		if(IFX_DECT_LAU_CONTACT_LIST == pxListInfo->ucListId) {
			pxListInfo->ucNoOfListEntries = 
				((x_IFX_DECT_LAU_ContactList*)pxListInfo->pxSortedList)->unNoOfEntries;
			/*printf("<DataPktRcv>AfterSave Contact: NoOfEntires = %d\n",
								pxListInfo->ucNoOfListEntries);*/
		}
		else {
    ++pxListInfo->ucNoOfListEntries;
		}
  }

	system("/etc/rc.d/backup");/* Write to rc.conf. */

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "Entry ID=",xInCmd.uxListCmd.xEntrySaveReq.nEntryId);
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "Position ID=",pxListInfo->nPositionId);

  pxListInfo->nEntryId = xInCmd.uxListCmd.xEntrySaveReq.nEntryId;

  xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_ENTRY_SAVE_CFM;
  xOutCmd.nSessionId = uiSessId;
  xOutCmd.uxListCmd.xEntrySaveCfm.nEntryId = xInCmd.uxListCmd.xEntrySaveReq.nEntryId;
  xOutCmd.uxListCmd.xEntrySaveCfm.nPostionIndex = pxListInfo->nPositionId;
  xOutCmd.uxListCmd.xEntrySaveCfm.nAvailEntries = pxListInfo->ucNoOfListEntries;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "pxListInfo->ucNoOfListEntries",pxListInfo->ucNoOfListEntries);
  IFX_DECT_LAU_ConfirmationSend(&xOutCmd);

  pxListInfo->nEntryId = 0;
  pxListInfo->nPositionId = 0;

  /*Free lock.*/
  printf("\n Free LOCk when entry saved.\n"); 
  vnListLock[(pxListInfo->ucListId)-1][(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS] = 0;
  printf("vnListLock[%d][%d]=%d\n",pxListInfo->ucListId-1,(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS,0);

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "Processed." );
  return IFX_PROCESSED;

  Fail:
	 xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_NACK;
   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                       "DataRecv Failure!!" );
	IFX_DECT_LAU_NackSend(pxListInfo->nSessId,xOutCmd.eNackReason);
	 return IFX_PROCESSED;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_EntryDelete
 *  Description     : This Api is a request from the PP to delete an entry in 
 *                    the list specified by the entry identifier.Delete entry 
 *                    is not allowed for "DECT System Settings List" 
 *  Input Values    : pxInCmd - It contains the entry identifier of the entry to 
 *                    be deleted 
 *  Output Values   : pxOutCmd - This indicates the total number of available 
 *                    entries after deletion
 *  Return Value    : IFX_PROCESSED/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_LAU_EntryDelete(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                           OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd)
{

  uint32 uiSessHdl = 0;
  uint32 uiTempSessHdl = 0;
  uint32 i = 0;
  x_IFX_DECT_ListInfo *pxListInfo = NULL;

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Entry." );

 if( NULL == pxOutCmd){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Invalid out parameters: pxOutCmd NULL " );
    return IFX_FAILURE;
  }

  if(NULL == pxInCmd ){

    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Invalid Input Parameters: pxInCmd NULL." );
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
		goto Fail;
  }
  if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(pxInCmd->nSessionId,&uiSessHdl)){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Invalid Session Id." );
    goto Fail;
  }
  pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;
  
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "Session ID=",pxInCmd->nSessionId);
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "Entry ID=",pxInCmd->uxListCmd.xEntryDeleteReq.nEntryId);

  /*Checking if Entry is unlocked.*/

  for(i = 0; i<IFX_DECTAPP_MAX_DECT_ENDPTS ;i++){
    if(vnListLock[(pxListInfo->ucListId)-1][i] &&
      (IFX_FAILURE != IFX_DECTAPP_ValidateSessionId(vnListLock[(pxListInfo->ucListId)-1][i],&uiTempSessHdl))){
      if(pxInCmd->uxListCmd.xEntryDeleteReq.nEntryId == ((x_IFX_DECT_ListInfo *)uiTempSessHdl)->nEntryId){

        IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Entry is locked.Can't delete it!" );
        pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
				goto Fail;
      }
    }
  } 

  if(IFX_DECT_LAU_SYS_SETTINGS == pxListInfo->ucListId){

     pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "IFX_DECTAPP_AllowDeleteEntry failed" );
		 goto Fail;
  }
	vucNotifyIgnore[pxListInfo->ucListId-1] = (pxListInfo->nSessId-1)/IFX_DECT_LAU_MAX_SESS_PER_HS +1;

  if(IFX_FAILURE == IFX_DECTAPP_DeleteListEntry(pxListInfo->ucListId,
				                                        pxListInfo->pxSortedList,
                                                pxInCmd)){
    
		pxOutCmd->eNackReason = pxInCmd->eNackReason;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "IFX_DECTAPP_DeleteListEntry failed" );
		goto Fail;
  }

	system("/etc/rc.d/backup");/* Write to rc.conf */

  --pxListInfo->ucNoOfListEntries;
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
           "ucNoOfListEntries=",pxListInfo->ucNoOfListEntries);
  
  pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_ENTRY_DELETE_CFM;
  pxOutCmd->nSessionId = pxInCmd->nSessionId;
  pxOutCmd->uxListCmd.xEntryDeleteCfm.nAvailEntries = pxListInfo->ucNoOfListEntries;

  IFX_DECT_LAU_ConfirmationSend(pxOutCmd);
  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Processed." );
  return IFX_PROCESSED;

  Fail:
   pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_NACK;
   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Entry Delete Failure." );
	 return IFX_FAILURE;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_ListDelete
 *  Description     : This Api is a request from PP to delete all the entries in
 *                    the list specified by the session identifier. 
 *  Input Values    : pxInCmd - It contains the session identifier.
 *  Output Values   : pxOutCmd - The confirmation is sent to PP,by sending the
 *                    session identifier 
 *  Return Value    : IFX_PROCESSED/ IFX_FAILURE
 *  Notes           : Delete list operation is not allowed in case of "Line
 *                    Settings List" and "DECT System settings List"
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_LAU_ListDelete(IN x_IFX_DECT_LAU_ListCommands *pxInCmd,
                           OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){

  uint32 uiSessHdl;
  x_IFX_DECT_ListInfo *pxListInfo = NULL;	
  uchar8 ucHandSetId = 0;
  int32 i=0;
  uint32 uiTempSessHdl=0;			  
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	               "Entry." );
 
	if( NULL == pxOutCmd){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
              "Invalid out parameters: pxOutCmd NULL " );
    return IFX_FAILURE;
  }


  if(NULL == pxInCmd ){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	               "Invalid Input parameters: pxInCmd/pxOutCmd NULL." );
		goto Fail;
  }

  /* Validate SessionId */
  if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(pxInCmd->nSessionId,&uiSessHdl)){

    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_INVALID_SESS_NUM;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	               "Invalid session Id." );
    goto Fail;
  }
  pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;
	
	if(IFX_DECTAPP_IsListIdValid(pxListInfo->ucListId) != IFX_SUCCESS ){
 
	 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
             "Invalid List Id",pxListInfo->ucListId);
  goto Fail;
  }

	
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
             "<ListDelete>Session ID=",pxInCmd->nSessionId);
			 
  /* Confirm if list can be deleted.*/
  if((pxListInfo->ucListId == IFX_DECT_LAU_SYS_SETTINGS)||
     (pxListInfo->ucListId == IFX_DECT_LAU_LINE_SETTINGS)||
		 (pxListInfo->ucListId == IFX_DECT_LAU_INTERNAL_NAMES)){
											   
     pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	            "Can't perform delete operation on list!" );
     goto Fail;
  }
	
  /*Checking if Entry is unlocked.*/
  for(i = 0; i<IFX_DECTAPP_MAX_DECT_ENDPTS ;i++){
    if(vnListLock[(pxListInfo->ucListId)-1][i] &&
      (IFX_FAILURE != IFX_DECTAPP_ValidateSessionId((uint16)vnListLock[(pxListInfo->ucListId)-1][i],&uiTempSessHdl))){

        IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
             "Entry is locked.Can't delete it!" );
        pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
		  goto Fail;
    }
  } 

  pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_LIST_DELETE_CFM;
  pxOutCmd->nSessionId = pxInCmd->nSessionId;
  IFX_DECT_LAU_ConfirmationSend(pxOutCmd); 

	/* During Notification,ignore this Handset. */
	vucNotifyIgnore[pxListInfo->ucListId-1] = (pxListInfo->nSessId-1)/IFX_DECT_LAU_MAX_SESS_PER_HS +1;
	ucHandSetId = ((pxListInfo->nSessId-1)/IFX_DECT_LAU_MAX_SESS_PER_HS)+1;
	if(ucHandSetId && ucHandSetId <= IFX_DECTAPP_MAX_DECT_ENDPTS){
  if(IFX_FAILURE == IFX_DECTAPP_DeleteList(pxListInfo->ucListId,
										&vacAssocLines[ucHandSetId-1][0],pxListInfo->pxSortedList)){
		
    pxOutCmd->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	           "IFX_DECTAPP_DeleteList failed." );
    goto Fail;
  }
}
	system("/etc/rc.d/backup");/* Write to rc.conf */
	pxListInfo->ucNoOfListEntries = 0;

  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	         "Processed." );
  return IFX_PROCESSED;
 
  Fail:
   pxOutCmd->ucListCmd = IFX_DECT_LAU_CMD_NACK;
   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	               "List Delete Failure." );
	 return IFX_FAILURE;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_SessionEnd
 *  Description     : This Api is a request from the PP to end the session
 *                    determined by the specified session identifier.All
 *                    session related info is freed.
 *  Input Values    : nSessId - Session Identifier
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           : Rejection of End Session request shall not be possible 
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_LAU_SessionEnd(IN int16 nSessId)
{

   uint32 uiSessHdl = 0;
   x_IFX_DECT_ListInfo *pxListInfo = NULL;

   IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	            "<IFX_DECTAPP_LAU_SessionEnd>Entry." );

   if(IFX_FAILURE == IFX_DECTAPP_ValidateSessionId(nSessId,&uiSessHdl)){

     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	            "<IFX_DECTAPP_LAU_SessionEnd>Invalid Session Id.Ignore." );
     return IFX_PROCESSED; 
   }
   pxListInfo = (x_IFX_DECT_ListInfo *)uiSessHdl;

   /* Free list lock */
   printf("\n Free Lock on Session End\n");
   vnListLock[(pxListInfo->ucListId)-1][(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS] = 0;
   //printf("vnListLock[%d][%d]=%d\n",pxListInfo->ucListId-1,(pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS,0);

   /* Free ListInfo structure */
	 free(pxListInfo->pxSortedList);
   memset(pxListInfo,0,sizeof(x_IFX_DECT_ListInfo));

   IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
	            "<IFX_DECTAPP_LAU_SessionEnd>Session End Success." );
   return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_ReadList
 *  Description     : This internal Api reads the entries stored in FP and sends
 *                    them to be displayed by PP. 
 *  Input Values    : ucListId - List Identifier
 *                    pxSortedList - pointer to Sorted List
 *                    pxReadList - It contains read info such as start index,
 *                    counter,mark entries request required for fetching the
 *                    entries.
 *  Output Values	  : pxReadList - NACK reason ,if any, is sent back.
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           : In case of Missed call list/All Incoming calls list,
 *                    with non-zero mark entries request and empty subset of field
 *                    identifiers ,only the read status of the read entries is 
 *                    changed(set/reset) and no data packet is sent subsequetly.
 ****************************************************************************/

e_IFX_Return IFX_DECTAPP_ReadList(IN uchar8 ucListId,
                                  IN void *pxSortedList,
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxReadList){

  void *pvPayload = NULL;
  uchar8 *pucDataPayload = NULL, aucLineIdList[IFX_DECTAPP_MAX_LINES] = {0};
  uint16 unPayldSize = 0;
  int32 i=0,j=0;
  boolean bOldReadStatus = 0;
 
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DECTAPP_ReadList>Entry");
	printf("<ReadList>Entry ***** \n");
  if(NULL == pxSortedList){
    return IFX_SUCCESS;//Ask??
  }
  switch(ucListId){

   case IFX_DECT_LAU_MISSED_CALLS:
   {
       x_IFX_DECT_LAU_MissedCallList xMissedCallList = {0};
       x_IFX_DECT_LAU_MissedCallList *pxMissedCallList = NULL;
       x_IFX_DECT_LAU_MissedCallList xTempMissedCallList = {0};
       x_IFX_DECT_LAU_MissedCallList xMissedCall = {0};
       boolean bReadStatus = 1; 

       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DECTAPP_ReadList>Read MissedCall List");

			 pxMissedCallList = (x_IFX_DECT_LAU_MissedCallList*)pxSortedList;
       switch(pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq){

          case 0/*Leave Unchanged*/:
              break;

          case 0x7F/*Mark as Read*/:
              bReadStatus = 0;
              break;

          case 0xFF/*Mark as UnRead*/:
              bReadStatus = 1;
              break;

       }
       
       xMissedCallList.cNoOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
       if(xMissedCallList.cNoOfEntries > 0 && xMissedCallList.cNoOfEntries <= IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES &&  pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 >= 0  && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 < IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES)
				memcpy(&xMissedCallList.axMissedCallList,
              &pxMissedCallList->axMissedCallList[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
              sizeof(x_IFX_DECT_LAU_MissedCallListEntry)*xMissedCallList.cNoOfEntries);

       if(pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq != 0){
         IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Mark Entries is non-zero.");

         xTempMissedCallList.cNoOfEntries = xMissedCallList.cNoOfEntries;
				if(xTempMissedCallList.cNoOfEntries > 0 && xTempMissedCallList.cNoOfEntries <= IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES )
				 memcpy(&xTempMissedCallList.axMissedCallList[0],&xMissedCallList.axMissedCallList[0],
							   sizeof(x_IFX_DECT_LAU_MissedCallListEntry)*xTempMissedCallList.cNoOfEntries);
         for(i=0;i<xTempMissedCallList.cNoOfEntries;i++){
           if(xTempMissedCallList.axMissedCallList[i].bNew ^ bReadStatus){
             aucLineIdList[(xTempMissedCallList.axMissedCallList[i].ucLineId)-1] += 1;
           }
         }
         
         for(i=0;i<xTempMissedCallList.cNoOfEntries;i++){
           bOldReadStatus = xTempMissedCallList.axMissedCallList[i].bNew;
           xTempMissedCallList.axMissedCallList[i].bNew = bReadStatus;
           memcpy(&xMissedCall.axMissedCallList,&xTempMissedCallList.axMissedCallList[i],
                  sizeof(x_IFX_DECT_LAU_MissedCallListEntry));
           xMissedCall.cNoOfEntries = 1;
           if(aucLineIdList[(xTempMissedCallList.axMissedCallList[i].ucLineId)-1] == 1){
             vucMissCallReadStatusNtfyFlag = 1;
           }else if(bOldReadStatus ^ bReadStatus){
             aucLineIdList[(xTempMissedCallList.axMissedCallList[i].ucLineId)-1] -= 1;
             vucMissCallReadStatusNtfyFlag = 0;
           }else{
             vucMissCallReadStatusNtfyFlag = 0;
           }
           if(bOldReadStatus ^ bReadStatus){
             if(IFX_FAILURE == IFX_CIF_MissedCallListSet(xMissedCall.axMissedCallList[0].ucLineId,
                                                         &xMissedCall,IFX_DECTAPP_MODIFY)){
               IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                        "<IFX_DECTAPP_ReadList>IFX_CIF_MissedCallListSet failed.");
               pxReadList->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
               return IFX_FAILURE;
             }
           }
           memset(&xMissedCall,0,sizeof(x_IFX_DECT_LAU_MissedCallList));
         }

				 i = pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1;
         for(;j<=xTempMissedCallList.cNoOfEntries;i++,j++){
           pxMissedCallList->axMissedCallList[i].bNew = bReadStatus;
         }
         IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>MarkEntries bit is zero.");
       }
       pvPayload = (void *)&xMissedCallList; 
   }
   break;
      
   case IFX_DECT_LAU_OUTGOING_CALLS:
   {
       x_IFX_DECT_LAU_OutgoingCallList xOutgoingCallList={0};

       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Read Outgoing Call List.");
       xOutgoingCallList.cNoOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
			if(xOutgoingCallList.cNoOfEntries > 0 && xOutgoingCallList.cNoOfEntries <= IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES &&  pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 >= 0  && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 < IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES )
       memcpy(&xOutgoingCallList.axOutgoingCallList[0],
              &((x_IFX_DECT_LAU_OutgoingCallList*)pxSortedList)->axOutgoingCallList[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
              sizeof(x_IFX_DECT_LAU_OutgoingCallListEntry)*xOutgoingCallList.cNoOfEntries);

       pvPayload = (void *)&xOutgoingCallList; 
   }
   break;

   case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:
   {
       x_IFX_DECT_LAU_IncomingCallList xIncomingCallList={0};

       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Read Incoming Call List.");
       xIncomingCallList.cNoOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
				if(xIncomingCallList.cNoOfEntries > 0 && xIncomingCallList.cNoOfEntries <= IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES &&  pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 >= 0  && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 < IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES)
       memcpy(&xIncomingCallList.axIncomingCallList[0],
              &((x_IFX_DECT_LAU_IncomingCallList*)pxSortedList)->axIncomingCallList[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
              sizeof(x_IFX_DECT_LAU_IncomingCallListEntry)*xIncomingCallList.cNoOfEntries);

       pvPayload = (void *)&xIncomingCallList; 
   }
   break;
     
   case IFX_DECT_LAU_ALL_CALLS:
   {
       x_IFX_DECT_LAU_AllCallList xAllCallList = {0};

       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Read All Call List.");
       xAllCallList.cNoOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
      if(xAllCallList.cNoOfEntries > 0 && xAllCallList.cNoOfEntries <=  IFX_DECT_LAU_MAX_ALL_CALL_LIST_ENTRIES && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1>=0 && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 <= IFX_DECT_LAU_MAX_ALL_CALL_LIST_ENTRIES)
				memcpy(&xAllCallList.axAllCallList[0],
                &((x_IFX_DECT_LAU_AllCallList*)pxSortedList)->axAllCallList[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
                sizeof(x_IFX_DECT_LAU_AllCallListEntry)*xAllCallList.cNoOfEntries);

       pvPayload = (void *)&xAllCallList; 
   }
   break;
        
   case IFX_DECT_LAU_ALL_INCOMING_CALLS:
   {   
       x_IFX_DECT_LAU_AllIncomingCallList xAllIncomingCallList = {0};
       x_IFX_DECT_LAU_AllIncomingCallList *pxAllIncomingCallList = NULL;
       x_IFX_DECT_LAU_MissedCallList xMissedCallList = {0};
       boolean bReadStatus = 1;
       
       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Read Incoming Call List.");
			 pxAllIncomingCallList = (x_IFX_DECT_LAU_AllIncomingCallList*)pxSortedList;
       switch(pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq){

          case 0/*Leave Unchanged*/:
              break;

          case 0x7F/*Mark as Read*/:
              bReadStatus = 0;
              break;

          case 0xFF/*Mark as UnRead*/:
              bReadStatus = 1;
              break;

       }
       xAllIncomingCallList.cNoOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
			if(xAllIncomingCallList.cNoOfEntries > 0 && xAllIncomingCallList.cNoOfEntries <=IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES &&  pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 >= 0  && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 < IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES)
       memcpy(&xAllIncomingCallList.axAllIncomingCallList[0],
					    &pxAllIncomingCallList->axAllIncomingCallList[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
              sizeof(x_IFX_DECT_LAU_AllIncomingCallListEntry)*xAllIncomingCallList.cNoOfEntries);

       if(pxReadList->uxListCmd.xEntryReadReq.ucMarkEntriesReq != 0){

         for(i=0;i<xAllIncomingCallList.cNoOfEntries;i++){

          switch(xAllIncomingCallList.axAllIncomingCallList[i].bNew){

            case 0xFF:

                xAllIncomingCallList.axAllIncomingCallList[i].ucNoOfCalls = 1;
                xAllIncomingCallList.axAllIncomingCallList[i].bNew = 0;
                break;

            default:
                printf("Missed Call List and the status is %d\n",
							 xAllIncomingCallList.axAllIncomingCallList[i].bNew);
                //xAllIncomingCallList.axAllIncomingCallList[i].bNew = bReadStatus;
                IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
                  "Missed Call List and the status is", xAllIncomingCallList.axAllIncomingCallList[i].bNew);
               	if(i>=0 && j>=0 && i < IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES && j < IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES){
								  memcpy(&xMissedCallList.axMissedCallList[j],
                       &xAllIncomingCallList.axAllIncomingCallList[i],
                       sizeof(x_IFX_DECT_LAU_AllIncomingCallListEntry));
					 xMissedCallList.axMissedCallList[j].bNew = bReadStatus;
								xMissedCallList.cNoOfEntries = ++j;
						}
                break;
          }
         }
         if(xMissedCallList.cNoOfEntries){
          
           for(i=0;i<xMissedCallList.cNoOfEntries;i++){

             for(j = 0;j < pxAllIncomingCallList->cNoOfEntries;j++){
               if(xMissedCallList.axMissedCallList[i].nEntryId == pxAllIncomingCallList->axAllIncomingCallList[j].nEntryId){
 
                  pxAllIncomingCallList->axAllIncomingCallList[j].bNew = bReadStatus;
						      break;
               }
             }
             if(IFX_FAILURE == IFX_CIF_MissedCallListSet(xMissedCallList.axMissedCallList[i].ucLineId,
                                                         &xMissedCallList,IFX_DECTAPP_MODIFY)){

              IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>IFX_CIF_MissedCallListSet failed.");
              pxReadList->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
              return IFX_FAILURE;
             }
           }
				 }	 
       }
     pvPayload = (void *)&xAllIncomingCallList; 
   }
   break;

   case IFX_DECT_LAU_CONTACTS:
   {    
       x_IFX_DECT_LAU_ContactList xContactList = {0}; 

       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           "<IFX_DECTAPP_ReadList>Read Contact List");
				printf("<ReadList> Contact List Entry ***** \n");
       xContactList.unNoOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
			if(xContactList.unNoOfEntries > 0 && xContactList.unNoOfEntries <=IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES &&  pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 >= 0  && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 < IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES)
       memcpy(&xContactList.axContactList[0],
             &((x_IFX_DECT_LAU_ContactList*)pxSortedList)->axContactList[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
             sizeof(x_IFX_DECT_LAU_ContactListEntry)*xContactList.unNoOfEntries);

       pvPayload = (void *)&xContactList; 
   }
   break;

   case IFX_DECT_LAU_LINE_SETTINGS:
   {
       x_IFX_DECT_LAU_LineSettingsList xLineSetList={0};

       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Read Line Settings List.");
			 xLineSetList.ucNoOfLines = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
		if( pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 >=0 && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 < IFX_DECT_LAU_MAX_LINES && xLineSetList.ucNoOfLines >0 && xLineSetList.ucNoOfLines<=IFX_DECT_LAU_MAX_LINES)
			 memcpy(&xLineSetList.axLineEntry[0],
              &((x_IFX_DECT_LAU_LineSettingsList*)pxSortedList)->axLineEntry[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
              sizeof(x_IFX_DECT_LAU_LineSettingsEntry)*xLineSetList.ucNoOfLines);

       pvPayload = (void *)&xLineSetList; 
   }
   break;

   case IFX_DECT_LAU_SYS_SETTINGS:
   {
      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Read System Settings List.");
       pvPayload = pxSortedList; 
   }
   break;

   case IFX_DECT_LAU_INTERNAL_NAMES:
   {
       x_IFX_DECT_LAU_IntNameList xIntNameList = {0};

       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Read Internal Names List.");
       xIntNameList.cNoOfEntries = pxReadList->uxListCmd.xEntryReadReq.ucNoOfReqFields;
			if(xIntNameList.cNoOfEntries > 0 && xIntNameList.cNoOfEntries <=IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 >=0 && pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1 < IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES )
       memcpy(&xIntNameList.axIntNameList[0],
              &((x_IFX_DECT_LAU_IntNameList*)pxSortedList)->axIntNameList[pxReadList->uxListCmd.xEntryReadReq.nStartIndex-1],
              sizeof(x_IFX_DECT_LAU_IntNameListEntry)*xIntNameList.cNoOfEntries);			 

       pvPayload = (void *)&xIntNameList; 
   }
   break;
   default:
       pxReadList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "<IFX_DECTAPP_ReadList>Error! List not supported.");
       return IFX_FAILURE; 
  }

  pucDataPayload = (uchar8 *) malloc(1000 * sizeof(uchar8));
  IFX_DECT_LAU_DataPktPayloadEncode(pxReadList->nSessionId,
                                    ucListId,
                                    pvPayload,
                                    &unPayldSize,
                                    (char8 *)pucDataPayload);

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	           "<IFX_DECTAPP_ReadList>unPayldSize",unPayldSize);

  IFX_DECT_LAU_DataPktSend(pxReadList->nSessionId,
                           unPayldSize,
                           pucDataPayload);

  free(pucDataPayload);
  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_ReadList>Success");
  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_SearchList
 *  Description     : This internal Api searches the entries stored in FP 
 *                    matching the specified criteria and sends the
 *                    corresponding entries in separate data pkt.
 *  Input Values    : nSessionId - Session Identifier
 *                    ucListId - List Identifier
 *                    pxSortedList - pointer to Sorted List
 *                    pxSearchList - It contains search info such as matching 
 *                    option,search string, counter ,direction and mark entries request                  
 *  Output Values	  : pxSearchList - NACK reason, if any, is sent back 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return IFX_DECTAPP_SearchList(IN int16 nSessionId,
                                    IN uchar8 ucListId,
																		IN void *pxSortedList,
                                    IN OUT x_IFX_DECT_LAU_ListCommands *pxSearchList){
  void *pvPayload = NULL;
  uchar8 *pucDataPayload = NULL;
  uint16 unPayldSize = 0;
  x_IFX_DECT_LAU_ListCommands xOutCmd = {0};
  uchar8 ucIsCaseSense = 0;
	uchar8 ucOrder = 0;
	uchar8 ucAvailEntries = 0;
  int32 i=0,iRet = 0;

  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "<IFX_DECTAPP_SearchList>Entry");

  ucIsCaseSense = (pxSearchList->uxListCmd.xEntrySearchReq.ucMatchingOption & 0x04)>>2;
                  /*Bit3 set then case sensitive search.*/
	ucOrder = pxSearchList->uxListCmd.xEntrySearchReq.uiCounter & 0x80 ?1:0;
                    /*Bit8 indicates direction of Search-forward/backward*/

  switch(ucListId){

     case IFX_DECT_LAU_INTERNAL_NAMES:
     {
         x_IFX_DECT_LAU_IntNameList xIntNameList = {0};
         x_IFX_DECT_LAU_IntNameList xTempIntNameList = {0};
         x_IFX_DECT_LAU_IntNameList *pxIntNameList = NULL;

         IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<IFX_DECTAPP_SearchList>Search Internal Names List.");
				 pxIntNameList = (x_IFX_DECT_LAU_IntNameList*)pxSortedList;

			   strcpy(xTempIntNameList.axIntNameList[0].acTermIdNum,
                pxSearchList->uxListCmd.xEntrySearchReq.cSearchValue);

				 for(i=0;i<pxIntNameList->cNoOfEntries;i++){
						
           iRet = IFX_DECTAPP_Compare(((uint32)&xTempIntNameList.axIntNameList[0]),
                                       ((uint32)&pxIntNameList->axIntNameList[i]),
                                       ucListId,
                                       ucIsCaseSense);

           if(iRet < 0){

             switch(pxSearchList->uxListCmd.xEntrySearchReq.ucMatchingOption & 0x03){

               case 0x01:
                   xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = i+1;
                   break;

               case 0x02:
				           if(i == 0){
                      xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = 0;
                      xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = 0;
				            }else{
                      xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = i;
                     }
                    break;

                case 0:
                    xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = 0;
                    xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = 0;
                    break;

                default:
                    return IFX_FAILURE;
                    break;
             }
             break;
           }else if((iRet == 0)&&((pxSearchList->uxListCmd.xEntrySearchReq.ucMatchingOption & 0x03)<=2)){
              xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = i+1;
              break;
            }
         }

				 switch(ucOrder){

           case IFX_DECTAPP_DIR_BACKWD:
           {
						   ucAvailEntries = (xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex>0)?xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex:0;
							 xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = ((pxSearchList->uxListCmd.xEntrySearchReq.uiCounter & 0x7F)>
								                                             ucAvailEntries)? ucAvailEntries:(pxSearchList->uxListCmd.xEntrySearchReq.uiCounter & 0x7F); 

							 xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = (xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex>0)?
								                                               (xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex-xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter+1):
																															 0; 
					 }             
					 break;

					 case IFX_DECTAPP_DIR_FWD: 	 
           {
               ucAvailEntries = (xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex>0)? 
								                (pxIntNameList->cNoOfEntries-xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex+1):
																0; 
							 xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = ((pxSearchList->uxListCmd.xEntrySearchReq.uiCounter & 0x7F)>
								                                             ucAvailEntries)? ucAvailEntries:(pxSearchList->uxListCmd.xEntrySearchReq.uiCounter & 0x7F); 
					 }
					 break;

					 default:
					     break; 
				 }	 

         xIntNameList.cNoOfEntries = xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter;
				if(xIntNameList.cNoOfEntries > 0 && xIntNameList.cNoOfEntries <= IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES && xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex > 0 && xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex <= IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES)
         memcpy(&xIntNameList.axIntNameList[0],
                &pxIntNameList->axIntNameList[xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex-1],
                sizeof(x_IFX_DECT_LAU_IntNameListEntry)*xIntNameList.cNoOfEntries);
						
         pvPayload = (void *)&xIntNameList;
     }
     break;

     case IFX_DECT_LAU_CONTACTS:
     {
         x_IFX_DECT_LAU_ContactList xContactList = {0};
         x_IFX_DECT_LAU_ContactList *pxContactList = NULL;
         x_IFX_DECT_LAU_ContactList xTempContactList = {0};
         //uint32 uiCurIndex=0;
			uchar8 ucFlag=0;
				 pxContactList = (x_IFX_DECT_LAU_ContactList*)pxSortedList;

         strcpy(xTempContactList.axContactList[0].acLastName,
                pxSearchList->uxListCmd.xEntrySearchReq.cSearchValue);

          for(i = 0;i < pxContactList->unNoOfEntries;i++){
         
            iRet = IFX_DECTAPP_Compare1(((uint32)&xTempContactList.axContactList[0]),
                                     ((uint32)&pxContactList->axContactList[i]),
                                     ucListId,
                                     ucFlag);

				if(iRet >0) continue;
				
            if(iRet < 0){    
              switch(pxSearchList->uxListCmd.xEntrySearchReq.ucMatchingOption & 0x03){
 
                case 0x01:/*Current index returned if exact match fails*/ 
                    xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = i+1;
                    break;
                       
                case 0x02:/*Previous index returned if exact match fails*/
				            if(i == 0){
                      xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = 0;
                      xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = 0;
				            }else{
                      xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = i;
                     }
                    break;
                case 0:
                    xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = 0;
                    xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = 0;
                    break;

                default:
                    pxSearchList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
                    return IFX_FAILURE;
                    break;  
              }
            }else if(iRet == 0){
              switch(pxSearchList->uxListCmd.xEntrySearchReq.ucMatchingOption & 0x03){
                case 0x01:/*Current index returned if exact match fails*/ 
                    xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = i+1;
                    break;
                       
                case 0x02:/*Previous index returned if exact match fails*/
				            if(i == 0){
                      xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = 0;
                      xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = 0;
				            }else{
                      xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = i;
                     }
                    break;
                case 0:
						  if(strlen(xTempContactList.axContactList[0].acLastName)!= 
							 strlen(pxContactList->axContactList[i].acLastName)){
                    xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = 0;
                    xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = 0;
						  }else{
                    xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = i+1;
						 }
                    break;

                default:
                    pxSearchList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_ALLOW;
                    return IFX_FAILURE;
                    break;  
              }
              IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<IFX_DECTAPP_SearchList>Contact list match found case insensitive.");
              if(ucIsCaseSense && ucFlag)
						  break;
             }
				 if(!ucIsCaseSense || (iRet !=0))
					break;
				 else {
					ucFlag =1;
					i--;
               xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = 0;
					/*if(pxSearchList->uxListCmd.xEntrySearchReq.ucMatchingOption == 4 || pxSearchList->uxListCmd.xEntrySearchReq.ucMatchingOption ==0){
               xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = 0;
					}*/
				 }
			 }
			 switch(ucOrder){

           case IFX_DECTAPP_DIR_BACKWD:
           {
						   ucAvailEntries = (xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex>0)?xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex:0;
							 xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = ((pxSearchList->uxListCmd.xEntrySearchReq.uiCounter & 0x7F)>
								                                             ucAvailEntries)? ucAvailEntries:(pxSearchList->uxListCmd.xEntrySearchReq.uiCounter & 0x7F); 

							 xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex = (xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex>0)?
								                                               (xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex-xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter+1):
																															 0; 
					 }             
					 break;

					 case IFX_DECTAPP_DIR_FWD: 	 
           {
               ucAvailEntries = (xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex>0)? 
								                (pxContactList->unNoOfEntries-xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex+1):0; 
							 xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter = ((pxSearchList->uxListCmd.xEntrySearchReq.uiCounter & 0x7F)>
								                                             ucAvailEntries)? ucAvailEntries:(pxSearchList->uxListCmd.xEntrySearchReq.uiCounter & 0x7F); 
					 }
					 break;

					 default:
					     break; 
				 }	 

         xContactList.unNoOfEntries =  xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter;
				if(xContactList.unNoOfEntries > 0 && xContactList.unNoOfEntries <= IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES && xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex > 0 && xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex <= IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES)
         memcpy(&xContactList.axContactList[0],
                &pxContactList->axContactList[xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex-1],
                sizeof(x_IFX_DECT_LAU_ContactListEntry)*xContactList.unNoOfEntries);

         pvPayload = (void *)&xContactList;
     }
     break;
 
     default:
      IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "<IFX_DECTAPP_SearchList>Error! List not supported.");
      pxSearchList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
      return IFX_FAILURE;
  }

  xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_ENTRIES_SEARCH_CFM;
  xOutCmd.nSessionId = nSessionId;
  IFX_DECT_LAU_ConfirmationSend(&xOutCmd);
  
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
                   "<IFX_DECTAPP_SearchList>Start Index",xOutCmd.uxListCmd.xEntrySearchCfm.nStartIndex);

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
                   "<IFX_DECTAPP_SearchList>Counter",xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter);

  if(xOutCmd.uxListCmd.xEntrySearchCfm.ucCounter == 0){
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "<IFX_DECTAPP_SearchList>Counter is 0.");
    return IFX_SUCCESS;
  }
  pucDataPayload = (uchar8*) malloc(1000 * sizeof(uchar8));
  IFX_DECT_LAU_DataPktPayloadEncode(nSessionId,
                                    ucListId,
                                    pvPayload,
                                    &unPayldSize,
                                    (char8 *) pucDataPayload);

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
                   "<IFX_DECTAPP_SearchList>unPayldSize",unPayldSize);
  IFX_DECT_LAU_DataPktSend(nSessionId,
                           unPayldSize,
                           pucDataPayload);
  free(pucDataPayload);
  IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "<IFX_DECTAPP_SearchList>Success.");
  return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_FindMatchingContactEntry
 *  Description     : 
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_FindMatchingContactEntry(IN int16 nEntryId,
																		 IN x_IFX_DECT_LAU_ContactList *pxContList,
																		 OUT int32 *iPosition)
{
   int32 i = 0;
   IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	 //printf("<DectApp_FindContMatch> Entry Id = %d\n",nEntryId);
	 for(i=0;i< pxContList->unNoOfEntries;i++){
		if(pxContList->axContactList[i].nEntryId == nEntryId){
					 			break;
		 }
	 }

	 if(i == pxContList->unNoOfEntries) {
     	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No Match found");
			return IFX_FAILURE;
	 }
	 *iPosition = i;
		return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_DelContactEntry
 *  Description     : This API deletes Contact list entry from cached contact based on
											entry Id
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_DelContactEntry(IN int16 nEntryId,
														IN x_IFX_DECT_LAU_ContactList *pxCachedContacts)
{
   x_IFX_DECT_LAU_ContactListEntry xLocalEntry = {0};
   xLocalEntry.nEntryId = nEntryId;
	 int iPos = 0;
   IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");

	 if(IFX_FAILURE == IFX_DECTAPP_FindMatchingContactEntry(
											nEntryId,pxCachedContacts,&iPos)) {
			return IFX_FAILURE;
		}
    xLocalEntry = pxCachedContacts->axContactList[iPos];

		/** check entry previously is belongs to common contact list */
if(pxCachedContacts->axContactList[iPos].ucSubType == IFX_DECT_LINE_SUBTYPE_ALL ){
		/*TODO Since Line id does not from Handeset - use cached line id*/
	if(IFX_FAILURE == IFX_CIF_CommonContactListSet(&xLocalEntry,IFX_DECTAPP_DEL)){
         IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Del failed");
         return IFX_FAILURE;
    }
	vunCommonContactEntires--;
} else {
		/*TODO Since Line id does not from Handeset - use cached line id*/
    xLocalEntry.ucLineId = pxCachedContacts->axContactList[iPos].ucLineId;

    if(IFX_FAILURE == IFX_CIF_ContactListSet(&xLocalEntry,NULL,IFX_DECTAPP_DEL)){
         IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Del failed");     				
				 return IFX_FAILURE;
		}
		/*Decrement the Global Count*/
	 	vunContactsPerLine[pxCachedContacts->axContactList[iPos].ucLineId - 1]--;
	}
	 	/*Decrement the number of entries*/
    --pxCachedContacts->unNoOfEntries;   
			/*If Removed entry is the last*/
		if(iPos == pxCachedContacts->unNoOfEntries){ 
          memset(&pxCachedContacts->axContactList[iPos],0,sizeof(xLocalEntry));
		}
			/*Re-arrange remaining Entries*/
		else{
           memmove(&pxCachedContacts->axContactList[iPos], &pxCachedContacts->axContactList[iPos+1],
                    sizeof(x_IFX_DECT_LAU_ContactListEntry)*(pxCachedContacts->unNoOfEntries-iPos)); 
		}	
    IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Success!");
		return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_DeleteListEntry
 *  Description     : This internal Api deletes from FP the entry identified by
 *                    the entry identifier.
 *  Input Values    : ucListId - List Identifier
 *                    pxSortedList - pointer to Sorted List
 *                    pxDeleteList - It contains the entry identifier of entry to 
 *                                   be deleted and session identifier to identify 
 *                                    the list.
 *  Output Values	  : pxDeleteList - NACK reason, if any, is sent back 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_DeleteListEntry(IN uchar8 ucListId,
		                        IN void *pxSortedList,  
                            IN x_IFX_DECT_LAU_ListCommands *pxDeleteList){
uchar8 ucLineId;

 IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entry");

 switch(ucListId){

   case IFX_DECT_LAU_CONTACTS:
   {
    	 x_IFX_DECT_LAU_ContactList *pxCachedContacts=NULL;
			 uint16 nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;
       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Delete Contact List");
			 pxCachedContacts = (x_IFX_DECT_LAU_ContactList*)pxSortedList;
			 
			 if(IFX_SUCCESS != IFX_DECTAPP_DelContactEntry(nEntryId,pxCachedContacts)){
         pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
         return IFX_FAILURE; 
       }
			 return IFX_SUCCESS;
		}
   break;

   case IFX_DECT_LAU_INTERNAL_NAMES:
   {
       x_IFX_DECT_LAU_IntNameList xIntNameList = {0};
       x_IFX_DECT_LAU_IntNameList *pxIntNameList = NULL;
       uint32 i = 0;

       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Delete Internal Names List Entry.");
       xIntNameList.axIntNameList[0].nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;

       if(IFX_FAILURE == IFX_CIF_IntNameSet(&xIntNameList,IFX_DECTAPP_DEL)){
         IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "IFX_CIF_IntNameSet failed");
         pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
         return IFX_FAILURE;
       }
			 pxIntNameList = (x_IFX_DECT_LAU_IntNameList*)pxSortedList;

			 for(i=0;i<pxIntNameList->cNoOfEntries;i++){
			  if(pxIntNameList->axIntNameList[i].nEntryId == pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId){

          --pxIntNameList->cNoOfEntries;   
					if(i == pxIntNameList->cNoOfEntries){
            memset(&pxIntNameList->axIntNameList[i],0,sizeof(x_IFX_DECT_LAU_IntNameListEntry));
					}else{
            memmove(&pxIntNameList->axIntNameList[i],
                    &pxIntNameList->axIntNameList[i+1],
                    sizeof(x_IFX_DECT_LAU_IntNameListEntry)*(pxIntNameList->cNoOfEntries-i)); 
					 }	
          IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Success!");
					return IFX_SUCCESS;
			  }	
       } 
   }
   break;
   case IFX_DECT_LAU_MISSED_CALLS:
   {
       x_IFX_DECT_LAU_MissedCallList xMissedCallList = {0};
       x_IFX_DECT_LAU_MissedCallList *pxMissedCallList = NULL;
       int32 i = 0;

       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "<IFX_DECTAPP_DeleteListEntry>Delete Missed Call List Entry");

       pxMissedCallList = (x_IFX_DECT_LAU_MissedCallList*)pxSortedList;

       for(i=0;i<pxMissedCallList->cNoOfEntries;i++){
	  if(pxMissedCallList->axMissedCallList[i].nEntryId == pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId){
            ucLineId = pxMissedCallList->axMissedCallList[i].ucLineId;
            xMissedCallList.cNoOfEntries = 1;               
            xMissedCallList.axMissedCallList[0].nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;

            if(IFX_FAILURE == IFX_CIF_MissedCallListSet(ucLineId, &xMissedCallList,IFX_DECTAPP_DEL)){
       
              IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_DeleteListEntry>IFX_CIF_MissedCallListSet failed");
              pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
              return IFX_FAILURE; 
            }

            --pxMissedCallList->cNoOfEntries;   
   	    if(i == pxMissedCallList->cNoOfEntries){
              memset(&pxMissedCallList->axMissedCallList[i],0,sizeof(x_IFX_DECT_LAU_MissedCallListEntry));
	    }else{

            memmove(&pxMissedCallList->axMissedCallList[i],
                    &pxMissedCallList->axMissedCallList[i+1],
                    sizeof(x_IFX_DECT_LAU_MissedCallListEntry)*(pxMissedCallList->cNoOfEntries-i)); 
					 }	
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "<IFX_DECTAPP_DeleteListEntry>Success!");
					return IFX_SUCCESS;
			  }	
       }
   }
   break;
  
   case IFX_DECT_LAU_OUTGOING_CALLS:
   {
       x_IFX_DECT_LAU_OutgoingCallList xOutgoingCallList = {0};
       x_IFX_DECT_LAU_OutgoingCallList *pxOutgoingCallList = NULL;
       int32 i = 0;

       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "<IFX_DECTAPP_DeleteListEntry>Delete Outgoing Call List Entry");

        pxOutgoingCallList = (x_IFX_DECT_LAU_OutgoingCallList*)pxSortedList;

        for(i=0;i<pxOutgoingCallList->cNoOfEntries;i++){
	  if(pxOutgoingCallList->axOutgoingCallList[i].nEntryId == pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId){
          ucLineId = pxOutgoingCallList->axOutgoingCallList[i].ucLineId;
          xOutgoingCallList.cNoOfEntries = 1;               
          xOutgoingCallList.axOutgoingCallList[0].nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;

          if(IFX_FAILURE == IFX_CIF_OutgoingCallListSet(ucLineId,&xOutgoingCallList,IFX_DECTAPP_DEL)){
       
            IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<IFX_DECTAPP_DeleteListEntry>IFX_CIF_OutgoingCallListSet failed");
            pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
            return IFX_FAILURE; 
          }
          --pxOutgoingCallList->cNoOfEntries;   
					if(i == pxOutgoingCallList->cNoOfEntries){
            memset(&pxOutgoingCallList->axOutgoingCallList[i],0,sizeof(x_IFX_DECT_LAU_OutgoingCallListEntry));
					}else{

            memmove(&pxOutgoingCallList->axOutgoingCallList[i],
                    &pxOutgoingCallList->axOutgoingCallList[i+1],
                    sizeof(x_IFX_DECT_LAU_OutgoingCallListEntry)*(pxOutgoingCallList->cNoOfEntries-i)); 
					 }	
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "<IFX_DECTAPP_DeleteListEntry>Success!");
					return IFX_SUCCESS;
			  }	
       }
   }
   break;

   case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:
   {
       x_IFX_DECT_LAU_IncomingCallList xIncomingCallList = {0};
       x_IFX_DECT_LAU_IncomingCallList *pxIncomingCallList = NULL;
       int32 i = 0;

       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "<IFX_DECTAPP_DeleteListEntry>Delete Incoming Call List Entry");

       
			 pxIncomingCallList = (x_IFX_DECT_LAU_IncomingCallList*)pxSortedList;

			 for(i=0;i<pxIncomingCallList->cNoOfEntries;i++){
			  if(pxIncomingCallList->axIncomingCallList[i].nEntryId == pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId){
         ucLineId = pxIncomingCallList->axIncomingCallList[i].ucLineId;
         xIncomingCallList.cNoOfEntries = 1;               
         xIncomingCallList.axIncomingCallList[0].nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;

       if(IFX_FAILURE == IFX_CIF_IncomingCallListSet(ucLineId,&xIncomingCallList,IFX_DECTAPP_DEL)){
       
         IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "<IFX_DECTAPP_DeleteListEntry>IFX_CIF_IncomingCallListSet failed");
         pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
         return IFX_FAILURE; 
       }

          --pxIncomingCallList->cNoOfEntries;   
					if(i == pxIncomingCallList->cNoOfEntries){
            memset(&pxIncomingCallList->axIncomingCallList[i],0,sizeof(x_IFX_DECT_LAU_IncomingCallListEntry));
					}else{

            memmove(&pxIncomingCallList->axIncomingCallList[i],
                    &pxIncomingCallList->axIncomingCallList[i+1],
                    sizeof(x_IFX_DECT_LAU_IncomingCallListEntry)*(pxIncomingCallList->cNoOfEntries-i)); 
					 }	
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "<IFX_DECTAPP_DeleteListEntry>Success!");
					return IFX_SUCCESS;
			  }	
       }
   }
   break;
  
   case IFX_DECT_LAU_ALL_CALLS:
   {
       //x_IFX_DECT_LAU_AllCallList xAllCallList = {0};
       x_IFX_DECT_LAU_AllCallList *pxAllCallList = NULL;
       x_IFX_DECT_LAU_MissedCallList xMissedCallList = {0};
       x_IFX_DECT_LAU_IncomingCallList xIncomingCallList = {0};
       x_IFX_DECT_LAU_OutgoingCallList xOutgoingCallList = {0};
       int32 i = 0;

       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "<IFX_DECTAPP_DeleteListEntry>Delete Incoming Call List Entry");

       
			 pxAllCallList = (x_IFX_DECT_LAU_AllCallList*)pxSortedList;

       for(i=0;i<pxAllCallList->cNoOfEntries;i++){
			  if(pxAllCallList->axAllCallList[i].nEntryId == pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId){
         ucLineId = pxAllCallList->axAllCallList[i].ucLineId;

       if(pxAllCallList->axAllCallList[i].cCallListType == IFX_DECT_LAU_CALL_LIST_TYPE_MISSED){
         xMissedCallList.cNoOfEntries = 1;               
         xMissedCallList.axMissedCallList[0].nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;

         if(IFX_FAILURE == IFX_CIF_MissedCallListSet(ucLineId,&xMissedCallList,IFX_DECTAPP_DEL)){
       
           IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    "<IFX_DECTAPP_DeleteListEntry>IFX_CIF_MissedCallListSet failed");
           pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
           return IFX_FAILURE; 
         }
       }

       if(pxAllCallList->axAllCallList[i].cCallListType == IFX_DECT_LAU_CALL_LIST_TYPE_ACCEPTED){
         xIncomingCallList.cNoOfEntries = 1;               
         xIncomingCallList.axIncomingCallList[0].nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;

         if(IFX_FAILURE == IFX_CIF_IncomingCallListSet(ucLineId,&xIncomingCallList,IFX_DECTAPP_DEL)){
       
           IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    "<IFX_DECTAPP_DeleteListEntry>IFX_CIF_IncomingCallListSet failed");
           pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
           return IFX_FAILURE; 
         }
       }

       if(pxAllCallList->axAllCallList[i].cCallListType == IFX_DECT_LAU_CALL_LIST_TYPE_OUTGOING){
         xOutgoingCallList.cNoOfEntries = 1;               
         xOutgoingCallList.axOutgoingCallList[0].nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;

         if(IFX_FAILURE == IFX_CIF_OutgoingCallListSet(ucLineId,&xOutgoingCallList,IFX_DECTAPP_DEL)){
       
           IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    "<IFX_DECTAPP_DeleteListEntry>IFX_CIF_OutgoingCallListSet failed");
           pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
           return IFX_FAILURE; 
         }
       }

          --pxAllCallList->cNoOfEntries;   
					if(i == pxAllCallList->cNoOfEntries){
            memset(&pxAllCallList->axAllCallList[i],0,sizeof(x_IFX_DECT_LAU_AllCallListEntry));
					}else{

            memmove(&pxAllCallList->axAllCallList[i],
                    &pxAllCallList->axAllCallList[i+1],
                    sizeof(x_IFX_DECT_LAU_AllCallListEntry)*(pxAllCallList->cNoOfEntries-i)); 
					 }	
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "<IFX_DECTAPP_DeleteListEntry>Success!");
					return IFX_SUCCESS;
			  }	
       }
   }
   break;

   case IFX_DECT_LAU_ALL_INCOMING_CALLS:
   {
       //x_IFX_DECT_LAU_AllIncomingCallList xAllIncomingCallList = {0};
       x_IFX_DECT_LAU_AllIncomingCallList *pxAllIncomingCallList = NULL;
       x_IFX_DECT_LAU_MissedCallList xMissedCallList = {0};
       x_IFX_DECT_LAU_IncomingCallList xIncomingCallList = {0};
       int32 i = 0;

       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "<IFX_DECTAPP_DeleteListEntry>Delete Incoming Call List Entry");

       
			 pxAllIncomingCallList = (x_IFX_DECT_LAU_AllIncomingCallList*)pxSortedList;

       for(i=0;i<pxAllIncomingCallList->cNoOfEntries;i++){
			  if(pxAllIncomingCallList->axAllIncomingCallList[i].nEntryId == pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId){
         ucLineId = pxAllIncomingCallList->axAllIncomingCallList[i].ucLineId;

       if(pxAllIncomingCallList->axAllIncomingCallList[i].nEntryId < 16){
         xMissedCallList.cNoOfEntries = 1;               
         xMissedCallList.axMissedCallList[0].nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;
         if(IFX_FAILURE == IFX_CIF_MissedCallListSet(ucLineId,&xMissedCallList,IFX_DECTAPP_DEL)){
       
           IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    "<IFX_DECTAPP_DeleteListEntry>IFX_CIF_MissedCallListSet failed");
           pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
           return IFX_FAILURE; 
         }
       }

       else if(pxAllIncomingCallList->axAllIncomingCallList[i].nEntryId < 31){
         xIncomingCallList.cNoOfEntries = 1;               
         xIncomingCallList.axIncomingCallList[0].nEntryId = pxDeleteList->uxListCmd.xEntryDeleteReq.nEntryId;

         if(IFX_FAILURE == IFX_CIF_IncomingCallListSet(ucLineId,&xIncomingCallList,IFX_DECTAPP_DEL)){
       
           IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    "<IFX_DECTAPP_DeleteListEntry>IFX_CIF_IncomingCallListSet failed");
           pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
           return IFX_FAILURE; 
         }
       }

          --pxAllIncomingCallList->cNoOfEntries;   
					if(i == pxAllIncomingCallList->cNoOfEntries){
            memset(&pxAllIncomingCallList->axAllIncomingCallList[i],0,sizeof(x_IFX_DECT_LAU_AllIncomingCallListEntry));
					}else{

            memmove(&pxAllIncomingCallList->axAllIncomingCallList[i],
                    &pxAllIncomingCallList->axAllIncomingCallList[i+1],
                    sizeof(x_IFX_DECT_LAU_AllIncomingCallListEntry)*(pxAllIncomingCallList->cNoOfEntries-i)); 
					 }	
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "<IFX_DECTAPP_DeleteListEntry>Success!");
					return IFX_SUCCESS;
			  }	
       }

   }
   break;

   default:
      IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Error! List not supported.");
      pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
      return IFX_FAILURE;
 }
 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Failure!");
 pxDeleteList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
 return IFX_FAILURE;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_DeleteList
 *  Description     : This internal Api deletes all the entries in the list 
 *                    specified.
 *  Input Values    : ucListId - List Identifier
 *                    pxSortedList - pointer to Sorted List
 *  Output Values	  :  
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_DeleteList(IN uchar8 ucListId,
                       IN uchar8 *pucLineIdList,
                       IN void *pxSortedList)
{
 e_IFX_Return eRet = IFX_FAILURE;
 int32 i = 0;

 IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "<IFX_DECTAPP_DeleteList>Entry");
 
 switch(ucListId){

   case IFX_DECT_LAU_MISSED_CALLS:
   {
       while(pucLineIdList[i] != '\0'){
         if(IFX_SUCCESS != IFX_CIF_MissedCallListSet(pucLineIdList[i],NULL,IFX_DECTAPP_DEL)){
          return IFX_FAILURE;
         } 
         i++;
       }
       memset((x_IFX_DECT_LAU_MissedCallList*)pxSortedList,0,sizeof(x_IFX_DECT_LAU_MissedCallList));
       eRet = IFX_SUCCESS; 
   }
   break;

   case IFX_DECT_LAU_OUTGOING_CALLS:
   {
       while(pucLineIdList[i] != '\0'){
         if(IFX_SUCCESS != IFX_CIF_OutgoingCallListSet(pucLineIdList[i],NULL,IFX_DECTAPP_DEL)){
          return IFX_FAILURE;
         }
         i++;
       }
       memset((x_IFX_DECT_LAU_OutgoingCallList*)pxSortedList,0,sizeof(x_IFX_DECT_LAU_OutgoingCallList));
       eRet = IFX_SUCCESS; 
   }
   break;

   case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:
   {
       while(pucLineIdList[i] != '\0'){
         if(IFX_SUCCESS != IFX_CIF_IncomingCallListSet(pucLineIdList[i],NULL,IFX_DECTAPP_DEL)){
          return IFX_FAILURE;
         }
         i++;
       }
       memset((x_IFX_DECT_LAU_IncomingCallList*)pxSortedList,0,sizeof(x_IFX_DECT_LAU_IncomingCallList));
       eRet = IFX_SUCCESS; 
   }
   break;

   case IFX_DECT_LAU_ALL_CALLS:
   {
       while(pucLineIdList[i] != '\0'){
         if(!((IFX_SUCCESS == IFX_CIF_MissedCallListSet(pucLineIdList[i],NULL,IFX_DECTAPP_DEL))&&
            (IFX_SUCCESS == IFX_CIF_OutgoingCallListSet(pucLineIdList[i],NULL,IFX_DECTAPP_DEL))&&
            (IFX_SUCCESS == IFX_CIF_IncomingCallListSet(pucLineIdList[i],NULL,IFX_DECTAPP_DEL)))){
            return IFX_FAILURE;
         }
         i++;
       }
       memset((x_IFX_DECT_LAU_AllCallList*)pxSortedList,0,sizeof(x_IFX_DECT_LAU_AllCallList));
       eRet = IFX_SUCCESS; 
   }
   break;

   case IFX_DECT_LAU_ALL_INCOMING_CALLS:
   {
       while(pucLineIdList[i] != '\0'){
         if(!((IFX_SUCCESS == IFX_CIF_MissedCallListSet(pucLineIdList[i],NULL,IFX_DECTAPP_DEL))&&
            (IFX_SUCCESS == IFX_CIF_IncomingCallListSet(pucLineIdList[i],NULL,IFX_DECTAPP_DEL)))){
            return IFX_FAILURE;
         }
         i++;
       }
       memset((x_IFX_DECT_LAU_AllIncomingCallList*)pxSortedList,0,sizeof(x_IFX_DECT_LAU_AllIncomingCallList));
       eRet = IFX_SUCCESS; 
   }
   break;

   case IFX_DECT_LAU_CONTACTS:
   {
			int i=0;
      IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"All Contacts");		 
			 
			if(IFX_SUCCESS == IFX_CIF_ContactListSet(NULL,pucLineIdList,
												IFX_DECTAPP_DEL_ALL)){
         memset((x_IFX_DECT_LAU_ContactList*)pxSortedList,0,sizeof(x_IFX_DECT_LAU_ContactList));
         eRet = IFX_SUCCESS; 
       }
			
				/*Reset Global count of number of contacts for all associated lines*/
			 while(pucLineIdList[i] != '\0'){
					uchar8 ucLineId = pucLineIdList[i];
					if( ucLineId && ucLineId-1 < IFX_DECTAPP_MAX_LINES)
						vunContactsPerLine[ucLineId-1] = 0;
					i++;
			 }
   }
   break; 

   default:
      IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Error! List not supported.");
			eRet = IFX_FAILURE;
 }
 return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_EditList
 *  Description     : This internal Api retrieves the requested entry stored
 *                    in the FP.If available,the contents are encoded in a separate 
 *                    data packet and sent to PP.
 *  Input Values    : ucListId - List Identifier
 *                    pxSortedList - pointer to Sorted List
 *                    pxEditList - It contains the entry identifier 
 *  Output Values	  : pnPositionId - Position Identifier of the entry in sorted 
 *                                   list
 *                    pxEditList - NACK reason, if any, is sent back 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_DECTAPP_EditList(IN uchar8 ucListId,
																	IN void *pxSortedList,
                                  OUT int16 *pnPositionId,
                                  IN OUT x_IFX_DECT_LAU_ListCommands *pxEditList){

 void *pvPayload = NULL;
 uchar8 *pucDataPayload = NULL;
 uint16 unPayldSize = 0;
 x_IFX_DECT_LAU_ListCommands xOutCmd={0};
 int32 i = 0;

 IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        "Entry");

 switch(ucListId){

   case IFX_DECT_LAU_CONTACTS:
   {
       x_IFX_DECT_LAU_ContactList xContactList = {0};
       x_IFX_DECT_LAU_ContactList *pxContactList = NULL;

       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Edit Contact List.");
       pxContactList = (x_IFX_DECT_LAU_ContactList*)pxSortedList;
       for(i=0;i<pxContactList->unNoOfEntries;i++){
         if(pxContactList->axContactList[i].nEntryId == pxEditList->uxListCmd.xEntryEditReq.nEntryId){
           
            memcpy(&xContactList.axContactList[0],&pxContactList->axContactList[i],
                   sizeof(x_IFX_DECT_LAU_ContactListEntry));
            xContactList.unNoOfEntries = 1;
            *pnPositionId = i+1; 
						break;
				 }	 
			 }	 

       if(i == pxContactList->unNoOfEntries){
         IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Contact List Entry not found.");
         pxEditList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE; 
         return IFX_FAILURE;
			 }	 

       pvPayload = (void *)&xContactList;
   }
   break; 

   case IFX_DECT_LAU_SYS_SETTINGS:
   {
       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Edit System Settings List.");
       pvPayload = pxSortedList;
   }
   break;

   case IFX_DECT_LAU_LINE_SETTINGS:
   {
       x_IFX_DECT_LAU_LineSettingsList xLineSetList = {0};
       x_IFX_DECT_LAU_LineSettingsList *pxLineSetList = NULL;

       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                "Edit Line Settings List.");
       pxLineSetList = (x_IFX_DECT_LAU_LineSettingsList*)pxSortedList;
			
			 for(i=0;i < pxLineSetList->ucNoOfLines;i++){
				 if(pxLineSetList->axLineEntry[i].nEntryId == pxEditList->uxListCmd.xEntryEditReq.nEntryId){

					 memcpy(&xLineSetList.axLineEntry[0],&pxLineSetList->axLineEntry[i],
											sizeof(x_IFX_DECT_LAU_LineSettingsEntry));
           xLineSetList.ucNoOfLines=1;
           *pnPositionId = i+1; 
					 break;
				 }
			 }

       if(i == pxLineSetList->ucNoOfLines){
         IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Line Settings List Entry not found.");
         pxEditList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE; 
         return IFX_FAILURE;
			 }	 
       pvPayload = (void *)&xLineSetList;
   }
   break; 
     case IFX_DECT_LAU_INTERNAL_NAMES:
     {
         x_IFX_DECT_LAU_IntNameList xIntNameList = {0};
         x_IFX_DECT_LAU_IntNameList *pxIntNameList = NULL;

         IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "Edit Internal Names List.");
         pxIntNameList = (x_IFX_DECT_LAU_IntNameList*)pxSortedList;

         for(i=0;i < pxIntNameList->cNoOfEntries;i++){
					 if(pxIntNameList->axIntNameList[i].nEntryId == pxEditList->uxListCmd.xEntryEditReq.nEntryId){

							memcpy(&xIntNameList.axIntNameList[0],&pxIntNameList->axIntNameList[i],
											sizeof(x_IFX_DECT_LAU_IntNameListEntry));
              xIntNameList.cNoOfEntries=1;
              *pnPositionId = i+1; 
							break;
					 }
				 }

         if(i == pxIntNameList->cNoOfEntries){
           IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                    "Internal Names List Entry not found.");
           pxEditList->eNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE; 
           return IFX_FAILURE;
			   }	 
         pvPayload = (void *)&xIntNameList;
     }
     break;

   default:
       IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Error! List not supported.");
       pxEditList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       return IFX_FAILURE;
 }  

 xOutCmd.ucListCmd = IFX_DECT_LAU_CMD_ENTRY_EDIT_CFM;
 xOutCmd.nSessionId = pxEditList->nSessionId;
 IFX_DECT_LAU_ConfirmationSend(&xOutCmd);

 pucDataPayload = (uchar8*) malloc(1000 * sizeof(uchar8));
 IFX_DECT_LAU_DataPktPayloadEncode(pxEditList->nSessionId,
                                   ucListId,
                                   pvPayload,
                                   &unPayldSize,
                                   (char8 *)pucDataPayload);

  IFX_DECT_LAU_DataPktSend(pxEditList->nSessionId,
                           unPayldSize,
                           pucDataPayload);

 free(pucDataPayload);
 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
               "Success!");
 return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECT_GetDateTime
 *  Description     : This internal Api converts time-date information into
 *                    BCD format and stores in the structure pxTimeDate.
 *  Input Values    : pcDate - Date Information(hours,minutes,seconds)
 *                    pcTime - Time Information(day,month,year)
 *  Output Values   : pxTimeDate - pointer to TimeDate structure with information 
 *                    stored in BCD format
 *  Return Value    : IFX_PROCESSED/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECT_GetDateTime(IN char* pcDate, IN char* pcTime,OUT x_IFX_DECT_USU_TimeDate *pxTimeDate){

  IFX_DECT_GetBCD(atoi(pcDate+2),&pxTimeDate->ucYear);
  IFX_DECT_GetBCD(atoi(pcDate+5),&pxTimeDate->ucMonth);
  IFX_DECT_GetBCD(atoi(pcDate+8),&pxTimeDate->ucDay);
  IFX_DECT_GetBCD(atoi(pcTime),&pxTimeDate->ucHour);
  IFX_DECT_GetBCD(atoi(pcTime+3),&pxTimeDate->ucMinutes);
  IFX_DECT_GetBCD(atoi(pcTime+6),&pxTimeDate->ucSeconds);
  IFX_DECT_GetBCD(0,&pxTimeDate->ucTimeZone);

  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_VerifyEditable
 *  Description     : This internal Api verifies that the non-editable fields are 
 *                    not modified during a save.
 *  Input Values    : ucListId - ListIdentifier
 *                    unFieldMap - bit map of field Identifiers
 *  Output Values   : None
 *  Return Value    : IFX_PROCESSED/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
 IFX_DECTAPP_VerifyEditable(IN uchar8 ucListId,IN uint16 unFieldMap){

   e_IFX_Return eRet = IFX_FAILURE;

   switch(ucListId){

     case IFX_DECT_LAU_CONTACTS:
     {
			   if((unFieldMap & (IFX_DECT_LAU_CL_LNAME | IFX_DECT_LAU_CL_FNAME | IFX_DECT_LAU_CL_NUM | IFX_DECT_LAU_CL_LINEID))!=0)
  			 eRet =  IFX_SUCCESS;
     }
     break;

		 case IFX_DECT_LAU_LINE_SETTINGS:
     {
    		 if((unFieldMap & (IFX_DECT_LAU_LSE_ATCHPP|IFX_DECT_LAU_LSE_CLIR|IFX_DECT_LAU_LSE_LINENAME|
                           IFX_DECT_LAU_LSE_CFU|IFX_DECT_LAU_LSE_CFB|
														IFX_DECT_LAU_LSE_CFN|IFX_DECT_LAU_LSE_CALLMODE|IFX_DECT_LAU_LSE_INTR))!=0)
    			eRet = IFX_SUCCESS;
     }
		 break;

		 case IFX_DECT_LAU_SYS_SETTINGS:
     {
			   if((unFieldMap & (IFX_DECT_LAU_SSE_PIN|IFX_DECT_LAU_SSE_CLKMSTR|IFX_DECT_LAU_SSE_BASERESET
											  |IFX_DECT_LAU_SSE_NEWPIN|IFX_DECT_LAU_SSE_NEM))!=0)		
			     eRet = IFX_SUCCESS;
     }
		 break;

		 case IFX_DECT_LAU_INTERNAL_NAMES:
     {
   			if(((IFX_DECT_LAU_IL_FNAME|IFX_DECT_LAU_IL_INTERCEPTION) & unFieldMap) != 0)
         eRet =  IFX_SUCCESS; 
     }
     break;

     default:
         IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                  "<IFX_DECTAPP_VerifyEditable>Error! List not supported." );
         break; 

   }
  
   return eRet;  
}


/******************************************************************************
 *  Function Name   : IFX_DECTAPP_AllowEditSave
 *  Description     : This internal Api verifies whether Edit/Save operation
 *                    is permitted on the List or not.Edit or Save is not 
 *                    allowed in "Call Lists". 
 *  Input Values    : ucListId - List Identifier
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
  IFX_DECTAPP_AllowEditSave(IN uchar8 ucListId){

  switch(ucListId){

    case IFX_DECT_LAU_MISSED_CALLS:
    case IFX_DECT_LAU_OUTGOING_CALLS:
    case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:
    case IFX_DECT_LAU_ALL_CALLS:
    case IFX_DECT_LAU_ALL_INCOMING_CALLS: 
        IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
           "<IFX_DECTAPP_AllowEditSave>Failure." );
	      return IFX_FAILURE;

    default:
        return IFX_SUCCESS;
  }
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_IsLineIdValid
 *  Description     : This API Validates line Id for a given HandsetId
											Line Id is considered to valid ONLY IF - Handset is
											associated to that line.
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_IsLineIdValid(IN uchar8 ucHandSetId, 
													IN uchar8 ucLineId)
{
	int32 i=0;
	if(IFX_DECTAPP_IsHandSetIdValid(ucHandSetId) == IFX_SUCCESS){
		while(vacAssocLines[ucHandSetId-1][i] != '\0'){
			if(vacAssocLines[ucHandSetId-1][i] == ucLineId ){
				return IFX_SUCCESS;
			}
			i++;
		}
	}
	return IFX_FAILURE;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_GetDefaultLineId
 *  Description     : This API gets Default line based on Handset Id
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Default Line Id OR Zeor If no default line found
 *  Notes           :
 ****************************************************************************/
uchar8 IFX_DECTAPP_GetDefaultLineId(unsigned char  ucHandSetId)
{
	char8 szEndptId[64] = "";
	uchar8 ucDefaultLine=0;
	e_IFX_ReasonCode eReason;

	if(IFX_DECT_GetEndptName(ucHandSetId,szEndptId) != IFX_SUCCESS) {
 		 IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
	               "Endpoint Not found: ", ucHandSetId);
      return ucDefaultLine;
	}
	
 	if (IFX_CIF_EndptDefaultVLGet(szEndptId,&ucDefaultLine,&eReason) != IFX_SUCCESS) {
      				IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
	               "No default Lind found", ucHandSetId);
	}
 	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
	               "Default Line ",ucDefaultLine );
	return ucDefaultLine;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_CanContactBeAdded
 *  Description     : This API does various validation check for a successful
											ADD operation.
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_CanContactBeAdded( IN uchar8 ucHandSetId,
															 IN x_IFX_DECT_LAU_ContactListEntry *pxRcvdEntry,
															 OUT uchar8* pucLineIdList)
{
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry" );

	if(IFX_DECT_LINE_SUBTYPE_ALL == pxRcvdEntry->ucSubType ) {
  	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Subtype is All" );

			/*Check curent number of entries in the common contact list  from Global Info*/
			if(IFX_MAX_CONTACTS_PER_LINE ==  vunCommonContactEntires ){
 					IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
	               "Max Limit reached for Common list ");
					return IFX_FAILURE;
			}
	}

	else {
				/*Check Validity of Rcvd Line*/
				pucLineIdList[0] = pxRcvdEntry->ucLineId;
				pxRcvdEntry->ucSubType=IFX_DECT_LINE_SUBTYPE_RELATING_TO;
				if(IFX_FAILURE == IFX_DECTAPP_IsLineIdValid(ucHandSetId,
					pxRcvdEntry->ucLineId)){
  				IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Invalid Line Id ",
										pxRcvdEntry->ucLineId );

					/*Use Default Line*/
					pucLineIdList[0] = IFX_DECTAPP_GetDefaultLineId(ucHandSetId);
					if(pucLineIdList[0] == 0 ){
  					IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"No Line found" );
						return IFX_FAILURE;
					}
				}
				if(IFX_MAX_CONTACTS_PER_LINE == vunContactsPerLine[pucLineIdList[0]-1]){
 						IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
	               "Max Limit reached for line ",pucLineIdList[0] );
					return IFX_FAILURE;
				}
		}
		return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_AddContactEntry
 *  Description     : This API Adds recevied entry to Cached contact list. 
											In case of failure it updates NACK Reason code.
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_AddContactEntry( IN x_IFX_DECT_LAU_ContactListEntry *pxRcvdEntry,
														 IN_OUT x_IFX_DECT_LAU_ContactList *pxCachedContacts,
									           IN uchar8 ucHandSetId,
														 IN int16 *pnPositionId,
														 OUT e_IFX_DECT_LAU_NackReason *peNackReason)
{
			x_IFX_DECT_LAU_ContactList xLocalContacts;
			uchar8 aucLineList[IFX_DECTAPP_MAX_LINES + 1]=""; /*List of Lines Where Contact needs to be added*/
			uint16 i=0;
			uint16 unOldNoOfEntries = 0;
			int32 uiPtrArray[IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES]= {0};
			if(!pxRcvdEntry || !pxCachedContacts || !pnPositionId ||
						ucHandSetId ==0 || !peNackReason) {
  				IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Invalid IN Params" );
					return IFX_FAILURE;
			}

			/*Check If Contact can be added - 
				also get List of Lines where contact need to be added*/
      if(IFX_FAILURE == IFX_DECTAPP_CanContactBeAdded(ucHandSetId,pxRcvdEntry,aucLineList)){
  				IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Can not Add - Failed" );
					*peNackReason = IFX_DECT_LAU_NACK_REASON_LIST_FULL;
					return IFX_FAILURE;
			}

  			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_INT,"Line subtype is ", pxRcvdEntry->ucSubType);
			unOldNoOfEntries =  pxCachedContacts->unNoOfEntries;
			if('\0' == pxRcvdEntry->acFirstName[0]){
  			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"FirstName NULL- Failed" );
				*peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
              return IFX_FAILURE;
			}
			if('\0' == pxRcvdEntry->acLastName[0]){
  			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"LastName NULL- Failed" );
				*peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
              return IFX_FAILURE;
			}
			
		if('\0' == (pxRcvdEntry->xNumber.xNum[0].acNumber[0])){
  			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Phone Number-I NULL- Failed" );
				*peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
              return IFX_FAILURE;
		}	
		if(IFX_DECT_LINE_SUBTYPE_ALL == pxRcvdEntry->ucSubType){
					pxRcvdEntry->nEntryId = 0;
					if(IFX_SUCCESS != IFX_CIF_CommonContactListSet(pxRcvdEntry,IFX_DECTAPP_ADD)){
  						IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Set failed" );
							/*Could be due to Duplicate entry*/
							*peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
							return IFX_FAILURE;	
					 }

					 /*Increment Gloabal count of Common Contacts*/
					vunCommonContactEntires++;

			}else { 
					while(aucLineList[i] != 0 && i < IFX_DECTAPP_MAX_LINES){
						pxRcvdEntry->ucLineId =  aucLineList[i];
 						IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
	               "Adding to Line ",pxRcvdEntry->ucLineId);
							pxRcvdEntry->nEntryId = 0;
							if(IFX_SUCCESS != IFX_CIF_ContactListSet(pxRcvdEntry,NULL,IFX_DECTAPP_ADD)){
  								IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Set failed" );
									/*Could be due to Duplicate entry*/
									*peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
									return IFX_FAILURE;	
					 }

					 /*Increment Gloabal count of Contacts per line*/
					 vunContactsPerLine[pxRcvdEntry->ucLineId - 1 ]++;
					 i++;
			}
	}				 /*Copy New-Entry into Cached Contacts*/
					 memcpy(&pxCachedContacts->axContactList[pxCachedContacts->unNoOfEntries],pxRcvdEntry,
									sizeof(x_IFX_DECT_LAU_ContactListEntry));

					 pxCachedContacts->unNoOfEntries++;
			/*Take a local copy of the list*/
			memcpy(&xLocalContacts,pxCachedContacts,sizeof(xLocalContacts));
			for(i=0;i<xLocalContacts.unNoOfEntries;i++){
            uiPtrArray[i] = (uint32)(&xLocalContacts.axContactList[i]);
      }
			
			/*Break new list as two sorted list and merge them*/
			IFX_DECTAPP_MergeSortedLists(0,unOldNoOfEntries-1,
																	xLocalContacts.unNoOfEntries-1,uiPtrArray,
																	IFX_DECT_LAU_CONTACTS);

			/*ReArrange Cached Contact*/
			for(i=0;i<pxCachedContacts->unNoOfEntries;i++){
           memcpy(&pxCachedContacts->axContactList[i],
									(x_IFX_DECT_LAU_ContactListEntry*)uiPtrArray[i],
                 	sizeof(x_IFX_DECT_LAU_ContactListEntry));
					if(pxCachedContacts->axContactList[i].nEntryId == pxRcvdEntry->nEntryId){
              *pnPositionId = i+1;
             }
      }
			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Success NoOfEntires ",
			pxCachedContacts->unNoOfEntries);
			return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_EditContactEntry
 *  Description     : This API modifies recevied entry. If line id changed of the contact 
											then Add and Delete operation is perfomed. 
                      In case of failure it updates NACK Reason code.
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_EditContactEntry(IN x_IFX_DECT_LAU_ContactListEntry *pxRcvdEntry,
														 IN_OUT x_IFX_DECT_LAU_ContactList *pxCachedContacts,
			 											 IN uchar8 ucHandSetId,
														 OUT e_IFX_DECT_LAU_NackReason *peNackReason)
{
	int32 i = 0,k = 0;
		x_IFX_DECT_LAU_ContactList xLocalContacts = {0};	
		uchar8 aucLineList[IFX_DECTAPP_MAX_LINES]=""; /*List of Lines Where Contact needs to be added*/
		int32 uiPtrArray[IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES]= {0};
  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Entry" );
printf("<IFX_DECTAPP_EditContactEntry> Entry\n");	
	if( IFX_FAILURE == IFX_DECTAPP_FindMatchingContactEntry	
				(pxRcvdEntry->nEntryId,pxCachedContacts,&i) ) {

      IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"No Match found");
				*peNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
				return IFX_FAILURE;
	}
	/*Check If Last name to be edited*/
	if(pxRcvdEntry->uiEditField & IFX_DECT_LAU_CL_LNAME){
		if('\0' == pxRcvdEntry->acLastName[0]){
				printf("<IFX_DECTAPP_EditContactEntry> No matching Entry Found for edit\n");	
  		 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"LastName NULL- Failed" );
			 *peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
       return IFX_FAILURE;
		}
	}
	else{
		printf("<EditCont> Don't Edit Last Name");
		strcpy(pxRcvdEntry->acLastName,pxCachedContacts->axContactList[i].acLastName);
	}

	/*Check If First name to be edited*/
	if(pxRcvdEntry->uiEditField & IFX_DECT_LAU_CL_FNAME){
		if('\0' == pxRcvdEntry->acFirstName[0]){
				printf("<IFX_DECTAPP_EditContactEntry> No matching Entry Found for edit\n");	
  		 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"FirstName NULL- Failed" );
			 *peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
       return IFX_FAILURE;
		}
	}
	else{
		printf("<EditCont> Don't First Name");
		strcpy(pxRcvdEntry->acFirstName,pxCachedContacts->axContactList[i].acFirstName);
	}
		/*if (!(pxRcvdEntry->uiEditField & IFX_DECT_LAU_CL_FNAME)) {
		strcpy(pxRcvdEntry->acFirstName,pxCachedContacts->axContactList[i].acFirstName);
	}*/

	if ((pxRcvdEntry->uiEditField & IFX_DECT_LAU_CL_NUM)) {
		if('\0' == (pxRcvdEntry->xNumber.xNum[0].acNumber[0])){
  			IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Phone Number-I NULL- Failed" );
				*peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
              return IFX_FAILURE;
		}
	}
		else { /*if (!(pxRcvdEntry->uiEditField & IFX_DECT_LAU_CL_NUM)) {*/
		printf("<EditCont> Don't Edit Contact Numbers");
    for(k = 0; k<pxCachedContacts->axContactList[i].xNumber.ucNoOfContactNumbers; k++){
		 strcpy(pxRcvdEntry->xNumber.xNum[k].acNumber,pxCachedContacts->axContactList[i].xNumber.xNum[k].acNumber);
		 pxRcvdEntry->xNumber.xNum[k].ctype = pxCachedContacts->axContactList[i].xNumber.xNum[k].ctype;
    }
    pxRcvdEntry->xNumber.ucNoOfContactNumbers = pxCachedContacts->axContactList[i].xNumber.ucNoOfContactNumbers;
	}
						  

	/*Normal Edit*/
  if( !(pxRcvdEntry->uiEditField & IFX_DECT_LAU_CL_LINEID) || //Line Id is not in Edit field
       (0 == pxRcvdEntry->ucLineId) ||  //Line Id is 0
       (pxCachedContacts->axContactList[i].ucLineId==pxRcvdEntry->ucLineId)) //Same Line Id
	{ 
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Normal Edit");
				printf("<IFX_DECTAPP_EditContactEntry> Normal  edit\n");	
	 	 if(IFX_DECT_LINE_SUBTYPE_ALL == pxCachedContacts->axContactList[i].ucSubType){
				/*Incase LineId=0 - preserve the earlier ID*/
        pxRcvdEntry->ucLineId = pxCachedContacts->axContactList[i].ucLineId;
        if(IFX_SUCCESS != IFX_CIF_CommonContactListSet(pxRcvdEntry,IFX_DECTAPP_MODIFY)){
            *peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
						printf("***** <EditContCommon> Failed\n");
            IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Edit failed");
            return IFX_FAILURE;
				}
			}
			else{
					/*Incase LineId=0 - preserve the earlier ID*/
 				pxRcvdEntry->ucLineId = pxCachedContacts->axContactList[i].ucLineId;
				if(IFX_SUCCESS != IFX_CIF_ContactListSet(pxRcvdEntry,NULL,IFX_DECTAPP_MODIFY)){	
						*peNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
				 		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Edit failed");
						return IFX_FAILURE;
				}

			}
      /*Copy Edited entry in the sorted list*/
      memcpy(&pxCachedContacts->axContactList[i],pxRcvdEntry,sizeof(x_IFX_DECT_LAU_ContactListEntry));
       /*Get a local copy of cached contatcs*/
      memcpy(&xLocalContacts,pxCachedContacts,sizeof(xLocalContacts));

        /*Sort local copy of  cached contact list */
      for(i=0;i<xLocalContacts.unNoOfEntries;i++){
           uiPtrArray[i] = (uint32)(&xLocalContacts.axContactList[i]);
      }
      IFX_DECTAPP_SortList(0,xLocalContacts.unNoOfEntries-1,uiPtrArray,IFX_DECT_LAU_CONTACTS);

						/*Copy back to Cached List*/
      memset(pxCachedContacts,0,sizeof(x_IFX_DECT_LAU_ContactList));
			for(i=0;i<xLocalContacts.unNoOfEntries;i++){
          memcpy(&pxCachedContacts->axContactList[i],
								(x_IFX_DECT_LAU_ContactListEntry*)uiPtrArray[i],
                sizeof(x_IFX_DECT_LAU_ContactListEntry));
       }
       pxCachedContacts->unNoOfEntries = xLocalContacts.unNoOfEntries;
	}

	/*Line Id has changed*/
	else 
	{
		int16 nOldEntryId = pxCachedContacts->axContactList[i].nEntryId;
		int16 TempPosId=0;
		e_IFX_Return eRet;
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Line Id Changed");
		
			//Validate the received line ID
			if(IFX_DECT_LINE_SUBTYPE_ALL != pxRcvdEntry->ucSubType && IFX_FAILURE == IFX_DECTAPP_IsLineIdValid(ucHandSetId,
          pxRcvdEntry->ucLineId)){
          IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Invalid Line Id ",
                    pxRcvdEntry->ucLineId );
				pxRcvdEntry->ucLineId = pxCachedContacts->axContactList[i].ucLineId;	
			}
		
			if(IFX_DECT_LINE_SUBTYPE_ALL != pxRcvdEntry->ucSubType )
					pxRcvdEntry->ucSubType=IFX_DECT_LINE_SUBTYPE_RELATING_TO;
			
				/*Check If Contact can be added - 
				also get List of Lines where contact need to be added*/
      if(IFX_FAILURE == IFX_DECTAPP_CanContactBeAdded(ucHandSetId,pxRcvdEntry,aucLineList)){
  				IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Can not Move it to Line" );
					*peNackReason = IFX_DECT_LAU_NACK_REASON_LIST_FULL;
					return IFX_FAILURE;
			}
		eRet = IFX_DECTAPP_DelContactEntry(nOldEntryId,pxCachedContacts);
		if(IFX_SUCCESS != eRet){
				/*What TODO */
				 IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Del failed");
				*peNackReason = IFX_DECT_LAU_NACK_REASON_NOT_AVAILABLE;
        return IFX_FAILURE;
		}
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Del Done");
 	  
		eRet = IFX_DECTAPP_AddContactEntry(pxRcvdEntry,pxCachedContacts,ucHandSetId,
                             			&TempPosId,peNackReason);
		if(eRet != IFX_SUCCESS) {
					IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
										"Failed to add in Line",pxRcvdEntry->ucLineId);
					return IFX_FAILURE;
		}
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Add Done");
		/*Set the flag Again*/
		vucNotifyIgnore[IFX_DECT_LAU_CONTACT_LIST-1] = ucHandSetId;

	}
	
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"Success");
	return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_SaveList
 *  Description     : This internal Api saves a new/previously editted entry in
 *                    the FP.
 *  Input Values    : ucListId - List Identifier
 *                    pnPositionId - Position Identifier
 *                    pxSortedList - pointer to Sorted List
 *                    unDataLen - Length of entry  
 *                    pucData - entry to be saved
 *                    pxSaveList - It contains the entry identifier of 
 *                    the entry to be saved
 *  Output Values   : pxSaveList - Nack reason ,if any, is sent back
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_DECTAPP_SaveList(IN uchar8 ucListId,
                     IN int16 *pnPositionId,
										 IN void *pxSortedList,
										 IN uint16 *punFieldIds,
                     IN uint16 unDataLen,
                     IN uchar8 *pucData,
                     IN OUT x_IFX_DECT_LAU_ListCommands *pxSaveList)
{
	uchar8 ucHandSetId = ((pxSaveList->nSessionId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS)+1;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "Entry.");
  switch(ucListId){
		
	  case IFX_DECT_LAU_CONTACT_LIST:
	  {
      x_IFX_DECT_LAU_ContactList xLocalContacts = {0};
      x_IFX_DECT_LAU_ContactList *pxCachedContacts = NULL;
			e_IFX_DECT_LAU_NackReason eNackReason=0;
			e_IFX_Return eRet = IFX_FAILURE;

      IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"ContactList");
      memset(&xLocalContacts,0,sizeof(x_IFX_DECT_LAU_ContactList));
      pxCachedContacts = (x_IFX_DECT_LAU_ContactList*)pxSortedList; 

      if(IFX_FAILURE == IFX_DECT_LAU_DataPktPayloadDecode(
												ucListId,(void *)&xLocalContacts,
												unDataLen,pucData)) {

        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Pkt Decode failed.");
        *punFieldIds = 0;
        pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
        return IFX_FAILURE;
      }

		  xLocalContacts.axContactList[0].uiEditField = *punFieldIds; 
      *punFieldIds = 0;
      if(!pxSaveList->uxListCmd.xEntrySaveReq.nEntryId){ 
			    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Add op");
					eRet = IFX_DECTAPP_AddContactEntry(&xLocalContacts.axContactList[0],
																						pxCachedContacts,ucHandSetId,
																						pnPositionId,&eNackReason);
			}
			else{
         	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"EDIT");
					eRet = IFX_DECTAPP_EditContactEntry(&xLocalContacts.axContactList[0],
														pxCachedContacts,ucHandSetId,&eNackReason);
		 }

		 if(eRet == IFX_FAILURE) {
         		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Add/Edit failed");
          	pxSaveList->eNackReason = eNackReason;
          	return IFX_FAILURE;
     }   
		 /*Saving EntryId is reuqired in Edit as Line Change may change Entry Id*/
		 pxSaveList->uxListCmd.xEntrySaveReq.nEntryId = xLocalContacts.axContactList[0].nEntryId;
			return IFX_SUCCESS;
    }
    break;
	
		case IFX_DECT_LAU_SYS_SETTINGS:
    {
        x_IFX_DECT_LAU_SystemSettingsList xSysList = {0};
        x_IFX_DECT_LAU_SystemSettingsList *pxSysList = (x_IFX_DECT_LAU_SystemSettingsList *)pxSortedList;

        IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "Save System Settings List.");
        if(IFX_FAILURE == IFX_DECT_LAU_DataPktPayloadDecode(ucListId,
                                                            (void *)&xSysList,
                                                            unDataLen,
                                                            pucData)){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "IFX_DECT_LAU_DataPktPayloadDecode failed.");
          pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
          *punFieldIds = 0;
          return IFX_FAILURE;
        }  
				*pnPositionId=1;

				xSysList.uiEditField = *punFieldIds; 
        *punFieldIds = 0;
			if(IFX_DECTAPP_IsHandSetIdValid(ucHandSetId) != IFX_SUCCESS){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "IFX_DECT_LAU_DataPktPayloadDecode Invalid Handset ID");
          pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
          *punFieldIds = 0;
          return IFX_FAILURE;
				}
				/* Verify Pin for this HS.Needed for Pin Protection. */
          if((xSysList.uiEditField & IFX_DECT_LAU_SSE_PIN)){
            if(!strcmp(pxSysList->acPIN,xSysList.acPIN)){
              vaxPinInfo.aucPinEval[ucHandSetId-1] = 1;
              return IFX_SUCCESS;    
				  	}else{
              IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "Pin Verification failed.");
              vaxPinInfo.aucPinEval[ucHandSetId-1] = 0;//Check?
				      pxSaveList->eNackReason=IFX_DECT_LAU_NACK_REASON_PIN_INCORRECT;
              return IFX_FAILURE;
					   }	
		      }
        if(!vaxPinInfo.aucPinEval[ucHandSetId-1]){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "Correct Pin Required.");
          pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_PIN_REQUIRED;
          return IFX_FAILURE;
        }
        if(IFX_SUCCESS == IFX_CIF_SystemSet(&xSysList)){
          memcpy(pxSysList,&xSysList,sizeof(x_IFX_DECT_LAU_SystemSettingsList));
          return IFX_SUCCESS;
        }
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "IFX_CIF_SystemSet failed.");
	  }		
    break;
  
    case IFX_DECT_LAU_LINE_SETTINGS: 
    { 
        x_IFX_DECT_LAU_LineSettingsList xLineSetList={0};

        IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "Save Line Settings List.");
        if(IFX_FAILURE == IFX_DECT_LAU_DataPktPayloadDecode(ucListId,
                                                            (void *)&xLineSetList,
                                                            unDataLen,
                                                            pucData)){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "IFX_DECT_LAU_DataPktPayloadDecode failed.");
          pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
          *punFieldIds = 0;
          return IFX_FAILURE;
        }

        xLineSetList.axLineEntry[0].uiEditField = *punFieldIds;
        *punFieldIds = 0;

        if(ucHandSetId > 0 && ucHandSetId <= IFX_DECTAPP_MAX_DECT_ENDPTS && !vaxPinInfo.aucPinEval[ucHandSetId-1]){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "Pin Verification required.");
          pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_PIN_REQUIRED;
          return IFX_FAILURE;
        }
        xLineSetList.axLineEntry[0].nEntryId = pxSaveList->uxListCmd.xEntrySaveReq.nEntryId;

		    if(IFX_SUCCESS == IFX_CIF_LineSet(&xLineSetList,IFX_DECTAPP_MODIFY)){
						*pnPositionId=(xLineSetList.axLineEntry[0].nEntryId != 4/*PSTN Line Id*/)?xLineSetList.axLineEntry[0].nEntryId:
                           ((x_IFX_DECT_LAU_LineSettingsList*)pxSortedList)->ucNoOfLines;
          printf("\n Position Id=%d\n",*pnPositionId); 
          memcpy(&((x_IFX_DECT_LAU_LineSettingsList*)pxSortedList)->axLineEntry[*pnPositionId-1],
                 &xLineSetList.axLineEntry[0],sizeof(x_IFX_DECT_LAU_LineSettingsEntry));  
		      return IFX_SUCCESS;
		    }
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "IFX_CIF_LineSet failed.");
    }
    break;

    case IFX_DECT_LAU_INTERNAL_NAMES:
    {
        x_IFX_DECT_LAU_IntNameList xIntNameList = {0};

        if(IFX_FAILURE == IFX_DECT_LAU_DataPktPayloadDecode(ucListId,
                                                            (void *)&xIntNameList,
                                                            unDataLen,
                                                            pucData)){
           IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "DataPktPayloadDecode failed.");
           pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_CONTENT_NOT_ACCEPT;
           *punFieldIds = 0;
           return IFX_FAILURE;
        }
				printf("\n Exit from Internal name data pkt decode in save\n");
        xIntNameList.axIntNameList[0].uiEditField = *punFieldIds;
        *punFieldIds = 0;
#if 1
        if((ucHandSetId > 0 && ucHandSetId <= IFX_DECTAPP_MAX_DECT_ENDPTS) && (!vaxPinInfo.aucPinEval[ucHandSetId-1])&&
						(xIntNameList.axIntNameList[0].uiEditField & IFX_DECT_LAU_IL_INTERCEPTION)){
          IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "Pin Verification Required.");
          pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_PIN_REQUIRED;
          return IFX_FAILURE;
        }
#endif
        xIntNameList.axIntNameList[0].nEntryId = pxSaveList->uxListCmd.xEntrySaveReq.nEntryId;

        if(IFX_SUCCESS == IFX_CIF_IntNameSet(&xIntNameList,IFX_DECTAPP_MODIFY)){
					*pnPositionId=xIntNameList.axIntNameList[0].nEntryId;
          memcpy(&((x_IFX_DECT_LAU_IntNameList*)pxSortedList)->axIntNameList[*pnPositionId-1],
                 &xIntNameList.axIntNameList[0],sizeof(x_IFX_DECT_LAU_IntNameListEntry));  
          return IFX_SUCCESS;
        }
        IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "IFX_CIF_IntNameSet failed.");
		}
    break;

    default:
       pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_PROC_NOT_SUPP;
       IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "Error!List not supported.");
       return IFX_FAILURE;
  }

  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	               "Failure.");
  pxSaveList->eNackReason = IFX_DECT_LAU_NACK_REASON_TEMP_NOT_POSS;
  return IFX_FAILURE; 
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_MissedCallNotify
 *  Description     : This Api is invoked when there is a change in the Missed
 *                    Call List(new entry added,read status changed,list deleted,
 *                    unread missed calls during locate request),to notify the PP(s) 
 *                    that the list is modified since last read operation.
 *  Input Values    : ucHandset - Handset Identifier 
 *                    pxOld - Old Missed Call List structure 
 *                    pxNew - New Missed Call List structure  
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
  IFX_DECTAPP_MissedCallNotify(IN uchar8 ucHandset,
			                         IN void *pxOld,
															 IN void *pxNew){

  uchar8 ucNoOfUnread = 0;
	uchar8 ucNoOfEntries = 0;
	uchar8 ucLineId =0;
	uchar8 aucLineIdRefresh[15] = "";
  x_IFX_DECT_LAU_MissedCallList xOldMissedCall = {0};
  x_IFX_DECT_LAU_MissedCallList xNewMissedCall = {0};
  int32 i=0,j=0;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "<IFX_DECTAPP_MissedCallNotify>Notification For Missed Call.");

if(IFX_DECTAPP_IsHandSetIdValid(ucHandset) != IFX_SUCCESS){
       IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_MissedCallNotify>Invalid HandsetId",ucHandset );
			 return IFX_FAILURE;
}

   if(vacAssocLines[ucHandset-1][0] == '\0'){ 
     if(IFX_FAILURE == IFX_CIF_AssocLineIdsGet(ucHandset,vacAssocLines[ucHandset-1])){

       IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_MissedCallNotify>IFX_CIF_AssocLineIdGet failed." );
			 return IFX_FAILURE;
     }
   }
  
	if((pxOld == NULL) && (pxNew == NULL)){
   

   IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			            "<IFX_DECTAPP_MissedCallNotify>Notification for Missed Call during Location Registration.");

   IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
  			            "<IFX_DECTAPP_MissedCallNotify>Notification for Missed Call for HS.",ucHandset);
   for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){

		 ucNoOfUnread = 0;ucNoOfEntries =0;
		 if(IFX_FAILURE == IFX_CIF_NoOfUnreadGet(vacAssocLines[ucHandset-1][i],&ucNoOfUnread)){
       IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			          "<IFX_DECTAPP_MissedCallNotify>IFX_CIF_NoOfUnreadGet failed");
       return IFX_FAILURE;
		 }	
     if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_MISSED_CALLS,vacAssocLines[ucHandset-1][i],&ucNoOfEntries)){
       IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "<IFX_DECTAPP_MissedCallNotify>IFX_CIF_NoOfEntriesGet failed");
       return IFX_FAILURE;
     }   
     IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
  			            "<IFX_DECTAPP_MissedCallNotify>Notification for Missed Call for line.",vacAssocLines[ucHandset-1][i]);
     IFX_DECT_LAU_MissedCallNotify(ucHandset,vacAssocLines[ucHandset-1][i],IFX_DECTAPP_MISS_SUBTYPE_READ,
									                 ucNoOfUnread,ucNoOfEntries); 

     IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "<IFX_DECTAPP_MissedCallNotify>Missed Call Notification Sent.");
	 }	 
	 return IFX_SUCCESS;
	}else{	

    if(IFX_SUCCESS == IFX_CIF_ListObjectGet(IFX_DECT_LAU_MISSED_CALLS,pxOld,(void *)&xOldMissedCall)){
      if(IFX_SUCCESS == IFX_CIF_ListObjectGet(IFX_DECT_LAU_MISSED_CALLS,pxNew,(void *)&xNewMissedCall)){

        if(xNewMissedCall.cNoOfEntries == 0){ /*Missed Call List Deleted*/ //TODO:Change when miss call comes under line.
          ucLineId = xOldMissedCall.axMissedCallList[0].ucLineId;
          IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                 "<IFX_DECTAPP_MissedCallNotify>Missed Call List Deleted for HS");
          for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){  
            if(ucLineId == vacAssocLines[ucHandset-1][i]){
              IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	                        "<IFX_DECTAPP_MissedCallNotify>Notifying Handset Id:",ucHandset);

              IFX_DECT_LAU_MissedCallNotify(ucHandset,vacAssocLines[ucHandset-1][i],IFX_DECTAPP_MISS_SUBTYPE_READ,0,0); 
              IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			           "<IFX_DECTAPP_MissedCallNotify>Missed Call Notification Sent.");
            }
          }
        }
        if((xNewMissedCall.cNoOfEntries > xOldMissedCall.cNoOfEntries)||
           ((xNewMissedCall.cNoOfEntries == xOldMissedCall.cNoOfEntries)&&
            (xNewMissedCall.axMissedCallList[0].nEntryId != xOldMissedCall.axMissedCallList[0].nEntryId))||
           ((xNewMissedCall.cNoOfEntries == xOldMissedCall.cNoOfEntries)&&
            (xNewMissedCall.axMissedCallList[0].nEntryId == xOldMissedCall.axMissedCallList[0].nEntryId)&&
            (xNewMissedCall.axMissedCallList[0].bNew == 1))){/* New Entry Added */
						printf("ReadN %d Reado %d EntryN %d,Entryo %d,NoN %d,Noo %d\n",xNewMissedCall.axMissedCallList[0].bNew,
													xOldMissedCall.axMissedCallList[0].bNew,xNewMissedCall.axMissedCallList[0].nEntryId,
													xOldMissedCall.axMissedCallList[0].nEntryId,xNewMissedCall.cNoOfEntries,xOldMissedCall.cNoOfEntries);

	/* Latter Case when max entries reached i.e. 5 and new entry pushes first entry out of list. */

          ucLineId = xNewMissedCall.axMissedCallList[0].ucLineId;
          IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                 "<IFX_DECTAPP_MissedCallNotify>Missed Call List New Entry");
      
          for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){  

            if(ucLineId == vacAssocLines[ucHandset-1][i]){
                IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	                        "<IFX_DECTAPP_MissedCallNotify>Notifying Handset Id:",ucHandset);

	        ucNoOfUnread = 0;ucNoOfEntries=0;
                if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_MISSED_CALLS,
		                                   vacAssocLines[ucHandset-1][i],&ucNoOfEntries)){
                  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                   "<IFX_DECTAPP_MissedCallNotify>IFX_CIF_NoOfEntriesGet failed");
                  return IFX_FAILURE;
                }   
		 if(IFX_FAILURE == IFX_CIF_NoOfUnreadGet(vacAssocLines[ucHandset-1][i],&ucNoOfUnread)){
                  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                  "<IFX_DECTAPP_MissedCallNotify>IFX_CIF_NoOfUnreadGet failed");
                  return IFX_FAILURE;
				        }	
                IFX_DECT_LAU_MissedCallNotify(ucHandset,vacAssocLines[ucHandset-1][i],IFX_DECTAPP_MISS_SUBTYPE_NEW,
											                                ucNoOfUnread,ucNoOfEntries); 
                IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                  "<IFX_DECTAPP_MissedCallNotify>Missed Call Notification Sent.");

								break;
						}		
					}	 
          return IFX_SUCCESS;
         }else if(xNewMissedCall.cNoOfEntries == xOldMissedCall.cNoOfEntries){ /*Read Status Changed*/ 

            for(j=0;j<xNewMissedCall.cNoOfEntries;j++){
              if(xNewMissedCall.axMissedCallList[j].bNew != xOldMissedCall.axMissedCallList[j].bNew){
                IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	                        "<IFX_DECTAPP_MissedCallNotify>Notifying Handset Id:",ucHandset);

                IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                                   "<IFX_DECTAPP_MissedCallNotify>Missed Call List Read Status changed." );
                ucLineId = xNewMissedCall.axMissedCallList[j].ucLineId;
		
		if(ucLineId > 0 && ucLineId<IFX_DECTAPP_MAX_LINES && !aucLineIdRefresh[ucLineId-1]){
	 	  aucLineIdRefresh[ucLineId-1] = 1;
                }else{
                  IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                                   "<IFX_DECTAPP_MissedCallNotify>Notification already sent for this line." );
		  continue;
	        }	

                 for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){
                   if(ucLineId == vacAssocLines[ucHandset-1][i]){

						         ucNoOfUnread = 0;ucNoOfEntries = 0;
                     if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_MISSED_CALLS,
			                                      vacAssocLines[ucHandset-1][i],&ucNoOfEntries)){
                       IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                    "<IFX_DECTAPP_MissedCallNotify>IFX_CIF_NoOfEntriesGet failed");
                       return IFX_FAILURE;
                     }   
	             if(IFX_FAILURE == IFX_CIF_NoOfUnreadGet(vacAssocLines[ucHandset-1][i],&ucNoOfUnread)){
                       IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                                 "<IFX_DECTAPP_MissedCallNotify>IFX_CIF_NoOfUnreadGet failed");
                       return IFX_FAILURE;
				             }	
                     IFX_DECT_LAU_MissedCallNotify(ucHandset,vacAssocLines[ucHandset-1][i],
			                           IFX_DECTAPP_MISS_SUBTYPE_READ,
                                                     ucNoOfUnread,ucNoOfEntries);
                     IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                      "<IFX_DECTAPP_MissedCallNotify>Missed Call Notification Sent.");
                     break;
                   }
                 }
                }
              }
            }else if(xNewMissedCall.cNoOfEntries < xOldMissedCall.cNoOfEntries){/* Entry Deleted */

        for(i=0;i<xOldMissedCall.cNoOfEntries;i++){
			   if(xOldMissedCall.axMissedCallList[i].nEntryId != xNewMissedCall.axMissedCallList[i].nEntryId){
           ucLineId = xOldMissedCall.axMissedCallList[i].ucLineId;
         }
        }
          IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                 "<IFX_DECTAPP_MissedCallNotify>Missed Call List Entry Delete");
      
          for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){  

            if(ucLineId == vacAssocLines[ucHandset-1][i]){
              IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	                        "<IFX_DECTAPP_MissedCallNotify>Notifying Handset Id:",ucHandset);

	    ucNoOfUnread = 0;ucNoOfEntries=0;
                if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_MISSED_CALLS,
											                                   vacAssocLines[ucHandset-1][i],&ucNoOfEntries)){
                  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                   "<IFX_DECTAPP_MissedCallNotify>IFX_CIF_NoOfEntriesGet failed");
                  return IFX_FAILURE;
                }   
				        if(IFX_FAILURE == IFX_CIF_NoOfUnreadGet(vacAssocLines[ucHandset-1][i],&ucNoOfUnread)){
                  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                  "<IFX_DECTAPP_MissedCallNotify>IFX_CIF_NoOfUnreadGet failed");
                  return IFX_FAILURE;
				        }	
                IFX_DECT_LAU_MissedCallNotify(ucHandset,vacAssocLines[ucHandset-1][i],IFX_DECTAPP_MISS_SUBTYPE_READ,
											                                ucNoOfUnread,ucNoOfEntries); 
                IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                  "<IFX_DECTAPP_MissedCallNotify>Missed Call Notification Sent.");

								break;
						}		
					}	 
          return IFX_SUCCESS;
         }
          
          return IFX_SUCCESS;
        }
			}		
      return IFX_FAILURE;
	 }	
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_OutgoingCallNotify
 *  Description     : This Api is invoked when there is a change in the Outgoing
 *                    Call List(when a new entry gets added or list is deleted),
 *                    to notify the PP(s) that the list is modified since last read
 *                    operation. 
 *  Input Values    : ucHandset - Handset Identifier 
 *                    pxOld - Old Outgoing Call List structure 
 *                    pxNew - New Outgoing Call List structure  
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
  IFX_DECTAPP_OutgoingCallNotify(IN uchar8 ucHandset,
			                           IN void *pxOld,
															   IN void *pxNew){

   x_IFX_DECT_LAU_OutgoingCallList xOldOutgoingCall = {0};
   x_IFX_DECT_LAU_OutgoingCallList xNewOutgoingCall = {0};
	 uchar8 ucNoOfEntries = 0;
	 uchar8 ucLineId =0;
	 int32 i=0;

   IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
								"<IFX_DECTAPP_OutgoingCallNotify>Notification For Outgoing Call.");

   if(IFX_SUCCESS == IFX_CIF_ListObjectGet(IFX_DECT_LAU_OUTGOING_CALLS,pxOld,(void *)&xOldOutgoingCall)){
		 if(IFX_SUCCESS == IFX_CIF_ListObjectGet(IFX_DECT_LAU_OUTGOING_CALLS,pxNew,(void *)&xNewOutgoingCall)){

       if(ucHandset > 0 && ucHandset <= IFX_DECTAPP_MAX_DECT_ENDPTS && vacAssocLines[ucHandset-1][0] == '\0'){ 
         if(IFX_FAILURE == IFX_CIF_AssocLineIdsGet(ucHandset,vacAssocLines[ucHandset-1])){

           IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_OutgoingCallNotify>IFX_CIF_AssocLineIdGet failed." );
			     return IFX_FAILURE;
         }
       }

if(IFX_DECTAPP_IsHandSetIdValid(ucHandset) != IFX_SUCCESS){
           IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_OutgoingCallNotify>Invalid Handset ID ...." );
			     return IFX_FAILURE;
}


       if(xNewOutgoingCall.cNoOfEntries == 0){ /*Outgoing Call List Deleted*/
          ucLineId = xOldOutgoingCall.axOutgoingCallList[0].ucLineId;
          IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                 "<IFX_DECTAPP_OutgoingCallNotify>Outgoing Call List Deleted");

          for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){  

            if(ucHandset > 0 && ucHandset <= IFX_DECTAPP_MAX_DECT_ENDPTS && ucLineId == vacAssocLines[ucHandset-1][i]){
               IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	                        "<IFX_DECTAPP_OutgoingCallNotify>Notifying Handset Id:",ucHandset);
              IFX_DECT_LAU_ListChangeNotify(ucHandset,0,IFX_DECT_LAU_OUTGOING_CALLS,0); 
              IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			          "<IFX_DECTAPP_OutgoingCallNotify>Outgoing Call Notification Sent.");
            }
         }
       }

       if((xNewOutgoingCall.cNoOfEntries > xOldOutgoingCall.cNoOfEntries)||((xNewOutgoingCall.cNoOfEntries == xOldOutgoingCall.cNoOfEntries)
						  &&(xNewOutgoingCall.axOutgoingCallList[0].nEntryId != xOldOutgoingCall.axOutgoingCallList[0].nEntryId))){ /*New Entry Added*/

         ucLineId = xNewOutgoingCall.axOutgoingCallList[0].ucLineId;
         IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                 "<IFX_DECTAPP_OutgoingCallNotify>Outgoing Call List New Entry");
				 for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){
      
          if(ucLineId == vacAssocLines[ucHandset-1][i]){
             IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	                        "<IFX_DECTAPP_OutgoingCallNotify>Notifying Handset Id:",ucHandset);

						ucNoOfEntries = 0;
            if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_OUTGOING_CALLS,
											                               vacAssocLines[ucHandset-1][i],&ucNoOfEntries)){
              IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                   "<IFX_DECTAPP_OutgoingCallNotify>IFX_CIF_NoOfEntriesGet failed");
              return IFX_FAILURE;
            }   

            IFX_DECT_LAU_ListChangeNotify(ucHandset,vacAssocLines[ucHandset-1][i],IFX_DECT_LAU_OUTGOING_CALLS,
								                          ucNoOfEntries);
            IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			             "<IFX_DECTAPP_OutgoingCallNotify>Outgoing Call Notification Sent.");

						break;
          }
				 }
			 }else if(xNewOutgoingCall.cNoOfEntries < xOldOutgoingCall.cNoOfEntries)
						 { /*Entry Deleted*/

                           for(i=0;i<xOldOutgoingCall.cNoOfEntries;i++){
			   if(xOldOutgoingCall.axOutgoingCallList[i].nEntryId != xNewOutgoingCall.axOutgoingCallList[i].nEntryId){
           ucLineId = xOldOutgoingCall.axOutgoingCallList[i].ucLineId;
         }
        }
         IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                 "<IFX_DECTAPP_OutgoingCallNotify>Outgoing Call List Entry Deleted");
				 for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){
      
          if(ucLineId == vacAssocLines[ucHandset-1][i]){

						ucNoOfEntries = 0;
            if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_OUTGOING_CALLS,
											                               vacAssocLines[ucHandset-1][i],&ucNoOfEntries)){
              IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                   "<IFX_DECTAPP_OutgoingCallNotify>IFX_CIF_NoOfEntriesGet failed");
              return IFX_FAILURE;
            }   

            IFX_DECT_LAU_ListChangeNotify(ucHandset,vacAssocLines[ucHandset-1][i],IFX_DECT_LAU_OUTGOING_CALLS,
								                          ucNoOfEntries);
            IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			             "<IFX_DECTAPP_OutgoingCallNotify>Outgoing Call Notification Sent.");

						break;
          }
				 }
			 }
			 return IFX_SUCCESS;
		 }
	 }	 
	 return IFX_FAILURE;
}		

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_IncomingCallNotify
 *  Description     : This Api is invoked when there is a change in the Incoming
 *                    Call List(new entry added in the list or list deleted),
 *                    to notify the PP(s) that the list is modified since last read
 *                    operation. 
 *  Input Values    : ucHandset - Handset Identifier 
 *                    pxOld - Old Incoming Call List structure 
 *                    pxNew - New Incoming Call List structure  
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
  IFX_DECTAPP_IncomingCallNotify(IN uchar8 ucHandset,
			                           IN void *pxOld,
															   IN void *pxNew){


  x_IFX_DECT_LAU_IncomingCallList xOldIncomingCall = {0};
  x_IFX_DECT_LAU_IncomingCallList xNewIncomingCall = {0};
  uchar8 ucNoOfEntries = 0;
	uchar8 ucLineId =0;
	int32 i = 0;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
								"<IFX_DECTAPP_IncomingCallNotify>Notification For Incoming Call.");

  if(IFX_SUCCESS == IFX_CIF_ListObjectGet(IFX_DECT_LAU_INCOMING_ACCEPT_CALLS,pxOld,(void *)&xOldIncomingCall)){
   if(IFX_SUCCESS == IFX_CIF_ListObjectGet(IFX_DECT_LAU_INCOMING_ACCEPT_CALLS,pxNew,(void *)&xNewIncomingCall)){

     if(ucHandset > 0 && ucHandset <= IFX_DECTAPP_MAX_DECT_ENDPTS && vacAssocLines[ucHandset-1][0] == '\0'){ 
        if(IFX_FAILURE == IFX_CIF_AssocLineIdsGet(ucHandset,vacAssocLines[ucHandset-1])){

          IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_IncomingCallNotify>IFX_CIF_AssocLineIdGet failed." );
			    return IFX_FAILURE;
        }
     }

if(IFX_DECTAPP_IsHandSetIdValid(ucHandset) != IFX_SUCCESS){
           IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<IFX_DECTAPP_IncomingCallNotify>Invalid Handset ID ...." );
           return IFX_FAILURE;
}

     if(xNewIncomingCall.cNoOfEntries == 0){ /*Missed Call List Deleted*/
          ucLineId = xOldIncomingCall.axIncomingCallList[0].ucLineId;
          IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                 "<IFX_DECTAPP_IncomingCallNotify>Incoming Call List Deleted");


          for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){  

            if(ucLineId == vacAssocLines[ucHandset-1][i]){
               IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	                        "<IFX_DECTAPP_IncomingCallNotify>Notifying Handset Id:",ucHandset);
               IFX_DECT_LAU_ListChangeNotify(ucHandset,0,IFX_DECT_LAU_INCOMING_ACCEPT_CALLS,0); 
               IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
								"<IFX_DECTAPP_IncomingCallNotify>Incoming Call Notification Sent.");
            }
         }
     }

     if(xNewIncomingCall.cNoOfEntries > xOldIncomingCall.cNoOfEntries){ /*New Entry Added*/

       ucLineId = xNewIncomingCall.axIncomingCallList[0].ucLineId;

       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                 "<IFX_DECTAPP_IncomingCallNotify>Incoming Call List New Entry");

			 for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){
         if(ucLineId == vacAssocLines[ucHandset-1][i]){

					 ucNoOfEntries = 0;
           if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_OUTGOING_CALLS,
											                               vacAssocLines[ucHandset-1][i],&ucNoOfEntries)){
             IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                   "<IFX_DECTAPP_IncomingCallNotify>IFX_CIF_NoOfEntriesGet failed");
             return IFX_FAILURE;
           }   

           IFX_DECT_LAU_ListChangeNotify(ucHandset,vacAssocLines[ucHandset-1][i],IFX_DECT_LAU_INCOMING_ACCEPT_CALLS,
								                          ucNoOfEntries);
           IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					    			"<IFX_DECTAPP_IncomingCallNotify>Incoming Call Notification Sent.");

					 break;
         }
			 }
		 } else if(xNewIncomingCall.cNoOfEntries > xOldIncomingCall.cNoOfEntries){ /*Entry Deleted*/

                          for(i=0;i<xOldIncomingCall.cNoOfEntries;i++){
			   if(xOldIncomingCall.axIncomingCallList[i].nEntryId != xNewIncomingCall.axIncomingCallList[i].nEntryId){
           ucLineId = xOldIncomingCall.axIncomingCallList[i].ucLineId;
         }
        }

       IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                 "<IFX_DECTAPP_IncomingCallNotify>Incoming Call List New Entry");

			 for(i=0;vacAssocLines[ucHandset-1][i] != '\0';i++){
         if(ucLineId == vacAssocLines[ucHandset-1][i]){

					 ucNoOfEntries = 0;
           if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_OUTGOING_CALLS,
											                               vacAssocLines[ucHandset-1][i],&ucNoOfEntries)){
             IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			                   "<IFX_DECTAPP_IncomingCallNotify>IFX_CIF_NoOfEntriesGet failed");
             return IFX_FAILURE;
           }   

           IFX_DECT_LAU_ListChangeNotify(ucHandset,vacAssocLines[ucHandset-1][i],IFX_DECT_LAU_INCOMING_ACCEPT_CALLS,
								                          ucNoOfEntries);
           IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
					    			"<IFX_DECTAPP_IncomingCallNotify>Incoming Call Notification Sent.");

					 break;
         }
			 }
		 }
		 return IFX_SUCCESS;
	 }	 
	}	 
	return IFX_FAILURE;
}		


/******************************************************************************
 *  Function Name   : IFX_DECTAPP_InternalNamesNotify
 *  Description     : This Api is invoked when there is a change in the Internal
 *                    Names List(PP name modified or new entry during attachment),
 *                    to notify the PP(s) that the list is modified since last read
 *                    operation. 
 *  Input Values    : ucHandset - Handset Identifier 
 *                    pxOld - Old Internal Names List structure 
 *                    pxNew - New Internal Names List structure  
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
  IFX_DECTAPP_InternalNamesNotify(IN uchar8 ucHandset,
			                            IN void *pxOld,
															    IN void *pxNew){

   uchar8 ucNoOfEntries = 0;
   uchar8 ucModPPId = 0;

   IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			    "<IFX_DECTAPP_InternalNamesNotify>Notification for Internal Names List.");

   if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_INTERNAL_NAMES,0,&ucNoOfEntries)){
     IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "<IFX_DECTAPP_InternalNamesNotify>IFX_CIF_NoOfEntriesGet failed");
     return IFX_FAILURE;
   }   

	 if((pxOld == NULL) && (pxNew == NULL)){

     IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			       "<IFX_DECTAPP_InternalNamesNotify>Notification for Internal Names List during Location Registration.");
     IFX_DECT_LAU_ListChangeNotify(ucHandset,0,IFX_DECT_LAU_INTERNAL_NAMES,ucNoOfEntries); 
	 }else{	 
     /*In case a handset is unregistered,ucModPPId is 0.In case a new Handset gets registered ucModPPId contains the 
       Handset Id for registered HS + IFX_DECTAPP_MAX_DECT_ENDPTS.In case of newly registered handset,notify all other
       handsets because the registered handset gets notified on location registration.*/

     if(IFX_FAILURE == IFX_CIF_ModifiedNamePP(pxOld,pxNew,&ucModPPId)){
        IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  		    	    "<IFX_DECTAPP_InternalNamesNotify>IFX_CIF_ModifiedNamePP failed");
        return IFX_FAILURE; 
     }
      
		 if((ucModPPId == 0)||((ucHandset+IFX_DECTAPP_MAX_DECT_ENDPTS) != ucModPPId)||(ucModPPId != vucNotifyIgnore[IFX_DECT_LAU_INTERNAL_NAMES-1])){
			 	 
       IFX_DECT_LAU_ListChangeNotify(ucHandset,0,IFX_DECT_LAU_INTERNAL_NAMES,ucNoOfEntries); 
       IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  		    	    "<IFX_DECTAPP_InternalNamesNotify>Internal Names Notification sent.");

		 }else if(ucModPPId == vucNotifyIgnore[IFX_DECT_LAU_INTERNAL_NAMES-1]){//Handset modified its own name. 
		   vucNotifyIgnore[IFX_DECT_LAU_INTERNAL_NAMES-1] = 0;
      }
	  }
	 return IFX_SUCCESS; 
}  

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LineSettingsNotify
 *  Description     : This Api is invoked when there is a change in the Line
 *                    Settings List(HS Assoc Changes,Change in Calling Features,Line
 *                    Add/Delete operation),to notify the PP(s) that the list is 
 *                    modified since last read operation. 
 *  Input Values    : ucHandset - Handset Identifier 
 *                    pxOld - Old Line Settings List structure 
 *                    pxNew - New Line Settings List structure  
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
  IFX_DECTAPP_LineSettingsNotify(IN uchar8 ucHandset,
			                           IN uchar8 ucLineObjType,
			                           IN void *pxOld,
															   IN void *pxNew){

	uchar8 ucLineId = 0;	
  uchar8 ucNoOfEntries = 0;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "<IFX_DECTAPP_LineSettingsNotify>Notification for Line Settings List.");

  if((ucHandset > 0 && ucHandset <= IFX_DECTAPP_MAX_DECT_ENDPTS) && (ucLineObjType == IFX_DECTAPP_LINEOBJ_LINEASSOC || ucLineObjType == IFX_DECTAPP_LINEOBJ_PSTN)){

	  memset(vacAssocLines[ucHandset-1],0,sizeof(IFX_DECTAPP_MAX_LINES));
    if(IFX_FAILURE == IFX_CIF_AssocLineIdsGet(ucHandset,vacAssocLines[ucHandset-1])){
       IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	           "<IFX_DECTAPP_LineSettingsNotify>IFX_CIF_AssocLineIdsGet failed." );
			 return IFX_FAILURE;
    }
  }

	if(IFX_DECTAPP_IsHandSetIdValid(ucHandset) != IFX_SUCCESS){
           IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<IFX_DECTAPP_IncomingCallNotify>Invalid Handset ID ...." );
           return IFX_FAILURE;
	}

  if(ucLineObjType == IFX_DECTAPP_LINEOBJ_LINEASSOC){

		if(IFX_SUCCESS != IFX_CIF_LineChange(pxOld,pxNew,&ucLineId)){
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "<IFX_DECTAPP_LineSettingsNotify>IFX_CIF_LineChange failed.");
			return IFX_FAILURE;
		}  
	}else if(ucLineObjType == IFX_DECTAPP_LINEOBJ_CALLFEAT){

		if(IFX_SUCCESS != IFX_CIF_CallFeatChange(pxOld,pxNew,&ucLineId)){
      IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "<IFX_DECTAPP_LineSettingsNotify>IFX_CIF_CallFeatChange failed.");
			return IFX_FAILURE;
		}	
	 }else if(ucLineObjType == IFX_DECTAPP_LINEOBJ_PSTN){
     
		 if(IFX_SUCCESS != IFX_CIF_PSTNLineChange(pxOld,pxNew,&ucLineId)){
       IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	         "<IFX_DECTAPP_LineSettingsNotify>IFX_CIF_PSTNLineChange failed.");
			 return IFX_FAILURE;
		 }  
    }	
    if(!ucLineId){//All Lines

      if(IFX_FAILURE == IFX_CIF_NoOfEntriesGet(IFX_DECT_LAU_LINE_SETTINGS,0,&ucNoOfEntries)){
         IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "<IFX_DECTAPP_LineSettingsNotify>IFX_CIF_NoOfEntriesGet failed");
         return IFX_FAILURE;
      }   
    }else{//Specific Line
      ucNoOfEntries = 1; 
     }
    IFX_DECT_LAU_ListChangeNotify(ucHandset,ucLineId,IFX_DECT_LAU_LINE_SETTINGS,ucNoOfEntries);
    IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
	             "<IFX_DECTAPP_LineSettingsNotify>Line Settings List Notification sent.");
	  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_ContactListNotify
 *  Description     : This Api is invoked when there is a change in the Contact
 *                    List(Edit/Add/Delete op),to notify the PP that the list is
 *                    modified since last read operation. 
 *  Input Values    : ucHandset - Handset Identifier 
 *                    pxOld - Old Contact List structure 
 *                    pxNew - New Contact List structure  
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
  IFX_DECTAPP_ContactListNotify(IN uchar8 ucHandset,
			                          IN void *pxOld,
															  IN void *pxNew)
{
  uchar8 ucNoOfEntries = 0;
  uchar8 ucLineId = 0;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "Notification For Contact List.");
	if(NULL == pxNew) {
  		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Invalid In Params");
			return IFX_FAILURE;
	}
	IFX_CIF_GetContactListInfoFromVmapiObj(pxNew,&ucLineId,&ucNoOfEntries);
	/*printf("<DectApp_ContNotify> LineId = %d NoOfEntries =%d\n",ucLineId,ucNoOfEntries);*/
	
  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,"Number of Entries",ucNoOfEntries);


	if(vucNotifyIgnore[IFX_DECT_LAU_CONTACT_LIST-1] != ucHandset){
    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	            "Notifying Handset Id:",ucHandset);
    IFX_DECT_LAU_ListChangeNotify(ucHandset,ucLineId,IFX_DECT_LAU_CONTACTS,ucNoOfEntries);//Check Edit Entry
    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "Contact List Notification Sent.");
	}
	else {	
  		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Ignore");
  	vucNotifyIgnore[IFX_DECT_LAU_CONTACTS-1] = 0;
	}
  return IFX_SUCCESS;
}	

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_SystemSettingsNotify
 *  Description     : This Api is invoked when there is a change in the System
 *                    Settings List(change in mandatory param or base reset),
 *                    to notify the PP that the list is modified since last read 
 *                    operation. 
 *  Input Values    : ucHandset - Handset Identifier 
 *                    pxOld - Old System Settings List structure 
 *                    pxNew - New System Settings List structure  
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
  IFX_DECTAPP_SystemSettingsNotify(IN uchar8 ucHandset,
			                          IN void *pxOld,
															  IN void *pxNew)
{

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "Notification For System Settings List.");

	if(vucNotifyIgnore[IFX_DECT_LAU_SYS_SETTINGS-1] != ucHandset){
    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
	            "Notifying Handset Id:",ucHandset);
    if(IFX_FAILURE == IFX_CIF_SystemChange(pxOld,pxNew)){
      return IFX_FAILURE;
    }
    IFX_DECT_LAU_ListChangeNotify(ucHandset,0,IFX_DECT_LAU_SYS_SETTINGS,1);
    IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "System Settings List Notification Sent.");
	}else{	
  		IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Ignore");
  	vucNotifyIgnore[IFX_DECT_LAU_SYS_SETTINGS-1] = 0;
	}
  return IFX_SUCCESS;
}	
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_LinkRelease
 *  Description     : This callback function is used to clean up local data
 *  Input Values    : None
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_DECTAPP_LAU_LinkRelease(uchar8 ucHandsetID)
{

if(IFX_DECTAPP_IsHandSetIdValid(ucHandsetID) != IFX_SUCCESS){
           IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
             "<IFX_DECTAPP_LAU_LinkRelease>Invalid Handset ID ...." );
           return IFX_FAILURE;
}

  vaxPinInfo.aucPinEval[ucHandsetID-1] = 0;
  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_LAU_Init
 *  Description     : This Api specifies the lists supported and the callbacks 
 *                    thereby invoking IFX_DECT_LAU_Init and 
 *                    IFX_DECT_LAU_CallBksRegister Apis of the DECT Tk.
 *  Input Values    : None
 *  Output Values	  : None
 *  Return Value    : IFX_SUCCESS/ IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_DECTAPP_LAU_Init(){

  x_IFX_DECT_LAU_CallBks xLAUCallBks;

  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "<IFX_DECTAPP_LAU_Init>Entry");
  /*auiList is a 2 dim array which stores list supported and supported fields map
    for that list in each 1 dim array*/
#ifdef LTQ_DT_SUPPORT 
 uint32 auiList[IFX_DECT_LAU_MAX_SUPPORTED_LISTS+ 1 + IFX_DT_LAU_MAX_PROP_LISTS][2]= 
#else 
 uint32 auiList[IFX_DECT_LAU_MAX_SUPPORTED_LISTS+1][2]=
#endif 
                       {{IFX_DECT_LAU_MISSED_CALLS,0},
                  	    {IFX_DECT_LAU_OUTGOING_CALLS,0},
	                      {IFX_DECT_LAU_INCOMING_ACCEPT_CALLS,0},  
                        {IFX_DECT_LAU_ALL_CALLS,0},
	                      {IFX_DECT_LAU_CONTACTS,0},
	                      {IFX_DECT_LAU_SYS_SETTINGS,0},
	                      {IFX_DECT_LAU_LINE_SETTINGS,0},
												{IFX_DECT_LAU_INTERNAL_NAMES,0},
                        {IFX_DECT_LAU_ALL_INCOMING_CALLS,0},
#ifdef LTQ_DT_SUPPORT 
                        {IFX_DT_LAU_RSS_CHANNEL_LIST,0},
                        {IFX_DT_LAU_NET_PHONE_BOOK,0},
                        {IFX_DT_LAU_EMAIL_ACCOUNT_LIST,0},
#endif
                        {0,0}};
	
  IFX_DECTAPP_PopulateSupportedFieldMap((uint32*)auiList);
	
#ifdef LTQ_DT_SUPPORT 
  IFX_DECT_LAU_Init((uint32*)auiList,0x1181);
#else 
  IFX_DECT_LAU_Init((uint32*)auiList,0);
#endif
  xLAUCallBks.pfnSessionStart = IFX_DECTAPP_LAU_StartSession;
  xLAUCallBks.pfnSessionEnd = IFX_DECTAPP_LAU_SessionEnd;
  xLAUCallBks.pfnFieldQuery = IFX_DECTAPP_LAU_FieldQuery; 
  xLAUCallBks.pfnEntryRead = IFX_DECTAPP_LAU_ReadEntries; 
  xLAUCallBks.pfnEntryEdit = IFX_DECTAPP_LAU_EditEntries;     
  xLAUCallBks.pfnEntrySave = IFX_DECTAPP_LAU_SaveEntry;    
  xLAUCallBks.pfnEntryDelete = IFX_DECTAPP_LAU_EntryDelete;      
  xLAUCallBks.pfnListDelete = IFX_DECTAPP_LAU_ListDelete; 
  xLAUCallBks.pfnEntrySearch = IFX_DECTAPP_LAU_SearchEntries;   
  xLAUCallBks.pfnDataPktRecv = IFX_DECTAPP_LAU_DataRecv;
  xLAUCallBks.pfnLinkRelease = IFX_DECTAPP_LAU_LinkRelease;
#ifdef LTQ_DT_SUPPORT 
	xLAUCallBks.pfnSessionMove = IFX_DECTAPP_LAU_MoveSession;
#endif
	
  IFX_DECT_LAU_CallBksRegister(&xLAUCallBks);
  IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  			   "<IFX_DECTAPP_LAU_Init>Success");
  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_PopulateSupportedFieldMap
 *  Description     : This internal Api specifies the lists supported and the 
 *                    supported fields for the same and populates in a two 
 *                    dimensional array with the first column indicating List Id
 *                    and second column Supported fields map. 
 *  Input Values    : puiList - Indicates List Supported 
 *  Output Values	  : puiList - Supported Field map populated
 *  Return Value    : None
 *  Notes           :
 ****************************************************************************/
void
IFX_DECTAPP_PopulateSupportedFieldMap(IN OUT uint32 *puiList){

  int32 i=0;
#ifdef LTQ_DT_SUPPORT
	uint32 ucListId;
#endif
  while(*puiList != '\0'){
#ifdef LTQ_DT_SUPPORT
    ucListId=*puiList;
	printf("List Id--%d Pointer value--%d pointer --%p\n",ucListId,*puiList,puiList);
		if(IFX_DECTAPP_isProprietaryList(ucListId) == IFX_SUCCESS ){
	 		//ucListId=IFX_DECTAPP_getListAccessListId(ucListId);
			IFX_DT_PopulateSupportedFieldMap(puiList);
		}else{
#endif
   				/*Populate supported field map with editable fields.*/
			   for(i=0;i<vacEditableFields[*puiList-1][0];i++){
     				*(puiList+1) |=                                                                                                                          
			       	1<<(vacEditableFields[*puiList-1][i+1]-1); 
   			}
			   /*Populate supported field map with uneditable fields.*/
			   for(i=0;i<vacUnEditableFields[*puiList-1][0];i++){
        *(puiList+1) |=                                                                                                                          
     	  1<<(vacUnEditableFields[*puiList-1][i+1]-1); 
   }

#ifdef LTQ_DT_SUPPORT
	}
#endif
   /*Increment by two to point to next list Id.*/
   puiList += 2;
  }
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_SortList
 *  Description     : This internal Api uses merge sort technique to sort an array.
 *                    The array here comprises of addresses of elements to be sorted
 *                    which are then typecast to the appropriate type and compared
 *                    on the basis of default sorting fields. 
 *  Input Values    : min_index - minimum index in the list to be sorted
 *                    max_index - maximum index in the list to be sorted
 *                    iSortedArray - integer array containing addresses of list entry
 *                    structures.
 *  Output Values	  : iSortedArray - integer array containing addresses of list entry
 *                    structures in sorted order.  
 *  Return Value    : None
 *  Notes           : The entries at addresses in the array are sorted and 
 *                    sorted addresses are stored back in the array. 
 ****************************************************************************/
void IFX_DECTAPP_SortList(IN int32 min_index, 
                          IN int32 max_index,
                          IN OUT int32 iSortedArray[],
                          IN uchar8 ucListId){

   if (min_index<max_index){

     int32 mid=(min_index+max_index)/2;
     IFX_DECTAPP_SortList(min_index, mid,iSortedArray,ucListId);
     IFX_DECTAPP_SortList(mid+1, max_index,iSortedArray,ucListId);
     IFX_DECTAPP_MergeSortedLists(min_index, mid, max_index,iSortedArray,ucListId);
   }
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_MergeSortedLists
 *  Description     : This internal Api merges the two sorted sub-lists divided at 
 *                    mid(mid being part of first sub-list) into one.The two sub-lists
 *                    contain addresses of list elements in sorted order. 
 *  Input Values    : min_index - minimum index in the list
 *                    mid - index that divides the two sorted sub-lists
 *                    max_index - maximum index in the list
 *                    iSortedArray - integer array containing addresses of list entry
                      structures divided at mid(mid being part of first list)into two
										  sorted sub-lists,each containing addresses of entries in sorted
											order.
 *                    ucListId - List Identifier
 *  Output Values	  : iSortedArray - The two sorted sub-lists are merged to form a 
 *                    single sorted array containing addresses of list entries in
 *                    sorted order. 
 *  Return Value    : None
 *  Notes           :
 ****************************************************************************/
void IFX_DECTAPP_MergeSortedLists(IN int32 min_index, 
                                  IN int32 mid, 
                                  IN int32 max_index,
                                  IN OUT int32 iSortedArray[],
                                  IN uchar8 ucListId){

  int32 i, j, k;
  uint32 *uiAux_array;

  uiAux_array=(uint32*)malloc(sizeof(uint32)*(max_index+1));
	if(uiAux_array == NULL)
		return;

  memset(uiAux_array,0,sizeof(uint32)*(max_index+1));

  for(i=min_index; i<=max_index; i++){
     uiAux_array[i] = iSortedArray[i];
  }
  i=min_index; j=mid+1; k=min_index;

  while (i<=mid && j<=max_index){

    if (IFX_DECTAPP_Compare(uiAux_array[i],uiAux_array[j],ucListId,0)<=0){
      iSortedArray[k++]=uiAux_array[i++];
    }else{
      iSortedArray[k++]=uiAux_array[j++];
     }
  }
  while (i<=mid){
    iSortedArray[k++]=uiAux_array[i++];
  }
  free(uiAux_array);
}
/******************************************************************************
 *  Function Name   : IFX_DECTAPP_Compare1
 *  Description     : This internal Api compares the two list entries at addresses
 *                    specified by uiEntryAddrA and uiEntryAddrB and indicates whether first entry 
 *                    is greater than,equal to or less than second.
 *  Input Values    : uiEntryAddrA - address of first entry
 *                    uiEntryAddrB - address of second entry
 *                    ucListId - List Identifier
 *                    ucIsCaseSense - Case sensitive/insensitive search
 *  Output Values	  : None
 *  Return Value    : integer -> -1,0,1
 *  Notes           :
 ****************************************************************************/
int32 IFX_DECTAPP_Compare1(IN uint32 uiEntryAddrA,IN uint32 uiEntryAddrB,
		                      IN uchar8 ucListId,
										  IN uchar8 ucIsCaseSense){
    int32 iRet = 0;
    switch(ucListId){

      case IFX_DECT_LAU_CONTACTS:
      {  
           if(ucIsCaseSense){
              iRet = strncmp(((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrA))->acLastName,
                                    ((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrB))->acLastName,
												strlen(((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrA))->acLastName));
              IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
  			               "String Case Compare",iRet);
			  return ((iRet==0)?0:((iRet >0)?-1:1)); 	
           }else{
				 
				 printf("Search Value is %s and String 1 is %s \n",
						  ((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrA))->acLastName,
						   ((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrB))->acLastName);
				 
             iRet = strncasecmp(((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrA))->acLastName,
                                    ((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrB))->acLastName,
												strlen(((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrA))->acLastName));
              IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
  			               "String case insensitive compare",iRet);
           }
			  return ((iRet==0)?0:((iRet >0)?1:-1)); 	
      }
      break;
     default:
          break;
    }
    return 1;
}


/******************************************************************************
 *  Function Name   : IFX_DECTAPP_Compare
 *  Description     : This internal Api compares the two list entries at addresses
 *                    specified by uiEntryAddrA and uiEntryAddrB and indicates whether first entry 
 *                    is greater than,equal to or less than second.
 *  Input Values    : uiEntryAddrA - address of first entry
 *                    uiEntryAddrB - address of second entry
 *                    ucListId - List Identifier
 *                    ucIsCaseSense - Case sensitive/insensitive search
 *  Output Values	  : None
 *  Return Value    : integer -> -1,0,1
 *  Notes           :
 ****************************************************************************/
int32 IFX_DECTAPP_Compare(IN uint32 uiEntryAddrA,IN uint32 uiEntryAddrB,
		                      IN uchar8 ucListId,
                          IN uchar8 ucIsCaseSense){
    int32 iRet = 0;
    uchar8 acDate[30] = "";
    time_t tA,tB;

    switch(ucListId){

      case IFX_DECT_LAU_MISSED_CALLS:
      {
          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrA)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrA)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrA)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrA)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrA)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrA)->xTimeDate.ucSeconds);

          tA = toSeconds(acDate);
          memset(acDate,0,sizeof(acDate));

          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrB)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrB)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrB)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrB)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrB)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_MissedCallListEntry*)uiEntryAddrB)->xTimeDate.ucSeconds);

          tB = toSeconds(acDate);

          return ((tA>=tB)? 0: 1);
      }
      break;

      case IFX_DECT_LAU_OUTGOING_CALLS:
      {
          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrA)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrA)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrA)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrA)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrA)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrA)->xTimeDate.ucSeconds);

          tA = toSeconds(acDate);
          memset(acDate,0,sizeof(acDate));

          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrB)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrB)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrB)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrB)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrB)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_OutgoingCallListEntry*)uiEntryAddrB)->xTimeDate.ucSeconds);

          tB = toSeconds(acDate);
          return ((tA>=tB)? 0: 1);
      } 
      break;

      case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:
			{
          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucSeconds);

          tA = toSeconds(acDate);//check tA and tB are not 0.
          memset((char8 *)acDate,0,sizeof(acDate));

          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_IncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucSeconds);

          tB = toSeconds(acDate);
          return ((tA>=tB)? 0: 1);
			}	
      break;
    
			case IFX_DECT_LAU_ALL_INCOMING_CALLS:
			{
          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrA)->xTimeDate.ucSeconds);

					tA = toSeconds(acDate);//check tA and tB are not 0.
					memset(acDate,0,sizeof(acDate));

          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiEntryAddrB)->xTimeDate.ucSeconds);

          tB = toSeconds(acDate);
          return ((tA>=tB)? 0: 1);
			}
		  break;

      case IFX_DECT_LAU_ALL_CALLS:
		  {
          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrA)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrA)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrA)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrA)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrA)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrA)->xTimeDate.ucSeconds);

					tA = toSeconds(acDate);//check tA and tB are not 0.
					memset(acDate,0,sizeof(acDate));

          sprintf((char8 *)acDate,"%x-%x-%x  %x:%x:%x",
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrB)->xTimeDate.ucYear,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrB)->xTimeDate.ucMonth,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrB)->xTimeDate.ucDay,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrB)->xTimeDate.ucHour,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrB)->xTimeDate.ucMinutes,
                  ((x_IFX_DECT_LAU_AllCallListEntry*)uiEntryAddrB)->xTimeDate.ucSeconds);

          tB = toSeconds(acDate);
          return ((tA>=tB)? 0: 1);
		  }		
      break;

      case IFX_DECT_LAU_CONTACTS:
      {  
           if(ucIsCaseSense){
              iRet = strcmp(((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrA))->acLastName,
                                    ((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrB))->acLastName);
           }else{ 
             iRet = strcasecmp(((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrA))->acLastName,
                                    ((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrB))->acLastName);
            }
			   if(iRet == 0){
	           if(ucIsCaseSense){
                iRet = strcmp(((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrA))->acFirstName,
                                    ((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrB))->acFirstName);
              }else{ 
                 iRet = strcasecmp(((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrA))->acFirstName,
                                    ((x_IFX_DECT_LAU_ContactListEntry*)(uiEntryAddrB))->acFirstName);
              }
				}
			   return (iRet >0)?1:-1; 	
      }
      break;

      case IFX_DECT_LAU_INTERNAL_NAMES:
      {
					iRet = strcmp(((x_IFX_DECT_LAU_IntNameListEntry*)(uiEntryAddrA))->acTermIdNum,
										   ((x_IFX_DECT_LAU_IntNameListEntry*)(uiEntryAddrB))->acTermIdNum);
					return ((iRet==0)?0:((iRet >0)?1:-1)); 	
			}		
      break;

      case IFX_DECT_LAU_LINE_SETTINGS:
      {  
           iRet = (((x_IFX_DECT_LAU_LineSettingsEntry*)(uiEntryAddrA))->ucLineId - 
                                    ((x_IFX_DECT_LAU_LineSettingsEntry*)(uiEntryAddrB))->ucLineId);
					 return ((iRet >0)?1:-1); 	
      }
      break;

      default:
          break;
    }
    return 1;
}

/******************************************************************************
 *  Function Name   : toSeconds
 *  Description     : This internal Api is used to compare two entries in All Call
 *                    /All Incoming Call List where sorting field is Date and Time.
 *                    The two dates are compared by converting into seconds since
 *                    Jan 1,1970.
 *  Input Values    : pcDate - date and time info in the format
 *                    yyyy-mm-dd HH:MM:SS
 *  Output Values   :
 *  Return Value    : It returns number of seconds elapsed since 00:00:00 on January 1,
 *                    1970,UTC.The return data type is time_t holding the number of
 *                    seconds
 *  Notes           :
 ****************************************************************************/
time_t toSeconds(uchar8 *pcDate){

   struct tm time;
   uchar8 *pt=NULL;
   time_t tsec=0;

   pt = (uchar8 *)strptime((char8 *)pcDate,"%y-%m-%d %H:%M:%S",&time);
   if(pt == NULL){
     //printf("\n tsec is 0.\n");
     tsec = 0;
   }else{
     tsec = mktime(&time);
    }
   return tsec;
}

/******************************************************************************
 *  Function Name   : IFX_DECTAPP_ListSort
 *  Description     : This internal Api is used to Sort a given list as per the
 *                    default sorting field. 
 *  Input Values    : pucLineIdList - Line Identifers to which the handset is associated
 *                    pxListInfo - pointer to List Info structure
 *  Output Values   : pxListInfo - Total number of entries and sorted list pointer is
 *                    stored in ListInfo 
 *  Return Value    :  
 *  Notes           : In case of Call register,sorted list comprises of entries  
 *                    relating to lines the handset is associated to.
 ****************************************************************************/
e_IFX_Return
 IFX_DECTAPP_ListSort(IN uchar8 *pucLineIdList,
											IN OUT x_IFX_DECT_ListInfo *pxListInfo){

 int32 i=0,j=0,k=0;
 int32 mid_index=0,low_index=0,high_index = 0;
 
	if(pxListInfo == NULL)
		return IFX_FAILURE;

pxListInfo->ucNoOfListEntries = 0;

 IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "Entry.");
 switch(pxListInfo->ucListId){

   case IFX_DECT_LAU_MISSED_CALLS:
   {
       x_IFX_DECT_LAU_MissedCallList xMissedCallList = {0};
       x_IFX_DECT_LAU_MissedCallList xLineMissedCall = {0};
       int32 uiPtrArray[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES];

       if(pucLineIdList[0] == '\0'){
         return IFX_SUCCESS;//Ask 
			 }	 

    if( (pxListInfo->pxSortedList = (x_IFX_DECT_LAU_MissedCallList*)calloc(1,sizeof(x_IFX_DECT_LAU_MissedCallList))) ==NULL) {
            IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Calloc Failed");
            return IFX_FAILURE;
		}
       for(i=0;pucLineIdList[i] != '\0';i++){
          memset(&xLineMissedCall,0,sizeof(x_IFX_DECT_LAU_MissedCallList)); 
          if(IFX_FAILURE == IFX_CIF_MissedCallListGet(pucLineIdList[i],&xLineMissedCall)){

            IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                  "IFX_CIF_MissedCallListGet failed");
            return IFX_FAILURE;
          }
					if(xLineMissedCall.cNoOfEntries == 0){
            continue;   
					}

					memcpy(&xMissedCallList.axMissedCallList[j],&xLineMissedCall.axMissedCallList[0],
							   sizeof(x_IFX_DECT_LAU_MissedCallListEntry)*xLineMissedCall.cNoOfEntries);

					for(k=0;k<xLineMissedCall.cNoOfEntries;k++){
						uiPtrArray[j] = (uint32)(&xMissedCallList.axMissedCallList[j]);
						j++;
					}

          if(j>xLineMissedCall.cNoOfEntries){
              mid_index = j-xLineMissedCall.cNoOfEntries;
              high_index = j;   
              IFX_DECTAPP_MergeSortedLists(low_index,mid_index-1,high_index-1,uiPtrArray,pxListInfo->ucListId);
          }					  	
       }
			 pxListInfo->ucNoOfListEntries = j;

		   if(pxListInfo->ucNoOfListEntries == 0){
			   return IFX_SUCCESS;
			 }

       for(i=0;i<pxListInfo->ucNoOfListEntries;i++){

         memcpy(&((x_IFX_DECT_LAU_MissedCallList*)pxListInfo->pxSortedList)->axMissedCallList[i],
               (x_IFX_DECT_LAU_MissedCallListEntry*)uiPtrArray[i],
               sizeof(x_IFX_DECT_LAU_MissedCallListEntry));
       }
      ((x_IFX_DECT_LAU_MissedCallList*)pxListInfo->pxSortedList)->cNoOfEntries = j;
   }
   break;

   case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:
   {
       x_IFX_DECT_LAU_IncomingCallList xIncomingCallList={0};
       x_IFX_DECT_LAU_IncomingCallList xLineIncomingCall={0};
       int32 uiPtrArray[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES];

       if(pucLineIdList[0] == '\0'){
         return IFX_SUCCESS;//Ask 
			 }	 

        if( (/*pxListInfo->pxSortedList =*/ pxListInfo->pxSortedList = (x_IFX_DECT_LAU_IncomingCallList*)calloc(1,sizeof(x_IFX_DECT_LAU_IncomingCallList))) == NULL){
            IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>ListSort Calloc failed");
            return IFX_FAILURE;

				}
       for(i=0;pucLineIdList[i] != '\0';i++){
         
          memset(&xLineIncomingCall,0,sizeof(x_IFX_DECT_LAU_IncomingCallList)); 
          if(IFX_FAILURE == IFX_CIF_IncomingCallListGet(pucLineIdList[i],&xLineIncomingCall)){

            IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>IFX_CIF_IncomingCallListGet failed");
            return IFX_FAILURE;
          }

					if(xLineIncomingCall.cNoOfEntries == 0){
            continue;   
					}
					memcpy(&xIncomingCallList.axIncomingCallList[j],&xLineIncomingCall.axIncomingCallList[0],
							   sizeof(x_IFX_DECT_LAU_IncomingCallListEntry)*xLineIncomingCall.cNoOfEntries);

					for(k=0;k<xLineIncomingCall.cNoOfEntries;k++){
						uiPtrArray[j] = (uint32)(&xIncomingCallList.axIncomingCallList[j]);
						j++;
          }
          if(j>xLineIncomingCall.cNoOfEntries){
              mid_index = j-xLineIncomingCall.cNoOfEntries;
              high_index = j;   
              IFX_DECTAPP_MergeSortedLists(low_index,mid_index-1,high_index-1,uiPtrArray,pxListInfo->ucListId);
          }					  	
       }
       pxListInfo->ucNoOfListEntries = j;
   
       if(pxListInfo->ucNoOfListEntries == 0){
	      return IFX_SUCCESS;
       }

       for(i=0;i<pxListInfo->ucNoOfListEntries;i++){

         memcpy(&((x_IFX_DECT_LAU_IncomingCallList*)pxListInfo->pxSortedList)->axIncomingCallList[i],
                 (x_IFX_DECT_LAU_IncomingCallListEntry*)uiPtrArray[i],
                 sizeof(x_IFX_DECT_LAU_IncomingCallListEntry));
       } 
       ((x_IFX_DECT_LAU_IncomingCallList*)pxListInfo->pxSortedList)->cNoOfEntries = j;
   }
   break;

   case IFX_DECT_LAU_OUTGOING_CALLS:
   {
       x_IFX_DECT_LAU_OutgoingCallList xOutgoingCallList={0};
       x_IFX_DECT_LAU_OutgoingCallList xLineOutgoingCall={0};
       int32 uiPtrArray[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES];

       if(pucLineIdList[0] == '\0'){
         return IFX_SUCCESS;//Ask 
			 }	 

       pxListInfo->pxSortedList = (x_IFX_DECT_LAU_OutgoingCallList*)calloc(1,sizeof(x_IFX_DECT_LAU_OutgoingCallList));
       if(pxListInfo->pxSortedList == NULL){
					IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>IFX_CIF_OutgoingCallListGet Calloc failed");
            return IFX_FAILURE;
				}
				for(i=0;pucLineIdList[i] != '\0';i++){

          memset(&xLineOutgoingCall,0,sizeof(x_IFX_DECT_LAU_OutgoingCallList)); 
          if(IFX_FAILURE == IFX_CIF_OutgoingCallListGet(pucLineIdList[i],&xLineOutgoingCall)){

            IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>IFX_CIF_OutgoingCallListGet failed");
            return IFX_FAILURE;
          }
					if(xLineOutgoingCall.cNoOfEntries == 0){
            continue;   
					}
					memcpy(&xOutgoingCallList.axOutgoingCallList[j],&xLineOutgoingCall.axOutgoingCallList[0],
							   sizeof(x_IFX_DECT_LAU_OutgoingCallListEntry)*xLineOutgoingCall.cNoOfEntries);

					for(k=0;k<xLineOutgoingCall.cNoOfEntries;k++){
						uiPtrArray[j] = (uint32)(&xOutgoingCallList.axOutgoingCallList[j]);
						j++;
          }
          if(j>xLineOutgoingCall.cNoOfEntries){
              mid_index = j-xLineOutgoingCall.cNoOfEntries;
              high_index = j;   
              IFX_DECTAPP_MergeSortedLists(low_index,mid_index-1,high_index-1,uiPtrArray,pxListInfo->ucListId);
          }					  	
       }
       pxListInfo->ucNoOfListEntries = j;
   
       if(pxListInfo->ucNoOfListEntries == 0){
	      return IFX_SUCCESS;
       }  
       for(i=0;i<pxListInfo->ucNoOfListEntries;i++){
         memcpy(&((x_IFX_DECT_LAU_OutgoingCallList*)pxListInfo->pxSortedList)->axOutgoingCallList[i],
                 (x_IFX_DECT_LAU_OutgoingCallListEntry*)uiPtrArray[i],
                 sizeof(x_IFX_DECT_LAU_OutgoingCallListEntry));
       } 
       ((x_IFX_DECT_LAU_OutgoingCallList*)pxListInfo->pxSortedList)->cNoOfEntries = j;
   }
   break;

   case IFX_DECT_LAU_ALL_CALLS:
   {
       x_IFX_DECT_LAU_AllCallList xAllCallList = {0};
       x_IFX_DECT_LAU_AllCallList xLineAllCall = {0};
       int32 uiPtrArray[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES*3];

       if(pucLineIdList[0] == '\0'){
         return IFX_SUCCESS;//Ask 
			 }	 

       if((pxListInfo->pxSortedList = (x_IFX_DECT_LAU_AllCallList*)calloc(1,sizeof(x_IFX_DECT_LAU_AllCallList))) ==NULL){
            IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort> Calloc Failed.. ");
            return IFX_FAILURE;
				}

       for(i=0;pucLineIdList[i] != '\0';i++){
         
          memset(&xLineAllCall,0,sizeof(x_IFX_DECT_LAU_AllCallList)); 
          if(IFX_FAILURE == IFX_CIF_AllCallListGet(pucLineIdList[i],&xLineAllCall)){

            IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>IFX_CIF_AllCallListGet failed");
            return IFX_FAILURE;
          }

					if(xLineAllCall.cNoOfEntries == 0){
            continue;   
					}
					memcpy(&xAllCallList.axAllCallList[j],&xLineAllCall.axAllCallList[0],
							   sizeof(x_IFX_DECT_LAU_AllCallListEntry)*xLineAllCall.cNoOfEntries);

					for(k=0;k<xLineAllCall.cNoOfEntries;k++){
						uiPtrArray[j] = (uint32)(&xAllCallList.axAllCallList[j]);
            j++;
					}

						k = 0;
            while((k<xLineAllCall.cNoOfEntries)&&
              (xLineAllCall.axAllCallList[k].cCallListType == IFX_DECT_LAU_CALL_LIST_TYPE_MISSED)){
						  k++;
					  }	
					  mid_index = k;

            while((k<xLineAllCall.cNoOfEntries)&&
              (xLineAllCall.axAllCallList[k].cCallListType == IFX_DECT_LAU_CALL_LIST_TYPE_ACCEPTED)){
              k++;
            }

            if((mid_index != 0) && (mid_index != k)){
              IFX_DECTAPP_MergeSortedLists(low_index,mid_index-1,k-1,uiPtrArray,pxListInfo->ucListId);
            }

            IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>Merge1");
						mid_index = k;

            while((k<xLineAllCall.cNoOfEntries)&&
              (xAllCallList.axAllCallList[k].cCallListType == IFX_DECT_LAU_CALL_LIST_TYPE_OUTGOING)){
              k++;
            }
          
            if((mid_index != 0) && (mid_index != k)){
             IFX_DECTAPP_MergeSortedLists(low_index,mid_index-1,k-1,uiPtrArray,pxListInfo->ucListId);
            }
            IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>Merge2");

            if(j>xLineAllCall.cNoOfEntries){
              mid_index = j-xLineAllCall.cNoOfEntries;
              high_index = j;							
              IFX_DECTAPP_MergeSortedLists(low_index,mid_index-1,high_index-1,uiPtrArray,pxListInfo->ucListId);
						}	
			 }			 
       pxListInfo->ucNoOfListEntries = j;
       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
                     "<IFX_DECTAPP_ListSort>pxListInfo->ucNoOfListEntries");
   
       if(pxListInfo->ucNoOfListEntries == 0){
         IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>No Entries.Success");
	      return IFX_SUCCESS;
       }  

       for(i=0;i<pxListInfo->ucNoOfListEntries;i++){
       memcpy(&((x_IFX_DECT_LAU_AllCallList*)pxListInfo->pxSortedList)->axAllCallList[i],
                 (x_IFX_DECT_LAU_AllCallListEntry*)uiPtrArray[i],
                 sizeof(x_IFX_DECT_LAU_AllCallListEntry));
       } 
       ((x_IFX_DECT_LAU_AllCallList*)pxListInfo->pxSortedList)->cNoOfEntries = j;
   }
   break;

   case IFX_DECT_LAU_CONTACTS:
 				IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "Contacts");
   {
       x_IFX_DECT_LAU_ContactList xContactList = {0};
       int32 uiPtrArray[IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES];
       x_IFX_DECT_LAU_ContactList xLineContactList = {0};
			 j=0;
			 if(pucLineIdList[0] == '\0'){
         return IFX_SUCCESS; //TODO
       }
     if( (pxListInfo->pxSortedList = (x_IFX_DECT_LAU_ContactList*)calloc(1,sizeof(x_IFX_DECT_LAU_ContactList))) == NULL){
       IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
                     "<IFX_DECTAPP_ListSort> Calloc Failure....");
				return IFX_FAILURE;
			}
		
			 for(i=0;pucLineIdList[i] != '\0';i++){
      	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
	               "Get Contact for Line ", pucLineIdList[i]);
				memset(&xLineContactList,0,sizeof(xLineContactList));

				if(IFX_FAILURE == IFX_CIF_ContactListGet(&xLineContactList,
						pucLineIdList[i])) {
 						IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "Get failed");
						//free(pxListInfo->pxSortedList);
						return IFX_FAILURE;
				}
				if(0 == xLineContactList.unNoOfEntries) {
					continue;
				}
				/*Update Global count of Number of entries in this particular line*/
				vunContactsPerLine[pucLineIdList[i]-1] = xLineContactList.unNoOfEntries;
				if( j>=0 && xLineContactList.unNoOfEntries > 0 && xLineContactList.unNoOfEntries <=IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES ){
				memcpy(&xContactList.axContactList[j],xLineContactList.axContactList,
               sizeof(x_IFX_DECT_LAU_ContactListEntry)*xLineContactList.unNoOfEntries);
				j = j + xLineContactList.unNoOfEntries;
				}
       }
			
				/* Get the common Contact-List entires and put it into list */		 
				memset(&xLineContactList,0,sizeof(xLineContactList));
				
        if(IFX_FAILURE == IFX_CIF_CommonContactListGet(&xLineContactList)) {
            IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "Get failed");
            //free(pxListInfo->pxSortedList);
            return IFX_FAILURE;
        }
        if(0 != xLineContactList.unNoOfEntries) {
        /*Update Global count of Number of entries in this particular line*/
        vunCommonContactEntires = xLineContactList.unNoOfEntries;
         if( j>=0 && j < IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES && xLineContactList.unNoOfEntries > 0 && xLineContactList.unNoOfEntries <=IFX_DECT_LAU_MAX_CONTACT_LIST_ENTRIES){
					memcpy(&xContactList.axContactList[j],xLineContactList.axContactList,
               sizeof(x_IFX_DECT_LAU_ContactListEntry)*xLineContactList.unNoOfEntries);
        	j = j + xLineContactList.unNoOfEntries;
				}
       }
	
			/*Prepare for Sorting*/
			 /*Prepare for Sorting*/
			 xContactList.unNoOfEntries = j;
			 pxListInfo->ucNoOfListEntries = j;
			 if(pxListInfo->ucNoOfListEntries == 0){
         return IFX_SUCCESS;
       }
			 for(i=0;i<xContactList.unNoOfEntries;i++){
				 uiPtrArray[i] = (uint32)(&xContactList.axContactList[i]);
			 }	 
			/*Sort the list*/	
       IFX_DECTAPP_SortList(low_index,xContactList.unNoOfEntries-1,
						uiPtrArray,pxListInfo->ucListId);
			 /*Rearrange as per Sorting*/
			 for(i=0;i<xContactList.unNoOfEntries;i++){
         memcpy(&((x_IFX_DECT_LAU_ContactList*)pxListInfo->pxSortedList)->axContactList[i],
                 (x_IFX_DECT_LAU_ContactListEntry*)uiPtrArray[i],
                 sizeof(x_IFX_DECT_LAU_ContactListEntry));
       }
       ((x_IFX_DECT_LAU_ContactList*)pxListInfo->pxSortedList)->unNoOfEntries = 
						pxListInfo->ucNoOfListEntries = xContactList.unNoOfEntries;
   }
 	 IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Get Contacts Done");
   break;

   case IFX_DECT_LAU_INTERNAL_NAMES:
	 {
       x_IFX_DECT_LAU_IntNameList xIntNameList = {0};
			 uchar8 ucHandset = 0;

       pxListInfo->pxSortedList = (x_IFX_DECT_LAU_IntNameList*)calloc(1,sizeof(x_IFX_DECT_LAU_IntNameList));

			 if(IFX_FAILURE == IFX_CIF_IntNameGet(&xIntNameList)){
          IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>IFX_CIF_IntNameGet failed");
					return IFX_FAILURE; 
			 }		 
			 if(xIntNameList.cNoOfEntries == 0){
        return IFX_SUCCESS;
			 }	 

			 ucHandset = ((pxListInfo->nSessId - 1)/IFX_DECT_LAU_MAX_SESS_PER_HS)+1;
			 for(i=0;i<xIntNameList.cNoOfEntries;i++){
				 if(ucHandset == atoi(xIntNameList.axIntNameList[i].acTermIdNum)){
				  xIntNameList.axIntNameList[i].ucOwn = 0x10; 
					break;
				 }	
			 }		 
       memcpy(&((x_IFX_DECT_LAU_IntNameList*)pxListInfo->pxSortedList)->axIntNameList[0],
              &xIntNameList.axIntNameList[0],
              sizeof(x_IFX_DECT_LAU_IntNameListEntry)*xIntNameList.cNoOfEntries);
       ((x_IFX_DECT_LAU_IntNameList*)pxListInfo->pxSortedList)->cNoOfEntries = pxListInfo->ucNoOfListEntries = xIntNameList.cNoOfEntries;  
       
	 }
	 break;

   case IFX_DECT_LAU_LINE_SETTINGS:
	 {
		   x_IFX_DECT_LAU_LineSettingsList xLineSetList = {0};
       int32 uiPtrArray[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES];
			 
       pxListInfo->pxSortedList = (x_IFX_DECT_LAU_LineSettingsList*)calloc(1,sizeof(x_IFX_DECT_LAU_LineSettingsList));

			 if(IFX_FAILURE == IFX_CIF_LineGet(&xLineSetList)){
          IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>IFX_CIF_LineGet failed");
					return IFX_FAILURE; 
			 }		 
			 if(xLineSetList.ucNoOfLines == 0){
        return IFX_SUCCESS;
			 }	 

			 for(i=0;i<xLineSetList.ucNoOfLines;i++){
				 uiPtrArray[i] = (uint32)(&xLineSetList.axLineEntry[i]);
			 }	 
       IFX_DECTAPP_SortList(low_index,xLineSetList.ucNoOfLines-1,uiPtrArray,pxListInfo->ucListId);

			 for(i=0;i<xLineSetList.ucNoOfLines;i++){

          memcpy(&((x_IFX_DECT_LAU_LineSettingsList*)pxListInfo->pxSortedList)->axLineEntry[i],
                (x_IFX_DECT_LAU_LineSettingsEntry*)uiPtrArray[i],
                sizeof(x_IFX_DECT_LAU_LineSettingsEntry));
       }
       ((x_IFX_DECT_LAU_LineSettingsList*)pxListInfo->pxSortedList)->ucNoOfLines = pxListInfo->ucNoOfListEntries = xLineSetList.ucNoOfLines;  
	 }
	 break;

   case IFX_DECT_LAU_SYS_SETTINGS:
   {
		   x_IFX_DECT_LAU_SystemSettingsList xSysSetList = {0};
			 
       pxListInfo->pxSortedList = (x_IFX_DECT_LAU_SystemSettingsList*)calloc(1,sizeof(x_IFX_DECT_LAU_SystemSettingsList));
			 if(IFX_FAILURE == IFX_CIF_SystemGet(&xSysSetList)){
          IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>IFX_CIF_SystemGet failed");
					return IFX_FAILURE; 
			 }		 
       memcpy((x_IFX_DECT_LAU_SystemSettingsList*)pxListInfo->pxSortedList,
              &xSysSetList,sizeof(x_IFX_DECT_LAU_SystemSettingsList));
			 pxListInfo->ucNoOfListEntries = 1;
	 }		 
   break;

   case IFX_DECT_LAU_ALL_INCOMING_CALLS:
   {
       x_IFX_DECT_LAU_AllIncomingCallList xAllIncomingCallList = {0};
       x_IFX_DECT_LAU_AllIncomingCallList xLineAllIncomingCall = {0};
       int32 uiPtrArray[IFX_DECT_LAU_MAX_CALL_LIST_ENTRIES*2];

       if(pucLineIdList[0] == '\0'){
         return IFX_SUCCESS;//Ask 
			 }	 
       pxListInfo->pxSortedList = (x_IFX_DECT_LAU_AllIncomingCallList*)calloc(1,sizeof(x_IFX_DECT_LAU_AllIncomingCallList));
       for(i=0;pucLineIdList[i] != '\0';i++){
         
          memset(&xLineAllIncomingCall,0,sizeof(x_IFX_DECT_LAU_AllIncomingCallList)); 
          if(IFX_FAILURE == IFX_CIF_AllIncomingCallListGet(pucLineIdList[i],&xLineAllIncomingCall)){

            IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>IFX_CIF_AllCallListGet failed");
            return IFX_FAILURE;
          }
					if(xLineAllIncomingCall.cNoOfEntries == 0){
            continue;   
          }
					memcpy(&xAllIncomingCallList.axAllIncomingCallList[j],&xLineAllIncomingCall.axAllIncomingCallList[0],
							   sizeof(x_IFX_DECT_LAU_AllIncomingCallListEntry)*xLineAllIncomingCall.cNoOfEntries);

					for(k=0;k<xLineAllIncomingCall.cNoOfEntries;k++){
						uiPtrArray[j] = (uint32)(&xAllIncomingCallList.axAllIncomingCallList[j]);
            j++;
					}

						k = 0;
            while((k<xLineAllIncomingCall.cNoOfEntries)&&
              (xAllIncomingCallList.axAllIncomingCallList[k].bNew != 0xFF)){
						  k++;
					  }	
					  mid_index = k;

            while((k<xLineAllIncomingCall.cNoOfEntries)&&
              (xAllIncomingCallList.axAllIncomingCallList[k].bNew == 0xFF)){
              k++;
            }

            if((mid_index != 0) && (mid_index != k)){
             IFX_DECTAPP_MergeSortedLists(low_index,mid_index-1,k-1,uiPtrArray,pxListInfo->ucListId);
            }
            if(j>xLineAllIncomingCall.cNoOfEntries){
              mid_index = j-xLineAllIncomingCall.cNoOfEntries;
              high_index = j;							
              IFX_DECTAPP_MergeSortedLists(low_index,mid_index-1,high_index-1,uiPtrArray,pxListInfo->ucListId);
						}	
			 }			 
       pxListInfo->ucNoOfListEntries = j;
   
       if(pxListInfo->ucNoOfListEntries == 0){
     	  return IFX_SUCCESS;
       }  
       for(i=0;i<pxListInfo->ucNoOfListEntries;i++){
         memcpy(&((x_IFX_DECT_LAU_AllIncomingCallList*)pxListInfo->pxSortedList)->axAllIncomingCallList[i],
                 (x_IFX_DECT_LAU_AllIncomingCallListEntry*)uiPtrArray[i],
                 sizeof(x_IFX_DECT_LAU_AllIncomingCallListEntry));
       }
       ((x_IFX_DECT_LAU_AllIncomingCallList*)pxListInfo->pxSortedList)->cNoOfEntries = j;
   }   
   break;
   
   default:
       IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "<IFX_DECTAPP_ListSort>Failure!");
       return IFX_FAILURE;
        
 }
 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
          "<IFX_DECTAPP_ListSort>Success!!");
 return IFX_SUCCESS;
}


e_IFX_Return IFX_DECTAPP_IsHandSetIdValid(uchar8 pucHandSetId){

if(pucHandSetId > 0 && pucHandSetId <= IFX_DECTAPP_MAX_DECT_ENDPTS )
return IFX_SUCCESS;
else
return IFX_FAILURE;

}

e_IFX_Return IFX_DECTAPP_IsListIdValid(uchar8 pucListId){
#ifdef  LTQ_DT_SUPPORT
  if(IFX_DECTAPP_isProprietaryList(pucListId) == IFX_SUCCESS ){
		return IFX_SUCCESS;
}
else
#endif
if(pucListId <= 0 || pucListId > IFX_DECT_LAU_MAX_SUPPORTED_LISTS )
return IFX_FAILURE;
else
return IFX_SUCCESS;

}


