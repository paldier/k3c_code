/**************************************************************************
 **   SRC_FILE          : IFX_DECT_Agent.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT Agent
 **   SRC VERSION       : v0.1
 **   DATE              : 8th Oct 2007
 **   AUTHOR            :
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/

#include <stdio.h>
#include <string.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

/* According to POSIX 1003.1-2001 */
#include <sys/select.h>
/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/ioctl.h>

#include "ifx_common_defs.h"
#include "IFX_Config.h"
//#define printf(...)
#ifdef printf
#undef printf
#endif

#define DECT_APP 1 /* Needed to include dect stack headers */
#define FT 1
/* DECT Specific Header file */
#if 1
#include "TYPEDEF.H"
#include "CC_DEF.H"
#include "PCT_DEF.H"
#include "MESSAGE_DEF.H"
#include "SYSDEF.H"
#include "FGLOBAL.H"
#endif

#include "IFX_DECT_MsgRouter.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_USU.h"
#include "IFX_DECT_MU.h"
#include "ifx_common_defs.h"
#include "IFX_Config.h"
#include "IFX_CallMgrIf.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_Agents_CfgIf.h"
#include "ifx_debug.h"
#include "ifx_os.h"
#include "IFX_DECT_Agent.h"
#include "IFX_DECT_MsgApi.h"
#include "IFX_TimerIf.h"
#ifdef ULE_SUPPORT
#include "ifx_ule_defs.h"
#endif

#define IFX_DECT_FIFO_PERM	          0644
#define IFX_DECT_AGENT_FIFO_NAME	    "/tmp/DectAgentFifo"
#ifdef ULE_SUPPORT
#define IFX_ULE_AGENT_FIFO_NAME	    "/tmp/UleAgentFifo"
//#define SMART_HOME_DEMO 1
#endif
#define IFX_DECT_STACK_FIFO_NAME	    "/tmp/DectStackFifo"
#define IFX_DECT_INTERNAL_FIFO_NAME	  "/tmp/DectIntFifo"
#define IFX_DECT_DECT_PAGEKEY_DRV	    "/dev/pb"

#ifdef ENABLE_PAGING 
#define IFX_DECT_NO_OF_FD_TOBE_REGISTERED 2
#else
#define IFX_DECT_NO_OF_FD_TOBE_REGISTERED 1
#endif

int32 viStackFifoFd; /** Fd used to read DECT stack messages */
int32 viAgentFifoFd; /** Fd used to write messages to DECT stack */
STATIC int32 viPagingKeyFd; /** Fd used to read Paging Key events */
STATIC boolean vbDectStackInitialized = IFX_FALSE;

EXTERN uchar8 vucDectAgnetModId;
extern uint32 vuiGwUp;
extern e_IFX_Return IFX_CIF_DectBasicParamsGet(char8* pszBasePin, uchar8* pucBitMap,
                                        x_IFX_DECT_EnhancedStackCfg *pxEnhancedStackCfg);
extern e_IFX_Return IFX_CIF_BMCRegparamGet(OUT x_IFX_DECT_BMCRegParams *pxBMCParams);
extern e_IFX_Return IFX_CIF_OscTrimParamGet(OUT x_IFX_DECT_OscTrimVal *pxOscTrimVal);
extern e_IFX_Return IFX_CIF_TPCValGet(OUT x_IFX_DECT_TransmitPowerParam *pxTpcGet);
extern e_IFX_Return IFX_CIF_RFPIGet(OUT uchar8 *paxRFPI);
extern void IFX_DectStartTime( uint32 uiTimerId, void *ptr);
extern e_IFX_Return	IFX_DECT_DIAG_ModemRestart(void);
//#ifdef __PIN_CODE__
#if 0
uchar8 vszPinCode[5];
#endif

#ifdef ULE_SUPPORT
int32 viUleFifoFd;

#ifdef SMART_HOME_DEMO
int32 viUleSocFd;
uchar8 srvflg;
struct sockaddr_in srvaddr;
void IFX_ULE_ProcessSocMessage(uchar8* pucBuff,uint16 n);
#endif

EXTERN 
e_IFX_Return IFX_ULE_ProcessWebMessage(IN x_IFX_ULE_IPC_Msg* pxIpcMsg);
#endif

EXTERN 
e_IFX_Return IFX_DECT_ProcessStackMessage(IN x_IFX_DECT_IPC_Msg* pxIpcMsg);
EXTERN 
e_IFX_Return IFX_DECT_ProcessPagekeyMessage();
				
STATIC e_IFX_Return IFX_DECT_MsgRouterFdHdlr(IN int32 iFd);
//STATIC e_IFX_Return IFX_DECT_SendMsgToStack(IN x_IFX_DECT_IPC_Msg* pxIpcMsg);
#define IFX_DECT_SendMsgToStack(x) IFX_DECT_MsgRt_PostToStack(1,x);
EXTERN char8** vppcArgv;

#define ReadFifo(Fd, pcBuf, bufSize) read(Fd, pcBuf, bufSize)
#define WriteFifo(Fd, pcBuf, bufSize) write(Fd, pcBuf, bufSize)

void IFX_DECT_PageDrvClose(void)
{
	//int iRet=0;
/*note-Ioctl of page driver not chking any cmd. So can send any cmd with ioctl meaning shutdown for Page button*/
  /*iRet=*/ioctl(viPagingKeyFd, 1, NULL);
	close(viPagingKeyFd);
	viPagingKeyFd = 0;
}
void IFX_DECT_UnInitStack(void)
{
	vbDectStackInitialized = IFX_FALSE;
	return;
}
boolean IFX_DECT_IsDectStackInitialized()
{
	return vbDectStackInitialized;
}
/******************************************************************
*  Function Name    :IFX_DEACT_CMGR_RegFd
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/

int32 IFX_DECT_CMGR_RegFd(int32 iFd,uchar8 ucFdType,
                          pfn_IFX_DECT_FdCallback pfunc)
{
   x_IFX_MSGRTR_FdInfo xFdInfo={0};
   xFdInfo.eFdSetType = ucFdType;
   xFdInfo.uiFd = iFd;
   return IFX_MSGRTR_DectFdCallBackRegister(&xFdInfo,
            (e_IFX_Return (*)(fd_set*, IN fd_set *,fd_set *,int32 *))pfunc);
}
/******************************************************************
*  Function Name    : IFX_SIPAPP_CMGR_UnRegFd
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_DECT_CMGR_UnRegFd(int32 iFd,uchar8 ucFdType)
{
	 x_IFX_MSGRTR_FdInfo xFdInfo={0};
	 xFdInfo.eFdSetType = ucFdType;
	 xFdInfo.uiFd = iFd;
	 return IFX_MSGRTR_FdUnregister(&xFdInfo);
}
/******************************************************************
*  Function Name    : IFX_DECT_InitStatus
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/
void IFX_DECT_InitStatus(int32 iStatus){
  static int iAgentInitDone=0;
	int i=0;
  vbDectStackInitialized = IFX_TRUE;
	if(iStatus == IFX_SUCCESS)
	{
	i = system("grep 'App' /proc/driver/dect/gw-stats 2>/dev/null");
	if( i !=0) {
    //iAgentInitDone=0;
  	IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        "##############CALLING  Firmware Download ###################\n");
  	sleep(3);
#ifdef COSIC_BMC_FW_ON_RAM
 		IFX_DECT_USU_ModemFirmwareDownload("/flash/","BMCFw.BIN","COSICFw.BIN"); 
#else
 		IFX_DECT_USU_ModemFirmwareDownload("/opt/ifx/downloads/","BMCFw.BIN","COSICFw.BIN"); 
#endif
	}
	else { /*Firwmare is App Mode*/
    //iAgentInitDone=0;
  	sleep(3);
  			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        "############## Cosic already Initialized\n");
			//IFX_DectStartTime(0,NULL);
			IFX_DECT_DIAG_ModemRestart();
	}
	}
	else if((iStatus == IFX_FW_DOWNLOAD_SUCCESS) || (iStatus == IFX_DECT_SHUTDOWN_SUCCESS)) 
	{
    if(iAgentInitDone==0){
			uint32 uiDectDownLoadTimer;
 			IFX_TIM_TimerStart(2000,NULL, 0, IFX_DectStartTime,&uiDectDownLoadTimer);
      iAgentInitDone=1;
    }
		else
		{
  			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
        "DECT Shutdown happened But RTP/Fax already started so no need to start again\n");
		}
	}
}

/******************************************************************
*  Function Name    : IFX_DECT_InitDectStack
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
*********************************************************************/
e_IFX_Return IFX_DECT_InitDectStack(IN uchar8 ucDectStackModId,
	                    IN uchar8 ucDectAgentModId,
	                    IN x_IFX_CIF_DectSubsInfo* pxPPSubInfo,
	                    IN uchar8 ucNoOfSubscribedPPs)
{
   x_IFX_MSGRTR_FdInfo axDectFdInfo[10];
   uint32 uiStackMode = IFX_DECT_ASYNC_MODE;
   x_IFX_DECT_StackInitCfg xInitCfg = {0};
   //uchar8 ucTxFreq, uRxFreq, ucRange;
   uint32 uiNoOfFdsReg=0;
   viDectStackMode = uiStackMode;
	 boolean bStatus=0;
   uchar8 ucBitMap=0;
   x_IFX_DECT_EnhancedStackCfg xEnhancedStackCfg={0};
   if( IFX_TRUE == vbDectStackInitialized )
		{
			IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
				"Initializing DECT STACK=1.....");
		return IFX_SUCCESS;
		}
		else
		{
				IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
				"Initializing DECT STACK=0.....");
		}	
	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
				"Initializing DECT STACK.....");
   if(uiStackMode == IFX_DECT_ASYNC_MODE) {
    if (IFX_OS_CreateFifo((uchar8 *)IFX_DECT_AGENT_FIFO_NAME) < 0)
	  {
		 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, 
		   		"Failed To Create IFX_DECT_AGENT_FIFO_NAME");
		 return IFX_FAILURE;
	  }
	  if (IFX_OS_CreateFifo((uchar8 *)IFX_DECT_STACK_FIFO_NAME) < 0)
	  {
	     IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   	"Failed To Create IFX_DECT_STACK_FIFO_NAME");
		  return IFX_FAILURE;
	  }
	  if(( viAgentFifoFd = 
				IFX_OS_OpenFifo((uchar8 *)IFX_DECT_AGENT_FIFO_NAME,O_RDWR|O_NONBLOCK)) < 0)
	  {
	   	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, 
				"Failed To Open IFX_DECT_AGENT_FIFO_NAME");
		   return IFX_FAILURE;
	  }

	  if( (viStackFifoFd = 
			IFX_OS_OpenFifo((uchar8 *)IFX_DECT_STACK_FIFO_NAME,O_RDWR|O_NONBLOCK)) < 0)
	  { 
	   	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
		   	"Failed To Open IFX_DECT_STACK_FIFO_NAME");
		   return IFX_FAILURE;
	  }
#ifdef ULE_SUPPORT	
    if (IFX_OS_CreateFifo((uchar8 *)IFX_ULE_AGENT_FIFO_NAME) < 0)
	  {
		 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, 
		   		"Failed To Create IFX_ULE_AGENT_FIFO_NAME");
		 return IFX_FAILURE;
	  }
	  if(( viUleFifoFd = 
				IFX_OS_OpenFifo((uchar8 *)IFX_ULE_AGENT_FIFO_NAME,O_RDWR|O_NONBLOCK)) < 0)
	  {
	   	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, 
				"Failed To Open IFX_ULE_AGENT_FIFO_NAME");
		   return IFX_FAILURE;
	  }
#ifdef SMART_HOME_DEMO
    if ((viUleSocFd=IFX_OS_CreateSocket(IFX_OS_PROTOCOL_UDP,2222,0,0,0)) < 0)
	  {
		 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR, 
		   		"Failed To Create DEMO Socket");
		 return IFX_FAILURE;
	  }

#endif
#endif
	  IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
				"Opening FIFOs......done");
	}
#ifdef ENABLE_PAGING
	if( viPagingKeyFd == 0 )
	{ 
    if((viPagingKeyFd = open(IFX_DECT_DECT_PAGEKEY_DRV, O_RDWR|O_NONBLOCK)) < 0)
     {
	 	 IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Paging Key Drv open Failed");
			return IFX_FAILURE;
	  }
	} 
#endif
	/*
	 * Register FDs with message router.
	 */
    if(uiStackMode == IFX_DECT_ASYNC_MODE) {
   	axDectFdInfo[uiNoOfFdsReg].uiFd = viAgentFifoFd;
   	axDectFdInfo[uiNoOfFdsReg].eFdSetType = IFX_MSGRTR_READ_TYPE;
      uiNoOfFdsReg++;
    }
#ifdef ENABLE_PAGING 
 	   axDectFdInfo[uiNoOfFdsReg].uiFd = viPagingKeyFd;
	   axDectFdInfo[uiNoOfFdsReg].eFdSetType = IFX_MSGRTR_READ_TYPE;
      uiNoOfFdsReg++;
#endif
#ifdef ULE_SUPPORT
 	   axDectFdInfo[uiNoOfFdsReg].uiFd = viUleFifoFd;
	   axDectFdInfo[uiNoOfFdsReg].eFdSetType = IFX_MSGRTR_READ_TYPE;
      uiNoOfFdsReg++;

#ifdef SMART_HOME_DEMO
 	   axDectFdInfo[uiNoOfFdsReg].uiFd = viUleSocFd;
	   axDectFdInfo[uiNoOfFdsReg].eFdSetType = IFX_MSGRTR_READ_TYPE;
      uiNoOfFdsReg++;
#endif
#endif
	 if( IFX_SUCCESS != IFX_MSGRTR_FdCallBackRegister(axDectFdInfo, 
								uiNoOfFdsReg,IFX_DECT_MsgRouterFdHdlr))
	 {
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							         "IFX_MSGRTR_FdCallBackRegister Failed");
		return IFX_FAILURE;
	 }
	if( IFX_SUCCESS != IFX_CIF_RFPIGet(xInitCfg.aucRfpi) ){
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							         "RFPI Get Failed");
		 return IFX_FAILURE;
  }
	if( IFX_SUCCESS != IFX_CIF_BMCRegparamGet(&xInitCfg.xBMCPrams) ){
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							         "BMC Get Failed");
  	return IFX_FAILURE;
  }
   xInitCfg.ucMaxHandsets =6;

	if( IFX_SUCCESS != IFX_CIF_OscTrimParamGet(&xInitCfg.xOscTrimVal) ){
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							         "Osc Get Failed");
           return IFX_FAILURE;
  }

	IFX_CIF_DectDbgGet((uchar8 *)&xInitCfg.iDbgType,(uchar8 *) &xInitCfg.iDbgLvl);

#if 1
	if( IFX_SUCCESS != IFX_CIF_TPCValGet(&xInitCfg.xTPCPrams)){
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							         "TPC Get Failed");
		return IFX_FAILURE;
  }
#endif
	if( IFX_SUCCESS != IFX_CIF_GaussianValGet(&xInitCfg.unGaussianVal) ){
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							         "Gaussian Get Failed");
		return IFX_FAILURE;
  }
	if(IFX_SUCCESS != IFX_CIF_DectBasicParamsGet(xInitCfg.acBasePin,&ucBitMap,&xEnhancedStackCfg)){
		IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
							         "Dect Basic Params Get Failed");
		return IFX_FAILURE;
		
	}
	{ int iFeatures=0;
	iFeatures = IFX_DECT_InitEnhancedFeatures(&xEnhancedStackCfg);
	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
							         "iFeatures=",iFeatures);
	}
	/*Encryption will be the first one in the bitmap*/
	xInitCfg.bEncryption = (ucBitMap & LTQ_DECT_ENC_BITMAP);
  /*Nemo status is the second one set in bitmap*/
  bStatus = (ucBitMap & LTQ_DECT_NEMO_BITMAP);
  /*bRfon/off default keep it on,actually its the 3rd one in bitmap*/
#if 0
	xInitCfg.bRfEnable = 1;
	xInitCfg.iDectfd=0;
	xInitCfg.iTimerfd=0;
#endif	
	/*Pass 0 for configuring Nemo on else 1*/
	IFX_DBGC(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,
							         "calling IFX_DECT_MU_NemoConfig value",bStatus);
	IFX_DECT_MU_NemoConfig((bStatus==2)?0:1);
	
   IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO, 
			"***********  Base PIN = ***********", xInitCfg.acBasePin);
   xInitCfg.ucNoOfReg = ucNoOfSubscribedPPs;
   memcpy(&xInitCfg.xRegList,pxPPSubInfo,sizeof(x_IFX_DECT_FTRegList)*6);
   IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
	"Retrieving DECT Configuration and Subscription Info......done");
   if(uiStackMode == IFX_DECT_ASYNC_MODE) {
     IFX_DECT_Async_Init(&xInitCfg,IFX_DECT_InitStatus); 
   }
   else{
     x_IFX_DECT_SyncCallBks xCallbks={0};
     xCallbks.pfnAddFDToSelect = (void (*)(int32,int32 ,pfn_IFX_DECT_FdCallback))IFX_DECT_CMGR_RegFd;
     xCallbks.pfnRemoveFDToSelect = (void (*) (int32,int32))IFX_DECT_CMGR_UnRegFd;
     vbDectStackInitialized = IFX_DECT_Sync_Init(&xInitCfg,&xCallbks);
   }
 
	IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
    			"DECT Stack Initialized.......");
	vbDectStackInitialized = IFX_TRUE;
	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECT_GetStackMsg(x_IFX_DECT_IntFifoMsg *pxIntMsg)
{
  int  n;
	n = ReadFifo(viAgentFifoFd,pxIntMsg,sizeof(x_IFX_DECT_IntFifoMsg));
	return (n > 0)?IFX_SUCCESS:IFX_FAILURE;

}
extern pfn_IFX_DECT_Fsm vax_IFX_DECTFsm[IFX_DECT_STATE_MAX][IFX_DECT_EventMax];
e_IFX_Return IFX_DECT_MsgRouterFdHdlr(IN int32 iFd)
{
  
	if( viAgentFifoFd == iFd )
	{
    x_IFX_DECT_IntFifoMsg xIntMsg;
    e_IFX_ReasonCode eReason;
    memset(&xIntMsg,0,sizeof(x_IFX_DECT_IntFifoMsg));

		//TODO Call Fsm Functions
    while( IFX_SUCCESS == IFX_DECT_GetStackMsg(&xIntMsg) )
    {
      pfn_IFX_DECT_Fsm pfnFsmHandler = 0;
   	  pfnFsmHandler = vax_IFX_DECTFsm[xIntMsg.pxEndptInfo->eState][xIntMsg.xEvtInfo.eEvent];
	    pfnFsmHandler(xIntMsg.pxEndptInfo,&(xIntMsg.xEvtInfo),&eReason);
      /*
	     IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO, 
			  pxEndptInfo->szEndptId, IFX_DECT_GetStateStr(pxEndptInfo->eState) );	*/
    }
	} 
#ifdef ENABLE_PAGING
	if(viPagingKeyFd == iFd)
	{
		uint32 uiPageKeyPressDur;
		char8  aucPagingInfo[32];
		IFX_DBGC(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
																			"Paging Key Pressed");
		if( read(viPagingKeyFd, aucPagingInfo, 32) > 0 )
		{
			uiPageKeyPressDur = atoi(aucPagingInfo);
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
				"Buffer Received From Paging Driver = ", aucPagingInfo);	
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO, 
				"Actual Duration Of Key Pressed = ", uiPageKeyPressDur);
			IFX_DECT_ProcessPagekeyMessage(uiPageKeyPressDur*100);
		}
		else
		{
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
																			"Could Not Read Paging Data Properly");
		}
	}
#endif
#ifdef ULE_SUPPORT
	if(viUleFifoFd == iFd)
	{
		x_IFX_ULE_IPC_Msg xIpcMsg;
		memset(&xIpcMsg,0,sizeof(x_IFX_ULE_IPC_Msg));
		int16 n;
		n=ReadFifo(viUleFifoFd,&xIpcMsg,sizeof(x_IFX_ULE_IPC_Msg));
		if(n>0)
			IFX_ULE_ProcessWebMessage(&xIpcMsg);
	}

#ifdef SMART_HOME_DEMO

	if(viUleSocFd == iFd)
	{
		uchar8 ucBuff[50]={0};
		int16 n;
	//	struct sockaddr_in srvaddr;
		unsigned int uiLen=sizeof(srvaddr);
	//	bzero(&srvaddr,sizeof(srvaddr));
		n = recvfrom(viUleSocFd, ucBuff,sizeof(ucBuff) , 0, (struct sockaddr*)&srvaddr, &uiLen);
		if(n>0)
		{
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT, 
				" Rcvd from DEMO SOC Len=",n);	
			{int i;
				for(i=0;i<n;i++)
				{
					printf(" %x", ucBuff[i]);
				}
				printf("\n");
			}
			IFX_ULE_ProcessSocMessage(ucBuff,n);
		}
		else
		{
			IFX_DBGA(vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
				" Reading from DEMO SOC failed!!!!! ");	
		}
	}

#endif

#endif
	return IFX_SUCCESS;
}



#ifdef DEBUG_COSIC
e_IFX_Return IFX_DECT_DebugCosic(IN uchar8 ucPPInstance, 
	                               IN uchar8 ucReqId, //req id
	                               IN uchar8 ucOper, //read/write
	                               IN uchar8* pcBuf, //Buffer for writing
	                               IN uchar8 ucBufLen
	                               )
{
	x_IFX_DECT_IPC_Msg xIpcMsg = {FP_DEBUG_INFO_RQ};
	
	//printf("Req Id = %d Operation= %d", ucReqId,ucOper);
	//xIpcMsg.ucMsgId = FP_DEBUG_INFO_RQ;
	xIpcMsg.ucInstance = ucPPInstance;
	xIpcMsg.ucPara1 = ucPPInstance + 1;
	xIpcMsg.ucPara2 = ucReqId ;
	xIpcMsg.ucPara3 = ucOper; //R/W - read
	//xIpcMsg.ucPara4 = 0;
	if( pcBuf )
		memcpy(xIpcMsg.acData,pcBuf,ucBufLen);

	return IFX_DECT_SendMsgToStack(&xIpcMsg);
		
}
#endif
