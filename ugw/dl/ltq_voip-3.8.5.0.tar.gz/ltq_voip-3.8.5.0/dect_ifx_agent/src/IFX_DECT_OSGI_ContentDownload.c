/**************************************************************************
 **   SRC_FILE          : IFX_DECT_ContentDownload.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT DATA IWU
 **   SRC VERSION       : v0.1
 **   DATE              : 17th Sept 2010/latest version
 **   AUTHOR            : Sandor Plosz
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
#ifdef LTQ_OSGI_POWER_OUTLET

#include <stdlib.h>             
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stddef.h>
#include <sys/types.h>
#include <sys/socket.h>         
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>            
#include <unistd.h>
#include <sys/select.h>         
#include <sys/un.h>
#include <errno.h>
#include <fcntl.h>
#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_DPSU.h"
#include "IFX_DECT_OSGI_ContentDownload.h"
#include "ifx_debug.h"
//#include "IFX_DECT_GlobalInfo.h"
#include "IFX_AIM_Info.h"
// #include <upnp/ithread.h>
// #include <upnp/upnp.h>

extern uchar8 vucDectAgnetModId;

#define a vucDectAgnetModId
//#define b IFX_DBG_TYPE_CONSOLE
#define b IFX_DBG_LVL_NORMAL
#define c IFX_DBG_STR
#define d IFX_DBG_STR

#define SERVER_PORT 13000

#undef printf
#define IFX_PRINT printf

x_IFX_DECTAPP_CD_ConnectionStruct vaxsoc_sock[IFX_DECTAPP_CD_MAX_CONN]; 
x_IFX_DECTAPP_CD_Message vxCallIntnlSocket;

fd_set vxGlobalReadFdS;
fd_set vxGlobalWriteFdS;  
fd_set vxGlobalExceptFdS;

int32 viInternalSockFd, fdSocket, fdComSocket;
struct sockaddr_un vFILE_name;
struct sockaddr_in serv_addr;
struct sockaddr saddr;

int32 iHTTP;//check to be included in structure.
int32 size;//same as above.
//int32 SocIndex;
int32 arg,arg1;
int32 viReadLength;//same
   

e_IFX_Return IFX_DECT_DPSU_Init (void *Discard){

  int32 i = 0;
  pthread_t Thread;
  	
  IFX_DBGA (a,b,c,"<ContentDownload>API IFX_DECT_DPSU_Init Entry."); 
  for(i = 0; i < IFX_DECTAPP_CD_MAX_CONN; i++){
	
     vaxsoc_sock[i].IsUsed=0;
	 vaxsoc_sock[i].IsDevice=0;
  }  
  
  // This app can communicate with another app via FIFOs. The other app is an UPnP controller.
  IFX_DBGA (a,b,c,"<ContentDownload>API IFX_DECT_DPSU_Init,creating new thread for UPnP .");	
  if (pthread_create (&Thread, NULL,(THREAD_RTN_PTR)IFX_DECTAPP_CD_Thread_Function, NULL)){
     
    IFX_DBGA (a,b,c,"<ContentDownload>API IFX_DECT_DPSU_Init,creating new thread failed."); 
    return IFX_FAILURE;
  }
  IFX_DBGA (a,b,c,"<ContentDownload>API IFX_DECT_DPSU_Init successful.");  
	
  IFX_DBGA (a,b,c,"<ContentDownload>API IFX_DECT_DPSU_Init successful.");
  return IFX_SUCCESS;
}

/*! \brief API ContDownInit is used to initialize ContentDownload and create 
           placeholders for callback functions.
    \return IFX_SUCCESS or IFX_FAILURE;       
*/
e_IFX_Return IFX_DECT_ContDownInit(){

  x_IFX_DECT_DPSU_CallBks xCallBks={0};
 
  IFX_DBGA (a,b,c,"<ContentDownload>ContDownInit:Entry.");
  //Registering callbacks
  xCallBks.pfnCallInitiate= IFX_DECT_DPSU_CallInitiate;
  xCallBks.pfnDataSendToIP = IFX_DECT_DPSU_HandleIncommingData;
  xCallBks.pfnCallRelease =IFX_DECT_DPSU_ReleaseCall;

  IFX_DBGA (a,b,c,"<ContentDownload>ContDownInit:RegisterDataApp invoked.");
  if(IFX_DECT_DPSU_RegisterDataApp(1,&xCallBks) == IFX_FAILURE){

    IFX_DBGA (a,b,c,"<ContentDownload>ContDownInit:RegisterDataApp failed.");
    return IFX_FAILURE;
  }  

  IFX_DBGA (a,b,c,"<ContentDownload>ContDownInit:Init function invoked.");
  if(IFX_DECT_DPSU_Init(NULL) == IFX_FAILURE){

    IFX_DBGA (a,b,c,"<ContentDownload>ContDownInit:Init function failed.");
    return IFX_FAILURE;
  }

  IFX_DBGA (a,b,c,"<ContentDownload>ContDownInit:Successful.");
  return IFX_SUCCESS;
}

void HandleIncomingMessage(unsigned char* data, int length)
{
  int i, /*fd,*/ num;
  //char devices_flag = 0;
  //char temp[5];
  int iLoop/*, count = 0*/;
  int bufLength;
  char8* buffer;	  
  
  printf("Data arrived from FIFO: ");
  for(i=0;i<length;i++)
    printf(" %x",data[i]);  
  printf("\n");
  
  if(length > 0 && data[0] != IFX_AIM_MAGIC)
  {
    printf("Data does not start with IFX_AIM_MAGIC, ignoring message...\n");
    return;
  }
  
  if(length > 1 && data[1] == IFX_AIM_SENDING_DEVICES)
  {
    printf("Sending devices message arrived, alive devices: ");
    i = data[2];
    if(i==0) 
    {
      printf("none\n");
      return;
    }
    
    if(i & IFX_AIM_DEVICE_INDESIT_FRIDGE) printf("fridge");
    if(i & IFX_AIM_DEVICE_INDESIT_WM) printf(", wm ");
    if(i & IFX_AIM_DEVICE_INDESIT_OVEN) printf(", oven ");
    printf("\n");
    
  } 
  else if(data[1] == IFX_AIM_SEND_MEASUREMENT)
  {
    num = (data[3] << 8) | data[4];
    printf("Send measurement message arrived, measurement: %i\n",num);
		
	bufLength = 6;
	buffer = (char8*) malloc(sizeof(char8)*bufLength);
	
	buffer[0] = IFX_AIM_MAGIC;
	buffer[1] = IFX_AIM_SENDING_DEVICE_STATUS;
	buffer[2] = 0;
	buffer[3] = IFX_AIM_STATE_ON;
	buffer[4] = data[3];
	buffer[5] = data[4];	
	
	for (iLoop = 0; iLoop < IFX_DECTAPP_CD_MAX_CONN; iLoop++)
	{		      
		if ((vaxsoc_sock[iLoop].IsUsed!=0) && (vaxsoc_sock[iLoop].IsDevice == IFX_AIM_TERMINAL_IND))
		{
			buffer[2] = vaxsoc_sock[iLoop].Status;		
			IFX_DECT_DPSU_DataSendToDECT (vaxsoc_sock[iLoop].iSessionId, buffer, bufLength);			
		}		
	}
	
	free(buffer);		
	
  }
  
}

//Connect to UPnP controller app.
e_IFX_Return IFX_DECTAPP_CD_Thread_Function()
{
    //int incr = 5;         

    int num, fd;
    char s[300];	    
    
    mknod("upnp_aim_fifo_back", S_IFIFO | 0644 , 0);
    
    fd = open("upnp_aim_fifo_back", O_RDONLY); //Open FIFO
    
    printf("FIFO opened on the other side\n");
    
    do {
        if ((num = read(fd, s, 300)) == -1)  perror("read"); //Blocking read
        else {
            s[num] = '\0';
            printf("FIFO Read: read %d bytes: \"%s\"\n", num, s);
			HandleIncomingMessage((unsigned char*)s,num);
        }
    } while (num > 0);  

    return IFX_SUCCESS;
}

/*! \brief IFX_DECT_DPSU_CallInitiate,this callback function is issued when the PT
           initiates a Data Call to communicate with the Download Server.
    \param[in] uiCallHdl unique Connection handle.
    \param[in] ucHandsetId Handset Number.
    \param[in] uiIEHdl Information Element handle.
    \param[out] pucRejectReason Reason for Call reject.
    \param[out] puiPrivateData data specific to app used to uniquely identify 
                a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_CallInitiate (IN uint32 uiCallHdl,
                                         IN uchar8 ucHandsetId,//
                                         IN uint32 uiIEHdl,
                                         OUT uchar8 *pucRejectReason,//
                                         OUT uint32 *puiPrivateData){

   int32 i = 0;
   int32 iSocIndex = IFX_DECTAPP_CD_MAX_CONN;
   x_IFX_DECTAPP_CD_ConnectionStruct *pxConnectionId = NULL;

   IFX_DBGA (a,b,c,"<ContentDownload>Callbk CallInitiate:Entry.");
   //printf("-----HandsetId is: %x ----\n",ucHandsetId);
   //printf("-----SessionId is: %i ----\n",uiCallHdl);
   //IFX_DECTAPP_AIM_PrintConnInfo();

   if((NULL == pucRejectReason) || (NULL == puiPrivateData) || (0 == uiCallHdl)){

     IFX_DBGA (a,b,c,
     "<ContentDownload>Callbk CallInitiate:puiPrivateData or pucRejectReason is null,or uiCallHdl is 0.");
     return IFX_FAILURE;
   }
   uiIEHdl = 0;
   *pucRejectReason = 0;

	for(i=0;i< IFX_DECTAPP_CD_MAX_CONN;++i){

	  if(vaxsoc_sock[i].IsUsed==0){

	    iSocIndex=i;	
	  }
	}
	if(iSocIndex == IFX_DECTAPP_CD_MAX_CONN){

     IFX_DBGA (a,b,c,"<ContentDownload>Callbk CallInitiate:No free Connection.");
	  return IFX_FAILURE;
	}
	vaxsoc_sock[iSocIndex].IsUsed=1;
	vaxsoc_sock[iSocIndex].IsDevice=0;
	vaxsoc_sock[iSocIndex].DeviceId = 0;
	vaxsoc_sock[iSocIndex].Status = 0;
	
	pxConnectionId = &vaxsoc_sock[iSocIndex];

   IFX_DBGA (a,b,d,"<ContentDownload>Callbk CallInitiate:Connection Index",*pxConnectionId);
   *puiPrivateData = (uint32) &vaxsoc_sock[iSocIndex];
  
   pxConnectionId->iSessionId = uiCallHdl;
   pxConnectionId->status = IFX_DECTAPP_CD_IDLE;
  
   vxCallIntnlSocket.Event = IFX_DECTAPP_CD_DATA_CALL_INIT;
	vxCallIntnlSocket.pxConnId =  pxConnectionId;

   
   IFX_DECT_DPSU_CallAccept(uiCallHdl,0);

	IFX_DBGA (a,b,c,"<ContentDownload>Callbk CallInitiate:Successful.");
	IFX_DECTAPP_AIM_PrintConnInfo();
	return IFX_SUCCESS;
}
    

/*! \brief IFX_DECT_DPSU_CallRelease callback function is called once the DECT 
           stack closes the connection.
    \param[in] uiCallHdl unique Connection Handle.
    \param[in] uiIEHdl Information Element Handle.
    \param[in] eReason Reason for Release.
    \param[in] uiPrivateData data specific to app used to uniquely identify
               a connection.
    \return IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_DECT_DPSU_ReleaseCall( IN uint32 uiCallHdl,//
                                        IN uint32 uiIEHdl,
                                        IN e_IFX_DECT_RelType eReason,//
                                        IN uint32 uiPrivateData){//

   x_IFX_DECTAPP_CD_ConnectionStruct *pxConnectionId = NULL;
   uchar8 wasDevice = 0;
   
   pxConnectionId = (x_IFX_DECTAPP_CD_ConnectionStruct *) uiPrivateData;
   
   uiIEHdl = 0;

   if((0 == uiCallHdl) || (0 == uiPrivateData)){
     
     IFX_DBGA (a,b,c,"<ContentDownload>Callbk CallRelease:uiCallHdl or uiPrivateData is 0.");
     return IFX_FAILURE;
   }

   IFX_DBGA (a,b,c,"<ContentDownload>Callbk CallRelease:Entry.");
   IFX_DECTAPP_AIM_PrintConnInfo();
   
   //vxCallIntnlSocket.Event = IFX_DECTAPP_CD_REMOVE_SOCK_FD;
   //IFX_DBGA (a,b,c,"<ContentDownload>Callbk CallRelease:Close connection to internal socket.");	
   //sendto (viInternalSockFd, &vxCallIntnlSocket, sizeof (vxCallIntnlSocket), 0, (struct sockaddr *) &vFILE_name, size);
	wasDevice = pxConnectionId->IsDevice;
	
    pxConnectionId->IsUsed=0;
	pxConnectionId->IsDevice=0;
	pxConnectionId->DeviceId = 0;
	pxConnectionId->Status = 0;
	if(wasDevice == IFX_AIM_DEVICE_IND) IFX_DECTAPP_AIM_SendDeviceList(NULL);   

   IFX_DBGA (a,b,c,"<ContentDownload>Callbk CallRelease:Successful.");
   IFX_DECTAPP_AIM_PrintConnInfo();
	return IFX_SUCCESS;
}

//Print application debug info
e_IFX_Return IFX_DECTAPP_AIM_PrintConnInfo()
{
	int iLoop = 0;
	
	return IFX_SUCCESS;
	
	printf("\n----------------------------------------------------------------------------------------------\n\t Connection# \t IsUsed \t IsDevice \t DeviceId \t Status \n");
	for (iLoop = 0; iLoop < IFX_DECTAPP_CD_MAX_CONN; iLoop++)
	{		      
		printf("\t   %i \t\t   %x \t\t   %x \t\t   %x \t\t   %x\n",iLoop,vaxsoc_sock[iLoop].IsUsed,vaxsoc_sock[iLoop].IsDevice,vaxsoc_sock[iLoop].DeviceId,vaxsoc_sock[iLoop].Status);		
	} 
	printf("----------------------------------------------------------------------------------------------\n\n	");
	
	return IFX_SUCCESS;
}


//This function checks how many plugs are registered
e_IFX_Return IFX_DECTAPP_AIM_GetConnectedDevices(char8* devs) // result is stored in 1 byte
{
	int i = 0, iLoop = 0;
	
	for (iLoop = 0; iLoop < IFX_DECTAPP_CD_MAX_CONN; iLoop++)
	{		      
		if ((vaxsoc_sock[iLoop].IsUsed!=0) && (vaxsoc_sock[iLoop].IsDevice == IFX_AIM_DEVICE_IND))
		{
			*devs |= vaxsoc_sock[iLoop].DeviceId;
			i++;
			if(i == 4)	printf("<ContentDownload> Something WRONG!! More than 4 Plugs?? \n");
		}
		
	} 

	printf("<ContentDownload> Devices flag is : 0x%x \n",*devs); 
	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECTAPP_AIM_CalcDeviceId(uchar8* devId)
{
	int devs[4] = {0,0,0,0};
	int i, iLoop;
	uchar8 OK = 0;
	
	for (iLoop = 0; iLoop < IFX_DECTAPP_CD_MAX_CONN; iLoop++)
	{
		if ((vaxsoc_sock[iLoop].IsUsed!=0) && (vaxsoc_sock[iLoop].IsDevice == IFX_AIM_DEVICE_IND))
		{
			switch(vaxsoc_sock[iLoop].DeviceId)
			{
				case IFX_AIM_DEVICE_DECT_PLUG1: devs[0]++; break;
				case IFX_AIM_DEVICE_DECT_PLUG2: devs[1]++; break;
				case IFX_AIM_DEVICE_DECT_PLUG3: devs[2]++; break;
				case IFX_AIM_DEVICE_DECT_PLUG4: devs[3]++; break;					
			}
		}		
	}
	
	for(i=0;i<4;i++)
	{
		if(devs[i]==0 && !OK) 
		{
			*devId = 1 << i;
			OK = 1;
		}
		else if(devs[i]>1) printf("\n ERROR, more device has the same id!!!!!!!!!!! \n");		
	}
	if(!OK) 
	{
		printf("\n ERROR, no free device ID!!!!!!!!!!! \n");
		return IFX_FAILURE;
	}
	
	//printf("\n Device is given ID: %x \n",devId);
	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECTAPP_AIM_SendDeviceList(int32* sessionId)
{
	int bufLength;
	char8* buffer;
	char8 devs;
	int iLoop = 0;
	
	//IFX_DBGA (a,b,c,"<ContentDownload> IFX_DECTAPP_AIM_SendDeviceList : Entry.");
	
	bufLength = 3;
	buffer = (char8*) malloc(sizeof(char8)*bufLength);
	
	IFX_DECTAPP_AIM_GetConnectedDevices(&devs);
	//devs = devs | IFX_AIM_DEVICE_INDESIT_FRIDGE | IFX_AIM_DEVICE_INDESIT_WM | IFX_AIM_DEVICE_INDESIT_OVEN;
	
	buffer[0] = IFX_AIM_MAGIC;
	buffer[1] = IFX_AIM_SENDING_DEVICES;
	buffer[2] = devs;
	
	if(sessionId == NULL)
	{  //Send to all
		for (iLoop = 0; iLoop < IFX_DECTAPP_CD_MAX_CONN; iLoop++)
		{		      
			if ((vaxsoc_sock[iLoop].IsUsed!=0) && (vaxsoc_sock[iLoop].IsDevice == IFX_AIM_TERMINAL_IND))
			{
				IFX_DECT_DPSU_DataSendToDECT (vaxsoc_sock[iLoop].iSessionId, buffer, bufLength);
			}		
		}
	}
	else //Send only to requested
	{
		IFX_DECT_DPSU_DataSendToDECT (*sessionId, buffer, bufLength);
	}
	
	//IFX_DBGA (a,b,c,"<ContentDownload> IFX_DECTAPP_AIM_SendDeviceList : Successful.");
	
	free(buffer);
	
	return IFX_SUCCESS;	
}

e_IFX_Return IFX_DECTAPP_AIM_HandleSubscription(uchar8 devId)
{
	int iLoop;
	int bufLength;
	char8* buffer;	
	
	IFX_DBGA (a,b,c, "<ContentDownload>IFX_DECTAPP_AIM_HandleSubscription entry");
	
	for (iLoop = 0; iLoop < IFX_DECTAPP_CD_MAX_CONN; iLoop++)
	{		      
		if ((vaxsoc_sock[iLoop].IsUsed!=0) && (vaxsoc_sock[iLoop].IsDevice == IFX_AIM_DEVICE_IND))
		{
			if(vaxsoc_sock[iLoop].DeviceId == devId) break;
		}		
	}
	
	if(iLoop == IFX_DECTAPP_CD_MAX_CONN)
	{
		printf("\n ERROR, no such device is registered!!!!!!!!!!! \n");
		return IFX_FAILURE;		
	}
	
	if(vaxsoc_sock[iLoop].Status != IFX_AIM_SEND_MEASUREMENT)
	{
		bufLength = 3;
		buffer = (char8*) malloc(sizeof(char8)*bufLength);
		buffer[0] = IFX_AIM_MAGIC;
		buffer[1] = IFX_AIM_START_MEASUREMENT_REQ;
		buffer[2] = 0;		
		IFX_DECT_DPSU_DataSendToDECT (vaxsoc_sock[iLoop].iSessionId, buffer, bufLength);
		free(buffer);		
	}
	//else aready in sending state, so just wait for next message
	
	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECTAPP_AIM_HandleSetStatus(uchar8 devId, uchar8 status)
{
	int iLoop;
	int bufLength;
	char8* buffer;	
	
	 IFX_DBGA (a,b,c, "<ContentDownload>IFX_DECTAPP_AIM_HandleSubscription entry");
	
	for (iLoop = 0; iLoop < IFX_DECTAPP_CD_MAX_CONN; iLoop++)
	{		      
		if ((vaxsoc_sock[iLoop].IsUsed!=0) && (vaxsoc_sock[iLoop].IsDevice == IFX_AIM_DEVICE_IND))
		{
			if(vaxsoc_sock[iLoop].DeviceId == devId) break;
		}		
	}
	
	if(iLoop == IFX_DECTAPP_CD_MAX_CONN)
	{
		printf("\n ERROR, no such device is registered!!!!!!!!!!! \n");
		return IFX_FAILURE;		
	}
	
	bufLength = 3;
	buffer = (char8*) malloc(sizeof(char8)*bufLength);
	buffer[0] = IFX_AIM_MAGIC;
	buffer[1] = IFX_AIM_SET_STATUS_REQ;
	buffer[2] = status;		
	IFX_DECT_DPSU_DataSendToDECT (vaxsoc_sock[iLoop].iSessionId, buffer, bufLength);
	free(buffer);		
		
	return IFX_SUCCESS;
}

e_IFX_Return IFX_DECTAPP_AIM_HandleDeviceMessage(x_IFX_DECTAPP_CD_ConnectionStruct * connStruct, uchar8* msgPtr)
{
	int iLoop, count = 0;
	int bufLength;
	char8* buffer;
	uchar8 devId = connStruct->DeviceId;	
	
	if(devId==0 || devId > IFX_AIM_DEVICE_DECT_PLUG4)
	{
		printf("\n ERROR, this device does not have an ID!!!!!!!!!! \n");
		return IFX_FAILURE;
	}
	
	bufLength = 8;
	buffer = (char8*) malloc(sizeof(char8)*bufLength);
	
	buffer[0] = IFX_AIM_MAGIC;
	buffer[1] = IFX_AIM_SENDING_DEVICE_STATUS;
	buffer[2] = devId;
	buffer[3] = msgPtr[0];
	buffer[4] = msgPtr[1];
	buffer[5] = msgPtr[2];
	buffer[6] = msgPtr[3];	
	buffer[7] = msgPtr[4];		
	
	for (iLoop = 0; iLoop < IFX_DECTAPP_CD_MAX_CONN; iLoop++)
	{		      
		if ((vaxsoc_sock[iLoop].IsUsed!=0) && (vaxsoc_sock[iLoop].IsDevice == IFX_AIM_TERMINAL_IND) && (vaxsoc_sock[iLoop].Status == devId))
		{
			count++;			
			IFX_DECT_DPSU_DataSendToDECT (vaxsoc_sock[iLoop].iSessionId, buffer, bufLength);			
		}		
	}
	
	free(buffer);

	if(count == 0)
	{
		bufLength = 3;
		buffer = (char8*) malloc(sizeof(char8)*bufLength);
		buffer[0] = IFX_AIM_MAGIC;
		buffer[1] = IFX_AIM_STOP_MEASUREMENT_REQ;
		buffer[2] = 0;		
		IFX_DECT_DPSU_DataSendToDECT (connStruct->iSessionId, buffer, bufLength);	
		connStruct->Status = 0;
		free(buffer);	
	}
	
	return IFX_SUCCESS;
}

//This function handles all the incomming data packets
e_IFX_Return IFX_DECT_DPSU_HandleIncommingData (IN uint32 uiCallHdl, IN char8 *pcBuff, IN int32 iLen, IN uint32 uiPrivateData)
{
  int32 i = 0;
  uchar8* pcTempBuff; 
  uchar8 senderType; 
  int bufLength;
  char8* buffer;
  int fd, num;
  char m2[] = { IFX_AIM_MAGIC, IFX_AIM_START_MEASUREMENT_REQ, IFX_AIM_DEVICE_INDESIT_FRIDGE};
  
  x_IFX_DECTAPP_CD_ConnectionStruct *pxConnectionId = NULL;
  
  IFX_DBGA (a,b,c, "<ContentDownload>Callbk IFX_DECT_DPSU_HandleIncommingData entry");

  if((NULL == pcBuff) || (0 == uiCallHdl) || (0 == uiPrivateData)){    
    return IFX_FAILURE;
  }
  
  pxConnectionId = (x_IFX_DECTAPP_CD_ConnectionStruct *) uiPrivateData;
  
  pcTempBuff = (uchar8*) pcBuff;   
  
  //Debug print the data
  printf("\n");  
  printf("DATA PKT ARRIVED:\n");
  for(i=0;i<iLen;i++){
	printf("%x\t",pcTempBuff[i]);
	if( (i>0) && (i%10 == 0)){
		printf("\n");
	}
  }
  printf("\n");
  
  IFX_DECTAPP_AIM_PrintConnInfo();
  
  //Data has to start with IFX_AIM_MAGIC magic
  if(*pcTempBuff != IFX_AIM_MAGIC)
  {
	IFX_DBGC (a,b,c, "<ContentDownload> Data (%x) does not start with IFX_AIM_MAGIC, ingoring message...",*pcTempBuff); 
	return IFX_SUCCESS;
  }
  pcTempBuff++;
  
  senderType = *pcTempBuff++;
  
  //Sender can be either IFX_AIM_DEVICE_IND or IFX_AIM_TERMINAL_IND
  if(senderType == IFX_AIM_DEVICE_IND) 
  {
	IFX_DBGA (a,b,c, "<ContentDownload> IFX_AIM_DEVICE_IND contained in message");
	pxConnectionId->IsDevice = IFX_AIM_DEVICE_IND;	
	
	if(*pcTempBuff == IFX_AIM_DEVICE_HELLO_MSG) //Device sends hello, we register it
	{
		IFX_DBGA (a,b,c, "<ContentDownload> IFX_AIM_DEVICE_HELLO_MSG arrived");
		IFX_DECTAPP_AIM_CalcDeviceId(&pxConnectionId->DeviceId); //Get an ID for the device
		IFX_DECTAPP_AIM_PrintConnInfo();
		IFX_DECTAPP_AIM_SendDeviceList(NULL); // Broadcast new device to connected handsets
		return IFX_SUCCESS;
	}
	else if(*pcTempBuff == IFX_AIM_SEND_MEASUREMENT) // Device is sending power measurement
	{
		int measurement;
		//int total_cons;
		
		pxConnectionId->Status = IFX_AIM_SEND_MEASUREMENT;
		IFX_DECTAPP_AIM_HandleDeviceMessage(pxConnectionId,pcTempBuff+2); //Broadcase measurement to handsets which request it	
		
		//Print debug info
		IFX_DBGA (a,b,c, "<ContentDownload> IFX_AIM_SEND_MEASUREMENT arrived");
		printf("State is: %x, measurement1: %x, measurement2: %x, total1: %x, total2: %x\n",pcTempBuff[2],pcTempBuff[3],pcTempBuff[4],pcTempBuff[5],pcTempBuff[6]);
		if(pcTempBuff[2] == IFX_AIM_STATE_ON) IFX_DBGA (a,b,c, "<ContentDownload> IFX_AIM_STATE_ON");
		if(pcTempBuff[2] == IFX_AIM_STATE_OFF) IFX_DBGA (a,b,c, "<ContentDownload> IFX_AIM_STATE_OFF");
		measurement = pcTempBuff[3];
		measurement = (measurement << 8) | pcTempBuff[4];
		printf("Consumption is: %i W \n\n",measurement);
		measurement = pcTempBuff[5];
		measurement = (measurement << 8) | pcTempBuff[6];
		printf("Total Consumption is: %i Wh \n\n",measurement);

		IFX_DECTAPP_AIM_PrintConnInfo();
		return IFX_SUCCESS;		
	}
  }   
  
  else if(senderType == IFX_AIM_TERMINAL_IND) //Handset message
  {
	  pxConnectionId->IsDevice = IFX_AIM_TERMINAL_IND; 
	  IFX_DECTAPP_AIM_PrintConnInfo();
	  if(*pcTempBuff == IFX_AIM_REQUEST_DEVICES)
	  { //Send device list
		IFX_DBGA (a,b,c, "<ContentDownload> IFX_AIM_REQUEST_DEVICES arrived");		
		IFX_DECTAPP_AIM_SendDeviceList(&pxConnectionId->iSessionId);				
	  } 
	  else if(*pcTempBuff == IFX_AIM_REQUEST_DEVICE_STATUS)
	  {	
		//*pcTempBuff++;
		IFX_DBGA (a,b,c, "<ContentDownload> IFX_AIM_REQUEST_DEVICE_STATUS arrived for device: %x",pcTempBuff);		
		pxConnectionId->Status = *pcTempBuff;
		if(pxConnectionId->Status <= IFX_AIM_DEVICE_DECT_PLUG4)
		  IFX_DECTAPP_AIM_HandleSubscription(pxConnectionId->Status); // Handset subscribes to this device
		else // above IFX_AIM_DEVICE_DECT_PLUG4 are the UPnP devices
		{
		  fd = open("upnp_aim_fifo", O_WRONLY | O_NDELAY);
		  
		  if(fd == -1)
		  {
		    printf("Error, no reader on the other side!!! \n");
		    bufLength = 6;
		    buffer = (char8*) malloc(sizeof(char8)*bufLength);
		    
		    buffer[0] = IFX_AIM_MAGIC;
		    buffer[1] = IFX_AIM_SENDING_DEVICE_STATUS;
		    buffer[2] = pxConnectionId->Status;
		    buffer[3] = IFX_AIM_STATE_ERROR;
		    buffer[4] = 0;
		    buffer[5] = 0;	
		    IFX_DECT_DPSU_DataSendToDECT (pxConnectionId->iSessionId, buffer, bufLength);		    
		    return IFX_SUCCESS;
		  }
		  
		  printf("Sending power request to AIM device\n");
		  m2[2] = pxConnectionId->Status;

		  if ((num = write(fd, m2, 3)) == -1) perror("write");
		  
		}		
		IFX_DECTAPP_AIM_PrintConnInfo();
			  
	  }
	  else if(*pcTempBuff == IFX_AIM_STOP_MEASUREMENT_REQ)
	  {
		pxConnectionId->Status = 0; //So it will no longer receive measurements
	  }
	  else if(*pcTempBuff == IFX_AIM_SET_STATUS_REQ)
	  {
		//*pcTempBuff++;
		IFX_DBGA (a,b,c, "<ContentDownload> IFX_AIM_SET_STATUS_REQ arrived for device: %x",pxConnectionId->Status);		
		if(pxConnectionId->Status == 0)
		{
			IFX_DBGA (a,b,c, "<ContentDownload> ERROR this terminal is not registered to any device!!!");
			return IFX_SUCCESS;			
		}
		IFX_DECTAPP_AIM_HandleSetStatus(pxConnectionId->Status,*pcTempBuff);
		IFX_DECTAPP_AIM_PrintConnInfo();	  
		
	  }
	  else
	  {
		IFX_DBGA (a,b,c, "<ContentDownload> Unknown command, ingoring message..."); 
		return IFX_SUCCESS;  
	  }	  
  
  }
  else
  {
	IFX_DBGA (a,b,c, "<ContentDownload> Unknown sender type, ingoring message..."); 
	return IFX_SUCCESS;  
  }
	return IFX_SUCCESS;  
	
}
#endif
