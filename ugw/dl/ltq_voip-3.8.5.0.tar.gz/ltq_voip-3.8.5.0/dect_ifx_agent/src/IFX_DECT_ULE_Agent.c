/**************************************************************************
 **   SRC_FILE          : IFX_DECT_Agent.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : DECT Agent
 **   SRC VERSION       : v0.1
 **   DATE              : 8th Oct 2007
 **   AUTHOR            : Mahipati Deshpande
 **   DESCRIPTION       :
 **   FUNCTIONS        	:
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
*******************************************************************************/
#ifdef ULE_SUPPORT

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <fcntl.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>



#include <stdio.h>
#include <string.h>
#include <time.h>
/* According to POSIX 1003.1-2001 */
#include <sys/select.h>
/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include "ifx_common_defs.h"
#include "IFX_Config.h"
#include "IFX_TimerIf.h"
#include "IFX_CallMgrIf.h"
#include "IFX_DECT_Stack.h"
#include "IFX_Agents_CfgIf.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_DialPlanIf.h"
#include "IFX_Misc.h"
#include "ifx_debug.h"
#include "IFX_DialPlan.h"
#include "IFX_DECT_MU.h"
#include "IFX_DECT_Agent.h"
#include "IFX_DECT_ULE.h"
#include "IFX_DECT_MsgApi.h"
#include "IFX_DECT_MsgRouter.h"
#include "IFX_AgentsUtils.h"
#include "ifx_ule_defs.h"
#include "IFX_DECT_ULE_Global.h"
uint32 viPageMap[IFX_DECT_MAX_ULE_DEVICES];
uint32 viBPageMap[IFX_DECT_MAX_ULE_DEVICES];
extern uchar8 vucDectAgnetModId;
extern e_IFX_Return  IFX_DECT_MU_ULE_BPagePP_Stop(IN uchar8 ucHandset);
extern e_IFX_Return  IFX_DECT_MU_ULE_BPagePP(IN uchar8 ucHandset,IN uchar8 *pcCnip,IN uchar8 *pcClip);
extern e_IFX_Return IFX_CIF_UleSubsInfoGet(IN uchar8 ucEndptId,OUT x_IFX_CIF_UleSubsInfo *pxDectSubsInfo);
extern e_IFX_Return IFX_CIF_ULESubsInfoSet(IN uchar8 ucEndptId,IN x_IFX_CIF_UleSubsInfo *pxDectSubsInfo);
extern e_IFX_Return IFX_CIF_ULEConfigGet(OUT x_IFX_CIF_ULE_Config *pxULEConfig);
extern e_IFX_Return IFX_DECT_ULE_UpdateSubscInfo(IN uchar8 ucInstanceId,IN x_IFX_DECT_ULE_SubscInfo *pxSubscInfo);
#define IFX_MAX_ULE_DEVICES 10
//#define SMART_HOME_DEMO 1
#ifdef SMART_HOME_DEMO
extern uint32 vuiGwUp;
extern int viUleSocFd;
extern  uchar8 vucCurPagingPPCount ;
extern struct sockaddr_in srvaddr;
extern uchar8 srvflg;
extern void IFX_DECT_ULE_GetReg(uchar8* pucReg,uchar8* pn,uchar8 ucInstance);

#ifdef printf
#undef printf
#endif


void printReg(uchar8* Buf)
{
	int i;
	printf("\n");
	for(i=0;i<4;i++)
	{
		printf(" %x ", Buf[i]);
	}
	printf("\n");
}
#endif

#ifdef HANFUN_SUPPORT
#include <hanfun/agent.h>
#endif

/*****************************************************************************
 *  Function Name   : IFX_DECTAPP_ULE_Notify 
		Description  : call back function to notify the ule toolkit events to app
    INPUT Values	: ucInstanceId ULE Instance Identifier
										 pxULENotify Pointer to the Event Notification Structure
    Return Value  :	IFX_SUCCESS / IFX_FAILURE.
*******************************************************************************/
e_IFX_Return IFX_DECTAPP_ULE_Notify	(IN uchar8 ucInstanceId,
                                     IN x_IFX_DECT_ULE_NotifyEvent *pxULENotify)
{
	if(pxULENotify->eEvent==IFX_DECT_ULE_DATA_SENT_SUCCESS){
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
					"!!!Data sent successfully for",ucInstanceId);

	}else if(pxULENotify->eEvent==IFX_DECT_ULE_DATA_SENT_FAIL){
		IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
					"!!!Data send failed for",ucInstanceId);

	}else if(pxULENotify->eEvent==IFX_DECT_ULE_UPDATE_SUBS_INFO){
		if(IFX_SUCCESS != IFX_CIF_ULESubsInfoSet(ucInstanceId-IFX_DECT_ULE_OFFSET,(x_IFX_CIF_UleSubsInfo *)&(pxULENotify->uxNotify.xSubscInfo)))
		{
		/*	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				szEndptId, 
				"!! Could Not set Subscription Infomration !!");*/
		}
#ifdef SMART_HOME_DEMO

    if(srvflg)
	{
		uchar8 aucReg[4],n;	
//		struct sockaddr_in srvaddr;

//		bzero(&srvaddr,sizeof(srvaddr));
//		srvaddr.sin_family = AF_INET;
//		srvaddr.sin_port   = htons(2222);
//		srvaddr.sin_addr.s_addr=inet_addr("192.168.1.2");
		memset(aucReg,0,4);
		IFX_DECT_ULE_GetReg(&aucReg[0],&n,ucInstanceId);
		printReg(&aucReg[0]);
    		if(sendto(viUleSocFd,&aucReg[0], 4 , MSG_DONTWAIT, (const struct sockaddr*)&srvaddr,sizeof(srvaddr)) < 0)
		{
			IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				"Soc sendto failed - REG INFO!!!!!!!!!.....");
		}
	}
#endif
	}

#ifdef HANFUN_SUPPORT
	IFX_HANFUN_Notify(ucInstanceId, pxULENotify);
#endif

	return IFX_SUCCESS;
}
													  
/*****************************************************************************
 *  Function Name   : IFX_DECTAPP_ULE_DataRecv 
		Description  : call back function to notify   recvd from ule toolkit to app
    INPUT Values	: ucInstanceId ULE Instance Identifier
										 unSize length of the data
										pData--pointer to the data received
    Return Value  :	IFX_SUCCESS / IFX_FAILURE.
*******************************************************************************/
e_IFX_Return IFX_DECTAPP_ULE_DataRecv(IN uchar8 ucInstanceId,
                                     	IN uint16 unSize,
					IN void* pData)
{
#ifdef SMART_HOME_DEMO
    uchar8 aucData[100]={0};
//    struct sockaddr_in srvaddr;

    aucData[00]=0x02;
    aucData[01]=ucInstanceId;
	
   IFX_DECT_ULE_ReleaseExpConnection(ucInstanceId,IFX_DECT_ULE_NORMAL,0);
    memcpy(&aucData[02],((uchar8*)pData),unSize);

//    bzero(&srvaddr,sizeof(srvaddr));
//    srvaddr.sin_family = AF_INET;
//    srvaddr.sin_port   = htons(2222);

//   srvaddr.sin_addr.s_addr=inet_addr("192.168.1.2");

    if(srvflg)
    {
    	if(sendto(viUleSocFd,aucData,unSize+2,MSG_DONTWAIT,(const struct sockaddr*)&srvaddr,sizeof(srvaddr)) < 0)
    	{
        	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           	"Soc sendto failed - ULE Data Recv!!!!!!!!!.....");
    	}
   }
   else
   {
        	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
           	"Demo Srvr Not connected!!!!!!!!!.....");
   }

#elif defined(HANFUN_SUPPORT)

    IFX_HANFUN_ReceiveData(ucInstanceId,unSize,pData);

#else
	FILE *fp;
	time_t clk;
	uchar8 *pucData=(uchar8 *)pData;
	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Enter.....");
	IFX_DECT_ULE_ReleaseExpConnection(ucInstanceId,IFX_DECT_ULE_NORMAL,0);
	if(unSize>0){ // TODO: This code in bracket will be updated later by Lantiq. checkpoint
		// pucData[unSize]='\0';
		fp=fopen("/tmp/UleRxMessages","a");
		clk=time(NULL);
  	fprintf(fp,"%d::%s",ucInstanceId,ctime(&clk));	
		// fprintf(fp,"%d::%s\n",ucInstanceId,pucData);
		fprintf(fp,"%d::",ucInstanceId);
		{
			int i;
			for (i = 0; i < unSize; i++) {
				fprintf(fp,"%02x:", pucData[i]);
			}
			fprintf(fp,"%c", '\n');
		}
		fclose(fp);
	}
#endif
	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Exit.....");
	return IFX_SUCCESS;
}

#ifdef SMART_HOME_DEMO
void IFX_ULE_ProcessSocMessage(uchar8* pucBuff,uint16 n)
{
	if(pucBuff[0] == 0x12)
	{
//		struct sockaddr_in srvaddr;

//		bzero(&srvaddr,sizeof(srvaddr));
//		srvaddr.sin_family = AF_INET;
//		srvaddr.sin_port   = htons(2222);
//		srvaddr.sin_addr.s_addr=inet_addr("192.168.1.2");

		if(vuiGwUp)
		{
			*pucBuff=0x13;
		}

	  if(sendto(viUleSocFd,pucBuff,n,MSG_DONTWAIT,(const struct sockaddr*)&srvaddr,sizeof(srvaddr)) < 0)
		{
			IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Soc sendto failed - Loopback!!!!!!!!!.....");
		}
		if(srvflg == 0)
		{
			uchar8 aucReg[10][4],n=0,i=0;
			memset(&aucReg,0,sizeof(aucReg));
			IFX_DECT_ULE_GetReg(&aucReg[0][0],&n,0);
			IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
			" IFX_DECT_ULE_GetReg Total Reg Dev No=",n);
			for(i=0;i<n;i++)
			{
				printReg(&aucReg[i][0]);
	     		if(sendto(viUleSocFd,&aucReg[i][0],4,MSG_DONTWAIT,(const struct sockaddr*)&srvaddr,sizeof(srvaddr)) < 0)
				{
					IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
					"Soc sendto failed - REG INFO!!!!!!!!!.....",i);
				}

			}
			srvflg=1;
		}

	}
	else if(pucBuff[0] == 0x01)
	{
		char8 acBaseName[IFX_MAX_BASENAME]={'\0'};

		if( vucCurPagingPPCount > 0 )
		{
			IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Reg is not possible Paging is Ongoing!!!!!!!!!.....");
			return;
		}
	    	IFX_CIF_BS_NameGet((char8*)acBaseName);
    		if(acBaseName[0] != '\0'){
	    		IFX_DECT_MU_RegistrationAllow(/*IFX_DECT_REG_DURATION*/60000,(char8*)acBaseName);
    		}
    		else{
	    		IFX_DECT_MU_RegistrationAllow(/*IFX_DECT_REG_DURATION*/60000,NULL);
    		}
	}
	else if(pucBuff[0] == 0x02)
	{

		IFX_DECT_ULE_DataSend(pucBuff[1],n-2,&pucBuff[2]);
	}
	else if(pucBuff[0] == 0x03)
	{
			uchar8 aucReg[10][4],n=0,i=0;
			memset(&aucReg[0][0],0,sizeof(aucReg));
			IFX_DECT_ULE_GetReg(&aucReg[0][0],&n,0);
			IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
			"IFX_DECT_ULE_GetReg Num Of Reg Dev =",n);
			for(i=0;i<n;i++)
			{
			printReg(&aucReg[i][0]);
	     		if(sendto(viUleSocFd,&aucReg[i][0],4,MSG_DONTWAIT,(const struct sockaddr*)&srvaddr,sizeof(srvaddr)) < 0)
				{
					IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_INT,
					"Soc sendto failed - REG INFO!!!!!!!!!.....",i);
				}

			}

	}
	else
	{
		IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Check wrong Msg from DEMO Soc!!!!!!!!!.....");
	}
}
#endif
/******************************************************************************
 *  Function Name   : IFX_ULE_ProcessWebMessage
 *  Description     : This routine processes the messages from the web.
 *  Input Values    : x_IFX_ULE_IPC_Msg structure for ipc messages
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS 
 *  Notes           :
 ****************************************************************************/

e_IFX_Return IFX_ULE_ProcessWebMessage(IN x_IFX_ULE_IPC_Msg *pxIpcMsg)
{
	FILE *fp;
	time_t clk;
	uint16 unSize;
	x_IFX_CIF_UleSubsInfo xPPSubsInfo;
	x_IFX_DECT_ULE_Config xULEConfig;
	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Enter.....");
#ifdef VOIP_NEWVMAPI
	sleep(3);
#endif
	switch(pxIpcMsg->eMsgId)
	{
		case e_IFX_ULE_PAGE:
				if(viPageMap[pxIpcMsg->ucInstance]==0)
				{
					IFX_DECT_MU_PageHandset(pxIpcMsg->ucInstance+IFX_DECT_ULE_OFFSET,(uchar8 *)"Ule locator",(uchar8 *)"Ule locator");
					viPageMap[pxIpcMsg->ucInstance]=1;
				}
				else
				{
					IFX_DECT_MU_StopPagingHandset(pxIpcMsg->ucInstance+IFX_DECT_ULE_OFFSET);
					viPageMap[pxIpcMsg->ucInstance]=0;
				}
		break;
		case e_IFX_ULE_BPAGE:
				if(viBPageMap[pxIpcMsg->ucInstance]==0)
				{
					IFX_DECT_MU_ULE_BPagePP(pxIpcMsg->ucInstance+IFX_DECT_ULE_OFFSET,(uchar8 *)"Ule locator",(uchar8 *)"Ule locator");
					viBPageMap[pxIpcMsg->ucInstance]=1;
				}
				else
				{
					IFX_DECT_MU_ULE_BPagePP_Stop(pxIpcMsg->ucInstance+IFX_DECT_ULE_OFFSET);
					viBPageMap[pxIpcMsg->ucInstance]=0;
				}
		break;
		case e_IFX_ULE_SUBSC_CHG:
			
			memset(&xPPSubsInfo,0,sizeof(xPPSubsInfo));
		if(IFX_SUCCESS != IFX_CIF_UleSubsInfoGet(pxIpcMsg->ucInstance,&xPPSubsInfo ) )
		{
		/*	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				szEndptId, 
				"!! Could Not Read Subscription Infomration !!");*/
			return IFX_SUCCESS;
		}
		IFX_DECT_ULE_UpdateSubscInfo(pxIpcMsg->ucInstance+IFX_DECT_ULE_OFFSET,(x_IFX_DECT_ULE_SubscInfo *)&xPPSubsInfo);
		break;
		case e_IFX_ULE_UNREG:
		IFX_DECT_MU_UNRegister(0,pxIpcMsg->ucInstance+IFX_DECT_ULE_OFFSET);	
		break;
		case e_IFX_ULE_SEND_MSG:
		{
				uchar8 aucData[500];
				uchar8 *pIpcMsg=(uchar8 *)&pxIpcMsg->acData[0];
				memset(&aucData[0],0,500);
				unSize=strlen((char8 *)pxIpcMsg->acData)/3;
				{
  				uint32 unHex;
					uint16 unHexSize = 0;
					uchar8 *puHex=&aucData[0];
					do {
						sscanf((char8 *)pIpcMsg, "%02x",&unHex);
						*puHex = unHex;
						++puHex;
						pIpcMsg += 3;
						++unHexSize;
					} while(unHexSize<unSize);
				}
				IFX_DECT_ULE_DataSend(pxIpcMsg->ucInstance+IFX_DECT_ULE_OFFSET,unSize,aucData);
				fp=fopen("/tmp/UleTxMessages","a");
				if(fp==NULL){
						IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
											"Txmsg fopen failed");
					return IFX_SUCCESS;
				}
				clk=time(NULL);
   			fprintf(fp,"%d::%s",pxIpcMsg->ucInstance+IFX_DECT_ULE_OFFSET,ctime(&clk));	
				fprintf(fp,"%d::%s\n",pxIpcMsg->ucInstance+IFX_DECT_ULE_OFFSET,pxIpcMsg->acData);
				fclose(fp);
		}
		break;
		case e_IFX_ULE_CONFIG:
			memset(&xULEConfig,0,sizeof(xULEConfig));
			if(IFX_SUCCESS != IFX_CIF_ULEConfigGet((x_IFX_CIF_ULE_Config *)&xULEConfig) )
			{
				return IFX_SUCCESS;
			}
			IFX_DECT_ULE_InfoConfigure(&xULEConfig);
		break;
	}
	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Exit.....");
	return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_DECT_AgentInit
 *  Description     : This routine initializes ULE stacktoolkit.
 *  Input Values    : 
 *  Output Values	  : 
 *  Return Value    : Returns IFX_SUCCESS if ULE agent is initialized, else
 *	                  returns IFX_FAILURE
 *  Notes           :
 ****************************************************************************/

e_IFX_Return IFX_DECTAPP_ULEInit()
{
	x_IFX_DECT_ULE_SubscData xSubscData; 
	uchar8 ucNoOfSubscribedPPs = 0;
	//e_IFX_Return eRet = IFX_FAILURE;
	uint16 i;
	x_IFX_DECT_ULE_Config xULEConfig;
	x_IFX_DECT_ULE_CallBks xULECbs;
	memset(&xSubscData,0,sizeof(x_IFX_DECT_ULE_SubscData));
	IFX_DBGA( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Initializing ULE Agent.....");

		 /** Retrieve subscription info from configuration. If subscription info is
		 * available for the endpoint, then set instance number. Otherwise no 
		 * handset is using this endpoint, so assign invalid instance number.
		 */
		for(i=0;i<IFX_MAX_ULE_DEVICES;i++){
			if(IFX_SUCCESS != IFX_CIF_UleSubsInfoGet(i, 
			    (x_IFX_CIF_UleSubsInfo *)&(xSubscData.xRegList[i])) )
			{
			/*IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					szEndptId, 
					"!! Could Not Read Subscription Infomration !!");*/
			}

			if( xSubscData.xRegList[i].cstatus )
			{
			/*	IFX_DBGA(vucDectAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					szEndptId, "This Endpoint Is Registered !!");*/
				ucNoOfSubscribedPPs++;
			}
		}
	/*
	 * Note: Callback functions for DECT endpoint will be registered only after
	 * handset attaches to basestation.
	 */
		xSubscData.unNoOfReg = ucNoOfSubscribedPPs;
    xULECbs.pfnULENotify = IFX_DECTAPP_ULE_Notify; 
    xULECbs.pfnULEDataRecv = IFX_DECTAPP_ULE_DataRecv;
    xULECbs.pfnULEMsgRecv = NULL; 
    //xULECbs.pfnULEInfoStore = NULL;
		memset(&xULEConfig,0,sizeof(xULEConfig));
		if(IFX_SUCCESS == IFX_CIF_ULEConfigGet((x_IFX_CIF_ULE_Config *)&xULEConfig) )
		{
			IFX_DECT_ULE_Init(IFX_MAX_ULE_DEVICES,&xULEConfig,&xSubscData,&xULECbs);
		}else{
			IFX_DECT_ULE_Init(IFX_MAX_ULE_DEVICES,NULL,&xSubscData,&xULECbs);
		}

#ifdef HANFUN_SUPPORT
		IFX_HANFUN_Initialize();
#endif

	IFX_DBGC( vucDectAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		"ULE Agent Initialized");
	return IFX_SUCCESS;
}
#endif
