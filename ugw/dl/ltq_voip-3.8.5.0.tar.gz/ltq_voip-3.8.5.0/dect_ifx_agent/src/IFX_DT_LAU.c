/**************************************************************************
**   FILE NAME     : IFX_DECT_LAU.c
**   PROJECT       : DECT
**   MODULES       : DECT Tool kit
**   SRC VERSION   : V1.0 
**   DATE          : 26-07-2110
**   AUTHOR        : 
**   DESCRIPTION   : Function's related to DT Features 
**   COMPILER      : gcc
**   REFERENCE     : Coding guide lines
**   COPYRIGHT     : Copyright (c) 2004
**                   Infineon Technologies AG, st. Martin Strasse 53;
**                   81669 Munchen, Germany
**
**   Any use of this software is subject to the conclusion of a respective
**   License agreement. Without such a License agreement no rights to the
**   software are granted

**  Version Control Section  **        
**   $Author$    
**   $Date$      
**   $Revisions$ 
**   $Log$       Revision history
***********************************************************************/
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "IFX_DECT_GlobalInfo.h"
#include "IFX_DECT_LAU.h"
#include "IFX_DT_LAU.h"

#define printf(...)
#ifdef LTQ_DT_SUPPORT
/* Default sortig Fields for DT Supported Lists */
uchar8 vacPListDefaultSortingFields[IFX_DT_LAU_MAX_PROP_LISTS] = {
                                                                    IFX_DT_LAU_RSS_CHNL_TITLE,/*Rss-List*/
                                                                    0,/*Radio Station-List*/
                                                                    0,/*sms-List*/
                                                                    IFX_DT_LAU_NET_PHONE_BOOK_LAST_NAME,/*Net-PhoneBook */
                                                                    IFX_DT_LAU_EMAIL_ACC_NAME/*Email-Account */
                                                                  };

/* Supported Editable Fields for DT Supported Tree Lists */
uchar8 vacPListEditableFields[IFX_DT_LAU_MAX_PROP_LISTS][IFX_DT_MAX_EDITABLE]={
   {0},/*Rss-List*/
   {0},/*Radio Station-List*/
   {0},/*sms-List*/
   {0},/*Net-PhoneBook */
   {0}/*Email-Account */
};

/* Supported Un-Editable Fields for DT Supported Tree Lists */
uchar8 vacPListUnEditableFields[IFX_DT_LAU_MAX_PROP_LISTS][IFX_DT_MAX_UNEDITABLE] = {
   {7,IFX_DT_LAU_RSS_CHNL_TITLE,IFX_DT_LAU_RSS_CHNL_TYPE,IFX_DT_LAU_RSS_CHNL_URL,IFX_DT_LAU_RSS_CHNL_UNREAD_MSGS,
      IFX_DT_LAU_RSS_CHNL_TOTAL_MSGS,IFX_DT_LAU_RSS_CHNL_ATTACHED_HANDSETS,IFX_DT_LAU_RSS_CHNL_UPDATE_TIME},/*Rss-List*/
   {0},/*Radio Station-Listi*/
   {0},/*sms-List*/
   {9,IFX_DT_LAU_NET_PHONE_BOOK_LAST_NAME,IFX_DT_LAU_NET_PHONE_BOOK_FIRST_NAME,IFX_DT_LAU_NET_PHONE_BOOK_NUMBER,IFX_DT_LAU_NET_PHONE_BOOK_NUMBER,IFX_DT_LAU_NET_PHONE_BOOK_NUMBER,IFX_DT_LAU_NET_PHONE_BOOK_CITY,IFX_DT_LAU_NET_PHONE_BOOK_ZIP,IFX_DT_LAU_NET_PHONE_BOOK_STREET,IFX_DT_LAU_NET_PHONE_BOOK_BDATE},/*Net-PhoneBook */
   {6,IFX_DT_LAU_EMAIL_ACC_NAME,IFX_DT_LAU_EMAIL_ACC_UNREAD_MSGS,IFX_DT_LAU_EMAIL_ACC_TOTAL_MSGS,
      IFX_DT_LAU_EMAIL_ACC_ADDRESS,IFX_DT_LAU_EMAIL_ACC_ATTACHED_HANDSETS,IFX_DT_LAU_EMAIL_ACC_UPDATE_TIME}/*Email Account */
};

/* Supported Editable Fields for DT Supported Sub Lists */
uchar8 vacSubListEditableFields[2][IFX_DT_MAX_EDITABLE] = {
   {0},/*Rss Sub-List*/
   {0}/*Email-Sub List */
    };

/* Supported UnEditable Fields for DT Supported Sub Lists */
uchar8 vacSubListUnEditableFields[2][IFX_DT_MAX_UNEDITABLE] = {
   {4,IFX_DT_LAU_RSS_CHNL_ENTRY_DATE_TIME,IFX_DT_LAU_RSS_CHNL_ENTRY_READ_STATUS,IFX_DT_LAU_RSS_CHNL_ENTRY_TITLE,
      /*IFX_DT_LAU_RSS_CHNL_ENTRY_TEXT,*/IFX_DT_LAU_RSS_CHNL_ENTRY_URL},/*Rss-SubList*/
   {4,IFX_DT_LAU_EMAIL_ENTRY_READ_STATUS,IFX_DT_LAU_EMAIL_ENTRY_DATE_TIME,IFX_DT_LAU_EMAIL_ENTRY_ADDRESS,
      IFX_DT_LAU_EMAIL_ENTRY_SUBJECT/*,IFX_DT_LAU_EMAIL_ENTRY_TEXT*/}/*Email Account */
};


/* Supported Editable Fields for DT Supported Sub SubLists */
uchar8 vacSubSubListEditableFields[2][IFX_DT_MAX_EDITABLE] = {
   {0},/*Rss Sub-List*/
   {0}/*Email-Sub List */
    };

/* Supported UnEditable Fields for DT Supported Sub SubLists */
uchar8 vacSubSubListUnEditableFields[2][IFX_DT_MAX_UNEDITABLE] = {
   {1,IFX_DT_LAU_RSS_CHNL_ENTRY_TEXT},/*Rss-SubList*/
   {1,IFX_DT_LAU_EMAIL_ENTRY_TEXT}/*Email Account */
};

#define axLauInfo vxGlobalInfo.xLAU.axLauInfo 
#ifdef LTQ_DT_SUPPORT
#define axPropListInfo vxGlobalInfo.xLAU.axPropListInfo
#define iPropListCount vxGlobalInfo.xLAU.iPropListCount
#else
#define axPropListInfo vxGlobalInfo.xLAU.axPropListInfo
#define iPropListCount vxGlobalInfo.xLAU.iPropListCount
#endif

//#define vxLauCallBks vxGlobalInfo.xLAU.vxLauCallBks
//#define iListSupported vxGlobalInfo.xLAU.iListSupported
//#define uiEMCVal vxGlobalInfo.xLAU.uiEMCVal
//#define aunSupportedFieldMap vxGlobalInfo.xLAU.aunSupportedFieldMap

#define IFX_DECT_LAU_DECODE_2BYTEID_DT(pucBuff,nId); {\
     if((*pucBuff) & IFX_NON_EDITABLE_FIELD){\
       nId = (*pucBuff)&IFX_COMPL_VALUE;\
     pucBuff++;\
     }\
     else if((*(pucBuff+1)& IFX_NON_EDITABLE_FIELD )){\
       nId = (((*pucBuff)<<7)|(*(pucBuff+1)&IFX_COMPL_VALUE));\
     pucBuff+=2;\
     }\
   }

#define IFX_DECT_LAU_DECODE_2BYTEID_LEN_DT(pucBuff,nId, iLen); {\
     if(pucBuff[iLen] & IFX_NON_EDITABLE_FIELD){\
       nId = pucBuff[iLen]&IFX_COMPL_VALUE;\
       iLen++;\
     }\
     else if(pucBuff[iLen+1] & IFX_NON_EDITABLE_FIELD){\
       nId = ((pucBuff[iLen]<<7)|(pucBuff[iLen+1]&IFX_COMPL_VALUE));\
       iLen+=2;\
     }\
   }


#define IFX_DECT_LAU_ENCODE_2BYTEID_DT(nVal,pucBuff,iLen); {\
    if(nVal <= IFX_COMPL_VALUE){\
        pucBuff[iLen++] = nVal| IFX_NON_EDITABLE_FIELD ;\
    }\
    else{\
        pucBuff[iLen++] = nVal >> 7;\
        pucBuff[iLen++] = (nVal & IFX_COMPL_VALUE) | IFX_NON_EDITABLE_FIELD;\
    }\
   }

/************************************************************************
* Function Name  : IFX_DT_PopulateSupportedFieldMap
* Description    : To Populate the Supported Field's of Tree List 
* Input Values   : ListId 
* Output Values  : Updated buffer 
* Return Value   : void
* Notes          :
* *************************************************************************/
void
IFX_DT_PopulateSupportedFieldMap(IN OUT uint32 *puiList){
int32 i=0;
uchar8 ucListId=IFX_DECTAPP_getListAccessListId(*puiList);
/*Populate supported field map with editable fields.*/
       for(i=0;i<vacPListEditableFields[ucListId-1][0];i++){
            *(puiList+1) |=
              1<<(vacPListEditableFields[ucListId-1][i+1]-1);
        }
         /*Populate supported field map with uneditable fields.*/
         for(i=0;i<vacPListUnEditableFields[ucListId-1][0];i++){
        *(puiList+1) |=  
        1<<(vacPListUnEditableFields[ucListId-1][i+1]-1);
   }

}

/************************************************************************
* Function Name  : IFX_DT_Get_TreeList_EditUnEditFields 
* Description    : To Get the Editable/UnEditable Field ID's of DT List
* Input Values   : ListId
* Output Values  : Updated x_IFX_DECT_LAU_ListCommand 
* Return Value   : IFX_SUCCESS/IFX_FAILURE 
* Notes          :
* *************************************************************************/

e_IFX_Return IFX_DT_Get_TreeList_EditUnEditFields(IN uchar8 pucListId,
                             OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){
uchar8 ucListId=IFX_DECTAPP_getListAccessListId(pucListId);

if(!vacPListEditableFields[ucListId-1][0]){
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields = 0;
  }else{
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields = vacPListEditableFields[ucListId-1][0];
    memcpy(pxOutCmd->uxListCmd.xFieldQueryCfm.aucEditableFields,&vacPListEditableFields[ucListId-1][1],
           vacPListEditableFields[ucListId-1][0]);
   }

  if(!vacPListUnEditableFields[ucListId-1][0]){
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields = 0;
  }else{
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields = vacPListUnEditableFields[ucListId-1][0];
    memcpy(pxOutCmd->uxListCmd.xFieldQueryCfm.aucUneditableFields,&vacPListUnEditableFields[ucListId-1][1],
           vacPListUnEditableFields[ucListId-1][0]);
   }

return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DT_Get_SubList_EditUnEditFields
* Description    : To Get the Editable/UnEditable Field ID's of DT Sub List
* Input Values   : ListId
* Output Values  : Updated x_IFX_DECT_LAU_ListCommand
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/

e_IFX_Return IFX_DT_Get_SubList_EditUnEditFields(IN uchar8 pucListId,
                             OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){
int16 iIndex=0;
if(pucListId == IFX_DT_LAU_RSS_CHANNEL_LIST )
iIndex=0;
else if(pucListId == IFX_DT_LAU_EMAIL_ACCOUNT_LIST )
iIndex=1;
else
  return IFX_FAILURE;

if(!vacSubListEditableFields[iIndex][0]){
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields = 0;
  }else{
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields = vacSubListEditableFields[iIndex][0];
    memcpy(pxOutCmd->uxListCmd.xFieldQueryCfm.aucEditableFields,&vacSubListEditableFields[iIndex][1],
           vacSubListEditableFields[iIndex][0]);
   }

  if(!vacSubListUnEditableFields[iIndex][0]){
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields = 0;
  }else{
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields = vacSubListUnEditableFields[iIndex][0];
    memcpy(pxOutCmd->uxListCmd.xFieldQueryCfm.aucUneditableFields,&vacSubListUnEditableFields[iIndex][1],
           vacSubListUnEditableFields[iIndex][0]);
   }

return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DT_Get_SubSubList_EditUnEditFields
* Description    : To Get the Editable/UnEditable Field ID's of DT SubSub List
* Input Values   : ListId
* Output Values  : Updated x_IFX_DECT_LAU_ListCommand
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/

e_IFX_Return IFX_DT_Get_SubSubList_EditUnEditFields(IN uchar8 pucListId,
                             OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){
int16 iIndex=0;
if(pucListId == IFX_DT_LAU_RSS_CHANNEL_LIST )
iIndex=0;
else if(pucListId == IFX_DT_LAU_EMAIL_ACCOUNT_LIST )
iIndex=1;
else
  return IFX_FAILURE;

if(!vacSubSubListEditableFields[iIndex][0]){
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields = 0;
  }else{
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfEditableFields = vacSubSubListEditableFields[iIndex][0];
    memcpy(pxOutCmd->uxListCmd.xFieldQueryCfm.aucEditableFields,&vacSubSubListEditableFields[iIndex][1],
           vacSubSubListEditableFields[iIndex][0]);
   }

  if(!vacSubSubListUnEditableFields[iIndex][0]){
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields = 0;
  }else{
    pxOutCmd->uxListCmd.xFieldQueryCfm.ucNoOfUneditableFields = vacSubSubListUnEditableFields[iIndex][0];
    memcpy(pxOutCmd->uxListCmd.xFieldQueryCfm.aucUneditableFields,&vacSubSubListUnEditableFields[iIndex][1],
           vacSubSubListUnEditableFields[iIndex][0]);
   }

return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DT_Get_TreeList_SortingFields
* Description    : To Get the DT List Sorting Fields
* Input Values   : ListId
* Output Values  : Updated x_IFX_DECT_LAU_ListCommand
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          :
* *************************************************************************/

e_IFX_Return IFX_DT_Get_TreeList_SortingFields(IN uchar8 pucListId,
                             OUT x_IFX_DECT_LAU_ListCommands *pxOutCmd){
uchar8 ucListId=IFX_DECTAPP_getListAccessListId(pucListId);
memcpy(pxOutCmd->uxListCmd.xSessionStartCfm.aucSortingFields,
         &vacPListDefaultSortingFields[ucListId-1],
         pxOutCmd->uxListCmd.xSessionStartCfm.ucNoOfSortingFields);
	return IFX_SUCCESS;
}

/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeReadStatus 
* Description    : Encode Email Read Status 
* Input Values   : Command type, editable or not and Read status 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeReadStatus(IN uchar8 CmdType,IN uint32 uiEditable, IN uchar8 pStatus,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=1|0x80;
  printf("\nENTER...ENCODE NEW");
  if(uiEditable != 0){
    pDataPayload[size] = 0xC0;
  }
  else{
    pDataPayload[size] = 0x80;
  }
  if(pStatus){
    pDataPayload[size] |= (1<<5);
  }
  size++;
  *pPayloadSize=size;

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}



/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeNumOfNewFeeds 
* Description    : Encode Num Of New Feeds 
* Input Values   : Command type, editable or not and Feeds count 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeNumOfNewFeeds(IN uchar8 CmdType,
																IN uchar8 pNumOfNewMsgs,
                                OUT uint16* pPayloadSize,
                 								OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  IFX_DECT_LAU_ENCODE_2BYTEID_DT(2,pDataPayload,size);
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" ); 
  pDataPayload[size++]=pNumOfNewMsgs;
  *pPayloadSize=size;	  
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" ); 
}


/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeChannelType 
* Description    : Encode Chanel Type 
* Input Values   : Command type, editable or not and channel type 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeChannelType(IN uchar8 CmdType,IN uchar8 pChanelType,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2 | 0x80;
  pDataPayload[size++]=IFX_EDITABLE_FIELD;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  pDataPayload[size]=pChanelType;
  *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}



/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeChannelTitle 
* Description    : Encode Chanel Title 
* Input Values   : Command type, editable or not and Channel title 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeChannelTitle(IN uchar8 CmdType,
																			IN uchar8* pTitle,
                                 			OUT uint16* pPayloadSize,
                 											OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  
	pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pTitle))+1),pDataPayload,size);
  pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  memcpy(&pDataPayload[size],pTitle,strlen((char8 *)(pTitle)));
  size=size+strlen((char8 *)(pTitle));
	*pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
	
}


/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeChannelURL 
* Description    : Encode Chanel URL 
* Input Values   : Command type, editable or not and url 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeChannelURL(IN uchar8 CmdType, IN uchar8* pURL,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pURL))+1),pDataPayload,size);
	pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  memcpy(&pDataPayload[size],pURL,strlen((char8 *)(pURL)));
  size=size+strlen((char8 *)(pURL));
  *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}

/************************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeNumOfUnreadMsg 
* Description    : Encode Num Of Unread Msgs 
* Input Values   : Command type, editable or not and Msg count 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeNumberOfUnreadMsg(IN uchar8 CmdType,IN uchar8 pNoOfMsgs,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );

  pDataPayload[size++]=CmdType;
	pDataPayload[size++]=2 | 0x80;
	pDataPayload[size++]=0x80;
  pDataPayload[size++]=pNoOfMsgs;
  *pPayloadSize=size;
	
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}

/************************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeTotalMsgs 
* Description    : Encode Total Msgs 
* Input Values   : Command type, editable or not and total msg count 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeTotalMsgs(IN uchar8 CmdType,IN uchar8 pNoOfMsgs,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  
	pDataPayload[size++]=CmdType;
  pDataPayload[size++]= 2 | 0x80;
  pDataPayload[size++]= 0x80;
  pDataPayload[size++]=pNoOfMsgs;
  *pPayloadSize=size;
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );

}

/************************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeUpdateTime 
* Description    : Encode Update Time 
* Input Values   : Command type, editable or not and Update Time 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
**************************************************************************/

void IFX_DECT_LAU_EncodeUpdateTime(IN uchar8 CmdType,IN uint32* pUpdateTime,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  uint32 i=2,iNum=*pUpdateTime,iTemp[3]={0};
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
	pDataPayload[size++]=CmdType;
  pDataPayload[size++]=4 | CmdType;
	pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
	while(iNum != 0){
			iTemp[i]=iNum % 0x100;
			iNum=iNum / 0x100;
	}
	pDataPayload[size++]=iTemp[0];
	pDataPayload[size++]=iTemp[1];
	pDataPayload[size++]=iTemp[2];
  *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeDateTime 
* Description    : Encode Date and time
* Input Values   : Command type, Time and date Information, Editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeDateTime1(IN uchar8 CmdType,
                            IN x_IFX_DECT_USU_TimeDate *pxTimeDate,
							OUT uint16* pPayloadSize,
							OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]= 9|0x80;
	//Editable/non editable
   pDataPayload[size++]=0xC0;
  /* TIME and DATE IE from oct 3*/
  pDataPayload[size++] = 0xC0;//octet 3 coding and interpretation
  memcpy(&pDataPayload[size],pxTimeDate,7);
  *pPayloadSize+=11;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}

/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeTextMsg 
* Description    : Encode Text Msg 
* Input Values   : Command type, editable or not and text message 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeTextMsg(IN uchar8 CmdType, IN uchar8* pTextMsg,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry\n" );
  
	pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pTextMsg))+1),pDataPayload,size);
	pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
	
  memcpy(&pDataPayload[size],pTextMsg,strlen((char8 *)(pTextMsg)));
  size=size+strlen((char8 *)(pTextMsg));
  *pPayloadSize=size;

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}


/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeChanelEntryURL 
* Description    : Encode Channel Entry URL 
* Input Values   : Command type, editable or not and url 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeChannelEntryURL(IN uchar8 CmdType,IN uchar8* pURL,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  pDataPayload[size++]=CmdType;
  IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pURL))+1),pDataPayload,size);
  pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  memcpy(&pDataPayload[size],pURL,strlen((char8 *)(pURL)));
  size=size+strlen((char8 *)(pURL));
  *pPayloadSize=size;
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}


/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeChannelEntryTitle 
* Description    : Encode Channel Entry Title 
* Input Values   : Command type, editable or not and Title 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeChannelEntryTitle(IN uchar8 CmdType,
                                      IN uchar8* pTitle,
                                      OUT uint16* pPayloadSize,
                                      OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pTitle))+1),pDataPayload,size);
  pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;

  memcpy(&pDataPayload[size],pTitle,strlen((char8 *)(pTitle)));
  size=size+strlen((char8 *)(pTitle));
  *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeAttachedPP
* Description    : Encode Attached PPs
* Input Values   : Command type, Number of PPs, Attached PPs, editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeAttachedHandsets(IN uchar8 CmdType,
                              IN uchar8 NoOfPP,
                IN uchar8* pAttachedPP ,
                OUT uint16* pPayloadSize,
                OUT uchar8* pDataPayload)
{
  uchar8 i=0;
  uint16 size=*pPayloadSize,nLenLoc,nNumPP=0;

  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Entry" );

  pDataPayload[size++]=CmdType;
  nLenLoc=size;
  pDataPayload[size++]=2|IFX_NON_EDITABLE_FIELD;

  /*if((uiEditable & IFX_DT_LAU_RSS_CHNL_ATTACHED_HANDSETS_PIN) !=0){
    if(pDataPayload[size] == 0xC0)
      pDataPayload[size] |= 0x01;
  }*/
  //size++;
  pDataPayload[size++]=1|IFX_NON_EDITABLE_FIELD;
  pDataPayload[size++]=NoOfPP|IFX_NON_EDITABLE_FIELD;
  if(NoOfPP == 0){
    *pPayloadSize=size;
    return;
  }
  pDataPayload[size]=IFX_NON_EDITABLE_FIELD;
  pDataPayload[nLenLoc] += 1;
#if 1
  for(nNumPP=0;nNumPP<NoOfPP;nNumPP++){
   if(pAttachedPP[nNumPP]>'0' && pAttachedPP[nNumPP]<='6'){
   	i=pAttachedPP[nNumPP]-'1';
    if(i>=7){
      pDataPayload[size] &= IFX_COMPL_VALUE;
      pDataPayload[size+1] |= ((1<<(i%7)) | IFX_NON_EDITABLE_FIELD);
    }else{
      pDataPayload[size] |= ((1<<(i%7)) | IFX_NON_EDITABLE_FIELD);
     }
   }
  }
#else
  for(i=0;i<IFX_DECT_LAU_MAX_HS;i++){

   if(pAttachedPP[i] == 1){

    if(i>=7){
      pDataPayload[size] &= IFX_COMPL_VALUE;
      pDataPayload[size+1] |= ((1<<(i%7)) | IFX_NON_EDITABLE_FIELD);
    }else{
      pDataPayload[size] |= ((1<<(i%7)) | IFX_NON_EDITABLE_FIELD);
     }

    nNumPP++;
   }
   if(nNumPP==NoOfPP) break;
  }
#endif
  if((pDataPayload[size] & IFX_NON_EDITABLE_FIELD) == 0){
    pDataPayload[nLenLoc] += 1;
    size++;
  }
  size++;
//  for(i=*pPayloadSize;i<size;i++){
//    iprintf("%x\t",pDataPayload[i]);
//  }
//  iprintf("\n");
 *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Exit" );
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeRSS 
* Description    : Encode RSS Feed 
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
**************************************************************************/
int32 IFX_DT_LAU_EncodeRSS(IN int16 nSessId, IN uchar8 ucHSId,
					IN x_IFX_RSS_FEEDS* pRssList,OUT uint16* puiPayloadSize,
          OUT uchar8* pucDataPayload){
	uint16 entry_size=0;
  uchar8 j=0,k=0;
  uint16 size =0;
  int16 nId;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry.." );
  
for(k=0;k<pRssList->ucNumOfChannels;k++){
    j=0;
  /*Entry Identifier*/
  IFX_DECT_LAU_ENCODE_2BYTEID_DT(pRssList->axChannelList[k].nEntryId,
                              pucDataPayload,size);
  entry_size=size;
  /* 2 bytes left for length*/
  size += 2;
  

  while(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
    //printf("Field ID %d\n",axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]);
    switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
		case IFX_DT_LAU_RSS_CHNL_TITLE:
			IFX_DECT_LAU_EncodeChannelTitle(IFX_DT_LAU_RSS_CHNL_TITLE , 
														pRssList->axChannelList[k].ucChannelTitle,
														&size,pucDataPayload);
		break;

		case IFX_DT_LAU_RSS_CHNL_TYPE:
			IFX_DECT_LAU_EncodeChannelType(IFX_DT_LAU_RSS_CHNL_TYPE , 
                            pRssList->axChannelList[k].eChannelType,
                            &size,pucDataPayload);
		break;

		case IFX_DT_LAU_RSS_CHNL_URL:
			IFX_DECT_LAU_EncodeChannelURL(IFX_DT_LAU_RSS_CHNL_URL,
                            pRssList->axChannelList[k].ucChannelURL,
                            &size,pucDataPayload);
		break;

		case IFX_DT_LAU_RSS_CHNL_UNREAD_MSGS:
			IFX_DECT_LAU_EncodeNumberOfUnreadMsg(IFX_DT_LAU_RSS_CHNL_UNREAD_MSGS ,
                           pRssList->axChannelList[k].ucUnreadMsgCount,
                           &size,pucDataPayload);
		break;

		case IFX_DT_LAU_RSS_CHNL_TOTAL_MSGS:
			IFX_DECT_LAU_EncodeTotalMsgs(IFX_DT_LAU_RSS_CHNL_TOTAL_MSGS ,
                           pRssList->axChannelList[k].ucTotalMsgCount,
                            &size,pucDataPayload);
		break;

		case IFX_DT_LAU_RSS_CHNL_ATTACHED_HANDSETS:
		IFX_DECT_LAU_EncodeAttachedHandsets(IFX_DT_LAU_RSS_CHNL_ATTACHED_HANDSETS ,
                            pRssList->axChannelList[k].xAttachedPP.cNoOfPP,
														((uchar8 *)pRssList->axChannelList[k].xAttachedPP.acAttachedPP),
                            &size,pucDataPayload);
		break;

		case IFX_DT_LAU_RSS_CHNL_UPDATE_TIME:
			IFX_DECT_LAU_EncodeUpdateTime(IFX_DT_LAU_RSS_CHNL_UPDATE_TIME , 
                            &pRssList->axChannelList[k].uiUpdateIntrvl,
                            &size,pucDataPayload);
		break;
	}
		j++;
	}
/* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID_DT(nId,pucDataPayload,entry_size);

}
  *puiPayloadSize=size;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeRSSChannel 
* Description    : Encode RSS Channel 
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
**************************************************************************/

int32 IFX_DT_LAU_EncodeRSSChannel(IN int16 nSessId,
     IN uchar8 ucHSId,IN  IN x_IFX_RSS_SUBLISTFEEDS* pRssSublist ,
     OUT uint16* pPayloadSize,OUT uchar8* pDataPayload){

	uint16 entry_size=0;
  uchar8 j=0,k=0;
  uint16 size =0;
  int16 nId;
  
IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Entry" );

  for(k=0;k<pRssSublist->ucNumOfEntries;k++){
    j=0;
  /*Entry Identifier*/
  IFX_DECT_LAU_ENCODE_2BYTEID_DT(pRssSublist->axChannelEntries[k].nEntryId,
                              pDataPayload,size);
  entry_size=size;
  /* 2 bytes left for length*/
  size += 2;

  while(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
    printf("Field ID %d\n",axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]);
    switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){

	case IFX_DT_LAU_RSS_CHNL_ENTRY_DATE_TIME:
		IFX_DECT_LAU_EncodeDateTime1(IFX_DT_LAU_RSS_CHNL_ENTRY_DATE_TIME,
																&pRssSublist->axChannelEntries[k].xTimeDate,
																&size,pDataPayload);
	break;

	case IFX_DT_LAU_RSS_CHNL_ENTRY_READ_STATUS:
		IFX_DECT_LAU_EncodeReadStatus(IFX_DT_LAU_RSS_CHNL_ENTRY_READ_STATUS,1,
																	pRssSublist->axChannelEntries[k].bStatus,
																	&size,pDataPayload);
	break;
	
	case IFX_DT_LAU_RSS_CHNL_ENTRY_TITLE:
		IFX_DECT_LAU_EncodeChannelEntryTitle(IFX_DT_LAU_RSS_CHNL_ENTRY_TITLE,
																					pRssSublist->axChannelEntries[k].ucTitle,
																					&size,pDataPayload);
	break;
/*	
	case IFX_DT_LAU_RSS_CHNL_ENTRY_TEXT:
		IFX_DECT_LAU_EncodeTextMsg(IFX_DT_LAU_RSS_CHNL_ENTRY_TEXT,
																pRssSublist->axChannelEntries[k].ucText,
																&size,pDataPayload);
	break;
*/

	case IFX_DT_LAU_RSS_CHNL_ENTRY_URL:
		IFX_DECT_LAU_EncodeChannelEntryURL(IFX_DT_LAU_RSS_CHNL_ENTRY_URL,
																				pRssSublist->axChannelEntries[k].ucURL,
																				&size,pDataPayload);
	break;

}
j++;
}
/* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pDataPayload[entry_size+1],&pDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID_DT(nId,pDataPayload,entry_size);

}
  *pPayloadSize=size;
  return IFX_SUCCESS;
}


/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeEmailSubject 
* Description    : Encode Channel Entry Title 
* Input Values   : Command type, editable or not and Title 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeEmailSubject(IN uchar8 CmdType,
                                      IN uint32 uiEditable,
                                      IN uchar8* pSubject,
                                      OUT uint16* pPayloadSize,
                                      OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  
	pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pSubject))+1),pDataPayload,size);

  if(((uiEditable) & (IFX_DT_LAU_EMAIL_ENTRY_SUBJECT)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  memcpy(&pDataPayload[size],pSubject,strlen((char8 *)(pSubject)));
  size=size+strlen((char8 *)(pSubject));
  *pPayloadSize=size;
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}

/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeEmailMsg 
* Description    : Encode Email Message 
* Input Values   : Command type, editable or not and Title 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeEmailMsg(IN uchar8 CmdType,
                                      IN uint32 uiEditable,
                                      IN uchar8* pEmailMsg,
                                      OUT uint16* pPayloadSize,
                                      OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );

  pDataPayload[size++]=CmdType;
  IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pEmailMsg))+1),pDataPayload,size);
  if(((uiEditable) & (IFX_DT_LAU_EMAIL_ENTRY_TEXT)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  memcpy(&pDataPayload[size],pEmailMsg,strlen((char8 *)(pEmailMsg)));
  size=size+strlen((char8 *)(pEmailMsg));
  *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}


/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeFromEmailAddress 
* Description    : Encode Email From Address 
* Input Values   : Command type, editable or not and Title 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeFromEmailAddress(IN uchar8 CmdType,
                                      IN uint32 uiEditable,
                                      IN uchar8* pEmailAddrs,
                                      OUT uint16* pPayloadSize,
                                      OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );

  pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pEmailAddrs))+1),pDataPayload,size);
  if(((uiEditable) & (IFX_DT_LAU_EMAIL_ENTRY_ADDRESS)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  memcpy(&pDataPayload[size],pEmailAddrs,strlen((char8 *)(pEmailAddrs)));
  size=size+strlen((char8 *)(pEmailAddrs));
  *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}

/************************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeTotalMails 
* Description    : Encode Total Mails 
* Input Values   : Command type, editable or not and total msg count 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeTotalMails(IN uchar8 CmdType,IN uint32 uiEditable, IN uchar8 pNoOfMsgs,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );

  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2 | 0x80;
if(((uiEditable) & (IFX_DT_LAU_EMAIL_ACC_TOTAL_MSGS)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  pDataPayload[size++]=pNoOfMsgs;
  *pPayloadSize=size;
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}


/************************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeNumOfUnreadMails 
* Description    : Encode Unread  Mails 
* Input Values   : Command type, editable or not and total msg count 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeNumOfUnreadMails(IN uchar8 CmdType,IN uint32 uiEditable, IN uchar8 pNoOfMsgs,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  pDataPayload[size++]=CmdType;
  pDataPayload[size++]=2 | 0x80;

if(((uiEditable) & (IFX_DT_LAU_EMAIL_ACC_UNREAD_MSGS)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  pDataPayload[size++]=pNoOfMsgs;
  *pPayloadSize=size;
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}

/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeAccountName 
* Description    : Encode Account Name 
* Input Values   : Command type, editable or not and Title 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeAccountName(IN uchar8 CmdType,
                                      IN uint32 uiEditable,
                                      IN uchar8* pAccName,
                                      OUT uint16* pPayloadSize,
                                      OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  pDataPayload[size++]=CmdType;
   IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pAccName))+1),pDataPayload,size);

  if(((uiEditable) & (IFX_DT_LAU_EMAIL_ACC_NAME)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  memcpy(&pDataPayload[size],pAccName,strlen((char8 *)(pAccName)));
  *pPayloadSize=size+strlen((char8 *)(pAccName));
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}

/**********************************************************************
* Function Name  : IFX_DECT_LAU_EncodeEmailAddress 
* Description    : Encode Email From Address 
* Input Values   : Command type, editable or not and Title 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeEmailAddress(IN uchar8 CmdType,
                                      IN uint32 uiEditable,
                                      IN uchar8* pEmailAddrs,
                                      OUT uint16* pPayloadSize,
                                      OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;

	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );

  pDataPayload[size++]=CmdType;
  IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pEmailAddrs))+1),pDataPayload,size);
  if(((uiEditable) & (IFX_DT_LAU_EMAIL_ACC_ADDRESS)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  memcpy(&pDataPayload[size],pEmailAddrs,strlen((char8 *)(pEmailAddrs)));
  *pPayloadSize=size+strlen((char8 *)(pEmailAddrs));
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}

/************************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeUpdateTime 
* Description    : Encode Update Time 
* Input Values   : Command type, editable or not and Update Time 
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/

void IFX_DECT_LAU_EncodeEmailUpdateTime(IN uchar8 CmdType,IN uint32 uiEditable, IN uint32* pUpdateTime,
                                 OUT uint16* pPayloadSize,
                 OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  char8 cTemp[10]={"\0"};
  IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Entry" );
  pDataPayload[size++]=CmdType;
	sprintf(cTemp,"%d",*pUpdateTime);
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(cTemp))+1),pDataPayload,size);
	if(((uiEditable) & (IFX_DT_LAU_EMAIL_ACC_UPDATE_TIME)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  memcpy(&pDataPayload[size],cTemp,strlen((char8 *)(cTemp)));
  *pPayloadSize=size+strlen((char8 *)(cTemp));
	IFX_DBGA(vcDECTTKModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                  "Exit" );
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeEmailAccountList 
* Description    : Encode Email
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
**************************************************************************/
int32 IFX_DT_LAU_EncodeEmailAccountList(IN int16 nSessId, IN uchar8 ucHSId,
					IN x_IFX_EMAIL* pEmailList,OUT uint16* puiPayloadSize,
          OUT uchar8* pucDataPayload){
	uint16 entry_size=0;
  uchar8 j=0,k=0;
  uint16 size =0;
  int16 nId;
	

  for(k=0;k<pEmailList->ucNumOfAccounts;k++){
    j=0;
  /*Entry Identifier*/
  IFX_DECT_LAU_ENCODE_2BYTEID_DT(pEmailList->axMailAccounts[k].nEntryId,
                              pucDataPayload,size);
  entry_size=size;
  /* 2 bytes left for length*/
  size += 2;
  

  while(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
    printf("Field ID %d\n",axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]);
    switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
		case IFX_DT_LAU_EMAIL_ACC_NAME:
			IFX_DECT_LAU_EncodeAccountName(IFX_DT_LAU_EMAIL_ACC_NAME , pEmailList-> uiEditField,
														pEmailList->axMailAccounts[k].ucAccountName,
														&size,pucDataPayload);
		break;

		case IFX_DT_LAU_EMAIL_ACC_ADDRESS:
			IFX_DECT_LAU_EncodeEmailAddress(IFX_DT_LAU_EMAIL_ACC_ADDRESS,pEmailList-> uiEditField,
                            pEmailList->axMailAccounts[k].ucEmailAddress,
                            &size,pucDataPayload);
		break;

		case IFX_DT_LAU_EMAIL_ACC_UNREAD_MSGS:
			IFX_DECT_LAU_EncodeNumOfUnreadMails(IFX_DT_LAU_EMAIL_ACC_UNREAD_MSGS ,pEmailList-> uiEditField,
                           pEmailList->axMailAccounts[k].ucUnreadMsgs,
                           &size,pucDataPayload);
		break;

		case IFX_DT_LAU_EMAIL_ACC_TOTAL_MSGS:
			IFX_DECT_LAU_EncodeTotalMails(IFX_DT_LAU_EMAIL_ACC_TOTAL_MSGS , pEmailList-> uiEditField,
                           pEmailList->axMailAccounts[k].ucTotalMsgs,
                            &size,pucDataPayload);
		break;

		case IFX_DT_LAU_EMAIL_ACC_ATTACHED_HANDSETS:
		IFX_DECT_LAU_EncodeAttachedHandsets(IFX_DT_LAU_EMAIL_ACC_ATTACHED_HANDSETS , 
                            pEmailList->axMailAccounts[k].xAttachedPP.cNoOfPP,
														((uchar8 *)pEmailList->axMailAccounts[k].xAttachedPP.acAttachedPP),
                            &size,pucDataPayload);
		break;

		case IFX_DT_LAU_EMAIL_ACC_UPDATE_TIME:
			IFX_DECT_LAU_EncodeEmailUpdateTime(IFX_DT_LAU_EMAIL_ACC_UPDATE_TIME , pEmailList-> uiEditField ,
                            &pEmailList->axMailAccounts[k].uiUpdateTime,
                            &size,pucDataPayload);
		break;
	}
		j++;
	}
/* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID_DT(nId,pucDataPayload,entry_size);
}
  *puiPayloadSize=size;
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeEmailList 
* Description    : Encode Email Account 
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
**************************************************************************/

int32 IFX_DT_LAU_EncodeEmailList(IN int16 nSessId,
     IN uchar8 ucHSId,IN x_IFX_EMAIL_INBOXENTRIES* pEmailList,
     OUT uint16* pPayloadSize,OUT uchar8* pDataPayload){

uint16 entry_size=0;
  uchar8 j=0,k=0;
  uint16 size =0;
  int16 nId;

  for(k=0;k<pEmailList->ucNumOfEntries;k++){
    j=0;
  /*Entry Identifier*/
  IFX_DECT_LAU_ENCODE_2BYTEID_DT(pEmailList->axInboxEntries[k].nEntryId,
                              pDataPayload,size);
  entry_size=size;
  /* 2 bytes left for length*/
  size += 2;

  while(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
    switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){

	case IFX_DT_LAU_EMAIL_ENTRY_DATE_TIME:
		IFX_DECT_LAU_EncodeDateTime1(IFX_DT_LAU_EMAIL_ENTRY_DATE_TIME,
																&pEmailList->axInboxEntries[k].xTimeDate,
																&size,pDataPayload);
	break;

	case IFX_DT_LAU_EMAIL_ENTRY_READ_STATUS:
		IFX_DECT_LAU_EncodeReadStatus(IFX_DT_LAU_EMAIL_ENTRY_READ_STATUS,/*pEmailList-> uiEditField*/1,
																	pEmailList->axInboxEntries[k].bStatus,
																	&size,pDataPayload);
	break;
	
	case IFX_DT_LAU_EMAIL_ENTRY_SUBJECT:
		IFX_DECT_LAU_EncodeEmailSubject(IFX_DT_LAU_EMAIL_ENTRY_SUBJECT,pEmailList-> uiEditField,
																					pEmailList->axInboxEntries[k].ucSubject,
																					&size,pDataPayload);
	break;
	
/*	case IFX_DT_LAU_EMAIL_ENTRY_TEXT :
	IFX_DECT_LAU_EncodeEmailMsg(IFX_DT_LAU_EMAIL_ENTRY_TEXT ,pEmailList-> uiEditField,
																pEmailList->axInboxEntries[k].ucMessage,
																&size,pDataPayload);
	break;
*/
	case IFX_DT_LAU_EMAIL_ENTRY_ADDRESS:
		IFX_DECT_LAU_EncodeFromEmailAddress(IFX_DT_LAU_EMAIL_ENTRY_ADDRESS, pEmailList-> uiEditField,
																				pEmailList->axInboxEntries[k].ucFromAddress,
																				&size,pDataPayload);
	break;

}
j++;
}
/* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pDataPayload[entry_size+1],&pDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID_DT(nId,pDataPayload,entry_size);

}
  *pPayloadSize=size;
  return IFX_SUCCESS;
}

/******************************************************

Net phone book related Encode Functions 

*******************************************************/
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodePhoneBookFirstName
* Description    : Encode First name
* Input Values   : Command type, first name to encode, if editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodePhoneBookFirstName(IN uchar8 CmdType,
                                    IN uint32 uiEditable,
                                    IN char8* pContactFName,
                  OUT uint16* pPayloadSize,
                  OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pContactFName))+1),pDataPayload,size);

	if(((uiEditable) & (IFX_DT_LAU_NET_PHONE_BOOK_FIRST_NAME)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  memcpy(&pDataPayload[size],pContactFName,strlen(pContactFName));
  *pPayloadSize=size+strlen(pContactFName);
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodePhoneBookLastName
* Description    : Encode Last name
* Input Values   : Command type, Last name to encode, if editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodePhoneBookLastName(IN uchar8 CmdType,
                                    IN uint32 uiEditable,
                                    IN char8* pContactFName,
                  OUT uint16* pPayloadSize,
                  OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pContactFName))+1),pDataPayload,size);

  if(((uiEditable) & (IFX_DT_LAU_NET_PHONE_BOOK_LAST_NAME)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }

  memcpy(&pDataPayload[size],pContactFName,strlen(pContactFName));
  *pPayloadSize=size+strlen(pContactFName);
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeCity
* Description    : Encode Last name
* Input Values   : Command type, state name to encode, if editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeCity(IN uchar8 CmdType,
                                    IN uint32 uiEditable,
                                    IN char8* pCityName,
                  OUT uint16* pPayloadSize,
                  OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pCityName))+1),pDataPayload,size);
  if(((uiEditable) & (IFX_DT_LAU_NET_PHONE_BOOK_CITY)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }

  memcpy(&pDataPayload[size],pCityName,strlen(pCityName));
  *pPayloadSize=size+strlen(pCityName);
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeStreet
* Description    : Encode Street name
* Input Values   : Command type, street name to encode, if editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeStreet(IN uchar8 CmdType,
                                    IN uint32 uiEditable,
                                    IN char8* pStreetName,
                  OUT uint16* pPayloadSize,
                  OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
	IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pStreetName))+1),pDataPayload,size);

  if(((uiEditable) & (IFX_DT_LAU_NET_PHONE_BOOK_STREET)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }

  memcpy(&pDataPayload[size],pStreetName,strlen(pStreetName));
 *pPayloadSize=size+strlen(pStreetName);
}


#if 0
/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeState
* Description    : Encode State name
* Input Values   : Command type, Last name to encode, if editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeState(IN uchar8 CmdType,
                                    IN uint32 uiEditable,
                                    IN char8* pStateName,
                  OUT uint16* pPayloadSize,
                  OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pStateName))+1),pDataPayload,size);

  if(((uiEditable) & (IFX_DT_LAU_NET_PHONE_BOOK_STATE)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }

  memcpy(&pDataPayload[size],pStateName,strlen(pStateName));
  *pPayloadSize=size+strlen(pStateName);
}
#endif

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeZip
* Description    : Encode Zip Code 
* Input Values   : Command type, zip code to encode, if editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeZip(IN uchar8 CmdType,
                                    IN uint32 uiEditable,
                                    IN char8* pZipCode,
                  OUT uint16* pPayloadSize,
                  OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pZipCode))+1),pDataPayload,size);
  if(((uiEditable) & (IFX_DT_LAU_NET_PHONE_BOOK_ZIP)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }

  memcpy(&pDataPayload[size],pZipCode,strlen(pZipCode));
  *pPayloadSize=size+strlen(pZipCode);
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodePhoneBookNum 
* Description    : Encode number
* Input Values   : Command type, number to encode, if number is editable
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodePhoneBookNum(IN uchar8 CmdType,
                       IN uint32 uiEditable,
             IN uchar8 ucType,
                       IN char8* pNumber,
             OUT uint16* pPayloadSize,
             OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
  pDataPayload[size++]=CmdType;
IFX_DECT_LAU_ENCODE_2BYTEID_DT((strlen((char8 *)(pNumber))+1),pDataPayload,size);
	if(((uiEditable) & (IFX_DT_LAU_NET_PHONE_BOOK_NUMBER)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD|ucType;
  }
  else{
    pDataPayload[size++]=IFX_NON_EDITABLE_FIELD|ucType;
  }
  
  memcpy(&pDataPayload[size],pNumber,strlen((char8 *)(pNumber)));
  *pPayloadSize=size+strlen((char8 *)(pNumber));
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeDate 
* Description    : Encode Date 
* Input Values   : Command type, date Information, Editable or not
* Output Values  : Updated buffer and payload size
* Return Value   : void
* Notes          : 
* *************************************************************************/
void
IFX_DECT_LAU_EncodeDate(IN uchar8 CmdType,
                            IN uint32 uiEditable,
                            IN x_IFX_DECT_Date *pxDate,
              OUT uint16* pPayloadSize,
              OUT uchar8* pDataPayload)
{
  uint16 size=*pPayloadSize;
	pDataPayload[size++]=CmdType;
  pDataPayload[size++] = 9 | 0x80; //Encoding the length
	if(((uiEditable) & (IFX_DT_LAU_NET_PHONE_BOOK_BDATE)) != 0){
    pDataPayload[size++]=IFX_EDITABLE_FIELD;
  }
  else{
  	pDataPayload[size++]=IFX_NON_EDITABLE_FIELD;
  }
  memcpy(&pDataPayload[size],pxDate,sizeof(x_IFX_DECT_Date));
  *pPayloadSize+=11;
}


/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeNetPhoneBook 
* Description    : Encode Net Phone Book 
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DT_LAU_EncodeNetPhoneBook(IN int16 nSessId,
                               IN uchar8 ucHSId,
                               IN x_IFX_NET_PHONE_BOOK *pPhoneBook,
                   OUT uint16* punPayloadSize,
                   OUT uchar8* pucDataPayload)
{
  uint16 entry_size=0;
  uint16 i=0,j=0,k=0;
  uint16 size =0;
  int16 nId;
  for(i=0;i<pPhoneBook->unNoOfEntries;i++){

    /*Entry Identifier*/
    IFX_DECT_LAU_ENCODE_2BYTEID_DT(pPhoneBook->axPhoneBookEntries[i].nEntryId,
                              pucDataPayload,size);
    entry_size=size;
    /* 2 bytes left for length*/
    size += 2;
  j=0;
        k=0;
    while(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
      switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){
    case IFX_DT_LAU_NET_PHONE_BOOK_LAST_NAME:
      IFX_DECT_LAU_EncodePhoneBookLastName(IFX_DT_LAU_NET_PHONE_BOOK_LAST_NAME,
                              (pPhoneBook->axPhoneBookEntries[i].uiEditField & IFX_DECT_LAU_CL_LNAME),
                      pPhoneBook->axPhoneBookEntries[i].acLastName,
                      &size,pucDataPayload);
		break;

 		case IFX_DT_LAU_NET_PHONE_BOOK_FIRST_NAME:
      IFX_DECT_LAU_EncodePhoneBookFirstName(IFX_DT_LAU_NET_PHONE_BOOK_FIRST_NAME,
                                         (pPhoneBook->axPhoneBookEntries[i].uiEditField & IFX_DECT_LAU_CL_FNAME),
                       pPhoneBook->axPhoneBookEntries[i].acFirstName,
                       &size,pucDataPayload);
    break;
    case IFX_DT_LAU_NET_PHONE_BOOK_NUMBER:
        if(k >= pPhoneBook->axPhoneBookEntries[i].xNumber.ucNoOfContactNumbers){
          j++;
          continue;
        }
        IFX_DECT_LAU_EncodePhoneBookNum(IFX_DT_LAU_NET_PHONE_BOOK_NUMBER,
          pPhoneBook->axPhoneBookEntries[i].uiEditField & IFX_DECT_LAU_CL_NUM,
                  pPhoneBook->axPhoneBookEntries[i].xNumber.xNum[k].ctype,
                    pPhoneBook->axPhoneBookEntries[i].xNumber.xNum[k].acNumber,
                  &size,pucDataPayload);
        k++;
        break;
		
	case IFX_DT_LAU_NET_PHONE_BOOK_CITY:
				IFX_DECT_LAU_EncodeCity(IFX_DT_LAU_NET_PHONE_BOOK_CITY,
                                         (pPhoneBook->axPhoneBookEntries[i].uiEditField),
                       pPhoneBook->axPhoneBookEntries[i].acCity,
                       &size,pucDataPayload);

	break;

	case IFX_DT_LAU_NET_PHONE_BOOK_STREET:
			IFX_DECT_LAU_EncodeStreet(IFX_DT_LAU_NET_PHONE_BOOK_STREET,
                                         (pPhoneBook->axPhoneBookEntries[i].uiEditField ),
                       pPhoneBook->axPhoneBookEntries[i].acStreet,
                       &size,pucDataPayload);

	break;

	/*case IFX_DT_LAU_NET_PHONE_BOOK_STATE:
			IFX_DECT_LAU_EncodeState(IFX_DT_LAU_NET_PHONE_BOOK_STATE,
                                         (pPhoneBook->axPhoneBookEntries[i].uiEditField ),
                       pPhoneBook->axPhoneBookEntries[i].acState,
                       &size,pucDataPayload);

	break;		*/

	case IFX_DT_LAU_NET_PHONE_BOOK_ZIP:
		IFX_DECT_LAU_EncodeZip(IFX_DT_LAU_NET_PHONE_BOOK_ZIP,
                                         (pPhoneBook->axPhoneBookEntries[i].uiEditField),
                       pPhoneBook->axPhoneBookEntries[i].acZip,
                       &size,pucDataPayload);

  break;

	case IFX_DT_LAU_NET_PHONE_BOOK_BDATE:
		 IFX_DECT_LAU_EncodeDate(IFX_DT_LAU_NET_PHONE_BOOK_BDATE,
                                         (pPhoneBook->axPhoneBookEntries[i].uiEditField),
                       &pPhoneBook->axPhoneBookEntries[i].xBirthDay,
                       &size,pucDataPayload);

	break;
}
      j++;
}
    /* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pucDataPayload[entry_size+1],&pucDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID_DT(nId,pucDataPayload,entry_size);
}

  *punPayloadSize=size;
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DECTAPP_isProprietaryList 
* Description    : To check List belongs to ProprietaryList 
* Input Values   : List ID 
* Output Values  : none
* Return Value   : IFX_SUCCESS,IFX_FAILURE
* Notes          :
* *************************************************************************/


e_IFX_Return IFX_DECTAPP_isProprietaryList(IN uchar8 pucListId){

switch(pucListId){
    case IFX_DT_LAU_RSS_CHANNEL_LIST:
    case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
    case IFX_DT_LAU_NET_PHONE_BOOK:
          return IFX_SUCCESS;
    break;

    default:
          return IFX_FAILURE;
}

}


/************************************************************************
* Function Name  : IFX_DECTAPP_getListAccessListId 
* Description    : To get List access id of DT List 
* Input Values   : List ID 
* Output Values  : none
* Return Value   : List ID / Index 
* Notes          :
* *************************************************************************/

uchar8 IFX_DECTAPP_getListAccessListId(IN uchar8 pucListId){
      return (pucListId % 0x80) + 1;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_EncodeSubSubList 
* Description    : Encode Email/RSS/SMS Sub SubList
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
**************************************************************************/

int32 IFX_DT_LAU_EncodeSubSubList(IN int16 nSessId,
     IN uchar8 ucHSId,IN  x_IFX_SUB_SUBLIST *pxSubList,
     OUT uint16* pPayloadSize,OUT uchar8* pDataPayload){

  uint16 entry_size=0;
  uchar8 j=0,k=0;
  uint16 size =0;
  int16 nId;
		//printf("<IFX_DT_LAU_EncodeSubSubList> Functions Called for %d Number of Entries \n",pxSubList->ucNumOfEntries);
  for(k=0;k<pxSubList->ucNumOfEntries;k++){
    j=0;
  /*Entry Identifier*/
  IFX_DECT_LAU_ENCODE_2BYTEID_DT(pxSubList->axSubTextEntiries[k].nEntryId,
                              pDataPayload,size);
  entry_size=size;
  /* 2 bytes left for length*/
  size += 2;

  while(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]!=0){
    //printf("Field ID %d\n",axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]);
    switch(axLauInfo[ucHSId][nSessId].aucFieldIdsList[j]){

case IFX_DT_LAU_EMAIL_ENTRY_TEXT :
 IFX_DECT_LAU_EncodeTextMsg(IFX_DT_LAU_EMAIL_ENTRY_TEXT ,
                                pxSubList->axSubTextEntiries[k].ucText,
                                &size,pDataPayload);
  break;
}
j++;
}
/* encode the size*/
  if(size-(entry_size+2) <=127){
    memmove(&pDataPayload[entry_size+1],&pDataPayload[entry_size+2],size-(entry_size+2));
    size--;
    nId = (size-(entry_size+1));
  }else{
    nId = (size-(entry_size+2));
   }
    IFX_DECT_LAU_ENCODE_2BYTEID_DT(nId,pDataPayload,entry_size);

/*IFX_DECT_LAU_DataPktSend(nSessId,
                           size,
                           pDataPayload);*/
}
  *pPayloadSize=size;
  return IFX_SUCCESS;
}




/************************************************************************
* Function Name  : IFX_DECT_LAU_SubListDataPktPayloadEncode 
* Description    : Encode Sublist of RSS/Email 
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DT_SubSubList_DataPktPayloadEncode( IN int16 nSessId,
                                   IN uchar8 ucListCmdType,
                   IN void* pvPayloadStruct,
                   OUT uint16* punPayloadSize,
                   OUT char8* pucDataPayload)

{
  uchar8 ucHSId=0;
  *punPayloadSize=0;
  /* Store the requested fields locally */
  if(IFX_DECT_LAU_GetHSIdFromSessId(&ucHSId,nSessId) != IFX_SUCCESS){
       return IFX_FAILURE;
  }
  //printf("\nEntered <IFX_DECT_LAU_SubSubListDataPktPayloadEncode> Function.......");
  switch(ucListCmdType)
  {
    case IFX_DT_LAU_RSS_CHANNEL_LIST:
		case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
  {
		x_IFX_SUB_SUBLIST *axSubList=(x_IFX_SUB_SUBLIST *)pvPayloadStruct;;
    IFX_DT_LAU_EncodeSubSubList((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
                                         axSubList,
                                         punPayloadSize,
                                         ((uchar8 *)pucDataPayload));

	}
	break;
	default:
    return IFX_FAILURE;
  }
  return IFX_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_DECT_LAU_SubListDataPktPayloadEncode 
* Description    : Encode Sublist of RSS/Email 
* Input Values   : Session Id,Handset ID, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Handset ID and Session number of that Handset. This is not 
*                  the same as session number
* *************************************************************************/
e_IFX_Return
IFX_DT_SubList_DataPktPayloadEncode( IN int16 nSessId,
                                   IN uchar8 ucListCmdType,
                   IN void* pvPayloadStruct,
                   OUT uint16* punPayloadSize,
                   OUT char8* pucDataPayload)

{
  uchar8 ucHSId=0;
  *punPayloadSize=0;
  /* Store the requested fields locally */
  if(IFX_DECT_LAU_GetHSIdFromSessId(&ucHSId,nSessId) != IFX_SUCCESS){
       return IFX_FAILURE;
  }
  //printf("\nEntered <IFX_DECT_LAU_SubListDataPktPayloadEncode> Function.......");
  switch(ucListCmdType)
  {
    case IFX_DT_LAU_RSS_CHANNEL_LIST:
  {
    x_IFX_RSS_SUBLISTFEEDS *pxRssFeeds =( x_IFX_RSS_SUBLISTFEEDS *)pvPayloadStruct; ;
    IFX_DT_LAU_EncodeRSSChannel((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
                                         pxRssFeeds,
                                         punPayloadSize,
                                         ((uchar8 *)pucDataPayload));
 }
  break;

  case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
  {
    x_IFX_EMAIL_INBOXENTRIES *pxEmails=( x_IFX_EMAIL_INBOXENTRIES *)pvPayloadStruct;;
    IFX_DT_LAU_EncodeEmailList((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
                                         pxEmails,
                                         punPayloadSize,
                                         ((uchar8 *)pucDataPayload));

  }
  break;

	default:
    return IFX_FAILURE;
  }
  return IFX_SUCCESS;
}


/************************************************************************
* Function Name  : IFX_DT_TreeList_DataPktPayloadEncode 
* Description    : Encode the data packet
* Input Values   : Session Id,Command type, Data in struct format
* Output Values  : Updated buffer and payload size
* Return Value   : IFX_SUCCESS/IFX_FAILURE
* Notes          : Session ID is required to encode only the requested fields
* *************************************************************************/
e_IFX_Return
IFX_DT_TreeList_DataPktPayloadEncode( IN int16 nSessId,
                                   IN uchar8 ucListCmdType,
                   IN void* pvPayloadStruct,
                   OUT uint16* punPayloadSize,
                   OUT char8* pucDataPayload)

{
  uchar8 ucHSId=0;
  *punPayloadSize=0;
  /* Store the requested fields locally */
  if(IFX_DECT_LAU_GetHSIdFromSessId(&ucHSId,nSessId) != IFX_SUCCESS){
       return IFX_FAILURE;
  }
 // printf("\nEntered Encode function....");
  switch(ucListCmdType)
  {
			 case IFX_DT_LAU_RSS_CHANNEL_LIST:
  {
    x_IFX_RSS_FEEDS *pxRssFeed =(x_IFX_RSS_FEEDS *)pvPayloadStruct; ;
    IFX_DT_LAU_EncodeRSS((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
                                         pxRssFeed,
                                         punPayloadSize,
                                         ((uchar8 *)pucDataPayload));


  }
  break;

  case IFX_DT_LAU_EMAIL_ACCOUNT_LIST:
  {
    x_IFX_EMAIL *pxEmail=( x_IFX_EMAIL *)pvPayloadStruct;;
    IFX_DT_LAU_EncodeEmailAccountList((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
                                         pxEmail,
                                         punPayloadSize,
                                         ((uchar8 *)pucDataPayload));

  }
  break;
  case IFX_DT_LAU_NET_PHONE_BOOK:
  {
    x_IFX_NET_PHONE_BOOK *xPhoneBook=(x_IFX_NET_PHONE_BOOK *)pvPayloadStruct;;
    IFX_DT_LAU_EncodeNetPhoneBook((nSessId % IFX_DECT_LAU_MAX_SESS_PER_HS)-1,ucHSId-1,
                                         xPhoneBook,
                                         punPayloadSize,
                                         ((uchar8 *)pucDataPayload));

  }
  break;
   default:
    return IFX_FAILURE;
  }
  return IFX_SUCCESS;
}

e_IFX_Return
IFX_DECT_LAU_EmailNotify(uchar8 ucHandsetId,uchar8 rss_email,uint16 ucNoOfUnreadMsg)
{
  int32 i=0;
  x_IFX_DECT_USU_EventList xEventList={0};
  
//iprintf("%s: HS %d rss_email %d msg %d\n", __func__, ucHandsetId, rss_email, ucNoOfUnreadMsg);
  xEventList.ucNoOfEvents=1;
	if (rss_email==0) {
	  xEventList.axEvent[i].ucEventType=IFX_DECT_EVT_TYPE_WC;	/*Message Waiting*/
	  xEventList.axEvent[i].ucEventSubtype = IFX_DECT_MW_EVT_STYPE_RSS;
	}
	else {
	  xEventList.axEvent[i].ucEventType=IFX_DECT_EVT_TYPE_MW;	/*Message Waiting*/
	  xEventList.axEvent[i].ucEventSubtype = IFX_DECT_MW_EVT_STYPE_EMAIL;
  }
  xEventList.axEvent[i].unEventMultiplicity = ucNoOfUnreadMsg;

  if(IFX_DECT_USU_GenericEventNotify(ucHandsetId,&xEventList) != IFX_SUCCESS){
    return IFX_FAILURE;
  }
  return IFX_SUCCESS;
}

e_IFX_Return
IFX_DECT_LAU_DT_Notify(uchar8 ucHandsetId,uchar8 rss_count,uint16 RSSUnreadMsg,uchar8 mail_count,uint16 MailUnreadMsg)
{
  //int32 i=0;
  x_IFX_DECT_USU_EventList xEventList={0};

  if(!IFX_DECT_MU_IsCAT2(ucHandsetId)){
    return IFX_FAILURE;
  }
//iprintf("%s: HS %d rss %d email %d RSSmsg %d mailmsg %d\n", __func__, ucHandsetId, rss_count,mail_count,RSSUnreadMsg,MailUnreadMsg);
#if 1	//cause SPP700 crashed
  xEventList.ucNoOfEvents = 2;
  xEventList.axEvent[0].ucEventType = IFX_DECT_EVT_TYPE_LCI; /* Indicating List Change */
  xEventList.axEvent[0].ucEventSubtype = IFX_DT_LAU_RSS_CHANNEL_LIST;
  xEventList.axEvent[0].unEventMultiplicity = rss_count;

  xEventList.axEvent[1].ucEventType = IFX_DECT_EVT_TYPE_LCI; /* Indicating List Change */
  xEventList.axEvent[1].ucEventSubtype = IFX_DT_LAU_EMAIL_ACCOUNT_LIST;
  xEventList.axEvent[1].unEventMultiplicity = mail_count;

  if(IFX_DECT_USU_GenericEventNotify(ucHandsetId,&xEventList) != IFX_SUCCESS){
    return IFX_FAILURE;
  }
  //waitTick(20);
	sleep(2);
#endif  
  xEventList.ucNoOfEvents=2;	//3 is maximum
  xEventList.axEvent[0].ucEventType=IFX_DECT_EVT_TYPE_WC;	/*Message Waiting*/
  xEventList.axEvent[0].ucEventSubtype = IFX_DECT_MW_EVT_STYPE_RSS;
  xEventList.axEvent[0].unEventMultiplicity = RSSUnreadMsg;

  xEventList.axEvent[1].ucEventType=IFX_DECT_EVT_TYPE_MW;	/*Message Waiting*/
  xEventList.axEvent[1].ucEventSubtype = IFX_DECT_MW_EVT_STYPE_EMAIL;
  xEventList.axEvent[1].unEventMultiplicity = MailUnreadMsg;
  if(IFX_DECT_USU_GenericEventNotify(ucHandsetId,&xEventList) != IFX_SUCCESS){
    return IFX_FAILURE;
  }
  return IFX_SUCCESS;
}


#endif
