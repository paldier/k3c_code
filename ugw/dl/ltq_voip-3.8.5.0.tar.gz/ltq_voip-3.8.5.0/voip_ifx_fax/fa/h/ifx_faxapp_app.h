/*****************************************************************************
**   FILE NAME       : ifx_FAXAPP_app.h
**   PROJECT         : RTP/RTCP
**   MODULES         : Session Management Module.
**   SRC VERSION     : V1.0
**   DATE            : 10-05-2006
**   AUTHOR          : Deepak Shrivastava.
**   DESCRIPTION     : This file contains data structure of session management.
**                     
**   FUNCTIONS       :
**   COMPILER        :
**   REFERENCE       : RTP-RTCP desgin dcoument, Coding guide lines
**   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
**                     St. Martin Strasse 53; 81669 München, Germany
**                     Any use of this Software is subject to the conclusion
**                     of a respective License Agreement.Without such a
**                     License Agreement no rights to the Software are granted.
**  Version Control Section  **
**   $Author$
**   $Date$
**   $Revisions$
**   $Log$       Revision history
*****************************************************************************/
#ifndef __IFX_FAXAPP_APP_H__
#define __IFX_FAXAPP_APP_H__

/* Local Fax Agent Definitions */
#define IFX_FAXAPP_MAX_FAX_PROFILES        6
#define IFX_FAXAPP_MAX_CONNECTIONS         4
#define IFX_FAXAPP_MAX_PHONE_CHANNELS      2

#define IFX_FAXAPP_MLIB_ID                 1

#define IFX_FAXAPP_DATA_PUMP_DATA          1
#define IFX_FAXAPP_DATA_PUMP_COMMAND       2

/* Protocol Specific Definitions */
#define IFX_FAXAPP_TCP_SOCKTYPE_SERVER     1
#define IFX_FAXAPP_TCP_SOCKTYPE_CLIENT     2
#define IFX_FAXAPP_TCP_PORT_TYPE_SERVER    IFX_FAXAPP_TCP_SOCKTYPE_SERVER 
#define IFX_FAXAPP_TCP_PORT_TYPE_CLIENT    IFX_FAXAPP_TCP_SOCKTYPE_CLIENT
#define IFX_FAXAPP_MAX_BUFFER_LEN          512

#define IFX_FAXAPP_MAX_LINE_LEN            256
#define IFX_FAXAPP_MAX_BYTE_VALUE          16
#define IFX_FAXAPP_DEC_VALUE               10

typedef struct
{
   /* No need for storing ChannelNum, Table will be indexed on
    * Channel Num, will start from 0
    */
   /* Channel Info Bits */

   /* Protocol Types */
   #define IFX_FAXAPP_PROTOCOL_TCP          0
   #define IFX_FAXAPP_PROTOCOL_UDP          1 

   /* Coder Allocated */
   uchar8            ucCoder;

   /* Call Id Allocated for this Session */
   uint32            uiCallId;
   
   /* Call Status */
   #define IFX_FAXAPP_NO_CALL                 0x0
   #define IFX_FAXAPP_CALL_IN_PROG            0x1
   #define IFX_FAXAPP_CALL_TEAR_DOWN          0x2

   uchar8            ucCallStatus;

   /* Type of Connection - Relevant only of ucProtocol == TCP */
   uchar8            ucTcpTOC;
   
   int32             nConnId;    
   /* TCP Server socket fd */
   int16             nTcpServerSockFd;    

   /* TCP send socket fd */
   int16             nTcpSendSockFd;    

   /* TCP recv socket fd */
   int16             nTcpRecvSockFd;    

   /* UDP socket fd */
   int16             nUdpSockFd;    

   /* Fax/Fax Fd */
   int16             nFaxFd;

   /* Local Info */
   /* We can use SockFds for all purposes.  We need the local port number
    * only for port management when the connection is closed.  We have to
    * restore the port to the port pool.
    */
   uint16            unLocalPort;
//#ifdef IFX_T38_FW
char8 acLocalIpAddr[IFX_IP_ADDR_LEN];
//#endif
 
   /* Remote Info */
   uint16            unRemotePort;
   char8             acRemoteIpAddr[IFX_IP_ADDR_LEN];

   /* Data Pump Config Parameters */
   /* Data pump resource number */
   uchar8            ucDPNR;

   /* Tx and Rx Gain Values */
   uint16            unGain1;
   uint16            unGain2;

   /* Datapump Mailbox Sizes */

   uint16            unMOBSM;
   uint16            unMOBRD;
   uint16            unDMBSD;
   
   /* Packet Buffer */
   uchar8            * pucBuffer;
	 
  char8 szCoderDeviceName[32];
   
} x_IFX_FAXAPP_ConnectionInfo;


int8 IFX_FAXAPP_EventNotifier(uint32 uiCallId, e_IFX_ReasonCode eReasonCode);

/*FAXAPP APi's*/
int32 IFX_FAXAPP_AppInit(uchar8 ucDbgLvl,uchar8 ucDbgType,x_IFX_VMAPI_T38Cfg  *pxFA_T38Cfg);

int32 IFX_FAXAPP_AppMain(uchar8 ucDbgLvl,uchar8 ucDbgType,x_IFX_VMAPI_T38Cfg  *pxFA_T38Cfg);

int8 IFX_FAXAPP_DbgInit(uchar8 ucDbgLvl,uchar8 ucDbgType);
/*FD Related API's*/
int8 IFX_FAXAPP_SendMsgToFifo(IN int16 nFifoFd,
					                    IN char *pcFifoMsg,
							                IN int16 nMsgLen);

#endif/*__IFX_FAXAPP_APP_H__*/




















