/**************************************************************************
 **   SRC_FILE          : MT_T38_Interface_Import.h
 **   PROJECT           : T.38 Fax Relay
 **   MODULES           :
 **   SRC VERSION       : v1.0
 **   DATE              : 15-04-2003
 **   AUTHOR            : Andrew Matveyev, Dmitry Bahvalov, Sergey Boidenko
 **   DESCRIPTION       : T.38 Fax Relay interface functions prototypes.
 **   FUNCTIONS         :
 **   COMPILER          :
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : "METASOFT" SIA 1997-2006

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
***********************************************************************/

#ifndef __MT_T38_INTERFACE_IMPORT_H__
#define __MT_T38_INTERFACE_IMPORT_H__

#include "ifx_common_defs.h"
#if !FOIP_CHANNEL_VERSION
#include "ifin_mlib_interface_import.h"
#endif
#include "mt_t38_caps.h"
#include "mt_t38_t38stat.h"


/* Return code definition */
#define MT_T38_SUCCESS                     0
#define MT_T38_FAILURE                    -1

/* Status bit definition */
#define MT_DSP_FDP_REQ_BIT      0 /* request more data for modulation */
#define MT_DSP_FDP_ERR_BIT      1 /* report DSP error */

#define MT_T38_NSX_MAX_SIZE    40 /* maximal size of pucNsxInfoField */


/* Bit options for x_MT_T38_InitParam.iOptions */

/* Emitting gateway */
#define MT_T38_INIT_OPT_CALLING                0x0001

/* T.38 should take appropriate actions not to allow non-standard fax
 * connection, there are two possibilities to do this:
 * 1) discard non-standard facilities V.21 frames or
 * 2) to patch these frames.
 *
 * This bit chooses to patch NSF, NSC, NSS frames or to discard them (patch is
 * recommended not to provoke extraneous T.30 timeouts). */
#define MT_T38_INIT_OPT_NSXPATCH               0x0002

/* Packet format of the first T.38 standard (June 1998) is not compatible with
 * the consecutive T.38 standards.
 *
 * This bit chooses to use old ASN notation (packet format of june 1998) for
 * encoding and decoding. */
#define MT_T38_INIT_OPT_USE_OLD_ASN98          0x0004

/* Use for long round-trip IP delays (more than 3 seconds) or in situations
 * when many UDP packets are lost during transfer. */
#define MT_T38_INIT_OPT_SEVERE_IP_IMPAIRMENTS  0x0008

/* Use to disable ECM  */
#define MT_T38_INIT_OPT_DISABLE_ECM            0x0010

/* Use to enable frame based encoding for IP packets */
#define MT_T38_INIT_OPT_FRAME_ENCODING         0x0020

/* Use to enable additional UDP packet structure check
   and skip non T38 packets till first T38 packet */
#define MT_T38_INIT_OPT_UDP_GARBAGE_FILTER     0x0040

/* Use to enable additional NSX patch option
   keeps rest of frame unchanged.
   Only one option MT_T38_INIT_OPT_NSXPATCH_REST_XX can be used */
#define MT_T38_INIT_OPT_NSXPATCH_REST_UNCH     0x0080

/* Use to enable additional NSX patch option
   fills rest of frame with 0x00.
   Only one option MT_T38_INIT_OPT_NSXPATCH_REST_XX can be used */
#define MT_T38_INIT_OPT_NSXPATCH_REST_00       0x0100

/* Use to enable additional NSX patch option
   fills rest of frame with 0xFF.
   Only one option MT_T38_INIT_OPT_NSXPATCH_REST_XX can be used */
#define MT_T38_INIT_OPT_NSXPATCH_REST_FF       0x0200

/* Use to enable heartbeat no-signal indicator sending */
#define MT_T38_INIT_OPT_HEARTBEAT              0x0400

/* T.38 initial parameters */
typedef struct {
  /* Bit options */
  int32  iOptions;
  /* Output voice power level in dBm (accepted values 4-31 or 0 to use the
   * default value 10) */
  uint32 uiDBmLevel;
  /* To buffer appropriate V.21, ECM and non-ECM page data if end of line or
   * end of HDLC frame aren't found (value range: 0..100; use value 0 for
   * protocol default value) */
  uint32 uiDataWaitTime; /*(in 10 milliseconds)*/
  /* Number of additional recovery data packets (for redundancy and FEC error
   * correction modes) sent on high-speed fax transmissions (image data)
   * (required only for UDP) */
  uint32 uiUdpHighRateErrRecoveryPackets;
  /* Number of additional recovery data packets (for redundancy and FEC error
   * correction modes) sent on low-speed fax transmissions (V.21 data)
   * (required only for UDP) */
  uint32 uiUdpLowRateErrRecoveryPackets;
  /* Number of indicator duplication packets */
  uint32 uiUdpIndicatorDuplicationPackets;
  /* Number of packets to calculate FEC (required only for UDP FEC mode) */
  uint32 uiUdpPriorPacketsForFEC;
  /* Will be used to change information field of NSF, NSC and NSS frames if
   * bit MT_T38_INIT_OPT_NSXPATCH is set. The first bit transmitted should be
   * stored in the MSB (most significant bit) of the first octet. Usage of
   * long frames can increase delay of fax handshaking phase */
  uchar8 *pucNsxInfoField;
  /* Number of data bytes in pucNsxInfoField buffer (minimal value is 2,
   * maximal value is MT_T38_NSX_MAX_SIZE) */
  uint32 uiNsxInfoFieldSz;

  /* Data pump demodulation gain */
  uint16 unGain1;
  /* Data pump modulation gain */
  uint16 unGain2;
  /* Data pump resource number */
  uchar8 ucDPNR;
  /* Data pump input signal parameter */
  uchar8 ucInputSignal;
  /* Frame length of the data packets transferred via TCP/IP or UDP/IP */
  uchar8 ucDataFrameLength; /*in milliseconds*/

  /* Included by IFIN */

  /* Mailbox coefficients for Modulator/Demodulator */
  uint16 unMOBSM; /* In time units */
  uint16 unMOBRD;
  uint16 unDMBSD;
#if FOIP_CHANNEL_VERSION
  uint16 unMOBSZ;
#endif
  /* Timeout in ms to start automatic v21 modulation
   *  after v21 command or TCF demodulation
   * ( 0 - default value 2000 ms ) */
  uint32 uiAutoStartWaitTime;
  /* (in 10ms) Time to insert flags after automatic modulation started
   * before CRP will be sent, include preamble flags
   * ( 0 - default value 6000 ms ) */
  uint32 uiAutoSpoofingTime;
  /* (in 100ms) Time to send no-signal indicator *
   * if modulator and demodulator not active
   * ( 0 - default value 1000 ms ) */
  uint32 uiHearbeatInterval;
} x_MT_T38_InitParam;


/******************************************************************************
* Function Name: MT_T38_GetCapabilities
* Description  : Obtain T.38 capabilities required for connection establishment
* Input Values : eCapabilitiesType - type of the capabilities to obtain
* Output Values: pxCapabilities - output structure filled by the T.38 protocol
*                                 capabilities
* Return Value : MT_T38_SUCCESS - success, else failure
* Notes        :
******************************************************************************/
extern int32 MT_T38_GetCapabilities(e_MT_T38_CapType eCapabilitiesType,
                                    x_MT_T38_Caps *pxCapabilities);

/******************************************************************************
* Function Name: MT_T38_SessionStart
* Description  : Open T.38 Fax Relay channel
* Input Values : unChannelID - the T.38 Fax Relay channel identifier
*                pxInitParams - initial parameters
*                pxSessionCapabilities - current session capabilities
* Output Values: pMlibId - memory pool Id which is used for this section
* Return Value : MT_T38_SUCCESS - success, else failure
* Notes        :
******************************************************************************/
#if FOIP_CHANNEL_VERSION
extern int32 MT_T38_SessionStart(void *pv_T38FR_ID,
                                 uint16 unChannelID,
                                 x_MT_T38_InitParam *pxInitParams,
                                 x_MT_T38_Caps *pxSessionCapabilities);
#else
extern int32 MT_T38_SessionStart(uint16 unChannelID,
                                 x_MT_T38_InitParam *pxInitParams,
                                 x_MT_T38_Caps *pxSessionCapabilities,
                                 IFIN_MLIB_Id *pMlibId);
#endif

/******************************************************************************
* Function Name: MT_T38_SessionStop
* Description  : Close T.38 Fax Relay channel
* Input Values : unChannelID - the T.38 Fax Relay channel identifier
* Output Values:
* Return Value : MT_T38_SUCCESS - success, else failure
* Notes        : This is the last service for current session
******************************************************************************/
#if FOIP_CHANNEL_VERSION
extern int32 MT_T38_SessionStop(void *pv_T38FR_ID, uint16 unChannelID);
#else
extern int32 MT_T38_SessionStop(uint16 unChannelID);
#endif

/******************************************************************************
* Function Name: MT_T38_PacketReceived
* Description  : Provide T.38 Fax Relay with received packet (TCP or UDP)
* Input Values : unChannelID - the T.38 Fax Relay channel identifier
*                pucInBuffer - pointer to the input packet data
*                uiInBufferSize - packet data size in bytes
* Output Values:
* Return Value : MT_T38_SUCCESS - success, else failure
* Notes        :
******************************************************************************/
#if FOIP_CHANNEL_VERSION
extern int32 MT_T38_PacketReceived(void *pv_T38FR_ID,uint16 unChannelID,
                                   uchar8 *pucInBuffer, uint32 uiInBufferSize);
#else
extern int32 MT_T38_PacketReceived(uint16 unChannelID, uchar8 *pucInBuffer,
                                   uint32 uiInBufferSize);
#endif

/******************************************************************************
* Function Name: MT_T38_DataRcvdFromDataPump
* Description  : Provide T.38 Fax Relay with message received from DSP
* Input Values : unChannelID - the T.38 Fax Relay channel identifier
*                pucDataPumpMsg - pointer to the message data received from DSP
*                uiMsgSize - message data size in bytes
* Output Values:
* Return Value : MT_T38_SUCCESS - success, else failure
* Notes        :
******************************************************************************/
#if FOIP_CHANNEL_VERSION
int32 MT_T38_DataRcvdFromDataPump(void *pv_T38FR_ID, uint16 *pus_DemDataBuf,
                                  int32 *pl_ReadIndex, uint32 uiMsgSize);
#else
extern int32 MT_T38_DataRcvdFromDataPump(
  uint16 unChannelID, uchar8 *pucDataPumpMsg, uint32 uiMsgSize);
#endif

/******************************************************************************
* Function Name: MT_T38_StatusBitsInfo
* Description  : Indicate that status bit state transits from 0 to 1
* Input Values : unChannelID - the T.38 Fax Relay channel identifier
*                iStatusBit - changed status bit
* Output Values:
* Return Value : MT_T38_SUCCESS - success, else failure
* Notes        :
******************************************************************************/
#if FOIP_CHANNEL_VERSION
extern int32 MT_T38_StatusBitsInfo(void *pv_T38FR_ID, uint16 *pus_Data, int32 *pl_WriteIndex, int8 iStatusBit);
#else
extern int32 MT_T38_StatusBitsInfo(uint16 unChannelID, int8 iStatusBit);
#endif

/******************************************************************************
* Function Name: MT_T38_TimerCallback
* Description  : Indicate the Timeout
* Input Values : unChannelID - the T.38 Fax Relay channel identifier
* Output Values:
* Return Value : MT_T38_SUCCESS - success, else failure
* Notes        :
******************************************************************************/
#if FOIP_CHANNEL_VERSION
extern int32 MT_T38_TimerCallback(void *pv_T38FR_ID, uint16 unChannelID);
#else
extern int32 MT_T38_TimerCallback(uint16 unChannelID);
#endif

/******************************************************************************
* Function Name: MT_T38_GetT38Statistics
* Description  : Get statistics of opened T38 channel
* Input Values : unChannelID - the T.38 Fax Relay channel identifier
* Output Values: x_MT_T38_statistics_t  - pointer to output structure
                                          which accepts T38 statistics
* Return Value : MT_T38_SUCCESS - success, else failure
* Notes        :
******************************************************************************/
#if FOIP_CHANNEL_VERSION
extern int32 MT_T38_GetT38Statistics(void *pv_T38FR_ID,
  uint16 unChannelID, x_MT_T38_statistics_t *px_T38Statistics );
#else
extern int32 MT_T38_GetT38Statistics(
  uint16 unChannelID, x_MT_T38_statistics_t *px_T38Statistics );
#endif

#endif /*__MT_T38_INTERFACE_IMPORT_H__*/
