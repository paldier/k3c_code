/**************************************************************************
 **   SRC_FILE          : MT_T38_t38stat.h
 **   PROJECT           : T.38 Fax Relay
 **   MODULES           :
 **   SRC VERSION       : v1.0
 **   DATE              : 11-04-2003
 **   AUTHOR            : Sergey Boidenko
 **   DESCRIPTION       : T38 statistics.
 **   FUNCTIONS         :
 **   COMPILER          :
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : "METASOFT" SIA 1997-2006

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
***********************************************************************/

#ifndef __MT_T38_T38STAT_H__
#define __MT_T38_T38STAT_H__

/* Remote used FEC for recovering */
#define MT_T38_ST_FEC_USED              0x0001
/* Remote used Redundancy for recovering */
#define MT_T38_ST_REDUND_USED           0x0002
/* ECM page transaction */
#define MT_T38_ST_ECM_PAGE              0x0004
/* Completed transaction (DCN frame decoded or demodulated) */
#define MT_T38_ST_COMPLETE_TRANSACTION  0x0008

/* Standards used in fax session */
#define MT_T38_ST_STD_V27TER_2400       0x0001
#define MT_T38_ST_STD_V27TER_4800       0x0002
#define MT_T38_ST_STD_V29_7200          0x0004
#define MT_T38_ST_STD_V29_9600          0x0008
#define MT_T38_ST_STD_V17_7200          0x0010
#define MT_T38_ST_STD_V17_9600          0x0020
#define MT_T38_ST_STD_V17_12000         0x0040
#define MT_T38_ST_STD_V17_14400         0x0080

/* Collect T38 statistics */
typedef struct {
  int32   i_Flags;
  int32   i_Standards;         /* Standards used in fax session *
                                * see MT_T38_ST_STD_XXX         */
  uint32  ui_LostPackets;      /* Lost packets quantity */
  uint32  ui_RecoveredPackets; /* Recovered packets quantity */
  uint32  ui_MaxLostPcksGroup; /* Maximum number of consequent lost packets */
  uint32  ui_StatFTTcount;     /* Number of TCF responded with FTT */
  uint32  ui_PagesTransfered;  /* Transfered pages quantity */
  uint32  ui_LineBreaks;       /* Number of broken non-ECM page lines */
  uint32  ui_v21FrmBreaks;     /* Number of broken modulation of v21 frames */
  uint32  ui_ECM_FrmBreaks;    /* Number of broken ECM frames modulation */
  uint32  ui_MajorVersion;     /* Major T38 build version */
  uint32  ui_MinirVersion;     /* Minor T38 build version */
#if MT_T38_STATE_REPORT
  uint32  ui_FaxState;         /* One of e_MT_T38_PP_FaxRelayState */
#endif
} x_MT_T38_statistics_t;

typedef enum {
/* 0 */ MT_T38_ST_NULLSTATE,
/* 1 */ MT_T38_ST_IDLE,
/* 2 */ MT_T38_ST_PREPARE,
/* 3 */ MT_T38_ST_NEGOTIATING,
/* 4 */ MT_T38_ST_TRAIN_R,
/* 5 */ MT_T38_ST_TRAIN_T,
/* 6 */ MT_T38_ST_CONNECTED,
/* 7 */ MT_T38_ST_EOP,
/* 8 */ MT_T38_ST_INTERRUPT,
/* 9 */ MT_T38_ST_EOF
} e_MT_T38_PP_FaxRelayState;

#endif /* __MT_T38_T38STAT_H__ */
