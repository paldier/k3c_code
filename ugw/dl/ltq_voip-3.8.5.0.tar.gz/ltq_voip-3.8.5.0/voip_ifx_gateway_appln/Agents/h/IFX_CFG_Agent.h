/***********************************************************************
*   SRC_FILE           : IFX_CFG_Agent.c
*   PROJECT            : Voip Gateway Subsystem
*   MODULES            : Gateway Application
*   SRC VERSION        : V1.0
*   DATE               : 21/05/2007
*   AUTHOR             : Gw Appln Team
*   DESCRIPTION        :
*   FUNCTIONS          :
*   COMPILER           : mips(el)-linux-gcc
*   REFERENCE          :
*   COPYRIGHT          :Copyright © 2004
*                       Infineon Technologies AG
*                       St. Martin Strasse 53; 81669 München, Germany
*   DESCLAIMER         :Any use of this Software is subject to the conclusion
*                       of a respective License Agreement.
*                       Without such a License Agreement no rights to the
*                       Software are granted.
*   Version Control Section
*   $Author$
*   $Date$
*   $Revisions$
*   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_CFG_AGENT_H__
#define __IFX_CFG_AGENT_H__

/* Following flags are needed to access VMAPI */
#define IFX_CIF_GET_FLAGS	    0
#define IFX_CIF_MOD_FLAG	    IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ
#define IFX_CIF_ADD_FLAG	    0
#define IFX_CIF_SET_OPP	      IFX_VMAPI_OP_MOD

/*! \brief Resitration status */
typedef enum {
	IFX_CIF_NotRegistered,
	IFX_CIF_RegInitiated,
	IFX_CIF_Registered,
	IFX_CIF_UnRegInitiated,
	IFX_CIF_RegError
}e_IFX_CIF_RegStatus;

/*! \brief Subscription status */
typedef enum {
	IFX_CIF_NotSubscribed,
	IFX_CIF_SubInitiated,
	IFX_CIF_Subscribed,
	IFX_CIF_UnSubInitiated,
	IFX_CIF_SubError
}e_IFX_CIF_VMSubscriptionStatus;

/*! \brief This flag is set during unregistration & re-reistration */
#define IFX_CFG_RE_REGISTER		0x0001
/*! \brief This flag is set during un-subscription & re-subscription */
#define IFX_CFG_RE_SUBSCRIBE	0x0001

/*! \brief Voice Line information is stored in this structure. */
typedef struct {
	uchar8 ucFlags; /** Flags used for CFG Agent */
	uchar8 ucVoiceLineId;  /** Voice Line Id **/
	uchar8 ucVoiceLineStatus; /** Voice Line status. */
	uint32 uiRegRequestId; /** Request Id used for registration purpose */
	e_IFX_CIF_RegStatus eRegStatus; /** Registration status */
	uint32 uiSubRequestId; /** Request Id used for voice mail subscription */
	e_IFX_CIF_VMSubscriptionStatus eSubStatus; /** Voice mail subscription status */
}x_IFX_CFG_LineInfo;

#define IFX_CFG_SET_LINE_FLAG(pxLineInfo, flag)  ((pxLineInfo)->ucFlags |= (flag))
#define IFX_CFG_RESET_LINE_FLAG(pxLineInfo, flag)  ((pxLineInfo)->ucFlags &= ~(flag))
#define IFX_CFG_CHECK_LINE_FLAG(pxLineInfo, flag)  ((pxLineInfo)->ucFlags & (flag))

/*---------------------------- Extern declarations --------------------------*/
EXTERN e_IFX_Return IFX_FXS_AgentInit(
	                   IN char8  aszEndptId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucEndpoints,
	                   IN uchar8 ucFxsDbgId );

EXTERN e_IFX_Return IFX_FXS_AgentShut(
	                   IN char8  aszEndptId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucEndpts );

EXTERN e_IFX_Return IFX_FXO_AgentInit(
	                   IN char8  aszEndptId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucEndpts,
	                   IN uchar8 ucFxsDbgId );

EXTERN e_IFX_Return IFX_FXO_AgentShut(
	                   IN char8  aszEndptId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucEndpts );
#ifdef DECT_SUPPORT
EXTERN e_IFX_Return IFX_DECT_AgentInit(
										IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN],
										IN uchar8 ucNoOfEndpts,
										IN uchar8 ucDectDbgId );

EXTERN e_IFX_Return IFX_DECT_AgentShut(
										IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN],
										IN uchar8 ucNoOfEndpts);
#endif
#ifdef CVOIP_SUPPORT
EXTERN e_IFX_Return IFX_CVOIP_AgentInit(
										IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN],
										IN uchar8 ucNoOfEndpts,
                    IN uchar8 ucDectDbgId);
#endif

EXTERN e_IFX_Return IFX_MSGRTR_HandleTapiEvents(int32);

EXTERN e_IFX_Return IFX_ChipInit();



#endif /*__IFX_CFG_AGENT_H__ */
