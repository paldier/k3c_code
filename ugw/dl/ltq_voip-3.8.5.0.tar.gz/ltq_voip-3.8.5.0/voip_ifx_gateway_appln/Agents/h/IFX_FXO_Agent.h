/**************************************************************************
 **   SRC_FILE          : IFX_FXO_INFO.h
 **   PROJECT           : DECT-VOIP GW
 **   MODULES          : CallManager
 **   SRC VERSION       : v0.1
 **   DATE                  : 
 **   AUTHOR            : Voip-Gw Team
 **   DESCRIPTION   : Data Structures about FXO Endpoint FSM
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$ 
 **   $Date$ 05/12/2005
 **   $Revisions$
 **   $Log$
 **************************************************************************
This File lists down the events, states and data structures for FXO agent  
*******************************************************************************/
#ifndef __IFX_FXO_H__
#define __IFX_FXO_H__

/***********************Data structures and macros**********************************/
/***The events for the FSM****/
typedef enum 
{
	/*TAPI Events*/                                 
	IFX_FXO_EVT_RingStart,
	IFX_FXO_EVT_DgtPrs,
	IFX_FXO_EVT_RingStop,
	IFX_FXO_EVT_ToneDetect,
	IFX_FXO_EVT_CIDRxComplete,
	IFX_FXO_EVT_CAS,
	/*CallControl Events*/
	IFX_FXO_EVT_IncCall,
	IFX_FXO_EVT_EmgCall,
	IFX_FXO_EVT_ReleaseCall,
	IFX_FXO_EVT_RmtAccept,
	IFX_FXO_EVT_RmtAnswer,
	IFX_FXO_EVT_PSTNHookFlash,
	/*Tone Timer Events*/
	IFX_FXO_EVT_DialToneTimerExp,
	IFX_FXO_EVT_RingBackToneTimerExp,
	/*Functionality Timer Events*/
	IFX_FXO_EVT_RingBurstTimerExp,
	IFX_FXO_EVT_LineDgtTimerExp,
	IFX_FXO_EVT_LineInterDgtTimerExp,
	IFX_FXO_EVT_DialWaitTimerExp,
	IFX_FXO_EVT_OffHkWaitTimerExp,
	IFX_FXO_EVT_OnHkWaitTimerExp,
	IFX_FXO_EVT_RetryTimerExp,
	IFX_FXO_EVT_InterDgtTimerExp,
	IFX_FXO_EVT_HookFlashTimerExp,
	IFX_FXO_EVT_OffHkCIDTimerExp,
	/*SMS Related Events*/
	IFX_FXO_EVT_TransmitSMS,
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	/*FAX Related Events*/
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	/*Max Events*/
	IFX_FXO_EVT_MAX,
}e_IFX_FXO_Evt;

/*Macros to set/reset/get bit-flags.*/
//#define IFX_FXO_SET_FLAG(FLAG,FLAG_POS) (FLAG|=(1<<(FLAG_POS)))
//#define IFX_FXO_RESET_FLAG(FLAG,FLAG_POS) (FLAG&=(~(1<<(FLAG_POS))))

#define IFX_FXO_SET_FLAG(FLAG,FLAG_POS){ \
		FLAG|=(1<<(FLAG_POS));\
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,\
			"Setting Flag: ",IFX_FXO_GetFlag(FLAG_POS));\
		}

#define IFX_FXO_RESET_FLAG(FLAG,FLAG_POS){\
		FLAG&=(~(1<<(FLAG_POS)));\
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,\
			"Resetting Flag: ",IFX_FXO_GetFlag(FLAG_POS));\
		}

/* Macro give Zero value for Set and NON zero value for reset */
#define IFX_FXO_GET_FLAG(FLAG,FLAG_POS) (((FLAG)&(1<<FLAG_POS))>>FLAG_POS)

/* Macros for FXO */
# define IFX_MAX_FXO_CALLS 1
# define IFX_FXO_MAX_PSTN_NUM 128
# define IFX_FXO_MAX_DIGITS 40

/*Macros for state and event names for debugging */
# define IFX_FXO_GetState(eState) (aszStateName[eState])
# define IFX_FXO_GetEvent(eEvt) (aszEvtName[eEvt])
# define IFX_FXO_GetFlag(ePos) (aszFlagName[ePos])
# define GetFXOReturn(ret) (aszFXOReturn[ret])
# define stgnize(a) #a

/***The States for the FSM****/
typedef enum
{
   IFX_FXO_STATE_IDLE,
   IFX_FXO_STATE_CID_WAIT,
   IFX_FXO_STATE_DIAL_WAIT,
   IFX_FXO_STATE_DIGIT_DIAL,
   IFX_FXO_STATE_DIGIT_COLLECT,
   IFX_FXO_STATE_RINGBACK,
   IFX_FXO_STATE_CONVERSATION,
   IFX_FXO_STATE_RINGING,
   IFX_FXO_STATE_OFF_HK_WAIT,
	//IFX_FXO_STATE_SMS,
   IFX_FXO_STATE_MAX
}e_IFX_FXO_State;

/*Data for Active call*/
typedef struct
{
	/*Call Id*/
	uint32 uiCallId;
	/*Type of call*/
	e_IFX_CMGR_CallType eCallType;

}x_IFX_FXO_CallData;

/*The data structures for the event Info*/
typedef struct
{
	/*Call Id*/
   uint32 uiCallId;
   /*Type of call*/
   e_IFX_CMGR_CallType eCallType;
	/*The PSTN Number to be dialed out*/
   char8 szPstnDgt[IFX_FXO_MAX_PSTN_NUM];	
}x_IFX_FXO_IncCallInfo;

typedef struct
{

}x_IFX_SMS_Info;

typedef struct
{
	uchar8 ucNoOfDigits;         /*!< No of digit events */
	char8 acDigits[IFX_FXO_MAX_DIGITS]; /*!< Array containg all the digits */
}x_IFX_FXO_DgtInfo;

/*The Output values from FSM*/
typedef enum
{
	IFX_FXO_AcceptCall=1,
	IFX_FXO_RejectCall=2,
	IFX_FXO_AnswerCall=3,
	IFX_FXO_PendingCall=4,
	IFX_FXO_AcceptSMS=5,
	IFX_FXO_RejectSMS=6,
	IFX_FXO_Failure=7,
	IFX_FXO_MAXReturn=0
}e_IFX_FXO_Return;

/*The EventInfo union for thr FSM*/
typedef union
{
	x_IFX_MMGR_CidParams xCIDData; /*For CID Event*/
	char8 szDgtPrs[IFX_FXO_MAX_DIGITS]; /*For DigitPress event*/
	x_IFX_FXO_IncCallInfo xIncCallInfo; /*For Incoming call event and emergency call event */
	x_IFX_SMS_Info xSMSInfo; /*For Transmit SMS event*/
	e_IFX_MMGR_ToneType eToneDetect;
}ux_IFX_EvtInfo;	

typedef struct
{
	/*Event occured*/
	e_IFX_FXO_Evt eCurrEvt;
	/*The Call Id*/
	uint32 uiCallId;
	/*Information specific to avents*/
	ux_IFX_EvtInfo uxEvtInfo;
	/*The Return Value*/
	e_IFX_FXO_Return eReturn;
}x_IFX_FXO_EvtInfo;

/*Enum for bit flag positions*/
typedef enum
{
	/*Would be set on Emergency Call event and reset on next on-hook
	 -would reject PSTN hook flash, transfer etc while the flag is set.
	 */
	IFX_FXO_EMG_CALL_PROCEEDING = 0,	
	/*Would indicate the resource allocation status
	 -Set when Resource is allocated 
	 -Reset when State is moved to Idle and resource is deactivated.
	 */
	IFX_FXO_RESOURCE_ALLOCATED = 1,
	/*This flag is set in Idle state and would indicate ring start has been received.
	 upon the ring stop, state is changed to CID_WAIT and flag would be reset
	 -would reject another  normal incoming call while the flag is set.
	 */
	IFX_FXO_RING_START_RCVD = 2,
	/*Would be set when DMI of 2-9 is received CID and thus after digit dial, state has 
	  to be moved to SMS */
	IFX_FXO_MOVE_TO_SMS_STATE = 3,
	/*Would be set when Incoming call comes in off hook wait state and reset when the off hook wait timer fires */
	IFX_FXO_MOVE_TO_DIALWAIT = 4,
	/*Would be 0 for On hook and 1 for off hook*/
	IFX_FXO_HOOK_STATUS = 5,
	/*Flage to indicate Tone is playing*/
	IFX_FXO_TONE_PLAY = 6,

	IFX_FXO_MAX_FLAGS
}e_FXO_BitFlagPos;

/*****The endpoint info data structure*********/
typedef struct
{
	/*EndpointId for a given Endpoint*/
	char8 szEndPointId[IFX_MAX_ENDPOINTID_LEN];
	
	/*Bit flags*/	
	uint32 uiFlags;
	
	/*State Information*/
	e_IFX_FXO_State eCurrState;
	e_IFX_FXO_State ePrevState;

	/*Tone Timer Id's*/
	
   /*Timer ID of the Dial tone.*/
   uint32 uiDialToneTimId;
   /*Timer ID of the Ring Bk tone.*/
   uint32 uiRingBkToneTimId;
   
	/*Functionality timer Id's*/

	/*Timer ID for the Off-Hook Timer Wait*/
	uint32 uiOffHkWaitTimId;
	/*Timer ID for the On-Hook Timer Wait*/
	uint32 uiOnHkWaitTimId;
   /*Timer ID of the Interdigit timer when PSTN user dials the digits on second dial tone*/
   uint32 uiInterDgtTimId;
	/*Line Digit Length Timer*/
   uint32 uiLineDgtTimId;
   /*Line Inter Digit Timer*/
   uint32 uiLineInterDgtTimId;
	/*TImer ID for Retry Timer*/
   uint32 uiRetryTimId;
	/*Ring Burst Timer Id*/
   uint32 uiRingBurstTimId;
   /*Dial Wait Timer Id*/
   uint32 uiDialWaitTimId;
	/*Hook Flash*/
   uint32 uiHookFlashTimId;
	/*Timer for Type 2 CID*/
   uint32 uiOffHkCIDTimId;

	/*Digits to dial out to PSTN*/
    char8 szPstnDgt[IFX_FXO_MAX_PSTN_NUM];
	/*Pointer to the digit to play on PSTN Line*/
    char8 *pcCurrDgt;

	/*The DMI received*/
	char8 cDMI;

	/*The Tone for which the CPTD is active*/
	e_IFX_MMGR_ToneType eCPTDActv;

	/*Data structures when PSTN user dials the number on second dial tone.*/
	char8 szDialledDigits[IFX_FXO_MAX_DIGITS];
	/*Digit String to Dial out after deing parsed by the DP.*/
	char8 szDialOutDgtStr[IFX_FXO_MAX_DIGITS];
	
	/*Active Call Information*/
	x_IFX_FXO_CallData axFxoCallData[IFX_MAX_FXO_CALLS];

	/*Emergency Call's data saving location*/
   x_IFX_FXO_IncCallInfo xEmgCallInfo;
	/*The CID data, valid only in CID_WAIT state*/
	x_IFX_MMGR_CidParams xCIDdata;

}x_IFX_FXO_Info;


/*Structure to be filled when we start timer*/
typedef struct
{
	x_IFX_FXO_Info * pxEndptInfo;
	e_IFX_FXO_Evt eCurrEvt;
	uint32 * pTimerId;
}x_IFX_FXO_TimerInfo;

/**********Interface function prototypes**********************************/

/*********** The Functions to be registered with external modules ************/
/************ The Functions to be registered with Timer agent ****************/

/*! 
    \brief          This function would be registered with timer for every timer.
					When being calld, will indicate the expiry of the timer and 
					invoke the FSM, No other information is required.
					It will be registered with Timer library as (*pfn_IFX_TM_TimerCallBack)
					Events It can give:- 
   					IFX_FXO_EVT_DialToneTimerExp,
  						IFX_FXO_EVT_RingBackToneTimerExp,
   					IFX_FXO_EVT_RingBurstTimerExp,
   					IFX_FXO_EVT_LineDgtTimerExp,
   					IFX_FXO_EVT_LineInterDigitTimerExp,
   					IFX_FXO_EVT_DialWaitTimerExp,
   					IFX_FXO_EVT_OffHkWaitTimerExp,
   					IFX_FXO_EVT_OnHkWaitTimerExp,
   					IFX_FXO_EVT_RetryTimerExp,
   					IFX_FXO_EVT_InterDgtTimerExp,
   					IFX_FXO_EVT_HookFlashTimerExp,
						IFX_FXO_EVT_OffHkCIDTimerExp
    \param[in]  	pvPrivateData
    \return     IFX_SUCCESS or IFX_FAILUREURE
	
 
*/
void IFX_FXO_TimerFired(
						IN uint32 uiTimerId,
						IN void* pvPrivateData
						);

/*********************** The Functions to be registered with Message router *****************************/
/*! 
    \brief   	This function will be registered with the Message router
					as (*pfn_IFX_MSGRTR_EventCallback). It will give the appropriate EndpointId
					and the TAPI event ID.Thus the FXOHdlr would be invoked for appropriate endpoint 
					Events It Can Give
					IFX_FXO_EVT_RingStart,
					IFX_FXO_EVT_DgtPrs,
					IFX_FXO_EVT_RingStop,
					IFX_FXO_EVT_ToneDetect,
					IFX_FXO_EVT_CIDRxComplete,
					IFX_FXO_EVT_CAS,
    \param[in]		szEndpointId      
    \param[in] 	pxDevEvents
    \return     IFX_SUCCESS or IFX_FAILUREURE
*/

e_IFX_Return IFX_FXO_MSGRTR_EvtHdlr( IN x_IFX_MMGR_DeviceEvents *pxDevEvents);

		
/*********************** The Functions to be registered with Call Manager *****************************/
/*Events that could be given by the following function:-
IFX_FXO_EVT_IncCall,
IFX_FXO_EVT_EmgCall,*/
e_IFX_Return IFX_FXO_CallIncoming(
					 IN uint32 uiCallId, 
					 IN x_IFX_CMGR_AddressInfo *pxFrom,
					 IN x_IFX_CMGR_AddressInfo *pxTo, 
					 IN x_IFX_CMGR_CallParams *pxCallParams, 
					 OUT e_IFX_CMGR_Status* peStatus,
					 OUT e_IFX_ReasonCode* peReason,
					 OUT void** ppvPrivateData
					 );


/*Events that could be given by the following function:-
IFX_FXO_EVT_ReleaseCall,*/
e_IFX_Return IFX_FXO_RemoteCallRelease(
                     IN uint32 uiCallId,
                     IN e_IFX_ReasonCode eReleaseReason,
                     IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
                     IN void* pvPrivateData
                     );
/*Events that could be given by the following function:-
IFX_FXO_EVT_RmtAccept,*/
e_IFX_Return IFX_FXO_RemoteCallAccept(
								IN uint32 uiCallId,
					 			IN void* pvPrivateData
								);


/*Events that could be given by the following function:-*/
//IFX_FXO_EVT_RmtAnswer,
e_IFX_Return IFX_FXO_RemoteCallAnswer(
								IN uint32 uiCallId,
					 			IN void* pvPrivateData
							);							

/*Events that could be given by the following function:-*/
//IFX_FXO_EVT_PSTNHookFlash,   
e_IFX_Return IFX_FXO_RecvInfo(
                IN x_IFX_CMGR_AddressInfo* pxFrom,
                IN x_IFX_CMGR_AddressInfo* pxTo,
                IN void* pvInfo,
                IN uint16 unSize,
                OUT e_IFX_CMGR_Status* peStatus,
                OUT e_IFX_ReasonCode* peReason );

/*****
This is a special function which doesnot
invoke the FSM but just changes the call ID
of Active Call.
******/
e_IFX_Return IFX_FXO_CallIdReplace
                     (
                        IN uint32 uiOldCallId,
                        IN uint32 uiNewCallId,
                        IN_OUT void** ppvPrivateData
                     );


/*Events that could be given by the following function:-*/
//IFX_FXO_EVT_TransmitSMS,
e_IFX_Return IFX_FXO_SMS_SmsReceived(
                                         IN x_IFX_CMGR_AddressInfo *pxFrom,
                                         IN x_IFX_CMGR_AddressInfo *pxTo,
                                         IN char8* szSmsBody,
                                         IN boolean bUnread,
                                         IN uint16 unSmsId,
                                         OUT e_IFX_CMGR_Status* peStatus,
                                         OUT e_IFX_ReasonCode* peReason
                                      );

/*********************** The Functions to be registered with Call manager 
								Will not trigger the FSM and will always give success*******************/

e_IFX_Return IFX_FXO_BlindTxRequest(
					 	IN uint32 uiCallId,
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						OUT e_IFX_TransferStatus* peTransferStatus,
						OUT e_IFX_ReasonCode *peRespCode,
						IN void* pvPrivateData
					 );

e_IFX_Return IFX_FXO_AttendedTxRequest(
					 	IN uint32 uiCallId,
						IN uint32 uiReplacesCallId,
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						OUT e_IFX_TransferStatus* peTransferStatus,
						OUT e_IFX_ReasonCode *peRespCode,
						IN void* pvPrivateData
					 );

e_IFX_Return IFX_FXO_BlindTxStatus(
					 	IN uint32 uiCallId,
						IN e_IFX_TransferStatus eTransferStatus, 
						IN e_IFX_ReasonCode eRespCode,
						IN void* pvPrivateData
					 );	

e_IFX_Return IFX_FXO_AttendedTxStatus(
                                    	IN uint32 uiCallId,
                                       IN e_IFX_TransferStatus eTransferStatus,
                                       IN e_IFX_ReasonCode eRespCode,
                                       IN void* pvPrivateData 
												);

e_IFX_Return IFX_FXO_RemoteCallHold(
                                     	IN uint32 uiCallId,
					 								OUT e_IFX_CMGR_Status* peStatus,
					 								OUT e_IFX_ReasonCode* peReason,
                                     	IN void* pvPrivateData
                                     );

e_IFX_Return IFX_FXO_RemoteCallResume(
                                          IN uint32 uiCallId,
					 									OUT e_IFX_CMGR_Status* peStatus,
					 									OUT e_IFX_ReasonCode* peReason,
                                          IN void* pvPrivateData
                                          );

e_IFX_Return IFX_FXO_CallFwdInfo(
                                        IN uint32 uiCallId,
                                        IN e_IFX_ReasonCode eReason,
                                        IN x_IFX_CMGR_VoipAddr* pxFwdAddr,
													 OUT boolean* pbFwdAllow,
                                        IN void* pvPrivateData
                                 );

e_IFX_Return IFX_FXO_SMS_SmsStatus(
                                            IN uint16 unSmsId,
                                            IN e_IFX_CMGR_Status eSmsStatus
                                    );




e_IFX_Return IFX_FXO_CallHoldRsp(
									IN uint32 uiCallId,
									IN e_IFX_CMGR_Status eStatus,
									IN e_IFX_ReasonCode eReason, 
					 				IN void* pvPrivateData
									);							



e_IFX_Return IFX_FXO_CallResumeRsp(
									IN uint32 uiCallId,
									IN e_IFX_CMGR_Status eStatus,
									IN e_IFX_ReasonCode eReason, 
					 				IN void* pvPrivateData
									);							


/*********************** The internal utility functions for the FXO FSM *****************************/
/*The Set of Macros used to start timers through a common interface*/
/*TONETIMERS*/
/*TONE*/
#define DIAL_TONE        0
#define RING_BACK_TONE   1
#define BUSY_TONE        2
/*TIMER*/
#define FULL_INTERDGT    3
#define PROG_INTERDGT    4
#define OFF_HK_WAIT      5
#define LINE_DIGIT       6
#define LINE_INTERDIGIT  7
#define RINGBURST        8
#define RETRY            9
#define DIALWAIT         10
#define HOOKFLASH        11
#define ON_HK_WAIT       12
#define OFF_HK_CID       13
#define DEFAULT          0
# if 0
/*! 
    \brief     This function would be called to play a particular tone
					Start the given tone and the timer for tone
					in accordance with the ucTONETIMER value. 
    \param[in] ucTIMER is Tone or Timer MACRO.	
    \param[in] unTimeout in miliseconds is expected. 
					If 0, it will try to pick from 
					standard values based on EvtId , else would return fail.  
    \param[in]		pxEndptInfo      
    \return     IFX_SUCCESS or IFX_FAILUREURE
*/

e_IFX_Return IFX_FXO_StartToneTimer(uchar8 ucTONETIMER,uint32 unTimeout,
								x_IFX_FXO_Info * pxEndptInfo);

# endif
/****************************************************************************************/
/********** The Functions like FXO Agent Init Shut and status ****************/

/*! 
    \brief     -It Memsets the appropriate xFxoInfo structure. populates the EndpointId in it
					-It Registers the Callbacks 		
					-It Registers with Message router								 
					-Initializes FXO with Default values	
    \param[in] 		
    \param[in]		pxEndptInfo      
    \return     IFX_SUCCESS or IFX_FAILUREURE
*/

e_IFX_Return IFX_FXO_AgentInit(char8 ppszEndptId[][IFX_MAX_ENDPOINTID_LEN],
											uint32 uiNumEndpts, uchar8 vucDbgId);

/*! 
    \brief    		- It Calls MakeFXOIdle
						- It Unregisters all the callbacks.
    \param[in] 		
    \param[in]		pxEndptInfo      
    \return     IFX_SUCCESS or IFX_FAILUREURE
*/

e_IFX_Return IFX_FXO_AgentShut(char8 ppszEndptId[][IFX_MAX_ENDPOINTID_LEN],
								uint32 uiNumEndpts);


/********************** Macros used in FSM ***********************************/
#define IFX_FXO_MOVETO_STATE(STATE,pxEndptInfo) {\
		pxEndptInfo->ePrevState = pxEndptInfo->eCurrState;\
		pxEndptInfo->eCurrState = STATE;\
		IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,\
			"State is changed to ",IFX_FXO_GetState(pxEndptInfo->eCurrState));\
		}


#define IFX_FXO_POPULATE_DIALSTRING(string,pxEndptInfo) { \
		memset(pxEndptInfo->szPstnDgt,0,IFX_FXO_MAX_PSTN_NUM); \
		strcpy(pxEndptInfo->szPstnDgt,string); \
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO, \
                 "Dial String populated:-",string);\
		pxEndptInfo->pcCurrDgt = pxEndptInfo->szPstnDgt;   } \


# define IFX_FXO_RELEASECALL(CID){\
   if(CID){\
      e_IFX_CMGR_Status status=IFX_CMGR_STATUS_SUCCESS;\
      e_IFX_ReasonCode reason=IFX_MAX_REASON;\
      IFX_CMGR_CallRelease(CID,IFX_MAX_REASON,NULL,&status,&reason);\
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,\
             	"Releasing The Call with Call Id ",CID);\
      CID = 0;\
   }}


# define IFX_FXO_STOPTIMER(TIM_ID){\
   if(TIM_ID){\
      IFX_TIM_TimerStop(TIM_ID);\
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,\
			"Stopping timer ",stgnize(TIM_ID));\
      TIM_ID=0;}\
   }


/************* FSM Decleration******/

typedef e_IFX_Return 
	(*pfn_IFX_FXOFsm)(x_IFX_FXO_Info *pxEndptInfo,x_IFX_FXO_EvtInfo *pxEvtInfo);

# endif /*__IFX_FXO_H__ */

# if 0                                                                                                                             
/*********************** FSM Utility functions ****************/

/*!
    \brief     This function makes FXO Endpoint Idle
               -It calls DeallocResource
               -It calls Stops CPTS
               -It calls Stops CID Rx
               -It does on hook.
               -It stops the Tone if playing and Timers if any running.
               -It does ReleaseCall if active and memsets the callData
               -It Does ReleaseCall clears emergency call data
               -It clears the flags and dialDigit/collected digits and pointers
   				-It Resets the flag variable.
 					-Memsets DMI and CID data.
	\param[in]      pxEndptInfo is Endpoint Info
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_MakeFXOIdle(x_IFX_FXO_Info *pxEndptInfo);

/*
This is a utility function which will do CallInitiate from 
inside depending on mode and numbering plan action specified.
It will return status as accept/reject/pending.
*/
e_IFX_FXO_Return IFX_FXO_CallInitiate(
													IN x_IFX_FXO_Info *pxEndptInfo,
													IN uint32* puiCallId,													
													IN char8 *szTgtNum,
													e_IFX_LineMode eMode,
													IN e_IFX_DP_Action eAction												
												 );

/********************************* FSM handlers ******************/                                                                                                                             
/*!
    \brief          This function would be entry point for FXO FSM.
                    It invokes the FSM depending upon the event.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
                                                                                                                             
e_IFX_Return IFX_FXOHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!

	\brief	This Handler is used to Ignore a given event in a given state
   \param[in]      pxEndptInfo is Endpoint Info
   \param[in,out]      pxEvtInfo is Event Info
   \return     IFX_SUCCESS or IFX_FAILURE

*/
e_IFX_Return IFX_FXO_IgnoreHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
								);

/****************** IDLE STATE ****************/

/*!

	\brief	This Handler is used to handle IncomingCall event in IDLE state
				Logic-Check RING_STARTED flag, it set, reject the call
         	else Call AllocResource do off hook , check for Number of digits received.
             -if 0 , Start CPTD  for Busy Tone,move to CONVERSATION state, function callback returns
                   with CallAnswer.
             -if > 0 Start DIAL_WAIT_TIMER .Start CPTD for DialTone.Populate DialString.
                   move to DIAL_WAIT state, function callback returns with CallAccept.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE

*/
e_IFX_Return IFX_FXO_IdleIncCallHdlrHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
								);

/*!
    \brief     This function is called when RingStart event is received.
					Logic-Set flag RING_STARTED,Call AllocResource.					
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_IdleRingStartHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
								);

/*!
    \brief     This function is called when RingStop event is received.
    				Logic-Clear RING_STARTED flag, Start RingTimer and CID detection. 
							Move to CID_WAIT state
	 \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_IdleRingStopHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
								);
/*!
    \brief     This function is called when Emergency call event is received in IDLE state.
					Logic:-Check RING_STARTED flag,Set EMG_CALL flag.
                 =>it set, do off hook, start ON_HOOK_WAIT timer,copy Emergency call data in a local buffer,
                        copy the number to dialString. Move to CONVERSATION state.
                 =>else Call AllocResource do off hook,Copy the emergency call data in buffer ,
								Start CPTD for Dial tone,start DIAL_WAIT Timer. 
								Populate DialDigit string.move to DIAL_WAIT state,
                        function callback returns with CallAccept.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_IdleEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
								);

/*!
    \brief     Logic-Check RING_STARTED flag, it set, reject the SMS
    	else Call AllocResource do off hook , Start CPTD for Dial tone ,
    			start DIAL_WAIT Timer.Set the flag MOVE_TO_SMS.
    			Populate the DialString with SM-SC/SME/DMI Number.
    			Move State to DIAL_WAIT.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_IdleTxmitSMSHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/****************** CID_WAIT STATE ****************/
/*!
    \brief    		
		Logic:-Check the FXO Mode
			if(Gateway mode && ((Outgoing call block set)||(No valid voiceline attached))
      		Restart the RingTimer.Cancel CID.Move to Ringing state.
				(Let the device ring but donot pickup So move to ringing state 
				without initiating call and starting retry timer)
    		if forwarding Mode => Restart the RingTimer.Cancel CID.Populate RetryCallData.Call InitCall API from CMGR
    					InitCall Return values:
     			-CallAccepted:Move to RINGING state.
     			-CallAnswered:Cancel the RingStart timer.do off hook.Start CPTD for BUSY tone.
            	Move to CONVERSATION state.
     			-Pending:Move to RINGING state.
     			-Busy:Start RetryTimer.Move to RINGING state.
    if Gateway mode => Stop the RingTimer,Cancel the CID, do off Hook. Start DialTone
      and dial tone timer.Start CPTD for Busy tone.Move the state to DIGIT_COLLECT. 
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_CWRingStartHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
								);

/*!
    \brief     		
				Logic-Stop CID Rx Check for DMI value
					=>[DMI = 0/1] Or CID not populated :-Call ReleaseResource.Reset the flags.Move to IDLE State.
          		=>[DMI = 2/9]:-Set the flag MOVE_TO_SMS.Populate the DialString with SM-SC/SME/DMI Number.
            			Start CPTD for Dial Tone.Start the DIAL_WAIT Timer.Move State to DIAL_WAIT.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_CWRingTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
								);

/*!
    \brief     
		Logic- Populate the CID.Match the Number with SM-SC Number
			 -SM-Sc Number Matched:Check for the DMI value
         =>[DMI = 0/1]:-cacnel the RingTimer. do off hook,Start CPTD for busy tone,Move to SMS state.
         =>[DMI = 2/9]:-(Wait till ringing stops).
      	-SM-SC Number Not Matched:(Wait till Next ringStart)				 
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_CWCIDRxHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
								);

/*!
    \brief     	
			 Logic-Stop CID Rx.Populate the EmergencyCall data in a local buffer.
			 do off hook, start ON_HOOK_WAIT timer,
          copy the number to dialString,set EMG_CALL flag.
          Move to CONVERSATION state.send Callaccept
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_CWEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/****************** RINGING STATE ****************/
/*!
    \brief     Logic-Stop the RingTimer	
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_RGRingStartHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Start the Ringtimer 	
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_RGRingStopHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );


/*!
    \brief     	Logic-(Can come only on actv call)Start the Retry Timer
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_RGRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     	Logic-(Can come only on active call).do off hook.cancel the 
			 RingTimer if running.Start the Busy CPTD and move to CONVERSATION state
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_RGAnsHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );
/*!
    \brief     Logic-
					do ReleaseCall if call is initiated.stop the Retry timer if running.
          		Clear the flags.Flush the dialstring.Call DeallocResource and move to 
					IDLE state.	
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_RGRingTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     	Logic-Do InitCall.The return values can be:-
						-CallAccept:
						-CallAnswer:Cancel the Ringburst timer if running.
								do off hook.start CPTD for busy tone. move state to conversation state.
						-CallReject:Stert Retry timer
						-Pending:
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_RGRetryTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Stop the Retry timer and Ring timer if running.else do CallRelease 
					Populate the dial string
					do off hook.start ON_HOOK_WAIT timer. set EMG_CALL flag.
					and move to CONVERSATION state.	
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_FXO_RGEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/****************** DIGIT_COLLECT STATE ****************/
/*!
    \brief    Logic-Stop the dial tone if playing and the timer.Stop the Interdigit timer. Invoke the DialPlan.
      		=>Dial plan output=continue:As per the output start the Interdigit timer again.
      		=>Dial plan output=Mismatch:do on hook.start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state. 
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DCDgtPrsHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-(Busy tone)
						Stop dial tone if playing.Stop the timer.do on hook.else stop interdigit timer.
						start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DCToneDetectHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Invoke the dial plan again.
                =>Dial plan output=Match:As per the output.Do callInit. the outputs could be
                --->Accept:Start RINGBACK tone and timer Move to RINGBACK state.
                --->Answer:Move to CONVERSATION state.
                --->Busy:do on hook.start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state.
                --->Pending:Move to RINGBACK state.
                =>Dial plan output=Mismatch:do on hook.start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DCInterDgtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Stop the Tone.do on hook.start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state. 
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DCDialTnTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );
/*!
    \brief    	Logic-Stop dial tone and timer if playing else stop interdigit timer
							Set the EMG_CALL flag.populate the dialdigits and the Emgcall data.do on hook.
                        start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state.Send AcceptCall 
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DCEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/****************** RING_BACK STATE ****************/

/*!
    \brief     	Logic-(Can come only on actv call).Stop RingBack tone and timers if running.
      				Stop CPTD.do on hook.start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_RBRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );
/*!
    \brief     Logic-(Can come only on active call)Stop ringback tone and timer if playing. 
					Start the CPTD for BUSY tone.
      			Move the state to CONVERSATION.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_RBAnsHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief    Logic-Start Ringback tone and timer. 
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_RBAcceptHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Stop The Ringback Tone. Do ReleaseCall.do on hook.start OFF_HOOK_WAIT timer
      and move to OFF_HK_WAIT state.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_RBRingBackTnTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief    Logic-[Busy]-Stop RINGBACK tone and timer if running.Send release to active call.do on hook.
      start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_RBToneDetectHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief    Logic--Stop RINGBACK tone and timer if running.Send release to active call
				Set the EMG_CALL flag.populate the dialdigits
         	and the Inc call data.do on hook.start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state.
         	Send AcceptCall in return. 
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_RBEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );
/*********************** DIAL_WAIT STATE **************/


/*!
    \brief     Logic-[Dial tone]Cancel the DIAL_WAIT timer.Pick up the first digit 
				from DialString and play tone.Start the LINE_DIGIT Timer.
				Move the state to the DIGIT_DIAL.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DWToneDetectHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-(Can come only on actv call, can be emergency call also)
					Cancel the CPTD and dial wait timer.Reset EMG_CALL flag.
               do set on hook.Start the off hook wait timer.move to OFF_HOOK_WAIT state.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DWRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     	Logic-Set EMG_CALL flag.Copy the call data in to active call.
						Send ReleaseCall to the previous Active call.populate the Dialstring.send Callaccept to it.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DWEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );


/*!
    \brief     	Logic-Cancel the Dial tone CPTD.Pick up the first digit
        from DialString and play tone.Start the LINE_DIGIT Timer.Move the state to the DIGIT_DIAL.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DWDialWtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/**********************DIGIT_DIAL STATE *******/

/*!
	 \brief     	Logic-
				stop the currently playing digit tone,Check any digits are left in the string,
        if yes=>Start the LINE_INTERDIGIT timer.
        if no=>dialing is complete. check MOVE_TO_SMS. and clear it.
        -->MOVE_TO_SMS flag set:Start busy CPTD, move to SMS state.
        -->MOVE_TO_SMS flag not set:Start busy CPTD,
          ALSO Send AnswerCall to active call, move to CONVERSATION state.

    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DDLineDgtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     	Logic-pick up the next digit from dialString. call the playtone.
          and start LINE_DIGIT Timer
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DDLineInterDgtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     	Logic-(Can come only on actv call)
        Cancel the LINE_DIGIT /LINE_INTERDIGIT timers if they active.
        do on hook.Start the off_HK_WaitTimer.Reset the EMG_CALL flag. move to OFF_HK_WAIT state.	
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DDRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     	Logic-Set EMG_CALL flag.Stop the Line dgt/InterDgt timers.
			do on-hook.start OFF_HOOK_WAIT timer.copy the calldata into local buffer.
			copy the string to dialstring.Do release to active call
         Move the state to OFF_HK_WAIT.send Callaccept	
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_DDEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/******************************* OFF_HOOK_WAIT STATE*********************/

/*!
    \brief     Logic-Check the MOVE_TO_DIALWAIT flag and MOVE_TO_SMS flag
            -> If any of them set, Reject the call.
            -> Else Populate the Active call information.Populate the Number in to Dialstring
                Send CallAccept.Set the MOVE_TO_DIALWAIT flag.	
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_OhwIncCallHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Check the MOVE_TO_DIALWAIT flag
              if set,Send release to Active call.clear the active call data.clear the MOVE_TO_DIALWAIT flag.
              ALSO Set EMG_CALL flag.Copy Number to dialstring and calldata in a buffer.	
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_OhwEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief    		Logic-heck the MOVE_TO_DIALWAIT flag
                  -if set,and release is for the Active call Id.clear the MOVE_TO_DIALWAIT flag.
                  -else check EMG_CALL flag
                    =>if set,and the release is for emergency call.Reset the EMG_CALL flag.
                          memset the emergency the emergencyCall data
                    =>else return;
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_OhwRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );


/*!
    \brief     Logic-Check for EMG_CALL flag
        =>if set: do off hook,Copy Emgcall data from buffer to active and flush the buffer,
          start the DIAL_WAIT timer. move the state to DIAL_WAIT.
        =>if not set:Check for MOVE_TO_DIALWAIT flag
                  ->if set:Reset the flag.check the length of dialstring
                          if = 0 :do set off hook.start busy tone CPTD.Send answer to the call.
                                  move state to CONVERSATION state.
                          if > 0 :Clear the flag.do off hook,start the DIAL_WAIT timer. move the state to DIAL_WAIT
                  ->if not set:Check for MOVE_TO_SMS flag
                      ->if set:do off hook,start the DIAL_WAIT timer. move the state to DIAL_WAIT.
                      ->if not set:Clear all flags.Clear the DialString .call DeallocResource. Move state to IDLE.	
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_OhwOffHkWtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Check MOVE_TO_DIALWAIT flag.
          ->If set, Reject the SMS.
          ->else Set the MOVE_TO_SMS flag. populate the DialString with SM-SC number/0/DMI.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_OhwTxmitSMSHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );
/******************************* CONVERSATION STATE*********************/


/*!
    \brief     Logic-Invoke SendDigits In Call
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvDgtPrsHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-[busy]If ON_HOOK_WAIT timer is running, Ignore the event.
        elae check the hookstate if on hook cancel the hook flash timer else Do on hook.
        also Send Release to active call.start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state.
			Reset the emergency call flag
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvToneDetectHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );
/*!
    \brief     Logic-If The OffHk CID is in progress, drop the event.
						ELSE:
						(If Hook flash is working)- Do Set hook flash
						(If Hook flash is NOT working)- Do set on hook. Start Hook flash timer
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvPSTNHkFlashHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-(Can come on either emg call in buffer or actv normal or emg call)
                Reset the EMG_CALL flag.Stop CPTD.Check hookstate
                  ->if on hook,cancel hookflash timer.
                  ->else do on hook.
                    ALSO start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT_STATE.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-do on hook and start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvOnHkWaitTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-do off hook
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvPSTNHkFlashTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Start Off hook CID reception. Start Off hook CID timer
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvCASHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Stop The Off hook CID
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvOffHkCIDTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-Stop The Off Hk CID timer.
						if SM-SC number == Number received,drop the event
						else Invoke Send OffHook CID
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvCIDHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );

/*!
    \brief     Logic-check the hookstate if on hook cancel the hook flash timer else Do on hook.
        Send Release to active call.Stop CPTD.Set EMG_CALL flag.
        Copy Number to dialstring and calldata in a buffer.Stop CPTD.
        start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT_STATE. send AcceptCall.
    \param[in]      pxEndptInfo is Endpoint Info
    \param[in,out]      pxEvtInfo is Event Info
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_FXO_ConvEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo
                        );
# endif










