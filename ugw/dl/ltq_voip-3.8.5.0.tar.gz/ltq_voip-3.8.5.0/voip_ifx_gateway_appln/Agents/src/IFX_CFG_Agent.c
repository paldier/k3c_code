/***********************************************************************
*   SRC_FILE           : IFX_CFG_Agent.c
*   PROJECT            : Voip Gateway Subsystem
*   MODULES            : Gateway Application
*   SRC VERSION        : V1.0
*   DATE               : 21/05/2007
*   AUTHOR             : Gw Appln Team
*   DESCRIPTION        :
*   FUNCTIONS          :
*   COMPILER           : mips(el)-linux-gcc
*   REFERENCE          :
*   COPYRIGHT          :Copyright © 2004
*                       Infineon Technologies AG
*                       St. Martin Strasse 53; 81669 München, Germany
*   DESCLAIMER         :Any use of this Software is subject to the conclusion
*                       of a respective License Agreement.
*                       Without such a License Agreement no rights to the
*                       Software are granted.
*   Version Control Section
*   $Author$
*   $Date$
*   $Revisions$
*   $Log$       Revision history
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_os.h"
#include "ifx_ipc.h"
#include "ifx_list.h"
#include "IFX_Config.h"
#include "IFX_CallMgrIf.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_Agents_CfgIf.h"
#include "IFX_CallMgr_CfgIf.h"
#include "IFX_TimerIf.h"
#include "IFX_DialPlanIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_CFG_Agent.h"

#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"

#ifdef DECT_SUPPORT
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_DIAG.h"
#include "IFX_DECT_MU.h"
#endif
#ifdef CVOIP_SUPPORT
#include "LTQ_CVOIP_MsgHdlr.h"
#include "LTQ_APP_Parser_Intf.h"
#include "LTQ_CVOIP_Agent.h"
#endif

//#define DEMO 0

//TODO  - move to proper header file
#define IFX_MAX_BUFF_SIZE 200
#define IFX_DSP_DEVICE_POS 5
/*With SLIC121-Clare,Dsp dev fd is used for FXO events too*/
#ifndef SLIC121
#define IFX_FXO_DEVICE_POS 6
#else
#define IFX_FXO_DEVICE_POS 5
#endif
#define IFX_MAX_DEVICES_IN_VMAPI 7

#define printf(...)
#define print_error   printf
#define print_message printf
//uchar8 vuiDiagMode;

/* Added to delay the missed call notification after the release */
typedef struct{
  x_IFX_VMAPI_MissCallRegister xMissOld; 
  x_IFX_VMAPI_MissCallRegister xMissNew; 
}xMissedNtfy;
xMissedNtfy vxMissedTemp;
int32 viNewMissedCall;
uint32 vuiMissedTimerId;
extern uint16 vunDialToneLength;

typedef struct{
  x_IFX_VMAPI_VoiceLine xVlOld;
  x_IFX_VMAPI_VoiceLine xVlNew;
}xVLNtfy;
xVLNtfy vxVlTemp;
uint32 vuiVlChTimerId;


#ifdef ENABLE_FXO
boolean vbFxoEnable;
#endif

STATIC x_IFX_CFG_LineInfo	vaxLineInfo[IFX_MAX_LINES];
/* Debug Id for Application Modules */
STATIC uchar8	vcFXSModId, vcFXOModId;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
uchar8  vcDECTModId; 
#endif
#if defined(DECT_SUPPORT)
uint32 vuiGwUp;
#endif
STATIC uchar8  vcMMModId, vcCMModId, vcDPModId; 
STATIC int32	viVmapiFifoFd; /* Vmapi Fifo Fd */
int32 iDectSSTimerFd;
#if defined(DECT_SUPPORT)
//Functions required for SIP module initialization and config
EXTERN e_IFX_Return IFX_CIF_DectBasicParamsGet(char8* pszBasePin, uchar8* pucBitMap,
                                        x_IFX_DECT_EnhancedStackCfg *pxEnhancedStackCfg);
#endif

EXTERN e_IFX_Return IFX_SIPAPP_Init(IN uint32 uiNoOfSrvPdr);
EXTERN e_IFX_Return IFX_SIPAPP_CreateSrvPdr(IN uint32 uiSrvPdrId);
EXTERN e_IFX_Return IFX_SIPAPP_DestroySrvPdr(IN uint32 uiSrvPdrId);
EXTERN uint32 IFX_SIPAPP_CfgSrvPdr(IN uint32 uiSrvPdrId,
      			                                 IN uchar8 ucOptions,...);

//Functions required for RTP module initialization and config
EXTERN int32 IFX_RTPAgent_Init( uchar8 ucDbgLvl, uchar8 ucDbgType, 
	                                                   uint32 uiInternalPort );
EXTERN int32 IFX_RTPAgent_Config(uchar8 ucDbgLvl,uchar8 ucDbgType);

//Functions required for FAX module initialization and config
EXTERN int32 IFX_FAXAgent_Init(
	                 IN uchar8 ucDbgLvl,
		               IN uchar8 ucDbgType,
		               IN x_IFX_VMAPI_T38Cfg *pxFA_T38Cfg );
EXTERN int32 IFX_FAXAgent_Config(uchar8 ucDbgLvl,uchar8 ucDbgType);

EXTERN e_IFX_Return IFX_CIF_VLVMSubEventGet(
	               IN uchar8 ucVoiceLineId,
								 IN boolean bDepositAddr,
								 OUT x_IFX_CalledAddr* pxAddr,
								 OUT uint16* punSubExpiryTime);
EXTERN e_IFX_Return 
IFX_DECT_DebugCosic(IN uchar8 ucPPInstance, 
	                  IN uchar8 ucReqId, //req id
	                  IN uchar8 ucOper, //read/write
	                  IN uchar8* pcBuf, //Buffer for writing
	                  IN uchar8 ucBufLen);
EXTERN e_IFX_Return 
IFX_FXS_AgentStatus(char* pszEndptId, x_IFX_AgentStatus* pxStatus);
EXTERN e_IFX_Return 
IFX_CIF_LineTestResultSet(char8* pszEndpt,
                          x_IFX_VMAPI_VoiceServTestResult* pxPhyIntTestRes);

EXTERN e_IFX_Return 
IFX_DECTAPP_UpdateEndPtId(uchar8 *pcOldEndPtId, uchar8 *pcNewEndPtId);

/* STATIC/Local declarations */
e_IFX_Return 
IFX_CIF_StoreValuesFromModem(e_IFX_VMAPI_ObjectId eObj,IN void *buf);
#ifdef CVOIP_SUPPORT
e_IFX_Return 
IFX_CIF_DectSystemGet(x_IFX_VMAPI_DectSystem *pxDectSystemOld);
e_IFX_Return IFX_CIF_TPCValGet(OUT x_IFX_VMAPI_TransmitPowerParam *pxTpc);
e_IFX_Return IFX_CIF_GaussianValGet(OUT x_IFX_VMAPI_DectGFSKVal *pxGfsk);
e_IFX_Return IFX_CIF_BMCRegparamGet(OUT x_IFX_VMAPI_DectBMCParams *pxBMCParams);
e_IFX_Return IFX_CIF_OscTrimParamGet(OUT x_IFX_VMAPI_DectOscTrimVal *pxOscTrimVal);
#endif
STATIC e_IFX_Return IFX_CFG_CMInit();
STATIC e_IFX_Return IFX_CFG_DbgInit();
STATIC e_IFX_Return IFX_CFG_CreateFifoForVmapiNtfy();
STATIC e_IFX_Return IFX_CFG_TimerInit();
STATIC e_IFX_Return IFX_CFG_ReadFwFile(
	               IN	char8	*szFWFile, 
	               OUT uchar8	**ppucFwPram, 
                 OUT uint32	*punBytes);
STATIC int32  IFX_CFG_fgets(char8* pcBuff, int32 uiReadLen, int32 iFd);
STATIC e_IFX_MMGR_ToneType  IFX_CFG_GetToneType(char8* pcTone);

STATIC char8 IFX_CFG_strtok(char8* pcStarIndex,
                  char8* pcEndIndex,
                  char8** pcMatchedLocation,
                  char8* pcToken );
STATIC char8* IFX_CFG_strchr(char8* pcStartIndex,
                   char8* pcEndIndex,
                   char8 cMatch );
STATIC int32 IFX_CFG_ParseFreqAndGainVal(char8* pcStartIndex,
                          char8* pcEndIndex,
                          x_IFX_MMGR_FreqGain *pxFreqGain );
STATIC int32 IFX_CFG_GetFreqIndex(char8 *pcFreqName,
                   x_IFX_MMGR_Tone *pxTone );
STATIC int32 IFX_CFG_ParseFrequencies(char8* pcBuff,
                       x_IFX_MMGR_Tone* pxTone);
STATIC int32 IFX_CFG_ParseCadencePattern(char8 *pcStartIndex,
                          char8 *pcEndIndex,
                          x_IFX_MMGR_Tone *pxTone,
                          int32 iCadenceCount);
STATIC int32 IFX_CFG_ParseCadence(char8* pcBuff,
                   x_IFX_MMGR_Tone *pxTone);
STATIC e_IFX_Return IFX_CFG_GetCountrySpecificSettings(
	                   IN char8* pcCountryFileName,
	                   OUT x_IFX_MMGR_CountrySettingsParams *pxParams);

STATIC e_IFX_Return IFX_CFG_MMInit();

STATIC e_IFX_Return IFX_CFG_AgentsInit();

STATIC e_IFX_Return IFX_CFG_VLRegister(
	                   IN uchar8 ucLineId,
	                   IN boolean bRegister,
                     IN boolean bDontWaitForResp ) ;
STATIC e_IFX_Return IFX_CFG_VLVMSubscribe(
										 IN uchar8 ucLineId,
										 IN boolean bSubscribe,
                     IN boolean bDontWaitForResp);
STATIC e_IFX_Return IFX_CFG_VLRegAndSub();

STATIC e_IFX_Return IFX_CFG_ConvertNumPlanObject(
	                   IN	x_IFX_VMAPI_NumPlanRule * pxVMAPIRule,
	                   OUT	x_IFX_DP_Rule* pxDPRule );

STATIC e_IFX_Return IFX_CFG_RegRespHdlr(
	               IN uint32 uiRequestId,
	               IN uint32 uiExpVal,
	               IN e_IFX_CMGR_Status eStatus,
	               IN e_IFX_ReasonCode eReason,
	               IN void* pvPrivateData );
STATIC e_IFX_Return IFX_CFG_SubnRespHdlr(
	               IN uint32 uiRequestId,
	               IN uint32 uiExpVal,
	               IN e_IFX_CMGR_Status eStatus,
	               IN e_IFX_ReasonCode eReason,
	               IN void* pvPrivateData );

STATIC e_IFX_Return IFX_CFG_VMNotifyHdlr(
	               IN uint32 uiRequestId,
	               IN x_IFX_CMGR_VoiceMailNotifyInfo* pxVoiceMailNtfyInfo,
	               IN void* pvPrivateData );

STATIC e_IFX_Return IFX_CFG_PopulateDialPlan( );
#ifdef LTAM
STATIC e_IFX_Return IFX_CFG_MsgRouterEvtHdlr(
	                      IN x_IFX_MMGR_DeviceEvents	*pxDevEvents);
#endif
STATIC e_IFX_Return IFX_CFG_VmapiNtfyHdlr(IN int32 iFd);
STATIC e_IFX_Return IFX_CFG_CfgnParamsNtfnReg();
e_IFX_Return IFX_CFG_ProfileNtfyHdlr(IN x_IFX_VMAPI_VoiceProfile* pxVpOld, 
	                                   IN x_IFX_VMAPI_VoiceProfile* pxVpNew );

#ifndef LIST_ACCESS
extern e_IFX_Return IFX_CMGR_ListAccessNtfy(e_IFX_CMGR_LA_Type,void *, void *);
#endif

extern e_IFX_Return IFX_CMGR_DateTimeNtfy(void *, void *);
#ifdef DECT_SUPPORT
e_IFX_Return  IFX_CFG_Start_DECT(void)
{
{	
/* DECT Agent Init */
	char8	aszEndptIdList[IFX_MAX_ENDPTS][IFX_MAX_ENDPOINTID_LEN];
  uchar8 ucNumEndpts = IFX_MAX_ENDPTS;
  e_IFX_ReasonCode eReason;
  //uint32 uiDectDownLoadTimer;
	IFX_CIF_DectEndptListGet(&ucNumEndpts, aszEndptIdList, &eReason);
	if( ucNumEndpts == 0 || IFX_DECT_AgentInit(aszEndptIdList, 
													ucNumEndpts, vcDECTModId) != IFX_SUCCESS )
	{
		print_error("<%s:%d> ERROR : DECT Agent Initialization FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
 //IFX_TIM_TimerStart(12000,NULL, 0, IFX_DectStartTime,&uiDectDownLoadTimer);
}
	return IFX_SUCCESS;
}
#endif

/*******************************************************************************
* Function Name    : IFX_CFG_MissNotify
* Description      : This routine sends the missed call notification
* Input Values     : None
* Output Values    : None
* Return Value     : None
* Notes            :
*******************************************************************************/
void 
IFX_CFG_MissNotify(IN uint32 uiTimerId,
                   IN void* pvPrivateData)
{
  vuiMissedTimerId=0;
  IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_MISSED_CALLS,&vxMissedTemp.xMissOld,&vxMissedTemp.xMissNew);
}

#if 0
#define IFX_CFG_RstApp() \
	{ \
		printf("\n\n\n\n%s: SYSTEM IS REBOOTING\n\n\n",__FUNCTION__); \
		system("reboot"); \
	} 
#else
/*******************************************************************************
* Function Name    : IFX_CFG_RstApp
* Description      : This routine restarts the application.
* Input Values     : None
* Output Values    : None
* Return Value     : None
* Notes            :
*******************************************************************************/
void  IFX_CFG_RstApp(void)
{
	/* Fork and Execve and the invoke the script*/
	pid_t cPid = 0 ;
	char8 acBuf[IFX_MAX_ENDPOINTID_LEN];
	char8 *pcIfName = NULL;

	/* Get the WAN parameter*/
	pcIfName = getenv("WAN");
	if (pcIfName == NULL) {
		printf("could not get interface ip\n");
		return;
	}
	snprintf(acBuf, IFX_MAX_ENDPOINTID_LEN, "%s", pcIfName);
	switch(cPid = fork())	
	{
		case 0:
		{
			char8* cmd[] = {"RestartAppScript.sh", acBuf};
			char8* evp[] = {NULL};
			if (execve("RestartAppScript.sh",cmd,evp))
			{
				perror("execve");
				system("reboot");
			}
		}
		break;
		case -1:
		{
			perror("fork");
			system("reboot");
		}
		break;
		default:
			wait(NULL);	
	}
	return;
}

#endif

#ifdef DECT_SUPPORT
void IFX_DectStartTime( uint32 uiTimerId, void *ptr)
{
	uchar8 ucBitMap;
	ucBitMap=0;
	x_IFX_DECT_EnhancedStackCfg xEnhancedStackCfg={0};
	printf("\n\n\n DECT Timer Fired initing MMGR and rest of the agents\n\n\n");
	/* initialise Media Manager */
	if (IFX_CFG_MMInit() != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR: IFX_CFG_MMInit FAILED\n", __FUNCTION__,__LINE__);
		return ;
	}
	printf("\n\n\n VMAPI Fifo Init\n\n\n");
		/* 
	 * open a fifo in the receive mode to receive notifications from MAPI-V
	 * and register this fd with the message router
	 */
	if (IFX_CFG_CreateFifoForVmapiNtfy() != IFX_SUCCESS)
	{
		print_error("<%s:%d> : ERROR: Could Not Create VMAPI FIFO\n", 
																											__FUNCTION__,__LINE__);
		return;
	}

	printf("\n\n\n Agents Init Init\n\n\n");
	/* initialise Call Manager */
	IFX_CFG_AgentsInit();
/*Reading the Rf on/off param from rc.conf*/
	if(IFX_SUCCESS != IFX_CIF_DectBasicParamsGet(NULL,&ucBitMap,&xEnhancedStackCfg)){
		return;
	}
	/*Call the API for RF on/off only in case of off as the default startup mode is rf on*/
	if((ucBitMap&LTQ_DECT_RF_BITMAP)==0){
  	x_IFX_DECT_StackCfg xDECTStackCfg={0};
		xDECTStackCfg.bRfEnable=0;
  	IFX_DECT_Configure(IFX_DECT_CONFIG_RF,&xDECTStackCfg);
	}

	/*Pass 0 for configuring Nemo on else 1*/
	IFX_DECT_MU_NemoConfig(((ucBitMap & LTQ_DECT_NEMO_BITMAP) == 2 )?0:1);

	/*
	 * Finally, register those parameters with the MAPI-V which when changed
	 * from the web GUI/ACS can affect the calls or the system
	 */
	if (IFX_CFG_CfgnParamsNtfnReg() != IFX_SUCCESS)
	{
		print_error("<%s:%d> : ERROR: IFX_CFG_CfgnParamsNtfnReg FAILED\n", 
																											__FUNCTION__,__LINE__);
		return;
	}

	printf("\n\n\n Start registering and subscribing\n\n\n");
	IFX_CFG_VLRegAndSub();
	print_message("\n\n\n Gateway Application Is Up\n\n\n");
	vuiGwUp=1;
}
#endif


/*Globlal variable - Fd to /tmp/VoipStatusFifo*/
static  uint32 viVoipStatusFd =0;
#define IFX_VOIP_STATUS_FIFO "/tmp/VoipStatusFifo"
#define IFX_VOIP_STATUS_FIFO_PERM 0777
 /*******************************************************************************
* Function Name    : IFX_CFG_VoIPSigHdlr
* Description      : Function to trap SIGUSR1. Do very minimal stuff here.
										 Write a dummy message to Fifo and come out.
             
* Input Values     : 
* Output Values    :
*******************************************************************************/

void IFX_CFG_VoIPSigHdlr(int sig_number)
{
  //printf("\nSignalled\n");
  if(viVoipStatusFd !=0 ){
    write(viVoipStatusFd,"Wakeup!!",8);
  }
  return;
}

#ifdef VOIP_NEWVMAPI
/*******************************************************************************
* Function Name    : IFX_CFG_VoipIfChangeHandlr
* Description      : This functions is invoked when VoIP interface changed
* Input Values     :acInterfaceInfo Interface to be changed 
* Output Values    :Success/Failure
*******************************************************************************/
e_IFX_Return IFX_CFG_VoipIfChangeHandlr(char8 *acInterfaceInfo)
{
  e_IFX_Return eRet=IFX_FAILURE;
  x_IFX_VMAPI_VoiceProfile xOldProfile = {{{{""}}}};
  x_IFX_VMAPI_VoiceProfile xNewProfile = {{{{""}}}};
	char8 *pcIfName = NULL;
 
   /*Get profile information*/
   xOldProfile.ucProfileId = 1;
   if( IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xOldProfile,IFX_CIF_GET_FLAGS)){
		return IFX_FAILURE;
    }
    memcpy(&xNewProfile,&xOldProfile,sizeof(x_IFX_VMAPI_VoiceProfile));
   
    int nLen = strlen(acInterfaceInfo);
    if(nLen>0 && acInterfaceInfo[nLen-1] == '\n')
          acInterfaceInfo[nLen-1] = '\0';
		
		/* Nothing to be done if App is already running on passed interface */
		pcIfName = getenv("WAN");
		if (pcIfName == NULL || strncmp(pcIfName, acInterfaceInfo, 32) == 0) {
			print_message("\n##### %s %d Nothing to be done #######\n",__func__,__LINE__);
			return eRet;
		}

    /*Exporting WAN*/
    setenv("WAN",acInterfaceInfo, 1);
	
    if(IFX_VMAPI_VP_STATE_ENABLED == xOldProfile.ucState ){
		xNewProfile.ucState= IFX_VMAPI_VP_STATE_DISABLED;
	}

     /*Destroy the old server and unregister line if registered*/	
     eRet =IFX_CFG_ProfileNtfyHdlr(&xOldProfile,&xNewProfile);
     sleep(10);
     xNewProfile.ucState = IFX_VMAPI_VP_STATE_ENABLED;
     xOldProfile.ucState = IFX_VMAPI_VP_STATE_DISABLED;
     /*configure the new server and register line if enabled*/
     eRet =IFX_CFG_ProfileNtfyHdlr(&xOldProfile,&xNewProfile); 
     return eRet;
}

#endif
/*******************************************************************************
* Function Name    : IFX_CFG_VoipStatusFifoMsgHdlr
* Description      : This functions is invoked when VoIP status Fd is unblocked
										 It Opens /tmp/sipip file and reads ip address. If file does 
										 not exists then it is considered as stop service provider, 
										 otherwise - Create service provider will be issued. Once done
										 delete /tmp/sipip file.
             
* Input Values     : 
* Output Values    :
*******************************************************************************/
e_IFX_Return IFX_CFG_VoipStatusFifoMsgHdlr(int32 iFd)
{
  FILE *fp = fopen("/tmp/sipip","r");
  char acMsg[32]="";
  e_IFX_Return eRet=IFX_FAILURE;
  x_IFX_VMAPI_VoiceProfile xOldProfile = {{{{""}}}};
  x_IFX_VMAPI_VoiceProfile xNewProfile = {{{{""}}}};
  int flag=0;
 
  /*Read DUMMY message from the FIFO*/
  if(iFd == 0){
		if(fp)
			fclose(fp);
    return IFX_FAILURE;
  }
  read(iFd,acMsg,32); /*Put error checking code if required*/	
   /*Get profile information*/
  xOldProfile.ucProfileId = 1;
	if( IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xOldProfile,IFX_CIF_GET_FLAGS)){
		if(fp)
			fclose(fp);
		return IFX_FAILURE;
   }
   memcpy(&xNewProfile,&xOldProfile,sizeof(x_IFX_VMAPI_VoiceProfile));
 
  if(fp == NULL){
    /* If old profile enabled - put new profile in disable state */
		 if(IFX_VMAPI_VP_STATE_ENABLED == xOldProfile.ucState ){
      xNewProfile.ucState= IFX_VMAPI_VP_STATE_DISABLED;
      flag = 1;
     }

  }
  else{
     char acWanIf[16]="",acEnv[16]="";
     fread((void *)acWanIf,15,1,fp);
		 fclose(fp);

		 /*Curtail new line characther*/
		 strncpy(acEnv,acWanIf,(strlen(acWanIf)-1));
		 acEnv[strlen(acWanIf)-1] = 0;
		 setenv("WAN",acEnv, 1);

		 if(IFX_VMAPI_VP_STATE_ENABLED == xOldProfile.ucState ){
				xOldProfile.ucState= IFX_VMAPI_VP_STATE_DISABLED;
				flag=2;
		 }

  }
  if(flag != 0){
		eRet =IFX_CFG_ProfileNtfyHdlr(&xOldProfile,&xNewProfile);
		return eRet;
  }
  return IFX_SUCCESS;
}
/*******************************************************************************
* Function Name    : IFX_CFG_SigHandlerInit
* Description      : This function registers SIGUSR1 signal handler. 
                     Creates a FIFO in read and write mode and adds that FIFO to
										 read fd list, by registering call back function 
										 IFX_CFG_V
* Input Values     : 
* Output Values    :
*******************************************************************************/

e_IFX_Return IFX_CFG_SigHandlerInit() 
{
	struct sigaction sa,sb;
  e_IFX_Return eRet =IFX_FAILURE;
	x_IFX_MSGRTR_FdInfo axFdInfo[1];

  memset(&sa,0,sizeof(sa));
  memset(&sb,0,sizeof(sb));
  sa.sa_handler = IFX_CFG_VoIPSigHdlr;
  sigaction(SIGUSR1,&sa,&sb);
  
  system("rm -f /tmp/VoipStatusFifo");
  if(mkfifo(IFX_VOIP_STATUS_FIFO,IFX_VOIP_STATUS_FIFO_PERM)){
    return IFX_FAILURE;
  }
  if( 0 == (viVoipStatusFd = open(IFX_VOIP_STATUS_FIFO,O_RDWR))){
      return IFX_FAILURE;
  }
  axFdInfo[0].uiFd = viVoipStatusFd;
  axFdInfo[0].eFdSetType = IFX_MSGRTR_READ_TYPE;
 
  eRet = IFX_MSGRTR_FdCallBackRegister(axFdInfo,1,
				 IFX_CFG_VoipStatusFifoMsgHdlr);
  if(eRet != IFX_SUCCESS){
    return IFX_FAILURE;
  }
 return IFX_SUCCESS;
}
#ifdef VOIP_NEWVMAPI
e_IFX_Return IFX_CFG_SetFwSupportedCodec() 
{
	uint32 uiFwSuppCodec = 0;
	IFX_MMGR_check_FwSupp(&uiFwSuppCodec);
	if(IFX_VMAPI_UpdateFwSuppCodec(uiFwSuppCodec) != IFX_SUCCESS)
	{
		 print_error("<%s:%d> : ERROR: IFX_VMAPI_UpdateFwSuppCodec FAILED\n",
                                                                                                            __FUNCTION__,__LINE__);		
		return IFX_FAILURE;
	}
	return IFX_SUCCESS;		
}
#endif

/*******************************************************************************
* Function Name    : IFX_CFG_AgentInit
* Description      : This function initializes Gateway Application. Initializes
*                    chip (board initialization), MAPI-V library, debug module,
*                    timer module, dial plan module, call manager, media manager
*                    all agents (including network agents). If all module are 
*                    successfully initialized, then for all lines try to 
*                    register & subscribe to Voice Mail server.  
* Input Values     : 
* Output Values    :
* Return Value     : IFX_SUCCESS - If all modules are initialized.
*                    IFX_FAILURE - On failure.
* Notes            : Registration and subscription to voice mail server will be
*                    carried out only if voice line and its profile are enabled.
*******************************************************************************/
e_IFX_Return
IFX_CFG_AgentInit()
{
	/* we need to initialise the chip for few platforms such as ATA and Amazon */
#ifdef CVOIP_SUPPORT
	/* Initialize COSIC VoIP FP chip*/
	// it shuold be here or inside CVOIP_AgentInit api????
	if (LTQ_CVOIP_Init() != IFX_SUCCESS){
    print_error("<%s:%d>  ERROR: LTQ_CVOIP_Init FAILED\n", __FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	printf("IFX_CFG_AgentInit, CVOIP_Init Suceess\n");
#endif

	/* initialise VMAPI */
	if (IFX_CIF_Init() != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR: IFX_CIF_Init FAILED\n", __FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}

	/* initialise Debug Library..required by all the modules */
	if (IFX_CFG_DbgInit() != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR: IFX_CFG_DbgInit FAILED\n", __FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}
 
	/* initialise Timer Interface, which inturn initialises the Timer library */
	if (IFX_CFG_TimerInit() != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR: IFX_CFG_TimerInit FAILED\n", __FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}
	
	/* populate dial plan module with the dial plan */
	if (IFX_CFG_PopulateDialPlan() != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR: IFX_CFG_PopulateDialPlan FAILED\n", 
										__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}
	if (IFX_CFG_CMInit() != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR: IFX_CFG_CMInit FAILED\n", __FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}

{	
/* DECT Agent Init */
#ifdef DECT_SUPPORT
	if(IFX_CFG_Start_DECT() == IFX_FAILURE)
	{
		return IFX_FAILURE;
	}
#if 0
	char8	aszEndptIdList[IFX_MAX_ENDPTS][IFX_MAX_ENDPOINTID_LEN];
  uchar8 ucNumEndpts = IFX_MAX_ENDPTS;
  e_IFX_ReasonCode eReason;
  //uint32 uiDectDownLoadTimer;
	IFX_CIF_DectEndptListGet(&ucNumEndpts, aszEndptIdList, &eReason);
	if( ucNumEndpts == 0 || IFX_DECT_AgentInit(aszEndptIdList, 
													ucNumEndpts, vcDECTModId) != IFX_SUCCESS )
	{
		print_error("<%s:%d> ERROR : DECT Agent Initialization FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
 //IFX_TIM_TimerStart(12000,NULL, 0, IFX_DectStartTime,&uiDectDownLoadTimer);
#endif
#endif
}
#ifndef DECT_SUPPORT
	/* initialise Media Manager */
	if (IFX_CFG_MMInit() != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR: IFX_CFG_MMInit FAILED\n", __FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}
	
	/* initialise Call Manager */
	if (IFX_CFG_CMInit() != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR: IFX_CFG_CMInit FAILED\n", __FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}
#endif
#ifdef DEMO
	do	{
		x_IFX_VMAPI_VoiceLine xVoiceLine = {{{""}}};
		x_IFX_VMAPI_ProfileSignaling xProfileSig = {{{""}}}; 
		char8 szHostIp[32];

		xVoiceLine.ucLineId = 1; 
		if( IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS) )
		{
			/* Could not get line info...*/
    	print_error("<%s:%d> : ERROR: ifx_get_VoiceLine FAILED\n", __FUNCTION__,__LINE__);
			break;
		}

		xProfileSig.ucProfileId = xVoiceLine.ucProfileId;
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_ProfileSignaling(&xProfileSig,IFX_CIF_GET_FLAGS))
		{
			/* Could not Profile Signaling info...*/
    	print_error("<%s:%d> : ERROR: ifx_get_ProfileSignaling FAILED\n", 
																											__FUNCTION__,__LINE__);
			return IFX_FAILURE;
		}

		IFX_OS_GetHostIp(szHostIp);
		strcpy(xProfileSig.acUADomain, szHostIp);
		if( IFX_VMAPI_SUCCESS != 
				ifx_set_ProfileSignaling(IFX_CIF_SET_OPP, &xProfileSig, IFX_CIF_MOD_FLAG))
		{
			/* Could not Profile Signaling info...*/
    	print_error("<%s:%d> : ERROR: ifx_set_ProfileSignaling FAILED\n", 
																											__FUNCTION__,__LINE__);
		}
	}while(0);
#endif
	/* 
	 * initialise all the Agents (FXS, FXO, DECT, RTP, Fax and 
	 * SIP Network Agent )
	 */
#ifndef DECT_SUPPORT
	if( IFX_CFG_AgentsInit() != IFX_SUCCESS)
	{
		print_error("<%s:%d> : ERROR: IFX_CFG_AgentsInit FAILED\n", 
																											__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}

	/* 
	 * open a fifo in the receive mode to receive notifications from MAPI-V
	 * and register this fd with the message router
	 */
	if (IFX_CFG_CreateFifoForVmapiNtfy() != IFX_SUCCESS)
	{
		print_error("<%s:%d> : ERROR: Could Not Create VMAPI FIFO\n", 
																											__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}

	/*
	 * Finally, register those parameters with the MAPI-V which when changed
	 * from the web GUI/ACS can affect the calls or the system
	 */
	if (IFX_CFG_CfgnParamsNtfnReg() != IFX_SUCCESS)
	{
		print_error("<%s:%d> : ERROR: IFX_CFG_CfgnParamsNtfnReg FAILED\n", 
																											__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}
	IFX_CFG_VLRegAndSub();
//	print_message("\n\n\n Gateway Application Is Up\n\n\n");
#endif

	/* 
	 * register the voice lines (if any) with the Registrar and also
	 * subscribe the voice lines with the voice mail server to
	 * receive notifications on new voice mail
	 */
#ifndef VOIP_NEWVMAPI
  IFX_CFG_SigHandlerInit();
#endif
	printf("\n\n\n Gateway Application Is Up\n\n\n");
	return IFX_SUCCESS;
}


/*******************************************************************************
* Function Name    : IFX_CFG_CMInit 
* Description      : This routine initiates call manager and registers callbacks
*                    for CFG agent.
* Input Values     : 
* Output Values    : None
* Return Value     : IFX_SUCCESS - If call manager is initialized and callbacks
*                         are registered
*                    IFX_FAILURE - On failure.
* Notes            :
*******************************************************************************/
e_IFX_Return
IFX_CFG_CMInit()
{
	char8	aszEndptId[1][IFX_MAX_ENDPOINTID_LEN] = {IFX_CFG_AGENT_ENDPT_ID};
	char8	uiNum = 1;
	x_IFX_CMGR_CallBackList	xCBList = {0};
	e_IFX_Return eRet = IFX_FAILURE; 

  printf("\n CM INIT\n");
	if (IFX_CMGR_Init(vcCMModId) != IFX_SUCCESS) {
    print_error("<%s:%d> : ERROR: IFX_CMGR_Init FAILED\n", 
																								__FUNCTION__,__LINE__);
	} else {
		
		xCBList.pfnRegisterRsp	= IFX_CFG_RegRespHdlr;
		xCBList.pfnVM_SubnRsp	= IFX_CFG_SubnRespHdlr;
		xCBList.pfnVM_NtfnRcv	= IFX_CFG_VMNotifyHdlr;
		
		/* register Configuration Agent's callback functions with Call Manager */
		if( IFX_SUCCESS != 
				(eRet=IFX_CMGR_CallBacksRegister(aszEndptId, uiNum, &xCBList)) ) {

			print_error("<%s:%d> : ERROR: Could Not Register Callbacks with CM\n", 
																									__FUNCTION__,__LINE__);
		}
#ifdef LTAM
	 	else if( IFX_SUCCESS != (eRet = IFX_MSGRTR_EventCallBackRegister(
												aszEndptId, uiNum,  IFX_CFG_MsgRouterEvtHdlr)) ) {
				
			print_error(
				"<%s:%d> : ERROR: Could Not Register Callbacks With Message Router\n",
				__FUNCTION__,__LINE__);
		}
#endif
    printf("\n EXIT SUCCESS CM INIT\n");
	}

	return eRet;
}


/*******************************************************************************
* Function Name    : IFX_CFG_DbgInit
* Description      : This function initialize debug module and creates debug 
*                    module IDs for all other modules.
* Input Values     : 
* Output Values    : None
* Return Value     : IFX_SUCCESS or IFX_FAILURE. 
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_DbgInit()
{
  //uchar8 ucDbgType=IFX_DBG_TYPE_CONSOLE, ucDbgLvl=IFX_DBG_LVL_HIGH;
	char8 cRetVal;
	x_IFX_VMAPI_SystemDebugSettings xDbg = {{{{""}}}};

  if( IFX_VMAPI_SUCCESS != ifx_get_DbgSettings(&xDbg,IFX_CIF_GET_FLAGS))
	{
    print_error("<%s:%d> : WARNING : Could Not Get DBG Settings \n", 
																								__FUNCTION__,__LINE__);
	}
	
	IFX_DBG_Init("FXO", xDbg.xAgentsDbg.ucDbgType, xDbg.xAgentsDbg.ucDbgLvl, 
		&vcFXOModId, &cRetVal);
	if (cRetVal != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR : Could Not Init Debugs for FXO Agent \n", 
																								__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}

	IFX_DBG_Init("FXS",xDbg.xAgentsDbg.ucDbgType, xDbg.xAgentsDbg.ucDbgLvl, 
		&vcFXSModId, &cRetVal);
	if (cRetVal != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR : Could Not Init Debugs for FXS Agent \n", 
																								__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}
	
	IFX_DBG_Init("CM", xDbg.xCmDbg.ucDbgType, xDbg.xCmDbg.ucDbgLvl, 
		&vcCMModId, &cRetVal);
	if (cRetVal != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR : Could Not Init Debugs for CM Agent \n",
																								__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}

	IFX_DBG_Init("MM", xDbg.xMmDbg.ucDbgType, xDbg.xMmDbg.ucDbgLvl, 
		&vcMMModId, &cRetVal);
	if (cRetVal != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR : Could Not Init Debugs for MM Agent \n",
																								__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}

	/* 
	 * If DialPlan module debugs are needed set debug type and level. This is not
	 * configurable 
	 */
#ifndef DEBUG_DIALPLAN
	IFX_DBG_Init("DialPlan", 0, 0, &vcDPModId, &cRetVal);
#else
	IFX_DBG_Init("DialPlan", xDbg.xAgentsDbg.ucDbgType, xDbg.xAgentsDbg.ucDbgLvl,
 							&vcDPModId, &cRetVal);
#endif
	if (cRetVal != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR : Could Not Init Debugs for DailPlan Agent\n",
																								__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
	IFX_DBG_Init("DECT", xDbg.xAgentsDbg.ucDbgType, 
			xDbg.xAgentsDbg.ucDbgLvl, &vcDECTModId, &cRetVal);
	if (cRetVal != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR : Could Not Init Debugs for DECT Agent \n", 
																								__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}
#endif

	return IFX_SUCCESS;
}


/*******************************************************************************
* Function Name    : IFX_CFG_CreateFifoForVmapiNtfy 
* Description      : This function creates FIFO to receive configuration 
*                    notification form MAPI-V.
* Input Values     : None
* Output Values    : None
* Return Value     : IFX_SUCCESS or IFX_FAILURE.
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_CreateFifoForVmapiNtfy()
{
	x_IFX_MSGRTR_FdInfo 	xFdInfo;
	uchar8								ucNum = 1;

	if( IFX_OS_CreateFifo((uchar8 *)IFX_IPC_VMAPI_FIFO) < 0 )
  {
    print_error("<%s:%d> : ERROR : Could Not Create IFX_IPC_VMAPI_FIFO FIFO\n",
																								__FUNCTION__,__LINE__);
		return IFX_FAILURE;
  }

  if( (viVmapiFifoFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_VMAPI_FIFO, O_RDWR)) < 0 )
  {
    print_error("<%s:%d> : ERROR : Could Not Create IFX_IPC_VMAPI_FIFO FIFO\n",
																								__FUNCTION__,__LINE__);
    return IFX_FAILURE;
  }

	/* register this fd with the Message Router */
	xFdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;
	xFdInfo.uiFd = viVmapiFifoFd;

	if( IFX_MSGRTR_FdCallBackRegister( &xFdInfo, ucNum, 
					IFX_CFG_VmapiNtfyHdlr ) != IFX_SUCCESS)
	{
    print_error("<%s:%d> : ERROR : IFX_MSGRTR_FdCallBackRegister FAILED\n",
																								__FUNCTION__,__LINE__);
		return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}


/*******************************************************************************
* Function Name    : IFX_CFG_TimerInit
* Description      : This function initializes timer module
* Input Values     : None
* Output Values    : None
* Return Value     : IFX_SUCCESS or IFX_FAILURE.
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_TimerInit()
{
	uint32	iFifoFd; /* This fd is not required elsewhere in this modoule */
	x_IFX_MSGRTR_FdInfo  xFdInfo;
	uchar8	ucNum =1;
  e_IFX_Return eRet;

	if ((eRet = IFX_TIM_Init(IFX_IPC_TIM_FIFO, &iFifoFd)) == IFX_SUCCESS)
	{
		/* register this fd with the Message Router */
		xFdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;
		xFdInfo.uiFd = iFifoFd;
                iDectSSTimerFd = iFifoFd;
		if ((eRet=IFX_MSGRTR_FdCallBackRegister( &xFdInfo, ucNum, 
					IFX_TIM_TimerMsgReceived)) != IFX_SUCCESS)
		{
    	print_error("<%s:%d> : ERROR : IFX_MSGRTR_FdCallBackRegister FAILED\n",
																								__FUNCTION__,__LINE__);
		}
	}
	else
	{
		print_error("<%s:%d> : ERROR : IFX_TIM_Init FAILED\n",
																								__FUNCTION__,__LINE__);
	}

	return eRet;
}


/*******************************************************************************
*  Function Name    : IFX_CFG_ReadFwFile
*  Description      : This function reads firmare file.
*  Input Values     : szFWFile - Firmware file name
*  Output Values    : ppucFwPram - pointer to buffer( to hold firmware)
*                     punBytes - Size of firmware
*  Return Value     : IFX_SUCCESS or IFX_FAILURE.
*  Notes            : If function returns IFX_SUCCESS, then free buffer pointed 
*                     by ppucFwPram.
*******************************************************************************/
e_IFX_Return IFX_CFG_ReadFwFile(
			IN	char8	*szFWFile, 
			OUT uchar8	**ppucFwPram, 
			OUT uint32	*punBytes)
{	
	int16		nFwFileFd = -1;
	struct stat xStat;
	int32 sz=0;

	if(stat(szFWFile, &xStat) < 0)
	{
		print_error("<%s:%d> : ERROR : Could Not stat %s\n",
														__FUNCTION__,__LINE__, szFWFile);
		return IFX_FAILURE;
	}
	
	nFwFileFd = IFX_OS_OpenFile(szFWFile, O_RDONLY);
	if (nFwFileFd < 0)
	{
		print_error("<%s:%d> : ERROR : Could Not Open %s\n",
														__FUNCTION__,__LINE__, szFWFile);
		return IFX_FAILURE;
	}

	*ppucFwPram = (uchar8 *)malloc(xStat.st_size);
	if (!*ppucFwPram)
	{
		print_error("<%s:%d> : ERROR : Could Not Allocate Memory\n",
														__FUNCTION__,__LINE__);
		IFX_OS_CloseFile( nFwFileFd );
		return IFX_FAILURE;
	}

	*punBytes = xStat.st_size;
	while(sz != xStat.st_size)
	{
		sz += read( nFwFileFd, (*ppucFwPram) + sz, xStat.st_size - sz);
	}    

	if (*punBytes != xStat.st_size)
	{
		print_error("<%s:%d> : ERROR : Mismatch In Size Of File Read\n",
														__FUNCTION__,__LINE__);
		free(*ppucFwPram);
		return IFX_FAILURE;
	}

	IFX_OS_CloseFile( nFwFileFd );
	return IFX_SUCCESS;
}
#ifdef SLIC121
e_IFX_Return IFX_CFG_FwFileExists(IN char8 *szFwFile,
                                  OUT uchar8 **ppucFwPram,
                                  OUT uint32 *punBytes){
	struct stat xStat;

	if(stat(szFwFile, &xStat) == 0)
	{
    /*File exists,Read Co-efficients*/
    return IFX_CFG_ReadFwFile(szFwFile,ppucFwPram,punBytes); 
	}else{
    /*File for Fxo does not exist*/
    return IFX_FAILURE;
   }
}
#endif
/******************************************************************
*  Function Name:  IFX_CFG_fgets 
*  Description  :  This function reads a line from a file in a 
*                  buffer and removes the newline character
*  Input Values :  Buffer,Readlength and the file descriptor.
*  Output Values:  Buffer
*  Return Value :  Size of the line 
*  Notes        :  
*********************************************************************/
STATIC int32  IFX_CFG_fgets(char8* pcBuff,int32 uiReadLen,int32 iFd)
{
  char8 /**pcRet,*/cBuf[1],*pcCurrPos;
  int32 iReadSize;
  pcCurrPos = pcBuff;
   
	while(1){
		iReadSize = read(iFd,cBuf,1);
		if(iReadSize == 0)
		{
			 //pcRet = NULL;
			 break;
		}
		if(cBuf[0] == '\r' )
		{
			iReadSize = read(iFd,cBuf,1);
			*pcCurrPos = '\0';
			break;
		}
		else if(cBuf[0] == '\n')
		{
			 *pcCurrPos = '\0';
			 break;
		}
		else
		{       
 			*pcCurrPos = cBuf[0];
			pcCurrPos++;
		}
   
	} //while
	/*if(iReadSize == 0)
    pcRet = NULL;
  else
     pcRet = pcBuff;*/
  
	return iReadSize;
}

/*******************************************************************************
*  Function Name: IFX_CFG_GetToneType
*  Description  : This function is used to convert tone string to tone constant
*  Input Values : pcTone - tone name
*  Output Values:  
*  Return Value : Returns one of the e_IFX_MMGR_ToneType 
*  Notes        :  
*******************************************************************************/
e_IFX_MMGR_ToneType  IFX_CFG_GetToneType(char8* pcTone)
{
  e_IFX_MMGR_ToneType eToneType = IFX_MMGR_MAX_TONE;
  
  if(strcmp(pcTone,"<DIAL_TONE>") == 0){
    eToneType = IFX_MMGR_DIAL_TONE;
  }
  if(strcmp(pcTone,"<BUSY_TONE>") == 0){
    eToneType =  IFX_MMGR_BUSY_TONE;
  }
  if(strcmp(pcTone,"<RING_BACK_TONE>") == 0){
    eToneType = IFX_MMGR_RING_BACK_TONE;
  }
  if(strcmp(pcTone,"<STUTTER_TONE>") == 0){
    eToneType = IFX_MMGR_STUTTER_DIAL_TONE;
  }
  if(strcmp(pcTone,"<CONF_TONE>") == 0){
    eToneType = IFX_MMGR_CONFIRMATION_TONE;
  }
  if(strcmp(pcTone,"<OFF_HOOK_WARNING_TONE>") == 0){
    eToneType =  IFX_MMGR_OFF_HOOK_WARNING_TONE;
  }
  if(strcmp(pcTone,"<ERROR_TONE>") == 0){
    eToneType = IFX_MMGR_ERROR_TONE;
  }
  if(strcmp(pcTone,"<PROMPT_TONE>") == 0){
    eToneType =  IFX_MMGR_PROMPT_TONE;
  }
  if(strcmp(pcTone,"<RING_TONE>") == 0){
    eToneType = IFX_MMGR_RING_TONE;
  }
  if(strcmp(pcTone,"<CALL_WAITING_TONE>") == 0){
    eToneType = IFX_MMGR_CALL_WAITING_TONE;
  }
  if(strcmp(pcTone,"<SECOND_TONE>") == 0){
    eToneType =  IFX_MMGR_SEC_DIAL_TONE;
  }                  
  return eToneType;
}

/******************************************************************
*  Function Name:  IFX_CFG_strtok
*  Description  :  Checks for occurance of any of the tokens in the 
*                  token list, and returns the same on finding. 
*  Input Values :  Start and end indices, tokens to check out for
*  Output Values:  Matched location
*  Return Value :  Matched Token
*  Notes        :  This function checks for the presence of the tokens
*                  on matching returns the token matched 
*********************************************************************/
STATIC char8 IFX_CFG_strtok(char8* pcStarIndex,
                  char8* pcEndIndex,
                  char8** pcMatchedLocation,
                  char8* pcToken
                  )
{
  uint32 uiCount,uiTokenLen;
  char8* pcCurrPos = pcStarIndex;
  uiTokenLen = strlen(pcToken);
  while(pcCurrPos <= pcEndIndex)
  {
    for(uiCount=0;uiCount < uiTokenLen;uiCount++)
    {
      if(*pcCurrPos == pcToken[uiCount])
      {
        *pcMatchedLocation = pcCurrPos;
        return pcToken[uiCount];
      }
    }
    pcCurrPos++;
  }
  return IFX_FAILURE;
}

/******************************************************************
*  Function Name:  IFX_CFG_strchr
*  Description  :  checks for a delimiter and returns ptr to first
*                  occurance
*  Input Values :  Two character pointers and the character to compare with
*  Output Values:  None
*  Return Value :  pointer the character if found or NULL.
*  Notes        :  
*********************************************************************/
STATIC char8* IFX_CFG_strchr(char8* pcStartIndex,
                   char8* pcEndIndex,
                   char8 cMatch
                   )
{
  //char8 cTemp;
  //cTemp = *pcEndIndex;
  while(pcStartIndex <= pcEndIndex)
  {
    if(*pcStartIndex == cMatch)
    {
      return pcStartIndex;
    }
    pcStartIndex++;
  }
  return NULL;
}
/******************************************************************
*  Function Name:  IFX_CFG_ParseFreqAndGainVal
*  Description  :  Parses the Frequency and gain values 
*  Input Values :  Start and end indeces of the character sequence 
*                  pointer to the  
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/
STATIC int32 IFX_CFG_ParseFreqAndGainVal(char8* pcStartIndex,
                          char8* pcEndIndex,
                          x_IFX_MMGR_FreqGain *pxFreqGain
                        )
{
  char8 *pcCurrPos,*pcDelim,*pcFreqVal,cTemp;
  pcCurrPos = pcStartIndex;
  while(*pcStartIndex == ' ')
  {
    pcStartIndex++;
  }
  pcDelim = IFX_CFG_strchr(pcStartIndex,pcEndIndex,',');
  if(pcDelim == NULL)
  {
    return IFX_FAILURE ;
  }
  pcCurrPos = IFX_CFG_strchr(pcStartIndex,pcDelim-1,'=');
  if(pcCurrPos == NULL)
  {
    return IFX_FAILURE ;
  }
  pcFreqVal = pcCurrPos + 1;
  /* Copy the Frequency name if required */
  *pcCurrPos = '\0';
  strcpy(pxFreqGain->szFreqName,pcStartIndex);
  *pcCurrPos = '=';
  *pcDelim = '\0';
  sscanf(pcFreqVal,"%d",&pxFreqGain->uiFrequency);
  *pcDelim = ',';
  pcCurrPos = IFX_CFG_strchr(pcDelim+1,pcEndIndex,'=');
  if(pcCurrPos == NULL)
  {
    return IFX_FAILURE;
  }
  cTemp = *(pcEndIndex + 1);
  *(pcEndIndex + 1) = '\0';
  sscanf(pcCurrPos+1,"%d",&pxFreqGain->iGain);
  *(pcEndIndex + 1) = cTemp;
  return IFX_SUCCESS ;
}
/******************************************************************
*  Function Name:  IFX_CFG_GetFreqIndex
*  Description  :  checks for a delimiter and returns ptr to first
*                  occurance
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/
STATIC int32 IFX_CFG_GetFreqIndex(char8 *pcFreqName,
                   x_IFX_MMGR_Tone *pxTone
                   )
{
  int32 iIndex;
  for(iIndex=0;iIndex < pxTone->ucNoOfFreqComp;iIndex++)
  {
    if(strcmp(pcFreqName,pxTone->xFrequencies[iIndex].szFreqName) == 0)
    {
      return iIndex;
    }
  }
  return IFX_FAILURE;
}


/********************************************************************
*  Function Name:  IFX_CFG_ParseFrequencies
*  Description  :  checks for a delimiter and returns ptr to first
*                  occurance
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/
STATIC int32 IFX_CFG_ParseFrequencies(char8* pcBuff,
                       x_IFX_MMGR_Tone* pxTone
                      )
{
  char8 cRet,*pcMatchedLoc,*pcStartPos,*pcEndPos;
  int32 iNoOfFreq = 0,iRetVal=0;

  pcEndPos = pcBuff + strlen(pcBuff) -1 ;
  cRet = IFX_CFG_strtok(pcBuff,pcEndPos,&pcMatchedLoc,";\0");
  if(cRet == IFX_FAILURE){
    return IFX_FAILURE;
  }
  pcStartPos = pcBuff;
  while(cRet != IFX_FAILURE){ 
      iRetVal = IFX_CFG_ParseFreqAndGainVal(pcStartPos,
							 pcMatchedLoc -1 ,&pxTone->xFrequencies[iNoOfFreq]);
      if(iRetVal < 0)
      {
        return IFX_FAILURE;
      }
      pcStartPos = pcMatchedLoc + 1;
      cRet = IFX_CFG_strtok(pcStartPos,pcEndPos,&pcMatchedLoc,";\0");
      iNoOfFreq++;
  }
  pxTone->ucNoOfFreqComp = iNoOfFreq;
  return IFX_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_CFG_ParseCadencePattern
*  Description  :  checks for a delimiter and returns ptr to first
*                  occurance
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/
STATIC int32 IFX_CFG_ParseCadencePattern(char8 *pcStartIndex,
                          char8 *pcEndIndex,
                          x_IFX_MMGR_Tone *pxTone,
                          int32 iCadenceCount
                         )
{
  char8 *pcCurrPos,*pcDelim,cTemp,cRet;
  int32 iFreqIndex;
  pcCurrPos = pcStartIndex;
  while(*pcStartIndex == ' ')
  {
    pcStartIndex++;
  }
  pcDelim = IFX_CFG_strchr(pcStartIndex,pcEndIndex,',');
  if(pcDelim == NULL)
  {
    return IFX_FAILURE ;
  }
  pcCurrPos = IFX_CFG_strchr(pcStartIndex,pcDelim-1,'=');
  if(pcCurrPos == NULL)
  {
    return IFX_FAILURE;
  }
  *pcDelim = '\0';
  sscanf(pcCurrPos + 1,"%d",&pxTone->uiCadenceduration[iCadenceCount]);
  *pcDelim = ',';
  pcCurrPos = IFX_CFG_strchr(pcDelim+1,pcEndIndex,'=');
  if(pcCurrPos == NULL)
  {
    return IFX_FAILURE;
  }
  pcCurrPos++;
  while(*pcCurrPos == ' ')
  {
    pcCurrPos++;
  }
  while(pcCurrPos <= pcEndIndex)
  {
    cRet = IFX_CFG_strtok(pcCurrPos,pcEndIndex,&pcDelim,"+;,");
    cTemp = *pcDelim;
    *pcDelim = '\0';
    if(strcmp(pcCurrPos,"off"))
    {
      iFreqIndex = IFX_CFG_GetFreqIndex(pcCurrPos,pxTone);
      pxTone->uiCadencePattern[iCadenceCount] |= 1 << iFreqIndex;
    }
    *pcDelim = cTemp;
    if(cRet == ',')
    {
      if(*(pcDelim + 3) == '1')
      {
        pxTone->uiCadencePattern[iCadenceCount] |= 1 << 5;
        break;
      }
    }
    pcCurrPos = pcDelim + 1;
  }
  return IFX_SUCCESS;
}
/******************************************************************
*  Function Name:  IFX_CFG_ParseCadence
*  Description  :  checks for a delimiter and returns ptr to first
*                  occurance
*  Input Values :  Two strings and the number of bytes to compare
*  Output Values:  None
*  Return Value :  0 on success
*  Notes        :  
*********************************************************************/
STATIC int32 IFX_CFG_ParseCadence(char8* pcBuff,
                   x_IFX_MMGR_Tone *pxTone
                   )
{
  char8 cRet,*pcStartPos,*pcEndPos,*pcMatchedLoc;
  int32 iNoOfCadences = 0;
  pcStartPos = pcBuff;
  pcEndPos = pcBuff + strlen(pcBuff) -1;
  cRet = IFX_CFG_strtok(pcBuff,pcEndPos,&pcMatchedLoc,";");
  if(cRet == IFX_FAILURE)
  {
    return IFX_FAILURE;
  }
  while(cRet != IFX_FAILURE)
  {
    if(IFX_CFG_ParseCadencePattern(pcStartPos,pcMatchedLoc,pxTone,iNoOfCadences) == -1)
    {
      return IFX_FAILURE;
    }
    pcStartPos = pcMatchedLoc + 1;
    cRet = IFX_CFG_strtok(pcStartPos,pcEndPos,&pcMatchedLoc,";");
    iNoOfCadences++;
  }
  pxTone->uiNoOfCadences = iNoOfCadences;
  return 0;
}
/********************************************************************
*  Function Name    : IFX_CFG_GetContrySpecificSettings
*  Description      : This Function updates the country specific parameters
*  Input Values     : Country name
*  Output Values    : None
*  Return Value     : IFX_APP__SUCC,IFX_FAILURE
*  Notes            :
*********************************************************************/
e_IFX_Return
IFX_CFG_GetCountrySpecificSettings(IN char8* pcCountryFileName,
				OUT x_IFX_MMGR_CountrySettingsParams *pxCountrySettingsParams)
{
	/* int32 iChCount; 
	uint32 uiCount; */
	int32 iFd;
	char8 cBuffer[IFX_MAX_BUFF_SIZE],*pcCurrPos;
	e_IFX_MMGR_ToneType eToneType=IFX_MMGR_MAX_TONE;
	int32 iNoOfTones=0;
	
	x_IFX_MMGR_CountrySettingsParams stxCountrySettingsParams;
	memset(&stxCountrySettingsParams,0,sizeof(x_IFX_MMGR_CountrySettingsParams));

	iFd = open(pcCountryFileName,O_RDONLY);
	if(iFd < 0)
	{
    print_error("<%s:%d>  ERROR : Could Not Open CountrySetting File\n", 
																										__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
		
	while(IFX_CFG_fgets((char*)cBuffer,IFX_MAX_BUFF_SIZE,iFd) )
	{ 
		if( strcmp(cBuffer,"<TONE>") == 0 )
		{
			do
			{
				IFX_CFG_fgets((char*)cBuffer,IFX_MAX_BUFF_SIZE,iFd);
				if(cBuffer[0] == '<')
				{
					if(cBuffer[1] != '/')
					{        
						eToneType = IFX_CFG_GetToneType(cBuffer);
						stxCountrySettingsParams.axTones[eToneType].eToneType = eToneType;
					}          
				}
				else
				{
					int32 iLoop;
					IFX_CFG_ParseFrequencies((char*)&cBuffer, &stxCountrySettingsParams.axTones[eToneType]);
					IFX_CFG_fgets((char*)&cBuffer,IFX_MAX_BUFF_SIZE,iFd);
					IFX_CFG_ParseCadence(cBuffer,&stxCountrySettingsParams.axTones[eToneType]);
					IFX_CFG_fgets((char*)&cBuffer,IFX_MAX_BUFF_SIZE,iFd);
					pcCurrPos = cBuffer;

					while(*pcCurrPos != '=')
						pcCurrPos++;

					pcCurrPos++;
					sscanf(pcCurrPos,"%d",&iLoop);
					stxCountrySettingsParams.axTones[eToneType].ucLoop = iLoop;
					while(*pcCurrPos != '=')
						pcCurrPos++;
					pcCurrPos++;
					sscanf(pcCurrPos,"%d",&stxCountrySettingsParams.axTones[eToneType].uiPause);	
					iNoOfTones++;
				}
	 		}while(strcmp(cBuffer,"</TONE>"));
      
			stxCountrySettingsParams.unNoOfTones = iNoOfTones;
			IFX_CFG_fgets((char*)&cBuffer,IFX_MAX_BUFF_SIZE,iFd);
		} //<TONE>
  
		if(strcmp(cBuffer,"<HOOK_TIME>") == 0)
		{
			do
			{
				IFX_CFG_fgets((char8*)&cBuffer,IFX_MAX_BUFF_SIZE,iFd);
				if(strcmp(cBuffer,"<ON_HOOK>") == 0)
				{
					IFX_CFG_fgets((char8*)&cBuffer,IFX_MAX_BUFF_SIZE,iFd);
					pcCurrPos = cBuffer;
					while(*pcCurrPos != '=')
						pcCurrPos++;
					pcCurrPos++;			
					sscanf(pcCurrPos,"%d",&stxCountrySettingsParams.uiOnHookMaxDuration);
					if(stxCountrySettingsParams.uiOnHookMaxDuration == 0){
						close(iFd);
						return IFX_FAILURE;
					}
					while(*pcCurrPos != '=')
						pcCurrPos++;
					pcCurrPos++;
			
					sscanf(pcCurrPos,"%d",&stxCountrySettingsParams.uiOnHookMinDuration);
					if(stxCountrySettingsParams.uiOnHookMaxDuration == 0){
						close(iFd);
						return IFX_FAILURE;
					}
				}
			
				if(strcmp(cBuffer,"<OFF_HOOK>") == 0)
				{
					IFX_CFG_fgets((char8*)&cBuffer,IFX_MAX_BUFF_SIZE,iFd);
					pcCurrPos = cBuffer;
					while(*pcCurrPos != '=')
						pcCurrPos++;
					pcCurrPos++;
					sscanf(pcCurrPos,"%d",&stxCountrySettingsParams.uiOffHookMaxDuration);
					if(stxCountrySettingsParams.uiOnHookMaxDuration == 0){
						close(iFd);
						return IFX_FAILURE;
					}

					while(*pcCurrPos != '=')
						pcCurrPos++;
			
					pcCurrPos++;
					sscanf(pcCurrPos,"%d",&stxCountrySettingsParams.uiOffHookMinDuration);
					if(stxCountrySettingsParams.uiOffHookMinDuration == 0){
						close(iFd);
						return IFX_FAILURE;
					}
				}
			
				if(strcmp(cBuffer,"<HOOK_FLASH>") == 0)
				{
					IFX_CFG_fgets((char8*)&cBuffer,IFX_MAX_BUFF_SIZE,iFd);
					pcCurrPos = cBuffer;
					while(*pcCurrPos != '=')
						pcCurrPos++;
			
					pcCurrPos++;
					sscanf(pcCurrPos,"%d",&stxCountrySettingsParams.uiHookFlashMaxDuration);
					if(stxCountrySettingsParams.uiHookFlashMaxDuration == 0)	{
						close(iFd);
						return IFX_FAILURE;
					}
					while(*pcCurrPos != '=')
						pcCurrPos++;
					pcCurrPos++;
			
					sscanf(pcCurrPos,"%d",&stxCountrySettingsParams.uiHookFlashMinDuration);
					if(stxCountrySettingsParams.uiHookFlashMinDuration == 0){
						close(iFd);
						return IFX_FAILURE;
					}
				}
      	
			}while(strcmp(cBuffer,"</HOOK_TIME>"));
    	
		} //<HOOK_TIME>
  	
	} //while
  
	close(iFd);
  memcpy(pxCountrySettingsParams,&stxCountrySettingsParams,sizeof(x_IFX_MMGR_CountrySettingsParams));
  return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CFG_MMInit
* Description      : This function initializes Media Manager.
* Input Values     : None
* Output Values    : None
* Return Value     : If media manager is initialized, returns IFX_SUCCESS, else
*                    returns IFX_FAILURE.
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_MMInit()
{
	x_IFX_MMGR_InitParams			xParams;
	x_IFX_MMGR_FXS_ResourceInfo		axFxsResourceInfo[IFX_MMGR_MAX_FXS_CHANNELS];
	x_IFX_MMGR_FXO_ResourceInfo		axFxoResourceInfo[IFX_MMGR_MAX_FXO_CHANNELS];

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
	x_IFX_MMGR_DECT_ResourceInfo	axDectResourceInfo[IFX_MMGR_MAX_DECT_CHANNELS];
#endif
	x_IFX_MMGR_Coder_ResourceInfo	axCoderInfo[IFX_MMGR_MAX_CODER_CHANNELS];
	e_IFX_ReasonCode				eReason;
	x_IFX_CIF_FxResourceInfo		xResourceInfo;
	x_IFX_MMGR_FdSet				xFdSet;

	char8	szCountryName[10];
	char8	szFilePath[100];
	char8	aszEndptIdList[IFX_MAX_ENDPTS][IFX_MAX_ENDPOINTID_LEN];
	uchar8	ucNumEndpts;
	char8	aszDeviceList[IFX_MAX_DEVICES][IFX_MAX_DEV_STR_LEN];	
	int32	iCnt=0;
#ifdef SLIC121
  int32 iSuffixPos = 0;
#endif
	print_error(" In %s\n",__FUNCTION__);
  
	/* memset the structures that needs to be passed to MMgr */
	memset(&xParams, 0, sizeof(x_IFX_MMGR_InitParams));
	memset(&xFdSet, 0, sizeof(x_IFX_MMGR_FdSet));
  memset(&xResourceInfo,0,sizeof(x_IFX_CIF_FxResourceInfo));
  memset(axFxsResourceInfo,0,
							sizeof(x_IFX_MMGR_FXS_ResourceInfo)*IFX_MMGR_MAX_FXS_CHANNELS);
  memset(axFxoResourceInfo,0,
							sizeof(x_IFX_MMGR_FXO_ResourceInfo)*IFX_MMGR_MAX_FXO_CHANNELS);
#if defined( DECT_SUPPORT) || defined(CVOIP_SUPPORT)
  memset(axDectResourceInfo,0,
							sizeof(x_IFX_MMGR_DECT_ResourceInfo)*IFX_MMGR_MAX_DECT_CHANNELS);
#endif
  memset(axCoderInfo,0,sizeof(x_IFX_MMGR_Coder_ResourceInfo)*IFX_MMGR_MAX_CODER_CHANNELS);
	
	printf("\n\n\n Entering MMGR Init Init\n\n\n");
	/* get the device names from MAPI-V */
	if( IFX_SUCCESS != 
		  IFX_CIF_DeviceListGet(IFX_MAX_DEVICES_IN_VMAPI, aszDeviceList, &eReason))
	{
    print_error("<%s:%d>  IFX_CIF_DeviceListGet FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	
	/* fill xDSP Device Info */
	strcpy(xParams.xDSPDevice.szDeviceName, aszDeviceList[IFX_DSP_DEVICE_POS]);

	/* fill FXO Device Info */
	strcpy(xParams.xFXODevice.szDeviceName, aszDeviceList[IFX_FXO_DEVICE_POS]);	
	xParams.xFXODevice.uxDevParams.xFxoParam.ucIrqNum = IFX_MMGR_FXODEV_IRQNUM;
  xParams.xFXODevice.uxDevParams.xFxoParam.iAccessMode = IFX_MMGR_FXODEV_ACCESSMODE;
	
/* ============================================================================== */
	/* fill FXS information */
	xParams.xFxsRes.unNoOfFxsResources = IFX_MMGR_MAX_FXS_CHANNELS;
	xParams.xFxsRes.pxFxsInfo = &axFxsResourceInfo[0];

	/* get FXS endpoint ids from MAPI-V */
  ucNumEndpts = IFX_MMGR_MAX_FXS_CHANNELS;
	printf("\n\n Getting Endpoint List\n\n\n");
	if(IFX_SUCCESS != IFX_CIF_FxsEndptListGet(&ucNumEndpts, aszEndptIdList,
											&eReason))
	{
    print_error("<%s:%d>  ERROR : IFX_CIF_FxsEndptListGet FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	printf("\n\n Fx Getting Endpoint List\n\n\n");
	for(iCnt = 0; iCnt < ucNumEndpts && iCnt < IFX_MMGR_MAX_FXS_CHANNELS; iCnt++)
	{
		/* Get resource info from MAPI-V */
		if(IFX_SUCCESS !=  IFX_CIF_FxEndptResInfoGet(aszEndptIdList[iCnt],
													&xResourceInfo, &eReason))
		{
    	print_error("<%s:%d> ERROR : IFX_CIF_FxEndptResInfoGet FAILED\n", 
																								__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
    
		strcpy(axFxsResourceInfo[iCnt].szEndPtId, aszEndptIdList[iCnt]);
		strcpy(axFxsResourceInfo[iCnt].szChannelName, xResourceInfo.szChannelName);

		axFxsResourceInfo[iCnt].iInterfaceId  = 
											xResourceInfo.iInterfaceId;
		axFxsResourceInfo[iCnt].bIsWideBandEnabled  = 
											xResourceInfo.bIsWideBandEnabled;		
		axFxsResourceInfo[iCnt].bIsLecEnabled  = 
											xResourceInfo.bIsLecEnabled;
		axFxsResourceInfo[iCnt].cLecTailLength  = 
											xResourceInfo.cLecTailLength;
		axFxsResourceInfo[iCnt].unChannelNum  = 
											iCnt;
	}
	
	printf("\n\n Fx Country name get\n\n\n");
  /* 
	 * get cram coefficients from file. For this we need country name,
	 * country path and cram file name
	 */
	if(IFX_SUCCESS != IFX_CIF_CountryNameGet(szCountryName))
	{
    	
		print_error("<%s:%d> ERROR : IFX_CIF_CountryNameGet FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	strcpy(szFilePath, IFX_MMGR_FIRMWARE_PATH);
	//strcat(szFilePath, szCountryName);
	strcat(szFilePath, "/");
	strcat(szFilePath, IFX_MMGR_FXS_CRAM_FILE_NAME);
	printf("The PATH is %s\n",szFilePath);	
	if(IFX_CFG_ReadFwFile(szFilePath, &(xParams.xFxsRes.pucCoeffcient),
		(uint32 *)	&xParams.xFxsRes.iCoefficientSize) == IFX_FAILURE)
	
	{
		print_error("<%s:%d> ERROR : IFX_CFG_ReadFwFile FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

/* ============================================================================== */
#ifdef ENABLE_FXO
	if(IFX_SUCCESS==IFX_CIF_FxoEnableGet()){
		vbFxoEnable=1;
	}else{
		vbFxoEnable=0;
	}

if(vbFxoEnable){	
	printf("\n\n Fx0 init\n\n\n");
#ifdef SLIC121
  /*get CRAM co-efficients from FXS file*/
  iCnt = strlen(szFilePath);
  iSuffixPos = iCnt - strlen(TD_BBD_SUFIX_FXS);

  if ((iSuffixPos < 0) || (iCnt <= iSuffixPos)){
    /*Incorrect Suffix Pos*/
    return IFX_FAILURE;
  }else if(0 == strncmp(&szFilePath[iSuffixPos],TD_BBD_SUFIX_FXS,strlen(TD_BBD_SUFIX_FXS))){

    /*Suffix is fxs.bin*/
    if(strlen(TD_BBD_SUFIX_FXS) == strlen(TD_BBD_SUFIX_FXO)){

      /*Fxs And Fxo Suffixes are of same length*/
      strncpy(&szFilePath[iSuffixPos],TD_BBD_SUFIX_FXO,strlen(TD_BBD_SUFIX_FXO));
      if(IFX_FAILURE == IFX_CFG_FwFileExists(szFilePath, &(xParams.xFxoRes.pucCoefficient),
                         (uint32 *) &xParams.xFxoRes.iCoefficientSize)){ 

        /*No File with fxo suffix,taking Fxs Coefficients*/
        strncpy(&szFilePath[iSuffixPos],TD_BBD_SUFIX_FXS,strlen(TD_BBD_SUFIX_FXS));
        if(IFX_CFG_ReadFwFile(szFilePath, &(xParams.xFxoRes.pucCoefficient),
           (uint32 *)  &xParams.xFxoRes.iCoefficientSize) == IFX_FAILURE){
           print_error("<%s:%d> ERROR : IFX_CFG_ReadFwFile FAILED\n",__FUNCTION__, __LINE__);
           return IFX_FAILURE;
        }
      }
    }else{

      /*Fxs and Fxo files have different suffixes,using Fxs Co-efficients*/
      xParams.xFxoRes.pucCoefficient = xParams.xFxsRes.pucCoeffcient;
      xParams.xFxoRes.iCoefficientSize = xParams.xFxsRes.iCoefficientSize;
     } 
   }else{

     /*Improper file suffix*/
     return IFX_FAILURE;
    }
#endif

	/* fill FXO information */	
	xParams.xFxoRes.unNoOfFxoResources = IFX_MMGR_MAX_FXO_CHANNELS;
	xParams.xFxoRes.pxFxoInfo = &axFxoResourceInfo[0];

	/* get the FXO endpoint ids available in MAPI-V */
    ucNumEndpts = IFX_MMGR_MAX_FXO_CHANNELS;
	if(IFX_SUCCESS != IFX_CIF_FxoEndptListGet(&ucNumEndpts, aszEndptIdList,
											 &eReason))
	{
		print_error("<%s:%d> ERROR : IFX_CIF_FxoEndptListGet FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
  
  
	for(iCnt = 0; iCnt < ucNumEndpts && iCnt < IFX_MMGR_MAX_FXO_CHANNELS; iCnt++)
	{
		/* Get resource info from MAPI-V */
		if(IFX_SUCCESS != IFX_CIF_FxEndptResInfoGet(aszEndptIdList[iCnt],
												&xResourceInfo,&eReason))
		{
			print_error("<%s:%d> ERROR : IFX_CIF_FxEndptResInfoGet FAILED\n", 
																								__FUNCTION__, __LINE__);
			free(xParams.xFxsRes.pucCoeffcient);
			xParams.xFxsRes.pucCoeffcient = NULL;
			return IFX_FAILURE;
		}

		strcpy(axFxoResourceInfo[iCnt].szEndPtId, 
											aszEndptIdList[iCnt]);
		strcpy(axFxoResourceInfo[iCnt].szChannelName, 
											xResourceInfo.szChannelName);
		axFxoResourceInfo[iCnt].iInterfaceId  = 
											xResourceInfo.iInterfaceId;
		axFxoResourceInfo[iCnt].bIsLecEnabled = 
											xResourceInfo.bIsLecEnabled;
		axFxoResourceInfo[iCnt].ucLecTailLength = 
											xResourceInfo.cLecTailLength;
#ifndef SLIC121
		axFxoResourceInfo[iCnt].unChannelNum = iCnt;
#else
		axFxoResourceInfo[iCnt].unChannelNum = 
                     IFX_MMGR_MAX_FXS_CHANNELS;
#endif
		axFxoResourceInfo[iCnt].unPcmChannelNum = 
											IFX_MMGR_PCM_CHANNEL_NUM;
		strcpy(axFxoResourceInfo[iCnt].szPcmChannelName, 
											IFX_MMGR_PCM_CHANNEL_NAME);
	}
}
#endif//ENABLE_FXO

#if defined( DECT_SUPPORT) || defined(CVOIP_SUPPORT)
	xParams.xDectRes.unNoOfDectResources = IFX_MMGR_MAX_DECT_CHANNELS;
	xParams.xDectRes.pxDectInfo= axDectResourceInfo;

	/* get the FXO endpoint ids available in MAPI-V */
   ucNumEndpts = IFX_MMGR_MAX_DECT_CHANNELS;
	if(IFX_SUCCESS != IFX_CIF_DectEndptListGet(&ucNumEndpts, aszEndptIdList,
											 &eReason))
	{
			
		print_error("<%s:%d> ERROR : IFX_CIF_DectEndptListGet FAILED\n", 
																								__FUNCTION__, __LINE__);
			free(xParams.xFxsRes.pucCoeffcient);
			xParams.xFxsRes.pucCoeffcient = NULL;
		return IFX_FAILURE;
	}
 
	for(iCnt = 0; iCnt < ucNumEndpts && iCnt < IFX_MMGR_MAX_DECT_CHANNELS; iCnt++)
	{
		/* Get resource info from MAPI-V */
		if(IFX_SUCCESS != IFX_CIF_FxEndptResInfoGet(aszEndptIdList[iCnt],
												&xResourceInfo,&eReason))
		{
			print_error("<%s:%d> ERROR : IFX_CIF_FxEndptResInfoGet FAILED\n", 
																								__FUNCTION__, __LINE__);
			free(xParams.xFxsRes.pucCoeffcient);
			xParams.xFxsRes.pucCoeffcient = NULL;
			return IFX_FAILURE;
		}

		strcpy(axDectResourceInfo[iCnt].szChannelName, xResourceInfo.szChannelName);
		axDectResourceInfo[iCnt].iInterfaceId  = xResourceInfo.iInterfaceId;
		axDectResourceInfo[iCnt].unChannelNum = iCnt;
	}
#endif	
	/* 
	 * get cram coefficients from file. For this we need country name,
	 * country path and cram file name
	 */
#if 0 /* TBD */
	strcpy(szFilePath, IFX_MMGR_COUNTRYSETTINGS_PATH);
	strcat(szFilePath, szCountryName);
	strcat(szFilePath, "/");
	strcat(szFilePath, IFX_MMGR_FXO_CRAM_FILE_NAME);
		
	/* get fxo CRAM coefficients */
	if(IFX_CFG_ReadFwFile(szFilePath, &(xParams.xFxoRes.pucCoefficient),
			(uint16*)&(xParams.xFxoRes.iCoefficientSize)) == IFX_FAILURE)
	{
		return IFX_FAILURE;
	}
#endif

/* ============================================================================== */
	
	/* fill Coder Info */
	xParams.xCoderRes.unNoOfCoderResources = IFX_MMGR_MAX_CODER_CHANNELS;
	xParams.xCoderRes.pxCoderInfo = axCoderInfo;

	strcpy(szFilePath, IFX_MMGR_FIRMWARE_PATH);
	strcat(szFilePath, IFX_MMGR_PRAM_FILE_NAME);
	
	/* get the pram firmware */
	if(IFX_CFG_ReadFwFile(szFilePath, &(xParams.xCoderRes.pucFw) ,
				(uint32 *)&xParams.xCoderRes.iFWSize) == IFX_FAILURE)
	{
			
		print_error("<%s:%d> ERROR : IFX_CFG_ReadFwFile FAILED\n", 
																								__FUNCTION__, __LINE__);
		free(xParams.xFxsRes.pucCoeffcient);
		xParams.xFxsRes.pucCoeffcient = NULL;
		return IFX_FAILURE;
	}

	for(iCnt = 0; iCnt < IFX_MMGR_MAX_CODER_CHANNELS; iCnt++)
	{
		strcpy(axCoderInfo[iCnt].szChannelName, aszDeviceList[iCnt]);
		axCoderInfo[iCnt].unChannelNum = iCnt;
	}

    xParams.xCoderRes.iCoefficientSize=xParams.xFxsRes.iCoefficientSize;
    xParams.xCoderRes.pucCoeffcient=xParams.xFxsRes.pucCoeffcient;
/* ============================================================================== */
 	
	/* get country specific settings */
	
    strcpy(szFilePath, IFX_MMGR_COUNTRYSETTINGS_PATH);
	strcat(szFilePath, szCountryName);
	strcat(szFilePath, "/");
	strcat(szFilePath, IFX_COUNTRYSETTINGS_FILENAME);
	
  if(IFX_FAILURE == IFX_CFG_GetCountrySpecificSettings(szFilePath,
													&(xParams.xSettingparams)))
	{
		print_error("<%s:%d> ERROR : IFX_CFG_GetCountrySpecificSettings FAILED\n", 
																								__FUNCTION__, __LINE__);
		free(xParams.xFxsRes.pucCoeffcient);
		xParams.xFxsRes.pucCoeffcient = NULL;
		free(xParams.xCoderRes.pucFw);
		xParams.xCoderRes.pucFw = NULL;
		return IFX_FAILURE;
	}

	/* Update the CID standard */

	if(!strcmp(szCountryName,IFX_MMGR_COUNTRY_USA))
		xParams.xSettingparams.eCidStd = IFX_MMGR_CID_STD_TELCORDIA;
	else if(!strcmp(szCountryName,IFX_MMGR_COUNTRY_JAPAN))
		xParams.xSettingparams.eCidStd = IFX_MMGR_CID_STD_NTT;
	else if(!strcmp(szCountryName,IFX_MMGR_COUNTRY_TAIWAN))
		xParams.xSettingparams.eCidStd = IFX_MMGR_CID_STD_TELCORDIA;
	else if(!strcmp(szCountryName,IFX_MMGR_COUNTRY_CHINA))
		xParams.xSettingparams.eCidStd = IFX_MMGR_CID_STD_TELCORDIA;
	else
		xParams.xSettingparams.eCidStd = IFX_MMGR_CID_STD_ETSI;

/* ============================================================================== */
	
	printf("\n\n calling MMGR Init\n\n\n");
	/* Do MM Init now */
	if(IFX_SUCCESS != IFX_MMGR_Init(&xParams, vcMMModId, &xFdSet))
	{
		print_error("<%s:%d> ERROR : IFX_MMGR_Init FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
#ifdef VOIP_NEWVMAPI
  	IFX_CFG_SetFwSupportedCodec();
#endif
	/*
	 * Register voice dsp device fd and the duslic device fd with the Message
	 * Router
	 */
	for (iCnt=0; iCnt < xFdSet.ucNoOfFds; iCnt++)
	{
		x_IFX_MSGRTR_FdInfo		xFdInfo;
		uchar8					ucNum = 1;

		xFdInfo.uiFd = xFdSet.aiFd[iCnt];
		xFdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;

		if (IFX_MSGRTR_FdCallBackRegister(&xFdInfo, ucNum,
						IFX_MSGRTR_HandleTapiEvents) != IFX_SUCCESS)
		{
			print_error("<%s:%d> ERROR : IFX_MSGRTR_FdCallBackRegister FAILED\n", 
																								__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
	}

	/*Free the allocated memory**/
	free(xParams.xFxsRes.pucFw);
	free(xParams.xFxsRes.pucCoeffcient);
  if(xParams.xFxsRes.pucCoeffcient != xParams.xFxoRes.pucCoefficient)
	 free(xParams.xFxoRes.pucCoefficient);	
  xParams.xFxsRes.pucCoeffcient = NULL;
  xParams.xFxoRes.pucCoefficient = NULL;
	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CFG_AgentsInit
* Description      : This function initialises all agents. 
* Input Values     : None 
* Output Values    : None
* Return Value     : IFX_SUCCESS - If all agents are initialized.
*                    IFX_FAILURE - On failure.
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_AgentsInit()
{
	char8	aszEndptIdList[IFX_MAX_ENDPTS][IFX_MAX_ENDPOINTID_LEN];
	//uchar8 ucDbgType=0, ucDbgLvl=0;
	uchar8  ucNumEndpts;
	uchar8	aucProfileId[IFX_MAX_PROFILES] = {0};
	x_IFX_VMAPI_SystemDebugSettings xDbg = {{{{""}}}};
  e_IFX_ReasonCode eReason;
	
	//TO DO: Get debug info from VMAPI
	/*
	 * Following agents: FXS, FXO, DECT, SIP, RTP and FAX are to be inited 
	 * We need to get their endpoint ids from MAPI-V and
	 * initialise them.
	 */
#ifndef APOH_SUPPORT
	ucNumEndpts = IFX_MAX_ENDPTS;
	IFX_CIF_FxsEndptListGet(&ucNumEndpts, aszEndptIdList, &eReason);
#ifdef UTA
    /* Only 1 FXS port supported on UTA boards */
	if(ucNumEndpts == 0 || IFX_FXS_AgentInit(aszEndptIdList, 
											1, vcFXSModId) != IFX_SUCCESS )
#else
	if(ucNumEndpts == 0 || IFX_FXS_AgentInit(aszEndptIdList, 
											ucNumEndpts, vcFXSModId) != IFX_SUCCESS )
#endif
	{
			
		print_error("<%s:%d> ERROR : FXS Agent Initialization FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

#ifdef ENABLE_FXO
	if(vbFxoEnable){
  	ucNumEndpts = IFX_MAX_ENDPTS;
		IFX_CIF_FxoEndptListGet(&ucNumEndpts, aszEndptIdList, &eReason);

	if(ucNumEndpts == 0 || IFX_FXO_AgentInit(aszEndptIdList, 
											ucNumEndpts, vcFXOModId) != IFX_SUCCESS )
	{
		print_error("<%s:%d> ERROR : FXO Agent Initialization FAILED\n", 
																								__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
	}
#endif
#else
	/* 
	 * check whether another phone is offhook that is connected to FXS2 port,
	 * which inturn is connected to FXO port directly (hardwired and not 
	 * controlled by Network CPU). If no, only then initialize FXS2 and 
	 * FXO endpoints 
	 */
	if (IFX_MMGR_APOHStatusGet() != IFX_SUCCESS)
	{
		/* means phone connected to FXS2 is not in a call via FXO line */
		IFX_FXS_AgentInit();
		
#ifdef ENABLE_FXO
	if(vbFxoEnable){
		IFX_CIF_FxoEndptListGet(&ucNumEndpts, aszEndptIdList, &eReason);

		if (IFX_FXO_AgentInit(aszEndptIdList, ucNumEndpts, 
										vcFXOModId) != IFX_FAILURE)
		{
			return IFX_FAILURE;
		}
	}
#endif
	}
#endif /* APOH_SUPPORT */

	if (IFX_SIPAPP_Init(IFX_MAX_PROFILES) != IFX_SUCCESS)
	{
		print_error("<%s:%d> ERROR : SIP Initialization FAILED\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	printf("SIP Agent INIT#######################\n");
	
	/* check whether any profiles are created in MAPI-V, only then
	 * create so many service provider accounts in SIP stack
	 */
	if (IFX_CIF_ProfileIdListGet(aucProfileId) == IFX_SUCCESS)
	{
		uchar8	i;

		for (i=0; (i < IFX_MAX_PROFILES) && (aucProfileId[i] != 0); i++){
    	 x_IFX_VMAPI_VoiceProfile xVoiceProfile;
		 memset(&xVoiceProfile,0,sizeof(x_IFX_VMAPI_VoiceProfile));
	  	 xVoiceProfile.ucProfileId = aucProfileId[i];
       if(IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xVoiceProfile,IFX_CIF_GET_FLAGS) ){
		  continue;
       }
      if(IFX_VMAPI_VP_STATE_ENABLED == xVoiceProfile.ucState) {
        if (IFX_SIPAPP_CreateSrvPdr(aucProfileId[i]) != IFX_SUCCESS){
        print_error("<%s:%d> ERROR : Could Not Create SIP Service Provider\n",
                                                __FUNCTION__, __LINE__);
        return IFX_FAILURE;
       }
      }
	  }
	}

  if( IFX_VMAPI_SUCCESS != ifx_get_DbgSettings(&xDbg,IFX_CIF_GET_FLAGS))
	{
				
		print_error("<%s:%d> WARNING : Failed To Retrieve Debug Setting\n", 
																								__FUNCTION__, __LINE__);
	}
	printf("DBG INIT#######################\n");
	
	/* get the debug info of RTP module */
	if (IFX_RTPAgent_Init(xDbg.xRtpDbg.ucDbgLvl,xDbg.xRtpDbg.ucDbgType, 
													IFX_RTP_AGENT_PORT_START) != IFX_SUCCESS)
	{
		print_error("<%s:%d> ERROR : Could Not Initialize RTP Agent\n", 
																								__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	printf("RTP INIT#######################\n");

#ifdef FAX_SUPPORT
	{
		x_IFX_VMAPI_T38Cfg xT38SysCfg = {{{{""}}}};

		if( IFX_VMAPI_SUCCESS != ifx_get_SystemT38(&xT38SysCfg, IFX_CIF_GET_FLAGS) )
		{
			print_error("<%s:%d> ERROR : Could Not Retrieve T.38 Settings\n", 
																								__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
#if 0		
		memset(&xT38SysCfg,0,sizeof(x_IFX_VMAPI_T38Cfg));
/* Just for testing -- Remove later !!! - Chaitanya*/
		xT38SysCfg.ucOldAsn1 = 1;
		xT38SysCfg.ucNsxSize = 2;
		strcpy(xT38SysCfg.ucNsxInfoField, "0080");
		xT38SysCfg.ucDataWaitTime = 0;
#endif
		/* get the debug info of FAX module */
		if ( IFX_SUCCESS != 
				 IFX_FAXAgent_Init(xDbg.xFaxDbg.ucDbgLvl,xDbg.xFaxDbg.ucDbgType,
														&xT38SysCfg) )
		{
			print_error("<%s:%d> ERROR : Could Not Initialize FAX Agent\n", 
																								__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
	}
//#else
//#warning "FAX Support Is Not Enabled"
#endif /* FAX_SUPPORT */
	printf("FAX INIT DONE#######################\n");
	return IFX_SUCCESS;
}
	



/*******************************************************************************
* Function Name    : IFX_CFG_VLRegister
* Description      : This function initiates registration or unregistration 
*                    given line from SIP registrar server. 

*                   bRegister = IFX_TRUE - Requested for registration. If 
*                   line is registered already, it initiates unregistration &
*                   registration will be initiated after completing 
*                   unregistration. (see IFX_CFG_RegRespHdlr to understand how 
*                   registration is initiated, after completion of un-reg ).
*                   If unregistration is in progress and also in above condition, 
*                   sets the flag to initiated registration after completion 
*                   of un-registration. If line is not registered, registration
*                   initiates registration.
*
*                   bRegister = IFX_FALSE - Requested for unregistration. If
*                   line is registered, then unregistration is is initiated.
* Input Values     : ucLineId - Voice line id.
*                    bRegister - IFX_TRUE - To initated registration
*                                IFX_FALSE - To unregister line
*                    bDontWaitForResp - IFX_TRUE - Not to wait for response
*                                       IFX_FALSE - Wait for response
*                       (bDontWaitForResp is valid only for un-registration)
* Output Values    : None
* Return Value     : IFX_SUCCESS - If requested operation is intiated.
*                    IFX_FAILURE - On failure.
* Notes            : Registration is initiated only if required parameters for
*                    registration are set.
*******************************************************************************/
e_IFX_Return IFX_CFG_VLRegister(
										 IN uchar8 ucLineId,
										 IN boolean bRegister,
                     IN boolean bDontWaitForResp	)
{
	x_IFX_CFG_LineInfo* pxLineInfo;
	uint32 uiRegTime = 0;
	e_IFX_CMGR_Status eStatus;
	e_IFX_ReasonCode eReason = IFX_MAX_REASON;
	e_IFX_Return eRet;
	x_IFX_CMGR_RegServerInfo xRegServerInfo;
	memset(&xRegServerInfo,0,sizeof(x_IFX_CMGR_RegServerInfo));
	if( ucLineId == 0 || ucLineId > IFX_MAX_LINES )
		return IFX_FAILURE;

	pxLineInfo = (vaxLineInfo+(ucLineId-1));
	pxLineInfo->ucVoiceLineId = ucLineId; //TODO : Why init here???
	
	if( IFX_FALSE == bRegister && ( 0 == pxLineInfo->uiRegRequestId || 
			(IFX_CIF_UnRegInitiated == pxLineInfo->eRegStatus 
			 																	&& IFX_FALSE == bDontWaitForResp )) ) {

		/* 
		 * Unregistering line which is not registered or un-registration in 
		 * progress and trying to unregister again.
		 */
			
		print_error("<%s:%d> Warning : Can not Unregister Line %d \n", 
					__FUNCTION__, __LINE__, ucLineId) ;
		return IFX_SUCCESS;

	} else if( IFX_TRUE == bRegister && pxLineInfo->uiRegRequestId ) {
		/* 
		 * Already Registered, need to unregister first and register after 
		 * unregistering 
		 */	
		bRegister = IFX_FALSE;
		IFX_CFG_SET_LINE_FLAG(pxLineInfo,  IFX_CFG_RE_REGISTER);
		if( IFX_CIF_UnRegInitiated == pxLineInfo->eRegStatus )
			return IFX_SUCCESS; //Already un-registration in process
	}
				
	if( IFX_TRUE == bRegister )	{

		bDontWaitForResp = IFX_FALSE; //To be safe, turn off this
		/* Get registration expiry time */
		x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
		x_IFX_VMAPI_ProfileSignaling xProfileSig = {{{{""}}}} ; 
		x_IFX_VMAPI_VoiceProfile xProfile = {{{{""}}}} ;

		xVoiceLine.ucLineId = ucLineId; 
		if( IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS) )
		{
			/* Could not get line info...*/
			return IFX_FAILURE;
		}
		
		
		xProfile.ucProfileId = xProfileSig.ucProfileId = xVoiceLine.ucProfileId;
		if( (IFX_VMAPI_VL_STATE_ENABLED == xVoiceLine.ucState)
				&& (IFX_VMAPI_SUCCESS == ifx_get_VoiceProfile(&xProfile,IFX_CIF_GET_FLAGS))
				&& (IFX_VMAPI_VP_STATE_ENABLED == xProfile.ucState) 
				&& (IFX_VMAPI_SUCCESS == 
								ifx_get_ProfileSignaling(&xProfileSig,IFX_CIF_GET_FLAGS)) 
				&& (IFX_TRUE == xProfileSig.bEnableRegistrar || IFX_TRUE == xProfileSig.bEnableProxy) )
		{
#ifdef VOIP_NEWVMAPI
			uiRegTime = xProfileSig.unRegExpires;
#else
			uiRegTime = xProfileSig.uiRegExpirationTime;
#endif
			xRegServerInfo.unLineId = ucLineId;

			if (xProfileSig.acRegistrarAddr[0] == 0){
				/* Primary server is not configured, use proxy as registrar */
				if (xProfileSig.acProxyAddr[0] == 0){
					return IFX_FAILURE;
				}
				strcpy(xRegServerInfo.axSrvrAddr[0].acCalledAddr,xProfileSig.acProxyAddr);
				xRegServerInfo.axSrvrAddr[0].unPort = xProfileSig.unProxyPort;
				xRegServerInfo.axSrvrAddr[0].ucAddrProto = xProfileSig.ucProxyProtocol;
				xRegServerInfo.ucNoOfServer += 1;
			}
			else {

				strcpy(xRegServerInfo.axSrvrAddr[0].acCalledAddr,xProfileSig.acRegistrarAddr);
				xRegServerInfo.axSrvrAddr[0].unPort = xProfileSig.unRegistrarPort;
				xRegServerInfo.axSrvrAddr[0].ucAddrProto = xProfileSig.ucRegistrarProtocol;
				xRegServerInfo.ucNoOfServer += 1;
		

				if (xProfileSig.acBackupRegAddr[0] != 0){
					strcpy(xRegServerInfo.axSrvrAddr[1].acCalledAddr,xProfileSig.acBackupRegAddr);
					xRegServerInfo.axSrvrAddr[1].unPort = xProfileSig.unBackupRegPort;
					xRegServerInfo.axSrvrAddr[1].ucAddrProto = xProfileSig.ucBackupRegProtocol;
					xRegServerInfo.ucNoOfServer += 1;
				}
			}
		}
		else
		{
			return IFX_FAILURE;
		}
	}
	else if( IFX_TRUE == bDontWaitForResp ) {
		/* Don't wait for response is valid only for un-register request */
		eReason = IFX_REL_NO_NOTIFY;
	} 
	xRegServerInfo.uiExpVal = uiRegTime;
  eRet = IFX_CMGR_Register(&xRegServerInfo,
                           &pxLineInfo->uiRegRequestId,
                           &eStatus,&eReason,
                           pxLineInfo);
  if( IFX_TRUE == bDontWaitForResp ) {
		pxLineInfo->uiRegRequestId = 0;
		pxLineInfo->eRegStatus = IFX_CIF_NotRegistered;
		IFX_CIF_VLRegisterStatusSet(pxLineInfo->ucVoiceLineId, 
														IFX_VMAPI_VL_STATUS_DISABLED, 0, &eReason );
	}else	if( IFX_SUCCESS == eRet && IFX_CMGR_STATUS_FAIL != eStatus ) {
    //uchar8 ucStatus;
		pxLineInfo->eRegStatus = 
											(uiRegTime > 0)?IFX_CIF_RegInitiated:IFX_CIF_UnRegInitiated;
    if(uiRegTime == 0){
      //ucStatus= IFX_VMAPI_VL_STATUS_UNREGISTERING;
    }
    else{
      //ucStatus= IFX_VMAPI_VL_STATUS_REGISTERING;
      IFX_CIF_VLRegisterStatusSet(pxLineInfo->ucVoiceLineId, 
	    IFX_VMAPI_VL_STATUS_REGISTERING,uiRegTime, &eReason );
    }
	} else {
		
		print_error("<%s:%d> ERROR : IFX_CMGR_Register FAILED \n", 
					__FUNCTION__, __LINE__) ;
		pxLineInfo->eRegStatus = IFX_CIF_RegError;
		pxLineInfo->uiRegRequestId = 0;
		IFX_CIF_VLRegisterStatusSet(pxLineInfo->ucVoiceLineId, 
														IFX_VMAPI_VL_STATUS_ERROR, 0, &eReason );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CFG_VLVMSubscribe 
* Description      : This function subscribes or unsubscribes voice line from
*                    voice mail server. Its functionality is very similar to
*                    IFX_CFG_VLRegister, except registration/unregistration
*                    this function does subscription/unsubscription to voice 
*                    mail server.
* Input Values     : ucLineId - Voice line id.
*                    bSubscribe - IFX_TRUE - To initated subscription
*                                 IFX_FALSE - To unsubscribe line
*                    bDontWaitForResp - IFX_TRUE - Not to wait for unscubscribe
*                                                  response
*                              (valid only for unsubscribe request) 
* Output Values    : None
* Return Value     : IFX_SUCCESS - If requested operation is intiated.
*                    IFX_FAILURE - On failure.
* Notes            :
*******************************************************************************/
STATIC
e_IFX_Return IFX_CFG_VLVMSubscribe(
										 IN uchar8 ucLineId,
										 IN boolean bSubscribe,
                     IN boolean bDontWaitForResp )
{
	x_IFX_CFG_LineInfo* pxLineInfo;
	e_IFX_CMGR_Status eStatus;
	e_IFX_ReasonCode eReason;
	uint16 unSubnTime = 0;
	e_IFX_Return eRet = IFX_SUCCESS;
	
	if( ucLineId == 0 || ucLineId > IFX_MAX_LINES )
		return IFX_FAILURE;

	pxLineInfo = (vaxLineInfo+(ucLineId-1));

	if( IFX_FALSE == bSubscribe && ( 0 == pxLineInfo->uiSubRequestId || 
			(IFX_CIF_UnSubInitiated == pxLineInfo->eSubStatus &&
		 													IFX_TRUE == bDontWaitForResp)	) )
	{
		/* 
		 * Un-subscribing event which is not subscribed or un-subscribing in 
		 * progress and trying to un-subscribe again.
		 */
		return eRet; 
	}
	else if( IFX_TRUE == bSubscribe && pxLineInfo->uiSubRequestId)
	{
		bSubscribe = IFX_FALSE;
		IFX_CFG_SET_LINE_FLAG(pxLineInfo, IFX_CFG_RE_SUBSCRIBE);	
		if( IFX_CIF_UnSubInitiated == pxLineInfo->eSubStatus )
			 return IFX_SUCCESS; //it is process of unsubscribing
	}

	if( bSubscribe == IFX_TRUE) {

		bDontWaitForResp = IFX_FALSE; //To be safe, turn off this 
		x_IFX_CalledAddr xVmAddr = {0};
		x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
		x_IFX_VMAPI_VoiceProfile xProfile = {{{{""}}}} ;
		
		xVoiceLine.ucLineId = ucLineId; 
		if( IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS) )
		{
			/* Could not get line info...*/
			return IFX_FAILURE;
		}

		xProfile.ucProfileId = xVoiceLine.ucProfileId;
		if( (IFX_VMAPI_VL_STATE_ENABLED != xVoiceLine.ucState) 
				|| (IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xProfile,IFX_CIF_GET_FLAGS))
				|| (IFX_VMAPI_VP_STATE_ENABLED != xProfile.ucState) 
				|| (IFX_SUCCESS != 
								IFX_CIF_VLVMSubEventGet(ucLineId, IFX_FALSE, &xVmAddr,&unSubnTime))
				|| xVmAddr.acCalledAddr[0] == '\0' )
																	
		{
			print_error("<%s:%d> WARNING : Voice Mail Subscription Is Not Enabled on VoiceLine %d\n", 
					__FUNCTION__, __LINE__,ucLineId) ;
			return IFX_FAILURE;
		}
	} else if( IFX_TRUE == bDontWaitForResp ) {
		eReason = IFX_REL_NO_NOTIFY;
	}
	
	eRet = IFX_CMGR_VM_Subn(ucLineId, unSubnTime, 
						&pxLineInfo->uiSubRequestId, &eStatus,&eReason,pxLineInfo);
	if( IFX_TRUE == bDontWaitForResp ) {
		pxLineInfo->eSubStatus = IFX_CIF_NotSubscribed;
		pxLineInfo->uiSubRequestId = 0;
		IFX_CIF_VLVMStatusSet(ucLineId, 
														IFX_VMAPI_VL_SUBS_STATE_IDLE, 0, &eReason );
		eRet = IFX_SUCCESS;
	}else	if( IFX_SUCCESS == eRet && IFX_CMGR_STATUS_FAIL != eStatus ) {
		pxLineInfo->eSubStatus = 
										(bSubscribe)?IFX_CIF_SubInitiated:IFX_CIF_UnSubInitiated;
	} else {
		pxLineInfo->eSubStatus = IFX_CIF_SubError;
		pxLineInfo->uiSubRequestId = 0;
		IFX_CIF_VLVMStatusSet(ucLineId, 
														IFX_VMAPI_VL_SUBS_STATE_IDLE, 0, &eReason );
	}

	return eRet;
}

/*******************************************************************************
* Function Name    : IFX_CFG_VLRegAndSub
* Description      : This function initiates registrataion and subscription to 
*                    voice mail server on all valid lines of the system.
* Input Values     : None 
* Output Values    : None
*                    IFX_FAILURE - If failed to get voice lines from system,
*                    otherwise returns IFX_SUCCESS.
* Notes            :
*******************************************************************************/
STATIC
e_IFX_Return IFX_CFG_VLRegAndSub()
{

	x_IFX_VMAPI_VoiceService xVoiceSrv = {{{{""}}}};
	uchar8 ucLineCnt;

	if( IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVoiceSrv,IFX_CIF_GET_FLAGS))
	{
		return IFX_FAILURE;
	}

	for( ucLineCnt=0; ucLineCnt<(2*IFX_VMAPI_MAX_VOICE_LINES+1) 
				&& xVoiceSrv.ucLineIdList[ucLineCnt] > 0; ++ucLineCnt )
	{
		IFX_CFG_VLRegister(xVoiceSrv.ucLineIdList[ucLineCnt], IFX_TRUE, IFX_FALSE);
		IFX_CFG_VLVMSubscribe(xVoiceSrv.ucLineIdList[ucLineCnt], IFX_TRUE, IFX_FALSE);
		
	} /* for */

	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CFG_RegRespHdlr
* Description      : This function is callback function registered with call 
*                    manager to handle registration responses.
*                    If uiExpVal is zero (this means line is unregistered or 
*                    error) and IFX_CFG_RE_REGISTER is set, initiate registation
*                    and exit from function.
*                    eStatus is success and uiExpVal is not zero - Registration
*                    is going on and status of line registation depends on 
*                    eReason. If eReason = IFX_TIMEOUT, registration timed-out, 
*                    but still trying to register. Otherwise registration is
*                    success.
*                    If uiExpVal is zero, uiRequestId will no longer valid, so
*                    reset register request Id of line.
* Input Values     : uiRequestId - Request Id of the transaction
*                    uiExpVal - Expire value in secs.
*                    eStatus - Registration/unregitration status.
*                    eReason - Reason.
*                    pvPrivateData - Pointer to private data
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS. 
* Notes            : Line registered status is updated, if registration is not
*                    initiated in this function.
*******************************************************************************/
e_IFX_Return IFX_CFG_RegRespHdlr(
	               IN uint32 uiRequestId,
	               IN uint32 uiExpVal,
	               IN e_IFX_CMGR_Status eStatus,
	               IN e_IFX_ReasonCode eReason,
	               IN void* pvPrivateData )
{
	x_IFX_CFG_LineInfo* pxLineInfo = (x_IFX_CFG_LineInfo*)(pvPrivateData);
	uchar8 ucRegStatus = IFX_VMAPI_VL_STATUS_ERROR;

	print_message("[CFG] Register Response RequestId=%d Status=%d Expiry Value=%d\n",
		uiRequestId, eStatus, uiExpVal) ; 

	if( uiRequestId != pxLineInfo->uiRegRequestId ) {
		//print_error("Register RequestId does not match\n");
		return IFX_FAILURE;
	}
	
	if( 0 == uiExpVal && 
			IFX_CFG_CHECK_LINE_FLAG(pxLineInfo, IFX_CFG_RE_REGISTER ))
	{
		IFX_CFG_RESET_LINE_FLAG(pxLineInfo,IFX_CFG_RE_REGISTER);
		pxLineInfo->uiRegRequestId = 0;
		if( IFX_SUCCESS != 
				IFX_CFG_VLRegister(pxLineInfo->ucVoiceLineId, IFX_TRUE,IFX_FALSE) ) {
			eStatus = IFX_CMGR_STATUS_FAIL;
		}	else {
			return IFX_SUCCESS;
		}
	}

	if( IFX_CMGR_STATUS_SUCCESS == eStatus && uiExpVal > 0)
	{
		if( IFX_TIMEOUT == eReason 
			 || IFX_REQ_PENDING == eReason)
		{
		  pxLineInfo->eRegStatus = IFX_CIF_NotRegistered;
			ucRegStatus = IFX_VMAPI_VL_STATUS_REGISTERING;
		}
		else
		{
			pxLineInfo->eRegStatus = IFX_CIF_Registered;
			ucRegStatus = IFX_VMAPI_VL_STATUS_UP;
		}

	}
	else /* Failed */
	{
		pxLineInfo->eRegStatus = IFX_CIF_RegError;
		uiExpVal = 0;
	}

	pxLineInfo->uiRegRequestId = (uiExpVal > 0)?pxLineInfo->uiRegRequestId:0;
	IFX_CIF_VLRegisterStatusSet(pxLineInfo->ucVoiceLineId, 
																			ucRegStatus, uiExpVal, &eReason  );
	return IFX_SUCCESS;
}


/*******************************************************************************
* Function Name    : IFX_CFG_SubnRespHdlr 
* Description      : This function is registered as callback function with CM 
*                    to handle registration responses. Functinality is very 
*                    similar to IFX_CFG_RegRespHdlr, except that this function
*                    handles voice mail subscription responses, instead 
*                    registration response.
* Input Values     : uiRequestId - Request Id of the transaction
*                    uiExpVal - Expire value in secs.
*                    eStatus - Subscribe/unsubscribe status.
*                    eReason - Reason.
*                    pvPrivateData - Pointer to private data
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS.
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_SubnRespHdlr(
	               IN uint32 uiRequestId,
	               IN uint32 uiExpVal,
	               IN e_IFX_CMGR_Status eStatus,
	               IN e_IFX_ReasonCode eReason,
	               IN void* pvPrivateData )
{
	x_IFX_CFG_LineInfo* pxLineInfo = (x_IFX_CFG_LineInfo*)(pvPrivateData);
	uchar8 ucSubStatus = IFX_VMAPI_VL_SUBS_STATE_IDLE;
	print_message("[CFG] Subscription response status=%d Expiry=%d\n",
		eStatus, uiExpVal);
	if( 0 == uiExpVal && 
			IFX_CFG_CHECK_LINE_FLAG(pxLineInfo, IFX_CFG_RE_SUBSCRIBE))
	{
		IFX_CFG_RESET_LINE_FLAG(pxLineInfo, IFX_CFG_RE_SUBSCRIBE);
		pxLineInfo->uiSubRequestId = 0;
		if( IFX_SUCCESS != 
				IFX_CFG_VLVMSubscribe(pxLineInfo->ucVoiceLineId, IFX_TRUE, IFX_FALSE) ) {
			eStatus = IFX_CMGR_STATUS_FAIL;
		}	else {
			return IFX_SUCCESS;
		}
	}

	if( IFX_CMGR_STATUS_SUCCESS == eStatus && uiExpVal > 0)
	{
		if( IFX_TIMEOUT != eReason )
		{
			pxLineInfo->eSubStatus = IFX_CIF_Subscribed;
			ucSubStatus =	IFX_VMAPI_VL_SUBS_STATE_ACTIVE;
		}
		else
		{
			pxLineInfo->eSubStatus = IFX_CIF_NotSubscribed;
			ucSubStatus =	IFX_VMAPI_VL_SUBS_STATE_IDLE;
		}
	}
	else /* Failed */
	{
		print_message("[CFG] Subscription failed\n");
		pxLineInfo->eSubStatus = IFX_CIF_SubError;
	}

	pxLineInfo->uiSubRequestId = (uiExpVal > 0)?pxLineInfo->uiSubRequestId:0;
	IFX_CIF_VLVMStatusSet(pxLineInfo->ucVoiceLineId, 
														ucSubStatus, uiExpVal,&eReason );
	return IFX_SUCCESS;
}


/*******************************************************************************
* Function Name    : IFX_CFG_VMNotifyHdlr 
* Description      : This function is registered with CM to receive Voice Mail 
*                    server notification. 
*                    uiSubnReqId = 0 : This is for un-solicited notify. If 
*                    system is configured to receive un-solicited notify, 
*                    validate server. If valid, update voice mail status.
*                    If system is not configured to receive un-solicited notify
*                    or sever validation fails, reject this notify.
*                    uiSubnReqId != 0 : Validate request id. If valid update
*                    voice mail status.
* Input Values     : uiSubnReqId  - VM subscription id.
*                    pxVoiceMailNtfyInfo - Pointer to struct containing VM 
*                    notify information.
*                    pvPrivateData - Private data passed during subscription.
* Output Values    : 
* Return Value     : IFX_SUCCESS - If notify is valid and processed.
*                    IFX_FAILURE - On failure to process notification.
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_VMNotifyHdlr(
	               IN uint32 uiSubnReqId,
	               IN x_IFX_CMGR_VoiceMailNotifyInfo* pxVoiceMailNtfyInfo,
	               IN void* pvPrivateData )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallFtrs = {{{{""}}}};

	if( !uiSubnReqId )
	{
		/* Un-solicited notify. If unsolicited notify flag is not enabled, return 
		 * failure. If enabled, verify that notify contains valid receipent and 
		 * notifier is a Voice Mail Server, else reject notify. Update message 
		 * waiting status.
		 */
		x_IFX_CMGR_NotifyInfo* pxNtfyInf = (x_IFX_CMGR_NotifyInfo*)(pvPrivateData);
		//x_IFX_CMGR_VoipAddr xVmAddr;
		boolean bUnsolNtfy = IFX_FALSE;
		e_IFX_ReasonCode eReason;
		uchar8 ucLineId;
		//uint16 unSubnTime;

		IFX_CIF_UnsolicitedNtfyStatusGet(&bUnsolNtfy, &eReason);

		if( IFX_FALSE == bUnsolNtfy || IFX_SUCCESS != IFX_CIF_VLFromUrlGet(
				&pxNtfyInf->xToAddress.uxAddressInfo.xVoipAddr, &ucLineId, &eReason) )
		{
			return IFX_FAILURE;
		}
#if 0
		if( IFX_SUCCESS != 
				IFX_CIF_VLVMSubEventGet(ucLineId, IFX_TRUE, &xVmAddr,&unSubnTime) ||
				strcasecmp(xVmAddr.acCalledAddr, 
					pxNtfyInf->xFromAddress.uxAddressInfo.xVoipAddr.acCalledAddr)
			)
		{
			return IFX_FAILURE;
		}
#endif
		xLineCallFtrs.ucLineId = ucLineId;
	}
	else {
		x_IFX_CFG_LineInfo* pxLineInfo = (x_IFX_CFG_LineInfo*)(pvPrivateData);

		if( pxLineInfo->uiSubRequestId == uiSubnReqId)
			xLineCallFtrs.ucLineId = pxLineInfo->ucVoiceLineId;
		else
		{
			print_error("<%s:%d> ERROR : Subscription ID Is Wrong",
											__FUNCTION__,__LINE__);
			return IFX_FAILURE; // uiRequest Id is wrong
		}
	}

	if( IFX_VMAPI_SUCCESS == 
		ifx_get_LineCallingFeatures(&xLineCallFtrs,IFX_CIF_GET_FLAGS ) /*&&
		IFX_TRUE == xLineCallFtrs.bEnableMwiIndication*/ )
	{
		xLineCallFtrs.bIsMsgWaiting = pxVoiceMailNtfyInfo->bNewMsg;
		if( IFX_VMAPI_SUCCESS != ifx_set_LineCallingFeatures(IFX_CIF_SET_OPP,
				&xLineCallFtrs,IFX_CIF_MOD_FLAG) )
		{
			/* Could not set line info...*/
			print_error("<%s:%d> WARNING : Could Not Set Message Waiting Flag", 
																										__FUNCTION__, __LINE__);
		}
	}
	
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_CFG_PopulateDialPlan
* Description      : This function converts dial plan rules from vmapi 
*                    format according to dial plan module format and sets 
*                    these rules into dial plan module.
* Input Values     : None 
* Output Values    : None
* Return Value     : IFX_SUCCESS - On successfuly updating dial rules.
*                    IFX_FAILURE - If failed to update dial rules.
* Notes            :
***************************************************************************/
e_IFX_Return IFX_CFG_PopulateDialPlan( )
{
	x_IFX_VMAPI_NumPlan xNumPlan = {{{{""}}}};
	x_IFX_DP_Rule* pxDpRule = 0;
	uchar8 ucIndex = 0;
	e_IFX_Return eRet = IFX_FAILURE;
	
	if( IFX_VMAPI_SUCCESS == ifx_get_NumPlan(&xNumPlan, IFX_CIF_GET_FLAGS) )
	{
		/* There must be at least few rules */
		uchar8 ucExtraDialRules = 0;
		gucMindgts = xNumPlan.ucNumPlanMinDigits;
		gucMaxdgts = xNumPlan.ucNumPlanMaxDigits;
#ifdef ENABLE_DBG_THR_PHONE
		++ucExtraDialRules;
#endif 
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
#ifdef ENABLE_PIN_CODE_CFG_THR_PHONE
		++ucExtraDialRules;
#endif
#ifdef DEBUG_COSIC
		++ucExtraDialRules;
#endif
#endif //DECT_SUPPORT

		if( NULL != (pxDpRule = 
				malloc( ((xNumPlan.ucNoOfNumPlanRules + 
																ucExtraDialRules) * sizeof(x_IFX_DP_Rule))) ) )
		{
			x_IFX_VMAPI_NumPlanRule *pxTemp = xNumPlan.pxNumPlanRules;
    	while (pxTemp !=NULL) 
			{
				IFX_CFG_ConvertNumPlanObject(pxTemp,pxDpRule + ucIndex);
				ucIndex++;
    		__ifx_list_GetNext((void *)&pxTemp);
   		}/*while loop*/
#ifdef ENABLE_DBG_THR_PHONE
			{
				x_IFX_DP_Rule* pxDbgRule	= pxDpRule + ucIndex;

				//Debug enable
				strcpy(pxDbgRule->szPrefix, "#6");
				pxDbgRule->ucMax = pxDbgRule->ucMin = 2;
				pxDbgRule->ucDgtRmv = pxDbgRule->ucPosRmv = 0;
				pxDbgRule->cDgtIns = pxDbgRule->ucPosIns = pxDbgRule->cDgtReplace = 
								pxDbgRule->ucPosReplace = 0;
				pxDbgRule->eAction = IFX_DP_ENABLE_DEBUGS; 
				ucIndex++;
			
				//Debug disable	
				pxDbgRule	= pxDpRule + ucIndex ;
				strcpy(pxDbgRule->szPrefix, "#7");
				pxDbgRule->ucMax = pxDbgRule->ucMin = 2;
				pxDbgRule->ucDgtRmv = pxDbgRule->ucPosRmv = 0;
				pxDbgRule->cDgtIns = pxDbgRule->ucPosIns = pxDbgRule->cDgtReplace = 
								pxDbgRule->ucPosReplace = 0;
				pxDbgRule->eAction = IFX_DP_DISABLE_DEBUGS; 
				ucIndex++;

				//xNumPlan.ucNoOfNumPlanRules += 2;
			}
#endif
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
			//print_message("<TEMP> DECT SUPPORT enabled \n");
#ifdef ENABLE_PIN_CODE_CFG_THR_PHONE
			{
				//print_message("<TEMP> DIAL CODE FOR PIN Change ## \n");
				x_IFX_DP_Rule* pxPinCfgRule	= pxDpRule + ucIndex;

				strcpy(pxPinCfgRule->szPrefix, "##");
				pxPinCfgRule->ucMax = pxPinCfgRule->ucMin = 10;
				pxPinCfgRule->ucDgtRmv = pxPinCfgRule->ucPosRmv = 0;
				pxPinCfgRule->cDgtIns = pxPinCfgRule->ucPosIns = pxPinCfgRule->cDgtReplace = 
								pxPinCfgRule->ucPosReplace = 0;
				pxPinCfgRule->eAction = IFX_DP_CHANGE_BASE_PIN; 
				++ucIndex;
			}
#endif //ENABLE_PIN_CODE_CFG_THR_PHONE
#ifdef DEBUG_COSIC
			{
				//print_message("<TEMP> DIAL CODE Cosic Debug ## \n");
				x_IFX_DP_Rule* pxDpCosicDebugRule	= pxDpRule + ucIndex;

				strcpy(pxDpCosicDebugRule->szPrefix, "*##");
				pxDpCosicDebugRule->ucMax = pxDpCosicDebugRule->ucMin = 5;
				pxDpCosicDebugRule->ucDgtRmv = 0; 
				pxDpCosicDebugRule->ucPosRmv = 0;
				pxDpCosicDebugRule->cDgtIns = pxDpCosicDebugRule->ucPosIns =
						pxDpCosicDebugRule->cDgtReplace = pxDpCosicDebugRule->ucPosReplace = 0;
						pxDpCosicDebugRule->eAction = IFX_DP_DEBUG_COSIC; 
				++ucIndex;
			}

#endif
#endif //DECT_SUPPORT

			xNumPlan.ucNoOfNumPlanRules += ucExtraDialRules;
			printf("Number of dial plan rules in populate----------%d\n",xNumPlan.ucNoOfNumPlanRules);
			eRet = IFX_DP_DialPlanPopulate( pxDpRule, 
											(uchar8)xNumPlan.ucNoOfNumPlanRules,
											xNumPlan.ucInterdigTimerProg*1000,
											xNumPlan.ucInterdigTimerStd*1000,
											vcDPModId );
			free(pxDpRule);			
		}
		
		ifx_vmapi_freeObjectList(&xNumPlan, IFX_VMAPI_VS_NUM_PLAN);
	}

	return eRet;
}


/***************************************************************************
* Function Name    : IFX_CFG_ConvertNumPlanObject
* Description      : This routine converts dial plan rule from vmapi format
*                    to DP moduel format.
* Input Values     : pxVMAPIRule - pointer Rule to be converted
* Output Values    : pxDPRule - pointer to converted rule.
* Return Value     : Always returns success.
* Notes            :
***************************************************************************/
e_IFX_Return IFX_CFG_ConvertNumPlanObject(
	                   IN x_IFX_VMAPI_NumPlanRule * pxVMAPIRule,
	                   OUT x_IFX_DP_Rule* pxDPRule )
{
	char8* pszTmp;
	int16 iSzLen;

	memset(pxDPRule,0,sizeof(x_IFX_DP_Rule));
	
	/*Copy the prefix*/
	strcpy(pxDPRule->szPrefix,pxVMAPIRule->acPrefix);

	iSzLen = strlen(pxDPRule->szPrefix);
	pxDPRule->ucMax = pxVMAPIRule->ucMaxDigits4Prefix + iSzLen;
	pxDPRule->ucMin = pxVMAPIRule->ucMinDigits4Prefix + iSzLen;

	if( iSzLen )
	{
		pszTmp = pxDPRule->szPrefix;
		while(1)
		{
			pszTmp = strchr(pszTmp,'[');
			if( pszTmp )
			{
				pszTmp++;
				pxDPRule->ucMax-=4;
				pxDPRule->ucMin-=4;
			}
			else 
				break;
		}	
	}
	
	pxDPRule->ucDgtRmv = pxVMAPIRule->ucNoOfDigits2bRem ;
	
	if(pxVMAPIRule->ucPosDigits2bRem)
		pxDPRule->ucPosRmv = pxVMAPIRule->ucPosDigits2bRem-1;
	
	pxDPRule->cDgtIns = pxVMAPIRule->cDigits2bIns;
	pxDPRule->ucPosIns = pxVMAPIRule->ucPosDigits2bIns;
	pxDPRule->cDgtReplace = pxVMAPIRule->cDigits2bRep;
	pxDPRule->ucPosReplace = pxVMAPIRule->ucPosDigits2bRep;
	if(pxVMAPIRule->uiMainAct < IFX_DP_MAX_DP_ACTIONS)
		pxDPRule->eAction = pxVMAPIRule->uiMainAct;

	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_CFG_CfgnParamsNtfnReg 
* Description      : This function sets notification
* Input Values     : 
*                  :
* Output Values    : None
* Return Value     : Process Id
* Notes            :
***************************************************************************/
e_IFX_Return
IFX_CFG_CfgnParamsNtfnReg()
{
uchar8 uiNotifyObjArray[]={
	 IFX_VMAPI_PHY_IFACE_FXS,
	 IFX_VMAPI_PHY_IFACE_FXO,
   IFX_VMAPI_VOICE_PROFILE ,
  // IFX_VMAPI_ADD_PROFILE ,
   IFX_VMAPI_DELETE_PROFILE ,
   IFX_VMAPI_VP_SIGNALING , 
   IFX_VMAPI_VP_RTP ,
   IFX_VMAPI_VOICE_LINE ,
   IFX_VMAPI_ADD_LINE ,
   IFX_VMAPI_DELETE_LINE ,
   IFX_VMAPI_VL_EVENT_SUBSCR ,
   IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY ,
   IFX_VMAPI_VS_DEBUG_SET ,
   IFX_VMAPI_VS_NUM_PLAN ,
   IFX_VMAPI_VS_MISC ,
   IFX_VMAPI_VS_CONTACT_LIST ,
   //IFX_VMAPI_VS_DIALCALL_REGISTER ,
   IFX_VMAPI_VS_MISSCALL_REGISTER ,
   //IFX_VMAPI_VS_RECVCALL_REGISTER ,
   IFX_VMAPI_VL_CALLFEAT ,
   IFX_VMAPI_VS_PSTN_CONTACT_LIST ,
   IFX_VMAPI_VS_COMMON_CONTACT_LIST ,
   //IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER ,
   IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER ,
   //IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER ,
#ifdef LTAM
   IFX_VMAPI_PHY_INT_TEST ,
#endif
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
IFX_VMAPI_PHY_IFACE_DECT,
IFX_VMAPI_DECT_SYSTEM,
IFX_VMAPI_TBR6_TEST,
IFX_VMAPI_DECT_DIAGNOSTICS,
IFX_VMAPI_TRANS_POWER_TEST,
IFX_VMAPI_BMC_REG_PARAMS_TEST,
IFX_VMAPI_RF_MODE_TEST,
IFX_VMAPI_OSC_TRIM_TEST,
IFX_VMAPI_GFSK_TEST,
IFX_VMAPI_RFPI_TEST,
IFX_VMAPI_XRAM_TEST,
IFX_VMAPI_COUNTRY_SETTINGS_TEST,
#endif
#ifdef CVOIP_SUPPORT
  IFX_VMAPI_TBR6_REQUEST, /*!< TBR6 Test */
  IFX_VMAPI_DECT_SYSTEM_REQUEST, /*!< Dect System */
  IFX_VMAPI_DECT_DIAGNOSTICS_REQUEST, /*!< Dect Diagnostics */
  IFX_VMAPI_TRANS_POWER_REQUEST, /*!< Transmit Power Measurement Test */
  IFX_VMAPI_RF_MODE_REQUEST, /*!< RF Mode Test */
  IFX_VMAPI_RFPI_REQUEST, /*!< RFPI */
  IFX_VMAPI_XRAM_REQUEST, /*!< XRAM */
  IFX_VMAPI_XRAM_SFR_REQUEST, /*!< XRAM */
  IFX_VMAPI_COUNTRY_SETTINGS_REQUEST, /*!< DECT Country */
  IFX_VMAPI_BMC_REG_PARAMS_REQUEST, /*!< DECT BMC */
  IFX_VMAPI_OSC_TRIM_REQUEST, /*!< DECT Oscillator Trimming */
  IFX_VMAPI_GFSK_REQUEST, /*!< DECT GFSK */
	IFX_VMAPI_CVOIP_SYSTEM_CAPABALITIES,/*!<CVOIP Capabalities */
#endif
   IFX_DUMMY_TZ_CHANGE,
#ifdef VOIP_NEWVMAPI
  IFX_VMAPI_INTERFACE_CHANGE
#if defined DECT_SUPPORT
#ifdef DECT_REPEATER
  ,
  IFX_VMAPI_DECT_REPEATER
#endif
#endif
#endif

};	

///Make sure that appropriate number of objects counts are calculated and assigend into iSize
uchar8 iSize=20;
#ifdef LTAM
 iSize+=1;
#endif
///Make sure that appropriate number of dect related objects counts are calculated and assigend into iSize
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
 iSize+=12;
#endif
#if defined(CVOIP_SUPPORT)
 iSize+=13;
#endif
#ifdef VOIP_NEWVMAPI
 iSize+=1;
#if defined DECT_SUPPORT
#ifdef DECT_REPEATER
 iSize+=1;
#endif
#endif
#endif
IFX_VMAPI_IntimateOnChange(uiNotifyObjArray,iSize);
	return IFX_SUCCESS;
}

/* VMAPI Notify Handlers */
/*
 * If FXS endpoint id is changed, disconnect that endpoint and shutdown the 
 * endpoint, restart the endpoint.
 */
/*******************************************************************************
* Function Name    : 
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_FxsEndptNtfyHdlr(
	                   IN x_IFX_VMAPI_FxsPhyIf* pxFxsPhyIfOld,
	                   IN x_IFX_VMAPI_FxsPhyIf* pxFxsPhyIfNew )
{
	char8 aszEndpt[1][IFX_MAX_ENDPOINTID_LEN];
	e_IFX_ReasonCode eReason;
	boolean bEndptIdChanged = IFX_FALSE;
	if( strcmp((char8 *)pxFxsPhyIfOld->ucEndPtId,(char8 *)pxFxsPhyIfNew->ucEndPtId) )
	{
		/* Endpoint id is changed */

		bEndptIdChanged = IFX_TRUE;
		if( IFX_SUCCESS != 
				IFX_CMGR_CallsDiscForEndpt((char8 *)pxFxsPhyIfOld->ucEndPtId) )
		{
    	print_error("<%s:%d> WARNING :  IFX_CMGR_CallsDiscForEndpt FAILED\n", 
																											__FUNCTION__, __LINE__);
		}

		/* Shutdown FXS Agent */
		strcpy(aszEndpt[0],(char8 *)pxFxsPhyIfOld->ucEndPtId);
		if( IFX_SUCCESS != IFX_FXS_AgentShut(aszEndpt,1) )
		{
    	print_error("<%s:%d> WARNING :  IFX_FXS_AgentShut FAILED\n", 
																											__FUNCTION__, __LINE__);
		}

		/* Restart FXS Agent */
		strcpy(aszEndpt[0],(char8 *)pxFxsPhyIfNew->ucEndPtId);
		if( IFX_SUCCESS != IFX_FXS_AgentInit(aszEndpt,1,vcFXSModId) )
		{
    	print_error("<%s:%d> ERROR :  IFX_FXS_AgentInit FAILED\n", 
																											__FUNCTION__, __LINE__);
		}
	}
	
	if( IFX_TRUE == bEndptIdChanged || 
			pxFxsPhyIfNew->bEnableEchoCancel != pxFxsPhyIfOld->bEnableEchoCancel ||
			pxFxsPhyIfNew->bWideBandCapable != pxFxsPhyIfOld->bWideBandCapable)
	{
		x_IFX_MMGR_ChannelParams xChannelParams;

		memset(&xChannelParams,0,sizeof(xChannelParams));
		xChannelParams.bIsWideBandEnabled = pxFxsPhyIfNew->bWideBandCapable;
		xChannelParams.bIsLecEnabled = pxFxsPhyIfNew->bEnableEchoCancel;
		xChannelParams.cLecTailLength = 16;

		if( IFX_MMGR_SUCCESS != 
				IFX_MMGR_ChannelReCfg( pxFxsPhyIfNew->xVoiceServPhyIf.ucInterfaceId, 
				(char8 *)pxFxsPhyIfNew->ucEndPtId, &xChannelParams) )
		{
    	print_error("<%s:%d> ERROR :  IFX_MMGR_ChannelReCfg FAILED\n", 
																											__FUNCTION__, __LINE__);
		}
	}

	if( IFX_SUCCESS != 
			IFX_CIF_EndptDataUpdate((char8 *)pxFxsPhyIfOld->ucEndPtId,
				(char8 *)pxFxsPhyIfNew->ucEndPtId, pxFxsPhyIfNew->ucVoiceLineId,&eReason) )
	{
		//printf("\n%s : IFX_CIF_EndptDataUpdate FAILED",__FUNCTION__);
		;
	}

	return IFX_SUCCESS;
}
#if 0
#ifndef PSTNLine
/*******************************************************************************
* Function Name    : IFX_CFG_FxoLineHdlr 
* Description      : This Api handles Fxo line Enable/Disable.
*                    
* Input Values     : pxFxoIfOld - Poiner to struct containing previous values.
*                    pxFxoIfNew - Pointer to struct with new values.
* Output Values    : None
* Return Value     : IFX_SUCCESS
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_FxoLineHdlr(
	                   IN x_IFX_VMAPI_FxoPhyIf* pxFxoOld,
	                   IN x_IFX_VMAPI_FxoPhyIf* pxFxoNew )
{

	char8 aszEndpt[1][IFX_MAX_ENDPOINTID_LEN];
  
  if(pxFxoOld->ucState != pxFxoNew->ucState){
   
    x_IFX_MSGRTR_FdInfo xFdInfo;
    x_IFX_MMGR_FdSet xFdSet;
    int32 iCnt=0;
		strcpy(aszEndpt[0],pxFxoOld->ucEndPtId);

    if(pxFxoNew->ucState == IFX_VMAPI_PSTN_LINE_STATE_DISABLED){

      if(IFX_SUCCESS != IFX_CMGR_CallsDiscForEndpt(pxFxoOld->ucEndPtId) ){
         print_error("<%s:%d> WARNING :  IFX_CMGR_CallsDiscForEndpt FAILED\n",
                                                      __FUNCTION__, __LINE__);
      }
      /* Shutdown FXO Agent */
      if( IFX_SUCCESS != IFX_FXO_AgentShut(aszEndpt,1)){
        print_error("<%s:%d> ERROR :  IFX_FXO_AgentShut FAILED\n",
                                                      __FUNCTION__, __LINE__);
      }

      /* Invoke Fxo DeActivate */
       if(IFX_SUCCESS != IFX_MMGR_FXO_DeActivate(&xFdSet)){
         print_error("<%s:%d> ERROR : IFX_MMGR_FXO_DeActivate FAILED\n",
                                                __FUNCTION__, __LINE__);
         return IFX_FAILURE;
       }

      /* UnRegister the duslic device fd with the Message Router */

      for (iCnt=0; iCnt < xFdSet.ucNoOfFds; iCnt++){

         x_IFX_MSGRTR_FdInfo xFdInfo;

         xFdInfo.uiFd = xFdSet.aiFd[iCnt];
         xFdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;

         if (IFX_MSGRTR_FdUnregister(&xFdInfo) != IFX_SUCCESS){
           print_error("<%s:%d> ERROR : IFX_MSGRTR_FdUnregister FAILED\n",
                                                __FUNCTION__, __LINE__);
           return IFX_FAILURE;
         }
      }

    }else if(IFX_VMAPI_PSTN_LINE_STATE_ENABLED){
      
      x_IFX_MMGR_FXO_ResourceInfo axFxoResourceInfo[IFX_MMGR_MAX_FXO_CHANNELS];
      x_IFX_CIF_FxResourceInfo xResourceInfo;
      x_IFX_MMGR_FdSet xFdSet;
      x_IFX_MMGR_Device_Info xFXODevice;
      x_IFX_MMGR_FXO_Resources xFxoRes; 
      e_IFX_ReasonCode eReason;
      char8 aszEndptIdList[IFX_MAX_ENDPTS][IFX_MAX_ENDPOINTID_LEN];
      uchar8  ucNumEndpts;
      char8 aszDeviceList[IFX_MAX_DEVICES][IFX_MAX_DEV_STR_LEN];
      int32 iCnt=0;

      memset(&xFXODevice, 0, sizeof(x_IFX_MMGR_Device_Info));
      memset(&xFxoRes, 0, sizeof(x_IFX_MMGR_FXO_Resources));
      memset(&xFdSet, 0, sizeof(x_IFX_MMGR_FdSet));
      memset(&xResourceInfo,0,sizeof(x_IFX_CIF_FxResourceInfo));
      memset(axFxoResourceInfo,0,
      sizeof(x_IFX_MMGR_FXO_ResourceInfo)*IFX_MMGR_MAX_FXO_CHANNELS);
 
		   if( IFX_SUCCESS != IFX_FXO_AgentInit(aszEndpt,1,0)){
    	   print_error("<%s:%d> ERROR :  IFX_FXO_AgentInit FAILED\n", 
																											__FUNCTION__, __LINE__);
       }
  
       /* get the device names from MAPI-V */
       if(IFX_SUCCESS != IFX_CIF_DeviceListGet(IFX_MAX_DEVICES_IN_VMAPI, aszDeviceList, &eReason)){
         print_error("<%s:%d>  IFX_CIF_DeviceListGet FAILED\n",
																											__FUNCTION__, __LINE__);
         return IFX_FAILURE;
       }

       /* fill FXO Device Info */
       strcpy(xFXODevice.szDeviceName, aszDeviceList[IFX_FXO_DEVICE_POS]);
       xFXODevice.uxDevParams.xFxoParam.ucIrqNum = IFX_MMGR_FXODEV_IRQNUM;
       xFXODevice.uxDevParams.xFxoParam.iAccessMode = IFX_MMGR_FXODEV_ACCESSMODE;


       /* fill FXO information */
       xFxoRes.unNoOfFxoResources = IFX_MMGR_MAX_FXO_CHANNELS;
       xFxoRes.pxFxoInfo = &axFxoResourceInfo[0];

       /* get the FXO endpoint ids available in MAPI-V */
       ucNumEndpts = IFX_MMGR_MAX_FXO_CHANNELS;

       if(IFX_SUCCESS != IFX_CIF_FxoEndptListGet(&ucNumEndpts, aszEndptIdList,
                       &eReason))
       {
         print_error("<%s:%d> ERROR : IFX_CIF_FxoEndptListGet FAILED\n",
                                                __FUNCTION__, __LINE__);
         return IFX_FAILURE;
       }

       for(iCnt = 0; iCnt < ucNumEndpts; iCnt++){

         /* Get resource info from MAPI-V */
        if(IFX_SUCCESS != IFX_CIF_FxEndptResInfoGet(aszEndptIdList[iCnt],
                        &xResourceInfo,&eReason)){
          print_error("<%s:%d> ERROR : IFX_CIF_FxEndptResInfoGet FAILED\n",
                                                __FUNCTION__, __LINE__);
          return IFX_FAILURE;
        }

        strcpy(axFxoResourceInfo[iCnt].szEndPtId,
                      aszEndptIdList[iCnt]);
        strcpy(axFxoResourceInfo[iCnt].szChannelName,
                      xResourceInfo.szChannelName);
        axFxoResourceInfo[iCnt].iInterfaceId  =
                      xResourceInfo.iInterfaceId;
        axFxoResourceInfo[iCnt].bIsLecEnabled =
                      xResourceInfo.bIsLecEnabled;
        axFxoResourceInfo[iCnt].ucLecTailLength =
                      xResourceInfo.cLecTailLength;
        axFxoResourceInfo[iCnt].unChannelNum =
                      iCnt;
        axFxoResourceInfo[iCnt].unPcmChannelNum =
                      IFX_MMGR_PCM_CHANNEL_NUM;
        strcpy(axFxoResourceInfo[iCnt].szPcmChannelName,
                      IFX_MMGR_PCM_CHANNEL_NAME);
       }

       /* Invoke Fxo Activate */
       if(IFX_SUCCESS != IFX_MMGR_FXO_Activate(&xFXODevice,&xFxoRes, vcMMModId, &xFdSet)){
         print_error("<%s:%d> ERROR : IFX_MMGR_FXO_Activate FAILED\n",
                                                __FUNCTION__, __LINE__);
         return IFX_FAILURE;
       }

      /* Register the duslic device fd with the Message Router*/
      for (iCnt=0; iCnt < xFdSet.ucNoOfFds; iCnt++){

       x_IFX_MSGRTR_FdInfo xFdInfo;
       uchar8 ucNum = 1;

       xFdInfo.uiFd = xFdSet.aiFd[iCnt];
       xFdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;

       if (IFX_MSGRTR_FdCallBackRegister(&xFdInfo, ucNum,
            IFX_MSGRTR_HandleTapiEvents) != IFX_SUCCESS)
       {
          print_error("<%s:%d> ERROR : IFX_MSGRTR_FdCallBackRegister FAILED\n",
                                                __FUNCTION__, __LINE__);
          return IFX_FAILURE;
       }
      } 

     /*Free the allocated memory**/
     free(xFxoRes.pucCoefficient);
  }
  }
  return IFX_SUCCESS;
}
#endif
#endif
/*******************************************************************************
* Function Name    : IFX_CFG_FxoEndptNtfyHdlr 
* Description      : If FXO endpoint id is changed, disconnect that endpoint and 
*                    shutdown the endpoint, restart the endpoint.
* Input Values     : pxFxoIfOld - Poiner to struct containing previous values.
*                    pxFxoIfNew - Pointer to strcut with new values.
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_FxoEndptNtfyHdlr(
	                   IN x_IFX_VMAPI_FxoPhyIf* pxFxoIfOld,
	                   IN x_IFX_VMAPI_FxoPhyIf* pxFxoIfNew )
{
	char8 aszEndpt[1][IFX_MAX_ENDPOINTID_LEN];
	e_IFX_ReasonCode eReason;
	boolean bEndptIdChanged = IFX_FALSE;
	/*
	 * Check if line association has been changed. If changed, get default voice 
	 * line for each endpoint and assign it.
	 */
	if( memcmp(pxFxoIfNew->ucInterfaceIdList,
			pxFxoIfOld->ucInterfaceIdList,(2*(IFX_VMAPI_MAX_PHY_ENDPTS))) )
	{
		IFX_UpdateEnptDefaultLine();
	}
	if( strcmp((char8 *)pxFxoIfOld->ucEndPtId,(char8 *)pxFxoIfNew->ucEndPtId) )
	{
		/* Endpoint id is changed */
		bEndptIdChanged = IFX_TRUE;
		strcpy(aszEndpt[0],(char8 *)pxFxoIfOld->ucEndPtId);

		if( IFX_SUCCESS != 
				IFX_CMGR_CallsDiscForEndpt((char8 *)pxFxoIfOld->ucEndPtId) )
		{
    	print_error("<%s:%d> WARNING :  IFX_CMGR_CallsDiscForEndpt FAILED\n", 
																											__FUNCTION__, __LINE__);
		}

		/* Shutdown FXS Agent */
		if( IFX_SUCCESS != IFX_FXO_AgentShut(aszEndpt,1) )
		{
    	print_error("<%s:%d> ERROR :  IFX_FXO_AgentShut FAILED\n", 
																											__FUNCTION__, __LINE__);
		}

		/* Restart FXS Agent */
		strcpy(aszEndpt[0],(char8 *)pxFxoIfNew->ucEndPtId);
		if( IFX_SUCCESS != IFX_FXO_AgentInit(aszEndpt,1,0) )
		{
    	print_error("<%s:%d> ERROR :  IFX_FXO_AgentInit FAILED\n", 
																											__FUNCTION__, __LINE__);
		}
	}

	
	if( IFX_TRUE == bEndptIdChanged || 
			pxFxoIfNew->bEnableEchoCancel != pxFxoIfOld->bEnableEchoCancel)
	{
		x_IFX_MMGR_ChannelParams xChannelParams;

		memset(&xChannelParams,0,sizeof(xChannelParams));
		xChannelParams.bIsLecEnabled = pxFxoIfNew->bEnableEchoCancel;
		xChannelParams.cLecTailLength = 16;

		if( IFX_MMGR_SUCCESS != 
				IFX_MMGR_ChannelReCfg( pxFxoIfNew->xVoiceServPhyIf.ucInterfaceId, 
				(char8 *)pxFxoIfNew->ucEndPtId, &xChannelParams) )
		{
    	print_error("<%s:%d> ERROR :  IFX_MMGR_ChannelReCfg FAILED\n", 
																											__FUNCTION__, __LINE__);
		}
	}
	if( IFX_SUCCESS != 
			IFX_CIF_EndptDataUpdate((char8 *)pxFxoIfOld->ucEndPtId,
				(char8 *)pxFxoIfNew->ucEndPtId, pxFxoIfNew->ucVoiceLineId,&eReason) )
	{
		//printf("\n%s : IFX_CIF_EndptDataUpdate FAILED",__FUNCTION__);
		;
	}
	return IFX_SUCCESS;
}


#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
#ifdef DECT_REPEATER
extern e_IFX_Return IFX_DECT_UnregisterRepeater(IN uchar8 ucRepeaterNum);
/*******************************************************************************
* Function Name    : IFX_CFG_DectRepeaterChangeNtfyHdlr
* Description      : This funcion handles configuration changes applied on DECT
*                    Repeater.
* Input Values     : pxDectOld - Pointer to struct containing old values.
*                    pxDectNew -  Pointer to struct containing new values
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_DectRepeaterChangeNtfyHdlr(
                       IN x_IFX_VMAPI_DectRepeater* pxDectOld,
                       IN x_IFX_VMAPI_DectRepeater* pxDectNew )
{
    if( IFX_TRUE == pxDectOld->pxSubsInfo->bIsRegistered &&
            IFX_FALSE == pxDectNew->pxSubsInfo->bIsRegistered )
    {
		/*TODO : Unregister Repeater*/
		if (IFX_DECT_UnregisterRepeater(((uchar8)atoi(((const char *)(&(pxDectNew->ucEndPtId)))))) == IFX_SUCCESS)
		{		
			/*If Unregisteration successfull,reset suscription Info*/
			strncpy(pxDectNew->acSubscriptionTime,"",sizeof(pxDectNew->acSubscriptionTime));
			ifx_set_DectRepeater(0,pxDectNew,IFX_CIF_MOD_FLAG);
		}
		else
		{			 
			return IFX_FAILURE;
		}
	}
	return IFX_SUCCESS;
}
#endif

/*******************************************************************************
* Function Name    : IFX_CFG_DectHandsetChangeNtfyHdlr
* Description      : This funcion handles configuration changes applied on DECT
*                    handset.
* Input Values     : pxDectOld - Pointer to struct containing old values.
*                    pxDectNew -  Pointer to struct containing new values
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_DectHandsetChangeNtfyHdlr(
	                   IN x_IFX_VMAPI_DectHandset* pxDectOld,
	                   IN x_IFX_VMAPI_DectHandset* pxDectNew )
{
	char8 aszEndpt[1][IFX_MAX_ENDPOINTID_LEN];
	e_IFX_ReasonCode eReason;
	//boolean bEndptIdChanged = IFX_FALSE;

	if( strcmp((char8 *)pxDectOld->ucEndPtId, (char8 *)pxDectNew->ucEndPtId) )
	{
		/* TODO: Special handling for DECT. Don't shutdown agent and init it again
		 * How to inform DECT agent ?? 
		 */
#if 0 
		/* Endpoint id is changed */
		bEndptIdChanged = IFX_TRUE;
		strcpy(aszEndpt[0], pxDectOld->ucEndPtId);

		if( IFX_SUCCESS != 
				IFX_CMGR_CallsDiscForEndpt(pxDectOld->ucEndPtId) )
		{
    	print_error("<%s:%d> WARNING :  IFX_CMGR_CallsDiscForEndpt FAILED\n", 
																											__FUNCTION__, __LINE__);
		}
#endif
    /*PP Name Modified.Send Notification.*/
    //IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_INTERNAL_NAMES,pxDectOld,pxDectNew);
#ifdef DECT_SUPPORT
    IFX_DECTAPP_UpdateEndPtId(pxDectOld->ucEndPtId, pxDectNew->ucEndPtId);
#endif
	}
	if( strcmp((char8 *)pxDectOld->ucEndPtName, (char8 *)pxDectNew->ucEndPtName) )
  {
    /*PP Name Modified.Send Notification.*/
  }

	if( IFX_TRUE == pxDectOld->xSubsInfo.bIsRegistered &&
			IFX_FALSE == pxDectNew->xSubsInfo.bIsRegistered )
	{
		//print_message("Handset Has Been Unregistered By Admin/User.");
		/* Terminate Access Rights of the handset */
		strcpy(aszEndpt[0],(char8 *) pxDectOld->ucEndPtId);
#if defined(DECT_SUPPORT)
		if( IFX_SUCCESS != IFX_DECT_AgentShut(aszEndpt,1) )
		{
    	print_error("<%s:%d> ERROR :  IFX_DECT_AgentShut FAILED\n", 
																											__FUNCTION__, __LINE__);
		}
#elif defined(CVOIP_SUPPORT)
		if( IFX_SUCCESS != IFX_CVOIP_AgentShut(aszEndpt,1) )
		{
    	print_error("<%s:%d> ERROR :  IFX_CVOIP_AgentShut FAILED\n", 
																											__FUNCTION__, __LINE__);
		}
#endif
	}	
	IFX_CIF_EndptDataUpdate((char8 *)pxDectOld->ucEndPtId,
							(char8 *)pxDectNew->ucEndPtId, pxDectNew->ucVoiceLineId, &eReason);

	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CFG_DectSystemNtfy
* Description      : This routine handles configuration changes on DECT system.
* Input Values     : pxDectSystemOld - Pointer to x_IFX_VMAPI_DectSystem that 
*                     contains parameters before change
*                  : pxDectSystemNew - Pointer to x_IFX_VMAPI_DectSystem that
*                     contains changed parameters.
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS
* Notes            :
*******************************************************************************/
					
#ifdef CVOIP_SUPPORT
e_IFX_Return IFX_CFG_DectSystemNtfy(uchar8 ucOpMode,x_IFX_VMAPI_DectSystem* pxDectSystemOld, 
	                     x_IFX_VMAPI_DectSystem* pxDectSystemNew )
{
	switch(ucOpMode){
		default:	
		{
				uchar8 aucBuf[2];
				uchar8 *pucBuf = NULL;
				//x_IFX_VMAPI_DectSystem xDectSystem={{{{0}}}};
				x_IFX_VMAPI_DectSystem xDectSystemOld={{{{0}}}};

				IFX_CIF_DectSystemGet(&xDectSystemOld);
				if (memcmp(pxDectSystemOld, &xDectSystemOld, sizeof(x_IFX_VMAPI_DectSystem)) == 0){
					printf("No change in dect system setting\n");
					return IFX_SUCCESS;
				}
				//memcpy(&xDectSystem,pxDectSystemOld,sizeof(x_IFX_VMAPI_DectSystem));
				//IFX_CIF_StoreValuesFromModem(IFX_VMAPI_DECT_SYSTEM,&xDectSystem);

				/* Check for PIN change */
				if(strcmp(pxDectSystemOld->acAuthCode, xDectSystemOld.acAuthCode)){
					print_message("[CFG] : System PIN changed \n");
					/* print_message("[CFG] : Old PIN=%s New PIN =%s\n", 
					pxDectSystemOld->acAuthCode, pxDectSystemNew->acAuthCode); */
					pucBuf = (uchar8*)xDectSystemOld.acAuthCode;
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Pin, &pucBuf, 0);
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
				} else 	if(pxDectSystemOld->ucEncrytionEnable != xDectSystemOld.ucEncrytionEnable){
					printf("[CFG] : Encryption changed to %d\n",pxDectSystemOld->ucEncrytionEnable);
					//aucBuf[0] = LTQ_BaseCapCmd_Encryption;
					//aucBuf[1] = 0;
					pucBuf = aucBuf;
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Capabilities, NULL, xDectSystemOld.ucEncrytionEnable);
					//IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
  			}
			}
			break;
		}
	return IFX_SUCCESS;
}
#endif
#ifdef DECT_SUPPORT
e_IFX_Return IFX_CFG_DectSystemNtfy(x_IFX_VMAPI_DectSystem* pxDectSystemOld,
                       x_IFX_VMAPI_DectSystem* pxDectSystemNew )
{
  x_IFX_DECT_StackCfg xDECTStackCfg={0};
  /* Check for PIN change */
  if(strcmp(pxDectSystemOld->acAuthCode, pxDectSystemNew->acAuthCode))
  {
    print_message("[CFG] : System PIN changed \n");
    /* print_message("[CFG] : Old PIN=%s New PIN =%s\n", 
        pxDectSystemOld->acAuthCode, pxDectSystemNew->acAuthCode); */
    strcpy(xDECTStackCfg.acBasePin,pxDectSystemNew->acAuthCode);
    IFX_DECT_Configure(IFX_DECT_CONFIG_PIN,&xDECTStackCfg);
  }
  if(pxDectSystemOld->ucNoEmo != pxDectSystemNew->ucNoEmo){
    IFX_DECT_MU_NemoConfig((pxDectSystemNew->ucNoEmo==1)?0:1);
  }
  if(pxDectSystemOld->ucEncrytionEnable != pxDectSystemNew->ucEncrytionEnable)
  {
    printf("[CFG] : Encryption changed to %d\n",pxDectSystemNew->ucEncrytionEnable);
    xDECTStackCfg.bEncryption = pxDectSystemNew->ucEncrytionEnable;
    IFX_DECT_Configure(IFX_DECT_CONFIG_ENCRYPT,&xDECTStackCfg);
  }
  if(pxDectSystemOld->ucRfEnable != pxDectSystemNew->ucRfEnable)
  {
		printf("[CFG]: Rf Enable Old:%d new %d\n",pxDectSystemOld->ucRfEnable,pxDectSystemNew->ucRfEnable);
    xDECTStackCfg.bRfEnable = pxDectSystemNew->ucRfEnable;
    IFX_DECT_Configure(IFX_DECT_CONFIG_RF,&xDECTStackCfg);
  }
	
	return IFX_SUCCESS;
}

e_IFX_Return IFX_CFG_DectEnhancedFeatureNtfy(x_IFX_VMAPI_DectSystem* pxDectSystemOld,
                       x_IFX_VMAPI_DectSystem* pxDectSystemNew )
{
	x_IFX_DECT_EnhancedStackCfg xEnhancedStackCfg = {0};
	if((pxDectSystemOld == NULL) || (pxDectSystemNew == NULL) ){
		return IFX_SUCCESS;
	}
  
	if(pxDectSystemOld->ucEarlyEncrytion != pxDectSystemNew->ucEarlyEncrytion){
		printf("[CFG] : Early Encryption changed From %d - to %d\n",
											pxDectSystemOld->ucEarlyEncrytion,
											pxDectSystemNew->ucEarlyEncrytion);
  		/*TODO:Corresponding action api to be called*/
		xEnhancedStackCfg.bEarlyEncryption = pxDectSystemNew->ucEarlyEncrytion;
	}
	else
	{
		xEnhancedStackCfg.bEarlyEncryption = pxDectSystemOld->ucEarlyEncrytion;
	}
	if(pxDectSystemOld->ucReKeying != pxDectSystemNew->ucReKeying)
	{
		printf("[CFG] : Re-Keying changed From %d - to %d\n",
											pxDectSystemOld->ucReKeying,
											pxDectSystemNew->ucReKeying);
		/*TODO:Corresponding action api to be called*/
		xEnhancedStackCfg.bReKeying = pxDectSystemNew->ucReKeying;
	}
	else
	{
		xEnhancedStackCfg.bReKeying = pxDectSystemOld->ucReKeying;
	}
	
	if(pxDectSystemOld->ucUleSupport != pxDectSystemNew->ucUleSupport)
	{
		printf("[CFG] : ULE support changed From %d - to %d\n",
											pxDectSystemOld->ucUleSupport,
											pxDectSystemNew->ucUleSupport);
		/*TODO:Corresponding action api to be called*/
		xEnhancedStackCfg.bULESupport = pxDectSystemNew->ucUleSupport;
	}
	else
	{
		xEnhancedStackCfg.bULESupport = pxDectSystemOld->ucUleSupport;
	}
    if(pxDectSystemOld->ucRepeaterSupp != pxDectSystemNew->ucRepeaterSupp)
    {
        printf("[CFG] : Repeater Support changed From %d - to %d\n",
                                            pxDectSystemOld->ucRepeaterSupp,
                                            pxDectSystemNew->ucRepeaterSupp);
        /*TODO:Corresponding action api to be called*/
		xEnhancedStackCfg.bRepeaterSupport= pxDectSystemNew->ucRepeaterSupp;
    }
	else
	{
		xEnhancedStackCfg.bRepeaterSupport= pxDectSystemOld->ucRepeaterSupp;
	}
    if(pxDectSystemOld->ucJDECTSupp != pxDectSystemNew->ucJDECTSupp)
    {
        printf("[CFG] : JDECT support changed From %d - to %d\n",
                                            pxDectSystemOld->ucJDECTSupp,
                                            pxDectSystemNew->ucJDECTSupp);
        /*TODO:Corresponding action api to be called*/
		xEnhancedStackCfg.bJapanDECTSupport= pxDectSystemNew->ucJDECTSupp;
    }
	else
	{
		xEnhancedStackCfg.bJapanDECTSupport= pxDectSystemOld->ucJDECTSupp;
	}
    if(pxDectSystemOld->ucRealCN != pxDectSystemNew->ucRealCN)
    {
        printf("[CFG] : Real Carrier Number changed From %d - to %d\n",
                                            pxDectSystemOld->ucRealCN,
                                            pxDectSystemNew->ucRealCN);
        /*TODO:Corresponding action api to be called*/
		xEnhancedStackCfg.bUseRealCN=pxDectSystemNew->ucRealCN;
    }
	else
	{
		xEnhancedStackCfg.bUseRealCN=pxDectSystemOld->ucRealCN;
	}
	IFX_DECT_UpdateEnhancedFeatures(&xEnhancedStackCfg);
    
	return IFX_SUCCESS;
}

e_IFX_Return 
IFX_CFG_Diagnostics(uchar8 ucStartTest)
{


  switch(ucStartTest){
  
    case 0:

        IFX_DECT_DIAG_ModemDiagnostics(0);
        //vuiDiagMode = 0; 
	      break;

	  case 1:

        IFX_DECT_DIAG_ModemDiagnostics(1);
        //vuiDiagMode = 1; 
	      break;

	  case 2:

        IFX_DECT_DIAG_ModemRestart();
	      break;

		default:
		    break;		
  }
  return IFX_SUCCESS;
}
#endif

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
e_IFX_Return 
IFX_CFG_BMCRegParamsNtfy(uchar8 ucOpMode,
                         x_IFX_VMAPI_DectBMCParams* pxBmcOld, 
	                       x_IFX_VMAPI_DectBMCParams* pxBmcNew )
{
  x_IFX_VMAPI_DectBMCParams xBmc_vmapi = {{{{0}}}};
#if defined(DECT_SUPPORT)
  x_IFX_DECT_BMCRegParams xBmc_dect = {0};
  
  switch(ucOpMode){
	  case 1:

		    IFX_DECT_DIAG_BmcGet(&xBmc_dect);
	      memcpy(&xBmc_vmapi.ucDectRSSIFreeLevel,&xBmc_dect,14);	
	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_BMC_REG_PARAMS_TEST,&xBmc_vmapi);
        break;

  	case 2:
	      memcpy(&xBmc_dect,&pxBmcOld->ucDectRSSIFreeLevel,14);	
	      memcpy(&xBmc_vmapi.ucDectRSSIFreeLevel,&xBmc_dect,14);	
	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_BMC_REG_PARAMS_TEST,&xBmc_vmapi);
        IFX_DECT_DIAG_BmcSet(&xBmc_dect);
        IFX_DECT_DIAG_ModemRestart();
#elif defined(CVOIP_SUPPORT)
  x_IFX_VMAPI_DectBMCParams xBmcOld = {{{{0}}}};
	IFX_CIF_BMCRegparamGet(&xBmcOld);
	if (memcmp(&xBmcOld.ucDectRSSIFreeLevel, &pxBmcOld->ucDectRSSIFreeLevel, 16) == 0){
		printf("nothing is changed in BMC\n");
		return IFX_SUCCESS;
	}
  switch(ucOpMode){
	  case 2:
	  case 0:
			{
				uchar8 *pucBuf = (uchar8*)&xBmc_vmapi.ucDectRSSIFreeLevel;
	      memcpy(&xBmc_vmapi.ucDectRSSIFreeLevel,&pxBmcNew->ucDectRSSIFreeLevel,16);	
	      //IFX_CIF_StoreValuesFromModem(IFX_VMAPI_BMC_REG_PARAMS_TEST,&xBmc_vmapi);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_BMC, &pucBuf, 0);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
			}
#endif
        break;

		default:
				break;
  }
  return IFX_SUCCESS;
} 



e_IFX_Return 
IFX_CFG_TransmitPowerNtfy(uchar8 ucOpMode,
                          x_IFX_VMAPI_TransmitPowerParam* pxTpOld, 
	                        x_IFX_VMAPI_TransmitPowerParam* pxTpNew )
{
  x_IFX_VMAPI_TransmitPowerParam xTpc = {{{{0}}}};
#ifdef DECT_SUPPORT
  x_IFX_DECT_TransmitPowerParam xTp = {0};

  switch(ucOpMode){

	  case 1:

		    IFX_DECT_DIAG_TPCGet(&xTp);
        memcpy(&xTpc.ucTuneDigitalRef,&xTp,sizeof(x_IFX_DECT_TransmitPowerParam));
	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_TRANS_POWER_TEST,&xTpc);
        break;

	  case 2:
		
        memcpy(&xTp,&pxTpOld->ucTuneDigitalRef,sizeof(x_IFX_DECT_TransmitPowerParam));
        memcpy(&xTpc.ucTuneDigitalRef,&xTp,sizeof(x_IFX_DECT_TransmitPowerParam));
        IFX_CIF_StoreValuesFromModem(IFX_VMAPI_TRANS_POWER_TEST,&xTpc);
		    IFX_DECT_DIAG_TPCSet(&xTp);
        break;

		default:
	      break;			
  }
        //IFX_DECT_DIAG_ModemRestart();
#elif defined(CVOIP_SUPPORT)
  x_IFX_VMAPI_TransmitPowerParam xTpcOld = {{{{0}}}};
	if(pxTpNew == NULL) {
			IFX_CIF_TPCValGet(&xTpcOld);
			if (memcmp(&xTpcOld.ucTuneDigitalRef, &pxTpOld->ucTuneDigitalRef, 23) == 0){
						printf("Nothing is changed in TPC\n");
						return IFX_SUCCESS;
			}
        memcpy(&xTpc.ucTuneDigitalRef,&xTpcOld.ucTuneDigitalRef, 23);
	}else{
			if (memcmp(&pxTpNew->ucTuneDigitalRef, &pxTpOld->ucTuneDigitalRef, 23) == 0){
						printf("Nothing is changed in TPC\n");
						return IFX_SUCCESS;
				}
        memcpy(&xTpc.ucTuneDigitalRef,&pxTpNew->ucTuneDigitalRef, 23);
	}
  switch(ucOpMode){

	  case 0:
	  case 2:
			{
				uchar8 *pucBuf = (uchar8*)&xTpc.ucTuneDigitalRef;
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_TPC, &pucBuf, 0);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
			}
        break;

		default:
	      break;			
  }
#endif
  return IFX_SUCCESS;

}

e_IFX_Return 
IFX_CFG_OscTrimNtfy(uchar8 ucOpMode, 
		                x_IFX_VMAPI_DectOscTrimVal *pxOscOld, 
	                  x_IFX_VMAPI_DectOscTrimVal *pxOscNew )
{
  
  x_IFX_VMAPI_DectOscTrimVal xOscTrim={{{{0}}}};
  

  switch(ucOpMode){
#ifdef DECT_SUPPORT
	  case 1:
			{
  			uint16 unOscTrim = 0;
        IFX_DECT_DIAG_OscTrimGet(&unOscTrim);

		    xOscTrim.ucDectOscTrimValHI = unOscTrim >> 8;
		    xOscTrim.ucDectOscTrimValLOW = unOscTrim & 0X00FF;
		    xOscTrim.ucDectP10Status = 1;//Ask

	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_OSC_TRIM_TEST,&xOscTrim);
			}
      break;
	  case 2:
			{
  			uint16 unOscTrim = 0;
        unOscTrim = pxOscOld->ucDectOscTrimValLOW;
		    unOscTrim |= (pxOscOld->ucDectOscTrimValHI << 8);

	  	  xOscTrim.ucDectOscTrimValHI = pxOscOld->ucDectOscTrimValHI;
	  	  xOscTrim.ucDectOscTrimValLOW = pxOscOld->ucDectOscTrimValLOW;
		    xOscTrim.ucDectP10Status = 1;//Ask

	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_OSC_TRIM_TEST,&xOscTrim);
        IFX_DECT_DIAG_OscTrimSet(unOscTrim,1);
			}
#elif defined(CVOIP_SUPPORT)
	  case 0:
	  case 2:
			{
				uchar8 *pucBuf = (uchar8*)&xOscTrim.ucDectOscTrimValHI;
  			x_IFX_VMAPI_DectOscTrimVal xOscTrimNew={{{{0}}}};
				if (pxOscNew == NULL) {
						IFX_CIF_OscTrimParamGet(&xOscTrimNew);
						if (memcmp(&xOscTrimNew.ucDectOscTrimValHI, &pxOscOld->ucDectOscTrimValHI, 3) == 0){
									printf("nothing is changed in Osc\n");
									return IFX_SUCCESS;
						}
		        xOscTrim.ucDectOscTrimValHI = xOscTrimNew.ucDectOscTrimValHI;
    		    xOscTrim.ucDectOscTrimValLOW = xOscTrimNew.ucDectOscTrimValLOW;
        		xOscTrim.ucDectP10Status = 1;
				}else {
						if (memcmp(&pxOscNew->ucDectOscTrimValHI, &pxOscOld->ucDectOscTrimValHI, 3) == 0){
                  printf("nothing is changed in Osc\n");
                  return IFX_SUCCESS;
            }
		        xOscTrim.ucDectOscTrimValHI = pxOscNew->ucDectOscTrimValHI;
    		    xOscTrim.ucDectOscTrimValLOW = pxOscNew->ucDectOscTrimValLOW;
        		xOscTrim.ucDectP10Status = 1;
				}
        //IFX_CIF_StoreValuesFromModem(IFX_VMAPI_OSC_TRIM_TEST,&xOscTrim);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_OscTrim, &pucBuf, 0);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
			}
#endif
        break;
	
    default:
        break;    
  }
  return IFX_SUCCESS;
}

e_IFX_Return 
IFX_CFG_GfskNtfy(uchar8 ucOpMode,
		             x_IFX_VMAPI_DectGFSKVal *pxGfskOld, 
	               x_IFX_VMAPI_DectGFSKVal *pxGfskNew )
{
  
  x_IFX_VMAPI_DectGFSKVal xGfsk={{{{0}}}};
  

  switch(ucOpMode){

#ifdef DECT_SUPPORT
	  case 1:
			{
  			uint16 unGfsk = 0;
        IFX_DECT_DIAG_GfskGet(&unGfsk);

		    xGfsk.ucDectGFSKHI = unGfsk >> 8;
		    xGfsk.ucDectGFSKLOW = unGfsk & 0X00FF;

	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_GFSK_TEST,&xGfsk);
			}
        break;

    case 2:
			{
  			uint16 unGfsk = 0;
        unGfsk = pxGfskOld->ucDectGFSKHI;
        unGfsk <<= 8;
		    unGfsk |= pxGfskOld->ucDectGFSKLOW;

		    xGfsk.ucDectGFSKHI = pxGfskOld->ucDectGFSKHI;
		    xGfsk.ucDectGFSKLOW = pxGfskOld->ucDectGFSKLOW;


	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_GFSK_TEST,&xGfsk);
        IFX_DECT_DIAG_GfskSet(unGfsk);
			}
        //IFX_DECT_DIAG_ModemRestart();
#elif defined(CVOIP_SUPPORT)
		case 0:
	  case 2:
			{
			uchar8 *pucBuf = (uchar8*)&xGfsk.ucDectGFSKHI;
  		x_IFX_VMAPI_DectGFSKVal xGfskNew={{{{0}}}};
			if(pxGfskNew == NULL) {
				IFX_CIF_GaussianValGet(&xGfskNew);
				if(memcmp(&xGfskNew.ucDectGFSKHI,&pxGfskOld->ucDectGFSKHI, 2) == 0){
					printf("No change in GFSK\n");
					return IFX_SUCCESS;
				}
				xGfsk.ucDectGFSKHI = xGfskNew.ucDectGFSKHI;
				xGfsk.ucDectGFSKLOW = xGfskNew.ucDectGFSKLOW;
			}else {
				if(memcmp(&pxGfskNew->ucDectGFSKHI,&pxGfskOld->ucDectGFSKHI, 2) == 0){
					printf("No change in GFSK\n");
					return IFX_SUCCESS;
				}
				xGfsk.ucDectGFSKHI = pxGfskNew->ucDectGFSKHI;
				xGfsk.ucDectGFSKLOW = pxGfskNew->ucDectGFSKLOW;
			}
			//IFX_CIF_StoreValuesFromModem(IFX_VMAPI_GFSK_TEST,&xGfsk);
			IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Gfsk, &pucBuf, 0);
			IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
			}
#endif
        break;
	
    default:
        break;
  }
  return IFX_SUCCESS;
}
e_IFX_Return 
IFX_CFG_RFModeNtfy(uchar8 ucOpMode,
		               x_IFX_VMAPI_RFMode* pxRfOld, 
	                 x_IFX_VMAPI_RFMode* pxRfNew )
{
  x_IFX_VMAPI_RFMode xRfmode={{{{0}}}};
  
  printf("\nucOpMode=%d\n",ucOpMode);
  
  switch(ucOpMode){

#ifdef DECT_SUPPORT
	  case 1:
			{
  			uchar8 ucRFMode;
  			uchar8 ucSlotNumber;
  			uchar8 ucChannelNumber;

        IFX_DECT_DIAG_RfTestModeGet(&ucRFMode,&ucChannelNumber,&ucSlotNumber);
        
		    xRfmode.ucTxtestmode = ucRFMode;
		    xRfmode.ucChannel = ucChannelNumber;
		    xRfmode.ucSlot = ucSlotNumber;
		
	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_RF_MODE_TEST,&xRfmode);

			}
        break;
		
	  case 2:
			{
		    xRfmode.ucTxtestmode = pxRfOld->ucTxtestmode;
		    xRfmode.ucChannel = pxRfOld->ucChannel;
		    xRfmode.ucSlot = pxRfOld->ucSlot;
		
	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_RF_MODE_TEST,&xRfmode);
        IFX_DECT_DIAG_RfTestModeSet(pxRfOld->ucTxtestmode,
		                pxRfOld->ucChannel,pxRfOld->ucSlot);
			}
#elif defined(CVOIP_SUPPORT)
	  case 0:
	  case 2:
			{
				uchar8 *pucBuf = (uchar8*)&xRfmode.ucTxtestmode;
				if(pxRfNew == NULL ) {
		    	xRfmode.ucTxtestmode = pxRfOld->ucTxtestmode;
		    	xRfmode.ucChannel = pxRfOld->ucChannel;
		    	xRfmode.ucSlot = pxRfOld->ucSlot;
				}else {
						xRfmode.ucTxtestmode = pxRfNew->ucTxtestmode;
		        xRfmode.ucChannel = pxRfNew->ucChannel;
    	      xRfmode.ucSlot = pxRfNew->ucSlot;
				}
	      //IFX_CIF_StoreValuesFromModem(IFX_VMAPI_RF_MODE_TEST,&xRfmode);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_RfMode, &pucBuf, 0);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
			}
#endif
        break;
	
    default:
        break;
  }
		
	return IFX_SUCCESS;

}

e_IFX_Return
IFX_CFG_RfpiNtfy(uchar8 ucOpMode,
                 x_IFX_VMAPI_DectRfpi* pxRfpiold,
                 x_IFX_VMAPI_DectRfpi* pxRfpinew )
{
  char8 aucRfpi[5]={'\0'};
  printf("\nucOpMode=%d\n",ucOpMode);
  if(memcmp(pxRfpiold,pxRfpinew,sizeof(x_IFX_VMAPI_DectRfpi))==0){
   return IFX_SUCCESS;
  } 
  switch(ucOpMode){

#ifdef DECT_SUPPORT
	  case 2:
			{
    		aucRfpi[0] = pxRfpiold->ucByte1;
		    aucRfpi[1] = pxRfpiold->ucByte2;
		    aucRfpi[2] = pxRfpiold->ucByte3;
		    aucRfpi[3] = pxRfpiold->ucByte4;
		    aucRfpi[4] = pxRfpiold->ucByte5;
				printf("setting rfpi byte0 is %x, \n",pxRfpiold->ucByte1);
  			x_IFX_VMAPI_DectRfpi xRfpi={{{{0}}}};
        memcpy(&xRfpi,pxRfpiold,sizeof(x_IFX_VMAPI_DectRfpi));
	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_RFPI_TEST,&xRfpi);
		    IFX_DECT_DIAG_RFPISet(&aucRfpi[0]);
        IFX_DECT_DIAG_ModemRestart();
#elif defined(CVOIP_SUPPORT)
	  case 0:
	  case 2:
		{
				uchar8 *pucBuf = (uchar8*)aucRfpi;
			if(pxRfpinew != NULL) {
	   		aucRfpi[0] = pxRfpinew->ucByte1;
		    aucRfpi[1] = pxRfpinew->ucByte2;
		    aucRfpi[2] = pxRfpinew->ucByte3;
		    aucRfpi[3] = pxRfpinew->ucByte4;
		    aucRfpi[4] = pxRfpinew->ucByte5;
			}else {
    		aucRfpi[0] = pxRfpiold->ucByte1;
		    aucRfpi[1] = pxRfpiold->ucByte2;
		    aucRfpi[2] = pxRfpiold->ucByte3;
		    aucRfpi[3] = pxRfpiold->ucByte4;
		    aucRfpi[4] = pxRfpiold->ucByte5;
			}
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Rfpi, &pucBuf, 0);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
#endif
			}
        break;

    default:
				break;
  }
  return IFX_SUCCESS;
}

#if defined (DECT_SUPPORT) || defined (CVOIP_SUPPORT)
e_IFX_Return 
IFX_CFG_XramNtfy(uchar8 ucOpMode,
		             x_IFX_VMAPI_DectXRAM *pxXramOld, 
	               x_IFX_VMAPI_DectXRAM *pxXramNew )
{
  
  x_IFX_VMAPI_DectXRAM xXram={{{{0}}}};
#ifdef DECT_SUPPORT
	uint16 unAddr = 0;
  char8 xGet[10] = {'\0'};
  char8 xBuf[10] = {'\0'};
#endif
  uchar8 ucIsSfr = ucOpMode >> 7;
 
  ucOpMode &= 0x7F; 

  printf("\n ucOpMode = %d,ucIsSfr = %d\n",ucOpMode,ucIsSfr);

  switch(ucOpMode){
#ifdef DECT_SUPPORT
	  case 1:


        unAddr = pxXramOld->ucByte1;
		    unAddr = unAddr << 8;
		    unAddr |= pxXramOld->ucByte2 ;
        IFX_DECT_DIAG_MEMGet(ucIsSfr?0:1,unAddr,&xGet[0],10);


        xXram.ucByte1 = pxXramOld->ucByte1;      
        xXram.ucByte2 = pxXramOld->ucByte2;      
        memcpy(&xXram.ucByte3,&xGet[0],10);

	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_XRAM_TEST,&xXram);
        break;

    case 2:

        unAddr = pxXramOld->ucByte1;
		    unAddr = unAddr << 8;
		    unAddr |= pxXramOld->ucByte2 ;
		    memcpy(&xBuf[0],&pxXramOld->ucByte3,7);

        xXram.ucByte1 = pxXramOld->ucByte1;      
        xXram.ucByte2 = pxXramOld->ucByte2;      
        memcpy(&xXram.ucByte3,&pxXramOld->ucByte3,7);

	      IFX_CIF_StoreValuesFromModem(IFX_VMAPI_XRAM_TEST,&xXram);
        IFX_DECT_DIAG_MEMSet(ucIsSfr?0:1,unAddr,&xBuf[0],7);
#elif defined(CVOIP_SUPPORT)
	  case 1:
			break;

	  case 2:
	  case 0:
			{
				uchar8 *pucBuf = (uchar8*)&xXram.ucByte1;
				if(pxXramNew == NULL){
    	  	xXram.ucByte1 = pxXramOld->ucByte1;      
  	      xXram.ucByte2 = pxXramOld->ucByte2;      
      	  memcpy(&xXram.ucByte3,&pxXramOld->ucByte3,7);	
				}else {
    	  	xXram.ucByte1 = pxXramNew->ucByte1;      
  	      xXram.ucByte2 = pxXramNew->ucByte2;      
      	  memcpy(&xXram.ucByte3,&pxXramNew->ucByte3,7);	
				}
	      //IFX_CIF_StoreValuesFromModem(IFX_VMAPI_XRAM_TEST,&xXram);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_RAM, &pucBuf, ucIsSfr?1:0);
				//IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
			}
#endif
        break;
	
    default:
        break;
  }
  return IFX_SUCCESS;
}  

#endif
e_IFX_Return
IFX_CFG_CtrySetNtfy(uchar8 ucOpMode,
                    x_IFX_VMAPI_DectCountrySettings* pxCtrySettold,
                    x_IFX_VMAPI_DectCountrySettings* pxCtrySettnew )
{
  x_IFX_VMAPI_DectCountrySettings xCtryset={{{{0}}}};

  if(memcmp(pxCtrySettold,pxCtrySettnew,sizeof(x_IFX_VMAPI_DectCountrySettings))==0){
   return IFX_SUCCESS;
  } 
  switch(ucOpMode){

	  case 1:
#ifdef DECT_SUPPORT
				{
  			uchar8 ucFreqTx = 0;
  			uchar8 ucFreqRx = 0;
  			uchar8 ucFreqRan = 0;

        IFX_DECT_DIAG_FreqOffGet(&ucFreqTx,&ucFreqRx,&ucFreqRan);

        xCtryset.ucFreqTxOffset = ucFreqTx;
        xCtryset.ucFreqRxOffset = ucFreqRx;
        xCtryset.ucFreqRan = ucFreqRan;


        IFX_CIF_StoreValuesFromModem(IFX_VMAPI_COUNTRY_SETTINGS_TEST,&xCtryset);
        break;
				}
	  case 2:

        xCtryset.ucFreqTxOffset = pxCtrySettold->ucFreqTxOffset;
        xCtryset.ucFreqRxOffset = pxCtrySettold->ucFreqRxOffset;
        xCtryset.ucFreqRan = pxCtrySettold->ucFreqRan;

        IFX_CIF_StoreValuesFromModem(IFX_VMAPI_COUNTRY_SETTINGS_TEST,&xCtryset);
        IFX_DECT_DIAG_FreqOffSet(pxCtrySettold->ucFreqTxOffset,
                 pxCtrySettold->ucFreqRxOffset,pxCtrySettold->ucFreqRan);
        IFX_DECT_DIAG_ModemRestart();
#elif defined(CVOIP_SUPPORT)
	  case 2:
	  case 0:
			{
				uchar8 *pucBuf = (uchar8*)&xCtryset.ucFreqTxOffset;
        if(pxCtrySettnew == NULL){
					xCtryset.ucFreqTxOffset = pxCtrySettold->ucFreqTxOffset;
  	      xCtryset.ucFreqRxOffset = pxCtrySettold->ucFreqRxOffset;
    	    xCtryset.ucFreqRan = pxCtrySettold->ucFreqRan;
    	    xCtryset.ucEci = pxCtrySettold->ucEci;
  	      xCtryset.ucChmaskHigh = pxCtrySettold->ucChmaskHigh;
    	    xCtryset.ucChmaskLow = pxCtrySettold->ucChmaskLow;
				}else {
					xCtryset.ucFreqTxOffset = pxCtrySettnew->ucFreqTxOffset;
  	      xCtryset.ucFreqRxOffset = pxCtrySettnew->ucFreqRxOffset;
    	    xCtryset.ucFreqRan = pxCtrySettnew->ucFreqRan;
    	    xCtryset.ucEci = pxCtrySettnew->ucEci;
  	      xCtryset.ucChmaskHigh = pxCtrySettnew->ucChmaskHigh;
    	    xCtryset.ucChmaskLow = pxCtrySettnew->ucChmaskLow;
				}

        //IFX_CIF_StoreValuesFromModem(IFX_VMAPI_COUNTRY_SETTINGS_TEST,&xCtryset);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Freq, &pucBuf, 0);
				IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
			}
#endif
        break;
	
    default:
        break;
  }
  return IFX_SUCCESS;

}
#endif

/*******************************************************************************
* Function Name    : IFX_CFG_TbrTest 
* Description      : This function starts/stops TBR test case.
* Input Values     : bStartTest - IFX_TRUE - To start test, IFX_FALSE - To stop 
*                    test
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_TbrTest(boolean bStartTest)
{
	print_message("[CFG] : %s TBR6 Test\n", 
			(IFX_TRUE == bStartTest)?"Starting":"Stopping" );
	//IFX_DECT_TBRTest((IFX_TRUE == bStartTest)?1:0);
#ifdef DECT_SUPPORT
	IFX_DECT_DIAG_TBR06Mode((IFX_TRUE == bStartTest)?1:0);
#elif defined(CVOIP_SUPPORT)
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_TBR06, NULL, (IFX_TRUE == bStartTest)?1:0);
	IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Reset, NULL, 0);
#endif
	return IFX_SUCCESS;
}

#ifdef DECT_MODEM_TEST
IFX_CFG_RFTest(uchar8 ucRfTestMode, uchar8 ucChannelNo, uchar8 ucSlotNo )
{
		uchar8 acRFTestParams[8];
		print_message("[CFG] : Starting RF Test \n");
		acRFTestParams[0] = 0x13; //RF Test 
		acRFTestParams[0] = ucRfTestMode; //RF Test type
		acRFTestParams[0] = ucChannelNo; //Channel no 
		acRFTestParams[0] = ucSlotNo; //slot number
		IFX_DECT_DebugCosic(1, 1, 1, acRFTestParams, 4);
}
#endif

#endif //DECT_SUPPORT

#ifdef LTAM
/*******************************************************************************
* Function Name    : IFX_CFG_PhyLineTestNtfy
* Description      : This function starts LTAM test on FXS lines.
*                    If FXS line is idle (that is FXS agent is in idle state),
*                    shutdown the FXS agent and start GR909 test. 
* Input Values     : pxPhyTest - Pointer to x_IFX_VMAPI_VoiceServPhyIfTest
*                    struct containing info about FXS line.
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS
* Notes            : Agent will be re-initialised after completing GR909 test.
*                    (see IFX_CFG_MsgRouterEvtHdlr )
*******************************************************************************/
e_IFX_Return IFX_CFG_PhyLineTestNtfy(x_IFX_VMAPI_VoiceServPhyIfTest* pxPhyTest)
{
	x_IFX_VMAPI_FxsPhyIf xFxsPhyIf = {{{{""}}}};
		
	xFxsPhyIf.xVoiceServPhyIf.ucInterfaceId = pxPhyTest->ucInterfaceId;
	if( IFX_VMAPI_SUCCESS != 
		ifx_get_FxsPhyInterface(&xFxsPhyIf,IFX_CIF_GET_FLAGS) ) {
		print_error("<%s:%d> ERROR : Could Not Retrive %d Interface Info\n", 
			__FUNCTION__, __LINE__,pxPhyTest->ucInterfaceId);
	} else {
		
		x_IFX_AgentStatus xFxsStatus;
		uchar8 ucTestState = IFX_VMAPI_TEST_STATE_FAILURE;
		IFX_FXS_AgentStatus((char8 *)xFxsPhyIf.ucEndPtId, &xFxsStatus);
		if( xFxsStatus.eState == IFX_AGENT_STATE_IDLE ) {
			char8 aszEndpt[1][IFX_MAX_ENDPOINTID_LEN];
			/* shutdown the agent and start line test and update test state to 
				 in progress */
			strcpy(aszEndpt[0], (char8 *)xFxsPhyIf.ucEndPtId);
			if( IFX_SUCCESS == IFX_FXS_AgentShut(aszEndpt,1) ) {
				
				x_IFX_MMGR_GR909_Param xGrParam = {0};

				print_message("<%s:%d> Agent %s is shutdown\n", 
																__FUNCTION__, __LINE__,xFxsPhyIf.ucEndPtId);

				xGrParam.eFreq = IFX_MMGR_GR909_EU_50HZ;
				xGrParam.uiTests = IFX_MMGR_GR909_HPT | IFX_MMGR_GR909_FEMF |
				 									IFX_MMGR_GR909_RFT | IFX_MMGR_GR909_ROH | 
													IFX_MMGR_GR909_RIT ;
				if( IFX_MMGR_SUCCESS !=
						IFX_MMGR_GR909TestStart((char8*)xFxsPhyIf.ucEndPtId, &xGrParam) )
				{
    			print_error("<%s:%d>  ERROR: Could Not start GR909 line test\n", 
						__FUNCTION__, __LINE__);
					print_message("<%s:%d> Restarting Agent %s\n", 
																__FUNCTION__, __LINE__, xFxsPhyIf.ucEndPtId);
					IFX_FXS_AgentInit(aszEndpt,1,vcFXSModId); 
					ucTestState = IFX_VMAPI_TEST_STATE_FAILURE;
				}
				else
					ucTestState = IFX_VMAPI_TEST_STATE_IN_PROGRESS;
			}
		}
		pxPhyTest->ucTestState = ucTestState ;
		ifx_set_PhyInterfaceTest(IFX_CIF_SET_OPP, pxPhyTest, IFX_CIF_MOD_FLAG);
	}
	return IFX_SUCCESS;
}
#endif

/*******************************************************************************
* Function Name    : IFX_CFG_DebugSetttingsNtfyHdlr
* Description      : This function is called when debug setttings are changed.
*                    Update debug settings of all modules
* Input Values     : pxDbgOld - Pointer to x_IFX_VMAPI_SystemDebugSettings, that
                         contains old debug settings
                     pxDbgNew - Pointer to x_IFX_VMAPI_SystemDebugSettings, that
                         contains new debug settings
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS 
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_DebugSetttingsNtfyHdlr(
	                   IN x_IFX_VMAPI_SystemDebugSettings* pxDbgOld,
	                   IN x_IFX_VMAPI_SystemDebugSettings* pxDbgNew )
{
	IFX_DBG_Set("FXO", vcFXOModId, pxDbgNew->xAgentsDbg.ucDbgType, 
		pxDbgNew->xAgentsDbg.ucDbgLvl );
	IFX_DBG_Set("FXS", vcFXSModId, pxDbgNew->xAgentsDbg.ucDbgType,
		pxDbgNew->xAgentsDbg.ucDbgLvl);
#if defined(DECT_SUPPORT)
  IFX_DBG_Set("DECT", vcDECTModId, pxDbgNew->xAgentsDbg.ucDbgType,
		pxDbgNew->xAgentsDbg.ucDbgLvl);
  x_IFX_DECT_StackCfg xDECTStackCfg={0};
  xDECTStackCfg.iDbgType=pxDbgNew->xAgentsDbg.ucDbgType;
  xDECTStackCfg.iDbgLvl=pxDbgNew->xAgentsDbg.ucDbgLvl;
  IFX_DECT_Configure(IFX_DECT_CONFIG_DBG,&xDECTStackCfg);
#elif defined(CVOIP_SUPPORT)
	IFX_DBG_Set("DECT", vcDECTModId, pxDbgNew->xAgentsDbg.ucDbgType, 
		pxDbgNew->xAgentsDbg.ucDbgLvl);
#endif
	IFX_DBG_Set("CM", vcCMModId, pxDbgNew->xCmDbg.ucDbgType, 
		pxDbgNew->xCmDbg.ucDbgLvl);
	IFX_DBG_Set("MM", vcMMModId, pxDbgNew->xMmDbg.ucDbgType, 
		pxDbgNew->xMmDbg.ucDbgLvl);
	IFX_VMAPI_SetDebug(pxDbgNew->xVmapiDbg.ucDbgType, 
		pxDbgNew->xVmapiDbg.ucDbgLvl);
	/* For SIP */
	IFX_SIPAPP_CfgSrvPdr(1,0);
  /* For RTP */
  IFX_RTPAgent_Config(pxDbgNew->xRtpDbg.ucDbgLvl,	
									    pxDbgNew->xRtpDbg.ucDbgType);
#ifdef FAX_SUPPORT	
  /* For Fax */
  IFX_FAXAgent_Config(pxDbgNew->xFaxDbg.ucDbgLvl,	
									    pxDbgNew->xFaxDbg.ucDbgType);	
#endif
	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CFG_NumberingPlanNtfyHdlr
* Description      : This routine is called when Dial Plan rules are changed. 
*                    New dial plan rules.
* Input Values     : pxNumPlanOld - Not used 
*                  : pxNumPlanNew - Not used
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_NumberingPlanNtfyHdlr(
	                   IN x_IFX_VMAPI_NumPlan* pxNumPlanOld,
	                   IN x_IFX_VMAPI_NumPlan* pxNumPlanNew )
{
	return IFX_CFG_PopulateDialPlan();
}

/*******************************************************************************
* Function Name    : IFX_CFG_MiscellaneousNtfyHdlr 
* Description      : This ruotine is called when miscellaneous system parameters
*                    are changed.
* Input Values     : pxMiscOld - Not used
*                    pxMiscNew - Pointer to x_IFX_VMAPI_Misc containing canged
*                      parameters.
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS 
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_MiscellaneousNtfyHdlr(
	                   IN x_IFX_VMAPI_Misc* pxMiscOld,
	                   IN x_IFX_VMAPI_Misc* pxMiscNew)
{
	if( IFX_TRUE == pxMiscNew->bRestoreFactorySettings )
	{
		//Since soft reboot is not working, don't restart application
		//IFX_CFG_RstApp(); 
	}
	if (pxMiscOld->ucDialToneDuration != pxMiscNew->ucDialToneDuration){
		vunDialToneLength = 1000*pxMiscNew->ucDialToneDuration;
		printf("\nDialToneDuration is changed to %d ms\n",vunDialToneLength);
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CFG_ProfileNtfyHdlr 
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            :
*******************************************************************************/
uint32 vunProfNtnTimerId = 0;
void IFX_CFG_ProfNtfnTimeOutHdlr (uint32 uiTimerId,void *pvPvtData);
e_IFX_Return IFX_CFG_ProfileNtfyHdlr(
	                   IN x_IFX_VMAPI_VoiceProfile* pxVpOld, 
	                   IN x_IFX_VMAPI_VoiceProfile* pxVpNew )
{
	uchar8 ucLineId;
	uchar8 ucIndex;
	boolean bUnRegAndSub = IFX_FALSE;
	boolean bCreateSrv = IFX_FALSE;
	boolean bDestroySrv = IFX_FALSE;

	if( IFX_VMAPI_VP_STATE_DISABLED == pxVpNew->ucState && 
		IFX_VMAPI_VP_STATE_DISABLED == pxVpOld->ucState )
	{
		return IFX_SUCCESS;
	}
	
	if( pxVpNew->uiAssocCountry != pxVpOld->uiAssocCountry )
	{
		return IFX_SUCCESS;
	}

	/* Stun configuration changed */
	if( pxVpNew->bEnableStun != pxVpOld->bEnableStun ||
		pxVpNew->xStunConfig.unStunPort != pxVpOld->xStunConfig.unStunPort ||
		pxVpNew->xStunConfig.unNatKeepAliveTime != pxVpOld->xStunConfig.unNatKeepAliveTime ||
		strcasecmp(pxVpNew->xStunConfig.acStunUserName,pxVpOld->xStunConfig.acStunUserName) ||
		strcasecmp(pxVpNew->xStunConfig.acStunServer,pxVpOld->xStunConfig.acStunServer) )
	{
		if(  IFX_VMAPI_VP_STATE_ENABLED == pxVpOld->ucState )
			bDestroySrv = bUnRegAndSub = IFX_TRUE;
		if( IFX_VMAPI_VP_STATE_ENABLED == pxVpNew->ucState )	
			bCreateSrv = IFX_TRUE;
	}

	if( pxVpNew->ucState != pxVpOld->ucState )
	{
		/* 
		 * If profile is enabled, register & subscribe to VM for all lines 
		 * associated with this profile. If profile is disable, un-register & un-
		 * subscribe with VM on all line associated with this profile.
		 */
		if( IFX_VMAPI_VP_STATE_ENABLED == pxVpNew->ucState ){
			bCreateSrv = IFX_TRUE;
		}
		else{
			bDestroySrv = bUnRegAndSub = IFX_TRUE;
		}
	}
	/* Note that if a line addition/deletion on profile is handled in voice 
		 line notification */

	if( bUnRegAndSub )
	{
		for( ucIndex = 0; ucIndex < pxVpOld->ucNoOfLines; ++ucIndex)
		{
			ucLineId = pxVpOld->aucAssoLineIds[ucIndex];
			/* 
			 * FIX: If need to destroy service provider, then  for all lines 
			 * associated with this profile disconnect calls and update registration 
			 * and subscription status
			 */
			if( bDestroySrv )
			{
				IFX_CMGR_CallsDiscForLine( ucLineId );
			}
			IFX_CFG_VLRegister(ucLineId, IFX_FALSE, bDestroySrv );
			IFX_CFG_VLVMSubscribe(ucLineId, IFX_FALSE, bDestroySrv);

		}
	}

	if( bDestroySrv )
	{
		/* 
 		 * Destory service provider and create it. Note that all calls are 
		 * disconnected during service provider destruction.
		 */	
		uchar8 ucLineId;
		/*Stop Profile Notifaction Timer */
		if(vunProfNtnTimerId) {
			IFX_TIM_TimerStop(vunProfNtnTimerId);
			vunProfNtnTimerId = 0;
		}
		
		if( IFX_SUCCESS != IFX_SIPAPP_DestroySrvPdr(pxVpNew->ucProfileId) )
		{
    	print_error("<%s:%d>  ERROR: IFX_SIPAPP_DestroySrvPdr FAILED\n", 
					__FUNCTION__, __LINE__);
		}
		/* We don't wait for unregistration and subscription response, so reset all
		 * lines.
		 */
		for( ucIndex = 0; ucIndex < pxVpNew->ucNoOfLines && ucIndex<IFX_MAX_LINES 
					&& pxVpNew->aucAssoLineIds[ucIndex]<=IFX_MAX_LINES; ++ucIndex)
		{
			ucLineId = pxVpNew->aucAssoLineIds[ucIndex];
			memset((vaxLineInfo+ ucLineId-1),0,sizeof(x_IFX_CFG_LineInfo));
			if (ucLineId>0 && ucLineId<=IFX_MAX_LINES)
				vaxLineInfo[ucLineId-1].ucVoiceLineId = ucLineId;
		}
	}

	if( bCreateSrv )
	{
		if( IFX_SUCCESS != IFX_SIPAPP_CreateSrvPdr(pxVpNew->ucProfileId) )
		{
    	print_error("<%s:%d>  ERROR: IFX_SIPAPP_CreateSrvPdr FAILED. Restarting Application\n",
					__FUNCTION__, __LINE__);
		}
		/* Temp Fix: Since Add profile notification from VMAPI is not received, so
       updating RTP port info now
		*/
		IFX_CIF_UpdateProfilePorts( pxVpNew->ucProfileId );
		/*Start a time before sending New Reg Req - 
			as Notification for ProfSignaling is also expected*/
		IFX_TIM_TimerStart(10000,NULL,0,IFX_CFG_ProfNtfnTimeOutHdlr,&vunProfNtnTimerId);
    printf("<ProfNtnfHdlr> Timer Started with Id = %d\n",vunProfNtnTimerId);
		return IFX_SUCCESS;
	}
	return IFX_SUCCESS;
}
/*******************************************************************************
* Function Name    : 
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            :
*******************************************************************************/
void IFX_CFG_ProfNtfnTimeOutHdlr (uint32 uiTimerId,void *pvPvtData)
{
	x_IFX_VMAPI_VoiceProfile xVpNew = {{{{""}}}};
	uchar8 ucIndex = 0, ucLineId = 0;
	vunProfNtnTimerId = 0;
	printf("<ProfNtfnTimeOutHdlr> Entry\n");
	xVpNew.ucProfileId = 1;

	if( IFX_VMAPI_SUCCESS != 
		ifx_get_VoiceProfile(&xVpNew,IFX_CIF_GET_FLAGS)) {
		return;	
	}

  for( ucIndex = 0; ucIndex < xVpNew.ucNoOfLines; ++ucIndex)
	{
		ucLineId = xVpNew.aucAssoLineIds[ucIndex];
		IFX_CFG_VLRegister(ucLineId, IFX_TRUE, IFX_FALSE);
		IFX_CFG_VLVMSubscribe(ucLineId, IFX_TRUE, IFX_FALSE);
	}
}

/*******************************************************************************
* Function Name    : 
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_ProfileSignalingNtfyHdlr(
	                   IN x_IFX_VMAPI_ProfileSignaling* pxVpSigOld,
	                   IN x_IFX_VMAPI_ProfileSignaling* pxVpSigNew )
{
	x_IFX_VMAPI_VoiceProfile xProfile = {{{{""}}}};
	uchar8 ucIndex;
	boolean bReg = IFX_FALSE;
	boolean bUnReg = IFX_FALSE;
	boolean bRestartNA = IFX_FALSE;
  boolean bIsTimerStarted = IFX_FALSE;
  if(vunProfNtnTimerId != 0) {
		IFX_TIM_TimerStop(vunProfNtnTimerId);
		vunProfNtnTimerId = 0;
		bIsTimerStarted = 1;
		}
    

	xProfile.ucProfileId = pxVpSigNew->ucProfileId ;
	if( (IFX_VMAPI_SUCCESS != ifx_get_VoiceProfile(&xProfile,IFX_CIF_GET_FLAGS)) 
			|| IFX_VMAPI_VP_STATE_ENABLED != xProfile.ucState )
	{
		return IFX_FAILURE;
	}

	if( pxVpSigNew->ucUAProtocol != pxVpSigOld->ucUAProtocol ||
			pxVpSigNew->unUAPort != pxVpSigOld->unUAPort ||
			strcmp(pxVpSigNew->acUADomain, pxVpSigOld->acUADomain) )
	{
		// SIP UA parameters are changed. Need to Restart SIP NA
		bUnReg = bReg = IFX_TRUE;
		bRestartNA = IFX_TRUE;
	}
	else
	{
		IFX_SIPAPP_CfgSrvPdr(pxVpSigNew->ucProfileId,4);
	}
	/*
	 * If registration config changes, take action accordingly
	 */
	if( /*pxVpSigNew->bEnableRegistrar != pxVpSigOld->bEnableRegistrar ||*/
			bIsTimerStarted == 1 ||
			pxVpSigNew->unRegistrarPort != pxVpSigOld->unRegistrarPort ||
			pxVpSigNew->ucRegistrarProtocol != pxVpSigOld->ucRegistrarProtocol ||
			pxVpSigNew->uiRegExpirationTime != pxVpSigOld->uiRegExpirationTime ||
			pxVpSigNew->unRegExpires != pxVpSigOld->unRegExpires ||
			pxVpSigNew->unRegMinExpires != pxVpSigNew->unRegMinExpires ||
      pxVpSigNew->unBackupRegPort != pxVpSigOld->unBackupRegPort ||
			pxVpSigNew->ucBackupRegProtocol != pxVpSigOld->ucBackupRegProtocol ||
			strcasecmp(pxVpSigNew->acBackupRegAddr,pxVpSigOld->acBackupRegAddr) ||
			strcasecmp(pxVpSigNew->acRegistrarAddr,pxVpSigOld->acRegistrarAddr ) ||
			((pxVpSigOld->acRegistrarAddr[0] == 0) &&
			(strcasecmp(pxVpSigNew->acProxyAddr,pxVpSigOld->acProxyAddr ) ||
			pxVpSigNew->unProxyPort != pxVpSigOld->unProxyPort ||
			pxVpSigNew->ucProxyProtocol != pxVpSigOld->ucProxyProtocol)))
	{
		if( IFX_TRUE == pxVpSigOld->bEnableRegistrar ||
			(pxVpSigOld->acRegistrarAddr[0] == 0 && IFX_TRUE == pxVpSigOld->bEnableProxy))
			bUnReg = IFX_TRUE;
		if(IFX_TRUE == pxVpSigNew->bEnableRegistrar ||
			(pxVpSigOld->acRegistrarAddr[0] == 0 && IFX_TRUE == pxVpSigNew->bEnableProxy))
			bReg = IFX_TRUE;
	}	

	if( IFX_TRUE == bUnReg )
	{
  	/* Unregister and unsubscribe for all lines under current profile. If 
			 service provider needs to be destroyed, disconnect all calls for this 
			 line */
		for( ucIndex = 0; ucIndex < xProfile.ucNoOfLines; ++ucIndex)
		{
			if( IFX_TRUE == bRestartNA ) {
				IFX_CMGR_CallsDiscForLine( xProfile.aucAssoLineIds[ucIndex] );
			}
			IFX_CFG_VLRegister(xProfile.aucAssoLineIds[ucIndex], 
													IFX_FALSE, bRestartNA);
			IFX_CFG_VLVMSubscribe(xProfile.aucAssoLineIds[ucIndex], 
													IFX_FALSE, bRestartNA);
		}
	}

	if( IFX_TRUE == bRestartNA )
	{
		uchar8 ucLineId;
		/* Destory service provider and create it */	
		if( IFX_SUCCESS != IFX_SIPAPP_DestroySrvPdr(pxVpSigNew->ucProfileId) )
		{
		}
		/* We don't wait for unregistration and subscription response, so reset all
		 * lines.
		 */
		for( ucIndex = 0; ucIndex < xProfile.ucNoOfLines && ucIndex<IFX_MAX_LINES 
					&& xProfile.aucAssoLineIds[ucIndex]<=IFX_MAX_LINES; ++ucIndex)
		{
			ucLineId = xProfile.aucAssoLineIds[ucIndex];
			memset((vaxLineInfo+ ucLineId-1),0,sizeof(x_IFX_CFG_LineInfo));
			if (ucLineId>0 && ucLineId<=IFX_MAX_LINES)
				vaxLineInfo[ucLineId-1].ucVoiceLineId = ucLineId;
		}

		if( IFX_SUCCESS != IFX_SIPAPP_CreateSrvPdr(pxVpSigNew->ucProfileId) )
		{
    	print_error("<%s:%d>  ERROR: IFX_SIPAPP_CreateSrvPdr FAILED. Restarting Application\n",
					__FUNCTION__, __LINE__);
			bReg = IFX_FALSE;
		}
	}

	if( IFX_TRUE == bReg )
	{
		for( ucIndex = 0; ucIndex < xProfile.ucNoOfLines; ++ucIndex)
		{
			IFX_CFG_VLRegister(xProfile.aucAssoLineIds[ucIndex], IFX_TRUE, IFX_FALSE);
			IFX_CFG_VLVMSubscribe(xProfile.aucAssoLineIds[ucIndex], IFX_TRUE, IFX_FALSE);
		}
	}

	/* If proxy settings changes, no need to do anything */
	return IFX_SUCCESS;
}

/*
 * Handles profile notification.
 */
/*******************************************************************************
* Function Name    : 
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_ProfileEventNtfyHdlr(
	                   IN x_IFX_VMAPI_EventSubscribe* pxVpEventOld,
	                   IN x_IFX_VMAPI_EventSubscribe* pxVpEventNew )
{
	x_IFX_VMAPI_VoiceProfile xProfile = {{{{""}}}};
	uchar8 ucIndex;
  boolean bSubscribe = IFX_FALSE;
  boolean bDontWaitForResp = IFX_FALSE;
  
  if(pxVpEventNew->acNotifierAddr[0] != '\0'){
		bSubscribe = IFX_TRUE;
  }

	if( pxVpEventNew->uiEvent != IFX_VMAPI_VL_SUBS_EVENT_MWI )
		return IFX_SUCCESS ;

	xProfile.ucProfileId = pxVpEventNew->ucProfileId ;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_VoiceProfile(&xProfile,IFX_CIF_GET_FLAGS) &&
			IFX_VMAPI_VP_STATE_ENABLED == xProfile.ucState)
	{
		for( ucIndex = 0; ucIndex < xProfile.ucNoOfLines; ++ucIndex)
		{
			IFX_CFG_VLVMSubscribe(xProfile.aucAssoLineIds[ucIndex], 
														bSubscribe, bDontWaitForResp);
		}
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CFG_ProfileMediaNtfyHdlr 
* Description      :
* Input Values     : 
* Output Values    : None
* Return Value     : 
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_ProfileMediaNtfyHdlr(
	                   IN x_IFX_VMAPI_ProfileMediaRTP* pxMediaOld,
	                   IN x_IFX_VMAPI_ProfileMediaRTP* pxMediaNew )
{
	//x_IFX_VMAPI_VoiceProfile xProfile;
	//boolean bDisconnectCalls =  IFX_FALSE;

	/*
	 * Disconnect calls belonging to this profile if following parameters are 
	 * changed - RTP/FAX port range changes, Jitter buffer 
	 * !!!! Now calls are not disconnected !!!!
	 */
	if( pxMediaNew->unMinRtpPort != pxMediaOld->unMinRtpPort ||
			pxMediaNew->unMaxRtpPort != pxMediaOld->unMaxRtpPort ||
			pxMediaNew->unMinFaxPort != pxMediaOld->unMinFaxPort ||
			pxMediaNew->unMaxFaxPort != pxMediaOld->unMaxFaxPort )
	{
		//TODO: Need to close old ports on firewall & open new ports
		IFX_CIF_UpdateProfilePorts(pxMediaNew->ucProfileId);
		//bDisconnectCalls = IFX_TRUE;
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : 
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_VoiceLineNtfyHdlr(
	                   IN x_IFX_VMAPI_VoiceLine* pxVLOld,
	                   IN x_IFX_VMAPI_VoiceLine* pxVLNew )
{

	boolean bReg = IFX_FALSE;
	boolean bUnReg = IFX_FALSE;
	boolean bDiscCall = IFX_FALSE;
	/*
	 * Check if line association has been changed. If changed, get default voice 
	 * line for each endpoint and assign it.
	 */
	if( memcmp(pxVLNew->ucAssocVoiceInterface,
			pxVLOld->ucAssocVoiceInterface,IFX_VMAPI_MAX_VOICE_INTERFACES) )
	{
		IFX_UpdateEnptDefaultLine();
	}

	if( IFX_VMAPI_VL_STATE_DISABLED == pxVLNew->ucState &&  
			IFX_VMAPI_VL_STATE_DISABLED == pxVLOld->ucState )
	{
		//Nothing to do
		return IFX_SUCCESS;
	}

	if( pxVLNew->ucState != pxVLOld->ucState ) 
	{
		if(pxVLNew->ucState == IFX_VMAPI_VL_STATE_ENABLED)
			bReg = IFX_TRUE;
		else
			bUnReg = IFX_TRUE;

		if( pxVLNew->ucState == IFX_VMAPI_VL_STATE_DISABLED )
			bDiscCall = IFX_TRUE;
	}
	else if( pxVLOld->ucProfileId != pxVLNew->ucProfileId )
	{
		bUnReg = bReg  = bDiscCall = IFX_TRUE;
	}
	else if( strcasecmp(pxVLNew->acDirName, pxVLOld->acDirName) )
	{
		bDiscCall = bUnReg = bReg = IFX_TRUE;
	}	

	if( IFX_TRUE == bDiscCall )
		IFX_CMGR_CallsDiscForLine(pxVLNew->ucLineId);


	if( IFX_TRUE == bUnReg )
	{
		IFX_CFG_VLRegister(pxVLNew->ucLineId, IFX_FALSE,IFX_FALSE);
		IFX_CFG_VLVMSubscribe(pxVLNew->ucLineId, IFX_FALSE, IFX_FALSE);
	}

	if( IFX_TRUE == bReg )
	{
		IFX_CFG_VLRegister(pxVLNew->ucLineId, IFX_TRUE,IFX_FALSE);
		IFX_CFG_VLVMSubscribe(pxVLNew->ucLineId, IFX_TRUE, IFX_FALSE);
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CFG_VlChNotify
* Description      : This routine sends the Line change notification
* Input Values     : None
* Output Values    : None
* Return Value     : None
* Notes            :
*******************************************************************************/
void
IFX_CFG_VlChNotify(IN uint32 uiTimerId,
                   IN void* pvPrivateData)
{
  vuiVlChTimerId=0;
  IFX_CFG_VoiceLineNtfyHdlr(&vxVlTemp.xVlOld,&vxVlTemp.xVlNew);

}


#ifdef LTAM
/*******************************************************************************
* Function Name    : IFX_CFG_MsgRouterEvtHdlr 
* Description      : This function is called by message router after completing
*                    GR909 line testing. In this function GR909 result and test
*                    parameters are updated into configuration and then the FXS
*                    agent is re-initialized.
* Input Values     : pxDevEvents - Pointer to x_IFX_MMGR_DeviceEvents struct
*                    that contians GR909 test results.
* Output Values    : None
* Return Value     : Always returns IFX_SUCCESS
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CFG_MsgRouterEvtHdlr(
	                      IN x_IFX_MMGR_DeviceEvents	*pxDevEvents)
{
	//x_IFX_MMGR_GR909_Result xGR909Result
	x_IFX_VMAPI_VoiceServTestResult xPhyIntTestRes = {{{{""}}}};
	char8 aszEndpt[1][IFX_MAX_ENDPOINTID_LEN];
					
	//print_message("<%s:%d> Got Line Test Result", __FUNCTION__, __LINE__);
	xPhyIntTestRes.xGr909HPTVoltResult.ucResult  = 
		xPhyIntTestRes.xGr909FEMFVoltResult.ucResult = 
		xPhyIntTestRes.xGr909RFTResult.ucResult =
		xPhyIntTestRes.xGr909ROHResult.ucResult =
		xPhyIntTestRes.xGr909RIResult.ucResult = IFX_VMAPI_TEST_RESULT_FAIL;
	
	if( pxDevEvents->xGR909Result.uiPassedResult & IFX_MMGR_GR909_HPT )
	{
		xPhyIntTestRes.xGr909HPTVoltResult.ucResult = IFX_VMAPI_TEST_RESULT_SUCCESS;
   xPhyIntTestRes.xGr909HPTVoltResult.facr2g = pxDevEvents->xGR909Result.nHPT_AC_R2G;
   xPhyIntTestRes.xGr909HPTVoltResult.fact2g = pxDevEvents->xGR909Result.nHPT_AC_T2G;
   xPhyIntTestRes.xGr909HPTVoltResult.fact2r = pxDevEvents->xGR909Result.nHPT_AC_T2R;
   xPhyIntTestRes.xGr909HPTVoltResult.fdcr2g = pxDevEvents->xGR909Result.nHPT_DC_R2G;
   xPhyIntTestRes.xGr909HPTVoltResult.fdct2g = pxDevEvents->xGR909Result.nHPT_DC_R2G;
   xPhyIntTestRes.xGr909HPTVoltResult.fdct2r = pxDevEvents->xGR909Result.nHPT_DC_T2G;
	 
	}
	if( pxDevEvents->xGR909Result.uiPassedResult & IFX_MMGR_GR909_FEMF )
	{
		xPhyIntTestRes.xGr909FEMFVoltResult.ucResult = IFX_VMAPI_TEST_RESULT_SUCCESS;
		xPhyIntTestRes.xGr909FEMFVoltResult.facr2g = pxDevEvents->xGR909Result.nFEMF_AC_R2G;
    xPhyIntTestRes.xGr909FEMFVoltResult.fact2g = pxDevEvents->xGR909Result.nFEMF_AC_T2G;
    xPhyIntTestRes.xGr909FEMFVoltResult.fact2r = pxDevEvents->xGR909Result.nFEMF_AC_T2R;
    xPhyIntTestRes.xGr909FEMFVoltResult.fdcr2g = pxDevEvents->xGR909Result.nFEMF_DC_R2G;
    xPhyIntTestRes.xGr909FEMFVoltResult.fdct2g = pxDevEvents->xGR909Result.nFEMF_DC_R2G;
    xPhyIntTestRes.xGr909FEMFVoltResult.fdct2r = pxDevEvents->xGR909Result.nFEMF_DC_T2G;
	}
	if( pxDevEvents->xGR909Result.uiPassedResult & IFX_MMGR_GR909_RFT )
	{
		xPhyIntTestRes.xGr909RFTResult.ucResult = IFX_VMAPI_TEST_RESULT_SUCCESS;
		xPhyIntTestRes.xGr909RFTResult.fr2g = pxDevEvents->xGR909Result.nRFT_R2G;
		xPhyIntTestRes.xGr909RFTResult.ft2g = pxDevEvents->xGR909Result.nRFT_T2G;
		xPhyIntTestRes.xGr909RFTResult.ft2r = pxDevEvents->xGR909Result.nRFT_T2R;
	}
	if( pxDevEvents->xGR909Result.uiPassedResult & IFX_MMGR_GR909_ROH )
	{
		xPhyIntTestRes.xGr909ROHResult.ucResult = IFX_VMAPI_TEST_RESULT_SUCCESS;
		xPhyIntTestRes.xGr909ROHResult.ft2rl = pxDevEvents->xGR909Result.nROH_T2R_L;
	}
	if( pxDevEvents->xGR909Result.uiPassedResult & IFX_MMGR_GR909_RIT )
	{
		xPhyIntTestRes.xGr909RIResult.ucResult = IFX_VMAPI_TEST_RESULT_SUCCESS;
		xPhyIntTestRes.xGr909RIResult.fRit = pxDevEvents->xGR909Result.nRIT_RES;
	}

	IFX_CIF_LineTestResultSet(pxDevEvents->szEndPtId, &xPhyIntTestRes);

	strcpy(aszEndpt[0], pxDevEvents->szEndPtId);
	if( IFX_SUCCESS != IFX_FXS_AgentInit(aszEndpt,1,vcFXSModId) )
	{
		print_error("<%s:%d> ERROR :  IFX_FXS_AgentInit FAILED\n", 
																										__FUNCTION__, __LINE__);
	}
	return IFX_SUCCESS;
}
#endif

/*******************************************************************************
* Function Name    : IFX_CFG_VmapiNtfyHdlr 
* Description      :  
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     :
* Notes            :
*******************************************************************************/
e_IFX_Return
IFX_CFG_VmapiNtfyHdlr(IN int32 iFd)
{
	uchar8 ucFromAppId;
	uchar8 ucToAppId;
	char8 cErr;
	uint16 unMsgSize;
	uint32 uiRes;
	char8 acMsg[4*1024]; //TODO: Need to get correct value
#ifdef CVOIP_SUPPORT	
	uchar8 aucBuf[6]="?";
  uchar8 *pucBuf = aucBuf;					
#endif
#ifdef VOIP_NEWVMAPI
char8 acInterface[256];
#endif
	if( IFX_IPC_RecvMsg(viVmapiFifoFd, &ucFromAppId, &ucToAppId,
			&unMsgSize, &uiRes, acMsg, &cErr) < 0 )
	{
		 perror("IFX_IPC_RecvMsg :");
		 return IFX_FAILURE;
	}
	else
	{
		char8 *pMsg = acMsg;
		uchar8 ucObjType = *pMsg;
	#if defined (DECT_SUPPORT) || defined (CVOIP_SUPPORT)
		uchar8 ucPrfIf = *(pMsg + 1);
		//uchar8 ucVLId  = *(pMsg + 2);
		//uchar8 ucIndex = *(pMsg + 3);
	#endif

		pMsg +=4; /* Point to object content */

		printf("\n<IFX_CFG_VmapiNtfyHdlr>ObjectType=%d\n",ucObjType);												  
		
		switch(ucObjType)
		{

#ifdef VOIP_NEWVMAPI
        		case IFX_VMAPI_INTERFACE_CHANGE:
			       {
					memset(acInterface,0,256);
					if (unMsgSize-4 < 256) {
						memcpy(acInterface,((char8 *)pMsg),unMsgSize-4);
						IFX_CFG_VoipIfChangeHandlr(acInterface);	
					}
					else {
						printf("\n<IFX_CFG_VmapiNtfyHdlr> Interface name is not proper, ignoring the event\n",ucObjType);
					}
					break;
				}
#endif

			case IFX_VMAPI_PHY_IFACE_FXS:
				{
					x_IFX_VMAPI_FxsPhyIf* pxFxsOld = (x_IFX_VMAPI_FxsPhyIf*)pMsg;
					x_IFX_VMAPI_FxsPhyIf* pxFxsNew = 
											(x_IFX_VMAPI_FxsPhyIf*)(pMsg + sizeof(x_IFX_VMAPI_FxsPhyIf));
					IFX_CFG_FxsEndptNtfyHdlr(pxFxsOld, pxFxsNew);
					break;
				}
			case IFX_VMAPI_PHY_IFACE_FXO:
				{
					x_IFX_VMAPI_FxoPhyIf* pxFxoOld =(x_IFX_VMAPI_FxoPhyIf*)(pMsg);
					x_IFX_VMAPI_FxoPhyIf* pxFxoNew = 
							(x_IFX_VMAPI_FxoPhyIf*)(pMsg + sizeof(x_IFX_VMAPI_FxoPhyIf));
#if 0
          IFX_CFG_FxoLineHdlr(pxFxoOld,pxFxoNew); 
#endif
					IFX_CFG_FxoEndptNtfyHdlr(pxFxoOld, pxFxoNew);
          sleep(5);
					IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_LINE_SETTINGS_PSTN,pxFxoOld,pxFxoNew);
				break;
				}
#if defined (DECT_SUPPORT) || defined (CVOIP_SUPPORT)
			case IFX_VMAPI_PHY_IFACE_DECT:
				{
				 	x_IFX_VMAPI_DectHandset* pxDectOld = 
																					(x_IFX_VMAPI_DectHandset*)pMsg;
				 	x_IFX_VMAPI_DectHandset* pxDectNew = 
						(x_IFX_VMAPI_DectHandset*)(pMsg+sizeof(x_IFX_VMAPI_DectHandset));
					IFX_CFG_DectHandsetChangeNtfyHdlr(pxDectOld,pxDectNew);
		
			#ifdef DECT_SUPPORT
					IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_INTERNAL_NAMES,pxDectOld,pxDectNew);
			#endif
					break;
				}
#endif
#ifdef DECT_SUPPORT
            case IFX_VMAPI_DECT_DIAGNOSTICS:
				{
					IFX_CFG_Diagnostics(ucPrfIf);
					break;
				}
#endif
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
			case IFX_VMAPI_DECT_SYSTEM:
				{
				 	x_IFX_VMAPI_DectSystem* pxDectSystemOld  = 
																					(x_IFX_VMAPI_DectSystem*)pMsg;
				 	x_IFX_VMAPI_DectSystem* pxDectSystemNew = 
						(x_IFX_VMAPI_DectSystem*)(pMsg+sizeof(x_IFX_VMAPI_DectSystem));
#ifdef DECT_SUPPORT
					IFX_CFG_DectSystemNtfy(pxDectSystemOld, pxDectSystemNew );
					IFX_CFG_DectEnhancedFeatureNtfy(pxDectSystemOld, pxDectSystemNew );
#else
					IFX_CFG_DectSystemNtfy(ucPrfIf, pxDectSystemOld, pxDectSystemNew );
#endif
          sleep(2);
					if(pxDectSystemOld->ucRfEnable==pxDectSystemNew->ucRfEnable){
          	IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_SYSTEM_SETTINGS,pxDectSystemOld,pxDectSystemNew);
					}else{
						IFX_CIF_FreeVmapiObj(IFX_CMGR_LA_SYSTEM_SETTINGS,pxDectSystemOld,pxDectSystemNew);
					}
					break;
				}
#ifdef DECT_REPEATER
			case IFX_VMAPI_DECT_REPEATER:
				{
				 	x_IFX_VMAPI_DectRepeater* pxDectOld = (x_IFX_VMAPI_DectRepeater*)pMsg;
					pxDectOld->pxSubsInfo = 
						(x_IFX_VMAPI_DectSubsInfo *)(pMsg+sizeof(x_IFX_VMAPI_DectRepeater));
				 	
					x_IFX_VMAPI_DectRepeater* pxDectNew = 
						(x_IFX_VMAPI_DectRepeater*)(pMsg+sizeof(x_IFX_VMAPI_DectRepeater) + sizeof(x_IFX_VMAPI_DectSubsInfo));
				 	pxDectNew->pxSubsInfo = 
						(x_IFX_VMAPI_DectSubsInfo *)(pMsg+ ( 2*sizeof(x_IFX_VMAPI_DectRepeater)) + sizeof(x_IFX_VMAPI_DectSubsInfo));
					IFX_CFG_DectRepeaterChangeNtfyHdlr(pxDectOld,pxDectNew);
		
					break;
				}
#endif

			case IFX_VMAPI_TBR6_TEST:
				{
					IFX_CFG_TbrTest((ucPrfIf == 1)?IFX_TRUE:IFX_FALSE);
					break;
				}
#ifdef DECT_MODEM_TEST
			case IFX_VMAPI_ /* ??? */:
				{
					IFX_CFG_RFTest(ucRfTestMode, ucChannelNo, ucSlotNo );
					break;
				}
#endif
    	case IFX_VMAPI_TRANS_POWER_TEST:
				{
				 	x_IFX_VMAPI_TransmitPowerParam* pxTpOld  = 
									(x_IFX_VMAPI_TransmitPowerParam*)pMsg;
				 	x_IFX_VMAPI_TransmitPowerParam* pxTpNew = 
						(x_IFX_VMAPI_TransmitPowerParam*)(pMsg+sizeof(x_IFX_VMAPI_TransmitPowerParam));
					IFX_CFG_TransmitPowerNtfy(ucPrfIf,pxTpOld, pxTpNew );
					break;
				}

    	case IFX_VMAPI_BMC_REG_PARAMS_TEST:
				{
				 	x_IFX_VMAPI_DectBMCParams* pxBmcOld  = 
										(x_IFX_VMAPI_DectBMCParams*)pMsg;
				  x_IFX_VMAPI_DectBMCParams* pxBmcNew = 
						( x_IFX_VMAPI_DectBMCParams*)(pMsg+sizeof( x_IFX_VMAPI_DectBMCParams));
					IFX_CFG_BMCRegParamsNtfy(ucPrfIf,pxBmcOld, pxBmcNew );
					break;
				}

    	case IFX_VMAPI_OSC_TRIM_TEST:
				{
				 	x_IFX_VMAPI_DectOscTrimVal* pxOscOld  = (x_IFX_VMAPI_DectOscTrimVal*)pMsg;
				 	x_IFX_VMAPI_DectOscTrimVal* pxOscNew = 
						(x_IFX_VMAPI_DectOscTrimVal*)(pMsg+sizeof(x_IFX_VMAPI_DectOscTrimVal));
					IFX_CFG_OscTrimNtfy(ucPrfIf, pxOscOld, pxOscNew );
					break;
				}

    	case IFX_VMAPI_GFSK_TEST:
				{
				 	x_IFX_VMAPI_DectGFSKVal* pxGfskOld  = (x_IFX_VMAPI_DectGFSKVal*)pMsg;
				 	x_IFX_VMAPI_DectGFSKVal* pxGfskNew = 
						(x_IFX_VMAPI_DectGFSKVal*)(pMsg+sizeof(x_IFX_VMAPI_DectGFSKVal));
					IFX_CFG_GfskNtfy(ucPrfIf, pxGfskOld, pxGfskNew );
					break;
				}
    	case IFX_VMAPI_RF_MODE_TEST:
				{
				 	x_IFX_VMAPI_RFMode* pxRfOld  = (x_IFX_VMAPI_RFMode*)pMsg;
				 	x_IFX_VMAPI_RFMode* pxRfNew = 
						(x_IFX_VMAPI_RFMode*)(pMsg+sizeof(x_IFX_VMAPI_RFMode));
					IFX_CFG_RFModeNtfy(ucPrfIf, pxRfOld, pxRfNew );
					break;
				}
        case IFX_VMAPI_RFPI_TEST:
                {
				 x_IFX_VMAPI_DectRfpi* pxRfpiold  = (x_IFX_VMAPI_DectRfpi*)pMsg;
				 x_IFX_VMAPI_DectRfpi* pxRfpinew = 
				           (x_IFX_VMAPI_DectRfpi*)(pMsg+sizeof(x_IFX_VMAPI_DectRfpi));
																  
                 IFX_CFG_RfpiNtfy(ucPrfIf, pxRfpiold, pxRfpinew );
				 break;
				}
//#if 0
        case IFX_VMAPI_XRAM_TEST:
                {
				 x_IFX_VMAPI_DectXRAM* pxXramold  = (x_IFX_VMAPI_DectXRAM*)pMsg;
				 x_IFX_VMAPI_DectXRAM* pxXramnew = 
				         (x_IFX_VMAPI_DectXRAM*)(pMsg+sizeof(x_IFX_VMAPI_DectXRAM));
																  
                 IFX_CFG_XramNtfy(ucPrfIf, pxXramold, pxXramnew );
				 break;
				}
//#endif
        case IFX_VMAPI_COUNTRY_SETTINGS_TEST:
                {
				 x_IFX_VMAPI_DectCountrySettings* pxCtrysettold  = (x_IFX_VMAPI_DectCountrySettings*)pMsg;
				 x_IFX_VMAPI_DectCountrySettings* pxCtrysettnew = 
				           (x_IFX_VMAPI_DectCountrySettings*)(pMsg+sizeof(x_IFX_VMAPI_DectCountrySettings));
				 printf("\n<IFX_CFG_VmapiNtfyHdlr>ucPrfIf=%d\n",ucPrfIf);												  
                 IFX_CFG_CtrySetNtfy(ucPrfIf, pxCtrysettold, pxCtrysettnew );
				 break;
				}
																						 
#endif
			case IFX_VMAPI_VOICE_PROFILE:
				{
					x_IFX_VMAPI_VoiceProfile* pxVpOld = (x_IFX_VMAPI_VoiceProfile*)(pMsg);
					x_IFX_VMAPI_VoiceProfile* pxVpNew = 
						(x_IFX_VMAPI_VoiceProfile*)(pMsg + sizeof(x_IFX_VMAPI_VoiceProfile));
					IFX_CFG_ProfileNtfyHdlr(pxVpOld,pxVpNew);
					break;
				}
			case IFX_VMAPI_DELETE_PROFILE:
				{
					x_IFX_VMAPI_VoiceProfile* pxVp = (x_IFX_VMAPI_VoiceProfile*)(pMsg);
					x_IFX_VMAPI_VoiceProfile xVpOld;

					memcpy(&xVpOld, pxVp, sizeof(x_IFX_VMAPI_VoiceProfile));
					xVpOld.ucState =  IFX_VMAPI_VP_STATE_ENABLED;
					pxVp->ucState = IFX_VMAPI_VP_STATE_DISABLED;
					IFX_CFG_ProfileNtfyHdlr(&xVpOld, pxVp);
					break;
				}
			case IFX_VMAPI_VP_SIGNALING:
				{	
					x_IFX_VMAPI_ProfileSignaling* pxVpSigOld = 
																					(x_IFX_VMAPI_ProfileSignaling*)pMsg;
					x_IFX_VMAPI_ProfileSignaling* pxVpSigNew = 
								(x_IFX_VMAPI_ProfileSignaling*)(pMsg + 
																				sizeof(x_IFX_VMAPI_ProfileSignaling));

					IFX_CFG_ProfileSignalingNtfyHdlr(pxVpSigOld,pxVpSigNew);
					break;
				}
			//case IFX_VMAPI_VP_EVENT_SUBSCR:
			case IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY:
				{
					x_IFX_VMAPI_EventSubscribe* pxVpEvntOld = 
																					(x_IFX_VMAPI_EventSubscribe*)(pMsg);
					x_IFX_VMAPI_EventSubscribe* pxVpEvntNew = 
											(x_IFX_VMAPI_EventSubscribe*)(pMsg + 
																					sizeof(x_IFX_VMAPI_EventSubscribe));
					
					IFX_CFG_ProfileEventNtfyHdlr(pxVpEvntOld, pxVpEvntNew);
					break;
				}
			case IFX_VMAPI_VP_RTP:
				{
					x_IFX_VMAPI_ProfileMediaRTP* pxPrfMediaOld = 
																		(x_IFX_VMAPI_ProfileMediaRTP*)(pMsg);
					x_IFX_VMAPI_ProfileMediaRTP* pxPrfMediaNew = 
													(x_IFX_VMAPI_ProfileMediaRTP*)(pMsg+ 
																			sizeof(x_IFX_VMAPI_ProfileMediaRTP));
					
					IFX_CFG_ProfileMediaNtfyHdlr(pxPrfMediaOld, pxPrfMediaNew);
					break;
				}

				case IFX_VMAPI_ADD_LINE:
					{
					  printf("Add Voice Line!!\n");		
						x_IFX_VMAPI_VoiceLine* pxVL = 
							(x_IFX_VMAPI_VoiceLine*)(pMsg+sizeof(x_IFX_VMAPI_VoiceLine));
					  IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_LINE_SETTINGS_ASSOC,NULL,pxVL);
						break;
					}

				case IFX_VMAPI_DELETE_LINE:
					{
						x_IFX_VMAPI_VoiceLine* pxVL = (x_IFX_VMAPI_VoiceLine*)(pMsg);
						x_IFX_VMAPI_VoiceLine xVL;
						memcpy(&xVL,pxVL, sizeof(x_IFX_VMAPI_VoiceLine));
						xVL.ucState = IFX_VMAPI_VL_STATE_ENABLED;
						pxVL->ucState = IFX_VMAPI_VL_STATE_DISABLED;
						IFX_CFG_VoiceLineNtfyHdlr(&xVL, pxVL);

					  printf("<CFG_NtfHdlr> Voice Line Changed \n");		
					  IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_LINE_SETTINGS_ASSOC,pxVL,NULL);
						break;
					}
			case IFX_VMAPI_VL_CALLFEAT://swaroop
				{
					printf("<Dect Agent>!!!!Notification for Calling Features !!!!!!\n");
					x_IFX_VMAPI_LineCallingFeatures* pxVLOld = (x_IFX_VMAPI_LineCallingFeatures*)(pMsg);
					x_IFX_VMAPI_LineCallingFeatures* pxVLNew = 
						(x_IFX_VMAPI_LineCallingFeatures*)(pMsg+sizeof(x_IFX_VMAPI_LineCallingFeatures));

#ifndef LIST_ACCESS
					printf("<CFG_NtfHdlr> Calling Features Changed \n");		
          sleep(5);
					IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_LINE_SETTINGS_CF,pxVLOld,pxVLNew);
#endif
					break;
				}
			case IFX_VMAPI_VOICE_LINE:
				{
					printf("<Dect Agent>!!!!Notification for Voice Line !!!!!!\n");
					x_IFX_VMAPI_VoiceLine* pxVLOld = (x_IFX_VMAPI_VoiceLine*)(pMsg);
					x_IFX_VMAPI_VoiceLine* pxVLNew = 
						(x_IFX_VMAPI_VoiceLine*)(pMsg+sizeof(x_IFX_VMAPI_VoiceLine));

					if(vuiVlChTimerId != 0){
                 			IFX_TIM_TimerStop(vuiVlChTimerId);
           			}
					memset(&vxVlTemp.xVlOld,0,sizeof(x_IFX_VMAPI_VoiceLine));
					memset(&vxVlTemp.xVlOld,0,sizeof(x_IFX_VMAPI_VoiceLine));

					memcpy(&vxVlTemp.xVlOld,pxVLOld,sizeof(x_IFX_VMAPI_VoiceLine));
					memcpy(&vxVlTemp.xVlNew,pxVLNew,sizeof(x_IFX_VMAPI_VoiceLine));
					IFX_TIM_TimerStart(10000, &(vxVlTemp), 4,
              		IFX_CFG_VlChNotify, &vuiVlChTimerId);

#ifndef LIST_ACCESS
					printf("<CFG_NtfHdlr> Voice Line Changed \n");		
          sleep(5);
					IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_LINE_SETTINGS_ASSOC,pxVLOld,pxVLNew);
#endif
					break;
				}
			case IFX_VMAPI_VL_EVENT_SUBSCR:
				{
					break;
				}
			case IFX_VMAPI_VS_DEBUG_SET:
				{
					x_IFX_VMAPI_SystemDebugSettings* pxDbgOld = 
																		(x_IFX_VMAPI_SystemDebugSettings*)(pMsg);
					x_IFX_VMAPI_SystemDebugSettings* pxDbgNew = 
																	(x_IFX_VMAPI_SystemDebugSettings*)
																	(pMsg+sizeof(x_IFX_VMAPI_SystemDebugSettings));
					
					IFX_CFG_DebugSetttingsNtfyHdlr(pxDbgOld, pxDbgNew);
					break;
				}
			case IFX_VMAPI_VS_NUM_PLAN:
				{
					x_IFX_VMAPI_NumPlan* pxNumPlanOld = (x_IFX_VMAPI_NumPlan*)(pMsg);
					x_IFX_VMAPI_NumPlan* pxNumPlanNew = 
									(x_IFX_VMAPI_NumPlan*)(pMsg+sizeof(x_IFX_VMAPI_NumPlan));
					
					IFX_CFG_NumberingPlanNtfyHdlr(pxNumPlanOld, pxNumPlanNew);
					break;
				}
			case IFX_VMAPI_VS_MISC:
				{
				 	x_IFX_VMAPI_Misc* pxMiscOld = (x_IFX_VMAPI_Misc*)(pMsg);
					x_IFX_VMAPI_Misc* pxMiscNew = 
							(x_IFX_VMAPI_Misc*)(pMsg+ sizeof(x_IFX_VMAPI_Misc));

					IFX_CFG_MiscellaneousNtfyHdlr(pxMiscOld, pxMiscNew);
					break;
				}
#ifdef LTAM
			case IFX_VMAPI_PHY_INT_TEST:
				{
					x_IFX_VMAPI_VoiceServPhyIfTest* pxPhyTest = 
																								(x_IFX_VMAPI_VoiceServPhyIfTest*)(pMsg);
					//print_message("<%s:%d> Got Line Notify", __FUNCTION__, __LINE__);
					IFX_CFG_PhyLineTestNtfy(pxPhyTest);
					break;
				}
#endif		
#ifndef LIST_ACCESS	
				case IFX_VMAPI_VS_CONTACT_LIST:
				case IFX_VMAPI_VS_PSTN_CONTACT_LIST:
				//case IFX_VMAPI_VS_COMMON_CONTACT_LIST:
				{
					x_IFX_VMAPI_ContactList *pxOldContacts, *pxNewContacts;
					printf("<CFGAgent> Contact List Changed\n");
					pxOldContacts = (x_IFX_VMAPI_ContactList*) (pMsg);
					pxNewContacts = (x_IFX_VMAPI_ContactList*) (pMsg + sizeof (x_IFX_VMAPI_ContactList));
					IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_CONTACTS,pxOldContacts,pxNewContacts);
					break;
				}
				
				case IFX_VMAPI_VS_COMMON_CONTACT_LIST:
				{
					x_IFX_VMAPI_ContactList *pxOldContacts, *pxNewContacts;
					printf("<CFGAgent> Contact List Changed\n");
					pxOldContacts = (x_IFX_VMAPI_ContactList*) (pMsg);
					pxNewContacts = (x_IFX_VMAPI_ContactList*) (pMsg + sizeof (x_IFX_VMAPI_ContactList));
					IFX_CMGR_ListAccessNtfy(IFX_CMGR_COMMON_CONTACTS,pxOldContacts,pxNewContacts);
					break;
				}
				
				
				case IFX_VMAPI_VS_DIALCALL_REGISTER:
				case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
				{
					printf("<CFG_NtfHdlr> Dial Call Changed\n");		
          x_IFX_VMAPI_DialCallRegister* pxDialOld = (x_IFX_VMAPI_DialCallRegister*)(pMsg);
          x_IFX_VMAPI_DialCallRegister* pxDialNew =
              (x_IFX_VMAPI_DialCallRegister*)(pMsg+ sizeof(x_IFX_VMAPI_DialCallRegister));
					IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_OUTGOING_CALLS,pxDialOld,pxDialNew);
					break;
				}
				case IFX_VMAPI_VS_MISSCALL_REGISTER:
				case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:{
					printf("<CFG_NtfHdlr> Miss Call Changed\n");		
          x_IFX_VMAPI_MissCallRegister* pxMissOld = (x_IFX_VMAPI_MissCallRegister*)(pMsg);
          x_IFX_VMAPI_MissCallRegister* pxMissNew =
              (x_IFX_VMAPI_MissCallRegister*)(pMsg+ sizeof(x_IFX_VMAPI_MissCallRegister));
         if(viNewMissedCall == 1){
           if(vuiMissedTimerId != 0){
		         IFX_TIM_TimerStop(vuiMissedTimerId);
           }
           memcpy(&vxMissedTemp.xMissOld,pxMissOld,sizeof(x_IFX_VMAPI_MissCallRegister));
           memcpy(&vxMissedTemp.xMissNew,pxMissNew,sizeof(x_IFX_VMAPI_MissCallRegister));
           IFX_TIM_TimerStart(1000*5, &(vxMissedTemp), 4,
              IFX_CFG_MissNotify, &vuiMissedTimerId);
           viNewMissedCall = 0;
         }
         else{
				   IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_MISSED_CALLS,pxMissOld,pxMissNew);
         }
					break;
				}

				case IFX_VMAPI_VS_RECVCALL_REGISTER:
				case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:{
					printf("<CFG_NtfHdlr> Recv Call Changed\n");		
          x_IFX_VMAPI_RecvCallRegister* pxRecvOld = (x_IFX_VMAPI_RecvCallRegister*)(pMsg);
          x_IFX_VMAPI_RecvCallRegister* pxRecvNew =
              (x_IFX_VMAPI_RecvCallRegister*)(pMsg+ sizeof(x_IFX_VMAPI_RecvCallRegister));
					IFX_CMGR_ListAccessNtfy(IFX_CMGR_LA_INCOMING_ACCEPT_CALLS,pxRecvOld,pxRecvNew);
					break;
				}

#endif
        case IFX_DUMMY_TZ_CHANGE:
        {
					  IFX_CMGR_DateTimeNtfy(NULL,NULL);
        }  
        break;
#ifdef CVOIP_SUPPORT
    case  IFX_VMAPI_TBR6_REQUEST: /*!< TBR6 Test */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_TBR06, &pucBuf, 0);
    break;
    case  IFX_VMAPI_DECT_SYSTEM_REQUEST: /*!< Dect System */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Pin, &pucBuf, 0);
    break;
    case  IFX_VMAPI_DECT_DIAGNOSTICS_REQUEST: /*!< Dect Diagnostics */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Diagnostics, &pucBuf, 0);
    break;
    case  IFX_VMAPI_TRANS_POWER_REQUEST: /*!< Transmit Power Measurement Test */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_TPC, &pucBuf, 0);
    break;
    case  IFX_VMAPI_RF_MODE_REQUEST: /*!< RF Mode Test */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_RfMode, &pucBuf, 0);
    break;
    case  IFX_VMAPI_RFPI_REQUEST: /*!< RFPI */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Rfpi, &pucBuf, 0);
    break;
    case  IFX_VMAPI_XRAM_REQUEST: /*!< XRAM */
		{
		//x_IFX_VMAPI_DectXRAM* pxXramOld  = (x_IFX_VMAPI_DectXRAM*)pMsg;
    char8 *buff = (char8*)pMsg;
		char8 finalBuff[50]="\0";
			strcpy(finalBuff,"#RAM ");
			strcat(finalBuff,(char8*)buff);
		/*x_IFX_VMAPI_DectXRAM* pxXramNew =
                 (x_IFX_VMAPI_DectXRAM*)(pMsg+sizeof(x_IFX_VMAPI_DectXRAM));
        if(pxXramNew == NULL){
          aucBuf[0] = pxXramOld->ucByte1;
          aucBuf[1] = pxXramOld->ucByte2;
          aucBuf[2]= pxXramOld->ucByte3;
        }else {
          aucBuf[0] = pxXramNew->ucByte1;
          aucBuf[1] = pxXramNew->ucByte2;
          aucBuf[2]= pxXramNew->ucByte3;
        }
          aucBuf[3]='?';*/
				printf("XRAM : REQUEST BUFFER : %s\n",finalBuff);
        //IFX_CIF_StoreValuesFromModem(IFX_VMAPI_XRAM_TEST,&xXram);
        //IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_RAM, buff, 0);
				if(LTQ_CVOIP_SendMsg((char8*)finalBuff,strlen(finalBuff)) != IFX_SUCCESS){
             printf("Failed in sending AT cmd to CVoIP...." );
  			}
		}
    break;

    case  IFX_VMAPI_COUNTRY_SETTINGS_REQUEST: /*!< DECT Country */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Freq, &pucBuf, 0);
    break;
    case  IFX_VMAPI_BMC_REG_PARAMS_REQUEST: /*!< DECT BMC */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_BMC, &pucBuf, 0);
    break;
    case  IFX_VMAPI_OSC_TRIM_REQUEST: /*!< DECT Oscillator Trimming */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_OscTrim, &pucBuf, 0);
    break;
    case  IFX_VMAPI_GFSK_REQUEST: /*!< DECT GFSK */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Gfsk, &pucBuf, 0);
		break;
    case  IFX_VMAPI_CVOIP_SYSTEM_CAPABALITIES: /*!< DECT CAP */
					IFX_CVOIP_ConstNSendATCmd(LTQ_ATCmd_Capabilities, &pucBuf, 0);
		break;
#endif
			default:
				{
					//Notification is not handled for this object
					;
				}
		}
		#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
		ucPrfIf =0;	//ucVLId  = ucIndex = 0 ; //To remove warning
		#endif
	}
	
	return IFX_SUCCESS;
}
