/**************************************************************************
 **   FILE NAME       : IFX_FAX_Agent.c
 **   PROJECT         : FAX Agent
 **   MODULES         : FAX Agent  Module.
 **   SRC VERSION     : V0.1
 **   DATE            :26-06-2007.
 **   AUTHOR          :Voip Lib Team.
 **   DESCRIPTION     :FAX Agent.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines.
 **
 **   COPYRIGHT       : Copyright © 2004
 **                     Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "fcntl.h"
#include "ifx_common_defs.h"
#include "ifx_os.h"
#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "IFX_Config.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_CallMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_FAX_Agent.h"
#include "ifx_debug.h"
#include "ifx_ipc.h"

#define printf(...)
#ifdef FAX_SUPPORT
/* Global Variables */
STATIC int16 v_nFAXAgentFifoFd,v_nFAXAppFifoFd;
extern int32 IFX_FAXAPP_AppInit(uchar8 ucDbgLvl,uchar8 ucDbgType,x_IFX_VMAPI_T38Cfg *pxFA_T38Cfg);
uint8 vcFAXAgentModId;

 /******************************************************************************
 *  Function Name   : IFX_FAX_AGENT_SendMsgToFifo
 *  Description     : This module writes Msg to FIFO
 *
 *  Input Values    : ua Message
 *  Output Values   : None
 *  Return Value    :
 *  Notes           :
 ******************************************************************************
*/
int8 IFX_FAX_AGENT_SendMsgToFifo(IN int16 nFifoFd,
                                 IN char *pcFifoMsg,
                                 IN int16 nMsgLen )
{
   int16 nBytes = 0;
   nBytes = IFX_OS_WriteFifo(nFifoFd, (char8 *) pcFifoMsg,nMsgLen);
  if (nBytes != nMsgLen)
  {
       IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "<FAXAgent> Error Writing to Fifo" );
       return IFX_FAILURE;
  }
   IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
                 "<FAXAgent> Bytes Written to Fifo",nBytes );
   return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_FAXAgentNotifier
 *  Description     : This Function is responsible 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_FAXAgentNotifier(int32 iFd)
{
   int16 nBufSize=0;
   x_IFX_FAX_AGENT_App2Agent xAppInfo ={0};
   nBufSize = IFX_OS_ReadFifo( iFd,( char8 * )&xAppInfo,
                              sizeof( x_IFX_FAX_AGENT_App2Agent ) );
   if( nBufSize < 0 )
   {
         IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_READ_ERR,
			            "FAX App Fifo\n" );
   }
	 printf("Response from FAXAPP arrived the Error code %d\n",
					xAppInfo.eErrCode);
	 
	 if( xAppInfo.eErrCode == IFX_FAX_END_SESSION){
	   return IFX_CMGR_FaxSessionEnd(xAppInfo.uiCallId);
	 }
	 else{
     return IFX_CMGR_FaxMediaError(xAppInfo.uiCallId,xAppInfo.eErrCode);
	 }
}
/******************************************************************************
 *  Function Name   : IFX_FAXAgent_CMGR_StartSession
 *  Description     : This Function is responsible  
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
e_IFX_Return IFX_FAXAgent_CMGR_StartSession
		  			(IN x_IFX_CMGR_FaxAgentInfo *pxFAXAgentInfo)
{
   x_IFX_FAX_AGENT_Agent2App xAgent2AppInfo;
	 memset(&xAgent2AppInfo,0,sizeof(x_IFX_FAX_AGENT_Agent2App));
   IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			            "Start Session Posted to FAXAPP\n" );
   xAgent2AppInfo.eAction = IFX_FAX_AGENT_START_SESSION;
   memcpy(&xAgent2AppInfo.xAgentInfo,pxFAXAgentInfo,
	      sizeof(x_IFX_CMGR_FaxAgentInfo));
   return IFX_FAX_AGENT_SendMsgToFifo(v_nFAXAppFifoFd,(char*)&xAgent2AppInfo,
	                        sizeof(x_IFX_FAX_AGENT_Agent2App));

}
/******************************************************************************
 *  Function Name   : IFX_FAXAgent_CMGR_StopSession
 *  Description     : This Function is responsible of   
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
e_IFX_Return IFX_FAXAgent_CMGR_StopSession
		  		(IN x_IFX_CMGR_FaxAgentInfo* pxFAXAgentInfo)
{
   x_IFX_FAX_AGENT_Agent2App xAgent2AppInfo;
	 memset(&xAgent2AppInfo,0,sizeof(x_IFX_FAX_AGENT_Agent2App));

   IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			            "Stop Session Posted to FAXAPP\n" );
   xAgent2AppInfo.eAction = IFX_FAX_AGENT_STOP_SESSION;
   memcpy(&xAgent2AppInfo.xAgentInfo,pxFAXAgentInfo,
	      sizeof(x_IFX_CMGR_FaxAgentInfo));

   return IFX_FAX_AGENT_SendMsgToFifo(v_nFAXAppFifoFd,(char*)&xAgent2AppInfo,
	                        sizeof(x_IFX_FAX_AGENT_Agent2App));
}
/******************************************************************************
 *  Function Name   : IFX_FAXAgent_CMGR_ModifySession
 *  Description     : This Function is responsible of 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
e_IFX_Return IFX_FAXAgent_CMGR_StartServer
		  		(IN x_IFX_CMGR_FaxAgentInfo* pxFAXAgentInfo)
{
  x_IFX_FAX_AGENT_Agent2App xAgent2AppInfo;
	memset(&xAgent2AppInfo,0,sizeof(x_IFX_FAX_AGENT_Agent2App));
  IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			            "Start Server Posted to FAXAPP\n" );
  xAgent2AppInfo.eAction = IFX_FAX_AGENT_START_SERVER;
  memcpy(&xAgent2AppInfo.xAgentInfo,pxFAXAgentInfo,
	      sizeof(x_IFX_CMGR_FaxAgentInfo));
  printf("The listen Flag is %d\n",pxFAXAgentInfo->bStopListen);
  return IFX_FAX_AGENT_SendMsgToFifo(v_nFAXAppFifoFd,(char*)&xAgent2AppInfo,
	                        sizeof(x_IFX_FAX_AGENT_Agent2App));
}
/******************************************************************************
 *  Function Name   : IFX_FAXAgent_Init
 *  Description     : This Function is responsible of 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_FAXAgent_Init(uchar8 ucDbgLvl,uchar8 ucDbgType,x_IFX_VMAPI_T38Cfg *pxFA_T38Cfg)
{
  int8 cRet = IFX_FAILURE;
  x_IFX_CMGR_CallBackList xCallBackList={0};
  x_IFX_MSGRTR_FdInfo xMSGFdInfo={0}; 
	char8 aszEndptId[1][IFX_MAX_ENDPOINTID_LEN] = {IFX_FAX_AGENT_ENDPT_ID};

	
  IFX_DBG_Init(IFX_IPC_APP_NAME_FAXAGENT,ucDbgType,
						   ucDbgLvl, &vcFAXAgentModId, &cRet);
	
  /* Create FAX Fifo */ 
   umask( 0 );
   if(access( IFX_IPC_FAX_AGENT_FIFO,F_OK ) == -1)
   {
      if(mkfifo(IFX_IPC_FAX_AGENT_FIFO,IFX_IPC_FIFO_PERM))
      {
         IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_CREATION_ERR,
                  "<AppMain> IFX_IPC_FAX_AGENT_FIFO");
         return cRet;
      }
   }
   if((v_nFAXAgentFifoFd = IFX_OS_OpenFifo( (uchar8 *)IFX_IPC_FAX_AGENT_FIFO,O_RDWR)) 
	   == -1 )
   {
      IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_OPEN_ERR,
	           "<AppMain> IFX_IPC_FAX_AGENT_FIFO");
      return cRet;
   }
	if(access( IFX_IPC_FAX_APP_FIFO,F_OK ) == -1)
   {
      if(mkfifo(IFX_IPC_FAX_APP_FIFO,IFX_IPC_FIFO_PERM))
      {
         IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_CREATION_ERR,
                  "<AppMain> IFX_IPC_FAX_APP_FIFO");
         return cRet;
      }
   }
   if((v_nFAXAppFifoFd = IFX_OS_OpenFifo( (uchar8 *) IFX_IPC_FAX_APP_FIFO,O_RDWR)) 
	     == -1 )
   {
      IFX_DBGA(vcFAXAgentModId,IFX_DBG_LVL_ERROR,IFX_DBG_FIFO_OPEN_ERR,
	           "<AppMain> IFX_IPC_FAX_APP_FIFO");
      return cRet;
   } 
   /*Register the FD with the callmanager*/
   xMSGFdInfo.uiFd = v_nFAXAgentFifoFd;
   xMSGFdInfo.eFdSetType = IFX_MSGRTR_READ_TYPE;
   IFX_MSGRTR_FdCallBackRegister(&xMSGFdInfo,1,IFX_FAXAgentNotifier);

   /*Register the CallBacks*/
   xCallBackList.pfnFaxServerListen = IFX_FAXAgent_CMGR_StartServer;
   xCallBackList.pfnFaxSessionStop = IFX_FAXAgent_CMGR_StopSession;
   xCallBackList.pfnFaxSessionStart = IFX_FAXAgent_CMGR_StartSession;
   IFX_CMGR_CallBacksRegister(aszEndptId,1,&xCallBackList);
	

		printf("%s: At line %d!",__FUNCTION__, __LINE__ );
   IFX_FAXAPP_AppInit(ucDbgLvl,ucDbgType,pxFA_T38Cfg);	 
	 return IFX_SUCCESS;

}
/******************************************************************************
 *  Function Name   : IFX_FAXAgent_Config
 *  Description     : This Function is responsible of 
 *
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - On Success
 *                    IFX_FAIL - On Failure
 *  Notes           :
 *****************************************************************************/
int32 IFX_FAXAgent_Config(uchar8 ucDbgLvl,uchar8 ucDbgType)
{
  x_IFX_FAX_AGENT_Agent2App xAgentInfo;
	memset(&xAgentInfo,0,sizeof(x_IFX_FAX_AGENT_Agent2App));
  xAgentInfo.eAction = IFX_FAX_AGENT_MODIFY_CFG;
  xAgentInfo.ucDbgLvl = ucDbgLvl;
  xAgentInfo.ucDbgType = ucDbgType;
  IFX_DBG_Set(IFX_IPC_APP_NAME_FAXAGENT,vcFAXAgentModId,
	            ucDbgType,ucDbgLvl);
  return IFX_FAX_AGENT_SendMsgToFifo(v_nFAXAppFifoFd,(char*)&xAgentInfo,
				                          sizeof(x_IFX_FAX_AGENT_Agent2App));	
}


#endif
