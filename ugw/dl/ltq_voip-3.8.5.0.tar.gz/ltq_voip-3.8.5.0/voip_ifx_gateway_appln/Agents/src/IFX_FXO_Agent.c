/**************************************************************************
 **   SRC_FILE          : IFX_FXO.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES          : 
 **   SRC VERSION       : v0.1
 **   DATE                  : 
 **   AUTHOR            : Voip-Gw Team
 **   DESCRIPTION   : 
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.  
 **  Version Control Section  **
 **   $Author$ 
 **   $Date$ 
 **   $Revisions$
 **   $Log$
 **************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "ifx_common_defs.h"
#include "ifx_debug.h"
# include "IFX_Config.h"
# include "IFX_Misc.h"
# include "IFX_CallMgrIf.h"
# include "IFX_MediaMgrIf.h"
# include "IFX_MsgRtrIf.h"
# include "IFX_Agents_CfgIf.h"
# include "IFX_TimerIf.h"
# include "IFX_DialPlanIf.h"
# include "IFX_FXO_Agent.h"

# define IFX_MAX_CID_BUFF_LEN 128

#ifdef CUST_DEBUG
//#define IFX_DBGA IFX_DBGC
#endif

/*******Data Declerations*********/

x_IFX_FXO_Info vaxFXOInfo[IFX_MMGR_MAX_FXO_CHANNELS];
uchar8 vucFXOModId;
extern uint16 vunDialToneLength;

/*******External Declerations*********/
extern e_IFX_MMGR_Return IFX_MMGR_FSK_FreeData(x_IFX_MMGR_FSK_Data *pxFsk);

/*********** The State and event names required for debugging *****************/

const char8 * aszStateName[] =
{
	[IFX_FXO_STATE_IDLE]    = "IFX_FXO_STATE_IDLE",
	[IFX_FXO_STATE_CID_WAIT]   = "IFX_FXO_STATE_CID_WAIT",
	[IFX_FXO_STATE_DIAL_WAIT]  = "IFX_FXO_STATE_DIAL_WAIT",
	[IFX_FXO_STATE_DIGIT_DIAL]  = "IFX_FXO_STATE_DIGIT_DIAL",
	[IFX_FXO_STATE_DIGIT_COLLECT] = "IFX_FXO_STATE_DIGIT_COLLECT",
	[IFX_FXO_STATE_RINGBACK]   = "IFX_FXO_STATE_RINGBACK",
	[IFX_FXO_STATE_CONVERSATION]  = "IFX_FXO_STATE_CONVERSATION",
	[IFX_FXO_STATE_RINGING]     = "IFX_FXO_STATE_RINGING",
	[IFX_FXO_STATE_OFF_HK_WAIT]   = "IFX_FXO_STATE_OFF_HK_WAIT",
	//[IFX_FXO_STATE_SMS]      = "IFX_FXO_STATE_SMS",
	[IFX_FXO_STATE_MAX]      = "IFX_FXO_STATE_MAX",
};

const char8 * aszEvtName[] =
{
	[IFX_FXO_EVT_RingStart]     = "IFX_FXO_EVT_RingStart",   
	[IFX_FXO_EVT_DgtPrs]      = "IFX_FXO_EVT_DgtPrs",
	[IFX_FXO_EVT_RingStop]     = "IFX_FXO_EVT_RingStop",
	[IFX_FXO_EVT_ToneDetect]    = "IFX_FXO_EVT_ToneDetect",
	[IFX_FXO_EVT_CIDRxComplete]   = "IFX_FXO_EVT_CIDRxComplete",
	[IFX_FXO_EVT_CAS]        = "IFX_FXO_EVT_CAS",
	[IFX_FXO_EVT_IncCall]      = "IFX_FXO_EVT_IncCall",
	[IFX_FXO_EVT_EmgCall]      = "IFX_FXO_EVT_EmgCall",
	[IFX_FXO_EVT_ReleaseCall]    = "IFX_FXO_EVT_ReleaseCall",
	[IFX_FXO_EVT_RmtAccept]     = "IFX_FXO_EVT_RmtAccept",
	[IFX_FXO_EVT_RmtAnswer]     = "IFX_FXO_EVT_RmtAnswer",
	[IFX_FXO_EVT_PSTNHookFlash]   = "IFX_FXO_EVT_PSTNHookFlash",
	[IFX_FXO_EVT_DialToneTimerExp] = "IFX_FXO_EVT_DialToneTimerExp",
	[IFX_FXO_EVT_RingBackToneTimerExp]= "IFX_FXO_EVT_RingBackToneTimerExp",
	[IFX_FXO_EVT_RingBurstTimerExp]  = "IFX_FXO_EVT_RingBurstTimerExp",
	[IFX_FXO_EVT_LineDgtTimerExp]   = "IFX_FXO_EVT_LineDgtTimerExp",
	[IFX_FXO_EVT_LineInterDgtTimerExp]= "IFX_FXO_EVT_LineInterDgtTimerExp",
	[IFX_FXO_EVT_DialWaitTimerExp]  = "IFX_FXO_EVT_DialWaitTimerExp",
	[IFX_FXO_EVT_OffHkWaitTimerExp]  = "IFX_FXO_EVT_OffHkWaitTimerExp",
	[IFX_FXO_EVT_OnHkWaitTimerExp]  = "IFX_FXO_EVT_OnHkWaitTimerExp",
	[IFX_FXO_EVT_RetryTimerExp]    = "IFX_FXO_EVT_RetryTimerExp",
	[IFX_FXO_EVT_InterDgtTimerExp]  = "IFX_FXO_EVT_InterDgtTimerExp",
	[IFX_FXO_EVT_HookFlashTimerExp]  = "IFX_FXO_EVT_HookFlashTimerExp",
	[IFX_FXO_EVT_OffHkCIDTimerExp]  = "IFX_FXO_EVT_OffHkCIDTimerExp",
	[IFX_FXO_EVT_TransmitSMS]     = "IFX_FXO_EVT_TransmitSMS",
	//[IFX_FXO_EVT_FSKDataReady]   = "IFX_FXO_EVT_FSKDataReady",
	//[IFX_FXO_EVT_SMSTimetFired]   = "IFX_FXO_EVT_SMSTimetFired",
	//[IFX_FXO_EVT_FAX_CNG]      = "IFX_FXO_EVT_FAX_CNG"
	//[IFX_FXO_EVT_FAX_CED]      = "IFX_FXO_EVT_FAX_CED",
	//[IFX_FXO_EVT_FAX_DIS]      = "IFX_FXO_EVT_FAX_DIS",
	[IFX_FXO_EVT_MAX]         = "IFX_FXO_EVT_MAX",
};

const char8 * aszFlagName[] =
{
	[IFX_FXO_EMG_CALL_PROCEEDING] = "EMG_CALL_PROCEEDING",
	[IFX_FXO_RESOURCE_ALLOCATED] = "RESOURCE_ALLOCATED",
	[IFX_FXO_RING_START_RCVD]   = "RING_START_RCVD",
 [IFX_FXO_MOVE_TO_SMS_STATE]  = "MOVE_TO_SMS_STATE",
	[IFX_FXO_MOVE_TO_DIALWAIT]  = "MOVE_TO_DIALWAIT",
	[IFX_FXO_HOOK_STATUS]     = "HOOK_STATUS",
	[IFX_FXO_MAX_FLAGS]      = "MAX_FLAGS",
};

const char8 * aszFXOReturn[] =
{
	[IFX_FXO_AcceptCall] ="IFX_FXO_AcceptCall",
	[IFX_FXO_RejectCall] ="IFX_FXO_RejectCall",
	[IFX_FXO_AnswerCall] ="IFX_FXO_AnswerCall",
	[IFX_FXO_PendingCall] ="IFX_FXO_PendingCall",
	[IFX_FXO_AcceptSMS] 	="IFX_FXO_AcceptSMS",
	[IFX_FXO_RejectSMS]  ="IFX_FXO_RejectSMS",
	[IFX_FXO_Failure]   ="IFX_FXO_Failure",
	[IFX_FXO_MAXReturn]  ="IFX_FXO_MAXReturn"
};

/************The functions for debugging ***************/
#ifdef PRINT_EXIT_INFO
STATIC inline 
e_IFX_Return IFX_FXO_PrintExitInfo(e_IFX_Return eRetVal, 
                                  char8* szFnName )
{
	IFX_DBGA( vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
		szFnName,(eRetVal == IFX_SUCCESS)?"SUCCESS": "FAILED" );
	
	return eRetVal;
}
#else
#define IFX_FXO_PrintExitInfo(eRet, szFunName) (eRet)
#endif

#ifdef PRINT_FSM_STATUS
STATIC inline 
void IFX_FXO_ShowStatus(x_IFX_FXO_Info * pxEndptInfo)
{		
	/*Endpoint status goes here*/
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "End point Id", pxEndptInfo->szEndPointId);

	/*Timers*/	
	if(pxEndptInfo->uiDialToneTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Dial tone timer running");
 	}
	if(pxEndptInfo->uiRingBkToneTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Ringback tone timer running");
 	}
	if(pxEndptInfo->uiRingBurstTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Ringburst timer running");
 	}
	if(pxEndptInfo->uiOffHkWaitTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Off hook wait timer running");
 	}
	if(pxEndptInfo->uiOnHkWaitTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "On hook wait timer running");
 	}
	if(pxEndptInfo->uiInterDgtTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Interdigit timer running");
 	}
	if(pxEndptInfo->uiLineDgtTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Line-digit timer running");
 	}
	if(pxEndptInfo->uiLineInterDgtTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Line-Interdigit timer running");
 	}
	if(pxEndptInfo->uiRetryTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Retry timer running");
 	}
	if(pxEndptInfo->uiDialWaitTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Dial wait timer running");
 	}
	if(pxEndptInfo->uiHookFlashTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Off hook wait timer running");
	}
	if(pxEndptInfo->uiOffHkCIDTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Off hook CID timer running");
	}
	
	/*Call Id's*/
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
		"The Active call Id",pxEndptInfo->axFxoCallData[0].uiCallId);
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
  		"The EMERGENCY Call Id",pxEndptInfo->xEmgCallInfo.uiCallId);
#if 0
	/*Flags*/
	{
		int32 iCnt;
		for(iCnt = 0;iCnt<IFX_FXO_MAX_FLAGS;iCnt ++)
		{
			if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,iCnt))
			{	
				IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
            	"The Flag set is",IFX_FXO_GetFlag(iCnt));
			}
		}
	} 
#endif
	/*State*/
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
       "The FXO FSM state",IFX_FXO_GetState(pxEndptInfo->eCurrState));
	return ;
}
#else
#define IFX_FXO_ShowStatus( pxEndptInfo)
#endif

/*************** The internal utility functions for the FXO FSM ************/
/************** Static Inline functions************/
STATIC inline e_IFX_Return IFX_FXO_AllocResource(x_IFX_FXO_Info * pxEndptInfo)
{
	e_IFX_Return eRet = IFX_FAILURE;
	if(0==IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_RESOURCE_ALLOCATED))
	{
		if(IFX_MMGR_SUCCESS != IFX_MMGR_SigResAlloc(pxEndptInfo->szEndPointId,NULL))
		{
			IFX_DBGC(vucFXOModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
																		"The Resource Allocation failed");
		}
		else {
			IFX_FXO_SET_FLAG(pxEndptInfo->uiFlags, IFX_FXO_RESOURCE_ALLOCATED);
			eRet = IFX_SUCCESS;
		}
	}
	/* Resource already allocated */
	return eRet;
}

STATIC inline e_IFX_Return IFX_FXO_DeallocResource(x_IFX_FXO_Info * pxEndptInfo)
{
   if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_RESOURCE_ALLOCATED))
   {
   	if(IFX_MMGR_SUCCESS != IFX_MMGR_SigResDealloc
												(pxEndptInfo->szEndPointId))
		{
			IFX_DBGC(vucFXOModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                             "The Resource De-Allocation failed");
			return IFX_SUCCESS;
		}
   	IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_RESOURCE_ALLOCATED);
   }
   
	/*Resource already Deallocated*/
	return IFX_SUCCESS;
}

STATIC inline e_IFX_Return IFX_FXO_SetOffHook(x_IFX_FXO_Info * pxEndptInfo)
{
	e_IFX_Return eRet = IFX_FAILURE;
	
	if( 0 == IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_HOOK_STATUS) )
	{
		if( IFX_MMGR_SUCCESS != IFX_MMGR_OffHookSet(pxEndptInfo->szEndPointId) )
		{
			IFX_DBGC(vucFXOModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR,
				"Could Not Do Off-Hook On FXO Line");
		}
		else
		{
			IFX_FXO_SET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_HOOK_STATUS);
			eRet =  IFX_SUCCESS;
		}
	}
	else
	{
		IFX_DBGC(vucFXOModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
			"FXO Line Is Already In Off-Hook State");
	}
	 /*Already off hook*/
	return eRet;
}

STATIC inline e_IFX_Return IFX_FXO_SetOnHook(x_IFX_FXO_Info * pxEndptInfo)
{
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_HOOK_STATUS))
	{
		if(IFX_MMGR_SUCCESS != IFX_MMGR_OnHookSet(pxEndptInfo->szEndPointId))
		{
			IFX_DBGC(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
														 "Set On-Hook Failed");
			return IFX_FAILURE;
		}
		IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_HOOK_STATUS);
		return IFX_SUCCESS;
	}
	//IFX_DBGA(vucFXOModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, "Already on hook");
	/*Already on hook*/
	return IFX_SUCCESS;
}

STATIC inline e_IFX_Return IFX_FXO_StartCptd(x_IFX_FXO_Info * pxEndptInfo,
									e_IFX_MMGR_ToneType eToneType)
{
	/*
	 * Mahipati: If CPTD to be started is the one that is running, then return 
	 * success
	 */
	if( pxEndptInfo->eCPTDActv != eToneType )
	{
		if( pxEndptInfo->eCPTDActv != IFX_MMGR_MAX_TONE )	
		{
			/*CPTD was running for some tone. Stopping it*/
			IFX_MMGR_CptdStop(pxEndptInfo->szEndPointId);
		}
		IFX_MMGR_CptdStart(pxEndptInfo->szEndPointId,eToneType);	
		pxEndptInfo->eCPTDActv = eToneType;	
	}	
	return IFX_SUCCESS;
}

STATIC inline e_IFX_Return IFX_FXO_StopCptd(x_IFX_FXO_Info * pxEndptInfo)
{
	if(pxEndptInfo->eCPTDActv != IFX_MMGR_MAX_TONE )
	{
		IFX_MMGR_CptdStop(pxEndptInfo->szEndPointId);
		pxEndptInfo->eCPTDActv = IFX_MMGR_MAX_TONE;	
	}
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_FXO_StartToneTimer
* Description      : This function would be called to play a particular tone
											Start the given tone and the timer for tone
											in accordance with the ucTONETIMER value. 
* Input Values     :	1)ucTIMER is Tone or Timer MACRO.	
    						2)unTimeout in miliseconds is expected. If 0, it will try to 
									pick from standard values based on EvtId , 
											else would return fail.  
    						3)pxEndptInfo 
* Output Values    : 
* Return Value     : IFX_SUCCESS or IFX_FAILUREURE
* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_StartToneTimer(
												uchar8 ucTONETIMER,uint32 unTimeout,
												x_IFX_FXO_Info * pxEndptInfo)
{
	uint32 uiTimeOut;
	x_IFX_FXO_TimerInfo xTimerInfo = {0};
	uint32 *puiTimerId;
	e_IFX_Return eRetVal=IFX_SUCCESS;
	
	xTimerInfo.pxEndptInfo = pxEndptInfo;			
	
	switch(ucTONETIMER)
	{
	case DIAL_TONE	:
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_DialToneTimerExp;
		puiTimerId = &pxEndptInfo->uiDialToneTimId;
		uiTimeOut = vunDialToneLength;
		break;			
	case RING_BACK_TONE :			
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_RingBackToneTimerExp;
		puiTimerId = &pxEndptInfo->uiRingBkToneTimId;
		uiTimeOut = IFX_RINGBACK_TONE_DURATION;
		break;			
 	case FULL_INTERDGT :		 
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_InterDgtTimerExp;
		puiTimerId = &pxEndptInfo->uiInterDgtTimId;
		uiTimeOut = IFX_FULL_INTERDIGIT_DURATION;
		break;			
 	case PROG_INTERDGT :		
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_InterDgtTimerExp;
		puiTimerId = &pxEndptInfo->uiInterDgtTimId;
		uiTimeOut = IFX_PROGRESSIVE_INTERDIGIT_DURATION;
		break;			
 	case OFF_HK_WAIT :		 
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_OffHkWaitTimerExp;
		puiTimerId = &pxEndptInfo->uiOffHkWaitTimId;
		uiTimeOut = IFX_FXO_OFF_HK_WAIT_DURATION;
		break;			
 	case LINE_DIGIT :    	
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_LineDgtTimerExp;
		puiTimerId = &pxEndptInfo->uiLineDgtTimId;
		uiTimeOut = IFX_FXO_LINE_DIGIT_DURATION;
		break;			
 	case LINE_INTERDIGIT :   
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_LineInterDgtTimerExp;
		puiTimerId = &pxEndptInfo->uiLineInterDgtTimId;
		uiTimeOut = IFX_FXO_LINE_INTERDIGIT_DURATION;
		break;			
 	case RINGBURST :   		
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_RingBurstTimerExp;
		puiTimerId = &pxEndptInfo->uiRingBurstTimId;
		uiTimeOut = IFX_FXO_RINGBURST_DURATION;
		break;			
 	case RETRY :     		
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_RetryTimerExp;
		puiTimerId = &pxEndptInfo->uiRetryTimId;
		uiTimeOut = IFX_FXO_RETRY_DURATION;
		break;			
 	case DIALWAIT:   		
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_DialWaitTimerExp;
		puiTimerId = &pxEndptInfo->uiDialWaitTimId;
		uiTimeOut = IFX_FXO_DIALWAIT_DURATION;
		break;			
 	case HOOKFLASH: 			
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_HookFlashTimerExp;
		puiTimerId = &pxEndptInfo->uiHookFlashTimId;
		uiTimeOut = IFX_FXO_HOOKFLASH_DURATION;
		break;			
 	case ON_HK_WAIT: 			
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_OnHkWaitTimerExp;
		puiTimerId = &pxEndptInfo->uiOnHkWaitTimId;
		uiTimeOut = IFX_FXO_ON_HK_WAIT_DURATION;
		break;			
 	case OFF_HK_CID: 			
		xTimerInfo.eCurrEvt = IFX_FXO_EVT_OffHkCIDTimerExp;
		puiTimerId = &pxEndptInfo->uiOffHkCIDTimId;
		uiTimeOut = IFX_FXO_OFF_HK_CID_DURATION;
		break;			
 	default: return eRetVal;		
	}

	xTimerInfo.pTimerId = puiTimerId;			
	if( DEFAULT != unTimeout )
		uiTimeOut = (uint32)unTimeout;

	eRetVal = IFX_TIM_TimerStart(uiTimeOut,&xTimerInfo,
									sizeof(xTimerInfo),IFX_FXO_TimerFired,puiTimerId);
	if(ucTONETIMER==DIAL_TONE) { 
		IFX_MMGR_TonePlay(pxEndptInfo->szEndPointId,IFX_MMGR_DIAL_TONE,NULL);
		IFX_FXO_SET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_TONE_PLAY);
	}
	else if(ucTONETIMER==RING_BACK_TONE) {
		IFX_MMGR_TonePlay(pxEndptInfo->szEndPointId,IFX_MMGR_RING_BACK_TONE,NULL);
		IFX_FXO_SET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_TONE_PLAY);
	}
	return IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);                                                                               
}
/***************************************************************************
* Function Name    : IFX_FXO_StopTone
* Description      : 
* Input Values     :
	 Output Values    : 
* Return Value     : IFX_SUCCESS or IFX_FAILUREURE
* Notes            :
***************************************************************************/
e_IFX_Return 
IFX_FXO_ToneStop(x_IFX_FXO_Info *pxEndptInfo)
{
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_TONE_PLAY)){
		IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId); 
	}
	IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_TONE_PLAY);
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_MakeFXOIdle
* Description      : -It calls DeallocResource
							-It calls Stops CPTS
							-It calls Stops CID Rx
							-It does on hook.
							-It stops the Tone if playing and Timers if any running.
							-It does ReleaseCall if active and memsets the callData
							-It Does ReleaseCall clears emergency call data
							-It clears the flags and dialDigit/collected digits 
													and pointers
							-It Resets the flag variable.
							-Memsets DMI and CID data.
* Input Values     : pxEndptInfo is Endpoint Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_MakeFXOIdle(x_IFX_FXO_Info *pxEndptInfo)
{
	IFX_DBGA(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,"Making FXO Idle");
	IFX_FXO_StopCptd(pxEndptInfo);
	IFX_MMGR_CidRxStop(pxEndptInfo->szEndPointId);
	IFX_FXO_ToneStop(pxEndptInfo);
		if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags, IFX_FXO_HOOK_STATUS)) {
		IFX_FXO_SetOnHook(pxEndptInfo);
	}
	IFX_FXO_DeallocResource(pxEndptInfo);
	if(pxEndptInfo->uiDialToneTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiDialToneTimId);
 		pxEndptInfo->uiDialToneTimId=0;
 	}
	if(pxEndptInfo->uiRingBkToneTimId)
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiRingBkToneTimId);
 		pxEndptInfo->uiRingBkToneTimId=0;
 	}
	if(pxEndptInfo->uiRingBurstTimId)
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiRingBurstTimId);
 		pxEndptInfo->uiRingBurstTimId=0;
 	}
	if(pxEndptInfo->uiOffHkWaitTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiOffHkWaitTimId);
 		pxEndptInfo->uiOffHkWaitTimId=0;
 	}
	if(pxEndptInfo->uiOnHkWaitTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiOnHkWaitTimId);
 		pxEndptInfo->uiOnHkWaitTimId=0;
 	}
	if(pxEndptInfo->uiInterDgtTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiInterDgtTimId);
 		pxEndptInfo->uiInterDgtTimId=0;
 	}
	if(pxEndptInfo->uiLineDgtTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiLineDgtTimId);
 		pxEndptInfo->uiLineDgtTimId=0;
 	}
	if(pxEndptInfo->uiLineInterDgtTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiLineInterDgtTimId);
 		pxEndptInfo->uiLineInterDgtTimId=0;
 	}
	if(pxEndptInfo->uiRetryTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiRetryTimId);
 		pxEndptInfo->uiRetryTimId=0;
 	}
	if(pxEndptInfo->uiDialWaitTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiDialWaitTimId);
 		pxEndptInfo->uiDialWaitTimId=0;
 	}
	if(pxEndptInfo->uiHookFlashTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiHookFlashTimId);
 		pxEndptInfo->uiHookFlashTimId=0;
	}
	if(pxEndptInfo->uiOffHkCIDTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiOffHkCIDTimId);
 		pxEndptInfo->uiOffHkCIDTimId=0;
	}
	IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
	IFX_FXO_RELEASECALL(pxEndptInfo->xEmgCallInfo.uiCallId);
	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	memset(&(pxEndptInfo->xEmgCallInfo),0,sizeof(x_IFX_FXO_IncCallInfo));
	pxEndptInfo->uiFlags = 0 ;
	memset(pxEndptInfo->szPstnDgt,0,IFX_FXO_MAX_PSTN_NUM);
	memset(pxEndptInfo->szDialledDigits,0,IFX_FXO_MAX_DIGITS);
	memset(pxEndptInfo->szDialOutDgtStr,0,IFX_FXO_MAX_DIGITS);
	pxEndptInfo->pcCurrDgt = pxEndptInfo->szPstnDgt;
	pxEndptInfo->cDMI = '0';
	memset(&(pxEndptInfo->xCIDdata),0,sizeof(x_IFX_MMGR_CidParams));
	pxEndptInfo->eCurrState=IFX_FXO_STATE_IDLE;
	pxEndptInfo->ePrevState=IFX_FXO_STATE_IDLE;
	return IFX_SUCCESS;
}

/*
This is a utility function which will do CallInitiate from 
inside depending on mode and numbering plan action specified.
It will return status as accept/reject/pending.
*/
STATIC e_IFX_FXO_Return IFX_FXO_CallInitiate(
													IN x_IFX_FXO_Info *pxEndptInfo,
													IN uint32* puiCallId,													
													IN char8 *szTgtNum,
													boolean bGwMode,
													IN e_IFX_DP_Action eAction )
{
	x_IFX_CMGR_AddressInfo xFrom={0};
	x_IFX_CMGR_AddressInfo xTo={0};
	x_IFX_CMGR_CallParams xCallParams={0};
	e_IFX_CMGR_Status eStatus;
	e_IFX_ReasonCode eReason;
#ifdef DIAL_PLAN_REMOVE	
char8 szTmp[48];
	int32 iCnt;
#endif
	 
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Call Initiated");
	
	/* memset(&xTo,0,sizeof(x_IFX_CMGR_AddressInfo));
	memset(&xFrom,0,sizeof(x_IFX_CMGR_AddressInfo));
	memset(&xCallParams,0,sizeof(x_IFX_CMGR_CallParams)); */
	xCallParams.eAgentType = IFX_CMGR_TYPE_FXO;
	
	/*Populate From*/
	xFrom.eAddressType = IFX_CMGR_TYPE_FXO;
	strncpy(xFrom.uxAddressInfo.xFxoInfo.szPhoneNumber,
										pxEndptInfo->xCIDdata.szCallerNumber,IFX_MAX_ENDPOINTID_LEN-1);
	xFrom.uxAddressInfo.xFxoInfo.szPhoneNumber[IFX_MAX_ENDPOINTID_LEN-1]=0;
	strcpy(xFrom.uxAddressInfo.xFxoInfo.szFxoLineId,pxEndptInfo->szEndPointId);
	/*Populate the CID info*/
	IFX_GetDateTime(xFrom.uxAddressInfo.xFxoInfo.xCidInfo.szDateOfCall,
							xFrom.uxAddressInfo.xFxoInfo.xCidInfo.szTimeOfCall);
	//strcpy(xFrom.uxAddressInfo.xFxoInfo.xCidInfo.szDateOfCall,"24/05/2007");
	//strcpy(xFrom.uxAddressInfo.xFxoInfo.xCidInfo.szTimeOfCall,"00:00:00");
	strcpy(xFrom.uxAddressInfo.xFxoInfo.xCidInfo.szDisplayName,
													pxEndptInfo->xCIDdata.szCallerName);
		
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                       (bGwMode)?"Gateway Mode Call":"Forwarding Mode Call");
	/*if forwarding populate the call type as internal and fill in the fxo line ID*/
	if(!bGwMode)
	{		
		xTo.eAddressType = IFX_CMGR_TYPE_EXTN;
		strcpy(xTo.uxAddressInfo.szEndptId,pxEndptInfo->szEndPointId);
	}	
	else
	{
		/*Populate To based upon the action specified.*/
		switch(eAction)
		{
			case IFX_DP_SPEED_DIAL:
				xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
				if(IFX_FAILURE == IFX_CIF_AddrBookEntryGet( szTgtNum, &xTo,&eReason))
				{					
					IFX_DBGC(vucFXOModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
              "Could Not Retrieve Specified Address Book Entry");
					return IFX_FXO_Failure;						
				}
				break;
			case IFX_DP_EXTENSION_DIAL:
				xTo.eAddressType = IFX_CMGR_TYPE_EXTN;
				strcpy(xTo.uxAddressInfo.szEndptId,szTgtNum);				
				break;
	 		//case IFX_DP_SERV_SIDE_CFG: //TODO:DISCUSS Do we need to support it from FXO
	#ifdef DIAL_PLAN_REMOVE	
		case IFX_DP_LOCAL_VOIP_CALLS:
			case IFX_DP_STD_VOIP_CALLS:
			case IFX_DP_ISD_VOIP_CALLS:
				xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
				strcpy(xTo.uxAddressInfo.xVoipAddr.acDisplayName,szTgtNum);
				strcpy(xTo.uxAddressInfo.xVoipAddr.acUserName,szTgtNum);
				xTo.uxAddressInfo.xVoipAddr.ucAddrType = 				
					 ((IFX_DP_SERV_SIDE_CFG == eAction)?IFX_EXTN:IFX_TEL_NUM);
				break;
	#endif
			case IFX_DP_DIALDEFAULT_DEF_IF:
				xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
				strcpy(xTo.uxAddressInfo.xVoipAddr.acDisplayName,szTgtNum);
				strcpy(xTo.uxAddressInfo.xVoipAddr.acUserName,szTgtNum);
				xTo.uxAddressInfo.xVoipAddr.ucAddrType = IFX_TEL_NUM;				
				break;
	#ifdef DIAL_PLAN_REMOVE	
			case IFX_DP_DIRECT_IP_CALLS:
				/*It may be required to construct an IP address from szTgtNum*/
				xTo.eAddressType = IFX_CMGR_TYPE_VOIP;
				IFX_ConvertIPAddr(szTgtNum,szTmp);
				for(iCnt = 0; szTmp[iCnt] != '@';iCnt++)
							xTo.uxAddressInfo.xVoipAddr.acUserName[iCnt] = szTmp[iCnt];
				xTo.uxAddressInfo.xVoipAddr.acUserName[iCnt] = '\0';
				iCnt ++ ;
				strcpy(xTo.uxAddressInfo.xVoipAddr.acCalledAddr,&szTmp[iCnt]);
				xTo.uxAddressInfo.xVoipAddr.ucAddrType = IFX_IP_ADDR;				
				break;
	#endif
			/* For rest of all actions, invalid on FXO, the Reject is returned */
			default:
   			return IFX_FXO_RejectCall;
		}
	}
	/*Call the CallInitiate*/
	if(IFX_FAILURE == IFX_CMGR_CallInitiate(puiCallId,&xFrom,&xTo,
						&xCallParams,&eStatus,&eReason,pxEndptInfo))
	{
		IFX_DBGC(vucFXOModId,
			IFX_DBG_LVL_HIGH,IFX_DBG_STR, "!! Could Not Initiate Call !!");
		return IFX_FXO_Failure;
	}
	else if(IFX_CMGR_STATUS_SUCCESS == eStatus)
	{
		IFX_DBGC(vucFXOModId,
			IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Call Answered By Peer");
		return IFX_FXO_AnswerCall;
	}
	else if(IFX_CMGR_STATUS_FAIL == eStatus)
  {
		/* Since the call is released, reset the call data */
		*puiCallId = 0;
		IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Could Not Make Call. May be tried later");
		return IFX_FXO_RejectCall;
	}
	else // IFX_CMGR_STATUS_PENDING == eStatus
	{ 	
		IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH,
											IFX_DBG_STR, "Trying to Reach Remote Party....");
		return (IFX_ENDPOINT_RINGING == eReason)
																				?IFX_FXO_AcceptCall:IFX_FXO_PendingCall;
	}
		
	return IFX_FXO_Failure;
}

/********************* The Functions like FXO Agent Init Shut and status ****************/

/***************************************************************************
* Function Name    : IFX_FXO_AgentInit
* Description      : -It Memsets the appropriate xFxoInfo structure. 
								populates the EndpointId in it
							-It Registers the Callbacks 		
							-It Registers with Message router								 
							-Initializes FXO with Default values	
* Input Values     :pxEndptInfo 
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
e_IFX_Return IFX_FXO_AgentInit(
										char8 ppszEndptId[][IFX_MAX_ENDPOINTID_LEN],
										uint32 uiNumEndpts,
										uchar8 vucDbgId)
{
	x_IFX_FXO_Info * pxEndptInfo = 0;
	x_IFX_CMGR_CallBackList xCallBackList = {0};	
	uchar8 ucFreeSlot = 0;
	uchar8 ucCnt = 0;
	
	/*ASSIGN THE DEBUG ID */
	vucFXOModId = vucDbgId;
	
	IFX_DBGC(vucFXOModId, 
		IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Initializing FXO Agent");
	for(ucCnt = 0;ucCnt<uiNumEndpts;ucCnt++)
	{	
		/*Search for Free endpoint*/
		for(ucFreeSlot = 0;ucFreeSlot < IFX_MMGR_MAX_FXO_CHANNELS;ucFreeSlot++)
		{
			if(vaxFXOInfo[ucFreeSlot].szEndPointId[0] == '\0')
			{
				pxEndptInfo = &vaxFXOInfo[ucFreeSlot];
				break;
			}
		}
		/*No Agent is found :Failure*/			
		if(ucFreeSlot == IFX_MMGR_MAX_FXO_CHANNELS)
		{	
			IFX_DBGC(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
				ppszEndptId[ucCnt], 
				"Could Not Initiate Endppoint. Max FXO Endpoint Reached" );
			return IFX_FAILURE;
		}				
	
		memset(pxEndptInfo,0,sizeof(x_IFX_FXO_Info));
		/* Initializes FXO with Default values */
		pxEndptInfo->eCPTDActv = IFX_MMGR_MAX_TONE;	
		strcpy(pxEndptInfo->szEndPointId,ppszEndptId[ucCnt]);
		//IFX_MakeFXOIdle(pxEndptInfo); //????
		pxEndptInfo->xCIDdata.szCallerNumber[0] = '\0';
		strcpy(pxEndptInfo->xCIDdata.szCallerName,"Anonymous");
	}

	/*Now populate the CallBack function pointers*/
	//memset(&xCallBackList,0,sizeof(x_IFX_CMGR_CallBackList));
	xCallBackList.pfnCallIncoming = IFX_FXO_CallIncoming;
	xCallBackList.pfnRemoteCallRelease = IFX_FXO_RemoteCallRelease;
	xCallBackList.pfnRemoteCallAccept = IFX_FXO_RemoteCallAccept;
	xCallBackList.pfnRemoteCallAnswer = IFX_FXO_RemoteCallAnswer;
	xCallBackList.pfnRemoteCallHold = IFX_FXO_RemoteCallHold;
	xCallBackList.pfnRemoteCallResume = IFX_FXO_RemoteCallResume;
	xCallBackList.pfnCallHoldRsp = IFX_FXO_CallHoldRsp;
	xCallBackList.pfnCallResumeRsp = IFX_FXO_CallResumeRsp;	
	xCallBackList.pfnCallFwdInfo = IFX_FXO_CallFwdInfo;
#ifdef MESSAGE_SUPPORT
	xCallBackList.pfnSmsRcv = IFX_FXO_SMS_SmsReceived;
	xCallBackList.pfnSmsStatus = IFX_FXO_SMS_SmsStatus;
#endif	
	xCallBackList.pfnBlindTxReq = IFX_FXO_BlindTxRequest;
	xCallBackList.pfnBlindTxStatus = IFX_FXO_BlindTxStatus;
	xCallBackList.pfnAttendedTxReq = IFX_FXO_AttendedTxRequest;
	xCallBackList.pfnAttendedTxStatus = IFX_FXO_AttendedTxStatus;
	xCallBackList.pfnInfoRcv = IFX_FXO_RecvInfo;
	xCallBackList.pfnCallIdRep = IFX_FXO_CallIdReplace;
	/* Register the callbacks with CMGR */
	if( IFX_SUCCESS != 
			IFX_CMGR_CallBacksRegister(ppszEndptId,uiNumEndpts,&xCallBackList))
  { 
		IFX_DBGC(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
			ppszEndptId[0], 
			"Could Not Register Callbacks With Call Manager" );
    return IFX_FAILURE;        
  }        
	/* Register with Message router */
	if( IFX_SUCCESS != 
			IFX_MSGRTR_EventCallBackRegister(ppszEndptId, 
									(uchar8)uiNumEndpts, IFX_FXO_MSGRTR_EvtHdlr) )
  { 
		IFX_DBGC(vucFXOModId,
			IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO, ppszEndptId[0], 
			"Could Not Register Callbacks For Message Routing" );
    return IFX_FAILURE;        
  }        
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_FXO_AgentShut
* Description      :- It Calls MakeFXOIdle
						  - It Unregisters all the callbacks.
* Input Values     : 
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
e_IFX_Return IFX_FXO_AgentShut(char8 ppszEndptId[][IFX_MAX_ENDPOINTID_LEN],
											uint32 uiNumEndpts)
{	
	x_IFX_FXO_Info * pxEndptInfo = &vaxFXOInfo[0];
	uchar8 ucCount = 0;
	uchar8 ucCnt = 0;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	for(ucCnt = 0;ucCnt<uiNumEndpts;ucCnt++)
	{	
		/*Search for Free endpoint*/
		for(ucCount = 0;ucCount < IFX_MMGR_MAX_FXO_CHANNELS;ucCount++)
		{
			if(vaxFXOInfo[ucCount].szEndPointId[0] == '\0')
			{
				pxEndptInfo = &vaxFXOInfo[ucCount];
				break;
			}
		}
		
		/*No Agent is found :Failure*/			
		if(ucCount == IFX_MMGR_MAX_FXO_CHANNELS)
			return IFX_FAILURE;
		/**Make the Fxo Idle*/
		IFX_MakeFXOIdle(pxEndptInfo);
		/*Memset the endpoint Id*/
		strcpy(pxEndptInfo->szEndPointId,"");
	}

	if( IFX_SUCCESS != 
			IFX_MSGRTR_EventCallBackUnregister(ppszEndptId,uiNumEndpts) )
	{
		IFX_DBGC(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
			ppszEndptId[0], 
			"Could Not Unregister Callbacks With Call Manager" );
	}
	
	if( IFX_SUCCESS != 
			IFX_CMGR_CallBacksUnRegister(ppszEndptId,uiNumEndpts))
	{ 
		IFX_DBGC(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
			ppszEndptId[0], 
			"Coudl Not Unregister Callbacks For Message Routing" );
	}        
	return IFX_SUCCESS;		
}

/*********************** FSM handlers*************/

/***************************************************************************
* Function Name    : IFX_FXO_IgnoreHdlr
* Description      : 
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_IgnoreHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	/*Ignore the event*/
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	return IFX_SUCCESS;
}
/****************** IDLE STATE ****************/

/***************************************************************************
* Function Name    :IFX_FXO_IdleIncCallHdlrHdlr 
* Description      : 
							Logic-Check RING_STARTED flag, it set, reject the call
         				else Call AllocResource do off hook , check for Number 
										of digits received.
             				-if 0 , Start CPTD  for Busy Tone,move to CONVERSATION state, 
										function callback returns	with CallAnswer.
             				-if > 0 Start DIAL_WAIT_TIMER .Start CPTD for DialTone.
										Populate DialString.	move to DIAL_WAIT state, 
										function callback returns with CallAccept.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_IdleIncCallHdlrHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
   /*Check for IFX_FXO_RING_START_RCVD flag*/
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_RING_START_RCVD))
	{		
		/*Call Rejected*/
		IFX_DBGC(vucFXOModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
			"There Is A Incoming Call. Can Not Accept Call Now");
		pxEvtInfo->eReturn = IFX_FXO_RejectCall;
		return IFX_SUCCESS;
	}
	/*Allocate the Resource*/
	if(IFX_FAILURE == IFX_FXO_AllocResource(pxEndptInfo))
	{		
		IFX_MakeFXOIdle(pxEndptInfo);
		pxEvtInfo->eReturn = IFX_FXO_RejectCall;
		return IFX_SUCCESS;
	}
	/*Do off hook*/
	if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
	{		
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}
	/*
	 * If no digits have been received, it means two stage dialing so move in to
	 * conversation, start Busy CPTD. If digits have been received, then start
	 * CPTD to detect dial tone & start timer for this. Save received digit and
	 * move to DIAL_WAIT state.
	 */
	if(0 == strlen(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt))
	{
		IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
			"No Digits Reeived. Its Two-Stage Diaing");
		IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_BUSY_TONE);
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo)
		pxEvtInfo->eReturn = IFX_FXO_AnswerCall;
	} else {	
		IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_DIAL_TONE);
		IFX_FXO_StartToneTimer(DIALWAIT,DEFAULT,pxEndptInfo);		
		IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																							pxEndptInfo)
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_DIAL_WAIT,pxEndptInfo)
		pxEvtInfo->eReturn = IFX_FXO_AcceptCall;
	}

	pxEndptInfo->axFxoCallData[0].uiCallId = 
											pxEvtInfo->uxEvtInfo.xIncCallInfo.uiCallId;
	pxEndptInfo->axFxoCallData[0].eCallType = 
											pxEvtInfo->uxEvtInfo.xIncCallInfo.eCallType;
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_IdleRingStartHdlr 
* Description      : 
							Logic-Set flag RING_STARTED,Call AllocResource.					
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/

STATIC e_IFX_Return IFX_FXO_IdleRingStartHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	/* Check the if Ring start has already occured */
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_RING_START_RCVD))
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
    	"Ring Start has already received,So event dropped");
	}
	else
	{	
		/*Allocate the Resource, if allocate move to Ringing*/
		if(IFX_FAILURE == IFX_FXO_AllocResource(pxEndptInfo))
		{
			IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_RINGING,pxEndptInfo) 	
		}
		else
		{
			/*Set the Ring Started Flag*/	
			IFX_FXO_SET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_RING_START_RCVD);
		}
	}
	return IFX_SUCCESS;
}


/***************************************************************************
* Function Name    : IFX_FXO_IdleRingStopHdlr
* Description      : 
						     This function is called when RingStop event is received.
							  Logic-Clear RING_STARTED flag, Start RingTimer and CID  
									  Move to CID_WAIT state
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_IdleRingStopHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/* Check the if Ring start has already occured */
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_RING_START_RCVD)==0)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
				"Ring Start has not received, So event dropped");
		return IFX_SUCCESS;
	}				
	/* Reset the Ring Started Flag, Start Ring Timer, Start CID Rx,
		 Move to CID wait State */
	IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_RING_START_RCVD);
	IFX_FXO_StartToneTimer(RINGBURST,DEFAULT,pxEndptInfo);	
	IFX_MMGR_CidRxStart(pxEndptInfo->szEndPointId,
						IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_HOOK_STATUS));
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CID_WAIT,pxEndptInfo)
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_IdleEmgHdlr
* Description      : 
					  		Logic:-Check RING_STARTED flag,Set EMG_CALL flag.
							=>it set, do off hook, start ON_HOOK_WAIT timer,copy Emergency 
							  call data in a local buffer,copy the number to dialString. 
							  Move to CONVERSATION state.
					  		=>else Call AllocResource do off hook,Copy the emergency call data in buffer ,
							  Start CPTD for Dial tone,start DIAL_WAIT Timer. 
							  Populate DialDigit string.move to DIAL_WAIT state,
							  function callback returns with CallAccept.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_IdleEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   	"Got Emergency call.");
	IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																						pxEndptInfo)
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_RING_START_RCVD))
	{
		IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
    	"There Is Incoming Call. Disconnecting Incoming Call");	
		/*Populate the Emergency call's data*/
		memcpy(&(pxEndptInfo->xEmgCallInfo),&(pxEvtInfo->uxEvtInfo.xIncCallInfo),
																			sizeof(x_IFX_FXO_IncCallInfo));	
		/* Ring is already received. So receive the call, start on-hook wait timer
		 * and move to conversation state.  */	
		if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
		{		
			IFX_MakeFXOIdle(pxEndptInfo); //!! This is Major Failure
			return IFX_FAILURE;
		}
		IFX_FXO_StartToneTimer(ON_HK_WAIT, DEFAULT, pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION, pxEndptInfo);		
		pxEvtInfo->eReturn = IFX_FXO_AcceptCall;
		return eReturn;
	}

	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
												  	"Dialing Out Emergency Number");
	/* Allocate the Resource */
	if(IFX_FAILURE == IFX_FXO_AllocResource(pxEndptInfo))
	{		
		IFX_MakeFXOIdle(pxEndptInfo);
		pxEvtInfo->eReturn = IFX_FXO_RejectCall;
		return IFX_SUCCESS;
	}
	/*Do off hook*/
	if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
	{		
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}
	/* Populate the Active call's data, Start CPTD for dial tone, Start Dial wait
		 timer, Move to Dial Wait State */
	pxEndptInfo->axFxoCallData[0].uiCallId = 
											pxEvtInfo->uxEvtInfo.xIncCallInfo.uiCallId;
	pxEndptInfo->axFxoCallData[0].eCallType = 
											pxEvtInfo->uxEvtInfo.xIncCallInfo.eCallType;
	IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_DIAL_TONE);
	IFX_FXO_StartToneTimer(DIALWAIT,DEFAULT,pxEndptInfo);	
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_DIAL_WAIT,pxEndptInfo);		
	pxEvtInfo->eReturn = IFX_FXO_AcceptCall;	
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_IdleTxmitSMSHdlr
* Description      : Logic-Check RING_STARTED flag, it set, reject the SMS
    						else Call AllocResource do off hook , Start CPTD for Dial tone ,
    							start DIAL_WAIT Timer.Set the flag MOVE_TO_SMS.
    							Populate the DialString with SM-SC/SME/DMI Number.
    							Move State to DIAL_WAIT.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_IdleTxmitSMSHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Check the RING_START_RCVD flag*/
	/*
	if(Set)
	{
		-Reject the SMS
		-Return
	}
	else
	{
		-Call AllocResource
		-Do off hook
		-Populate DialString with SM-Sc/0/DMI
		-Start DialWait timer
		-Start CPTD for dial tone
		-Move to dial wait state
		-AcceptSMS
		-Return
	}	
	*/
	return IFX_SUCCESS;
}

/****************** CID_WAIT STATE ****************/

/***************************************************************************
* Function Name    : IFX_FXO_CWRingStartHdlr
* Description      : 
		Logic:-Check the FXO Mode
			if(Gateway mode && ((Outgoing call block set)||(No valid voiceline attached))
      		Restart the RingTimer.Cancel CID.Move to Ringing state.
				(Let the device ring but donot pickup So move to ringing state 
				without initiating call and starting retry timer)
    		if forwarding Mode => Restart the RingTimer.Cancel CID.Populate 
											RetryCallData.Call InitCall API from CMGR
    					InitCall Return values:
     			-CallAccepted:Move to RINGING state.
     			-CallAnswered:Cancel the RingStart timer.do off hook.Start CPTD for BUSY tone.
            	Move to CONVERSATION state.
     			-Pending:Move to RINGING state.
     			-Busy:Start RetryTimer.Move to RINGING state.
    if Gateway mode => Stop the RingTimer,Cancel the CID, do off Hook. Start DialTone
      and dial tone timer.Start CPTD for Busy tone.Move the state to DIGIT_COLLECT. 
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_CWRingStartHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	boolean bGWMode = 0;
	e_IFX_ReasonCode eReason;
	boolean bBlocked = IFX_FALSE;
#if 0
	uchar8 ucEnabled=0;
	x_IFX_CalledAddr xFwdAdress;
#endif
	IFX_DBGA(vucFXOModId,
		IFX_DBG_LVL_HIGH, IFX_DBG_ATA_FUNC_ENTRY_INFO, __FUNCTION__ ,"Entry");
	
	IFX_MMGR_CidRxStop(pxEndptInfo->szEndPointId);/*Stop CID Rx*/
	IFX_FXO_STOPTIMER(pxEndptInfo->uiRingBurstTimId);	/*Stop the Ring timer*/
	/*Querrying mode of the Fxo line*/
	if(IFX_FAILURE == IFX_CIF_FxoModeGet(pxEndptInfo->szEndPointId,&bGWMode,
																						&eReason))
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Configuration interface failure");
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
      "Caller ID Received ", pxEndptInfo->xCIDdata.szCallerNumber);
	printf("CID Received %s\n",pxEndptInfo->xCIDdata.szCallerNumber);
# if 0			  
	//FIX FOR CALL FWD FEATURE -- UNCONDITIONAL
	/*Querry for PSTN call Fwd Address*/
 	if(IFX_CIF_FxoCallForwardAddrGet(pxEndptInfo->szEndPointId,
	                 &ucEnabled,&xFwdAdress,&eReason)== IFX_FAILURE)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Configuration interface failure");
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}		  

	/*If Call Fwd is enable*/
	if((ucEnabled) && (!bGwMode))
	{
		if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
		{		
			IFX_MakeFXOIdle(pxEndptInfo);
			return IFX_FAILURE;
		}
		
		switch(IFX_FXO_CallInitiate(pxEndptInfo,
									&pxEndptInfo->axFxoCallData[0].uiCallId,
									xFwdAdress.acCalledAddr,IFX_TRUE,IFX_DP_LOCAL_VOIP_CALLS))
		{
				case IFX_FXO_Failure:
						IFX_MakeFXOIdle(pxEndptInfo);
						return IFX_FAILURE;
   			case IFX_FXO_AnswerCall:
						/*Start CPTD for Busy Tone*/
						IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_BUSY_TONE);
						/*Move the State to Conversation*/
						IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo)
						return eReturn;
				case IFX_FXO_RejectCall:
						/*memset the calldata*/
						memset(&(pxEndptInfo->axFxoCallData[0]),0,
														sizeof(x_IFX_FXO_CallData));
						/*Stop the CPTD*/	
						IFX_FXO_StopCptd(pxEndptInfo);
						/*Do on hook*/
						if(IFX_FAILURE == IFX_FXO_SetOnHook(pxEndptInfo))
						{
							IFX_MakeFXOIdle(pxEndptInfo);
							return IFX_FAILURE;		
						}
						/*Start off hook wait timer*/
						IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
						/*Move to Off hook wait state*/
						IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
						return eReturn;
				case IFX_FXO_AcceptCall:
						/*Start Ringback tone and timer*/
						IFX_FXO_StartToneTimer(RING_BACK_TONE,DEFAULT,pxEndptInfo);	
						/*Move to Ringback State*/	
						IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_RINGBACK,pxEndptInfo);		
						return eReturn;
				case IFX_FXO_PendingCall:
						/*Move to Ringback State*/	
						IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_RINGBACK,pxEndptInfo);		
						return eReturn;
				default:
						IFX_MakeFXOIdle(pxEndptInfo);
						return IFX_FAILURE;		
		}
		
	}		  
# endif
	if(bGWMode) //FXO in gateway mode?
	{
		/*Querrying for Outgoing call bar*/
		IFX_CIF_OutgoingCallBlockCheck(pxEndptInfo->szEndPointId,&bBlocked,&eReason);
		if( IFX_TRUE == bBlocked ) 
		{
			IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                   "Outgoing Calls Are Blocked");
			/*Move state to Ringing*/
			IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_RINGING,pxEndptInfo) 			
			return eReturn;
		}
		/*Else pick up the call*/
		if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
		{		
			IFX_MakeFXOIdle(pxEndptInfo);
			return IFX_FAILURE;
		}
		//Start Dial tone & timer, start busy CPTD and move to digit collect state
		IFX_FXO_StartToneTimer(DIAL_TONE,DEFAULT,pxEndptInfo);	
		IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_BUSY_TONE);
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_DIGIT_COLLECT,pxEndptInfo) 
		return eReturn;
	}
	/* mode is forwarding, initiate call to terminals */
	switch(IFX_FXO_CallInitiate(pxEndptInfo,
									&pxEndptInfo->axFxoCallData[0].uiCallId,
									(char*)NULL,IFX_FALSE,
									IFX_DP_MAX_DP_ACTIONS))
	{
		case IFX_FXO_Failure:
				IFX_MakeFXOIdle(pxEndptInfo);
				eReturn = IFX_FAILURE;
				break;
   	case IFX_FXO_AnswerCall:
				/*Ring is already received. So receive the call*/	
				if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
				{		
					IFX_MakeFXOIdle(pxEndptInfo);
					eReturn = IFX_FAILURE;
				} else {
					/* Start CPTD for Busy Tone and Move the State to Conversation */
					IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_BUSY_TONE);
					IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo)
				}
   			break;
		case IFX_FXO_RejectCall:
				/*
				 * It could be because there are no resources/terminal to accept call.
				 * So try again later.
				 */
				memset(&(pxEndptInfo->axFxoCallData[0]),0, sizeof(x_IFX_FXO_CallData));
				/*Start Ringburst timer, Start Retry timer and Move state to Ringing */
				IFX_FXO_StartToneTimer(RINGBURST, DEFAULT, pxEndptInfo);	
				IFX_FXO_StartToneTimer(RETRY, DEFAULT, pxEndptInfo);	
				IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_RINGING, pxEndptInfo) 	
				break;
		case IFX_FXO_AcceptCall:
		case IFX_FXO_PendingCall:
				/* Start Ringburst timer, Move state to Ringing */
				IFX_FXO_StartToneTimer(RINGBURST,DEFAULT,pxEndptInfo);	
				IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_RINGING,pxEndptInfo) 	
				break;
		default:
				/* Irrelavant behaviour........ */
				/* Make the endpoint Idle */
				IFX_MakeFXOIdle(pxEndptInfo);
				eReturn = IFX_FAILURE;				
	}
	return eReturn;
}

/*******************************************************************************
* Function Name    : IFX_FXO_CWDigitEventHdlr 
* Description      : 
* Input Values     : pxEndptInfo - Endpoint Info
*                    pxEvtInfo   - Pointer to x_IFX_FXO_EvtInfo struct.
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE
* Notes            :
*******************************************************************************/
STATIC e_IFX_Return IFX_FXO_CWDigitEventHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	printf("CID digit Received %s\n",pxEvtInfo->uxEvtInfo.szDgtPrs);
  strcat(pxEndptInfo->xCIDdata.szCallerNumber,  pxEvtInfo->uxEvtInfo.szDgtPrs);
	printf("CID  %s\n",pxEndptInfo->xCIDdata.szCallerNumber);
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_FXO_CWRingTimExpHdlr
* Description      : 
							Logic-Stop CID Rx Check for DMI value
							=>[DMI = 0/1] Or CID not populated :-Call ReleaseResource.
											Reset the flags.Move to IDLE State.
          				=>[DMI = 2/9]:-Set the flag MOVE_TO_SMS.Populate the DialString 
											with SM-SC/SME/DMI Number.	Start CPTD for Dial Tone.
											Start the DIAL_WAIT Timer.Move State to DIAL_WAIT.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_CWRingTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Stop CID Rx*/
	IFX_MMGR_CidRxStop(pxEndptInfo->szEndPointId);
	/*DMI not between 2 and 9 or not populated */
	if((pxEndptInfo->cDMI < '2' )||(pxEndptInfo->cDMI > '9' )) 
	{
		pxEndptInfo->cDMI = '0';
		/*Deallocate the resource*/
		//IFX_FXO_DeallocResource(pxEndptInfo);		
		/*Make the endpoint Idle*/
		IFX_MakeFXOIdle(pxEndptInfo);
		return eReturn;
	}
	/*if DMI between 2 and 9 
	-Querry for SM-SC Number.
	-Populate dialString with SMSC number\0\DMI .
	-Start CPTD for Dial tone.
	-Start dial wait timer
	-Move to dial wait state.
	*/
	return eReturn;
}


/***************************************************************************
* Function Name    : IFX_FXO_CWCIDRxHdlr
* Description      : 
							Logic- Populate the CID.Match the Number with SM-SC Number
			 				-SM-Sc Number Matched:Check for the DMI value
         					=>[DMI = 0/1]:-cacnel the RingTimer. 
									do off hook,Start CPTD for busy tone,Move to SMS state.
         					=>[DMI = 2/9]:-(Wait till ringing stops).
      					-SM-SC Number Not Matched:(Wait till Next ringStart)				 
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_CWCIDRxHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Populate the CID data*/
	printf("Received CID end\n");
	memcpy(&(pxEndptInfo->xCIDdata),&(pxEvtInfo->uxEvtInfo.xCIDData),
														sizeof(x_IFX_MMGR_CidParams));
	printf("CID Received %s\n",pxEvtInfo->uxEvtInfo.xCIDData.szCallerNumber);
	/*
	-Querry for SM-SC Number.
	-Check the SM-SC number with the number received in caller Id.
	if(Matched)
	{
		Read the DMI value in CID data and populate the cDMI.
		if(cDMI < 2)
		{
			Cancel the Ring Timer
			Do off hook.
			Start CPTD for Busy tone
			Move to SMS state.
		}		
	}	
	*/
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_CWEmgHdlr
* Description      : 
			 				Logic-Stop CID Rx.Populate the EmergencyCall 
									data in a local buffer.do off hook, start ON_HOOK_WAIT timer,
          						copy the number to dialString,set EMG_CALL flag.
          						Move to CONVERSATION state.send Callaccept
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_CWEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Stop CID Rx*/
	IFX_MMGR_CidRxStop(pxEndptInfo->szEndPointId);
	/*Populate the Emergency call's data*/
	memcpy(&(pxEndptInfo->xEmgCallInfo),
			&(pxEvtInfo->uxEvtInfo.xIncCallInfo),sizeof(x_IFX_FXO_IncCallInfo));	
	/*Populate the DialString*/
   IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																					pxEndptInfo)
	/*Ring is already received. So receive the call*/	
	if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
	{		
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}
	/*Start on hook wait timer*/
	IFX_FXO_StartToneTimer(ON_HK_WAIT,DEFAULT,pxEndptInfo);	
	/*Move to Conversation State*/	
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo);		
	/*Return CallAccept*/		
	pxEvtInfo->eReturn = IFX_FXO_AcceptCall;
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_DWToneDetectHdlr  
* Description      :
   				     Logic-[Dial tone]Cancel the DIAL_WAIT timer.Pick 
							up the first digit from DialString and play tone.
							Start the LINE_DIGIT Timer.Move the state to the DIGIT_DIAL.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DWToneDetectHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Verify the tone is dial tone else return success*/
	if(IFX_MMGR_DIAL_TONE != pxEvtInfo->uxEvtInfo.eToneDetect)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR, "Wrong Tone Detected");
		return IFX_SUCCESS;
	} 
	IFX_DBGC(vucFXOModId, 
		IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Received PSTN Dial Tone");
	
	/* Stop dial tone timer. Pick the First digit and call the playtone. Move the 
		 pointer to next digit. Start line digit timer. Move to digit dial state */
	IFX_FXO_STOPTIMER(pxEndptInfo->uiDialWaitTimId)
	IFX_MMGR_DtmfPlayLocal(pxEndptInfo->szEndPointId, *(pxEndptInfo->pcCurrDgt));
	pxEndptInfo->pcCurrDgt++;
	IFX_FXO_StartToneTimer(LINE_DIGIT,DEFAULT,pxEndptInfo);	
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_DIGIT_DIAL,pxEndptInfo);
	return eReturn;

}

/***************************************************************************
* Function Name    :IFX_FXO_DWRelHdlr  
* Description      :
         Logic-(Can come only on actv call, can be emergency call also)
					Cancel the CPTD and dial wait timer.Reset EMG_CALL flag.
               do set on hook.Start the off hook wait timer.
					move to OFF_HOOK_WAIT state.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DWRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/**Check whether it is on active call*/
	if(pxEvtInfo->uiCallId != pxEndptInfo->axFxoCallData[0].uiCallId)
	{	
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Release on Wrong CID");	
		return IFX_FAILURE;
	}
		
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Remote Released Call");	

	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	
	/* stop CPTD, Cancel Dial Wait timer, Reset Emergency call flag */
	IFX_FXO_StopCptd(pxEndptInfo);
	IFX_FXO_STOPTIMER(pxEndptInfo->uiDialWaitTimId)
  IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING);
	if(IFX_FAILURE == (eReturn=IFX_FXO_SetOnHook(pxEndptInfo)) )
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		/* Start off hook wait timer and change state to Off hook wait */
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
	}
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_DWEmgHdlr 
* Description      :
         	Logic-Set EMG_CALL flag.Copy the call data in to active call.
						Send ReleaseCall to the previous Active call.populate the 
						Dialstring.send Callaccept to it.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DWEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   	"Got Emergency call. Disconnecting Incoming call");
	/* Call Release, store emergency call info */
	IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
	/*memset the calldata*/
	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	pxEndptInfo->axFxoCallData[0].uiCallId = 
					pxEvtInfo->uxEvtInfo.xIncCallInfo.uiCallId;
	pxEndptInfo->axFxoCallData[0].eCallType = 
					pxEvtInfo->uxEvtInfo.xIncCallInfo.eCallType;
   IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																					pxEndptInfo)
	pxEvtInfo->eReturn = IFX_FXO_AcceptCall;	
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_FXO_DWDialWtTimExpHdlr 
* Description      :
         	Logic-Cancel the Dial tone CPTD.Pick up the first digit
        						from DialString and play tone.Start the LINE_DIGIT Timer.
		  						Move the state to the DIGIT_DIAL.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DWDialWtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/* Cancel the CPTD, Pick the First digit and call the playtone, Move the 
		 pointer to next digit, Start line digit timer, Move to digit dial state */
	IFX_FXO_StopCptd(pxEndptInfo);
	IFX_MMGR_DtmfPlayLocal(pxEndptInfo->szEndPointId,*(pxEndptInfo->pcCurrDgt));
	pxEndptInfo->pcCurrDgt++;
	IFX_FXO_StartToneTimer(LINE_DIGIT,DEFAULT,pxEndptInfo);	
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_DIGIT_DIAL,pxEndptInfo)
	return eReturn;
}

/***************************************************************************
* Function Name    :  IFX_FXO_DDLineDgtTimExpHdlr
* Description      :
							stop the currently playing digit tone,
							Check any digits are left in the string,
        						if yes=>Start the LINE_INTERDIGIT timer.
								if no=>dialing is complete. check MOVE_TO_SMS. and clear it.
								-->MOVE_TO_SMS flag set:Start busy CPTD, move to SMS state.
								-->MOVE_TO_SMS flag not set:Start busy CPTD,
								  ALSO Send AnswerCall to active call, move to CONVERSATION state.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DDLineDgtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	e_IFX_ReasonCode eReason;
	e_IFX_CMGR_Status eStatus;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/* Stop the currently playing DTMF tone. If there are still digits to dial
	   then start interdigit timer */
	IFX_MMGR_DtmfStopLocal(pxEndptInfo->szEndPointId);
	if(*(pxEndptInfo->pcCurrDgt))
	{
		IFX_FXO_StartToneTimer(LINE_INTERDIGIT,DEFAULT,pxEndptInfo);	
		return eReturn;
	}
	/*Control comes here means the Digits are over*/	
	/*Check whether MOVE_TO_SMS flag is set*/
	/*if(Set)
	{
		-Reset the MOVE_TO_SMS flag	
		-Start CPTD for busy tone
		-Move the state to SMS
		-Return eRetVal;
	}
	*/
	
	/* Start CPTD for busy tone, Send answer to active call */
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   	"Digits Are Dialed Out. Answering Call.");
	IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_BUSY_TONE);	
	eReturn = IFX_CMGR_CallAnswer(pxEndptInfo->axFxoCallData[0].uiCallId,
																		&eStatus,&eReason);
	if((IFX_FAILURE == eReturn )||(IFX_CMGR_STATUS_FAIL == eStatus))
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		/*Move to conversation state*/	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo);
	}
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_DDLineInterDgtTimExpHdlr 
* Description      : pick up the next digit from dialString. call the playtone.
* 									 and start LINE_DIGIT Timer
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DDLineInterDgtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/* Pick the digit and call the playtone, move the pointer to next digit */
	IFX_MMGR_DtmfPlayLocal(pxEndptInfo->szEndPointId, *(pxEndptInfo->pcCurrDgt));
	pxEndptInfo->pcCurrDgt++;
	IFX_FXO_StartToneTimer(LINE_DIGIT,DEFAULT,pxEndptInfo);	
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_FXO_DDRelHdlr
* Description      :
		     	Logic-(Can come only on actv call)
      		  Cancel the LINE_DIGIT /LINE_INTERDIGIT timers if they active.
      		  do on hook.Start the off_HK_WaitTimer.Reset the EMG_CALL flag. move to OFF_HK_WAIT state.	
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DDRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/** Check whether it is on active call */
	if(pxEvtInfo->uiCallId != pxEndptInfo->axFxoCallData[0].uiCallId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Release on Wrong CID");		
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}		
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   	"Remote Call Released. Disconnecting PSTN Call");
	
	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	/* Stop Line & inder digit digit timer, Start off hook wait timer and Move 
		 to Off hook wait state */
	IFX_FXO_STOPTIMER(pxEndptInfo->uiLineDgtTimId)
	IFX_FXO_STOPTIMER(pxEndptInfo->uiLineInterDgtTimId)
   IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,
													IFX_FXO_EMG_CALL_PROCEEDING);
	if(IFX_FAILURE == (eReturn=IFX_FXO_SetOnHook(pxEndptInfo)) )
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
	}
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_DDEmgHdlr 
* Description      :
				  Logic-Set EMG_CALL flag.Stop the Line dgt/InterDgt timers.
					  do on-hook.start OFF_HOOK_WAIT timer.
					  copy the calldata into local buffer.
					  copy the string to dialstring.Do release to active call
					  Move the state to OFF_HK_WAIT.send Callaccept	
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DDEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   	"Got Emergency call. Disconnecting Ongoing Call");
	/* Stop Line & inter digit timer. Release call and disconnect PSTN line. Store
	   emergency call info. Start off-hook wait timer and  Move to Off hook wait 
		 state */
	IFX_FXO_STOPTIMER(pxEndptInfo->uiLineDgtTimId)
	IFX_FXO_STOPTIMER(pxEndptInfo->uiLineInterDgtTimId)
	IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	memcpy(&(pxEndptInfo->xEmgCallInfo),&(pxEvtInfo->uxEvtInfo.xIncCallInfo),
																sizeof(x_IFX_FXO_IncCallInfo));	
   IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																						pxEndptInfo)
	if(IFX_FAILURE == (eReturn = IFX_FXO_SetOnHook(pxEndptInfo)) )
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
		pxEvtInfo->eReturn = IFX_FXO_AcceptCall;	
	}
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_DCDgtPrsHdlr 
* Description      : 
						  Logic- Stop the dial tone if playing and the timer.
								Stop the Interdigit timer. Invoke the DialPlan.
      					=>Dial plan output=continue:As per the output 
								start the Interdigit timer again.
      					=>Dial plan output=Mismatch:do on hook.
								start OFF_HOOK_WAIT timer and move to 
											OFF_HK_WAIT state. 
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DCDgtPrsHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	x_IFX_DP_Rule xDpRuleMatched;
	uchar8 ucAction = IFX_DP_MISMATCH;
	uint16 unInterdigitTimer = DEFAULT;
	/*If the dial tone is playing , stop the tone and timer, 
			Initialize the Dial plan structures*/
	if(pxEndptInfo->uiDialToneTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Dial tone palying, stopping tone and timer");
 		IFX_TIM_TimerStop(pxEndptInfo->uiDialToneTimId);
		//IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
		IFX_FXO_ToneStop(pxEndptInfo);
 		pxEndptInfo->uiDialToneTimId=0;
		pxEndptInfo->szDialledDigits[0] = pxEndptInfo->szDialOutDgtStr[0] = '\0';
 	}
	/* Stop Interdigit timer and store received digits */
	IFX_FXO_STOPTIMER(pxEndptInfo->uiInterDgtTimId)
	strcat(pxEndptInfo->szDialledDigits,pxEvtInfo->uxEvtInfo.szDgtPrs);

	/* Check dialed digit pattern */
	if(IFX_FAILURE == IFX_DP_Match(pxEndptInfo->szDialledDigits,
											IFX_FALSE,&ucAction,
											pxEndptInfo->szDialOutDgtStr,
											&xDpRuleMatched,&unInterdigitTimer))
	{
		//IFX_MakeFXOIdle(pxEndptInfo);
		//return IFX_FAILURE;		
		ucAction = IFX_DP_MISMATCH; //treat it mismatch
	}
	switch(ucAction)
	{
		case IFX_DP_ST_SMALL_TIM :
			/*Start Progressive interdigit timer */
			IFX_FXO_StartToneTimer(PROG_INTERDGT,unInterdigitTimer,pxEndptInfo);				
			break;
		case IFX_DP_ST_LARGE_TIM : 
			/*Start Full interdigit timer */
			IFX_FXO_StartToneTimer(FULL_INTERDGT,unInterdigitTimer,pxEndptInfo);
			break;
		case IFX_DP_MISMATCH :			
			/* Dial plan mismatch - disconnect call & update state. Once off-hook wait
			   timer expires FXO is ready to receive/make calls */
			IFX_DBGC(vucFXOModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				"Dialplan Error", pxEndptInfo->szDialledDigits);
			if(IFX_FAILURE == IFX_FXO_SetOnHook(pxEndptInfo))
			{
				IFX_MakeFXOIdle(pxEndptInfo);
				eReturn=IFX_FAILURE;		
			} else {
				IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
				IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
			}
	}
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_DCToneDetectHdlr 
* Description      : 
    				     Logic-(Busy tone)
							Stop dial tone if playing.Stop the timer.do on hook.
							else stop interdigit timer.start OFF_HOOK_WAIT timer and 
							move to OFF_HK_WAIT state.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DCToneDetectHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Verify the tone is busy tone else return success*/
	if(IFX_MMGR_BUSY_TONE != pxEvtInfo->uxEvtInfo.eToneDetect)
	{
		IFX_DBGA(vucFXOModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,"Wrong Tone detection");
		return IFX_SUCCESS;
	} 
		
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, 
													"Remote Party disconnected call");
	if(pxEndptInfo->uiDialToneTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Dial tone playing, Stopping tone and timer");
		IFX_TIM_TimerStop(pxEndptInfo->uiDialToneTimId);
		//IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
	IFX_FXO_ToneStop(pxEndptInfo);
 		pxEndptInfo->uiDialToneTimId=0;
	}
	else	
	{	
		IFX_FXO_STOPTIMER(pxEndptInfo->uiInterDgtTimId)
	}
	if(IFX_FAILURE == IFX_FXO_SetOnHook(pxEndptInfo))
	{
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;		
	}
	/* Start off hook wait timer, Move to Off hook wait state */
	IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_DCInterDgtTimExpHdlr 
* Description      : 
						    Logic-Invoke the dial plan again.
                			=>Dial plan output=Match:As per the output.Do callInit. the outputs could be
                			--->Accept:Start RINGBACK tone and timer 
										Move to RINGBACK state.
                			--->Answer:Move to CONVERSATION state.
                			--->Busy:do on hook.start OFF_HOOK_WAIT timer and 
										move to OFF_HK_WAIT state.
                			--->Pending:Move to RINGBACK state.
                			=>Dial plan output=Mismatch:do on hook.start OFF_HOOK_WAIT 
										timer and move to OFF_HK_WAIT state.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DCInterDgtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	x_IFX_DP_Rule xDpRuleMatched;
	uchar8 ucAction = IFX_DP_MISMATCH;
	uint16 unInterdigitTimer = DEFAULT;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Invoke The Numbering plan*/
	if(IFX_FAILURE == IFX_DP_Match(pxEndptInfo->szDialledDigits,IFX_TRUE,&ucAction,
							pxEndptInfo->szDialOutDgtStr,&xDpRuleMatched,&unInterdigitTimer))
	{
		IFX_DBGC(vucFXOModId, IFX_DBG_LVL_ERROR, 
			IFX_DBG_ATA_STRING_INFO, "Dialplan Error", pxEndptInfo->szDialledDigits);
		//IFX_MakeFXOIdle(pxEndptInfo);
		//return IFX_FAILURE;
		ucAction = IFX_DP_MISMATCH; 
	}
	
	if( IFX_DP_DIALOUT == ucAction)
	{
		switch( IFX_FXO_CallInitiate(
						pxEndptInfo,&pxEndptInfo->axFxoCallData[0].uiCallId,
						pxEndptInfo->szDialOutDgtStr, IFX_TRUE, xDpRuleMatched.eAction) )
		{
			case IFX_FXO_Failure:
				IFX_MakeFXOIdle(pxEndptInfo);
				eReturn=IFX_FAILURE;
				break;
			case IFX_FXO_AnswerCall:
				/*Move the State to Conversation*/
				IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo)
				break;
			case IFX_FXO_RejectCall:
				memset(&(pxEndptInfo->axFxoCallData[0]),0,
												sizeof(x_IFX_FXO_CallData));
				/* Stop the CPTD, go on hook, start off hook wait timer, move to Off
					 hook wait state */
				IFX_FXO_StopCptd(pxEndptInfo);
				if(IFX_FAILURE == IFX_FXO_SetOnHook(pxEndptInfo))
				{
					IFX_MakeFXOIdle(pxEndptInfo);
					eReturn =  IFX_FAILURE;		
				} else {
					IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
					IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
				}
				break; 
			case IFX_FXO_AcceptCall:
				/* Start Ringback tone & timer and move to ringback */
				IFX_FXO_StartToneTimer(RING_BACK_TONE, DEFAULT, pxEndptInfo);	
				//IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_RINGBACK, pxEndptInfo);		
				//break;
			case IFX_FXO_PendingCall:
				/* Move to Ringback State */	
				IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_RINGBACK, pxEndptInfo);		
				break;
			default:
				IFX_MakeFXOIdle(pxEndptInfo);
				break;		
		}
	} else { // IFX_DP_MISMATCH
		/* Stop the CPTD, Do on hook, Start off hook wait timer,Move to Off hook 
			 wait state */
		IFX_FXO_StopCptd(pxEndptInfo);
		if(IFX_FAILURE == IFX_FXO_SetOnHook(pxEndptInfo))
		{
			IFX_MakeFXOIdle(pxEndptInfo);
			eReturn=IFX_FAILURE;		
		} else {
			IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
			IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
		}
	}
	return eReturn;
}


/***************************************************************************
* Function Name    :IFX_FXO_DCDialTnTimExpHdlr 
* Description      : 
    				     Logic-Stop the Tone.do on hook.start 
								OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state. 
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DCDialTnTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/* Stop the Dial Tone, stop the CPTD and go on hook */
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
									"Could Not Receive Digits. Call disconnected");
	//IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
	IFX_FXO_ToneStop(pxEndptInfo);
	IFX_FXO_StopCptd(pxEndptInfo);
	if( IFX_FAILURE == (eReturn=IFX_FXO_SetOnHook(pxEndptInfo)) )
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		/* Start off hook wait timer and Move to Off hook wait state */
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
	}
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_DCEmgHdlr 
* Description      : 
    				    	Logic-Stop dial tone and timer if playing	else stop 
							interdigit timer	Set the EMG_CALL flag.populate the dialdigits 
							and the Emgcall data.do on hook.start OFF_HOOK_WAIT timer and 
							move to OFF_HK_WAIT state.Send AcceptCall 
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_DCEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
				  	"Got Emergency Call. Disconnecting On Going Call");
	/*Stop the dial tone if playing*/	
	if(pxEndptInfo->uiDialToneTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Dial tone Playing, Stopping tone and timer");
 		IFX_TIM_TimerStop(pxEndptInfo->uiDialToneTimId);
		//IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
		IFX_FXO_ToneStop(pxEndptInfo);
 		pxEndptInfo->uiDialToneTimId=0;
	}
	else	
	{	/*Stop Interdigit timer*/
		IFX_FXO_STOPTIMER(pxEndptInfo->uiInterDgtTimId)
	}
	/* store emergency call number */
	memcpy(&(pxEndptInfo->xEmgCallInfo),
			&(pxEvtInfo->uxEvtInfo.xIncCallInfo),sizeof(x_IFX_FXO_IncCallInfo));	
   IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
			 																															pxEndptInfo)
	/* Stop the CPTD and go on hook */
	IFX_FXO_StopCptd(pxEndptInfo);
	if(IFX_FAILURE == (eReturn=IFX_FXO_SetOnHook(pxEndptInfo)) )
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		/* Start off hook wait timer and Move to Off hook wait state */
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
		pxEvtInfo->eReturn = IFX_FXO_AcceptCall;	
	}
	return eReturn;
}
/***************************************************************************
* Function Name    : IFX_FXO_RBToneDetectHdlr 
* Description      :
    				 Logic-[Busy]-Stop RINGBACK tone and timer if running.
								Send release to active call.do on hook.
      						start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT state.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RBToneDetectHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Verify the tone is busy tone else return success*/
	if(IFX_MMGR_BUSY_TONE != pxEvtInfo->uxEvtInfo.eToneDetect)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Wrong tone Detected");
		return IFX_SUCCESS;
	} 

	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "PSTN disconnected call");
	/* Stop RingBack tone and timer if they are running*/
	if( pxEndptInfo->uiRingBkToneTimId )
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiRingBkToneTimId);
 		pxEndptInfo->uiRingBkToneTimId = 0;
		//IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
		IFX_FXO_ToneStop(pxEndptInfo);
 	}
	/* Release call with CM, stop CPTD */
	IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	IFX_FXO_StopCptd(pxEndptInfo);
	if(IFX_FAILURE == (eReturn=IFX_FXO_SetOnHook(pxEndptInfo)) )
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		/* Start off hook wait timer and Move to Off hook wait state */
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
	}
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_RBEmgHdlr  
* Description      :
   	    Logic--Stop RINGBACK tone and timer if running.Send release to active call
					Set the EMG_CALL flag.populate the dialdigits
         		and the Inc call data.do on hook.start OFF_HOOK_WAIT timer and 
					move to OFF_HK_WAIT state. Send AcceptCall in return. 
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RBEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   	"Got Emergency call. Disconnecting Incoming call");
	/* Stop RingBack tone and timer if they are running. Release call. Store 
		 emergency call info */
	if(pxEndptInfo->uiRingBkToneTimId)
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiRingBkToneTimId);
 		pxEndptInfo->uiRingBkToneTimId=0;
		//IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
		IFX_FXO_ToneStop(pxEndptInfo);
 	}
	IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	memcpy(&(pxEndptInfo->xEmgCallInfo),&(pxEvtInfo->uxEvtInfo.xIncCallInfo),
																sizeof(x_IFX_FXO_IncCallInfo));	
  IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																						pxEndptInfo)
	IFX_FXO_StopCptd(pxEndptInfo);
	if(IFX_FAILURE == (eReturn = IFX_FXO_SetOnHook(pxEndptInfo)) )
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		/*Start off hook wait timer and move to Off hook wait state. */
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
		pxEvtInfo->eReturn = IFX_FXO_AcceptCall;
	}
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_RBRelHdlr
* Description      :
    				     	Logic-(Can come only on actv call).Stop RingBack tone and 
								timers if running.Stop CPTD.do on hook.start OFF_HOOK_WAIT 
								timer and move to OFF_HK_WAIT state.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RBRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/**Check whether it is on active call*/
	if(pxEvtInfo->uiCallId != pxEndptInfo->axFxoCallData[0].uiCallId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Release on Wrong CID");		
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}
		
	IFX_DBGC(vucFXOModId, 
		IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Remote Released Call. ");		
	/* Stop RingBack tone and timer if they are running*/
	if(pxEndptInfo->uiRingBkToneTimId)
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiRingBkToneTimId);
 		pxEndptInfo->uiRingBkToneTimId=0;
		//IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
		IFX_FXO_ToneStop(pxEndptInfo);
 	}
	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	IFX_FXO_StopCptd(pxEndptInfo);
	if( IFX_FAILURE == (eReturn=IFX_FXO_SetOnHook(pxEndptInfo)) )
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		/* Start off hook wait timer and move to Off hook wait state */
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
	}
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_RBAnsHdlr
* Description      :
    					    Logic-(Can come only on active call)Stop ringback 
														tone and timer if playing. 
								Start the CPTD for BUSY tone.
      						Move the state to CONVERSATION.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RBAnsHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/**Check whether it is on active call*/
	if(pxEvtInfo->uiCallId != pxEndptInfo->axFxoCallData[0].uiCallId)
	{	
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Release on Wrong CID");
		eReturn =  IFX_FAILURE;
	}	else {
		IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Remote Answered Call");
		/* Stop RingBack tone & timer and move to conversation state */
		IFX_TIM_TimerStop(pxEndptInfo->uiRingBkToneTimId);
		pxEndptInfo->uiRingBkToneTimId=0;
		//IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
		IFX_FXO_ToneStop(pxEndptInfo);
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo)
	}
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_RBAcceptHdlr
* Description      :
    					    Logic-Start Ringback tone and timer. 
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RBAcceptHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/**Check whether it is on active call*/
	if(pxEvtInfo->uiCallId != pxEndptInfo->axFxoCallData[0].uiCallId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Accept on Wrong CID");
		eReturn = IFX_FAILURE;
	}	else {
		/* Start Ringback tone and timer */
		IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Remote Accepted Call");
		IFX_FXO_StartToneTimer(RING_BACK_TONE, DEFAULT, pxEndptInfo);	
	}
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_RBRingBackTnTimExpHdlr 
* Description      :
    				     Logic-Stop The Ringback Tone. Do ReleaseCall.do on hook.start 
								OFF_HOOK_WAIT timer
      						and move to OFF_HK_WAIT state.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RBRingBackTnTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
		
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, 
		IFX_DBG_STR, "Remote Could Not Answer Call. Disconnected");

	/* Stop RingBack tone and release call on either side */
	//IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
	IFX_FXO_ToneStop(pxEndptInfo);
	IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	IFX_FXO_StopCptd(pxEndptInfo);
	if(IFX_FAILURE == (eReturn = IFX_FXO_SetOnHook(pxEndptInfo)) )
	{
		IFX_MakeFXOIdle(pxEndptInfo);
	} else {
		/* Start off hook wait timer and Move to Off hook wait state */
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
	}
	return eReturn;
}


/***************************************************************************
* Function Name    : IFX_FXO_ConvDgtPrsHdlr 
* Description      :
        Logic-Invoke SendDigits In Call
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvDgtPrsHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	x_IFX_CMGR_DgtInfo xDgtInfo;	
	e_IFX_CMGR_Status eStatus;
	e_IFX_ReasonCode eReason;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Populate the digits*/
	strncpy(xDgtInfo.szDigits, pxEvtInfo->uxEvtInfo.szDgtPrs,IFX_MAX_ENDPOINTID_LEN-1);
	xDgtInfo.szDigits[IFX_MAX_ENDPOINTID_LEN-1]=0;
	/*Invoke the SendDigitsInCall */
	IFX_CMGR_DigitsInCallSnd(pxEndptInfo->axFxoCallData[0].uiCallId,
																	&xDgtInfo,&eStatus,&eReason);
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_FXO_ConvToneDetectHdlr 
* Description      :
        		Logic-[busy]If ON_HOOK_WAIT timer is running, Ignore the event.
    	   		 	else check the hookstate if on hook cancel the hook flash timer 
						else Do on hook.
      		  		also Send Release to active call.start OFF_HOOK_WAIT timer and 
						move to OFF_HK_WAIT state.
						Reset the emergency call flag
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE
* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvToneDetectHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/* If it is busy tone, then release the call. Go on hook. Stop hook flash & 
		 offHk-cid timer (if running). Start off-hook wait timer and move to
	   off hook wait state */
	if(IFX_MMGR_BUSY_TONE != pxEvtInfo->uxEvtInfo.eToneDetect)
	{
		//IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Wrong tone detection");
		return IFX_SUCCESS;
	}
	IFX_DBGC(vucFXOModId,
		IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Got busy tone on PSTN line, releasing call");
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_HOOK_STATUS))
	{
		if(IFX_FAILURE == IFX_FXO_SetOnHook(pxEndptInfo))
		{
			IFX_MakeFXOIdle(pxEndptInfo);
			return IFX_FAILURE;		
		}
	}
	else
	{	
		IFX_FXO_STOPTIMER(pxEndptInfo->uiHookFlashTimId)
	}
	
	if(pxEndptInfo->uiOffHkCIDTimId) // Stop Off hook CID timer if running
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiOffHkCIDTimId);
 		pxEndptInfo->uiOffHkCIDTimId=0;
		IFX_MMGR_CidRxStop(pxEndptInfo->szEndPointId);
 	}
   
	IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
	memset(&(pxEndptInfo->axFxoCallData[0]),0, sizeof(x_IFX_FXO_CallData));
	IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags, IFX_FXO_EMG_CALL_PROCEEDING);
	IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_ConvPSTNHkFlashHdlr
* Description      :
    		    Logic-If The OffHk CID is in progress, drop the event.
							ELSE:
						(If Hook flash is working)- Do Set hook flash
						(If Hook flash is NOT working)- Do set on hook. Start Hook flash timer
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvPSTNHkFlashHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/* If Off Hk CID is in progress*/
	if(pxEndptInfo->uiOffHkCIDTimId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "Off Hook CID is running So dropping the event");
		pxEvtInfo->eReturn = IFX_FXO_Failure;	
		return eReturn;		
 	}
		
	IFX_DBGC(vucFXOModId,
		IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Trying to hold PSTN call");
#if 0
	IFX_MMGR_SetHookFlash(pxEndptInfo->szEndPointId);	
#else
	/* Go on-hook, start hook-flash timer */
	if(IFX_SUCCESS == (eReturn=IFX_FXO_SetOnHook(pxEndptInfo)) )
		IFX_FXO_StartToneTimer(HOOKFLASH, DEFAULT, pxEndptInfo);
#endif
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_ConvRelHdlr 
* Description      :
		    	     Logic-(Can come on either emg call in buffer or 
														actv normal or emg call)
      	          Reset the EMG_CALL flag.Stop CPTD.Check hookstate
                  ->if on hook,cancel hookflash timer.
                  ->else do on hook.
                    ALSO start OFF_HOOK_WAIT timer and move 
							to OFF_HK_WAIT_STATE.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	//uchar8 ucFlag=0;
	e_IFX_Return eReturn = IFX_SUCCESS;

	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Peer Released Call.");
  IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING);
	
	if(pxEvtInfo->uiCallId == pxEndptInfo->axFxoCallData[0].uiCallId)
	{ //Normal calll		
		memset(&(pxEndptInfo->axFxoCallData[0]), 0,	sizeof(x_IFX_FXO_CallData));
		/* Stop hook-flash timer if running. If off-hook, go on hook. 
			 Stop CPTD, stop off-cid timer if running and stop cid reception. Start 
			 off-wait timer and move to Off hook wait state */
		IFX_FXO_STOPTIMER(pxEndptInfo->uiHookFlashTimId) ;
		if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags, IFX_FXO_HOOK_STATUS) &&
				IFX_FAILURE == IFX_FXO_SetOnHook(pxEndptInfo) ) 
		{ //failed to do on-hook. 
			IFX_MakeFXOIdle(pxEndptInfo);
			eReturn = IFX_FAILURE;		
		}
		else 
		{	
			IFX_FXO_StopCptd(pxEndptInfo);
			if(pxEndptInfo->uiOffHkCIDTimId)
			{
				IFX_TIM_TimerStop(pxEndptInfo->uiOffHkCIDTimId);
				pxEndptInfo->uiOffHkCIDTimId=0;
				IFX_MMGR_CidRxStop(pxEndptInfo->szEndPointId);
			}
			IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
			IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)
		}
	}		
	else if(pxEvtInfo->uiCallId == pxEndptInfo->xEmgCallInfo.uiCallId)
	{ //it is emergency call		
		memset(&(pxEndptInfo->xEmgCallInfo),0, sizeof(x_IFX_FXO_IncCallInfo));
	}
	else 
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Release on Wrong CID");
		//IFX_MakeFXOIdle(pxEndptInfo);
		eReturn = IFX_FAILURE;
	}
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_ConvOnHkWaitTimExpHdlr 
* Description      :
   			    Logic-do on hook and start OFF_HOOK_WAIT timer and move 
								to OFF_HK_WAIT state
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvOnHkWaitTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING))
	{
		if(IFX_FAILURE == IFX_FXO_SetOnHook(pxEndptInfo))
		{ 
			IFX_MakeFXOIdle(pxEndptInfo); 
			return IFX_FAILURE;		
		}
		IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
		IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo)	
		return eReturn;
	}
	IFX_MakeFXOIdle(pxEndptInfo);
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_ConvPSTNHkFlashTimExpHdlr 
* Description      :
				         Logic-do off hook
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvPSTNHkFlashTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;

	if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
	{		
		IFX_MakeFXOIdle(pxEndptInfo);
		eReturn = IFX_FAILURE;
	}
	IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
  	(IFX_SUCCESS == eReturn )?"Hook-flash is successfull":"Hook-flash failed");
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_ConvPSTNHkFlashTimExpHdlr 
* Description      :
    				     Logic-Start Off hook CID reception. 
						  				Start Off hook CID timer
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvCASHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	/* Start Off hook CID and timer */
	IFX_MMGR_CidRxStart(pxEndptInfo->szEndPointId,
						IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_HOOK_STATUS));
	IFX_FXO_StartToneTimer(OFF_HK_CID, DEFAULT, pxEndptInfo);	
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_FXO_ConvOffHkCIDTimExpHdlr 
* Description      :
    				     Logic-Stop The Off hook CID
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvOffHkCIDTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	/* Stop CID Rx */
	IFX_MMGR_CidRxStop(pxEndptInfo->szEndPointId);
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    :  IFX_FXO_ConvCIDHdlr
* Description      :
					     Logic-Stop The Off Hk CID timer.
							if SM-SC number == Number received,drop the event
							else Invoke Send OffHook CID
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvCIDHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn ;
	x_IFX_CMGR_CidInfo xCidInfo;
  memset(&xCidInfo,0,sizeof(x_IFX_CMGR_CidInfo));
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	//strcpy(xCidInfo.szDateOfCall,"24/05/2007"); //TODO
	//strcpy(xCidInfo.szTimeOfCall,"00:00:00");
	strcpy(xCidInfo.szDisplayName,pxEvtInfo->uxEvtInfo.xCIDData.szCallerName);
	/*Stop the Off hook CID timer*/
	IFX_FXO_STOPTIMER(pxEndptInfo->uiOffHkCIDTimId)
	/* TODO: 
		 If received number matches with SC-SC Number then drop this event, else 
		 send off-hook cid data to CM */
	IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
		"There is a waiting call on PSTN line ",xCidInfo.szDisplayName);
	eReturn = IFX_CMGR_OffHkCidSnd(pxEndptInfo->axFxoCallData[0].uiCallId,
					pxEvtInfo->uxEvtInfo.xCIDData.szCallerNumber,&xCidInfo);	
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_ConvEmgHdlr
* Description      :
		    		Logic-check the hookstate if on hook cancel 
								the hook flash timer else Do on hook.
        			Send Release to active call.Stop CPTD.Set EMG_CALL flag.
        			Copy Number to dialstring and calldata in a buffer.Stop CPTD.
        			start OFF_HOOK_WAIT timer and move to OFF_HK_WAIT_STATE. 
					send AcceptCall.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_ConvEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	/*Check hook status - If off hook*/
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");

	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   	"Got Emergency call. Disconnecting active call");
	if( IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_HOOK_STATUS) )
	{ //go on hook
		if(IFX_FAILURE == IFX_FXO_SetOnHook(pxEndptInfo))
		{
			IFX_MakeFXOIdle(pxEndptInfo);
			return IFX_FAILURE;		
		}
	}
	else
	{	
		/*Stop the HOOK FLASH timer*/
		IFX_FXO_STOPTIMER(pxEndptInfo->uiHookFlashTimId)
	}
	/* Stop Off hook CID timer if running */
	if(pxEndptInfo->uiOffHkCIDTimId)
	{
 		IFX_TIM_TimerStop(pxEndptInfo->uiOffHkCIDTimId);
 		pxEndptInfo->uiOffHkCIDTimId=0;
		IFX_MMGR_CidRxStop(pxEndptInfo->szEndPointId);
 	}
	/* Populate the Emergency call's data.  Release active call Start off hook 
		 wait timer and move to Off hook wait state */
	memcpy(&(pxEndptInfo->xEmgCallInfo),
		&(pxEvtInfo->uxEvtInfo.xIncCallInfo), sizeof(x_IFX_FXO_IncCallInfo));	
	IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																																	pxEndptInfo);
	IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
	memset(&(pxEndptInfo->axFxoCallData[0]),0, sizeof(x_IFX_FXO_CallData));
	IFX_FXO_StartToneTimer(OFF_HK_WAIT,DEFAULT,pxEndptInfo);	
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_OFF_HK_WAIT,pxEndptInfo);  
	pxEvtInfo->eReturn = IFX_FXO_AcceptCall;
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_RGRingStartHdlr
* Description      : 
    						 Logic-Stop the RingTimer	
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RGRingStartHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	/*Stop the Ring timer*/
   IFX_FXO_STOPTIMER(pxEndptInfo->uiRingBurstTimId)
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    :IFX_FXO_RGRingStopHdlr 
* Description      : 
		   			     Logic-Start the Ringtimer 	
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RGRingStopHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{	
	/*Start Ring Timer*/
	IFX_FXO_StartToneTimer(RINGBURST,DEFAULT,pxEndptInfo);	
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    :IFX_FXO_RGRelHdlr 
* Description      : 
    				     	Logic-(Can come only on actv call)Start the 
												Retry Timer
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RGRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	/**Check whether it is on active call*/
	if(pxEvtInfo->uiCallId != pxEndptInfo->axFxoCallData[0].uiCallId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Release On Wrong Call Id");	
		//IFX_MakeFXOIdle(pxEndptInfo); //Not required
		return IFX_FAILURE;
	}
	/*memset the calldata*/
	memset(&(pxEndptInfo->axFxoCallData[0]),0, sizeof(x_IFX_FXO_CallData));
	/*Start Retry Timer*/
	IFX_FXO_StartToneTimer(RETRY,DEFAULT,pxEndptInfo);	
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    :IFX_FXO_RGAnsHdlr 
* Description      : 
					     	Logic-(Can come only on active call).do off hook.cancel the 
			 					RingTimer if running.Start the Busy CPTD and move 
								to CONVERSATION state
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RGAnsHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/**Check whether it is on active call*/
	if(pxEvtInfo->uiCallId != pxEndptInfo->axFxoCallData[0].uiCallId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Answer on wrong CID");
		//IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Peer Answered Call");
	/*Stop the Ring timer if running*/
   IFX_FXO_STOPTIMER(pxEndptInfo->uiRingBurstTimId)
	/**Do off hook*/
	if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
	{		
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}
	/* Start CPTD for Busy Tone. Move the State to Conversation */
	IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_BUSY_TONE);
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo)
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    :IFX_FXO_RGRingTimExpHdlr 
* Description      : 
    				     Logic-
								do ReleaseCall if call is initiated.stop the Retry timer 
								if running.Clear the flags.Flush the dialstring.
								Call DeallocResource and move to IDLE state.	
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RGRingTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Deallocate the resource*/
	//IFX_FXO_DeallocResource(pxEndptInfo);		
	/*Make the endpoint Idle*/
	IFX_MakeFXOIdle(pxEndptInfo);
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    :IFX_FXO_RGRetryTimExpHdlr 
* Description      : 
    				     	Logic-Do InitCall.The return values can be:-
							-CallAccept:
							-CallAnswer:Cancel the Ringburst timer if running.
								do off hook.start CPTD for busy tone. move state to 
								conversation state.
							-CallReject:Stert Retry timer
							-Pending:
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RGRetryTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Do CallInitiate*/
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH,IFX_DBG_STR, 
									"Retring : Initiating Call To Terminals Again");
	switch( IFX_FXO_CallInitiate(pxEndptInfo,
					&pxEndptInfo->axFxoCallData[0].uiCallId, 
					(char*)NULL,IFX_FALSE, IFX_DP_MAX_DP_ACTIONS) )
	{
		case IFX_FXO_Failure:
				IFX_MakeFXOIdle(pxEndptInfo);
				eReturn = IFX_FAILURE;
				break;
		case IFX_FXO_AnswerCall:
				/* Stop the Ring timer and answer the call. Start busy CPTD and change 
					 state to Conversation */
				IFX_FXO_STOPTIMER(pxEndptInfo->uiRingBurstTimId)	
				if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
				{		
					IFX_MakeFXOIdle(pxEndptInfo);
					eReturn =  IFX_FAILURE;
				} else {
					IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_BUSY_TONE);
					IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo)
				}
   			break;
		case IFX_FXO_RejectCall:
				/* Rejected again- start Retry timer */
				memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
				IFX_FXO_StartToneTimer(RETRY,DEFAULT,pxEndptInfo);	
				break;
		case IFX_FXO_AcceptCall:
		case IFX_FXO_PendingCall:
				break;
		default :	
				/* Make the endpoint Idle */
				IFX_MakeFXOIdle(pxEndptInfo);
				return IFX_FAILURE;				
	}
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_RGEmgHdlr 
* Description      : 
					     Logic-Stop the Retry timer and Ring timer if running.else do CallRelease 
							Populate the dial string
							do off hook.start ON_HOOK_WAIT timer. set EMG_CALL flag.
							and move to CONVERSATION state.	
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_RGEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/* Stop the Ring timer and retry timer, release current call and store 
		 emergency number. Since line is ringing, go off hook to answer and 
	   this call will be disconnected immediately */
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   	"Got Emergency call. Disconnecting Incoming call");
	IFX_FXO_STOPTIMER(pxEndptInfo->uiRingBurstTimId)	
	IFX_FXO_STOPTIMER(pxEndptInfo->uiRetryTimId)
	IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
 	memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	memcpy(&(pxEndptInfo->xEmgCallInfo),
			&(pxEvtInfo->uxEvtInfo.xIncCallInfo),sizeof(x_IFX_FXO_IncCallInfo));	
	IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																					pxEndptInfo)
	if(IFX_FAILURE == IFX_FXO_SetOffHook(pxEndptInfo))
	{		
		IFX_MakeFXOIdle(pxEndptInfo);
		return IFX_FAILURE;
	}
	/* Start on hook wait timer and move to Conversation State */	
	IFX_FXO_StartToneTimer(ON_HK_WAIT,DEFAULT,pxEndptInfo);	
	IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION,pxEndptInfo);		
	pxEvtInfo->eReturn = IFX_FXO_AcceptCall;	
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_OhwIncCallHdlr  
* Description      :
		         Logic-Check the MOVE_TO_DIALWAIT flag and MOVE_TO_SMS flag
      	      -> If any of them set, Reject the call.
         	   -> Else Populate the Active call information.
					Populate the Number in to Dialstring
               ALSO Send CallAccept.Set the MOVE_TO_DIALWAIT flag.	
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_OhwIncCallHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Check the MOVE TO SMS and MOVE_TO_DIALWAIT flag*/
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_MOVE_TO_DIALWAIT))
	{
		IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  		"Incoming call. Another call is going on. Call Rejected");
		pxEvtInfo->eReturn = IFX_FXO_RejectCall;	
		return eReturn;
	}
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
  	"Incoming call. Waiting for on-hook wait timer to expire");
	 /* Store incoming call info and turn on IFX_FXO_MOVE_TO_DIALWAIT */
	IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																					pxEndptInfo)
	pxEndptInfo->axFxoCallData[0].uiCallId
								 = pxEvtInfo->uxEvtInfo.xIncCallInfo.uiCallId;
	pxEndptInfo->axFxoCallData[0].eCallType
								 = pxEvtInfo->uxEvtInfo.xIncCallInfo.eCallType;
	IFX_FXO_SET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_MOVE_TO_DIALWAIT);
	pxEvtInfo->eReturn = IFX_FXO_AcceptCall;	
	return eReturn;
}

/***************************************************************************
* Function Name    :IFX_FXO_OhwEmgHdlr  
* Description      :
    	   	  Logic-Check the MOVE_TO_DIALWAIT flag
      	        if set,Send release to Active call.clear the active call 
						data.clear the MOVE_TO_DIALWAIT flag.
            	  ALSO Set EMG_CALL flag.Copy Number to dialstring and 
					  	calldata in a buffer.	
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_OhwEmgHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   	"Got Emergency call.");
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_MOVE_TO_DIALWAIT))
	{
		IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
   		"There is call to be initiated. Disconnecting it.");
		IFX_FXO_RELEASECALL(pxEndptInfo->axFxoCallData[0].uiCallId);
		memset(&(pxEndptInfo->axFxoCallData[0]),0,sizeof(x_IFX_FXO_CallData));
	}
	
	/* Rememmber emergenct call info. Once timer expires make emergency call */
	memcpy(&(pxEndptInfo->xEmgCallInfo),
		&(pxEvtInfo->uxEvtInfo.xIncCallInfo), sizeof(x_IFX_FXO_IncCallInfo) );	
   IFX_FXO_POPULATE_DIALSTRING(pxEvtInfo->uxEvtInfo.xIncCallInfo.szPstnDgt,
																						pxEndptInfo);	
	pxEvtInfo->eReturn = IFX_FXO_AcceptCall;	
	return eReturn;
}

/***************************************************************************
* Function Name    :  IFX_FXO_OhwRelHdlr
* Description      :
        		Logic-heck the MOVE_TO_DIALWAIT flag
                  -if set,and release is for the Active call Id.
							clear the MOVE_TO_DIALWAIT flag.
                  -else check EMG_CALL flag
                    =>if set,and the release is for emergency call.
									Reset the EMG_CALL flag.
                          	memset the emergency the emergencyCall data
                    =>else return;
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_OhwRelHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo )
{
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*
	 * Reset flag & call related to info of the call to be made.
	 */
	IFX_DBGC(vucFXOModId, IFX_DBG_LVL_HIGH, IFX_DBG_STR, "Remote Released Call");
	if( IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_MOVE_TO_DIALWAIT) && 
			pxEvtInfo->uiCallId == pxEndptInfo->axFxoCallData[0].uiCallId )
	{
		memset(&(pxEndptInfo->axFxoCallData[0]),0, sizeof(x_IFX_FXO_CallData));
		IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_MOVE_TO_DIALWAIT);
	}
	else if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags, IFX_FXO_EMG_CALL_PROCEEDING) &&
					pxEvtInfo->uiCallId == pxEndptInfo->xEmgCallInfo.uiCallId )
	{
		memset(&(pxEndptInfo->xEmgCallInfo),0, sizeof(x_IFX_FXO_IncCallInfo));
		IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags, IFX_FXO_EMG_CALL_PROCEEDING);
	}
	return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_FXO_OhwOffHkWtTimExpHdlr
* Description      :
        Logic-Check for EMG_CALL flag
        =>if set: do off hook,Copy Emgcall data from buffer to active 
				and flush the buffer,start the DIAL_WAIT timer. 
				move the state to DIAL_WAIT.
        =>if not set:Check for MOVE_TO_DIALWAIT flag
                  ->if set:Reset the flag.check the length of dialstring
                          if = 0 :do set off hook.start busy tone CPTD.
												Send answer to the call.
                                  	move state to CONVERSATION state.
                          if > 0 :Clear the flag.do off hook,start the 
												DIAL_WAIT timer. move the state to DIAL_WAIT
                  ->if not set:Check for MOVE_TO_SMS flag
                      ->if set:do off hook,start the DIAL_WAIT timer. 
												move the state to DIAL_WAIT.
                      ->if not set:Clear all flags.Clear the DialString .
											call DeallocResource. Move state to IDLE.	
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_OhwOffHkWtTimExpHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eReturn = IFX_SUCCESS;
	e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_SUCCESS;	
	e_IFX_ReasonCode eReason;
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Check the emergency call proceeding flag*/
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING)) {

		IFX_DBGC(vucFXOModId,
			IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Dialing out emergency call...");
		if(IFX_FAILURE == (eReturn = IFX_FXO_SetOffHook(pxEndptInfo)) ) {		
			IFX_MakeFXOIdle(pxEndptInfo);
		} else {
			/* Start dial tone CPTD, dial wait timer and move to dial wait state */
			pxEndptInfo->axFxoCallData[0].uiCallId 
													= pxEndptInfo->xEmgCallInfo.uiCallId;
			pxEndptInfo->axFxoCallData[0].eCallType 
													= pxEndptInfo->xEmgCallInfo.eCallType;
			memset(&(pxEndptInfo->xEmgCallInfo),0,sizeof(x_IFX_FXO_IncCallInfo));
			IFX_FXO_StartCptd(pxEndptInfo,IFX_MMGR_DIAL_TONE);
			IFX_FXO_StartToneTimer(DIALWAIT,DEFAULT,pxEndptInfo);	
			IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_DIAL_WAIT,pxEndptInfo);		
		}
	} else if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_MOVE_TO_DIALWAIT)) {

		IFX_DBGC(vucFXOModId,
			IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Dilaing out pending call...");
		IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_MOVE_TO_DIALWAIT);
		/* Go off hook. If there are digits to dialout, start CPTD on dila tone &
			 timer for it and move to dial wait state. If no digits are there to dialout
		   then answer the call and move to conversation state */
		if(IFX_SUCCESS == (eReturn = IFX_FXO_SetOffHook(pxEndptInfo)) )
		{
			if(strlen(pxEndptInfo->szPstnDgt)) {
				IFX_FXO_StartCptd(pxEndptInfo, IFX_MMGR_DIAL_TONE);
				IFX_FXO_StartToneTimer(DIALWAIT, DEFAULT, pxEndptInfo);	
				IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_DIAL_WAIT, pxEndptInfo);		
			}	else {
				IFX_FXO_StartCptd(pxEndptInfo, IFX_MMGR_BUSY_TONE);
				IFX_FXO_MOVETO_STATE(IFX_FXO_STATE_CONVERSATION, pxEndptInfo)
				eReturn = IFX_CMGR_CallAnswer(
						pxEndptInfo->axFxoCallData[0].uiCallId, &eStatus, &eReason );
			}
		}
		if((IFX_FAILURE == eReturn )||(IFX_CMGR_STATUS_FAIL == eStatus))
		{
	 		/*Make FXO Idle*/
      IFX_MakeFXOIdle(pxEndptInfo);
      eReturn =  IFX_FAILURE;
   	}
	}
#ifdef PSTN_SMS	
	else if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_MOVE_TO_SMS_STATE)) {
		IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "SMS transmission pending");
		/*Do off hook*/ /*Start dial wait timer*/ /*Start CPTD for dial tone*/
		/*Move to dial wait state*/
	}
#endif
	else {
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                 "No Call Pending,Making FXO Idle");
		/*Move to Idle state*/
		IFX_MakeFXOIdle(pxEndptInfo);	
	}
	return eReturn;
}

/***************************************************************************
* Function Name    : IFX_FXO_OhwTxmitSMSHdlr
* Description      :
        Logic-Check MOVE_TO_DIALWAIT flag.
          ->If set, Reject the SMS.
          ->else Set the MOVE_TO_SMS flag. populate the 
					DialString with SM-SC number/0/DMI.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXO_OhwTxmitSMSHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Check the MOVE_TO_SMS flag*/
	/*if(Set)
		{
			-Send RejectSMS
			-Return
		}
		else
		{
			-Set MOVE_TO_SMS flag
			-Populate the Dialstring with SM-SC number/0/DMI
			(Wait for off hook timer to expire)
			-Send AcceptSMS
			-return
		}
	*/
	return IFX_SUCCESS;
}

/*******THE FXO FSM HANDLER'S FUNCTION POINTER ARRAY ********/
pfn_IFX_FXOFsm va_IFX_FXOFsm[IFX_FXO_STATE_MAX][IFX_FXO_EVT_MAX]=
{
	/* IFX_FXO_STATE_IDLE */
	{
	IFX_FXO_IdleRingStartHdlr,			/*IFX_FXO_EVT_RingStart,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DgtPrs,*/
	IFX_FXO_IdleRingStopHdlr,        /*IFX_FXO_EVT_RingStop,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_ToneDetect,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CIDRxComplete,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CAS,*/
	IFX_FXO_IdleIncCallHdlrHdlr,     /*IFX_FXO_EVT_IncCall,*/
	IFX_FXO_IdleEmgHdlr,             /*IFX_FXO_EVT_EmgCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_ReleaseCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAccept,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAnswer,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_PSTNHookFlash,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBackToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBurstTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineInterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OnHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RetryTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_InterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_HookFlashTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkCIDTimerExp,*/
	IFX_FXO_IdleTxmitSMSHdlr,        /*IFX_FXO_EVT_TransmitSMS,*/
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	},
	/* IFX_FXO_STATE_CID_WAIT */
	{
	IFX_FXO_CWRingStartHdlr,				 /*IFX_FXO_EVT_RingStart,*/
	IFX_FXO_CWDigitEventHdlr,     	 /*IFX_FXO_EVT_DgtPrs,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingStop,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_ToneDetect,*/
	IFX_FXO_CWCIDRxHdlr,             /*IFX_FXO_EVT_CIDRxComplete,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CAS,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_IncCall,*/
	IFX_FXO_CWEmgHdlr,	            /*IFX_FXO_EVT_EmgCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_ReleaseCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAccept,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAnswer,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_PSTNHookFlash,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBackToneTimerExp,*/
	IFX_FXO_CWRingTimExpHdlr,        /*IFX_FXO_EVT_RingBurstTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineInterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OnHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RetryTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_InterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_HookFlashTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkCIDTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_TransmitSMS,*/
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	},
	/* IFX_FXO_STATE_DIAL_WAIT */
	{
	IFX_FXO_IgnoreHdlr,					/*IFX_FXO_EVT_RingStart,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DgtPrs,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingStop,*/
	IFX_FXO_DWToneDetectHdlr,        /*IFX_FXO_EVT_ToneDetect,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CIDRxComplete,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CAS,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_IncCall,*/
	IFX_FXO_DWEmgHdlr, 	            /*IFX_FXO_EVT_EmgCall,*/
	IFX_FXO_DWRelHdlr,               /*IFX_FXO_EVT_ReleaseCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAccept,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAnswer,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_PSTNHookFlash,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBackToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBurstTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineInterDgtTimerExp,*/
	IFX_FXO_DWDialWtTimExpHdlr,      /*IFX_FXO_EVT_DialWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OnHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RetryTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_InterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_HookFlashTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkCIDTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_TransmitSMS,*/
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	},
	/* IFX_FXO_STATE_DIGIT_DIAL */
	{
	IFX_FXO_IgnoreHdlr,					/*IFX_FXO_EVT_RingStart,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DgtPrs,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingStop,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_ToneDetect,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CIDRxComplete,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CAS,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_IncCall,*/
	IFX_FXO_DDEmgHdlr,	            /*IFX_FXO_EVT_EmgCall,*/
	IFX_FXO_DDRelHdlr,               /*IFX_FXO_EVT_ReleaseCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAccept,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAnswer,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_PSTNHookFlash,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBackToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBurstTimerExp,*/
	IFX_FXO_DDLineDgtTimExpHdlr,     /*IFX_FXO_EVT_LineDgtTimerExp,*/
	IFX_FXO_DDLineInterDgtTimExpHdlr,/*IFX_FXO_EVT_LineInterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OnHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RetryTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_InterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_HookFlashTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkCIDTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_TransmitSMS,*/
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	},
	/* IFX_FXO_STATE_DIGIT_COLLECT */
	{
	IFX_FXO_IgnoreHdlr,					/*IFX_FXO_EVT_RingStart,*/
	IFX_FXO_DCDgtPrsHdlr,            /*IFX_FXO_EVT_DgtPrs,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingStop,*/
	IFX_FXO_DCToneDetectHdlr,        /*IFX_FXO_EVT_ToneDetect,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CIDRxComplete,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CAS,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_IncCall,*/
	IFX_FXO_DCEmgHdlr,	            /*IFX_FXO_EVT_EmgCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_ReleaseCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAccept,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAnswer,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_PSTNHookFlash,*/
	IFX_FXO_DCDialTnTimExpHdlr,      /*IFX_FXO_EVT_DialToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBackToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBurstTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineInterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OnHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RetryTimerExp,*/
	IFX_FXO_DCInterDgtTimExpHdlr,    /*IFX_FXO_EVT_InterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_HookFlashTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkCIDTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_TransmitSMS,*/
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	},
	/* IFX_FXO_STATE_RINGBACK */
	{
	IFX_FXO_IgnoreHdlr,					/*IFX_FXO_EVT_RingStart,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DgtPrs,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingStop,*/
	IFX_FXO_RBToneDetectHdlr,        /*IFX_FXO_EVT_ToneDetect,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CIDRxComplete,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CAS,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_IncCall,*/
	IFX_FXO_RBEmgHdlr,  	            /*IFX_FXO_EVT_EmgCall,*/
	IFX_FXO_RBRelHdlr,     	         /*IFX_FXO_EVT_ReleaseCall,*/
	IFX_FXO_RBAcceptHdlr,            /*IFX_FXO_EVT_RmtAccept,*/
	IFX_FXO_RBAnsHdlr,	            /*IFX_FXO_EVT_RmtAnswer,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_PSTNHookFlash,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialToneTimerExp,*/
	IFX_FXO_RBRingBackTnTimExpHdlr,  /*IFX_FXO_EVT_RingBackToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBurstTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineInterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OnHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RetryTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_InterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_HookFlashTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkCIDTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_TransmitSMS,*/
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	},
	/* IFX_FXO_STATE_CONVERSATION */
	{
	IFX_FXO_IgnoreHdlr,					/*IFX_FXO_EVT_RingStart,*/
	IFX_FXO_ConvDgtPrsHdlr,          /*IFX_FXO_EVT_DgtPrs,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingStop,*/
	IFX_FXO_ConvToneDetectHdlr,      /*IFX_FXO_EVT_ToneDetect,*/
	IFX_FXO_ConvCIDHdlr,             /*IFX_FXO_EVT_CIDRxComplete,*/
	IFX_FXO_ConvCASHdlr,             /*IFX_FXO_EVT_CAS,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_IncCall,*/
	IFX_FXO_ConvEmgHdlr,             /*IFX_FXO_EVT_EmgCall,*/
	IFX_FXO_ConvRelHdlr,             /*IFX_FXO_EVT_ReleaseCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAccept,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAnswer,*/
	IFX_FXO_ConvPSTNHkFlashHdlr,     /*IFX_FXO_EVT_PSTNHookFlash,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBackToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBurstTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineInterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkWaitTimerExp,*/
	IFX_FXO_ConvOnHkWaitTimExpHdlr,  /*IFX_FXO_EVT_OnHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RetryTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_InterDgtTimerExp,*/
	IFX_FXO_ConvPSTNHkFlashTimExpHdlr,/*IFX_FXO_EVT_HookFlashTimerExp,*/
	IFX_FXO_ConvOffHkCIDTimExpHdlr,  /*IFX_FXO_EVT_OffHkCIDTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_TransmitSMS,*/
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	},
	/* IFX_FXO_STATE_RINGING */
	{
	IFX_FXO_RGRingStartHdlr,         /*IFX_FXO_EVT_RingStart,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DgtPrs,*/
	IFX_FXO_RGRingStopHdlr,          /*IFX_FXO_EVT_RingStop,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_ToneDetect,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CIDRxComplete,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CAS,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_IncCall,*/
	IFX_FXO_RGEmgHdlr,               /*IFX_FXO_EVT_EmgCall,*/
	IFX_FXO_RGRelHdlr,               /*IFX_FXO_EVT_ReleaseCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAccept,*/
	IFX_FXO_RGAnsHdlr,               /*IFX_FXO_EVT_RmtAnswer,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_PSTNHookFlash,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBackToneTimerExp,*/
	IFX_FXO_RGRingTimExpHdlr,        /*IFX_FXO_EVT_RingBurstTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineInterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OnHkWaitTimerExp,*/
	IFX_FXO_RGRetryTimExpHdlr,       /*IFX_FXO_EVT_RetryTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_InterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_HookFlashTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkCIDTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_TransmitSMS,*/
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	},
	/* IFX_FXO_STATE_OFF_HK_WAIT */
	{
	IFX_FXO_IgnoreHdlr,					/*IFX_FXO_EVT_RingStart,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DgtPrs,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingStop,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_ToneDetect,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CIDRxComplete,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_CAS,*/
	IFX_FXO_OhwIncCallHdlr,          /*IFX_FXO_EVT_IncCall,*/
	IFX_FXO_OhwEmgHdlr,              /*IFX_FXO_EVT_EmgCall,*/
	IFX_FXO_OhwRelHdlr,              /*IFX_FXO_EVT_ReleaseCall,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAccept,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RmtAnswer,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_PSTNHookFlash,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBackToneTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RingBurstTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_LineInterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_DialWaitTimerExp,*/
	IFX_FXO_OhwOffHkWtTimExpHdlr,    /*IFX_FXO_EVT_OffHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OnHkWaitTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_RetryTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_InterDgtTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_HookFlashTimerExp,*/
	IFX_FXO_IgnoreHdlr,              /*IFX_FXO_EVT_OffHkCIDTimerExp,*/
	IFX_FXO_OhwTxmitSMSHdlr,         /*IFX_FXO_EVT_TransmitSMS,*/
	//IFX_FXO_EVT_FSKDataReady,
	//IFX_FXO_EVT_SMSTimetFired,
	//IFX_FXO_EVT_FAX_CNG,
	//IFX_FXO_EVT_FAX_CED,
	//IFX_FXO_EVT_FAX_DIS,
	},
	/* IFX_FXO_STATE_SMS */
};

/******************************The Entry point for FXO FSM ****************************/

                                                                                                                             
/***************************************************************************
* Function Name    :IFX_FXOHdlr
* Description      :
    			          This function would be entry point for FXO FSM.
            	        It invokes the FSM depending upon the event.
* Input Values     : - pxEndptInfo is Endpoint Info
   					   - pxEvtInfo is Event Info
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
STATIC e_IFX_Return IFX_FXOHdlr(
                        IN x_IFX_FXO_Info *pxEndptInfo,
                        IN_OUT x_IFX_FXO_EvtInfo *pxEvtInfo)
{
	e_IFX_Return eRetVal = IFX_SUCCESS;

	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "The Event is:-",IFX_FXO_GetEvent(pxEvtInfo->eCurrEvt));

	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "The State is:-",IFX_FXO_GetState(pxEndptInfo->eCurrState));

   eRetVal=va_IFX_FXOFsm[pxEndptInfo->eCurrState][pxEvtInfo->eCurrEvt]
																(pxEndptInfo,pxEvtInfo);
	
		
	 IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
        (IFX_SUCCESS == eRetVal)?"FSM Handler Returned SUCCESS":
																						"FSM Handler Returned FAILED");
	
	/*Has to be removed once the code is frozen*/
	IFX_FXO_ShowStatus(pxEndptInfo);

	return IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);	

}

/************* The Functions to be registered with external modules*****************/

/***************************************************************************
* Function Name    :IFX_FXO_TimerFired
* Description      :
    			     This function would be registered with timer for every timer.
						When being calld, will indicate the expiry of the timer and invoke the FSM, 
						No other information is required.
						It will be registered with Timer library as (*pfn_IFX_TM_TimerCallBack)
						Events It can give:- 
   					IFX_FXO_EVT_DialToneTimerExp,
  						IFX_FXO_EVT_RingBackToneTimerExp,
   					IFX_FXO_EVT_RingBurstTimerExp,
   					IFX_FXO_EVT_LineDgtTimerExp,
   					IFX_FXO_EVT_LineInterDigitTimerExp,
   					IFX_FXO_EVT_DialWaitTimerExp,
   					IFX_FXO_EVT_OffHkWaitTimerExp,
   					IFX_FXO_EVT_OnHkWaitTimerExp,
   					IFX_FXO_EVT_RetryTimerExp,
   					IFX_FXO_EVT_InterDgtTimerExp,
   					IFX_FXO_EVT_HookFlashTimerExp,
						IFX_FXO_EVT_OffHkCIDTimerExp
* Input Values     : - uiTimerId 
   					   - pvPrivateData
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/

void IFX_FXO_TimerFired(
						IN uint32 uiTimerId,
						IN void* pvPrivateData)
{
	
	x_IFX_FXO_TimerInfo xTimerInfo;
	x_IFX_FXO_EvtInfo xEvtInfo;
	//e_IFX_Return eRetVal=IFX_SUCCESS;

	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));	
	memcpy(&xTimerInfo,pvPrivateData,sizeof(x_IFX_FXO_TimerInfo));

	xEvtInfo.eCurrEvt = xTimerInfo.eCurrEvt;	

	if(xTimerInfo.pTimerId != NULL && uiTimerId != *xTimerInfo.pTimerId)
	{
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "Wrong Timer Id");					
		return ;
	}

	/**Reset The Timer Id*/
	if(xTimerInfo.pTimerId)
	*(xTimerInfo.pTimerId) = 0;	
	
	if (xEvtInfo.eCurrEvt < IFX_FXO_EVT_MAX)
		/*eRetVal =*/  IFX_FXOHdlr(xTimerInfo.pxEndptInfo,&xEvtInfo);
	else
		IFX_DBGA(vucFXOModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "Invalid event");					

	//IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);
	return ;
}


/***************************************************************************
* Function Name    :IFX_FXOHdlr
* Description      :
    			   	This function will be registered with the Message router
						as (*pfn_IFX_MSGRTR_EventCallback). 
						It will give the appropriate EndpointId
						and the TAPI event ID.Thus the FXOHdlr would be invoked 
						for appropriate endpoint 
						Events It Can Give
							  IFX_FXO_EVT_RingStart,
							  IFX_FXO_EVT_DgtPrs,
							  IFX_FXO_EVT_RingStop,
							  IFX_FXO_EVT_ToneDetect,
							  IFX_FXO_EVT_CIDRxComplete,
							  IFX_FXO_EVT_CAS,
* Input Values     : -pxDevEvents  
   					  
*                  : 
* Output Values    : 
* Return Value     :  IFX_SUCCESS or IFX_FAILUREURE

* Notes            :
***************************************************************************/
e_IFX_Return IFX_FXO_MSGRTR_EvtHdlr(
										IN x_IFX_MMGR_DeviceEvents *pxDevEvents)
{
	x_IFX_FXO_EvtInfo xEvtInfo;
	e_IFX_Return eRetVal=IFX_SUCCESS;
	x_IFX_FXO_Info* pxEndptInfo = 0;
	char8 *szEndptId = pxDevEvents->szEndPtId; 
	uchar8 ucCount = 0;

	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");

	/*Search for Appropriate endpoint*/
	for(ucCount = 0;ucCount < IFX_MMGR_MAX_FXO_CHANNELS;ucCount++)
	{
		if(0 == strcmp(szEndptId,vaxFXOInfo[ucCount].szEndPointId))
		{
			pxEndptInfo = &vaxFXOInfo[ucCount];
			break;
		}		
	}
	/**Endpoint not found**/
	if(!pxEndptInfo)
	{		
		return IFX_FAILURE;
	}
	if((pxDevEvents->uiEvents)&(IFX_MMGR_EVENT_TONE_DETECTION_END))
	{
		memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
		xEvtInfo.eCurrEvt = IFX_FXO_EVT_ToneDetect;
		/*Populate the tone detected*/
		xEvtInfo.uxEvtInfo.eToneDetect = pxEndptInfo->eCPTDActv;
		pxEndptInfo->eCPTDActv = IFX_MMGR_MAX_TONE;                                                                            
		if(IFX_FAILURE ==  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo))
			return IFX_FAILURE;
	}
	if((pxDevEvents->uiEvents)&(IFX_MMGR_EVENT_RING_START))
	{
		memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
		xEvtInfo.eCurrEvt = IFX_FXO_EVT_RingStart;
		if(IFX_FAILURE ==  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo))
			return IFX_FAILURE;
	}
	if((pxDevEvents->uiEvents)&(IFX_MMGR_EVENT_RING_STOP))
	{
		memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
		xEvtInfo.eCurrEvt = IFX_FXO_EVT_RingStop;
		if(IFX_FAILURE ==  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo))
			return IFX_FAILURE;
	}
	if((pxDevEvents->uiEvents)&(IFX_MMGR_EVENT_DIGIT))
	{
		memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
		xEvtInfo.eCurrEvt = IFX_FXO_EVT_DgtPrs;
		strncpy(xEvtInfo.uxEvtInfo.szDgtPrs,(char8 *)pxDevEvents->aucDigits,pxDevEvents->ucNoOfDigits);		
		xEvtInfo.uxEvtInfo.szDgtPrs[pxDevEvents->ucNoOfDigits] = '\0';
		if(IFX_FAILURE ==  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo))
			return IFX_FAILURE;	
	}
	if((pxDevEvents->uiEvents)&(IFX_MMGR_EVENT_CID_DATA))
	{
		x_IFX_MMGR_FSK_Data xFskDta = {0};
		
		memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
		xEvtInfo.eCurrEvt = IFX_FXO_EVT_CIDRxComplete;
		if(IFX_MMGR_SUCCESS == IFX_MMGR_FSKDataRcv(pxDevEvents->szEndPtId,
												&xFskDta))
		{
			//memcpy(&(xEvtInfo.uxEvtInfo.xCIDData),&(pxDevEvents->xCidData),sizeof(x_IFX_MMGR_CidParams));
			if( xFskDta.aeParams[IFX_MMGR_FSK_PARAM_CLI] == IFX_MMGR_FSK_PARAM_CLI)
			{
			 	strcpy(xEvtInfo.uxEvtInfo.xCIDData.szCallerNumber, 
															(char8*)(xFskDta.apvParams[IFX_MMGR_FSK_PARAM_CLI]));
			}
			else if( xFskDta.aeParams[IFX_MMGR_FSK_PARAM_FIRST_CLI] == IFX_MMGR_FSK_PARAM_FIRST_CLI)
			{
				strcpy(xEvtInfo.uxEvtInfo.xCIDData.szCallerNumber, 
															(char8*)(xFskDta.apvParams[IFX_MMGR_FSK_PARAM_FIRST_CLI])); 
			}
			if( xFskDta.aeParams[IFX_MMGR_FSK_PARAM_NAME] == IFX_MMGR_FSK_PARAM_NAME)
			{
				strncpy(xEvtInfo.uxEvtInfo.xCIDData.szCallerName, 
					 						(char8*)(xFskDta.apvParams[IFX_MMGR_FSK_PARAM_NAME]),32);
			}
			
			IFX_MMGR_FSK_FreeData(&xFskDta);	//Free FSK data here
			if(IFX_FAILURE ==  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo))
				return IFX_FAILURE;
		}
		else
		{
			IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "FSK Data Reception Failed");
			return IFX_FAILURE;	
		}
	}
	if((pxDevEvents->uiEvents)&(IFX_MMGR_EVENT_CID_RX_CAS))
	{
		/*Fail If the emergency call is proceeding.*/
		if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING))
		{
			return eRetVal;	
		}
		memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
		xEvtInfo.eCurrEvt = IFX_FXO_EVT_CAS;
		if(IFX_FAILURE ==  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo))
			return IFX_FAILURE;
	}

	return IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);	
}
		
/*********************** The Functions to be registered with Call Manager 

 THEY WILL INVOKE THE FSM WITH THE EVENTS MENTIONED AT THE TOP OF THE FUNCTION.
 
 *****************************/
//IFX_FXO_EVT_IncCall,
//IFX_FXO_EVT_EmgCall,
e_IFX_Return IFX_FXO_CallIncoming(
					 IN uint32 uiCallId, 
					 IN x_IFX_CMGR_AddressInfo *pxFrom,
					 IN x_IFX_CMGR_AddressInfo *pxTo, 
					 IN x_IFX_CMGR_CallParams *pxCallParams, 
					 OUT e_IFX_CMGR_Status* peStatus,
					 OUT e_IFX_ReasonCode* peReason,
					 OUT void** ppvPrivateData)
{
	x_IFX_FXO_EvtInfo xEvtInfo = {0};
	e_IFX_Return eRetVal=IFX_SUCCESS;
	e_IFX_ReasonCode eReason;
	x_IFX_FXO_Info * pxEndptInfo = &vaxFXOInfo[0];
	uchar8 ucCount = 0;
	
	IFX_DBGC(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "Call Initiated From CM");
	
	/*Search for Appropriate endpoint*/
	for(ucCount = 0;ucCount < IFX_MMGR_MAX_FXO_CHANNELS;ucCount++)
	{
		if(0 == strcmp(pxTo->uxAddressInfo.xFxoInfo.szFxoLineId,
												vaxFXOInfo[ucCount].szEndPointId))
		{
			pxEndptInfo = &vaxFXOInfo[ucCount];
			break;
		}		
	}
	/**Endpoint not found**/
	if(ucCount == IFX_MMGR_MAX_FXO_CHANNELS)
	{		
		return IFX_FAILURE;
	}
	/* Check if emergency call is in progress Then Reject the call */
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING))
	{
		IFX_DBGC(vucFXOModId,IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
																								"Emergency Call Is In Progress");
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_ENDPOINT_BUSY;	
		return eRetVal;	
	}
	/*Else check whether curent call is a normal or 
					an emergency call and Construct the eventInfo accordingly*/
	if(pxCallParams->uxCallParams.xFxoParams.bEmergency)
	{
		xEvtInfo.eCurrEvt = IFX_FXO_EVT_EmgCall;
			/**Reset the SMS flag*/
		IFX_FXO_RESET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_MOVE_TO_SMS_STATE);
			/*Set the Emergency call proceeding Flag*/
		IFX_FXO_SET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING);
	}
	else
	{
		/*
		 * Don't initiate call, if outgoing calls are barred  or caller number (for 
		 * gateway call) is blocked.
		 */ 
		boolean bOutBlocked = IFX_FALSE;
	//	boolean bInBlocked = IFX_FALSE;

		IFX_CIF_OutgoingCallBlockCheck(pxEndptInfo->szEndPointId,
																					&bOutBlocked, &eReason);
	/*	if( IFX_CMGR_TYPE_VOIP == pxTo->eAddressType )
		{
			IFX_CIF_IncomingCallBlockCheck( pxEndptInfo->szEndPointId,
					pxTo->uxAddressInfo.xVoipAddr.acCalledAddr, &bInBlocked, &eReason);
		}*/
		//if( IFX_TRUE == bOutBlocked || IFX_TRUE == bInBlocked )
		if( IFX_TRUE == bOutBlocked )
		{
			IFX_DBGC(vucFXOModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
                             "Can Not Initiate Call -- Call Is Blocked");
			*peStatus = IFX_CMGR_STATUS_FAIL;
			return eRetVal;
		}	
		/*Else The event is to be given to the FSM */			
		xEvtInfo.eCurrEvt = IFX_FXO_EVT_IncCall;
	}
	/*Populate the Number to be dialed and Call ID*/
	strcpy(xEvtInfo.uxEvtInfo.xIncCallInfo.szPstnDgt,
										pxTo->uxAddressInfo.xFxoInfo.szPhoneNumber);
	xEvtInfo.uxEvtInfo.xIncCallInfo.eCallType =pxFrom->eAddressType ; 
	xEvtInfo.uxEvtInfo.xIncCallInfo.uiCallId = uiCallId; 
	xEvtInfo.uiCallId = uiCallId; 
	/*Assign default value to status as FAIL i. e. The call is to be is rejected*/
	*peStatus = IFX_CMGR_STATUS_FAIL;
	/*Invoke the FSM*/
	eRetVal =  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo);
	
	/* IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "In IncCall :- FXO FSM Returned:",
						GetFXOReturn(xEvtInfo.eReturn)); */

	/*Repopulate the return values*/
	if(IFX_FXO_AcceptCall == xEvtInfo.eReturn)
	{	
		*peStatus = IFX_CMGR_STATUS_PENDING;			
		*peReason = IFX_ENDPOINT_RINGING;
	}
	else if(IFX_FXO_RejectCall == xEvtInfo.eReturn)
	{	
		*peStatus = IFX_CMGR_STATUS_FAIL;	
	}
	else if(IFX_FXO_AnswerCall == xEvtInfo.eReturn)
	{	
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
	}
		
	/*populate the private data*/
	*ppvPrivateData = pxEndptInfo;
	return IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);
	
}

//IFX_FXO_EVT_ReleaseCall,
e_IFX_Return IFX_FXO_RemoteCallRelease(
							IN uint32 uiCallId,
							IN e_IFX_ReasonCode eReleaseReason,
							IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
					 		IN void* pvPrivateData)
{
	x_IFX_FXO_EvtInfo xEvtInfo;
	e_IFX_Return eRetVal=IFX_SUCCESS;
	/*Restore EndpointInfo*/
	x_IFX_FXO_Info * pxEndptInfo = pvPrivateData;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	/*Populate the EventInfo*/
	memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
	xEvtInfo.uiCallId = uiCallId; 
	xEvtInfo.eCurrEvt = IFX_FXO_EVT_ReleaseCall;
	/*Invoke the FSM*/
	eRetVal =  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo);
	return IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);
}


//IFX_FXO_EVT_RmtAccept,
e_IFX_Return IFX_FXO_RemoteCallAccept(
								IN uint32 uiCallId,
					 			IN void* pvPrivateData)
{
	x_IFX_FXO_EvtInfo xEvtInfo;
	e_IFX_Return eRetVal=IFX_SUCCESS;
	/*Restore EndpointInfo*/
	x_IFX_FXO_Info * pxEndptInfo = pvPrivateData;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");

	memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
	xEvtInfo.uiCallId = uiCallId; 
	xEvtInfo.eCurrEvt = IFX_FXO_EVT_RmtAccept;
	/*Invoke the FSM*/
	eRetVal =  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo);
	return IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);
}

//IFX_FXO_EVT_RmtAnswer,
e_IFX_Return IFX_FXO_RemoteCallAnswer(
								IN uint32 uiCallId,
					 			IN void* pvPrivateData)							
{
	x_IFX_FXO_EvtInfo xEvtInfo;
	e_IFX_Return eRetVal=IFX_SUCCESS;
	/*Restore EndpointInfo*/
	x_IFX_FXO_Info * pxEndptInfo = pvPrivateData;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
	xEvtInfo.uiCallId = uiCallId; 
	xEvtInfo.eCurrEvt = IFX_FXO_EVT_RmtAnswer;
	/*Invoke the FSM*/
	eRetVal =  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo);
	return IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);
}

e_IFX_Return IFX_FXO_RecvInfo(
                IN x_IFX_CMGR_AddressInfo* pxFrom,
                IN x_IFX_CMGR_AddressInfo* pxTo,
                IN void* pvInfo,
                IN uint16 unSize,
                OUT e_IFX_CMGR_Status* peStatus,
                OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXO_EvtInfo xEvtInfo;
	e_IFX_Return eRetVal=IFX_SUCCESS;
	x_IFX_FXO_Info * pxEndptInfo = &vaxFXOInfo[0];
	uchar8 ucCount = 0;

    *peStatus = IFX_CMGR_STATUS_PENDING;

	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Search for Appropriate endpoint*/
	for(ucCount = 0;ucCount < IFX_MMGR_MAX_FXO_CHANNELS;ucCount++)
	{
		if(0 == strcmp(pxTo->uxAddressInfo.xFxoInfo.szFxoLineId,
													vaxFXOInfo[ucCount].szEndPointId))
		{
			pxEndptInfo = &vaxFXOInfo[ucCount];
			break;
		}		
	}
	/**Endpoint not found**/
	if(ucCount == IFX_MMGR_MAX_FXO_CHANNELS)
	{		
		return IFX_FAILURE;
	}
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING))
	{
		/*If emergency call is ongoing, Drop the event.*/
		return eRetVal;	
	}
  *peStatus = IFX_CMGR_STATUS_SUCCESS;
	memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
	xEvtInfo.eCurrEvt = IFX_FXO_EVT_PSTNHookFlash;
	/*Invoke the FSM*/
	eRetVal =  IFX_FXOHdlr(pxEndptInfo,&xEvtInfo);
	return IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);
}

/*****
This is a special function which doesnot 
invoke the FSM but just changes the call ID
of Active Call.
******/

e_IFX_Return IFX_FXO_CallIdReplace
                     (
                        IN uint32 uiOldCallId,
                        IN uint32 uiNewCallId,
                        IN_OUT void** ppvPrivateData)
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	/*Restore EndpointInfo*/
	x_IFX_FXO_Info * pxEndptInfo = *ppvPrivateData;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	
	if(pxEndptInfo->axFxoCallData[0].uiCallId == uiOldCallId)
		pxEndptInfo->axFxoCallData[0].uiCallId = uiNewCallId;
	else
		eRetVal = IFX_FAILURE;

	return IFX_FXO_PrintExitInfo(eRetVal,__FUNCTION__);

}
//IFX_FXO_EVT_TransmitSMS,
e_IFX_Return IFX_FXO_SMS_SmsReceived(
                                    IN x_IFX_CMGR_AddressInfo *pxFrom,
                                    IN x_IFX_CMGR_AddressInfo *pxTo,
                                    IN char8* szSmsBody,
                                    IN boolean bUnread,
                                    IN uint16 unSmsId,
                                    OUT e_IFX_CMGR_Status* peStatus,
                                    OUT e_IFX_ReasonCode* peReason)
{
	x_IFX_FXO_EvtInfo xEvtInfo;
	e_IFX_Return eRetVal=IFX_SUCCESS;
	x_IFX_FXO_Info * pxEndptInfo = &vaxFXOInfo[0];
	uchar8 ucCount = 0;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");

	memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
	/*Search for Appropriate endpoint*/
	for(ucCount = 0;ucCount < IFX_MMGR_MAX_FXO_CHANNELS;ucCount++)
	{
		if(0 == strcmp(pxTo->uxAddressInfo.xFxoInfo.szFxoLineId,
														vaxFXOInfo[ucCount].szEndPointId))
		{
			pxEndptInfo = &vaxFXOInfo[ucCount];
			break;
		}		
	}
	/**Endpoint not found**/
	if(ucCount == IFX_MMGR_MAX_FXO_CHANNELS)
	{		
		return IFX_FAILURE;
	}
	/*Fail If the emergency call is proceeding.*/
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
		*peReason = IFX_ENDPOINT_BUSY;	
		return eRetVal;	
	}
	memset(&xEvtInfo,0,sizeof(x_IFX_FXO_EvtInfo));
	/*Initialize the status to failure  initially i. e. the SMS is not acceptsd*/
	*peStatus = IFX_CMGR_STATUS_FAIL;
	//TBD: Populate the EvtInfo
	//TBD: Invoke the FSM
	//Analyse return types.
	return eRetVal;
}

/* The Functions to be registered with Call manager but send success always */

e_IFX_Return IFX_FXO_BlindTxRequest(
					 	IN uint32 uiCallId,
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						OUT e_IFX_TransferStatus* peTransferStatus,
						OUT e_IFX_ReasonCode *peRespCode,
						IN void* pvPrivateData)
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	/*Restore EndpointInfo*/
	x_IFX_FXO_Info * pxEndptInfo = (x_IFX_FXO_Info *)pvPrivateData;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");

	*peTransferStatus=IFX_CMGR_TRANSFER_ACCEPTED;
	/*Fail If the emergency call is proceeding.*/
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING))
	{
		*peTransferStatus=IFX_CMGR_TRANSFER_REJECTED;
	}	
	return eRetVal;
}

e_IFX_Return IFX_FXO_AttendedTxRequest(
					 	IN uint32 uiCallId,
						IN uint32 uiReplacesCallId,
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						OUT e_IFX_TransferStatus* peTransferStatus,
						OUT e_IFX_ReasonCode *peRespCode,
						IN void* pvPrivateData)
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	/*Restore EndpointInfo*/
	x_IFX_FXO_Info * pxEndptInfo = (x_IFX_FXO_Info*)(pvPrivateData);
	*peTransferStatus=IFX_CMGR_TRANSFER_ACCEPTED;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");

	/*Fail If the emergency call is proceeding.*/
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING))
	{
		*peTransferStatus=IFX_CMGR_TRANSFER_REJECTED;
	}	
	return eRetVal;
}

e_IFX_Return IFX_FXO_BlindTxStatus(
					 	IN uint32 uiCallId,
						IN e_IFX_TransferStatus eTransferStatus, 
						IN e_IFX_ReasonCode eRespCode,
						IN void* pvPrivateData)	
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	return eRetVal;
}

e_IFX_Return IFX_FXO_AttendedTxStatus(
													IN uint32 uiCallId,
                  							IN e_IFX_TransferStatus eTransferStatus,
                  							IN e_IFX_ReasonCode eRespCode,
                  							IN void* pvPrivateData)
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	return eRetVal;
}

e_IFX_Return IFX_FXO_RemoteCallHold(
								IN uint32 uiCallId,
								OUT e_IFX_CMGR_Status* peStatus,
								OUT e_IFX_ReasonCode* peReason,
								IN void* pvPrivateData)
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	/*Restore EndpointInfo*/
	x_IFX_FXO_Info * pxEndptInfo = (x_IFX_FXO_Info *)pvPrivateData;
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");

	/*Fail If the emergency call is proceeding.*/
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}	
	return eRetVal;
}

e_IFX_Return IFX_FXO_RemoteCallResume(
								IN uint32 uiCallId,
								OUT e_IFX_CMGR_Status* peStatus,
								OUT e_IFX_ReasonCode* peReason,
								IN void* pvPrivateData)
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	/*Restore EndpointInfo*/
	x_IFX_FXO_Info * pxEndptInfo = (x_IFX_FXO_Info *)(pvPrivateData);
	*peStatus = IFX_CMGR_STATUS_SUCCESS;
	
	IFX_DBGA(vucFXOModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,"Entry");
	/*Fail If the emergency call is proceeding.*/
	if(IFX_FXO_GET_FLAG(pxEndptInfo->uiFlags,IFX_FXO_EMG_CALL_PROCEEDING))
	{
		*peStatus = IFX_CMGR_STATUS_FAIL;
	}	
	return eRetVal;
}

e_IFX_Return IFX_FXO_CallFwdInfo(
								IN uint32 uiCallId,
								IN e_IFX_ReasonCode eReason,
								IN x_IFX_CMGR_VoipAddr* pxFwdAddr,
								OUT boolean* pbFwdAllow,
								IN void* pvPrivateData)
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	*pbFwdAllow = 1;
	return eRetVal;
}

e_IFX_Return IFX_FXO_SMS_SmsStatus(
								IN uint16 unSmsId,
								IN e_IFX_CMGR_Status eSmsStatus)
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	return eRetVal;
}

e_IFX_Return IFX_FXO_CallHoldRsp(
									IN uint32 uiCallId,
									IN e_IFX_CMGR_Status eStatus,
									IN e_IFX_ReasonCode eReason, 
					 				IN void* pvPrivateData)							
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	return eRetVal;
}

e_IFX_Return IFX_FXO_CallResumeRsp(
									IN uint32 uiCallId,
									IN e_IFX_CMGR_Status eStatus,
									IN e_IFX_ReasonCode eReason, 
					 				IN void* pvPrivateData)							
{
	e_IFX_Return eRetVal=IFX_SUCCESS;
	return eRetVal;
}

