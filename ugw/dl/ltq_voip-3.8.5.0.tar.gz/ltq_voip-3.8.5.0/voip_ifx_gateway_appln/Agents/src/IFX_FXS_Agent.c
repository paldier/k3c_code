/**************************************************************************
 **   SRC_FILE          : IFX_FXS_Agent.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : FXS Agent 
 **   SRC VERSION       : v0.1
 **   DATE              : 
 **   AUTHOR            : Mahipati Deshpande
 **   DESCRIPTION       : 
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$ 
 **   $Date$ 
 **   $Revisions$
 **   $Log$
*******************************************************************************/

#include <stdio.h>
#include <string.h>
/* According to POSIX 1003.1-2001 */
#include <sys/select.h>
/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include "ifx_common_defs.h"
#include "IFX_Config.h"
#include "IFX_TimerIf.h"
#include "IFX_CallMgrIf.h"
#include "IFX_Agents_CfgIf.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_DialPlanIf.h"
#include "IFX_Misc.h"
#include "ifx_debug.h"
#include "IFX_AgentsUtils.h"

#include "IFX_FXS_Agent.h"

#define IFX_FXS_REG_DIAL_TONE           IFX_MMGR_DIAL_TONE
/* TODO: Change to unregister tone */
#define IFX_FXS_UNREG_DIAL_TONE         IFX_MMGR_DIAL_TONE 
/*TODO: Santosh has to define */ 
#define IFX_MMGR_DISTINCTIVE_RING_TONE  IFX_MMGR_RING_TONE  //IFX_MMGR_SEC_DIAL_TONE
#define printf

/* This array is used to store FXS endpoint FSM Infomration */
x_IFX_FXS_EndptFsmInfo vaxFxsEndptFsmInfo[IFX_MMGR_MAX_FXS_CHANNELS];
uchar8 vucFxsAgnetModId;
uint16 vunDialToneLength = 60000;//milliseconds

/* FXS FSM handler functions */
/*----- Utility routines for FXS Agent -----*/

#define IFX_FXS_GetCallInfo(pxEndpt, CallId, ppxCallInfo) \
	{ \
		if( (pxEndpt)->axFxsCallInfo[0].uiCallId == (CallId) ) \
			*(ppxCallInfo) = ((pxEndpt)->axFxsCallInfo+0); \
		else if( (pxEndpt)->axFxsCallInfo[1].uiCallId == (CallId) ) \
			*(ppxCallInfo) = ((pxEndpt)->axFxsCallInfo+1); \
		else \
			*(ppxCallInfo) = 0; \
	}

#define IFX_FXS_GetFreeCallInfo(pxEndpt, ppxCallInfo) \
	{ \
		if( (pxEndpt)->axFxsCallInfo[0].uiCallId == 0 ) \
			*(ppxCallInfo) = ((pxEndpt)->axFxsCallInfo+0); \
		else if( (pxEndpt)->axFxsCallInfo[1].uiCallId == 0) \
			*(ppxCallInfo) = ((pxEndpt)->axFxsCallInfo+1); \
		else \
			*(ppxCallInfo) = 0; \
	}

#define IFX_FXS_GetWaitingCallInfo(pxEndpt, ppxWaitingCall) \
	{ \
		if( IFX_FXS_CS_RINGING ==  pxEndpt->axFxsCallInfo[0].eCallState ) \
			*(ppxWaitingCall) = (pxEndptInfo->axFxsCallInfo + 0); \
		else if( IFX_FXS_CS_RINGING == pxEndptInfo->axFxsCallInfo[1].eCallState ) \
			*(ppxWaitingCall) = (pxEndptInfo->axFxsCallInfo + 1); \
		else \
			*(ppxWaitingCall) = NULL; \
	}

/*
 * This routine returns last held call of a given FXS endpoint.
 */
#define IFX_FXS_GetLastHeldCall(pxEndpt, ppxLastHeldCall) \
	{ \
		if( IFX_FXS_CS_LOCAL_HELD == pxEndpt->axFxsCallInfo[0].eCallState ) \
			*(ppxLastHeldCall) = (pxEndpt->axFxsCallInfo+0); \
		else if( IFX_FXS_CS_LOCAL_HELD ==  pxEndpt->axFxsCallInfo[1].eCallState ) \
			*(ppxLastHeldCall) = (pxEndpt->axFxsCallInfo+1); \
		else \
			*(ppxLastHeldCall) = NULL; \
	}

#define IFX_FXS_ReleaseCall(pxEndpt, pxRelCall) \
	{ \
		memset(pxRelCall,0,sizeof(x_IFX_FXS_CallInfo)); \
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_ORIGINATOR); \
	} 

#define IFX_FXS_UpdateCallState(pxEndpt, pxCall, eState) \
	{ \
		(pxCall)->eCallState = eState; \
	}

#define IFX_FXS_UpdateEndpointState(pxEndpt, state) \
	{ \
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_LOW,IFX_DBG_ATA_STRING_INFO, \
						(pxEndpt)->szEndPointId, IFX_FXS_GetStateStr(pxEndpt->eState) ); \
		pxEndpt->ePrevState = pxEndpt->eState; \
		pxEndpt->eState = state; \
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_LOW,IFX_DBG_ATA_STRING_INFO, \
						(pxEndpt)->szEndPointId, IFX_FXS_GetStateStr(pxEndpt->eState) ); \
	} 

#define IFX_FXS_SetEndpointFlag(pxEndpt, flag) \
						IFX_FXS_SET_FLAG((pxEndpt)->uiFlags,flag)

#define IFX_FXS_ResetEndpointFlag(pxEndpt, flag) \
						IFX_FXS_RESET_FLAG(pxEndpt->uiFlags,flag)

#define IFX_FXS_CheckEndpointFlag(pxEndpt, flag) \
						IFX_FXS_CHECKFLAG(pxEndpt->uiFlags,flag)

STATIC e_IFX_Return IFX_FXS_StartTone(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndPtInfo,
	                      IN e_IFX_MMGR_ToneType eToneType,
	                      IN uint32 unTimeOut,
	                      IN e_IFX_FXS_Event eEventOnExpiry,
	                      IN x_IFX_MMGR_CidParams* pxCidparams,
	                      IN uint32* puiTimerId );

STATIC e_IFX_Return IFX_FXS_StopTone(
	                   IN x_IFX_FXS_EndptFsmInfo* pxEndPtInfo,
	                   IN_OUT uint32* puiTimerId);

STATIC void IFX_FXS_TimerFired(
	              IN uint32 uiTimerId,
	              IN void* pvPrivateData );

STATIC e_IFX_Return IFX_FXS_MsgRouterEvtHdlr(
	                      IN x_IFX_MMGR_DeviceEvents	*pxDevEvents);

STATIC e_IFX_Return IFX_FXS_ExecuteDialPlanAction(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndPtInfo,
	                      IN char8* szDialOut,
												IN e_IFX_DP_Action eDpAction,
	                      OUT e_IFX_MMGR_ToneType* peToneType,
	                      OUT e_IFX_FXS_State* peState
	                      );

STATIC e_IFX_Return IFX_FXS_InitiateCall(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
												IN x_IFX_CMGR_AddressInfo* pxDialedAddr,
												e_IFX_CMGR_FeatStatus eCidStatus,
	                      IN boolean bEmergencyCall,
	                      OUT e_IFX_CMGR_Status* peStatus,
	                      OUT e_IFX_ReasonCode* peReason);

STATIC e_IFX_Return IFX_FXS_ActDeActvAutoRedial(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	                      IN boolean bEnable,
	                      OUT e_IFX_MMGR_ToneType* peToneType,
	                      OUT e_IFX_FXS_State* peState ) ;

STATIC e_IFX_Return IFX_FXS_BlindTransfer(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	                      IN char8* szDialOut,
	                      OUT e_IFX_TransferStatus* peState );

STATIC e_IFX_Return IFX_FXS_SetCallForward(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	                      IN e_IFX_DP_Action eDpAction,
	                      IN char8* szDialOut );

STATIC e_IFX_MMGR_ToneType IFX_FXS_GetDialToneType(
	                                 IN char8* szEndpointId, 
	                                 OUT uint16* punTimeOut);

STATIC e_IFX_Return IFX_FXS_GetEndpointInfo(IN char8* szEndpointId,
	                      OUT x_IFX_FXS_EndptFsmInfo** ppxEndPtInfo);

STATIC e_IFX_Return IFX_FXS_CallHoldSuccess(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo, 
	                      OUT e_IFX_FXS_State* peEndptState,
	                      OUT e_IFX_ReasonCode* peReason );

STATIC e_IFX_Return IFX_FXS_ResumeCallInBusy(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
										    OUT e_IFX_ReasonCode* peReason );
STATIC e_IFX_Return IFX_FXS_AutoRedial(IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo);
STATIC char8* IFX_FXS_GetStateStr( IN e_IFX_FXS_State eState );
STATIC char8* IFX_FXS_GetEventStr( IN  e_IFX_FXS_Event eEvent);

STATIC e_IFX_Return IFX_FXS_SendAutoRedialNtfy(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndPtInfo,
	                      IN boolean bNotify);

uchar8 IFX_FXS_GetHeldCallsCount(
	                   IN x_IFX_FXS_EndptFsmInfo* pxEndPtInfo);

EXTERN e_IFX_Return IFX_DECT_ChangeBasePin(char8* pszPin);

pfn_IFX_FXS_Fsm 
	vax_IFX_FXSFsm[IFX_FXS_STATE_MAX][IFX_FXS_EventMax] = 
{
	/* IFX_FXS_STATE_IDLE        */
	{
		IFX_FXS_IdleOffHookHdlr,/* IFX_FXS_EVT_OffHk */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_OnHk  */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_HkFlash */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DigitPressed */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_InterDgtTimerExp */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DialToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_StutterToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingBackToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BCEToneExpired*/
		IFX_FXS_IdleIncomingCallHdlr,/* IFX_FXS_EVT_IncomingCall*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ReleaseCall*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAccept*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAnswer*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtHold*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtResume*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_HoldResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ResumeResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ConfStatus*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BTxResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ATxResp*/
		IFX_FXS_IgnoreHdlr,	/** FAX DIS event */
		IFX_FXS_IgnoreHdlr, /** FAX CED event */
		IFX_FXS_IgnoreHdlr  /** FAX CNG event */
	},
	/* IFX_FXS_STATE_DIALING     */
	{
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_OffHk */
		IFX_FXS_DialingOnHookHdlr,/* IFX_FXS_EVT_OnHk  */
		IFX_FXS_DialingHookFlashHdlr,/* IFX_FXS_EVT_HkFlash */
		IFX_FXS_DialingDigitPressedHdlr,/* IFX_FXS_EVT_DigitPressed */
		IFX_FXS_DialingInterDigitExpiryHdlr,/* IFX_FXS_EVT_InterDgtTimerExp */
		IFX_FXS_DialingDialToneExpiryHdlr,/* IFX_FXS_EVT_DialToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingToneExpired*/
		IFX_FXS_DialingStutterToneExpiryHdlr,/* IFX_FXS_EVT_StutterToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingBackToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BCEToneExpired*/
		IFX_FXS_IgnoreCallHdlr,/* IFX_FXS_EVT_IncomingCall*/
		IFX_FXS_DialAndRingbackReleaseCallHdlr,/* IFX_FXS_EVT_ReleaseCall*/
		IFX_FXS_DialingRmtAcceptHdlr,/* IFX_FXS_EVT_RmtAccept*/
		IFX_FXS_RemoteAnswerHdlr,/* IFX_FXS_EVT_RmtAnswer*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtHold*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtResume*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_HoldResp*/
		IFX_FXS_DialingResumeRespHdlr,/* IFX_FXS_EVT_ResumeResp*/
		IFX_FXS_DialingConferenceStatusHdlr,/* IFX_FXS_EVT_ConfStatus*/
		IFX_FXS_DialingBtxRespHdlr,/* IFX_FXS_EVT_BTxResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ATxResp*/
		IFX_FXS_IgnoreHdlr,	/** FAX DIS event */
		IFX_FXS_IgnoreHdlr, /** FAX CED event */
		IFX_FXS_IgnoreHdlr  /** FAX CNG event */
	},
	/* IFX_FXS_STATE_RINGING     */
	{
		IFX_FXS_RingOffHookHdlr,/* IFX_FXS_EVT_OffHk */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_OnHk  */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_HkFlash */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DigitPressed */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_InterDgtTimerExp */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DialToneExpired*/
		IFX_FXS_RingRingTimerExpiryHdlr,/* IFX_FXS_EVT_RingToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_StutterToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingBackToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BCEToneExpired*/
		IFX_FXS_IgnoreCallHdlr,/* IFX_FXS_EVT_IncomingCall*/
		IFX_FXS_RingReleaseCallHdlr,/* IFX_FXS_EVT_ReleaseCall*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAccept*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAnswer*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtHold*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtResume*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_HoldResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ResumeResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ConfStatus*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BTxResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ATxResp*/
		IFX_FXS_IgnoreHdlr,	/** FAX DIS event */
		IFX_FXS_IgnoreHdlr, /** FAX CED event */
		IFX_FXS_IgnoreHdlr  /** FAX CNG event */
	},
	/* IFX_FXS_STATE_RINGBACK    */
	{
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_OffHk */
		IFX_FXS_RingbackOnHookHdlr,/* IFX_FXS_EVT_OnHk  */
		IFX_FXS_RingbackHookFlashHdlr,/* IFX_FXS_EVT_HkFlash */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DigitPressed */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_InterDgtTimerExp */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DialToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_StutterToneExpired*/
		IFX_FXS_RingbackRingbackTimerExpiryHdlr,/* IFX_FXS_EVT_RingBackToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BCEToneExpired*/
		IFX_FXS_IgnoreCallHdlr,/* IFX_FXS_EVT_IncomingCall*/
		IFX_FXS_DialAndRingbackReleaseCallHdlr,/* IFX_FXS_EVT_ReleaseCall*/
		//IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAccept*/
		IFX_FXS_RingbackRmtAcceptHdlr,/* IFX_FXS_EVT_RmtAccept*/
		IFX_FXS_RemoteAnswerHdlr,/* IFX_FXS_EVT_RmtAnswer*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtHold*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtResume*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_HoldResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ResumeResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ConfStatus*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BTxResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ATxResp*/
		IFX_FXS_IgnoreHdlr,	/** FAX DIS event */
		IFX_FXS_IgnoreHdlr, /** FAX CED event */
		IFX_FXS_IgnoreHdlr  /** FAX CNG event */
	},
	/* IFX_FXS_STATE_CONVERSATION*/
	{
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_OffHk */
		IFX_FXS_ConvOnHookHdlr,/* IFX_FXS_EVT_OnHk  */
		IFX_FXS_ConvAndCwHookFlashHdlr,/* IFX_FXS_EVT_HkFlash */
		IFX_FXS_DigitPressedDuringConvHdlr,/* IFX_FXS_EVT_DigitPressed */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_InterDgtTimerExp */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DialToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_StutterToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingBackToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BCEToneExpired*/
		IFX_FXS_ConvIncomingCallHdlr,/* IFX_FXS_EVT_IncomingCall*/
		IFX_FXS_ConvReleaseCallHdlr,/* IFX_FXS_EVT_ReleaseCall*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAccept*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAnswer*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtHold*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtResume*/
		IFX_FXS_ConvAndCwHoldRespHdlr,/* IFX_FXS_EVT_HoldResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ResumeResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ConfStatus*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BTxResp*/
		IFX_FXS_IgnoreHdlr,
		//IFX_FXS_ConvAtxRespHdlr,/* IFX_FXS_EVT_ATxResp*/
		IFX_FXS_ConvFaxStartHdlr,	/** FAX DIS event */
		IFX_FXS_ConvFaxStartHdlr, /** FAX CED event */
		IFX_FXS_ConvCNGHdlr /** FAX CNG event */
	},	
	/* IFX_FXS_STATE_CONFERENCE  */
	{
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_OffHk */
		IFX_FXS_ConfOnHookHdlr,/* IFX_FXS_EVT_OnHk  */
		IFX_FXS_ConfHookFlashHdlr,/* IFX_FXS_EVT_HkFlash */
		IFX_FXS_DigitPressedDuringConvHdlr,/* IFX_FXS_EVT_DigitPressed */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_InterDgtTimerExp */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DialToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_StutterToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingBackToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BCEToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_IncomingCall*/
		IFX_FXS_ConfReleaseCallHdlr,/* IFX_FXS_EVT_ReleaseCall*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAccept*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAnswer*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtHold*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtResume*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_HoldResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ResumeResp*/
		IFX_FXS_ConfConfStatusHdlr,/* IFX_FXS_EVT_ConfStatus*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BTxResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ATxResp*/
		IFX_FXS_IgnoreHdlr,	/** FAX DIS event */
		IFX_FXS_IgnoreHdlr, /** FAX CED event */
		IFX_FXS_IgnoreHdlr  /** FAX CNG event */
	},
	/* IFX_FXS_STATE_CALLWAITING */
	{
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_OffHk */
		IFX_FXS_CwOnHookHdlr,/* IFX_FXS_EVT_OnHk  */
		IFX_FXS_ConvAndCwHookFlashHdlr,/* IFX_FXS_EVT_HkFlash */
		IFX_FXS_CwDigitPressedHdlr,/* IFX_FXS_EVT_DigitPressed */  
		IFX_FXS_CwInterDigitTimerExpiryHdlr,/* IFX_FXS_EVT_InterDgtTimerExp */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DialToneExpired*/
		IFX_FXS_CwRingToneExpiryHdlr,/* IFX_FXS_EVT_RingToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_StutterToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingBackToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BCEToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_IncomingCall*/
		IFX_FXS_CwReleaseCallHdlr,/* IFX_FXS_EVT_ReleaseCall*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAccept*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAnswer*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtHold*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtResume*/
		IFX_FXS_ConvAndCwHoldRespHdlr,/* IFX_FXS_EVT_HoldResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ResumeResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ConfStatus*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BTxResp*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ATxResp*/
		IFX_FXS_IgnoreHdlr,	/** FAX DIS event */
		IFX_FXS_IgnoreHdlr, /** FAX CED event */
		IFX_FXS_IgnoreHdlr  /** FAX CNG event */
	},
	/* IFX_FXS_STATE_BUSY        */
	{
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_OffHk */
		IFX_FXS_BusyOnHookHdlr,/* IFX_FXS_EVT_OnHk  */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_HkFlash */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DigitPressed */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_InterDgtTimerExp */  
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_DialToneExpired */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RingToneExpired */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_StutterToneExpired */
		IFX_FXS_BusyRingTimerExpiryHdlr,/* IFX_FXS_EVT_RingBackToneExpired */
		IFX_FXS_BCEToneTimerExpiryHdlr,/* IFX_FXS_EVT_BCEToneExpired*/
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_IncomingCall */
		IFX_FXS_BusyReleaseCallHdlr,/* IFX_FXS_EVT_ReleaseCall */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAccept */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtAnswer */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtHold */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_RmtResume */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_HoldResp */
		IFX_FXS_BusyResumeRespHdlr,/* IFX_FXS_EVT_ResumeResp */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ConfStatus */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_BTxResp */
		IFX_FXS_IgnoreHdlr,/* IFX_FXS_EVT_ATxResp */
		IFX_FXS_IgnoreHdlr,	/** FAX DIS event */
		IFX_FXS_IgnoreHdlr, /** FAX CED event */
		IFX_FXS_IgnoreHdlr  /** FAX CNG event */
	}
};

/*******************************************************************************
 *  Function Name   : IFX_FXS_AgentInit
 *  Description     : This function initializes FXS endpoint.  
 *  Input Values    : aszEndPoiaszEndPointIdntId - List of endpoints to be 
                                     initialized
                      ucNoOfEndpts - Number of endpoints in to be init 
                      ucFxsDbgId   - Debug Id for FXS agent. 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - If given FXS endpoints are initialized
                      IFX_FAILURE - If failed to initialize FXS endpoints
 *  Notes           : Don't initialize same endpoint twice.
 ******************************************************************************/
e_IFX_Return IFX_FXS_AgentInit(
	                   IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucNoOfEndpts,
	                   IN uchar8 ucFxsDbgId )
{
	x_IFX_CMGR_CallBackList xCallBacks = {0} ;
	uchar8 ucFreeSlot = 0;
	uchar8 ucEndptCount = 0;
	e_IFX_Return eRet = IFX_FAILURE;
	/*
	 * Find free slot in vaxFxsEndptFsmInfo. If no free slot, something is 
	 * seriously wrong -- return IFX_FAILURE. 
	 * Intialize endpoint info and assign endpoint id. Register callback functions
	 * for this endpoint with call manager. Return IFX_SUCCESS only if 
	 * initialization is success, else return IFX_FAILURE.
	 */
	
	if( ucNoOfEndpts > IFX_MMGR_MAX_FXS_CHANNELS )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR ,
			 "Endpoints exceeded IFX_MMGR_MAX_FXS_CHANNELS");
		return eRet;
	}
	
	while( ucEndptCount < ucNoOfEndpts )
	{
		ucFreeSlot = 0;
		while(ucFreeSlot < IFX_MMGR_MAX_FXS_CHANNELS )
		{
			if( strlen(vaxFxsEndptFsmInfo[ucFreeSlot].szEndPointId ) == 0 )
				break;
			++ucFreeSlot;
		}

		if( ucFreeSlot == IFX_MMGR_MAX_FXS_CHANNELS )
		{
			/* Could not get free slot */
			IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"No Free Slot");
			return eRet;
		}

		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_LOW,IFX_DBG_ATA_STRING_INFO,
				"Initializing FXS Endpoint", aszEndPointId[ucEndptCount]);
		/*printf("Initializing FXS Endpoint %s\n",aszEndPointId[ucEndptCount]);
		printf("MAX FXS ENDPTS is  %d and ucNoOfEdpts is %d\n",IFX_MMGR_MAX_FXS_CHANNELS,ucNoOfEndpts);*/
		strcpy(vaxFxsEndptFsmInfo[ucFreeSlot].szEndPointId,
			aszEndPointId[ucEndptCount]);

		++ucEndptCount;
	}

	if( IFX_SUCCESS != 
		IFX_MSGRTR_EventCallBackRegister(aszEndPointId,ucNoOfEndpts,
																		IFX_FXS_MsgRouterEvtHdlr ) )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				 		"IFX_MSGRTR_EventCallBackRegister Failed");
		return eRet;
	}

	xCallBacks.pfnCallIncoming = IFX_FXS_CallIncoming;
	xCallBacks.pfnRemoteCallAccept = IFX_FXS_RemoteCallAccept;
	xCallBacks.pfnRemoteCallAnswer = IFX_FXS_RemoteCallAnswer;
	xCallBacks.pfnRemoteCallHold = IFX_FXS_RemoteCallHold;
	xCallBacks.pfnRemoteCallResume = IFX_FXS_RemoteCallResume;
	xCallBacks.pfnCallHoldRsp =  IFX_FXS_CallHoldResponse;
	xCallBacks.pfnCallResumeRsp = IFX_FXS_CallResumeResponse;
	xCallBacks.pfnRemoteCallRelease = IFX_FXS_RemoteCallRelease;
	xCallBacks.pfnCallFwdInfo = IFX_FXS_CallForwardInfo;
	xCallBacks.pfnConfStatus = IFX_FXS_ConfStatus;
	xCallBacks.pfnARD_Status = IFX_FXS_AutoRedialStatus;
	xCallBacks.pfnARD_NtfnRcv = IFX_FXS_AutoRedialNotifyReceived;
	xCallBacks.pfnARD_Reg = IFX_FXS_AutoRedialRegister;
	xCallBacks.pfnBlindTxReq = IFX_FXS_BlindTxRequest;
	xCallBacks.pfnBlindTxStatus = IFX_FXS_BlindTxStatus;
	xCallBacks.pfnAttendedTxReq = IFX_FXS_AttendedTxRequest;
	xCallBacks.pfnAttendedTxStatus = IFX_FXS_AttendedTxStatus;
  xCallBacks.pfnCallIdRep = IFX_FXS_CallIdReplace;
	
	if( IFX_SUCCESS != 
		(eRet=IFX_CMGR_CallBacksRegister(aszEndPointId,ucNoOfEndpts,&xCallBacks)) )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 			"IFX_CMGR_CallBacksRegister Failed");
		return eRet;
	}
  
	vucFxsAgnetModId = ucFxsDbgId; 

		IFX_CIF_DialToneLengthSet();
	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_AgentShut  
 *  Description     : This function shuts FXS agent. Call this function to stop
                      FXS agent.
 *  Input Values    : aszEndPointId  - List of endpoints to be shut
                      ucNoOfEndpts   - Number of endpoint to be shut.
 *  Output Values   : IFX_SUCCESS - If all given endpoints endpoints are shut.
                      IFX_FALSE - On failure. 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_AgentShut(
	                   IN char8 aszEndPointId[][IFX_MAX_ENDPOINTID_LEN], 
	                   IN uchar8 ucNoOfEndpts )
{
	uchar8 ucEndptSlot = 0;
	uchar8 ucEndptIndex = 0;
	boolean bShutProblem = IFX_FALSE;
	e_IFX_MMGR_ToneType eToneType;
	e_IFX_FXS_State eState;
	e_IFX_ReasonCode eReason;

	/*
	 * For each endpoint in aszEndPointId, make endpoint idle
	 */
	while( ucEndptIndex < ucNoOfEndpts )
	{
		ucEndptSlot = 0;
		while(ucEndptSlot < IFX_MMGR_MAX_FXS_CHANNELS )
		{
			if( strcmp(aszEndPointId[ucEndptIndex],
				vaxFxsEndptFsmInfo[ucEndptSlot].szEndPointId ) == 0 )
			{
				break;
			}
			++ucEndptSlot;
		}

		if( IFX_MMGR_MAX_FXS_CHANNELS == ucEndptSlot )
		{
			bShutProblem = IFX_TRUE;
		} 
		else
		{
			x_IFX_FXS_EndptFsmInfo* pxEndPtInfo = (vaxFxsEndptFsmInfo+ucEndptSlot);
			/*
			 * If auto redial subscription is active Terminate it (both side). Make
			 * endpoint idle (this disconnects all calls). Then memset thie endpoint
			 * information.
			 */
			if( IFX_FXS_CheckEndpointFlag(pxEndPtInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN))
				IFX_FXS_SendAutoRedialNtfy(pxEndPtInfo,IFX_FALSE);

			if( IFX_FXS_CheckEndpointFlag(pxEndPtInfo,IFX_FXS_AUTOREDIAL_ACTIVE_OUT))
				IFX_FXS_ActDeActvAutoRedial(pxEndPtInfo,IFX_FALSE, &eToneType,&eState);

			IFX_FXS_MakeFXSIdle(pxEndPtInfo,&eReason);
			memset(pxEndPtInfo,0,sizeof(x_IFX_FXS_EndptFsmInfo));
		}

		++ucEndptIndex;
	} /* while */

	if( (e_IFX_Return) IFX_MMGR_SUCCESS != 
		IFX_MSGRTR_EventCallBackUnregister(aszEndPointId,ucNoOfEndpts) )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			aszEndPointId[0], "IFX_MSGRTR_EventCallBackUnregister FAILED");
		bShutProblem = IFX_TRUE;	
	}

	if( IFX_SUCCESS != IFX_CMGR_CallBacksUnRegister(aszEndPointId,ucNoOfEndpts))
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				aszEndPointId[0], "IFX_CMGR_CallBacksUnRegister FAILED");
		bShutProblem = IFX_TRUE;
	}

	return (IFX_TRUE == bShutProblem)?IFX_FAILURE:IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_AgentStatus
 *  Description     : This function is used to get FXS agent status.
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_AgentStatus(char* pszEndptId, x_IFX_AgentStatus* pxStatus)
{
	e_IFX_Return eRet = IFX_FAILURE;
#ifdef LTAM
	pxStatus->eState = IFX_AGENT_STATE_BUSY;
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo = 0;
		
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pszEndptId, "Extracting Agent Status" );
	
	if( IFX_SUCCESS != 
		IFX_FXS_GetEndpointInfo(pszEndptId, &pxEndptInfo) )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
			pszEndptId, "Invalid FXS Endpoint Id" );
	} else {
		if( IFX_FXS_STATE_IDLE == pxEndptInfo->eState )
			pxStatus->eState = IFX_AGENT_STATE_IDLE;
		eRet =IFX_SUCCESS;
	}
#endif
	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_CallIncoming
 *  Description     : This function is registered as callback function with CM.
 *                    This function is called when there is incoming call for 
 *                    FXS. If FXS endpoint is valid, then invokes FXS FSM with
 *                    incoming call event.
 *  Input Values    : Please refer pfnCallIncoming callback function for 
 *	                  parameter details
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - If FXS endpoint is valid.
 *                    IFX_FAILURE - If FXS endpoint is not found.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_CallIncoming(
	               IN uint32 uiCallId, 
	               IN x_IFX_CMGR_AddressInfo *pxFrom,
	               IN x_IFX_CMGR_AddressInfo *pxTo, 
	               IN x_IFX_CMGR_CallParams *pxCallParams, 
	               OUT e_IFX_CMGR_Status* peStatus,
	               OUT e_IFX_ReasonCode* peReason,
	               OUT void** ppvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo eventInfo;
	e_IFX_ReasonCode eReason ;
	e_IFX_Return eRet = IFX_FAILURE;
		
	if( IFX_SUCCESS != 
		IFX_FXS_GetEndpointInfo(pxTo->uxAddressInfo.szEndptId, &pxEndptInfo) )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
					 pxTo->uxAddressInfo.szEndptId, "Invalid FXS Endpoint Id" );
		return eRet;
	}
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Got A Incoming Call" );

	*peStatus = IFX_CMGR_STATUS_FAIL;
	*peReason = IFX_CIF_INVALID_ENDPOINT;
#ifdef DEV_DEBUG 
   /* Since already endpoint is found. Its not neccessary to check
      address type. However this can be used for debuging */
	if( IFX_CMGR_TYPE_EXTN != pxTo->eAddressType )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndPointId, "Invalid Address Type" );
		return eRet;
	}
#endif

	eventInfo.eEvent = IFX_FXS_EVT_IncomingCall;
	eventInfo.uiId = uiCallId;
	eventInfo.uxEventData.xIncCallEvent.pxCallParams = pxCallParams;
	eventInfo.uxEventData.xIncCallEvent.pxFrom = pxFrom;

	if( IFX_SUCCESS == 
		(eRet = IFX_FXS_FxsFsmHdlr(pxEndptInfo,&eventInfo,peReason)) )
	{
    if(*peReason == IFX_ABNORMAL_RELEASE){

		 *peStatus = IFX_CMGR_STATUS_FAIL;
    }else{
		 *peStatus = IFX_CMGR_STATUS_PENDING;
		 /* Don't care for failure. Default no wideband capability */
		 IFX_CIF_FxsWidebandCapablityCheck(pxEndptInfo->szEndPointId,
			&(pxCallParams->uxCallParams.xExtnParams.bWideBandCapable),&eReason);

		 *peReason = IFX_ENDPOINT_RINGING;
		 *ppvPrivateData = (void*)pxEndptInfo;
    }
	}
	else
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_LOW,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndPointId, "Call Rejected." );
		*peReason = IFX_ENDPOINT_BUSY;
		eRet = IFX_SUCCESS;
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_RemoteCallAccept
 *  Description     : This callback routine is called by call manager when peer
 *	                   party accepts the call. This routine invokes FXS FSM with
 *                    IFX_FXS_EVT_RmtAccept event.
 *  Input Values    : Please refer pfnRemoteCallAccept callback function for 
 *                    parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RemoteCallAccept(
	             IN uint32 uiCallId,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo eventInfo;
	e_IFX_ReasonCode eReason ;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Peer Accepted Call");

	eventInfo.eEvent = IFX_FXS_EVT_RmtAccept;
	eventInfo.uiId = uiCallId;

	if( IFX_SUCCESS != IFX_FXS_FxsFsmHdlr(pxEndptInfo,&eventInfo,&eReason) ) 
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndPointId, "Remote Answer Failed" );
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_RemoteCallAnswer 
 *  Description     : This callback function is called by CM to indicate peer
 *                    party ansered call. This routine calls FXS FSM with
 *                    IFX_FXS_EVT_RmtAnswer event. 
 *  Input Values    : Please refer pfnRemoteCallAnswer callback function for 
 *	                  parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RemoteCallAnswer(
	             IN uint32 uiCallId,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo eventInfo;
	e_IFX_ReasonCode eReason ;
	//e_IFX_Return eRet = IFX_FAILURE;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Peer Answered Call");	
	eventInfo.eEvent = IFX_FXS_EVT_RmtAnswer;
	eventInfo.uiId = uiCallId;

	if( IFX_SUCCESS != IFX_FXS_FxsFsmHdlr(pxEndptInfo,&eventInfo,&eReason) ) 
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Remote Call Answer Failed");
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_RemoteCallHold
 *  Description     : CM invokes this callback function to indicate peer 
 *                    requested to hold a call. If call can be held, then it 
 *                    informs CM to accept call hold request, else request will
 *                    be rejected.
 *  Input Values    : Please refer pfnRemoteCallHold callback function for 
 *	                  parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RemoteCallHold(
	             IN uint32 uiCallId,
	             OUT e_IFX_CMGR_Status* peStatus,
	             OUT e_IFX_ReasonCode* peReason,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_CallInfo* pxCallInfo = NULL;
	//e_IFX_Return eRet = IFX_FAILURE;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Peer Requested For Call Hold");
	
	IFX_FXS_GetCallInfo(pxEndptInfo,uiCallId,&pxCallInfo);
	*peStatus = IFX_CMGR_STATUS_FAIL;
	if( pxCallInfo )
	{
		/* CHECK: Do need to check call state here */
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Remote Call Hold SUCCESS");
		//eRet = IFX_SUCCESS;
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
	}
	else
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Remote Call Hold on wrong Call id");
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_RemoteCallResume
 *  Description     : This callback function is invoked by CM to inform that held
 *                    call is resumed by peer.
 *  Input Values    : Please refer pfnRemoteCallResume callback function for 
 *	                  parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RemoteCallResume(
	             IN uint32 uiCallId,
	             OUT e_IFX_CMGR_Status* peStatus,
	             OUT e_IFX_ReasonCode* peReason,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_CallInfo* pxCallInfo = NULL;
	//e_IFX_Return eRet = IFX_FAILURE;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Peer Is Resuming Call");
	
	IFX_FXS_GetCallInfo(pxEndptInfo,uiCallId,&pxCallInfo);
	*peStatus = IFX_CMGR_STATUS_FAIL;
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId," Remote Call Resume");
	if( pxCallInfo )
	{
		//CHECK: Do need to check call state here
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Remote Call Resume SUCCESS");
		//eRet = IFX_SUCCESS;
		*peStatus = IFX_CMGR_STATUS_SUCCESS;
	}
	else
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Remote Resume :: wrong Call id");
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_RemoteCallRelease
 *  Description     : This callback function is called by CM to inform agent the 
 *                    call is released by peer. This function invokes FXS FSM to
 *                    indicate remote call release event.
 *  Input Values    : Please refer pfnRemoteCallRelease callback function for 
 *	                  parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RemoteCallRelease(
	             IN uint32 uiCallId,
	             IN e_IFX_ReasonCode eReleaseReason,
	             IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo eventInfo; 
	e_IFX_ReasonCode eReason ;
	//e_IFX_Return eRet = IFX_FAILURE;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Call Is Released");

	eventInfo.eEvent = IFX_FXS_EVT_ReleaseCall;
	eventInfo.uiId = uiCallId;
	eventInfo.uxEventData.eReasonCode = eReleaseReason;

	if( IFX_SUCCESS != IFX_FXS_FxsFsmHdlr(pxEndptInfo,&eventInfo,&eReason) )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Remote Call Release FAILED");
	}
	else
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Remote Release SUCCESS");
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_DECT_CallForwardInfo
 *  Description     : This callback function is called by CM if call initiated
 *                    from this Agent is forwarded by peer. If call being 
 *                    forwarded is initiated by given FXS agent, then informs CM
 *                    to do call forwarding.
 *  Input Values    : Please refer pfnCallFwdInfo callback function for 
 *                    parameter details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : 
 ******************************************************************************/
e_IFX_Return IFX_FXS_CallForwardInfo(
	             IN uint32 uiCallId,
	             IN e_IFX_ReasonCode eReason, 			
	             IN x_IFX_CMGR_VoipAddr* pxFwdAddr,			
	             OUT boolean* pbFwdAllow,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_CallInfo* pxCallInfo = NULL;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
   *pbFwdAllow = IFX_FALSE;

	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId, "Call Is Being Forwarded");
	IFX_FXS_GetCallInfo(pxEndptInfo, uiCallId, &pxCallInfo);

	if( pxCallInfo )
      *pbFwdAllow = IFX_TRUE;

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_CallHoldResponse
 *  Description     : This callback function is called by CM to inform status of 
 *                    hold request (accepts/rejects). This routine invokes FXS 
 *                    FSM to inform call hold request status.
 *  Input Values    : Please refer pfnCallHoldRsp callback function for 
 *	                  parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_CallHoldResponse(
	             IN uint32 uiCallId,
	             IN e_IFX_CMGR_Status eStatus,
	             IN e_IFX_ReasonCode eReason, 
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo eventInfo; 
	//e_IFX_Return eRet = IFX_FAILURE;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;

	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId, "Call Hold response received");
	
	eventInfo.eEvent = IFX_FXS_EVT_HoldResp;
	eventInfo.uiId = uiCallId;
	eventInfo.uxEventData.eStatus = eStatus;

	if( IFX_SUCCESS != IFX_FXS_FxsFsmHdlr(pxEndptInfo,&eventInfo,&eReason) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Hold Response FAILED");
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_CallResumeResponse
 *  Description     : This callback function is called by CM to inform status 
 *                    of resume request (accepts/rejects). FXS FSM is invoked to 
 *                    indicate resume request status.
 *  Input Values    : Please refer pfnCallResumeRsp callback function for 
 *	                  parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_CallResumeResponse(
	             IN uint32 uiCallId,
	             IN e_IFX_CMGR_Status eStatus,
	             IN e_IFX_ReasonCode eReason, 
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo eventInfo; 
	//e_IFX_Return eRet = IFX_FAILURE;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;	
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId,"Resume Response received");
	
	eventInfo.eEvent = IFX_FXS_EVT_ResumeResp;
	eventInfo.uiId = uiCallId;
	eventInfo.uxEventData.eStatus = eStatus;

	if( IFX_SUCCESS != 
		(/*eRet = */IFX_FXS_FxsFsmHdlr(pxEndptInfo,&eventInfo,&eReason)) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Resume Response Failed");
	}

	return IFX_SUCCESS;//eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_ConfStatus
 *  Description     : This callback function is called by CM to indicate 
 *                    conference status. FXS FSM is called to iform conference 
 *                    status.
 *  Input Values    : Please refer pfnConfStatus callback function for 
 *                    parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConfStatus(
	             IN uint32 RequestId,
	             IN e_IFX_CMGR_Status eStatus,
	             IN e_IFX_ReasonCode eReason,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo eventInfo; 
	//e_IFX_Return eRet = IFX_FAILURE;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId,"Conference status received");
	
	eventInfo.eEvent = IFX_FXS_EVT_ConfStatus;
	eventInfo.uiId = RequestId;
	eventInfo.uxEventData.eStatus = eStatus;

	if( IFX_SUCCESS != 
		(/*eRet = */IFX_FXS_FxsFsmHdlr(pxEndptInfo,&eventInfo,&eReason)) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Conference Failed");
	}

	return IFX_SUCCESS; //eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_BlindTxRequest
 *  Description     : This callback function is called by CM when peer request 
 *	                  for blind transfer. If call is valid and can be transfered
 *	                  then function informs call manager to allow transfer. Other
 *	                  -wise transfer will be denied.
 *  Input Values    : Please refer pfnBlindTxReq callback function for 
 *	                  parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_BlindTxRequest(
	             IN uint32 uiCallId,
	             IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
	             OUT e_IFX_TransferStatus* peTransferStatus,
	             OUT e_IFX_ReasonCode *peRespCode,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId,"Peer Requested For Blind Transfer");
	
	*peTransferStatus = IFX_CMGR_TRANSFER_REJECTED;
	*peRespCode = IFX_TRANSFER_FAIL;

	if( IFX_FXS_STATE_CONVERSATION == pxEndptInfo->eState )
	{
		x_IFX_FXS_CallInfo* pxCallInfo = NULL;
		IFX_FXS_GetCallInfo(pxEndptInfo, uiCallId, &pxCallInfo);
		
		if( pxCallInfo && ( pxCallInfo->eCallState == IFX_FXS_CS_ACTIVE ) )
		{
			*peTransferStatus = IFX_CMGR_TRANSFER_ACCEPTED;
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Blind Tx Accepted");
		}
		else
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Blind Tx Rejected");
		}
	}
	else
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId, "Can Not Accept Blind Tx Request Now");
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_AttendedTxRequest
 *  Description     : This callback function is called by CM when peer requests 
 *                    for attended transfers. If call can be transfer, then 
 *                    allows CM to make attended transfer, else attended 
 *                    transfer will be rejected.
 *  Input Values    : Please refer pfnAttendedTxReq callback function for 
 *                    parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_AttendedTxRequest(
	             IN uint32 uiCallId,
	             IN uint32 uiReplacesCallId,
	             IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
	             OUT e_IFX_TransferStatus* peTransferStatus,
	             OUT e_IFX_ReasonCode *peRespCode,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_CallInfo* pxCallInfo = NULL;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Peer Requested For Attended Transfer");
	
	*peTransferStatus = IFX_CMGR_TRANSFER_REJECTED;
	*peRespCode = IFX_TRANSFER_FAIL ;
	
	if( IFX_FXS_STATE_CONVERSATION == pxEndptInfo->eState )
	{
		IFX_FXS_GetCallInfo(pxEndptInfo,uiCallId,&pxCallInfo);
		if( pxCallInfo && ( pxCallInfo->eCallState == IFX_FXS_CS_ACTIVE ) )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Attended Tx Accepted");
			*peTransferStatus = IFX_CMGR_TRANSFER_ACCEPTED;
		}
		else
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Blind Tx Rejected");
		}
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_BlindTxStatus
 *  Description     : This callback function is called by CM to indicate blind 
 *                    transfer status. Invokes FXS FSM to indicate blind 
 *                    transfer request status.
 *  Input Values    : Please refer pfnBlindTxStatus callback function for 
 *                   parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_BlindTxStatus(
	             IN uint32 uiCallId,
	             IN e_IFX_TransferStatus eBtxStatus, 
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData)
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo eventInfo;
	e_IFX_Return eRet;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId,"Blind Transfer Response Received");

	eventInfo.eEvent = IFX_FXS_EVT_BTxResp;
	eventInfo.uiId = uiCallId;
	eventInfo.uxEventData.eTxStatus = eBtxStatus;

	if( IFX_SUCCESS != 
		(eRet = IFX_FXS_FxsFsmHdlr(pxEndptInfo,&eventInfo,&eRespCode)) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Blind Transfer Failed");
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_AttendedTxStatus
 *  Description     : This callback function is called by CM to indicate 
 *                    attended transfer status. This function invoked FXS FSM to
 *                    inform the attended transfer status.
 *  Input Values    : Please refer pfnAttendedTxStatus callback function for 
 *                    parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_AttendedTxStatus(
	             IN uint32 uiCallId,
	             IN e_IFX_TransferStatus eTransferStatus, 
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo eventInfo;
	//e_IFX_Return eRet;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId, "Attended Transfer Response Received");
	
	eventInfo.eEvent = IFX_FXS_EVT_ATxResp;
	eventInfo.uiId = uiCallId;
	eventInfo.uxEventData.eTxStatus = eTransferStatus;

	if( IFX_SUCCESS != 
		(/*eRet = */IFX_FXS_FxsFsmHdlr(pxEndptInfo,&eventInfo,&eRespCode)) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Attended Tx Failed");
	}

	return IFX_SUCCESS; //eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_CallIdReplace
 *  Description     : This callback function is called by CM to replace call id.  
 *                    Search call info using old call id and then replace 
 *                    with new call id. 
 *  Input Values    : Please refer pfnCallIdRep callback function for 
 *                    parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : Since after invoking attended transfer, FXS agent releases
 *                    call, so return IFX_SUCCESS always. 
 ******************************************************************************/
e_IFX_Return IFX_FXS_CallIdReplace(
	               IN uint32 uiOldCallId,
	               IN uint32 uiNewCallId,
	               IN_OUT void** ppvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_CallInfo* pxTxCall;
	//e_IFX_Return eRet = IFX_FAILURE;
	
	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)(*ppvPrivateData);
/*	
	IFX_DBGC(vucFxsAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Request To Change CallId From Call Manager");
*/	
	IFX_FXS_GetCallInfo(pxEndptInfo, uiOldCallId, &pxTxCall);

	if( NULL == pxTxCall )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Invalid Call Id");
	}
	else
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Call Id Changed");
		pxTxCall->uiCallId = uiNewCallId;
		//eRet = IFX_SUCCESS;
	}

	return IFX_SUCCESS; //eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_AutoRedialStatus
 *  Description     : This is callback function called by CM to inform FXS agent
 *                    about auto redial status.
 *                    This event is expected only if user initiated auto redial 
 *                    request with a remote party. Only in dialing state auto 
 *                    redial request is initiated. If endpoint is not in dialing
 *                    state, then ignore this event. (may be something wrong, 
 *                    this should not happen). If uiRequestId is same as that of
 *                    endpoint's  uiAutoRedialOutReqId and subscription status 
 *                    is still in pending state, no progress, so return.
 *                    Otherwise if status is success, start confirmation tone, 
 *                    else start error tone and start respective timer.
 *                    Move to busy state. 
 *  Input Values    : Please refer pfnARD_Status callback function for 
 *	                  parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_AutoRedialStatus(
	             IN uint32 uiRequestId,
	             IN e_IFX_CMGR_Status eSubsStatus,
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData)
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	e_IFX_MMGR_ToneType eToneType = IFX_MMGR_ERROR_TONE;
	uint16 unTimeOut = IFX_ERROR_TONE_DURATION;
	e_IFX_Return eRet = IFX_FAILURE;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Auto Redial Status Received");
	
	if( IFX_FXS_STATE_DIALING != pxEndptInfo->eState )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Auto Redial Status Is Not Expected");
		return IFX_SUCCESS;
	}

	if( pxEndptInfo->uiAutoRedialOutReqId == uiRequestId && 
		IFX_CMGR_STATUS_PENDING != eSubsStatus)
	{
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,
											 IFX_FXS_AUTOREDIAL_INITIATED);

		if( IFX_CMGR_STATUS_SUCCESS == eSubsStatus )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Auto redial SUCCESS");
			
			IFX_FXS_SetEndpointFlag(pxEndptInfo,
											 IFX_FXS_AUTOREDIAL_ACTIVE_OUT);
			eToneType = IFX_MMGR_CONFIRMATION_TONE;
			unTimeOut = IFX_CONF_TONE_DURATION;
		} 
		else
		{
			IFX_DBGC(vucFxsAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Could Not Subscribe For Auto Redial");
			pxEndptInfo->uiAutoRedialOutReqId = 0;
		}

		eRet = IFX_FXS_StartTone(pxEndptInfo,
											eToneType,
											unTimeOut,
											IFX_FXS_EVT_BCEToneExpired,
											NULL,
											&pxEndptInfo->uiToneTimerId);

		IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_BUSY);
	}

	return /*IFX_SUCCESS*/eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_AutoRedialNotifyReceived
 *  Description     : This callback function is invoked by CM to inform the auto
 *                    redial notification sent by remote party.
 *                    This event is entertained only in idle state. In any other
 *                    state this event will be ignored. On receiving this event 
 *                    in the idle state, check if user requested for subscription. 
 *                    If not requested or user has canceled subscription ignore 
 *                    the event. Otherwise allocate signaling channel, start 
 *                    distinctive ring tone & tone timer. Set flag to indicate 
 *                    distictive ring tone is being played. Move to Ring state.
 *  Input Values    : Please refer pfnARD_NtfnRcv callback function for 
 *                    parameter details
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_AutoRedialNotifyReceived(
	             IN uint32 uiRequestId,
	             IN e_IFX_CMGR_Status eRemoteStatus, 
	             IN e_IFX_ReasonCode eRespCode,
	             IN void* pvPrivateData)
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	e_IFX_Return eRet = IFX_SUCCESS;

	pxEndptInfo = (x_IFX_FXS_EndptFsmInfo*)pvPrivateData;
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId, "Auto Redial Notify Received");

	if( IFX_CMGR_STATUS_PENDING == eRemoteStatus )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Auto Redial Status Is Pending");
		return eRet;
	}

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_OUT) &&
		pxEndptInfo->uiAutoRedialOutReqId == uiRequestId ) 
	{
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,
															IFX_FXS_AUTOREDIAL_ACTIVE_OUT);
		pxEndptInfo->uiAutoRedialOutReqId = 0;
		if( IFX_CMGR_STATUS_FAIL == eRemoteStatus )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Auto Redial Subscription Failed");
		}
		else if( IFX_CMGR_STATUS_SUCCESS == eRemoteStatus )
		{
			/* 
			 * Remote party is free. If endpoint is not in idle state ignore event.
			 * Else allocate signaling channel, start distictive ring tone and timer
			 * and move to ring state.
			 */
			if( IFX_FXS_STATE_IDLE != pxEndptInfo->eState )
			{

				if( IFX_FXS_STATE_BUSY == pxEndptInfo->eState )
				{
					IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId, 
						"Redial Will Be Initiated Once Phone Goes OffHook");
					IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ON_ONHOOK);
				}
				else
				{
					IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId, "Can Not Redial");
				}
			}
			else
				IFX_FXS_AutoRedial(pxEndptInfo);
		} /* Remote party is free */
	}
	else
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Auto redial is not active");
		eRet = IFX_FAILURE;
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_AutoRedialRegister
 *  Description     : This callback function is called by CM to register auto 
 *                    redial function requested by remote party.
 *                    New subscription -- if someone has already subscribed, 
 *                    don't accept this  subscription. Else accept it and if 
 *                    endpoint is in idle state, return status as success and 
 *                    let call manager know its in idle state. If endpoint is 
 *                    not in idle state, then save subscription information and 
 *                    set flag to indicate auto redial subscription & return 
 *                    status as success.
 *                    Existing subscription - If this is for cancelation, reset 
 *                    flag and clear subscription information and return success.
 *                    Otherwise ignore the event.
 *  Input Values    : Please refer pfnARD_Reg callback function for parameter 
 *                    details
 *  Output Values	  : 
 *  Return Value    : Always returns IFX_SUCCESS.
 *  Notes           : Only one Auto Redial Request is accepted for a endpoint.
 *                    If ARD request is pending, new requested will be rejected.
 *                    This event is entertained in all states. 
 ******************************************************************************/
e_IFX_Return IFX_FXS_AutoRedialRegister(
	             IN uint32 uiRequestId,
	             IN boolean bEnable,
	             IN char8* szEndpointId,
	             OUT e_IFX_CMGR_Status* peLocalStatus,
	             IN void** pvPrivateData )
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	e_IFX_Return eRet;

	*peLocalStatus = IFX_CMGR_STATUS_FAIL;

	if( IFX_SUCCESS != 
		(eRet= IFX_FXS_GetEndpointInfo(szEndpointId, &pxEndptInfo) ) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			szEndpointId, "Wrong FXS endpoint ID");
		return eRet;
	}
	
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Auto Redial Register Req Received");
	
	*pvPrivateData = (void*)(pxEndptInfo);
	if( bEnable )
	{
 /* commented by radvajesh, since when auto redial is switched off the callmanager is not calling this function and when new subscription arrives it always gets rejected. So the solution was to accept the latest auto redial request*/
#if 0
		/* Reject if already someone subscribed */
		if( pxEndptInfo->uiAutoRedialInReqId != 0 )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, 
				"Someone Has Subscribed, So Rejecting This Subscription");
			return eRet;
		}
#endif
		/* 
		 * New subscription -If endpoint is in idle state, return status as success
		 * and indicate that endpoit is ready to accept the call. Else store 
		 * request id and set IFX_FXS_AUTOREDIAL_ACTIVE_IN flag.
		 */
		if( IFX_FXS_STATE_IDLE == pxEndptInfo->eState )
		{
			*peLocalStatus = IFX_CMGR_STATUS_SUCCESS;
			IFX_DBGA(vucFxsAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, 
				"This Endpoint In Idle State. Auto Redial Status = SUCCESS");
		}
		else
		{
			IFX_DBGA(vucFxsAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, 
				"This Endpoint In Busy. Auto Redial Status==PENDING");
			pxEndptInfo->uiAutoRedialInReqId = uiRequestId;
			IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN);
			*peLocalStatus = IFX_CMGR_STATUS_PENDING;
		}
	}
	else
	{
		/*
		 * If request id is is same as that of endpoint's uiAutoRedialInReqId, 
		 * reset IFX_FXS_AUTOREDIAL_ACTIVE_IN and uiAutoRedialInReqId.
		 * Return failure if request id does not match
		 */
		if( pxEndptInfo->uiAutoRedialInReqId == uiRequestId )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Remote Party CANCELED Auto Redial");
			pxEndptInfo->uiAutoRedialInReqId = 0 ;
			IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN);
			*peLocalStatus = IFX_CMGR_STATUS_SUCCESS;
		} 
		else
		{
			/* Request id mismatch. Return failure */
			IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Request ID MISMATCH");
			eRet = IFX_FAILURE;
		}
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_MakeFXSIdle
 *  Description     : This function makes FXS endpoint idle by terminating all
 *                    activities (including timers, tones and any pending 
 *                    responses). After calling this function, FXS endpoint is 
 *                    ready to receive new calls.
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : Call this function only when phone is on-hook. 
 ******************************************************************************/
e_IFX_Return IFX_FXS_MakeFXSIdle(
	                IN x_IFX_FXS_EndptFsmInfo *pxEndptInfo,
	                OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxCallInfo; 
	uchar8 ucCount = 0;
	e_IFX_Return eRet = IFX_SUCCESS;

	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Making FXS Idle");

	/* Stop all tone and timers */
	if( pxEndptInfo->uiToneTimerId )
		IFX_FXS_StopTone(pxEndptInfo,&pxEndptInfo->uiToneTimerId);

	if( pxEndptInfo->uiIntrDgtTimerId )
		IFX_TIM_TimerStop(pxEndptInfo->uiIntrDgtTimerId);

	pxCallInfo = pxEndptInfo->axFxsCallInfo;

	while( ucCount < IFX_MAX_FXS_CALLS)
	{
		if( pxCallInfo->eCallState != IFX_FXS_CS_NONE )
		{
			IFX_CMGR_CallRelease(pxCallInfo->uiCallId, IFX_TERMINATED, NULL,
					NULL, peReason);
			IFX_FXS_ReleaseCall(pxEndptInfo,pxCallInfo);
		}
		++ucCount;
		++pxCallInfo;
	}

	/* Now release signaling channel */
	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_SIG_RESOURCE_ALLOCATGED) )
	{
		if( IFX_MMGR_SUCCESS != IFX_MMGR_SigResDealloc(pxEndptInfo->szEndPointId))
		{
			/* Could not de-allocate signaling resource !! */
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId,"Could Not Release Signaling Resouce");
			eRet = IFX_FAILURE;
		}
		IFX_MMGR_SetFxsToStandBy(pxEndptInfo->szEndPointId);
	}
#if 0
	else
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"No Sig Resource Allocated Channel");
	}
#endif

	/*
	 * Reset all flags, except those that can be used in idle state too. Set last
	 * active call to NULL. Clear collected digits if exist. 
	 */
	pxEndptInfo->uiFlags &= (IFX_FXS_IDLE_STATE_FLAGS);
	pxEndptInfo->pxActiveCall = NULL;
	pxEndptInfo->uiConfReqId = pxEndptInfo->uiToneTimerId = 
		pxEndptInfo->uiIntrDgtTimerId = 0;
	pxEndptInfo->szDialledDigits[0]='\0';
	
	/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "FXS Endpoint Idle"); */
	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_FxsFsmHdlr
 *  Description     : This function is entry for FXS FSM.
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - If event is processed
 *                    IFX_FAILURE - If event is not processed or event is not 
 *                      expected or encountered error while processing event.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_FxsFsmHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo *pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	pfn_IFX_FXS_Fsm pfnFsmHandler = 0;
	e_IFX_Return eRet = IFX_FAILURE;

	if( pxEvtInfo->eEvent > IFX_FXS_EventMax )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Unknown event");
		return eRet;
	}

	IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
					 pxEndptInfo->szEndPointId );	
	IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			IFX_FXS_GetStateStr(pxEndptInfo->eState), IFX_FXS_GetEventStr(pxEvtInfo->eEvent));

  IFX_FXS_GetEventStr(pxEvtInfo->eEvent);
	
	pfnFsmHandler = vax_IFX_FXSFsm[pxEndptInfo->eState][pxEvtInfo->eEvent];

	eRet = (pfnFsmHandler)(pxEndptInfo,pxEvtInfo,peReason);
	return eRet;
}

/*---------------------- FXS FSM Handler Routines ----------------------------*/
/*******************************************************************************
 *  Function Name   : IFX_FXS_IgnoreHdlr
 *  Description     : This routine is used to ignore any FXS event. It is used 
 *                    in all states.
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_FAILURE
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_IgnoreHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId, "Ignoring Event");
	return IFX_FAILURE;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_IgnoreCallHdlr
 *  Description     : This routine is used to ignore any FXS event. It is used 
 *                    in all states.
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_FAILURE
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_IgnoreCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId, "Ignoring Call");
  *peReason = IFX_ABNORMAL_RELEASE;
	return IFX_SUCCESS;
}
/*******************************************************************************
 *  Function Name   : IFX_FXS_IdleOffHookHdlr
 *  Description     : This routine handles off-Hook event in idle state. 
 *                    Allocate signaling resource. Start dial/registered/stutter
 *                    tone depending on default line of the endpoint registration 
 *                    & voice mail status and start tone timer. 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - If channel is allocated(user can make calls)
 *                    IFX_FAILURE - If fails to allocate sig channel.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_IdleOffHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_MMGR_ToneType eToneType;
	uint16 unTimeOut;
	e_IFX_Return eRet = IFX_FAILURE;

	*peReason = IFX_NO_RESOURCE;
#ifdef MEM_DBG
	IFX_OS_MemInfo();
#endif
	if( IFX_MMGR_SUCCESS != 
		IFX_MMGR_SigResAlloc(pxEndptInfo->szEndPointId,NULL ) )
	{
		IFX_DBGC(vucFxsAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Could Not Allocate Signaling Resource");
	}
	else
	{
		IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_SIG_RESOURCE_ALLOCATGED);
		IFX_MMGR_SetFxsToActive(pxEndptInfo->szEndPointId); //Activate FXS
		eToneType = IFX_FXS_GetDialToneType(pxEndptInfo->szEndPointId,&unTimeOut);

		IFX_FXS_StartTone(pxEndptInfo, eToneType, unTimeOut,
							( (eToneType == IFX_MMGR_STUTTER_DIAL_TONE)? 
								IFX_FXS_EVT_StutterToneExpired: IFX_FXS_EVT_DialToneExpired ),
						  NULL, &pxEndptInfo->uiToneTimerId);

		IFX_FXS_UpdateEndpointState(pxEndptInfo, IFX_FXS_STATE_DIALING);
		IFX_DBGC(vucFxsAgnetModId, IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Waiting For Digits.....");
	}
	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_IdleIncomingCallHdlr
 *  Description     : This routine handles incoming call event in IDLE state.
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : IFX_SUCCESS - If call is accepted.
 *                    IFX_FAILURE - If call is rejected. peReason contains valid
 *                        reason code.
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_IdleIncomingCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo,
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_MMGR_CidParams xCidParams = {0};
	x_IFX_FXS_IncCallEvent* pxInCallEvnt;
	int32  iRingTimeOut = IFX_RING_TONE_DURATION;
	//boolean bBlocked = IFX_FALSE;
	e_IFX_Return eRet = IFX_FAILURE;

	*peReason = IFX_NO_RESOURCE;

	/* If caller's number is in block list, reject the call */
	pxInCallEvnt = &(pxEvtInfo->uxEventData.xIncCallEvent);
	IFX_AGU_GetCallerIdInfo(pxInCallEvnt->pxFrom, 
									xCidParams.szCallerName, xCidParams.szCallerNumber);
	xCidParams.eTxType = IFX_MMGR_ONHOOK;

/*	eRet = IFX_CIF_IncomingCallBlockCheck(pxEndptInfo->szEndPointId,
						xCidParams.szCallerNumber, &bBlocked, peReason); 
	if(IFX_SUCCESS != eRet || bBlocked )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					 pxEndptInfo->szEndPointId, "This Incoming Call Is Blocked" );
		return IFX_FAILURE;
	}
*/
	if( IFX_MMGR_SUCCESS != 
		IFX_MMGR_SigResAlloc(pxEndptInfo->szEndPointId,NULL ) )
	{
		IFX_DBGC(vucFxsAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Could Not Allocate Signaling Resource");
		eRet = IFX_FAILURE;
	}
	else
	{
		IFX_MMGR_SetFxsToActive(pxEndptInfo->szEndPointId); //Activate FXS 
		IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_SIG_RESOURCE_ALLOCATGED);

		if( pxInCallEvnt->pxCallParams->uxCallParams.xExtnParams.cRingCount ) {
			IFX_MMGR_RingCadenceTimeGet(&iRingTimeOut);
			iRingTimeOut *= 
				pxInCallEvnt->pxCallParams->uxCallParams.xExtnParams.cRingCount;
		IFX_DBGC(vucFxsAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Ring Time out is specified in InCallEvent");

		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
			"Received time is", iRingTimeOut);
				
		} 
		eRet = IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_RING_TONE, iRingTimeOut, 
				IFX_FXS_EVT_RingToneExpired, &xCidParams, &pxEndptInfo->uiToneTimerId);
	
		if( IFX_SUCCESS == eRet )
		{
			/* Initiate call parameter */
			pxEndptInfo->pxActiveCall = (pxEndptInfo->axFxsCallInfo+0);
			pxEndptInfo->pxActiveCall->uiCallId = pxEvtInfo->uiId;
			pxEndptInfo->pxActiveCall->eCallType = pxInCallEvnt->pxFrom->eAddressType;

			if( IFX_CMGR_TYPE_FXO == pxEndptInfo->pxActiveCall->eCallType )
			{
				strcpy(pxEndptInfo->pxActiveCall->szCallInitrEndptId, 
									pxInCallEvnt->pxFrom->uxAddressInfo.xFxoInfo.szFxoLineId );
			}

			IFX_FXS_UpdateCallState(pxEndptInfo, 
											pxEndptInfo->pxActiveCall, IFX_FXS_CS_RINGING );
			IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_RINGING );
		}
		else
		{
			IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_SIG_RESOURCE_ALLOCATGED);
			//IFX_MMGR_SetFxsToStandBy(pxEndptInfo->szEndPointId); //stand by mode
			IFX_MMGR_SigResDealloc(pxEndptInfo->szEndPointId);
		}
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_DialingOnHookHdlr
 *  Description     : This function handles On-Hook event in dialing state. Make
 *                    endpoint idle. If IFX_FXS_AUTOREDIAL_ACTIVE_IN flag is on, 
 *                    send notification to remote * party. Move to idle state
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{

	if( IFX_SUCCESS != IFX_FXS_MakeFXSIdle(pxEndptInfo,peReason) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "IFX_FXS_MakeFXSIdle FAILED");
	}

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN) &&
			IFX_SUCCESS != IFX_FXS_SendAutoRedialNtfy(pxEndptInfo,IFX_TRUE) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Could Not Send Auto Redial Notify");
	}

	/* Move to idle state */
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_IDLE);
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_DialingHookFlashHdlr
 *  Description     : This function is used for hook flash event handler in 
 *                    DIALING state. If there are no held call ignore this event. 
 *                    Check if any of the following flags are set -
 *                    IFX_FXS_RESUME_INITIATED,IFX_FXS_CONFERENCE_INITIATED, 
 *                    IFX_FXS_TRANSFER_INITIATED  or IFX_FXS_EMG_CALL_PROCEEDING.
 *                    If set, ignore this event. Otherwise do following -
 *                    New call was initiated, disconnect it and turn off 
 *                      IFX_FXS_CALL_INITIATED and play dial tone. 
 *                    Else Stop tone and interdigit timer if running. Clear all 
 *                      collected digits. Start dial tone & dial timer.
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           : New Requirement - In dialing state there was no option to 
 *                    terminate initiated call and also to resume held call 
 *                    (user needed to wait till time out to resume held call).
 *                    So it user does hook-flash initiated call shoul be 
 *                    terminated. If there is no call initiated, held call 
 *                    should be resumed.
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingHookFlashHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	uchar8 ucHeldCalls;
	e_IFX_Return eRet = IFX_SUCCESS;

	ucHeldCalls = IFX_FXS_GetHeldCallsCount(pxEndptInfo);

	/* Ignore the event if there are no held calls */
	if( ucHeldCalls && 
		!(IFX_FXS_CheckEndpointFlag(pxEndptInfo,
			(IFX_FXS_EMG_CALL_PROCEEDING | IFX_FXS_RESUME_INITIATED | 
			 IFX_FXS_CONFERENCE_INITIATED | IFX_FXS_TRANSFER_INITIATED ) )) )
	{
		uint16 unTimeOut;
		e_IFX_MMGR_ToneType eToneType; 
		/*
		 * If call is initiated, release the call. Clear all collected digits.
		 * Start dial tone and timer.
		 */
		if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_CALL_INITIATED) )
		{
			IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, IFX_TERMINATED,
				NULL, NULL, peReason);
			IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);

			eToneType = IFX_FXS_GetDialToneType(pxEndptInfo->szEndPointId,&unTimeOut);
			/* Don't play stutter tone now */
			eToneType = ( IFX_MMGR_STUTTER_DIAL_TONE == eToneType)
																						?IFX_FXS_REG_DIAL_TONE:eToneType;

			/* eRet =*/ IFX_FXS_StartTone(pxEndptInfo, eToneType,
								vunDialToneLength, IFX_FXS_EVT_DialToneExpired, NULL,
								&pxEndptInfo->uiToneTimerId);
		} 
		else 
		{
			e_IFX_CMGR_Status eStatus = IFX_CMGR_STATUS_FAIL;

			if( pxEndptInfo->uiToneTimerId )
				IFX_FXS_StopTone(pxEndptInfo, &pxEndptInfo->uiToneTimerId);

			if( pxEndptInfo->uiIntrDgtTimerId )
			{
				IFX_TIM_TimerStop(pxEndptInfo->uiIntrDgtTimerId);
				pxEndptInfo->uiIntrDgtTimerId = 0;
			}
			eRet = IFX_CMGR_CallResume(pxEndptInfo->pxActiveCall->uiCallId, 
					&eStatus, peReason );
			if( IFX_SUCCESS == eRet && IFX_CMGR_STATUS_FAIL != eStatus)
			{
				if( IFX_CMGR_STATUS_SUCCESS == eStatus )
				{
					IFX_FXS_UpdateCallState(pxEndptInfo, 
							pxEndptInfo->pxActiveCall,IFX_FXS_CS_ACTIVE);
					IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_CONVERSATION);
				}
				else if( IFX_CMGR_STATUS_PENDING == eStatus )
				{
					IFX_FXS_UpdateCallState(pxEndptInfo,
							pxEndptInfo->pxActiveCall,IFX_FXS_CS_RESUME_INITIATED);
					IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_RESUME_INITIATED );
				}
			}
			else
			{
				IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId, "Could Not Resume Call");
			}
		}

		pxEndptInfo->szDialledDigits[0] = '\0';
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_DialingDigitPressedHdlr
 *  Description     : This function is used in DIALING state to handle digit 
 *                    pressed event.
 *
 *                    Ignore the event if any of the following flags are tunred 
 *                    on - call initiated, resume initiated, transfer initiated,
 *                    auto redial initiated, conference nitiated or conference 
 *                    break initiated flags.
 *
 *                    If dial tone is being played, stop tone & timer. If 
 *                    interdigit timer exist, stop the timer. Append new digits 
 *                    pressed by user to endpoint's szDialledDigits. Invoke
 *                    IFX_DP_Match function to know whether any numbering rule 
 *                    is matched. In this function only start inter digit small 
 *                    or large timer action retunred form IFX_DP_Match are valid
 *                    If action is to start interdigit timer, start timer and 
 *                    stay in DIALING state. For any other actions start error 
 *                    tone & timer, clear all collected digits & move to BUSY 
 *                    state. 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingDigitPressedHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_DigitPressedEvent* pxDpEvent;
	x_IFX_FXS_TimerEvent xTimerEvent;
	x_IFX_DP_Rule xDpRule;
	char8  szDialOut[IFX_MAX_DIGITS];
	e_IFX_Return eRet = IFX_FAILURE;
	uint16 unTimeOut = 0;
	uint16 unLen;
	uchar8 ucDpAction = 0;

	/* If call/transfer/auto redil/resume initiated, ignore this event. */
	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo, (IFX_FXS_CALL_INITIATED | 
		IFX_FXS_RESUME_INITIATED | IFX_FXS_TRANSFER_INITIATED | 
		IFX_FXS_AUTOREDIAL_INITIATED | IFX_FXS_CONFERENCE_INITIATED |
		IFX_FXS_BREAK_CONFERENCE_INITIATED)) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Can not process Digit Event " );
		return IFX_SUCCESS; //eRet;
	}

	if( pxEndptInfo->uiToneTimerId )
	{
		IFX_FXS_StopTone(pxEndptInfo,&pxEndptInfo->uiToneTimerId);
	}
	else if( pxEndptInfo->uiIntrDgtTimerId )
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiIntrDgtTimerId);
		pxEndptInfo->uiIntrDgtTimerId = 0;
	}

	pxDpEvent = &(pxEvtInfo->uxEventData.xDgtEvent);
	unLen = strlen(pxEndptInfo->szDialledDigits);
	if (unLen+pxDpEvent->ucNumDgts < (2*IFX_MAX_DIGITS)){
		strncpy(pxEndptInfo->szDialledDigits+unLen,
						(char8 *)pxDpEvent->aucDgtInfo,pxDpEvent->ucNumDgts);
		pxEndptInfo->szDialledDigits[unLen+pxDpEvent->ucNumDgts] = '\0';
	}else{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
      pxEndptInfo->szEndPointId, "szDialledDigits buffer is not sufficient " );
			return IFX_SUCCESS;
	}

	eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits,
						IFX_FALSE, &ucDpAction, szDialOut, &xDpRule, &unTimeOut );
	/* 
	 * In this handler, only small/large actions are relevant. For other action
	 * play error tone and start tone timer
	 */
	if( IFX_SUCCESS == eRet && (IFX_DP_ST_SMALL_TIM == ucDpAction || 
							 IFX_DP_ST_LARGE_TIM == ucDpAction) )
	{
		xTimerEvent.eTimerEvent = IFX_FXS_EVT_InterDgtTimerExp;
		xTimerEvent.pxEndptInfo = pxEndptInfo;

		IFX_TIM_TimerStart(unTimeOut,&xTimerEvent,
				sizeof(xTimerEvent), IFX_FXS_TimerFired,&pxEndptInfo->uiIntrDgtTimerId);
	} 
	else
	{
		/* Dial plan error */
		IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_ERROR_TONE,
							IFX_ERROR_TONE_DURATION, IFX_FXS_EVT_BCEToneExpired, NULL,
							&pxEndptInfo->uiToneTimerId);
		IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_BUSY);
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_DialingInterDigitExpiryHdlr
 *  Description     : This function hanldes interdigit timer expiry event in 
 *                    DIALING state.
 *
 *                    Verify that timer id is same as that of interdigit timer. 
 *                    If does not match ignore this event.
 *                    Invoke IFX_DP_Match with so far collected digits. If this 
 *                    API returns failure or action retunred is not 
 *                    IFX_DP_DIALOUT, play error tone & start error tone timer 
 *                    & move to busy state. If action is IFX_DP_DIALOUT invoke 
 *                    IFX_FXS_ExecuteDialPlanAction (this executes dial plan 
 *                    action). If this routine returns failure play error tone
 *                    start error tone timer and move to busy state. Otherwise 
 *                    this routine retunrs tone to be played out and entpoint 
 *                    state. (For more detail see IFX_FXS_ExecuteDialPlanAction)
 *                    If tone is valid play tone and start timer. If endpoint 
 *                    state is valid move to that state.
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingInterDigitExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	/* if timer id did not match, ignore the event */
	if( pxEvtInfo->uiId != pxEndptInfo->uiIntrDgtTimerId )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Invalid Timer Id");
		return IFX_SUCCESS; //eRet;
	}
	pxEndptInfo->uiIntrDgtTimerId = 0 ;

	return IFX_FXS_ProcessDialPlan(pxEndptInfo,pxEvtInfo,peReason);
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_DialingDialToneExpiryHdlr
 *  Description     : This function handles Dial tone expiry event in DIALING 
 *                    state. If timer id is not valid ignore the event. Else 
 *                    stop dial tone, start error tone & its timer and 
 *                    move to BUSY state.
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingDialToneExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	//e_IFX_Return eRet = IFX_FAILURE;

	/* if timer id did not match, ignore the event */
	if( pxEvtInfo->uiId != pxEndptInfo->uiToneTimerId )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Wrong Timer Id");
	} 
	else
	{
		IFX_FXS_StopTone(pxEndptInfo,NULL);
		pxEndptInfo->uiToneTimerId = 0;

#ifdef DELAYED_HOTLINE
		boolean bDhlEnable = IFX_FALSE;
		char8 acDhlNumber[IFX_MAX_DIGITS];
		
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
             pxEndptInfo->szEndPointId, "Checking for Delayed Hotline configuration");

		if (IFX_SUCCESS != IFX_CIF_EndptDhlInfoGet(pxEndptInfo->szEndPointId,
                                              &bDhlEnable,acDhlNumber,peReason)){
			bDhlEnable = IFX_FALSE;
		}
			
		if (bDhlEnable == IFX_TRUE){
			strcpy(pxEndptInfo->szDialledDigits,acDhlNumber);
			IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndPointId, "Dialing Delayed Hotline number");
			IFX_FXS_ProcessDialPlan(pxEndptInfo,pxEvtInfo,peReason);

		}else
#endif
		{
			/*eRet = */ IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_ERROR_TONE, 
										IFX_ERROR_TONE_DURATION, IFX_FXS_EVT_BCEToneExpired,
										NULL, &pxEndptInfo->uiToneTimerId);
				IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_BUSY);
		}
	}
	return IFX_SUCCESS;
}

/*
 * This routine handles Stutter tone expiry event in dialing state
 * If timer id does not match with, ignore the handler. Else stop stutter tone
 * start dial tone and its timer. There is no change in endpoint state
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingStutterToneExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	/* if timer id did not match, ignore the event */
	if( pxEvtInfo->uiId != pxEndptInfo->uiToneTimerId )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Wrong Timer Id");
		return IFX_FAILURE;
	}

	IFX_FXS_StopTone(pxEndptInfo,NULL);

	IFX_FXS_StartTone(pxEndptInfo, IFX_FXS_REG_DIAL_TONE,
						vunDialToneLength, IFX_FXS_EVT_DialToneExpired, NULL,
						&pxEndptInfo->uiToneTimerId );
	return IFX_SUCCESS;
}

/*
 * This routine handles release call event in dialing and ringback states.
 *
 * Active call - If transfer was initiated on this call, release call and 
 * remain in this state (expecting BTX response). If call is in held state, 
 * release call and remain in this state. 
 * If call is initiated, depending on release reason start busy/error tone and
 * tone timer, turnoff IFX_FXS_CALL_INITIATED and move to busy state. If call 
 * is in resume state, start error tone & tone timer and turnoff 
 * IFX_FXS_RESUME_INITIATED & move to busy. In all above cases, if there is a 
 * held call, that call will be considered as active call.
 *
 * Non Active Call - Release call and don't change the state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialAndRingbackReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxRelCall;
	e_IFX_MMGR_ToneType eToneType = IFX_MMGR_MAX_TONE;
	uint16 unTimeOut = 0;
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_FXS_GetCallInfo(pxEndptInfo,pxEvtInfo->uiId,&pxRelCall);
	
	if( NULL == pxRelCall )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Invalid Call id");
		return eRet;
	}

	if( pxRelCall == pxEndptInfo->pxActiveCall )
	{
		/*
		 * If call is intiated, play busy tone if other end is busy otherwise play
		 * error tone.
		 */
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Active Call Released");
		
		eToneType = IFX_MMGR_ERROR_TONE;
		unTimeOut = IFX_ERROR_TONE_DURATION;

		switch(pxRelCall->eCallState)
		{
			case IFX_FXS_CS_CALL_INITIATED:
			case IFX_FXS_CS_RINGING:
			case IFX_FXS_CS_RESUME_INITIATED:
				{

					/* Reseting flags is needed in dialing state */
					IFX_FXS_ResetEndpointFlag(pxEndptInfo,
									(IFX_FXS_CALL_INITIATED|IFX_FXS_RESUME_INITIATED) );

					if( IFX_ENDPOINT_BUSY == pxEvtInfo->uxEventData.eReasonCode )
					{
						eToneType = IFX_MMGR_BUSY_TONE;
						unTimeOut = IFX_BUSY_TONE_DURATION;
					}
					break;
				}
			case IFX_FXS_CS_HOLD_INITIATED:
			case IFX_FXS_CS_TX_INITIATED:
				{
				 /* 
					* In this case, FXS Agent gets hold/Tx status. Play confirmation/error tone
					* after receiving hold status
					*/	
					/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId, "Hold/BlindTx Initiated Call Released"); */
					eToneType = IFX_MMGR_MAX_TONE;
					break;
				} 
			case IFX_FXS_CS_LOCAL_HELD:
			{
				eToneType = IFX_MMGR_MAX_TONE;
				break;
			}
			default:
			{
				/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId," Simply Release Call"); */
				;
			}
		}

		IFX_FXS_ReleaseCall(pxEndptInfo,pxRelCall);
		IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);
	} 
	else
	{
		/* Call is not active, it must be in held state */
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Held Call Release");
		IFX_FXS_ReleaseCall(pxEndptInfo,pxRelCall);
	}

	if( IFX_MMGR_MAX_TONE != eToneType )
	{
		/* Start tone & move to busy state */
		eRet = IFX_FXS_StartTone(pxEndptInfo, eToneType, unTimeOut,
							IFX_FXS_EVT_BCEToneExpired, NULL, &pxEndptInfo->uiToneTimerId );
		IFX_FXS_UpdateEndpointState(pxEndptInfo, IFX_FXS_STATE_BUSY);
	}

	return IFX_SUCCESS;
}

/*
 * This routine handles remote call accept event in dialing state.
 * Verify call id. If valid and call is in initiate state, start ringback tone,
 * & tone timer, turnoff IFX_FXS_CALL_INITIATED, update call state to rining &
 * move to ringback state. Otherwise ignore event and return failure.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingRmtAcceptHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxActiveCall;
	
	pxActiveCall = pxEndptInfo->pxActiveCall ;

	if( pxEvtInfo->uiId != pxActiveCall->uiCallId || 
		  IFX_FXS_CS_CALL_INITIATED != pxActiveCall->eCallState )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"FAILED: Wrong Call or Event Is Not Expected");
		return IFX_FAILURE;
	}

	IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_RING_BACK_TONE,
						IFX_RINGBACK_TONE_DURATION, IFX_FXS_EVT_RingBackToneExpired, NULL,
						&pxEndptInfo->uiToneTimerId );
	IFX_FXS_UpdateCallState(pxEndptInfo,pxActiveCall,IFX_FXS_CS_RINGING);
	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_INITIATED);
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_RINGBACK);

	return IFX_SUCCESS;
}

/*
 * This routine handles remote answer event in dialing & ringback states.
 * If call id of answered call is not equal to endpoint active call's call id
 * or if call has already been answered ignore event and return failure. 
 * Else Remote party has answered the call, update call state to active and  
 * move to conversation state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
******************************************************************************/
e_IFX_Return IFX_FXS_RemoteAnswerHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxActiveCall;
	//e_IFX_Return  eRet = IFX_FAILURE;
	
	pxActiveCall = pxEndptInfo->pxActiveCall ;

	if( pxEvtInfo->uiId != pxActiveCall->uiCallId || 
		  ( IFX_FXS_CS_CALL_INITIATED != pxActiveCall->eCallState && 
			  IFX_FXS_CS_RINGING != pxActiveCall->eCallState)  )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"FAILED : Remote Answer On Wrong Call");
		return IFX_FAILURE;
	}

	/*
	 * If tone is started, stop tone and timer. This is possible only in ringback
	 * state.
	 */
	if( pxEndptInfo->uiToneTimerId )
	{
		IFX_FXS_StopTone(pxEndptInfo, &pxEndptInfo->uiToneTimerId);
	}

	IFX_FXS_UpdateCallState(pxEndptInfo,pxActiveCall,IFX_FXS_CS_ACTIVE);
	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_INITIATED);
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_CONVERSATION);

	return IFX_SUCCESS;
}

/*
 * This routine handles resume response event in dialing state.
 * This event is ignored if resume was not initaited on active call. If resume
 * was initiated on active call and call resume is success, update call state
 * to active and move to conversation state. If resume fails, start dial tone
 * & timer and don't change the endpoint state.
 * (Note that resume status pending is not expected in this event)
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingResumeRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxActiveCall;

	pxActiveCall = pxEndptInfo->pxActiveCall ;

	if( pxActiveCall->uiCallId != pxEvtInfo->uiId || 
		  IFX_FXS_CS_RESUME_INITIATED != pxActiveCall->eCallState )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"FAILED : Resume On Wrong Call");
		return IFX_FAILURE;
	}

	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_RESUME_INITIATED);

	if( IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus )
	{
		IFX_FXS_UpdateCallState(pxEndptInfo,pxActiveCall,IFX_FXS_CS_ACTIVE);
		IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_CONVERSATION);
	}
	else
	{
		IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_DIAL_TONE, vunDialToneLength,
			IFX_FXS_EVT_DialToneExpired, NULL, &pxEndptInfo->uiToneTimerId );
	}

	return IFX_SUCCESS;
}

/*
 * This routine handles conference status event in dialing state.
 * 
 * If conference was not initiated, ignore this event and return failure. Else 
 * reset IFX_FXS_CONFERENCE_INITIATED flag. If conference is success, update 
 * all call states to active and move to conference state. If failed, start 
 * error tone and timer, move to busy state. 
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingConferenceStatusHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{

	if( !(IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_CONFERENCE_INITIATED)) )
	{
		IFX_DBGA(vucFxsAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Conference not initiated");
		return IFX_FAILURE;
	}

	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CONFERENCE_INITIATED);

	if( IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Conference success");
		IFX_FXS_UpdateCallState(pxEndptInfo,
														(pxEndptInfo->axFxsCallInfo+0),IFX_FXS_CS_ACTIVE);
		IFX_FXS_UpdateCallState(pxEndptInfo,
														(pxEndptInfo->axFxsCallInfo+1),IFX_FXS_CS_ACTIVE);
		IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_CONFERENCE);
	}
	else
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Conference Failed");
		IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_ERROR_TONE,
			IFX_ERROR_TONE_DURATION, IFX_FXS_EVT_BCEToneExpired, NULL,
			&pxEndptInfo->uiToneTimerId );
		IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_BUSY);
	}
	
	return IFX_SUCCESS;
}

/*
 * This routine handles BTX response in dialing state.
 *
 * If blind transfer was not initiated, ignore the event and return failure.
 * Turnoff IFX_FXS_TRANSFER_INITIATED flag. If success, start confirmation
 * tone & timer. If transfer failed, play error tone and start tone timer.
 * In either case move to busy state.
 * Before blind transfer response, transfered call could have been released.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DialingBtxRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	/* x_IFX_FXS_CallInfo* pxBtxCall; */
	e_IFX_MMGR_ToneType eTone = IFX_MMGR_ERROR_TONE;
	uint16 unToneDur = IFX_ERROR_TONE_DURATION;

	if( !(IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_TRANSFER_INITIATED)) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Blind Transfer Not Initiated");
		return IFX_FAILURE;
	}

	if( IFX_CMGR_TRANSFER_ACCEPTED == pxEvtInfo->uxEventData.eTxStatus ||
			IFX_CMGR_TRANSFER_PENDING == pxEvtInfo->uxEventData.eTxStatus ||
			IFX_CMGR_TRANSFER_PROCEEDING == pxEvtInfo->uxEventData.eTxStatus || 
			IFX_CMGR_TRANSFER_RINGING == pxEvtInfo->uxEventData.eTxStatus  )
	{
		/* Transfer is still going on */
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Blind Transfer Is In Progress");
		return IFX_SUCCESS;
	}
	else if( IFX_CMGR_TRANSFER_ANSWERED == pxEvtInfo->uxEventData.eTxStatus )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Blind Transfer SUCCESS");
		eTone = IFX_MMGR_CONFIRMATION_TONE;
		unToneDur = IFX_CONF_TONE_DURATION;
#if 0 /* This code is not needed...b'coz call manager release call before 
			 * sending Btx success status
			 */
		/* Release transfered call, if still exist */
		IFX_FXS_GetCallInfo(pxEndptInfo,pxEvtInfo->uiId,&pxBtxCall);
		if( pxBtxCall )
		{
			IFX_CMGR_CallRelease(pxBtxCall->uiCallId,IFX_TERMINATED,
													 NULL,NULL,peReason);
			IFX_FXS_ReleaseCall(pxEndptInfo,pxBtxCall);
			IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);
		}
#endif
	} 
	else
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Blind Transfer Failed");
	}

	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_TRANSFER_INITIATED);

	IFX_FXS_StartTone(pxEndptInfo, eTone, unToneDur, IFX_FXS_EVT_BCEToneExpired,
			NULL, &pxEndptInfo->uiToneTimerId );
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_BUSY);

	return IFX_SUCCESS;
}

	/* IFX_FXS_STATE_RINGING     */
/*
 * This routine handles off-hook event in ringing state.
 * 
 * Stop tone and tone timer.
 * If IFX_FXS_DISTINCTIVE_RING_ON was set, initiate call to party with which 
 * auto redial was requested & reset flag and auto redial parameters. Set 
 * IFX_FXS_CALL_INITIATED and move to dialing state. 
 * 
 * Else this call was initiated from remote end, so answer the call and move to
 * conversation.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RingOffHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	uint32 unToneDuration = IFX_ERROR_TONE_DURATION;
	e_IFX_CMGR_Status eStatus;
	e_IFX_MMGR_ToneType eToneType = IFX_MMGR_MAX_TONE;
	e_IFX_FXS_State eState = IFX_FXS_STATE_BUSY;
	e_IFX_Return eRet = IFX_SUCCESS;
#ifdef MEM_DBG
	IFX_OS_MemInfo();
#endif

	IFX_FXS_StopTone(pxEndptInfo,&pxEndptInfo->uiToneTimerId);
	//IFX_MMGR_SetFxsToActive(pxEndptInfo->szEndPointId); //Activate FXS

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_DISTINCTIVE_RING_ON) )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId, "Redialing Last Dialed VoIP Number");
		/* Initiate call */
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_DISTINCTIVE_RING_ON);

		eRet = IFX_FXS_InitiateCall(pxEndptInfo, &pxEndptInfo->xLastDialedAddr,
							IFX_CMGR_DONT_CARE, IFX_FALSE, &eStatus,peReason);

		if( IFX_SUCCESS == eRet )
		{
			if( IFX_CMGR_STATUS_SUCCESS == eStatus )
			{
					eState = IFX_FXS_STATE_CONVERSATION;
			}
			else if( IFX_ENDPOINT_RINGING == *peReason )
			{
					eToneType = IFX_MMGR_RING_BACK_TONE;
					unToneDuration = IFX_RINGBACK_TONE_DURATION;
					eState = IFX_FXS_STATE_RINGBACK;
			}
			else
			{
				/* Set flag if call is made */
				IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_INITIATED);
				eState = IFX_FXS_STATE_DIALING;
			}
		}

		if( IFX_SUCCESS != eRet || IFX_CMGR_STATUS_FAIL == eStatus )
		{
			if( IFX_ENDPOINT_BUSY == *peReason )
			{
				eToneType = IFX_MMGR_BUSY_TONE;
				unToneDuration = IFX_BUSY_TONE_DURATION;
			}
			else
			{
				eToneType = IFX_MMGR_ERROR_TONE;
			}
			eState = IFX_FXS_STATE_BUSY;
		}
	}
	else
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Incomoing Call Answered");
		/* Call is initiated from remote party */
		IFX_CMGR_CallAnswer(pxEndptInfo->pxActiveCall->uiCallId,
												&eStatus,
												peReason );

		if( IFX_CMGR_STATUS_SUCCESS != eStatus )
		{
			IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId, "Failed To Inform Peer About Call Answer");
			IFX_FXS_ReleaseCall(pxEndptInfo, pxEndptInfo->pxActiveCall);
			pxEndptInfo->pxActiveCall = 0;
			eToneType = IFX_MMGR_ERROR_TONE;
		} 
		else
		{
			IFX_FXS_UpdateCallState(pxEndptInfo,pxEndptInfo->pxActiveCall, 
				IFX_FXS_CS_ACTIVE);
			eState = IFX_FXS_STATE_CONVERSATION;
		}
	}

	if( IFX_MMGR_MAX_TONE != eToneType)
	{
		IFX_FXS_StartTone(pxEndptInfo, eToneType, unToneDuration,
							IFX_FXS_EVT_BCEToneExpired, NULL, &pxEndptInfo->uiToneTimerId );
	}

	IFX_FXS_UpdateEndpointState(pxEndptInfo,eState);
	return IFX_SUCCESS;
}

/*
 * This routine handles ring timer expiry event in ringing state.
 * If IFX_FXS_DISTINCTIVE_RING_ON flag is on, tunroff it and clear auto redial
 * parameters stored for the endpoint. Else release the call with reason as 
 * timeout. 
 * Make endpoint idle. If IFX_FXS_AUTOREDIAL_ACTIVE_IN flag was set, send 
 * notification. Move to idle state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RingRingTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{

	if( pxEndptInfo->uiToneTimerId != pxEvtInfo->uiId)
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Wrong Timer ID");
		return IFX_FAILURE;
	}

	IFX_FXS_StopTone(pxEndptInfo,&pxEndptInfo->uiToneTimerId);

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_DISTINCTIVE_RING_ON) )
	{
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_DISTINCTIVE_RING_ON);
		//memset(&pxEndptInfo->xLastDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
	}
	else
	{
		IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
												 IFX_TIMEOUT,NULL,NULL,peReason);
		IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
		pxEndptInfo->pxActiveCall = 0;
	}

	IFX_FXS_MakeFXSIdle(pxEndptInfo,peReason);
	
	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN) &&
			IFX_SUCCESS != IFX_FXS_SendAutoRedialNtfy(pxEndptInfo,IFX_TRUE) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Could Not Send Auto Redial Notify");
	}
	
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_IDLE);
	return IFX_SUCCESS;
}

/*
 * This routine handles release call event in ringing state.
 * Verify that call id is equal to that endpoint's activve call. If does not 
 * match ignore this event and return failure. Else stop ring tone & timer and
 * release call & make endpoint idle. If auto redial was requested by a remote
 * send notification. Move to idle state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RingReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxActvCall;

	pxActvCall =  pxEndptInfo->pxActiveCall;

	if( pxActvCall->uiCallId != pxEvtInfo->uiId )
	{
		return IFX_FAILURE;
	}

	IFX_FXS_StopTone(pxEndptInfo, &pxEndptInfo->uiToneTimerId);

	IFX_FXS_ReleaseCall(pxEndptInfo,pxActvCall);

	IFX_FXS_MakeFXSIdle(pxEndptInfo,peReason);
	
	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN) &&
			IFX_SUCCESS != IFX_FXS_SendAutoRedialNtfy(pxEndptInfo,IFX_TRUE) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Could Not Send Auto Redial Notify");
	}
	
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_IDLE);
	return IFX_SUCCESS;
}

	/* IFX_FXS_STATE_RINGBACK    */
/*
 * In ringback state, remote call release functinality is same as that of 
 * dialing state. So dilaing and ringback state release call handler are same.
 * (routine: IFX_FXS_DialAndRingbackReleaseCallHdlr)
 */

/*
 * This function handles on-hook event in ringback state.
 * Stop ringback tone and timer. Release active call. Make endpoint idle (this
 * releases all held calls). If IFX_FXS_AUTOREDIAL_ACTIVE_IN was set, send 
 * notification to remote party that subscribed for auto redial. Move to idle 
 * state
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RingbackOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	IFX_FXS_StopTone(pxEndptInfo,&pxEndptInfo->uiToneTimerId);
	IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, IFX_ENDPOINT_BUSY,
			NULL, NULL, peReason);
	IFX_FXS_ReleaseCall(pxEndptInfo, pxEndptInfo->pxActiveCall);
	IFX_FXS_MakeFXSIdle(pxEndptInfo, peReason);
	
	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN) &&
			IFX_SUCCESS != IFX_FXS_SendAutoRedialNtfy(pxEndptInfo,IFX_TRUE) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Could Not Send Auto Redial Notify");
	}
	
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_IDLE);
	return IFX_SUCCESS;
}

/*
 * This routine handles hook flash event in ringback state.
 * 
 * Ignore if there are no held calls. 
 * Else stop ringback tone & timer. Release initiated call. Start dial tone and
 * timer. Move to dialing state.
 *
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RingbackHookFlashHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_Return eRet = IFX_SUCCESS;
	uchar8 ucHeldCalls;
	uint16 unTimeOut;
	e_IFX_MMGR_ToneType eToneType; 
	
	ucHeldCalls = IFX_FXS_GetHeldCallsCount(pxEndptInfo);

	if( ucHeldCalls )
	{
		IFX_FXS_StopTone(pxEndptInfo,&pxEndptInfo->uiToneTimerId);
		IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, IFX_ENDPOINT_BUSY,
				NULL, NULL, peReason);
		IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
		IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);

		
		eToneType = IFX_FXS_GetDialToneType(pxEndptInfo->szEndPointId,&unTimeOut);
		/* Don't play stutter tone now */
		eToneType = ( IFX_MMGR_STUTTER_DIAL_TONE == eToneType)
																						?IFX_FXS_REG_DIAL_TONE:eToneType;
		IFX_FXS_StartTone(pxEndptInfo, eToneType,
							vunDialToneLength, IFX_FXS_EVT_DialToneExpired, NULL,
							&pxEndptInfo->uiToneTimerId );
		
		IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_DIALING);
	}

	return eRet;
}

/*
 * This routine handles ringback timer expiry event in ringback state.
 * If expired timer id does not match with tone timer id of endpoint, ignore
 * the event.
 * Stop tone, release call. Start error tone & timer. Move to busy state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
******************************************************************************/
e_IFX_Return IFX_FXS_RingbackRingbackTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{

	if( pxEndptInfo->uiToneTimerId != pxEvtInfo->uiId)
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Wrong Timer Id");
		return IFX_FAILURE;
	}

	IFX_FXS_StopTone(pxEndptInfo,NULL);
	pxEndptInfo->uiToneTimerId = 0;
	IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId, IFX_ENDPOINT_BUSY,
			NULL, NULL, peReason);
	IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
	IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);
	IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_ERROR_TONE,
						IFX_ERROR_TONE_DURATION, IFX_FXS_EVT_BCEToneExpired, NULL,
						&pxEndptInfo->uiToneTimerId );
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_BUSY);
	return IFX_SUCCESS;
}


/*---------------------------------------------------------------------------*/

/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_RingbackRmtAcceptHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
#if 0
	x_IFX_FXS_CallInfo* pxActiveCall;
	e_IFX_Return  eRet = IFX_FAILURE;
	
	pxActiveCall = pxEndptInfo->pxActiveCall ;
	if( pxEvtInfo->uiId != pxActiveCall->uiCallId || 
		  IFX_FXS_CS_CALL_INITIATED != pxActiveCall->eCallState )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"FAILED : Accept Event On Wrong Call");
		return eRet;
	}
#endif
/*
	IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId,"May Be Call Being Forwarded"); */
#if 0
	eRet = IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_RING_BACK_TONE,
						IFX_RINGBACK_TONE_DURATION, IFX_FXS_EVT_RingBackToneExpired, NULL,
						&pxEndptInfo->uiToneTimerId );
	IFX_FXS_UpdateCallState(pxEndptInfo,pxActiveCall,IFX_FXS_CS_RINGING);
	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_INITIATED);
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_RINGBACK);
#endif

	return IFX_SUCCESS;
}
/*---------------------------------------------------------------------------*/

	/* IFX_FXS_STATE_CONVERSATION*/
/*
 * This routine hanldes on-hook event in conversation state.
 *
 * If there are no held call or call hold is initiated release all calls, else
 * initiate attended transfer and release all calls.
 *
 * Make endpoint idle. If IFX_FXS_AUTOREDIAL_ACTIVE_IN was set send auto 
 * redial notification. Move to idle state.
 *
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConvOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxHeldCall = NULL;
	e_IFX_TransferStatus eTfrStatus;
	uchar8 ucHeldCalls;
	e_IFX_Return eRet;

	ucHeldCalls = IFX_FXS_GetHeldCallsCount(pxEndptInfo);

	if( ucHeldCalls )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
                 pxEndptInfo->szEndPointId, "Transfering Calls (Attended)" );
		IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxHeldCall);
		if (pxHeldCall == NULL)
			return IFX_FAILURE;
		eRet = IFX_CMGR_AttendedTx(pxHeldCall->uiCallId,
					 pxEndptInfo->pxActiveCall->uiCallId, NULL, &eTfrStatus, peReason );
		if( IFX_SUCCESS != eRet || IFX_CMGR_TRANSFER_FAILED == eTfrStatus ||
			IFX_CMGR_TRANSFER_REJECTED == eTfrStatus )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId,"Could Not Initiated Attended Transfer" );
			IFX_CMGR_CallRelease( pxEndptInfo->pxActiveCall->uiCallId,
					IFX_TERMINATED, NULL, NULL, peReason);
			IFX_CMGR_CallRelease( pxHeldCall->uiCallId,
					IFX_TERMINATED, NULL, NULL, peReason);
		}
		
		IFX_FXS_ReleaseCall(pxEndptInfo, pxEndptInfo->axFxsCallInfo+0);
		IFX_FXS_ReleaseCall(pxEndptInfo, pxEndptInfo->axFxsCallInfo+1);
	}

	/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
                 pxEndptInfo->szEndPointId,"Releasing FXS Calls Resources"); */
	pxEndptInfo->pxActiveCall = 0;
	IFX_FXS_MakeFXSIdle(pxEndptInfo,peReason); 
	
	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN) &&
			IFX_SUCCESS != IFX_FXS_SendAutoRedialNtfy(pxEndptInfo,IFX_TRUE) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Could Not Send Auto Redial Notify");
	}

	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_IDLE);
	return IFX_SUCCESS;
}

/*
 * This routine handles hook-flash in conversation state.
 * If any one of IFX_FXS_HOLD_INITIATED, IFX_FXS_EMG_CALL_PROCEEDING or 
 * IFX_FXS_TRANSFER_INITIATED was set, ignore this event. 
 * Else stop inter digit timer, initiate hold on active call. If call hold 
 * IFX_FXS_HOLD_INITIATED. If hold status is success, invoke 
 * status is pending, then set IFX_FXS_CallHoldSuccess & and move to state 
 * returned by this function. If hold failed, remain in this state
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConvAndCwHookFlashHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxActiveCall;
	e_IFX_CMGR_Status eStatus;
	e_IFX_FXS_State eEndptState = IFX_FXS_STATE_MAX;
	e_IFX_Return eRet = IFX_FAILURE;

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,(IFX_FXS_EMG_CALL_PROCEEDING |
			IFX_FXS_HOLD_INITIATED | IFX_FXS_TRANSFER_INITIATED) ) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndPointId, "Can not entertain Hook-Flash");
		return eRet;
	}
		
	/* 
	 * In call waiting state, if interdigit timer is running, stop it and clear 
	 * collected digits 
	 */
	if( IFX_FXS_STATE_CALLWAITING == pxEndptInfo->eState &&
		  pxEndptInfo->uiIntrDgtTimerId )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndPointId,"Answering Waiting Call");
		IFX_TIM_TimerStop(pxEndptInfo->uiIntrDgtTimerId);
		pxEndptInfo->szDialledDigits[0] = '\0';
		pxEndptInfo->uiIntrDgtTimerId = 0;
	}

	pxActiveCall = pxEndptInfo->pxActiveCall;

	/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndPointId,"Initiating Call Hold"); */

	eRet = IFX_CMGR_CallHold(pxActiveCall->uiCallId,&eStatus,peReason);

	if( IFX_SUCCESS == eRet )
	{
		if(IFX_CMGR_STATUS_SUCCESS == eStatus )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndPointId,"Call Hold SUCCESS");
			eRet = IFX_FXS_CallHoldSuccess(pxEndptInfo,&eEndptState,peReason);
			IFX_FXS_UpdateEndpointState(pxEndptInfo,eEndptState);
		}
		else if( IFX_CMGR_STATUS_PENDING == eStatus )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndPointId,"Call Hold PENDING");
			IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_HOLD_INITIATED);
			IFX_FXS_UpdateCallState(pxEndptInfo, 
											pxActiveCall, IFX_FXS_CS_HOLD_INITIATED);
		}
		else
		{
			/* Hold failed */
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
        pxEndptInfo->szEndPointId,"Call Hold FAILED");
		}
	}
	else
	{
		/* Hold API returned failure */
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId,"Failed To Initiate Call Hold" );
	}

	return eRet;
}

/*
 * This routine hanldes hold response in coversation state.
 * Hold was not initiated on active call or call id is not equal to active 
 * call's id, ignore event and return failure.
 *
 * Else reset IFX_FXS_HOLD_INITIATED flag. If hold status is success, invoke 
 * IFX_FXS_CallHoldSuccess & and move to state returned by this function. If 
 * hold failed, remain in this state
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConvAndCwHoldRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxActiveCall;
	e_IFX_FXS_State eEndptState = IFX_FXS_STATE_MAX;

	pxActiveCall = pxEndptInfo->pxActiveCall;

	if( IFX_FXS_CS_HOLD_INITIATED != pxActiveCall->eCallState ||
		  pxEvtInfo->uiId != pxActiveCall->uiCallId )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Either Call Id or Call state is WRONG");
		return IFX_FAILURE;
	}

	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_HOLD_INITIATED);

	if(IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus )
	{
		IFX_FXS_CallHoldSuccess(pxEndptInfo,&eEndptState,peReason);
		IFX_FXS_UpdateEndpointState(pxEndptInfo,eEndptState);
	}
	else 
	{
		/* Hold failed */
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Hold Failed");
	}

	return IFX_SUCCESS;
}

/** FAX DIS event */
/** FAX CED event */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConvFaxStartHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{			
	/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId,"Starting FAX"); */
	if(IFX_FXS_CheckEndpointFlag(pxEndptInfo, IFX_FXS_ORIGINATOR)){
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Ignoring CED as this is the call originator");
		return IFX_SUCCESS;
	}
	if( IFX_FALSE == pxEndptInfo->pxActiveCall->bFaxStarted )
	{
		if(IFX_SUCCESS != IFX_CMGR_FaxStart(pxEndptInfo->pxActiveCall->uiCallId))
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Could Not Start FAX");
		}
		else
			pxEndptInfo->pxActiveCall->bFaxStarted = IFX_TRUE;
	}

	return IFX_SUCCESS;
}

/** FAX CNG event */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConvCNGHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId,"CNG Event..Ignoring");
	return IFX_SUCCESS;
}
/*
 * This routine handles digit press event in conversation and conference states
 * If hold initiated or conference break initiated, ignore the event.
 * Else Send digits to remote party.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_DigitPressedDuringConvHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_DigitPressedEvent* pxDpEvent;
	x_IFX_CMGR_DgtInfo xDigitInfo;
	e_IFX_CMGR_Status eStatus;

	if( !IFX_FXS_CheckEndpointFlag(pxEndptInfo, 
		(IFX_FXS_HOLD_INITIATED | IFX_FXS_BREAK_CONFERENCE_INITIATED)) )
	{

		pxDpEvent = &(pxEvtInfo->uxEventData.xDgtEvent);
		strncpy(xDigitInfo.szDigits,(char8 *) pxDpEvent->aucDgtInfo,pxDpEvent->ucNumDgts);
		xDigitInfo.szDigits[pxDpEvent->ucNumDgts] = '\0';

		if( IFX_SUCCESS !=
			IFX_CMGR_DigitsInCallSnd(pxEndptInfo->pxActiveCall->uiCallId,
																&xDigitInfo,&eStatus,peReason ) )
		{
			IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"FAILED : DigitsInCallSnd");
		}
	}

	return IFX_SUCCESS;
}
 
/*
 * This routine is responsible for handling incoming call in conversation sate.
 *
 * Check whether call can be accpeted - If blocked, hold or transfer (ATX) 
 * initiated, or endpoint has maximum calls, reject call. Reject if emergency
 * call is going on.
 * Else accept the call. Start call waiting tone & timer. Move to call waiting
 * state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
******************************************************************************/
e_IFX_Return IFX_FXS_ConvIncomingCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxNewCall = NULL;
	x_IFX_FXS_IncCallEvent* pxInCallEvnt;
	int32 iRingTimeOut = IFX_RING_TONE_DURATION;
	//boolean bBlocked = IFX_FALSE;
	e_IFX_Return eRet = IFX_FAILURE;
	
	*peReason = IFX_NO_RESOURCE;
	/* pxNewCall will be NULL, if no free call info is available */
	IFX_FXS_GetFreeCallInfo(pxEndptInfo,&pxNewCall);

	/* 
	 * Reject if hold or transfer initiated or if endpoint has max active calls.
	 */
	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo, (IFX_FXS_HOLD_INITIATED |
		IFX_FXS_TRANSFER_INITIATED | IFX_FXS_EMG_CALL_PROCEEDING)) || 
		NULL == pxNewCall )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Can not accept incoming call");
		return eRet;
	}

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo, IFX_FXS_REJECT_WAITING_CALL) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"User De-Activated Call Waiting For Current Call");
		return eRet;
	}

	/* If caller's number is in block list, reject the call */
	pxInCallEvnt = &(pxEvtInfo->uxEventData.xIncCallEvent);

	/* If caller's number is in block list, reject the call */
	pxInCallEvnt = &(pxEvtInfo->uxEventData.xIncCallEvent);
	
	IFX_AGU_GetCallerIdInfo(pxInCallEvnt->pxFrom, 
									pxEndptInfo->xCwCidParams.szCallerName, 
									pxEndptInfo->xCwCidParams.szCallerNumber);
	pxEndptInfo->xCwCidParams.eTxType = IFX_MMGR_OFFHOOK;

/*	eRet = IFX_CIF_IncomingCallBlockCheck(pxEndptInfo->szEndPointId,
							pxEndptInfo->xCwCidParams.szCallerNumber, &bBlocked, peReason);
	if(IFX_SUCCESS != eRet || bBlocked )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "This call is blocked");
		return IFX_FAILURE;
	}*/
	/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
		pxEndptInfo->szEndPointId,"Call accepted..Playing call waiting tone"); */
	/* 
	 * Accept the call. Play call waiting tone. start call waiting timer. Move to
	 * call waiting state.
	 */
	pxNewCall->uiCallId =  pxEvtInfo->uiId; 
	pxNewCall->eCallType = pxInCallEvnt->pxFrom->eAddressType;
	if( IFX_CMGR_TYPE_FXO == pxNewCall->eCallType )
	{
		strcpy(pxEndptInfo->pxActiveCall->szCallInitrEndptId, 
							pxInCallEvnt->pxFrom->uxAddressInfo.xFxoInfo.szFxoLineId );
	}
	IFX_FXS_UpdateCallState(pxEndptInfo, pxNewCall,IFX_FXS_CS_RINGING);

	if( pxInCallEvnt->pxCallParams->uxCallParams.xExtnParams.cRingCount ) {
		IFX_MMGR_RingCadenceTimeGet(&iRingTimeOut);
		iRingTimeOut *= 
			pxInCallEvnt->pxCallParams->uxCallParams.xExtnParams.cRingCount;
	} 

	eRet = IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_CALL_WAITING_TONE,
						iRingTimeOut, IFX_FXS_EVT_RingToneExpired, &pxEndptInfo->xCwCidParams , 
						&pxEndptInfo->uiToneTimerId );
	IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING);
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_CALLWAITING);
	return IFX_SUCCESS;
}

/*
 * This routine hanldes remote call release even in conversation state.
 *
 * If released call is not valid, retunr failure.
 * Active call released - Release call, set active call of the endpoint to last
 * held call (if exist). play error tone & start tone timer. If hold was 
 * initiated reset IFX_FXS_HOLD_INITIATED. Move to busy state.
 * Held call - Release held call.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConvReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxRelCall;

	IFX_FXS_GetCallInfo(pxEndptInfo,pxEvtInfo->uiId,&pxRelCall);
	
	if( NULL == pxRelCall )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Invalid Call Id");
		return IFX_FAILURE;
	}

	if( pxRelCall == pxEndptInfo->pxActiveCall )
	{
	
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_HOLD_INITIATED);

		IFX_FXS_ReleaseCall(pxEndptInfo,pxRelCall);
		IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);
		/* Start tone & move to busy state */
		IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_ERROR_TONE,
							IFX_ERROR_TONE_DURATION, IFX_FXS_EVT_BCEToneExpired, NULL,
							&pxEndptInfo->uiToneTimerId );
		IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_BUSY);
	} 
	else
	{
		/* Call is not active, it must be in held state */
		IFX_FXS_ReleaseCall(pxEndptInfo,pxRelCall);
	}
	return IFX_SUCCESS;
}


	/* IFX_FXS_STATE_CONFERENCE  */
/*
 * This routine handles on-hook event in conference state.
 * Break conference and release all calls. Make endpoint idle. If remote party
 * subscribed for auto redial, send notification. Go to idle state.
 *
 * In this case endpoint does not wait for conference status. 
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConfOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{

/*	e_IFX_CMGR_Status eStatus;

	if( IFX_SUCCESS != 
			IFX_CMGR_ConfBreak(pxEndptInfo->uiConfReqId, &eStatus, peReason) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Failed To Break Conferene");
	}*/

	/* Release call, de-allocate signaling channel make endpoint idle. */
	IFX_FXS_MakeFXSIdle(pxEndptInfo,peReason);

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN) &&
			IFX_SUCCESS != IFX_FXS_SendAutoRedialNtfy(pxEndptInfo,IFX_TRUE) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Could not send Auto redial Notify");
	}

	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_IDLE);
	return IFX_SUCCESS ;
}

/*
 * This routine handles hook-flash event in conference state.
 * If conference break was initiated, ignore this event. Initiate conference
 * break. Check staus of conference break. If fail, remain in this state. If 
 * success mark all calls in conference as held and start second dial tone &
 * timer. Move to dialing state. If status is pending, set conference break 
 * flag (IFX_FXS_BREAK_CONFERENCE_INITIATED) and don't change the state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConfHookFlashHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_CMGR_Status eStatus;
	e_IFX_Return eRet;

	if( !IFX_FXS_CheckEndpointFlag(pxEndptInfo,
		IFX_FXS_BREAK_CONFERENCE_INITIATED) )
	{
		eRet = IFX_CMGR_ConfBreak(pxEndptInfo->uiConfReqId, &eStatus, peReason);

		if( IFX_SUCCESS != eRet || IFX_CMGR_STATUS_FAIL == eStatus )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Failed To Break Conference");
		}
		else
		{
			uint16 unTimeOut;
			e_IFX_MMGR_ToneType eToneType; 

			if( IFX_CMGR_STATUS_SUCCESS == eStatus )
			{
				IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId, "Conference Broken");
				IFX_FXS_UpdateCallState(pxEndptInfo, (pxEndptInfo->axFxsCallInfo+0),
						IFX_FXS_CS_LOCAL_HELD);				
				IFX_FXS_UpdateCallState(pxEndptInfo, (pxEndptInfo->axFxsCallInfo+1),
						IFX_FXS_CS_LOCAL_HELD);


				eToneType = IFX_FXS_GetDialToneType(pxEndptInfo->szEndPointId,&unTimeOut);
				/* Don't play stutter tone now */
				eToneType = ( IFX_MMGR_STUTTER_DIAL_TONE == eToneType)
																						?IFX_FXS_REG_DIAL_TONE:eToneType;
				IFX_FXS_StartTone(pxEndptInfo, eToneType,
										vunDialToneLength, IFX_FXS_EVT_DialToneExpired, NULL,
										&pxEndptInfo->uiToneTimerId );
				IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_DIALING);
			}
			else /* IFX_CMGR_STATUS_PENDING  */
				IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_BREAK_CONFERENCE_INITIATED);
		}								 
	}
	return IFX_SUCCESS;
}

/*
 * This routine handles remote release call event in conference state.
 *
 * Release the call.
 * If released call is endpoints active call and if there is another active 
 * call, make that call as endpoint's active call. If there is no other call
 * set NULL to endpoint's active call.  
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConfReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxRelCall;

	IFX_FXS_GetCallInfo(pxEndptInfo,pxEvtInfo->uiId,&pxRelCall);

	if( NULL == pxRelCall )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Invalid Call is released");
		return IFX_FAILURE;
	}

	IFX_FXS_ReleaseCall(pxEndptInfo,pxRelCall);

	if( pxEndptInfo->pxActiveCall == pxRelCall )
	{
		if( IFX_FXS_CS_NONE != pxEndptInfo->axFxsCallInfo[0].eCallState )
			pxEndptInfo->pxActiveCall = (pxEndptInfo->axFxsCallInfo+0);
		else if( IFX_FXS_CS_NONE != pxEndptInfo->axFxsCallInfo[1].eCallState )
			pxEndptInfo->pxActiveCall = (pxEndptInfo->axFxsCallInfo+1);
		else
		{
			/* 
			 * All calls in conference are released. Expecting break conference staus.
			 * In conference break status handler play error tone and move to busy 
			 * state.
			 */
			pxEndptInfo->pxActiveCall = NULL; 
		}
	}
	return IFX_SUCCESS;
}

/*
 * This routine hanldes conference status event in conference state.
 * If IFX_FXS_BREAK_CONFERENCE_INITIATED was set, mark all calls as held and
 * start second dial tone & timer. Move to dialing state.
 * 
 * Else if there is only one call, move to conersation state. If there are no
 * calls play error tone & start timer and move to busy state.
 * Note that call manager if initiates confeence break on its own, first it 
 * releases all calls in conference and sends conference break event.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ConfConfStatusHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_FXS_State eEndptState = IFX_FXS_STATE_CONFERENCE;
	e_IFX_CMGR_Status eStatus; 

	eStatus = pxEvtInfo->uxEventData.eStatus ;

	if( pxEndptInfo->uiConfReqId != pxEvtInfo->uiId )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Invalid Conference call id");
		return IFX_FAILURE;
	}

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,
		IFX_FXS_BREAK_CONFERENCE_INITIATED) )
	{
		uint16 unTimeOut;
		e_IFX_MMGR_ToneType eToneType; 

		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Conferene broken");
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,
															IFX_FXS_BREAK_CONFERENCE_INITIATED);
		if( IFX_CMGR_STATUS_SUCCESS == eStatus )
		{
			IFX_FXS_UpdateCallState(pxEndptInfo, (pxEndptInfo->axFxsCallInfo+0),
					IFX_FXS_CS_LOCAL_HELD);				
			IFX_FXS_UpdateCallState(pxEndptInfo, (pxEndptInfo->axFxsCallInfo+1),
					IFX_FXS_CS_LOCAL_HELD);


			eToneType = IFX_FXS_GetDialToneType(pxEndptInfo->szEndPointId,&unTimeOut);
			/* Don't play stutter tone now */
			eToneType = ( IFX_MMGR_STUTTER_DIAL_TONE == eToneType)
																						?IFX_FXS_REG_DIAL_TONE:eToneType;
			IFX_FXS_StartTone(pxEndptInfo, eToneType,
								vunDialToneLength, IFX_FXS_EVT_DialToneExpired, NULL,
								&pxEndptInfo->uiToneTimerId );
			eEndptState = IFX_FXS_STATE_DIALING;
		}
		else
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Conference Break Failed");
		}
	}
	else
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Conference broken by Call Manager");
		if( NULL != pxEndptInfo->pxActiveCall )
		{
			eEndptState = IFX_FXS_STATE_CONVERSATION;
		}
		else
		{
			IFX_FXS_StartTone(pxEndptInfo, IFX_MMGR_ERROR_TONE,
								IFX_ERROR_TONE_DURATION, IFX_FXS_EVT_BCEToneExpired, NULL,
							  &pxEndptInfo->uiToneTimerId );
			eEndptState = IFX_FXS_STATE_BUSY;
		}
	}

	if( IFX_FXS_STATE_CONFERENCE != eEndptState )
		IFX_FXS_UpdateEndpointState(pxEndptInfo,eEndptState);

	return IFX_SUCCESS;
}

	/* IFX_FXS_STATE_CALLWAITING */
/*
 * Hook-flash and hold response handlers are IFX_FXS_ConvAndCwHookFlashHdlr
 * and IFX_FXS_ConvAndCwHoldRespHdlr respectively. These two hanlders are used
 * in conversation and call waiting states.
 */

/*
 * This handler is responsible for on-hook event in call waiting state.
 *
 * Release active call. Stop call waiting tone (don't stop timer). Stop inter 
 * digit timer if running. Start ring tone. Turnoff IFX_FXS_CALL_WAITING flag.
 * Move to ringing state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_CwOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Entry"); */
	
	IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);

	if( pxEndptInfo->uiIntrDgtTimerId )
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiIntrDgtTimerId);
		pxEndptInfo->uiIntrDgtTimerId = 0;
	}

	IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
						IFX_TERMINATED, NULL, NULL, peReason);
	IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);

	/* Waiting call is active call now */
	IFX_FXS_GetWaitingCallInfo(pxEndptInfo,&pxEndptInfo->pxActiveCall);

	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING);
	pxEndptInfo->xCwCidParams.eTxType = IFX_MMGR_ONHOOK;
	if( IFX_MMGR_SUCCESS != IFX_MMGR_TonePlay(pxEndptInfo->szEndPointId, 
			IFX_MMGR_RING_TONE, &pxEndptInfo->xCwCidParams) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"IFX_MMGR_TonePlay FAILED");
		if (pxEndptInfo->pxActiveCall == NULL)
			return IFX_FAILURE;
		IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
							IFX_TERMINATED, NULL, NULL, peReason);
		IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
		pxEndptInfo->pxActiveCall = 0;
		IFX_FXS_MakeFXSIdle(pxEndptInfo,peReason);
	  IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_IDLE);
	}
	else
	  IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_RINGING);

	return IFX_SUCCESS;
}

/*
 * This routine hanldes digit pressed event in call waiting state
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_CwDigitPressedHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{

	x_IFX_FXS_TimerEvent xTimerEvent;
	x_IFX_DP_Rule xDpRule;
	char8  szDialOut[IFX_MAX_DIGITS];
	uint16 unValue;
	uchar8 ucDpAction;
	e_IFX_Return eRet;

	x_IFX_FXS_DigitPressedEvent* pxDpEvent;

	if( pxEndptInfo->uiIntrDgtTimerId )
	{
		IFX_TIM_TimerStop(pxEndptInfo->uiIntrDgtTimerId);
		pxEndptInfo->uiIntrDgtTimerId = 0;
	}

	pxDpEvent = &(pxEvtInfo->uxEventData.xDgtEvent);
	unValue = strlen(pxEndptInfo->szDialledDigits);
	if (unValue+pxDpEvent->ucNumDgts > (2*IFX_MAX_DIGITS-1)){
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
      	pxEndptInfo->szEndPointId, "szDialledDigits buffer is not sufficient " );
      	return IFX_SUCCESS;
  }
	strncpy(pxEndptInfo->szDialledDigits+unValue,
					(char8 *)pxDpEvent->aucDgtInfo,pxDpEvent->ucNumDgts);
	pxEndptInfo->szDialledDigits[unValue+pxDpEvent->ucNumDgts] = '\0';

	eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits, IFX_FALSE, &ucDpAction,
						szDialOut, &xDpRule, &unValue );
	/* 
	 * In this handler, only small/large actions are relevant. For other action
	 * play error tone and start tone timer
	 */
	if( IFX_SUCCESS == eRet && (IFX_DP_ST_SMALL_TIM == ucDpAction || 
							 IFX_DP_ST_LARGE_TIM == ucDpAction) )
	{
		xTimerEvent.eTimerEvent = IFX_FXS_EVT_InterDgtTimerExp;
		xTimerEvent.pxEndptInfo = pxEndptInfo;

		IFX_TIM_TimerStart(unValue,&xTimerEvent,sizeof(xTimerEvent),
				IFX_FXS_TimerFired,&pxEndptInfo->uiIntrDgtTimerId);		
	}
	else
		pxEndptInfo->szDialledDigits[0] = '\0';

	return IFX_SUCCESS;
}
 
/*
 * This routine hanldes inter digit timer expiry event in call waiting state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_CwInterDigitTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_DP_Rule xDpRule;
	x_IFX_FXS_CallInfo* pxWaitCall;
	char8  szDialOut[IFX_MAX_DIGITS];
	uint16 unValue;
	uchar8 ucDpAction;
	e_IFX_Return eRet = IFX_FAILURE;

	/* if timer id did not match, ignore the event */
	if( pxEvtInfo->uiId != pxEndptInfo->uiIntrDgtTimerId )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Invalid Timer Id");
		return eRet;
	}

	eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits, IFX_TRUE,
						&ucDpAction, szDialOut, &xDpRule, &unValue );
	
	if( IFX_SUCCESS == eRet && IFX_DP_DIALOUT == ucDpAction && 
		IFX_DP_CALLWAITING_REJECT == xDpRule.eAction )
	{
		/* Reject waiting call */
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Rejecting Waiting Call");
		IFX_FXS_StopTone(pxEndptInfo,NULL);
		IFX_FXS_GetWaitingCallInfo(pxEndptInfo,&pxWaitCall);
		if (pxWaitCall == NULL)
			return IFX_FAILURE;

		IFX_CMGR_CallRelease(pxWaitCall->uiCallId, IFX_TIMEOUT,
												NULL ,NULL,peReason);

		IFX_FXS_ReleaseCall(pxEndptInfo,pxWaitCall);	

		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING);
		IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_CONVERSATION);
	}

	pxEndptInfo->szDialledDigits[0] = '\0'; /* Clear dialed digit */
	return IFX_SUCCESS;
}
 
/*
 * This routine handles ring tone expiry handler in call waiting state.
 * Verify timer id with endpoint's timer id. If does not match, return failure.
 * Stop call waiting tone, release waiting & reset IFX_FXS_CALL_WAITING flag 
 * and move to conversation state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_CwRingToneExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxWaitCall;

	if( pxEvtInfo->uiId != pxEndptInfo->uiToneTimerId )
		return IFX_FAILURE;

	IFX_FXS_StopTone(pxEndptInfo,NULL);
	IFX_FXS_GetWaitingCallInfo(pxEndptInfo,&pxWaitCall);

	if( NULL == pxWaitCall )
	{
		/* This shall never happen */
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Major Error: Waiting Call Is Missing");
		return IFX_FAILURE;
	}

	IFX_CMGR_CallRelease(pxWaitCall->uiCallId, IFX_TIMEOUT, NULL, NULL, peReason);
	IFX_FXS_ReleaseCall(pxEndptInfo,pxWaitCall);
	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING);
	IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_CONVERSATION);
	return IFX_SUCCESS;
}

/*
 * This routine handles remote call release event in call waiting state.
 *
 * Verify released call's call id. If does not match return failure.
 * Stop call waiting tone (Don't stop timer)
 * Active call released - Release active call, start busy/error tone. If hold
 * was initiated reset IFX_FXS_HOLD_INITIATED flag. Now waiting call is active
 * call for endpoint. Move to busy state.
 *
 * Waiting call released -  Stop ring timer, release waiting call, reset 
 * IFX_FXS_CALL_WAITING flag. Move to conversation state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_CwReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxRelCall;
	e_IFX_FXS_State eEndptState;

	IFX_FXS_GetCallInfo(pxEndptInfo,pxEvtInfo->uiId,&pxRelCall);

	if( NULL == pxRelCall )
		return IFX_FAILURE;

	IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);

	if( pxEndptInfo->pxActiveCall == pxRelCall )
	{
		IFX_MMGR_TonePlay(pxEndptInfo->szEndPointId,
														 IFX_MMGR_ERROR_TONE, NULL);
		eEndptState = IFX_FXS_STATE_BUSY;
		/* Now waiting call is active call */
		IFX_FXS_GetWaitingCallInfo(pxEndptInfo,&pxEndptInfo->pxActiveCall);
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_HOLD_INITIATED); 
	}
	else
	{
		/* Waiting call released */
		IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
		pxEndptInfo->uiToneTimerId = 0;
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING);
		eEndptState = IFX_FXS_STATE_CONVERSATION;
	}

	IFX_FXS_ReleaseCall(pxEndptInfo,pxRelCall);
	IFX_FXS_UpdateEndpointState(pxEndptInfo,eEndptState);
	return IFX_SUCCESS;
}

	/* IFX_FXS_STATE_BUSY        */

/*
 * This routine handles On-Hook event in busy state.
 *
 * Stop tone and turnoff IFX_FXS_OFFHOOK_WARNING if on. (Don't stop timer.
 * If there is a waiting call, then ring timer should continue)
 * If IFX_FXS_CALL_WAITING was set, start ring tone & timer. Turnoff this flag
 * and move to rining state
 *
 * Else release all calls. Make endpoint idle. If someone requested for auto 
 * redial notification, send notification. Move to idle state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_BusyOnHookHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_FXS_State eEndptState;

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_OFFHOOK_WARNING) ||
			pxEndptInfo->uiToneTimerId  )
	{
		IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_OFFHOOK_WARNING);
	}

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING) )
	{
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING);

		if( IFX_MMGR_SUCCESS != IFX_MMGR_TonePlay(pxEndptInfo->szEndPointId, 
				IFX_MMGR_RING_TONE, &pxEndptInfo->xCwCidParams) )
		{
			IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"IFX_MMGR_TonePlay FAILED");
			IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
				IFX_TERMINATED, NULL, NULL, peReason);
			IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
			pxEndptInfo->pxActiveCall = 0;
			eEndptState = IFX_FXS_STATE_IDLE;
		}
		else
			eEndptState = IFX_FXS_STATE_RINGING;
	}
	else
	{
		if( pxEndptInfo->uiToneTimerId )
		{
			IFX_TIM_TimerStop(pxEndptInfo->uiToneTimerId);
			pxEndptInfo->uiToneTimerId = 0;
		}
		eEndptState = IFX_FXS_STATE_IDLE;
	}

	if( IFX_FXS_STATE_IDLE == eEndptState )
	{
		IFX_FXS_MakeFXSIdle(pxEndptInfo,peReason);

		if( IFX_FXS_CheckEndpointFlag(pxEndptInfo, IFX_FXS_AUTOREDIAL_ON_ONHOOK))
		{
			return IFX_FXS_AutoRedial(pxEndptInfo);
		}
		else
		if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN) 
			&& IFX_SUCCESS != IFX_FXS_SendAutoRedialNtfy(pxEndptInfo,IFX_TRUE) )
		{
			IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Could Not Send Auto Redial Notify");
		}
	}

	IFX_FXS_UpdateEndpointState(pxEndptInfo,eEndptState);
	return IFX_SUCCESS;
}

/*
 * This handler is responsible for ring timer expiry event in busy state.
 *
 * This event is possible only if there is a waiting call. Verify the timer id.
 * If timer id does not match ignore the event & return failure.
 * 
 * Stop tone. Release call with reason as timeout. Turnoff IFX_FXS_CALL_WAITING
 * flag. Start off-hook warning tone. Set IFX_FXS_OFFHOOK_WARNING flag. 
 * There is no change in endpoint state.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_BusyRingTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo,
	               OUT e_IFX_ReasonCode* peReason )
{

	if( pxEndptInfo->uiToneTimerId != pxEvtInfo->uiId )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Invalid Timer Id");
		return IFX_FAILURE;
	}

	IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
	IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
												 IFX_TIMEOUT,NULL,NULL,peReason);
	IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING);

	IFX_MMGR_TonePlay(pxEndptInfo->szEndPointId,
													 IFX_MMGR_OFF_HOOK_WARNING_TONE,NULL);

	IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_OFFHOOK_WARNING);
	return IFX_SUCCESS;
}

/*
 * This routine handles error tone, busy tone & confirmation events in busy 
 * state
 * Verify that timer with endpoints tone timer id. If does not match ignore 
 * event and return  failure.
 * 
 * Stop tone. 
 * Calls exist - Initiate resume on last active call. If resume status is 
 * success, mark resumed call as active & move to conversation state. If status
 * is pending set IFX_FXS_RESUME_INITIATED flag and remain in this state.
 * If failed to resume call, release that call and initiate resume on held call
 * if exist & depending on resume status take action as mentioned above. If there
 * is no other call start off hook warning tone and set IFX_FXS_OFFHOOK_WARNING.
 *
 * No Calls - start off hook warning tone and set IFX_FXS_OFFHOOK_WARNING.
 *
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_BCEToneTimerExpiryHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	//e_IFX_Return eRet = IFX_FAILURE;

	if( pxEndptInfo->uiToneTimerId != pxEvtInfo->uiId )
		return IFX_FAILURE;

	IFX_MMGR_ToneStop(pxEndptInfo->szEndPointId);
	pxEndptInfo->uiToneTimerId = 0;
	
	while( 1 )
	{
		if( IFX_SUCCESS != IFX_FXS_ResumeCallInBusy(pxEndptInfo,peReason) )
		{
			IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
					IFX_TERMINATED, NULL, NULL, peReason);
			IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
			IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);
		}
		else
			break;
	}
	return IFX_SUCCESS;
}

/*
 * This routne hanldes resume resonse in busy state.
 *
 * If resume was initiated, reset the IFX_FXS_RESUME_INITIATED flag. If resume
 * status is success, mark active call as resumed. Move to conversation state.
 * If resume failed, release that call. If there is another held all, initiate  
 * resume on that calll. If resume status is success, mark resumed call as active
 * & move to conversation state. If pending, set IFX_FXS_RESUME_INITIATED flag
 * and remain in this state. If resume failed on this call, release that call &
 * start off hook warning tone and set IFX_FXS_OFFHOOK_WARNING.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_BusyResumeRespHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{

	if( IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_RESUME_INITIATED ) )
	{
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_RESUME_INITIATED );
		if( IFX_CMGR_STATUS_SUCCESS == pxEvtInfo->uxEventData.eStatus )
		{
			IFX_FXS_UpdateCallState(pxEndptInfo,
															pxEndptInfo->pxActiveCall,IFX_FXS_CS_ACTIVE);
			IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_CONVERSATION);
		}
		else
		{
			/* Rsume failed. */
			while(1)
			{
				IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
														 IFX_TERMINATED, NULL, NULL, peReason);
				
				IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
				IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);
				
				if( IFX_SUCCESS == IFX_FXS_ResumeCallInBusy(pxEndptInfo,peReason) )
					break;
			}
		}
	}
	/* else Ignore event */

	return IFX_SUCCESS;
}

/*
 * This handler is used for remote call released event in busy state.
 *
 * Last held call (that is active call) - if IFX_FXS_RESUME_INITIATED was 
 * set reset flag and release call and invoke IFX_FXS_ResumeCallInBusy.
 *
 * No active call - Release call.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_BusyReleaseCallHdlr(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxRelCall;

	IFX_FXS_GetCallInfo(pxEndptInfo,pxEvtInfo->uiId,&pxRelCall);

	if( NULL == pxRelCall )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Call Does Not Exist");
		return IFX_FAILURE;
	}
 
	/* Reset call waiting flag if waiting call is released */
	if( pxRelCall->eCallState == IFX_FXS_CS_RINGING )
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING);

	if( pxEndptInfo->pxActiveCall == pxRelCall )
	{
		IFX_FXS_ReleaseCall(pxEndptInfo, pxRelCall);
		IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);

		if( pxEndptInfo->pxActiveCall && 
				IFX_FXS_CheckEndpointFlag(pxEndptInfo,IFX_FXS_RESUME_INITIATED) )
		{
			/*
			 * Resume initiated call was released and there is another held call.
			 */
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId, "Resume Initiated Call is Released");
			IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_RESUME_INITIATED);
			while( 1 )
			{
				if( IFX_SUCCESS != IFX_FXS_ResumeCallInBusy(pxEndptInfo,peReason) )
				{
					IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
															 IFX_TERMINATED, NULL, NULL, peReason);
					IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
					IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);
				}
				else
					break;
			}
		}
	}
	else 
	{
		/* released call is last held call.*/
		IFX_FXS_ReleaseCall(pxEndptInfo, pxRelCall);
	}
	return IFX_SUCCESS;
}


/*---------------------- End : Event handler routines -----------------------*/

/*----------------------------- Utility routines ----------------------------*/

/*
 * This routine will be registered as call back function with message router.
 * 
 * If event is valid for the FXS endpoint for event info and invoke 
 * IFX_FXS_FxsFsmHdlr. Otherwise ignore the event.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_MsgRouterEvtHdlr(
	               IN x_IFX_MMGR_DeviceEvents	*pxDevEvents)
{
	x_IFX_FXS_EndptFsmInfo* pxEndptInfo;
	x_IFX_FXS_EventInfo xEventInfo = {0};
	x_IFX_FXS_DigitPressedEvent* pxDpEvent;
	e_IFX_ReasonCode eReason;
	uchar8 ucEventCnt = 0;

	if( IFX_SUCCESS != 
			IFX_FXS_GetEndpointInfo(pxDevEvents->szEndPtId,&pxEndptInfo) )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 pxDevEvents->szEndPtId,"FXS Endpoint Not Found");
		return IFX_FAILURE;
	}
	
	if( 0 == pxDevEvents->uiEvents )
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "NO EVENTS - uiEvents is ZERO" );
		return IFX_SUCCESS;
	}
	
	xEventInfo.eEvent = IFX_FXS_EventMax;

	if( IFX_FXS_CHECKFLAG(pxDevEvents->uiEvents, IFX_MMGR_EVENT_OFFHOOK) )
	{
		 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId, "OFF-HOOK Event Received" ); 
		xEventInfo.eEvent = IFX_FXS_EVT_OffHk;
		++ucEventCnt;
	}

	if( IFX_FXS_CHECKFLAG(pxDevEvents->uiEvents, IFX_MMGR_EVENT_HOOK_FLASH) )
	{
		 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId,	"HOOK-FLASH Event Received" ); 
		xEventInfo.eEvent = IFX_FXS_EVT_HkFlash;
		++ucEventCnt;
	}

	if( IFX_FXS_CHECKFLAG(pxDevEvents->uiEvents, IFX_MMGR_EVENT_DIGIT) )
	{
		/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId,	"DIGITS Event Received" ); */
		xEventInfo.eEvent = IFX_FXS_EVT_DigitPressed;
		pxDpEvent = &(xEventInfo.uxEventData.xDgtEvent);
		pxDpEvent->ucNumDgts = pxDevEvents->ucNoOfDigits;
		strncpy((char8 *)pxDpEvent->aucDgtInfo,(char8 *) pxDevEvents->aucDigits,pxDpEvent->ucNumDgts);
		pxDpEvent->aucDgtInfo[pxDpEvent->ucNumDgts] = '\0';		
		++ucEventCnt;
	}

	if( IFX_FXS_CHECKFLAG(pxDevEvents->uiEvents, IFX_MMGR_EVENT_ONHOOK) )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "ON-HOOK Event Received" ); 
		xEventInfo.eEvent = IFX_FXS_EVT_OnHk;
		++ucEventCnt;
	}

	if( IFX_FXS_CHECKFLAG(pxDevEvents->uiEvents, IFX_MMGR_EVENT_FAXMODEM_CED ) 
		//							||
		//	IFX_FXS_CHECKFLAG(pxDevEvents->uiEvents, IFX_MMGR_EVENT_FAXMODEM_DIS) 
									)
	{
		 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "FAX CED/DIS Event Received" ); 
		xEventInfo.eEvent = IFX_FXS_EVT_FaxCEDEvent;
		++ucEventCnt;
	}

	if( IFX_FXS_CHECKFLAG(pxDevEvents->uiEvents, IFX_MMGR_EVENT_FAXMODEM_CNGFAX ) )
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "FAX CNG Event" );
		xEventInfo.eEvent = IFX_FXS_EVT_FaxCNGEvent;
		++ucEventCnt;
	}
	
	if( xEventInfo.eEvent != IFX_FXS_EventMax )
	{
		IFX_FXS_FxsFsmHdlr(pxEndptInfo,&xEventInfo,&eReason);
	}
#if 0
	else
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Unknown Event" );
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
			"Received Event", pxDevEvents->uiEvents);
	}
#endif

	return IFX_SUCCESS;
}

/*
 * This is timer callback function. 
 * Verify that endpoint is running. This is to ensure that if endpoint FSM
 * shuts down before timer fires. If endpoint id is valid, invoke the endpoint
 * FSM handler.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
STATIC void IFX_FXS_TimerFired(
	           IN uint32 uiTimerId,
	           IN void* pvPrivateData)
{
	x_IFX_FXS_TimerEvent* pxTimerEvent;
	x_IFX_FXS_EventInfo xEventInfo = {0};
	e_IFX_ReasonCode reason;

	pxTimerEvent = (x_IFX_FXS_TimerEvent*)(pvPrivateData);

 	IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
		pxTimerEvent->pxEndptInfo->szEndPointId, 
		IFX_FXS_GetEventStr(pxTimerEvent->eTimerEvent)); 

	if( strlen(pxTimerEvent->pxEndptInfo->szEndPointId) )
	{	
		xEventInfo.eEvent = pxTimerEvent->eTimerEvent;
		xEventInfo.uiId = uiTimerId;
		IFX_FXS_FxsFsmHdlr(pxTimerEvent->pxEndptInfo,&xEventInfo,&reason);
	}
	return ;
}

/*******************************************************************************
 *  Function Name   : IFX_FXS_ExecuteDialPlanAction
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : 
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ExecuteDialPlanAction(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	                      IN char8* pszDialOut,
												IN e_IFX_DP_Action eDpAction,
	                      OUT e_IFX_MMGR_ToneType* peToneType,
	                      OUT e_IFX_FXS_State* peState
	                      )
{
	x_IFX_CMGR_AddressInfo* pxDialedAddr = NULL;
	x_IFX_CMGR_AddressInfo xCmgrAddr;
	x_IFX_CalledAddr xAddress;

	char8 szTempDialOut[IFX_MAX_DIGITS];

	uchar8 ucChangeDefaultVL=0;
	uchar8 ucAction = 0;
	uint16 unTimeOut = 0;
	boolean bEmergencyCall = IFX_FALSE;
	boolean bMakeCall = IFX_FALSE;
	boolean bEnable = IFX_FALSE;
	boolean bRunDpPlan = IFX_FALSE;
  
	e_IFX_CMGR_Status  eStatus;
	e_IFX_TransferStatus eTxStatus;
	e_IFX_ReasonCode eReason;
	e_IFX_Return eRet = IFX_FAILURE;
	e_IFX_CMGR_FeatStatus eCidStatus = IFX_CMGR_DONT_CARE;

	*peToneType = IFX_MMGR_MAX_TONE;
	*peState = IFX_FXS_STATE_MAX;

	memset(&xCmgrAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
	/*  IFX_DP_CALLWAITING_PERCALL_ACTV - not supported */

	/* Check if need to call IFX_DP_Match again. */
	if( IFX_DP_CALLWAITING_PERCALL_ACTV == eDpAction||
			IFX_DP_CALLWAITING_PERCALL_DEACTV == eDpAction ||
			IFX_DP_CID_BLOCK_PERCALL_DEACTV	== eDpAction ||
			IFX_DP_CID_BLOCK_PERCALL_ACTV == eDpAction )
	{
		bRunDpPlan = IFX_TRUE;
	}
	else if(IFX_DP_NON_DEFAULT_VL_DIAL == eDpAction)
	{	
		/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Dial Through Non Default Voice Line"); */
		ucChangeDefaultVL = pszDialOut[0];
		pszDialOut++;
		bRunDpPlan =  (strlen(pszDialOut) > 0 )?IFX_TRUE:IFX_FALSE ;
	}

	if( bRunDpPlan )
	{
		x_IFX_DP_Rule xDpRule;

		strcpy(szTempDialOut,pszDialOut);
		eRet = IFX_DP_Match(szTempDialOut, IFX_TRUE, &ucAction, pszDialOut, 
												&xDpRule, &unTimeOut );
		if( IFX_SUCCESS != eRet || (IFX_DP_DIALOUT != ucAction ) )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, "Dial Plan Error");
			return IFX_FAILURE;
		}

		if( IFX_DP_CALLWAITING_PERCALL_DEACTV == eDpAction )
			IFX_FXS_SetEndpointFlag(pxEndptInfo, IFX_FXS_REJECT_WAITING_CALL);
		else if( IFX_DP_CID_BLOCK_PERCALL_ACTV == eDpAction ) 
			eCidStatus = IFX_CMGR_DISABLE; 
		else if( IFX_DP_CID_BLOCK_PERCALL_DEACTV == eDpAction )
			eCidStatus = IFX_CMGR_ENABLE; 
		
		eDpAction = xDpRule.eAction;
	}
	
	/* 
	 * IFX_DP_CALLWAITING_REJECT is hanlded in call waiting state ( see 
	 * IFX_FXS_CwInterDigitTimerExpiryHdlr )
	 */
	eRet = IFX_FAILURE;
	switch( eDpAction )
	{
	 case IFX_DP_ANON_CALLBLOCK_ACTV:
	 case IFX_DP_ANON_CALLBLOCK_DEACTV:
		 { 
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, 
					"DP Action : Anonymous Call block Enable/Disable");
			 /* Activate or deactivate anonymous call block */
			 bEnable = ( IFX_DP_ANON_CALLBLOCK_ACTV == eDpAction )?IFX_TRUE:IFX_FALSE;
			 if( IFX_SUCCESS == (eRet = 
				   IFX_CIF_EndptAnonymousCallBlockSet(pxEndptInfo->szEndPointId,
					 bEnable,&eReason)) )
			 {
				 *peToneType = IFX_MMGR_CONFIRMATION_TONE;
				 *peState = IFX_FXS_STATE_BUSY;
			 }

			 break;
		 }
	 case IFX_DP_AUTO_REDIAL_ACTV:
	 case IFX_DP_AUTO_REDIAL_DEACTV:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,	IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, 
					"DP Action : Auto Redail Activate/DeActivate");
			 /* Activate or deactivate auto redial. This action is allowed only if
				* last dialed number is VoIP address.
				*/
			 bEnable = 
				 (IFX_DP_AUTO_REDIAL_ACTV == eDpAction )?IFX_TRUE:IFX_FALSE;
				
			 eRet = IFX_FXS_ActDeActvAutoRedial(pxEndptInfo, bEnable, peToneType, 
								peState );
			 break;
		 }
	 case IFX_DP_DND_ACTV:
	 case IFX_DP_DND_DEACTV:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, "DP Action : DND Enable/Dissble");
			 /* Activate/deactivate DND */
			 bEnable = ( IFX_DP_DND_ACTV == eDpAction )?IFX_TRUE:IFX_FALSE;
			 if( IFX_SUCCESS == (eRet = IFX_CIF_EndptDNDStatusSet(
						pxEndptInfo->szEndPointId, bEnable,&eReason)) )
			 {
				 *peToneType = IFX_MMGR_CONFIRMATION_TONE;
				 *peState = IFX_FXS_STATE_BUSY;
			 }
			 break;
		 }
	 case IFX_DP_CALLWAITING_ACTV:
	 case IFX_DP_CALLWAITING_DEACTV:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,
					"DP Action : Call Waiting Activate/DeActivate");
			 /* Activate/Deactivate call waiting */
			 bEnable = 
				 ( IFX_DP_CALLWAITING_ACTV == eDpAction )?IFX_TRUE:IFX_FALSE;
			 if( IFX_SUCCESS == (eRet = IFX_CIF_EndptCallWaitingSet(
					 pxEndptInfo->szEndPointId, bEnable,&eReason)) )
			 {
				 *peToneType = IFX_MMGR_CONFIRMATION_TONE;
				 *peState = IFX_FXS_STATE_BUSY;
			 }

			 break;
		 }
	 case	IFX_DP_UNC_CFWD_ACTV:
	 case	IFX_DP_UNC_CFWD_DEACTV:
	 case	IFX_DP_BUSY_CFWD_ACTV:
	 case	IFX_DP_BUSY_CFWD_DEACTV:
	 case	IFX_DP_NOANS_CFWD_ACTV:
	 case	IFX_DP_NOANS_CFWD_DEACTV:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,
					"DP Action : Call Forward Activate/DeActivate");
			 if( IFX_SUCCESS == 
				 (eRet = IFX_FXS_SetCallForward(pxEndptInfo, eDpAction, pszDialOut)) )
			 {
				 *peToneType = IFX_MMGR_CONFIRMATION_TONE;
				 *peState = IFX_FXS_STATE_BUSY;
			 }

			 break;
		 }
	 case	IFX_DP_CID_BLOCK_ACTV:
	 case	IFX_DP_CID_BLOCK_DEACTV:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,
					"DP Action : CID Activate/DeActivate");
			 bEnable = 
				 (IFX_DP_CID_BLOCK_ACTV == eDpAction )?IFX_FALSE:IFX_TRUE;
			 if( IFX_SUCCESS == (eRet = IFX_CIF_EndptCidStatusSet(
					 pxEndptInfo->szEndPointId, bEnable,&eReason)) )
			 {
				 *peToneType = IFX_MMGR_CONFIRMATION_TONE;
				 *peState = IFX_FXS_STATE_BUSY;
			 }

			 break;
		 }
#if 0
   /*The rule is currently being used for Star Dialing. Enabling this could corrupt rc.conf if line
     is not configured.*/
	 case IFX_DP_NON_DEFAULT_VL_DIAL:
		 {
		 		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId, "DP Action : Change Default Voice Line");
		 		if(	IFX_SUCCESS == (eRet = IFX_CIF_EndptDefaultVLSet(
						pxEndptInfo->szEndPointId, ucChangeDefaultVL, &eReason)))
				{
					*peToneType = IFX_MMGR_CONFIRMATION_TONE;
					*peState = IFX_FXS_STATE_BUSY;
				}
			 break;
		 }
#endif
	 case IFX_DP_BLIND_TX: /* blind transfer */
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, "DP Action : Blind Transfer");
				if( pxEndptInfo->pxActiveCall )
				{
					if( IFX_SUCCESS == 
						(eRet = IFX_FXS_BlindTransfer(pxEndptInfo, pszDialOut, &eTxStatus)) )
					{
						/*
						 * Check transfer status. If rejected/failed - return faiulure.
						 * If answered - set peToneType to confirmation tone and peState to
						 * busy, release call. Else transfer is going on, wait for response and set call 
						 * state to IFX_FXS_CS_TX_INITIATED and set endpoint flag
						 * IFX_FXS_TRANSFER_INITIATED.
						 */
						if( IFX_CMGR_TRANSFER_REJECTED == eTxStatus || 
							IFX_CMGR_TRANSFER_FAILED == eTxStatus )
						{
							IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndPointId,"Blind TX Failed");
							eRet = IFX_FAILURE;
						}
						else if( IFX_CMGR_TRANSFER_ANSWERED == eTxStatus )
						{
							IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndPointId,"Blind TX Success");
#if 0 
							/* This code is not needed...b'coz call manager release call before 
			 				   sending Btx success status */
							IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
																	 IFX_TERMINATED, NULL, NULL, &eReason); 
							IFX_FXS_ReleaseCall(pxEndptInfo, pxEndptInfo->pxActiveCall);
#endif
							IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);
							*peToneType = IFX_MMGR_CONFIRMATION_TONE;
							*peState = IFX_FXS_STATE_BUSY;
						}
						else
						{
							/* Transfer is going on..wait for response */
							IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndPointId,"Blind TX Pending");
							IFX_FXS_UpdateCallState(pxEndptInfo,pxEndptInfo->pxActiveCall,
																			IFX_FXS_CS_TX_INITIATED);
							IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_TRANSFER_INITIATED);
						}
					}
				}
			 break;
		 }
	#ifdef DIAL_PLAN_REMOVE 
	case IFX_DP_PSTN_HOOKFLASH: /* PSTN hook flash */
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, "DP Action : PSTN Hook-Flash");
			 /*
			  * If call is PSTN, resume call, send info to FXO and go to conversation state. 
			  */
			 if( pxEndptInfo->pxActiveCall && 
				 IFX_CMGR_TYPE_FXO == pxEndptInfo->pxActiveCall->eCallType )
			 {
					x_IFX_CMGR_AddressInfo xToAddr = {0};

					xToAddr.eAddressType = IFX_CMGR_TYPE_FXO;
					strcpy(xToAddr.uxAddressInfo.xFxoInfo.szFxoLineId, 
													pxEndptInfo->pxActiveCall->szCallInitrEndptId );
					xCmgrAddr.eAddressType = IFX_CMGR_TYPE_EXTN;
					strcpy(xCmgrAddr.uxAddressInfo.szEndptId, pxEndptInfo->szEndPointId);

			 		if( IFX_SUCCESS == 
							IFX_CMGR_InfoSnd(&xCmgrAddr,&xToAddr, NULL, 0, &eStatus, &eReason ) 
							&& IFX_CMGR_STATUS_SUCCESS == eStatus )
					{

						if( IFX_SUCCESS == IFX_CMGR_CallResume(
								pxEndptInfo->pxActiveCall->uiCallId, &eStatus, &eReason ) && 
								IFX_CMGR_STATUS_SUCCESS == eStatus )
						{
							IFX_FXS_UpdateCallState(pxEndptInfo,
								pxEndptInfo->pxActiveCall,IFX_FXS_CS_ACTIVE);
				  		eRet = IFX_SUCCESS;
				 			*peState = IFX_FXS_STATE_CONVERSATION; 
						}
#if 1 //Remove this block
						/* 
						 * IFX_CMGR_CallResume should never return pending status. 
						 * Pending status is not expected in this scenario. 
						 */
						if( IFX_CMGR_STATUS_PENDING == eStatus )
						{
			 				IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			 					pxEndptInfo->szEndPointId, 
								"Unexpected Status returned IFX_CMGR_CallResume for FXO Call");
						}
#endif
					}
					
					IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO, 
						pxEndptInfo->szEndPointId, 	( IFX_SUCCESS == eRet )?
						"PSTN Hook Flash:: SUCCESS":"PSTN Hook-Flash:: FAILED" );
			 }
			 break;
		 }
	 case IFX_DP_DEF_OUTBOUND_INTERFACE_VOIP:
	 case IFX_DP_DEF_OUTBOUND_INTERFACE_PSTN:
		 {
		 	 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,
					"DP Action : Default Outbund Interface set");

			 ucAction = (IFX_DP_DEF_OUTBOUND_INTERFACE_VOIP==eDpAction)?0:1;
			 if( IFX_SUCCESS == (eRet = IFX_CIF_DefaultOutBoundIfSet(
					pxEndptInfo->szEndPointId, ucAction,&eReason)) )
			 {
				 *peToneType = IFX_MMGR_CONFIRMATION_TONE;
				 *peState = IFX_FXS_STATE_BUSY;
			 }
			 
			 break;
		 }
#endif
	 case IFX_DP_DISCONNECT_LASTACTV_CALLL:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,"DP Action : Disconnect Last Active Call");
			 if( pxEndptInfo->pxActiveCall )
			 {
					eRet = IFX_CMGR_CallRelease(pxEndptInfo->pxActiveCall->uiCallId,
										IFX_TERMINATED, NULL, NULL, &eReason);
					IFX_FXS_ReleaseCall(pxEndptInfo,pxEndptInfo->pxActiveCall);
					IFX_FXS_GetLastHeldCall(pxEndptInfo,&pxEndptInfo->pxActiveCall);
					*peToneType = IFX_MMGR_CONFIRMATION_TONE;
				  *peState = IFX_FXS_STATE_BUSY;
					eRet = IFX_SUCCESS; /* Call release always treat as success */
			 }
			 break;
		 }
	 case IFX_DP_RESUME_LASTACTV_CALLL:
	 case IFX_DP_RESUME_NON_LASTACTV_CALLL:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,"DP Action : Resume Call");
			 x_IFX_FXS_CallInfo* pxTempCall ;

			 if( IFX_DP_RESUME_LASTACTV_CALLL == eDpAction)
				 pxTempCall =  pxEndptInfo->pxActiveCall;
			 else
			 {
				 if( pxEndptInfo->pxActiveCall == (pxEndptInfo->axFxsCallInfo + 0))
					 pxTempCall = (pxEndptInfo->axFxsCallInfo + 1);
				 else
					 pxTempCall = (pxEndptInfo->axFxsCallInfo + 0);
			 }

			 if( pxTempCall != NULL && IFX_FXS_CS_LOCAL_HELD == pxTempCall->eCallState )
			 {
					/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId,"Resuming Call"); */

					eRet = IFX_CMGR_CallResume(pxTempCall->uiCallId, &eStatus, &eReason );
					if( IFX_SUCCESS == eRet && IFX_CMGR_STATUS_FAIL != eStatus)
					{
				 		pxEndptInfo->pxActiveCall = pxTempCall;
						if( IFX_CMGR_STATUS_SUCCESS == eStatus )
						{
							IFX_FXS_UpdateCallState(pxEndptInfo,
									pxTempCall,IFX_FXS_CS_ACTIVE);
							*peState = IFX_FXS_STATE_CONVERSATION;
						}
						else if( IFX_CMGR_STATUS_PENDING == eStatus )
						{
							IFX_FXS_UpdateCallState(pxEndptInfo,
																			pxTempCall,IFX_FXS_CS_RESUME_INITIATED);
							IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_RESUME_INITIATED );
						}
					}
					else
					{
						IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndPointId,"Resuming Call Failed");
						eRet = IFX_FAILURE;
					}
			 }
			 break;
		 }
	 case IFX_DP_CONFERENCE:
		 {
			 uint32 auiConfIds[IFX_MAX_FXS_CALLS];
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, "DP Action : Initiate Conference");
			 /* 
			  * Check if endpoint has two calls. If not ignore it. Else initiate 
				* conference. If conference status is success, mark both the calls
				* as active and move to conversation state. If status is pending set
				* IFX_FXS_CONFERENCE_INITIATED flag and stay in dialing state.
				* If error play error tone move to busy state.
			  */
			 if( IFX_FXS_CS_LOCAL_HELD != pxEndptInfo->axFxsCallInfo[0].eCallState ||
					IFX_FXS_CS_LOCAL_HELD != pxEndptInfo->axFxsCallInfo[1].eCallState )
			 {
					IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndPointId,"Can not make conference");
				 	eRet = IFX_FAILURE;
			 }
			 else
			 {
					/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndPointId,"Initiating conference"); */
				 	auiConfIds[0] = pxEndptInfo->axFxsCallInfo[0].uiCallId;
				 	auiConfIds[1] = pxEndptInfo->axFxsCallInfo[1].uiCallId;

				 	if( (IFX_SUCCESS == IFX_CMGR_ConfMake(auiConfIds, 2,
				 		    &pxEndptInfo->uiConfReqId, &eStatus, &eReason, pxEndptInfo)) &&
								IFX_CMGR_STATUS_FAIL != eStatus )
				  {
						eRet = IFX_SUCCESS;
						if( IFX_CMGR_STATUS_SUCCESS == eStatus )
						{
							IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndPointId,"Conference is active");
						 	IFX_FXS_UpdateCallState(pxEndptInfo, (pxEndptInfo->axFxsCallInfo+0),
									IFX_FXS_CS_ACTIVE );
						 	IFX_FXS_UpdateCallState(pxEndptInfo, (pxEndptInfo->axFxsCallInfo+1),
									IFX_FXS_CS_ACTIVE );
						 	*peState = IFX_FXS_STATE_CONFERENCE;
					 	}
					  else if( IFX_CMGR_STATUS_PENDING == eStatus )
						{
							IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_CONFERENCE_INITIATED);
					 	}
				 	}
				 	else
				 	{
						IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndPointId,"IFX_CMGR_ConfMake Failed");
						eRet = IFX_FAILURE;
				  }
			 }
			 break;
		 }
	 case IFX_DP_CALL_RETURN: /* call return */
		 {
		 		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId, "DP Action : Call Return");
				if(	IFX_SUCCESS == IFX_CIF_CallReturnAddrGet(
						pxEndptInfo->szEndPointId, &xCmgrAddr, &eReason ) )
				{
			 		bMakeCall = IFX_TRUE;
					memcpy(&pxEndptInfo->xLastDialedAddr,&xCmgrAddr,sizeof(xCmgrAddr));
					pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
				}
			 break;
		 }
	 case IFX_DP_VOICEMAIL_RETRIVAL: /* voice mail retrieval */
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, "DP Action : Voice Mail Retrieve");
			 if( IFX_SUCCESS == IFX_CIF_EndptVMRetrievalAddrGet(
					 pxEndptInfo->szEndPointId, &xAddress, &eReason ) )
			 {
					bMakeCall = IFX_TRUE;
					/* Note that voice mail address is not used for auto redial */
					pxDialedAddr = &xCmgrAddr;
					memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
					pxDialedAddr->eAddressType = IFX_CMGR_TYPE_VOIP;
					memcpy(&pxDialedAddr->uxAddressInfo.xVoipAddr,
								 &xAddress,sizeof(x_IFX_CMGR_VoipAddr));
			 }
			 break;
		 }
	 case IFX_DP_SPEED_DIAL:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, "DP Action : Dial Through Address Book");
			 
			 if( IFX_SUCCESS == IFX_CIF_AddrBookEntryGet(pszDialOut, 
					 &pxEndptInfo->xLastDialedAddr, &eReason))
			 {
				 bMakeCall = IFX_TRUE;
				 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
			 }
			 break;
		 }
#ifdef DIAL_PLAN_REMOVE	
	 case IFX_DP_DIRECT_IP_CALLS:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,"DP Action : Direct IP Dialing");
			 strcpy(szTempDialOut, pszDialOut);
			 if( IFX_SUCCESS !=  (eRet = IFX_ConvertIPAddr(szTempDialOut, pszDialOut)))
				 break;
		 }
	 case IFX_DP_SERV_SIDE_CFG:
	 case IFX_DP_LOCAL_VOIP_CALLS:
	 case IFX_DP_ISD_VOIP_CALLS:
	 case IFX_DP_STD_VOIP_CALLS:
		 {
			 char8* pszDomain;
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,"DP Action : Initiating VoIP Call"); 
			 IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, pszDialOut);

			 bMakeCall = IFX_TRUE;
			 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;

			 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_VOIP;

			 memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			 pszDomain = strchr(pszDialOut,'@');
			 if( pszDomain )
			 {
					strncpy(pxDialedAddr->uxAddressInfo.xVoipAddr.acUserName,pszDialOut, 
							pszDomain-pszDialOut);
					pxDialedAddr->uxAddressInfo.xVoipAddr.acUserName
																			[pszDomain-pszDialOut] = '\0';
					++pszDomain;
			 		pxDialedAddr->uxAddressInfo.xVoipAddr.ucAddrType = 
				 		((IFX_DP_DIRECT_IP_CALLS == eDpAction)?IFX_IP_ADDR:IFX_SIP_URL);
			 		strcpy(pxDialedAddr->uxAddressInfo.xVoipAddr.acCalledAddr, pszDomain); 
			 }
			 else
			 { //If no domain name, use Voip Address type as IFX_EXTN
			 	 pxDialedAddr->uxAddressInfo.xVoipAddr.ucAddrType = 
				 		((IFX_DP_SERV_SIDE_CFG == eDpAction)?IFX_EXTN:IFX_TEL_NUM);
				 strcpy(pxDialedAddr->uxAddressInfo.xVoipAddr.acUserName,pszDialOut);
			 		pxDialedAddr->uxAddressInfo.xVoipAddr.acCalledAddr[0]='\0';
			 }
			 
			 break;
		 }
#endif
	 case IFX_DP_EMERGENCY_CALLS:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_LOW, IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndPointId , 
								"DP Action : Initiating Emergency Call" );
			 IFX_FXS_SetEndpointFlag(pxEndptInfo, IFX_FXS_EMG_CALL_PROCEEDING);
			 bEmergencyCall = IFX_TRUE;
		 }
	 case IFX_DP_TWO_STAGE_PSTN_DIALING:
	 case IFX_DP_LOCAL_PSTN_CALLS:
	#ifdef DIAL_PLAN_REMOVE
	 case IFX_DP_STD_PSTN_CALLS:
	 case IFX_DP_ISD_PSTN_CALLS:
	#endif
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
                 pxEndptInfo->szEndPointId, "ACTION : Initiating FXO Call" );
			 
			 bMakeCall = IFX_TRUE;
			 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
			 memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_FXO;
			 strcpy(pxDialedAddr->uxAddressInfo.xFxoInfo.szPhoneNumber, pszDialOut);
			 break;
		 }
	 case IFX_DP_DIALDEFAULT_DEF_IF:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,
					"DP Action : Dial Using Default Outbound Interface");
			 if( IFX_SUCCESS == IFX_CIF_DefaultOutBoundIfGet(
						pxEndptInfo->szEndPointId, &ucAction, &eReason) )
			 {
				 bMakeCall = IFX_TRUE;
				 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
				 memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));

				 if( ucAction )
				 {
					 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_FXO;
					 strcpy(pxDialedAddr->uxAddressInfo.xFxoInfo.szPhoneNumber, pszDialOut);
				 }
				 else
				 {
					 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_VOIP;
					 pxDialedAddr->uxAddressInfo.xVoipAddr.ucAddrType = IFX_TEL_NUM;
					 strcpy(pxDialedAddr->uxAddressInfo.xVoipAddr.acUserName, pszDialOut);
				 }
			 }
			 break;
		 }
	 case IFX_DP_EXTENSION_DIAL:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, "DP Action : Initiating Extension Call");
			 bMakeCall = IFX_TRUE;
			 pxDialedAddr = &pxEndptInfo->xLastDialedAddr;
			 memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			 pxDialedAddr->eAddressType = IFX_CMGR_TYPE_EXTN;
			 strcpy(pxDialedAddr->uxAddressInfo.szEndptId, pszDialOut);
			 break;
		 }
#ifdef ENABLE_DBG_THR_PHONE
	 case IFX_DP_ENABLE_DEBUGS:
	 case IFX_DP_DISABLE_DEBUGS:
		 { 
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_NONE, IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, 
					(eDpAction == IFX_DP_ENABLE_DEBUGS)?
										"DP Action : Enable Debugs":"DP Action : Disable Debugs");
			 if(IFX_SUCCESS == (eRet = 
				 IFX_CIF_DebugSet((eDpAction == IFX_DP_ENABLE_DEBUGS)?IFX_TRUE:IFX_FALSE)))
			 {
				 *peToneType = IFX_MMGR_CONFIRMATION_TONE;
				 *peState = IFX_FXS_STATE_BUSY;
			 }
			 break;	
		 }
#endif
#ifdef DELAYED_HOTLINE
	 case IFX_DP_DHL_ACTV:
	 case IFX_DP_DHL_DEACTV:
		 {
			 IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId, "DP Action : Delayed Hotline Enable/Dissble");
			 /* Activate/deactivate DHL */
			bEnable = ( IFX_DP_DHL_ACTV == eDpAction )?IFX_TRUE:IFX_FALSE;
			if( IFX_SUCCESS == (eRet = IFX_CIF_EndptDhlInfoSet(
						pxEndptInfo->szEndPointId, bEnable,pszDialOut,&eReason)) )
			{
				*peToneType = IFX_MMGR_CONFIRMATION_TONE;
				*peState = IFX_FXS_STATE_BUSY;
			}
			break;
		 }
#endif
	 default:
		 {
			 IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			 		pxEndptInfo->szEndPointId,"Unknown Dial Plan Action");
		 }
	} /* switch */

	/* 
	 * If bMakeCall is true need to initiate call. Before initiating call, If 
	 * auto redial was requested by user, cancel it. Check outgoing call bar for
	 * non-emergency calls. Don't make call if outgoing calls are barred. If 
	 * outgoing calls are not bared, initiate call. If initiate call fails, 
	 * return failure. On success, move to ringback state if remote endpoint 
	 * status is ringing or else move to conversation state.
	 *
	 * If call is not initiated or failed, reset emergency & reject waiting call 
	 * flag if set
	 */
	if( bMakeCall )
	{
		boolean bOutCallBar = IFX_FALSE;
		if( IFX_FXS_CheckEndpointFlag(pxEndptInfo, IFX_FXS_AUTOREDIAL_ACTIVE_OUT) )
		{
			IFX_FXS_ActDeActvAutoRedial(pxEndptInfo, IFX_FALSE, peToneType, peState );
			*peToneType = IFX_MMGR_MAX_TONE;
			*peState = IFX_FXS_STATE_MAX;
		}

		/* Check outgoing call bar, except emergency & extension calls */
		if( IFX_FALSE == bEmergencyCall && IFX_DP_EXTENSION_DIAL != eDpAction) {
						
			IFX_CIF_OutgoingCallBlockCheck(pxEndptInfo->szEndPointId, 
																		&bOutCallBar, &eReason);
		}

		if( IFX_FALSE == bOutCallBar )
		{
			uchar8 ucOrgDefaultVL = 0;
			eRet = IFX_SUCCESS;

			if( ucChangeDefaultVL )
			{
				/* 
				 * Set default voice line to ucChangeDefaultVL and after initiating
				 * call change back to actual default voice line.
				 */
				IFX_CIF_EndptDefaultVLGet(pxEndptInfo->szEndPointId, 
																				&ucOrgDefaultVL, &eReason);
				eRet = IFX_CIF_EndptDefaultVLSet(pxEndptInfo->szEndPointId, 
																				ucChangeDefaultVL, &eReason);
			}

			if( IFX_SUCCESS == eRet &&
					IFX_SUCCESS == (eRet = IFX_FXS_InitiateCall(pxEndptInfo, 
					pxDialedAddr, eCidStatus,	bEmergencyCall,	&eStatus, &eReason)) )
			{
				if( IFX_CMGR_STATUS_FAIL == eStatus )
					eRet = IFX_FAILURE;
				else if( IFX_CMGR_STATUS_SUCCESS == eStatus )
				{
					*peState = IFX_FXS_STATE_CONVERSATION;
				}
				else if( IFX_ENDPOINT_RINGING == eReason )
				{
					*peToneType = IFX_MMGR_RING_BACK_TONE,
					*peState = IFX_FXS_STATE_RINGBACK;
				}
				else
				{
					IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_INITIATED);
				}
			}

			if( ucOrgDefaultVL )
			{ /* Change back to actual default voice line */
				IFX_CIF_EndptDefaultVLSet(pxEndptInfo->szEndPointId, 
																									ucOrgDefaultVL, &eReason);
			}
		} /* bOutCallBar */
		else
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
									 pxEndptInfo->szEndPointId, "Outgoing Call Bar Enabled" );
			memset(pxDialedAddr,0,sizeof(x_IFX_CMGR_AddressInfo));
			/* Set to non-voip call, so that user can not do auto redial request */
			pxDialedAddr->eAddressType = IFX_CMGR_TYPE_EXTN;
			eRet = IFX_FAILURE;
		}

		if( IFX_SUCCESS != eRet )
		{
			IFX_FXS_ResetEndpointFlag(pxEndptInfo, (IFX_FXS_EMG_CALL_PROCEEDING|
																							IFX_FXS_REJECT_WAITING_CALL) );
		}
	} /* bMakeCall */

	pxEndptInfo->szDialledDigits[0] = '\0'; /* Clear collected digits */
	return eRet;
}

/*	
 * This routine is used to initiate call for a given FXS endpoint.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_InitiateCall(
	                   IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
										 IN x_IFX_CMGR_AddressInfo* pxDialedAddr,
										 e_IFX_CMGR_FeatStatus eCidStatus,
	                   IN boolean bEmergencyCall,
	                   OUT e_IFX_CMGR_Status* peStatus,
	                   OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxNewCall;
	x_IFX_CMGR_AddressInfo xFrom ={0};
	x_IFX_CMGR_CallParams xCallParams = {0};
	e_IFX_FXS_CallState eCallState;
	uint32 uiCallId;

	e_IFX_Return eRet = IFX_FAILURE;

	if( bEmergencyCall )
	{
		/* Release all calls */
		//Pending: release all calls? Waiting for Narendra's response.
	}
	
	/* Get free call info */
	IFX_FXS_GetFreeCallInfo(pxEndptInfo, &pxNewCall);
	
	if( pxNewCall )
	{
		/* Fill from endpoint id */
		xFrom.eAddressType = IFX_CMGR_TYPE_EXTN;
		strcpy(xFrom.uxAddressInfo.szEndptId, pxEndptInfo->szEndPointId);
	
		/* set call params */
		xCallParams.eAgentType = IFX_CMGR_TYPE_EXTN;
		xCallParams.uxCallParams.xExtnParams.eCallerIdStatus = eCidStatus;
		xCallParams.uxCallParams.xExtnParams.bEmergency = bEmergencyCall;

		/* Get wideband capability of endpoint */
		xCallParams.uxCallParams.xExtnParams.bWideBandCapable = IFX_FALSE;
		IFX_CIF_FxsWidebandCapablityCheck(pxEndptInfo->szEndPointId,
			&(xCallParams.uxCallParams.xExtnParams.bWideBandCapable),peReason );

		eRet = IFX_CMGR_CallInitiate( &uiCallId,  &xFrom, 
							pxDialedAddr,	&xCallParams,	peStatus,	peReason,	pxEndptInfo );
		if( IFX_SUCCESS == eRet )
		{
			IFX_FXS_SetEndpointFlag(pxEndptInfo, IFX_FXS_ORIGINATOR);
			if( IFX_CMGR_STATUS_FAIL == (*peStatus) )
			{
				IFX_DBGC(vucFxsAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId, "Could Not Initiate Call: Status=Fail");
				eRet = IFX_FAILURE;
			}
			else
			{
				pxEndptInfo->pxActiveCall = pxNewCall;
				pxNewCall->uiCallId = uiCallId;
				pxNewCall->eCallType = pxEndptInfo->xLastDialedAddr.eAddressType;

				IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
 								pxEndptInfo->szEndPointId, "Call Initiate Success");
				eCallState = IFX_FXS_CS_CALL_INITIATED;
				if( IFX_CMGR_STATUS_SUCCESS == (*peStatus))
					eCallState = IFX_FXS_CS_ACTIVE;
				else
				{
					eCallState = ((IFX_ENDPOINT_RINGING == *peReason)?
																			IFX_FXS_CS_RINGING:IFX_FXS_CS_CALL_INITIATED);
				}
				
				IFX_FXS_UpdateCallState(pxEndptInfo,pxNewCall,eCallState);
			}
		}
		else
		{
			/* debug - failed to initiate call */
			IFX_DBGC(vucFxsAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId, "Could Not Initiate Call" );
		}
	}
	else
	{
		/* debug -- endpoint has max calls. */
		IFX_DBGA(vucFxsAgnetModId, IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId, 
				"Could Not Initiate Call -- FXS Has Max Calls");
	}

	return eRet;
}

/*
 * This routine does blind transfer of endpoint's active call.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_BlindTransfer(
	                   IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	                   IN char8* szDialOut,
										 OUT e_IFX_TransferStatus* peTxState )
{
	return IFX_AGU_BlindTransfer(pxEndptInfo->szEndPointId, 
								pxEndptInfo->pxActiveCall->uiCallId, 
								szDialOut, 
								vucFxsAgnetModId, 
								peTxState);
}

/*
 * This routine activates or de-activates auto redial subscription.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ActDeActvAutoRedial(
	                   IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
										 IN boolean bEnable,
	                   OUT e_IFX_MMGR_ToneType* peToneType,
	                   OUT e_IFX_FXS_State* peState )
{
	x_IFX_CMGR_AddressInfo xFromAddr;
	e_IFX_CMGR_Status  eStatus;
	e_IFX_ReasonCode eReason;
	e_IFX_Return eRet = IFX_FAILURE;

	if( IFX_CMGR_TYPE_VOIP == pxEndptInfo->xLastDialedAddr.eAddressType )
  {
		if( bEnable )
		{
		  eRet = (0 == pxEndptInfo->uiAutoRedialOutReqId )?IFX_SUCCESS:IFX_FAILURE;
		}
	  else
		{
		  eRet = (0 == pxEndptInfo->uiAutoRedialOutReqId  )?IFX_FAILURE:IFX_SUCCESS;
		  IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_OUT);
		}

	  if( IFX_SUCCESS == eRet )
		{
			xFromAddr.eAddressType = IFX_CMGR_TYPE_EXTN;
		  strcpy(xFromAddr.uxAddressInfo.szEndptId,pxEndptInfo->szEndPointId);
		 
		  if( IFX_SUCCESS == (eRet = IFX_CMGR_ARD_Activate(	&pxEndptInfo->xLastDialedAddr,
								&xFromAddr, bEnable, &pxEndptInfo->uiAutoRedialOutReqId,
								&eStatus, &eReason, pxEndptInfo)) ) 
			{
			  if( bEnable )
				{
				  if( IFX_CMGR_STATUS_PENDING == eStatus )
					{
						IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
							pxEndptInfo->szEndPointId,"Auto Redial Initiated: Status=PENDING");
					  IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_INITIATED);
					}
				  else
					{
					  *peToneType = (IFX_CMGR_STATUS_SUCCESS == eStatus)?
					  								IFX_MMGR_CONFIRMATION_TONE:IFX_MMGR_ERROR_TONE;
					  *peState = IFX_FXS_STATE_BUSY;
					  if( IFX_CMGR_STATUS_SUCCESS == eStatus )
						  IFX_FXS_SetEndpointFlag(pxEndptInfo, IFX_FXS_AUTOREDIAL_ACTIVE_OUT);
						else
						{
							IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
								pxEndptInfo->szEndPointId,"Could Not Initiate Auto Redial");
							eRet = IFX_FAILURE;
						}
					}
				}
				else
				{
					IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
						pxEndptInfo->szEndPointId, "Canceled Auto Redial Request");
					pxEndptInfo->uiAutoRedialOutReqId = 0;
					*peToneType = IFX_MMGR_CONFIRMATION_TONE;
					*peState = IFX_FXS_STATE_BUSY;
				}
			}
		  else
			{
				/* If failed, in either case request id is invalid */
				IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
					pxEndptInfo->szEndPointId,"Auto Redial Activation/Deactivation Failed");
			  pxEndptInfo->uiAutoRedialOutReqId = 0; 
			}
		}
	}
	else
	{	
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId, "Last Dialed Number Is Not A VoIP Call");
	}

	return eRet;
}

/*
 * This function activate/deactivate call forward on default voice line of the
 * endpoint 
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_SetCallForward(
	                   IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
										 IN e_IFX_DP_Action eDpAction,
										 IN char8* szDialOut )
{
	return IFX_AGU_SetCallForward(pxEndptInfo->szEndPointId, eDpAction,
									szDialOut, vucFxsAgnetModId);
}

/*
 * Call this API to get dial tone to be played by endpoint.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_MMGR_ToneType IFX_FXS_GetDialToneType(
	                          IN char8* szEndpointId, 
	                          OUT uint16* punTimeOut)
{
	boolean bEnable = IFX_FALSE;
	e_IFX_ReasonCode eFailReason;
	e_IFX_MMGR_ToneType eToneType = IFX_FXS_UNREG_DIAL_TONE;

	*punTimeOut = vunDialToneLength;

	IFX_CIF_EndptDefaultVLRegStatusCheck(szEndpointId,&bEnable,&eFailReason);

	if( bEnable )
	{
		IFX_CIF_EndptVMStatusCheck(szEndpointId,&bEnable,&eFailReason);
		if( bEnable )
		{
			eToneType = IFX_MMGR_STUTTER_DIAL_TONE;
			*punTimeOut = IFX_STTR_TONE_DURATION;
		}
		else
		{
			eToneType = IFX_FXS_REG_DIAL_TONE;
			/* Register tone and dial tone timer values are same */ 
			/* punTimeOut = vunDialToneLength; */ 
		}	
	}

	return eToneType;
}

/*
 * This routine starts tone and timer for given FXS endpoint.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_StartTone(
	                   IN x_IFX_FXS_EndptFsmInfo* pxEndPtInfo,
	                   IN e_IFX_MMGR_ToneType eToneType,
										 IN uint32 unTimeOut,
	                   IN e_IFX_FXS_Event eEventOnExpiry,
	                   IN x_IFX_MMGR_CidParams* pxCidparams,
	                   IN_OUT uint32* puiTimerId )
{
	x_IFX_FXS_TimerEvent xTimerEvent;
	e_IFX_Return eRet = IFX_FAILURE;

	if( IFX_MMGR_SUCCESS == 
		IFX_MMGR_TonePlay(pxEndPtInfo->szEndPointId,eToneType,pxCidparams ) )
	{
		eRet = IFX_SUCCESS;
		if( unTimeOut )
		{
			*puiTimerId = 0;
			xTimerEvent.eTimerEvent = eEventOnExpiry;
			xTimerEvent.pxEndptInfo = pxEndPtInfo;
			if( IFX_SUCCESS != (eRet = IFX_TIM_TimerStart(unTimeOut,&xTimerEvent,
					sizeof(xTimerEvent), IFX_FXS_TimerFired,puiTimerId) ) ) 
			{
				IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
					 "Could Not Start Timer");
				/* Could not start timer, stop tone */
				IFX_MMGR_ToneStop(pxEndPtInfo->szEndPointId);
			}
		}
	}
	else
	{
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
			 "Could Not Play Tone");
	}
	return eRet;
}

/*
 * This routine stops tone and timer of a given FXS endpoint.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_StopTone(IN x_IFX_FXS_EndptFsmInfo* pxEndPtInfo,
	               IN_OUT uint32* puiTimerId)
{
	e_IFX_Return eRet = IFX_SUCCESS; 
	
	if( IFX_MMGR_SUCCESS !=	IFX_MMGR_ToneStop(pxEndPtInfo->szEndPointId) )
		eRet = IFX_FAILURE;

	if( puiTimerId ) 
	{
		IFX_TIM_TimerStop(*puiTimerId);
		*puiTimerId = 0; 
	}

	return eRet;
}

/*
 * Call this routine to get endpoint info using endpoint id.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_GetEndpointInfo(IN char8* szEndpointId,
																 OUT x_IFX_FXS_EndptFsmInfo **ppxEndPtInfo)
{
	*ppxEndPtInfo = 0;
	if( strcmp(vaxFxsEndptFsmInfo[0].szEndPointId,szEndpointId) == 0 )
		*ppxEndPtInfo = (vaxFxsEndptFsmInfo+0);
	else if(strcmp(vaxFxsEndptFsmInfo[1].szEndPointId,szEndpointId) == 0)
		*ppxEndPtInfo = (vaxFxsEndptFsmInfo+1);

	return ((*ppxEndPtInfo)?IFX_SUCCESS:IFX_FAILURE);
}

/*
 * This routine sends auto redial notification and clears auto redial 
 * subscription related parameters.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_SendAutoRedialNtfy(
	                      IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	                      IN boolean bNotify)
{
	e_IFX_Return eRet = IFX_SUCCESS;

	/* 
	 * Check if uiAutoRedialInReqId is valid. If valid send notification and 
	 * clear parameters.
	 */
	if( pxEndptInfo->uiAutoRedialInReqId )
	{
		if(IFX_SUCCESS != (eRet=IFX_CMGR_ARD_Ntf(pxEndptInfo->uiAutoRedialInReqId,
			 (bNotify)?IFX_CMGR_STATUS_SUCCESS:IFX_CMGR_STATUS_FAIL)) )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Could Not Send Auto Redial Notify");
		}

		pxEndptInfo->uiAutoRedialInReqId = 0;
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_IN);
	}
#if 0
	else
	{
		IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"No Auto Redial Requests");
	}
#endif
	return eRet;
}

/*
 * This routine gets held call counts for a given FXS endpoint
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
uchar8 IFX_FXS_GetHeldCallsCount(
	                   IN x_IFX_FXS_EndptFsmInfo* pxEndPtInfo)
{
	uchar8 ucHeldCalls = 0;
	if( IFX_FXS_CS_LOCAL_HELD == pxEndPtInfo->axFxsCallInfo[0].eCallState )
		++ucHeldCalls;
	if( IFX_FXS_CS_LOCAL_HELD == pxEndPtInfo->axFxsCallInfo[1].eCallState  )
		++ucHeldCalls;

	return ucHeldCalls;
}


/*
 * This routine handles call hold success response for FXS endpoint.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_CallHoldSuccess(
	                  IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo, 
	                  OUT e_IFX_FXS_State* peEndptState,
	                  OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_FXS_CallInfo* pxActiveCall;
	e_IFX_CMGR_Status eStatus;
	e_IFX_MMGR_ToneType eToneType = IFX_MMGR_MAX_TONE;
	e_IFX_Return eRet = IFX_FAILURE;

	pxActiveCall = pxEndptInfo->pxActiveCall;
	/* Call hold success. Mark active call as held. */
	IFX_FXS_UpdateCallState( pxEndptInfo,pxActiveCall,IFX_FXS_CS_LOCAL_HELD);

	if( IFX_FXS_STATE_CALLWAITING == pxEndptInfo->eState )
	{
		/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Answering Waiting Call"); */

		IFX_FXS_StopTone(pxEndptInfo, &pxEndptInfo->uiToneTimerId);

		/* Waiting call is active call now */
		IFX_FXS_GetWaitingCallInfo(pxEndptInfo,&pxActiveCall);

		eRet = IFX_FAILURE;
		IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_CALL_WAITING);
		if( pxActiveCall )
			eRet = IFX_CMGR_CallAnswer(pxActiveCall->uiCallId, &eStatus,peReason);
			
		if( IFX_SUCCESS != eRet || IFX_CMGR_STATUS_SUCCESS != eStatus )
		{
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Answering Waiting Call Failed");
			IFX_FXS_ReleaseCall(pxEndptInfo, pxEndptInfo->pxActiveCall);
			pxEndptInfo->pxActiveCall = 0;
			eToneType = IFX_MMGR_DIAL_TONE;
		}
		else
		{
			/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"Answered Waiting Call"); */
			pxEndptInfo->pxActiveCall = pxActiveCall;
			IFX_FXS_UpdateCallState(pxEndptInfo,pxEndptInfo->pxActiveCall, 
				IFX_FXS_CS_ACTIVE);
			*peEndptState = IFX_FXS_STATE_CONVERSATION;
		}
	}
	else
	{
		/* Conversaion state */
		uint16 unTimeOut;

		eToneType = IFX_FXS_GetDialToneType(pxEndptInfo->szEndPointId,&unTimeOut);
		/* Don't play stutter tone now */
		eToneType = ( IFX_MMGR_STUTTER_DIAL_TONE == eToneType)
																						?IFX_FXS_REG_DIAL_TONE:eToneType;
	}

	if( IFX_MMGR_MAX_TONE != eToneType )
	{
		*peEndptState = IFX_FXS_STATE_DIALING;
		eRet = IFX_FXS_StartTone(pxEndptInfo, eToneType, vunDialToneLength,
							IFX_FXS_EVT_DialToneExpired, NULL, &pxEndptInfo->uiToneTimerId );
	}

	return eRet;
}

/*
 * This routine is invoked in busy state. If there a held call, initiates 
 * resume on that call. Else off hook warning is played out.
 * 
 * Endpoint has held call - Initiate resume on that call. If status is success,
 * mark held call as active and move to conversation state. If pending, set 
 * IFX_FXS_RESUME_INITIATED flag and update call's state to 
 * IFX_FXS_CS_RESUME_INITIATED. In both case return success. If failed retunr
 * failure.
 *
 * No held call - Stop tone if running. Start off-hook warning tone and set 
 * IFX_FXS_OFFHOOK_WARNING flag.
 */
/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ResumeCallInBusy(
	                   IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
										 OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_CMGR_Status eStatus;
	e_IFX_Return eRet = IFX_FAILURE;

	if( pxEndptInfo->pxActiveCall )
	{
		eRet = IFX_CMGR_CallResume(pxEndptInfo->pxActiveCall->uiCallId,
							&eStatus, peReason );
		if( IFX_SUCCESS == eRet )
		{
			if( IFX_CMGR_STATUS_SUCCESS == eStatus )
			{
				IFX_FXS_UpdateCallState(pxEndptInfo,
																pxEndptInfo->pxActiveCall,IFX_FXS_CS_ACTIVE);
				IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_CONVERSATION);
			}
			else if( IFX_CMGR_STATUS_PENDING == eStatus )
			{
				IFX_FXS_UpdateCallState(pxEndptInfo, 
						pxEndptInfo->pxActiveCall, IFX_FXS_CS_RESUME_INITIATED);
				IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_RESUME_INITIATED );
			}
			else
				eRet = IFX_FAILURE;
		} 
	}
	else
	{
		/* No call to resume. Play off hook warning tone */
		if( pxEndptInfo->uiToneTimerId )
			IFX_FXS_StopTone(pxEndptInfo, &pxEndptInfo->uiToneTimerId);

		eRet = IFX_MMGR_TonePlay(pxEndptInfo->szEndPointId,
													 IFX_MMGR_OFF_HOOK_WARNING_TONE,NULL);
		IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_OFFHOOK_WARNING);
		eRet = IFX_SUCCESS;
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_AutoRedial(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo)
{
	x_IFX_MMGR_CidParams	xCidParams;
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ACTIVE_OUT);
	IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_AUTOREDIAL_ON_ONHOOK);
	
	IFX_AGU_GetCallerIdInfo(&pxEndptInfo->xLastDialedAddr, 
									xCidParams.szCallerName, xCidParams.szCallerNumber);

	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Auto Redialing......");
	if( IFX_MMGR_SUCCESS == 
			IFX_MMGR_SigResAlloc(pxEndptInfo->szEndPointId,NULL ) )
	{
		IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_SIG_RESOURCE_ALLOCATGED);
		eRet = IFX_FXS_StartTone(pxEndptInfo,
											IFX_MMGR_DISTINCTIVE_RING_TONE,
											IFX_RING_TONE_DURATION,
											IFX_FXS_EVT_RingToneExpired,
											&xCidParams,
											&pxEndptInfo->uiToneTimerId);

		if( IFX_SUCCESS == eRet )
		{
			IFX_FXS_SetEndpointFlag(pxEndptInfo,IFX_FXS_DISTINCTIVE_RING_ON);
			IFX_FXS_UpdateEndpointState(pxEndptInfo,IFX_FXS_STATE_RINGING);
		}
		else
		{
			/* IFX_DBGA(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
				pxEndptInfo->szEndPointId,"IFX_FXS_StartTone Failed"); */
			IFX_FXS_ResetEndpointFlag(pxEndptInfo,IFX_FXS_SIG_RESOURCE_ALLOCATGED);
			IFX_MMGR_SigResDealloc(pxEndptInfo->szEndPointId);
		}
	}
	else
	{
		/* Failed to allocate signaling resource */
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
			pxEndptInfo->szEndPointId,"Resource Allocation Failed");
	}

	return eRet;
}

/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
STATIC char8* IFX_FXS_GetStateStr( IN e_IFX_FXS_State eState )
{
	static char8* aszFxsState[IFX_FXS_STATE_MAX+1] =
	{
		"Phone In Idle State",
		"Phone In Dialing State",
		"Phone In Ringing State",
		"Phone In Ringback State",
		"Phone In Conversation State",
		"Phone In Conference State",
		"Phone In Callwaiting State",
		"Phone In Busy State",
		"##** Phone In Invalid State **##"
	};

	if( eState >= IFX_FXS_STATE_MAX )
		return aszFxsState[IFX_FXS_STATE_MAX];
	return aszFxsState[eState];
}

/*******************************************************************************
 *  Function Name   : 
 *  Description     : 
 *  Input Values    : 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
STATIC char8* IFX_FXS_GetEventStr( IN  e_IFX_FXS_Event eEvent)
{
	static char8* aszEvetnStr[IFX_FXS_EventMax+1] =
	{
		"IFX_FXS_EVT_OffHk",
		"IFX_FXS_EVT_OnHk",
		"IFX_FXS_EVT_HkFlash", 
		"IFX_FXS_EVT_DigitPressed",
		"IFX_FXS_EVT_InterDgtTimerExpired",
		"IFX_FXS_EVT_DialToneExpired",
		"IFX_FXS_EVT_RingToneExpired,",
		"IFX_FXS_EVT_StutterToneExpir",
		"IFX_FXS_EVT_RingBackToneExpired",
		"IFX_FXS_EVT_BCEToneExpir",
		"IFX_FXS_EVT_IncomingCall",
		"IFX_FXS_EVT_ReleaseCall",
		"IFX_FXS_EVT_RmtAccept",
		"IFX_FXS_EVT_RmtAnswer",
		"IFX_FXS_EVT_RmtHold", 
		"IFX_FXS_EVT_RmtResume",
		"IFX_FXS_EVT_HoldResp",
		"IFX_FXS_EVT_ResumeResp",
		"IFX_FXS_EVT_ConfStatus",
		"IFX_FXS_EVT_BTxResp",
		"IFX_FXS_EVT_ATxResp", 
		"IFX_FXS_EVT_FaxDISEvent",
		"IFX_FXS_EVT_FaxCEDEvent",
		"IFX_FXS_EVT_FaxCNGEvent"
		"Invalid Event"
	};

	if( eEvent >= IFX_FXS_EventMax )
		return aszEvetnStr[IFX_FXS_EventMax];
	return aszEvetnStr[eEvent];
}
/*******************************************************************************
 *  Function Name   : IFX_FXS_ProcessDialPlan
 *  Description     : This function hanldes matching and execution of Dial plan
 *
 *                    Invoke IFX_DP_Match with so far collected digits. If this 
 *                    API returns failure or action retunred is not 
 *                    IFX_DP_DIALOUT, play error tone & start error tone timer 
 *                    & move to busy state. If action is IFX_DP_DIALOUT invoke 
 *                    IFX_FXS_ExecuteDialPlanAction (this executes dial plan 
 *                    action). If this routine returns failure play error tone
 *                    start error tone timer and move to busy state. Otherwise 
 *                    this routine retunrs tone to be played out and entpoint 
 *                    state. (For more detail see IFX_FXS_ExecuteDialPlanAction)
 *                    If tone is valid play tone and start timer. If endpoint 
 *                    state is valid move to that state.
 *  Input Values    : Please refer pfn_IFX_FXS_Fsm for details of parameters. 
 *  Output Values   : 
 *  Return Value    : Always returns IFX_SUCCESS
 *  Notes           :
 ******************************************************************************/
e_IFX_Return IFX_FXS_ProcessDialPlan(
	               IN x_IFX_FXS_EndptFsmInfo* pxEndptInfo,
	               IN x_IFX_FXS_EventInfo* pxEvtInfo, 
	               OUT e_IFX_ReasonCode* peReason )
{
	char8  szDialOut[IFX_MAX_DIGITS];
	x_IFX_DP_Rule xDpRule;
	uint32 unTimeOut = 0;
	uchar8 ucDpAction = 0;
	e_IFX_Return eRet = IFX_FAILURE;
	e_IFX_MMGR_ToneType eToneType;
  e_IFX_FXS_State eState = IFX_FXS_STATE_MAX;

	IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
      "Dialed Numbers ", pxEndptInfo->szDialledDigits );

	if ((gucMindgts > strlen(pxEndptInfo->szDialledDigits)) || 
	    (gucMaxdgts < strlen(pxEndptInfo->szDialledDigits)) ){
		IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
             pxEndptInfo->szEndPointId, "Dialed Number length is not between Minimum and Maximum Number of Digits" );
		eRet = IFX_FAILURE;
	}
  else{
		eRet = IFX_DP_Match(pxEndptInfo->szDialledDigits,
						IFX_TRUE, &ucDpAction, szDialOut, &xDpRule, (uint16*)&unTimeOut ); 
	}

	if( IFX_SUCCESS == eRet ){
		if( IFX_DP_DIALOUT == ucDpAction ){
			eRet = IFX_FXS_ExecuteDialPlanAction(pxEndptInfo, szDialOut, xDpRule.eAction, 
								&eToneType, &eState );
		}
		else{
			/*Dial plan error */
			IFX_DBGC(vucFxsAgnetModId,IFX_DBG_LVL_ERROR, IFX_DBG_ATA_STRING_INFO,
               pxEndptInfo->szEndPointId, "Dial Plan Mismatch" );
			eRet = IFX_FAILURE;
		}
	}
			
	/* Clear all collected digits */
  pxEndptInfo->szDialledDigits[0] = '\0';

  if( IFX_FAILURE == eRet ){
		eToneType = IFX_MMGR_ERROR_TONE;
		eState = IFX_FXS_STATE_BUSY;
	}

  if( IFX_MMGR_MAX_TONE != eToneType ){
		if( IFX_MMGR_ERROR_TONE == eToneType )
			unTimeOut = IFX_ERROR_TONE_DURATION;
		else if( IFX_MMGR_CONFIRMATION_TONE == eToneType )
			unTimeOut = IFX_CONF_TONE_DURATION;
		else if( IFX_MMGR_RING_BACK_TONE == eToneType )
			unTimeOut = IFX_RINGBACK_TONE_DURATION;
		else /* Busy tone */
			unTimeOut = IFX_BUSY_TONE_DURATION;

		eRet = IFX_FXS_StartTone(pxEndptInfo, eToneType, unTimeOut,
              IFX_FXS_EVT_BCEToneExpired, NULL, &pxEndptInfo->uiToneTimerId);
  }

  if( IFX_FXS_STATE_MAX != eState ){
		IFX_FXS_UpdateEndpointState(pxEndptInfo,eState);
	}

	return IFX_SUCCESS; //eRet;
}
