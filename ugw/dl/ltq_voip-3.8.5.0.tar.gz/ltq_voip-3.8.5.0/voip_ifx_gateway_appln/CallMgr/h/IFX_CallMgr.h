/*****************************************************************************
 **   FILE NAME       : IFX_CallMgr.h
 **   PROJECT         : ADSL DECT GW
 **   MODULES         : Call-Manager 
 **   SRC VERSION     : 0.1
 **   DATE            : 23/March/2007 
 **   AUTHOR          : ADSL VoIP DECT VoIP Application Team
 **   DESCRIPTION     : This file contains data structures and macros for CMGR
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#ifndef __IFX_CMGR_H__
#define __IFX_CMGR_H__

/* Mcros used across the file*/
#define IFX_CMGR_OUT_CL_IDX 0
#define IFX_CMGR_IN_CL_START_IDX 1

#define IFX_CMGR_GetOutCl(pxCnxt) (pxCnxt->pxCallLegs[IFX_CMGR_OUT_CL_IDX])
#define IFX_CMGR_GetInClStart(pxCnxt) \
		  (pxCnxt->pxCallLegs[IFX_CMGR_IN_CL_START_IDX])

#define IFX_CMGR_GetOutReqLeg(pxCnxt) ((pxCnxt)->pxReqLegs[IFX_CMGR_OUT_CL_IDX])
#define IFX_CMGR_GetInReqLeg(pxCnxt) ((pxCnxt)->pxReqLegs[IFX_CMGR_IN_CL_START_IDX])

#define IFX_CMGR_GetLegDir(pLeg)(pLeg->eDirection)
#define IFX_CMGR_SetLegDir(pLeg,NewDir)do{(pLeg)->eDirection=NewDir;}while(0)

#define IFX_CMGR_GetCurrState(pLeg)(pLeg->eCurrState)
#define IFX_CMGR_GetPrevState(pLeg)(pLeg->ePrevState)

#define IFX_CMGR_SetPeerPtr(pLeg,pPeer) do{pLeg->pxPeer = pPeer;}while(0)
#define IFX_CMGR_GetPeerPtr(pLeg) ((pLeg)?pLeg->pxPeer:NULL)

#define IFX_CMGR_SetCurrCnxt(pLeg,pCnxt) do{pLeg->pxCurrCnxt = pCnxt;}while(0)
#define IFX_CMGR_GetCurrCnxt(pLeg) (pLeg->pxCurrCnxt)

/*!
	\brief Maximum Number of agents in the system
*/
#define IFX_CMGR_MAX_AGENTS (IFX_MAX_ENDPTS+6)
/*!
 \brief This shows that the structure is busy/free/reserved
*/
typedef enum
{
	IFX_CMGR_STRUCT_FREE=0, /*!< structure free*/
	IFX_CMGR_STRUCT_RESERVED,/*!< struct reserved*/
	IFX_CMGR_STRUCT_OCCUPIED /*!< struct Occupied*/
}e_IFX_CMGR_StructStatus;


/*!
	\brief Basic Call types Enum
*/
typedef enum
{
	IFX_CMGR_BCT_VOIP_INT=1, /* Voip to Internal - EXTN/FXO*/
	
	IFX_CMGR_BCT_EXTN_FXO,
	IFX_CMGR_BCT_EXTN_VOIP,
	IFX_CMGR_BCT_EXTN_EXTN,
	IFX_CMGR_BCT_FXO_VOIP,
	IFX_CMGR_BCT_FXO_EXTN, /*Forking Possible in this*/
	
	IFX_CMGR_BCT_VOIP_EXTN, /* Forking possible in this*/
	IFX_CMGR_BCT_VOIP_FXO,
	IFX_CMGR_BCT_MAX
}e_IFX_CMGR_BasicCallType;


typedef struct
{
	uint8 ucRefCnt; /*Reference Counter*/
	x_IFX_CMGR_CallBackList xCallBackList;/*!< Call-back structure */
}x_IFX_CMGR_CallBackInfo;


/*!
	\brief Structure contians a pointer to the call-back list and a
			 the endpoint ID that owns the structure
*/
typedef struct
{
	e_IFX_CMGR_StructStatus eStructStatus; /*!< Is this structure in Use?*/
	x_IFX_CMGR_CallBackInfo* pxCallBackInfo;/*!< Call-back structure pointer*/
	char8 szEndptId[IFX_MAX_ENDPOINTID_LEN];/*!< Endpoint ID*/
}x_IFX_CMGR_EndptInfo;

/*!
	\brief Maximum Number of calls in the system
*/
#define IFX_CMGR_MAX_CALL_CNXT 15

/*!
 \brief Maximum number of call legs
*/
#define IFX_CMGR_MAX_CALL_LEGS ((IFX_CMGR_MAX_CALL_CNXT*2)+7)

/*!
	\brief Macro to set bit flags
*/
#define IFX_CMGR_SET_FLAG(FLAG,FLAG_POS) (FLAG|=(1<<(FLAG_POS)))
/*!
	\brief Macro to rest bit flags
*/
#define IFX_CMGR_RESET_FLAG(FLAG,FLAG_POS) (FLAG&=(~(1<<(FLAG_POS))))

/*!
	\brief	Macro give Zero value for Set and NON zero value for reset. 
*/
#define IFX_CMGR_GET_FLAG(FLAG,FLAG_POS) (((FLAG) & (1<<FLAG_POS))>>FLAG_POS)

/*!\brief Macro to Encapsulate the Call-Id*/
#define IFX_CMGR_GetCallId(CONTEXT_INDEX,LEG_INDEX) \
		  					((((CONTEXT_INDEX)<<16)|LEG_INDEX)+1)

/*!\brief	Macro to generate call context index from Call-Id*/
#define IFX_CMGR_GetCallCnxtIdx(CALL_ID) (((CALL_ID-1)>>16))

/*!\brief	Macro to generate call leg index from Call-Id*/
#define IFX_CMGR_GetCallLegIdx(CALL_ID) ((CALL_ID-1) & 0xFFFF)


/*!\brief Macro to Encapsulate the Req-Id*/
#define IFX_CMGR_GetReqId(CONTEXT_INDEX,LEG_INDEX) \
		  					((((CONTEXT_INDEX)<<16)|LEG_INDEX)+1)

/*!\brief	Macro to generate req context index from req-Id*/
#define IFX_CMGR_GetReqCnxtIdx(REQ_ID) (((REQ_ID-1)>>16))

/*!\brief	Macro to generate Req leg index from req-Id*/
#define IFX_CMGR_GetReqLegIdx(REQ_ID) ((REQ_ID-1) & 0xFFFF)


/*!
	\brief Maximum number of times the call fwd shall take place for one call
*/
#define IFX_MAX_CALL_FWD_LIST 3

/*!
	\brief Information based on each conference
*/
typedef struct
{		
	int8 cActiveCallIndex; /*!< Index of the active call, if any in the array. 
	The Agent which calls the MakeConf API may give at most one active call
	in the array of calls. This variable indexes into the array auiCallsInConf 
	and finds the right call. Variable is useful to restore the system to the
	initial state in case of a BreakConf API call. If no call was active this 
	value would be -1.*/
	uint32 auiCallsInConf[IFX_MAX_CONF_PARTIES]; /*!< Array of call-ids 
																	  that are in conf*/
	uint8 ucNumCalls;/*!< Number of calls in the array above*/
	uint8 ucCurrActiveCalls; /*Counter to indicate the the follwoing number of 
	calls are now active. The conference can be enabled when ucNumCalls 
	is equal to ucCurrActiveCalls*/
	boolean bConfEnabled; /*!< Flag to indicate that conf is on*/
	int32 iConfId; /*!< Conference Id given by the MMGR*/
}x_IFX_CMGR_ConfInfo;

/*!
	\brief Information based on each SIP registration
*/
typedef struct
{
	uint16 unVoipLineId; /*!< Voip line over which this 
								 registration is Reqed*/
 	x_IFX_CMGR_RegServerInfo xReServer;
	uchar8  ucIndex;
	boolean bRetry;
	uchar8  ucNoOfRetries;
}x_IFX_CMGR_VoipRegInfo;

#ifdef MESSAGE_SUPPORT
typedef struct
{
	uint16 unVoipLineId; /*!< Voip line over which this 
								 registration is Reqed*/
}x_IFX_CMGR_SmsInfoInt;
#endif

/*!
	\brief Information for Voice Mail related SIP subscription
*/
typedef struct
{
	uint16 unVoipLineId; /*!< Voip line over which this 
								 subscription is Reqed*/
}x_IFX_CMGR_VmSubsInfo;

/*!
	\brief Information for Auto redial SIP subscription
*/
typedef struct
{
	boolean bIncReq; /*!< Req is incoming or out-going*/
	x_IFX_CMGR_VoipAddr xAddr;/*!< Address to/from which subscription is Req*/
	uint16 unVoipLineId; /*!< Voip line over which this 
								 subscription is Reqed/received*/
	boolean bDeActReq; /*!< Flasg indicates that a de-activation of the 
		a previously enabled subscription was requested. */
}x_IFX_CMGR_AutoRedialSubsInfo;


/*!
	\brief Type of Req Id
 */
typedef enum
{
	IFX_CMGR_REQ_CONF=1, /*!< Conference Req*/
	IFX_CMGR_REQ_SUBS_AUTO_REDIAL,/*!< Req Subs for auto redial*/
	IFX_CMGR_REQ_SUBS_VOICE_MAIL,/*!< Req Subs for voice mail Req*/
	IFX_CMGR_REQ_REG,/*!< Req for SIP registration*/
#ifdef MESSAGE_SUPPORT
	IFX_CMGR_REQ_SMS,/*!< Req for SIP registration*/
#endif	
	IFX_CMGR_REQ_MAX=0,/*!< Terminator*/
}e_IFX_CMGR_TypeOfReq;

/*!
	\brief Union of information for each type of Req
*/
typedef union
{
	x_IFX_CMGR_ConfInfo xConfInfo; /*!< Conference Information*/
	x_IFX_CMGR_VoipRegInfo xRegInfo; /*!< SIP Reg Info*/
	x_IFX_CMGR_VmSubsInfo xVmSubsInfo; /*!< SIP Voice Mail subs Info*/
	x_IFX_CMGR_AutoRedialSubsInfo xArdSubsInfo; /*!< Auto Redial 
																		  subs Info*/
#ifdef MESSAGE_SUPPORT
	x_IFX_CMGR_SmsInfoInt xSmsInfoInt; /*!< SIP Reg Info*/
#endif
}ux_IFX_CMGR_ReqContext;

/* Just for a decleration*/
struct x_IFX_CMGR_ReqContext;

/*!
	\brief Structure carries information for each Req-id. One structure 
	represents on leg of the Req and contains data about the agent
*/
typedef struct x_IFX_CMGR_ReqLeg
{
	e_IFX_CMGR_StructStatus eStructStatus; /*!< Is this structure in Use?*/
	uint32 uiReqId; /*!< Req Id for this call leg*/
	x_IFX_CMGR_CallBackList* pxCallBackList;/*!< Pointer to the right CB 
	List structure. To be populated after the Req is initiated*/
	struct x_IFX_CMGR_ReqLeg* pxPeer; /*!< Req Leg for the 
																	peer agent, if any*/   
	struct x_IFX_CMGR_ReqContext* pxCurrCnxt;/*!< Pointer to the current Req 
																  Cnxt structure*/
	void* pvPrivateData; /*!< Needed by the agent*/
	char8 szEndptId[IFX_MAX_ENDPOINTID_LEN];/*!< Endpoint ID of the agent owing 
														this Req Leg*/
}x_IFX_CMGR_ReqLeg;

/*!
	\brief Maximum number of Req information structures
*/
#define IFX_CMGR_MAX_REQ_CNXT 10
/*!
	\brief	Maximum number of Req legs
*/
#define IFX_CMGR_MAX_REQ_LEGS (IFX_CMGR_MAX_REQ_CNXT * 2) 

/*!
	\brief	Maximum number of req legs per Req info
*/
#define IFX_CMGR_REQ_LEG_PER_CNXT 7

/*!
	\brief Structure carries information for each Req. It contains a pointer to 
	two Req legs. In some cases only one Req leg might be used (e.g. conf).
*/
typedef struct x_IFX_CMGR_ReqContext
{
	e_IFX_CMGR_StructStatus eStructStatus; /*!< Is this structure in Use?*/
	e_IFX_CMGR_TypeOfReq eReqType; /*!< Type of Reqs*/
	ux_IFX_CMGR_ReqContext uxReqCnxt;/*!< union of Req informatio 
													structures*/
	x_IFX_CMGR_ReqLeg *pxReqLegs[IFX_CMGR_REQ_LEG_PER_CNXT]; 
	/*!< Array of pointer to Req legs*/
}x_IFX_CMGR_ReqContext;

/*!
	\brief	Direction of the call leg
*/
typedef enum
{
	IFX_CMGR_OUT=1,/*!< Outgoing Call Leg*/
	IFX_CMGR_IN,/*!< Incoming Call Leg*/
	IFX_CMGR_MAX/*!< Terminator*/
}e_IFX_CMGR_Direction;

/*!
	\brief	These enums serve as bit  in the Flags 
				variable in the CMGR Structures
*/
typedef enum
{
	IFX_CMGR_FLAG_CALL_HOLD_FOR_ATX,/*!< Flag to indicate that the HOLD Req 
											sent for this call is for the puropse of 
											attended transfer initiated on another call.*/
	IFX_CMGR_FLAG_CALL_RESUME_FOR_ATX, /*!< To indicate that the call resume 
	is for ATX. In this case the resume response is not to be propogated back
	to the peer leg.*/ 
	IFX_CMGR_FLAG_EARLY_MEDIA_RECVD,/*!< Flag when set, indicates that the 
	CallAccept was with Codecs and hence with early media. So on this the,
	CMGR shall invoke ConfigMedia and do StartSession. This flag is set at this
	point. When the CallAnswer finally is invoked, this flag should be reset. */
	IFX_CMGR_FLAG_CNXT_IN_FORKING,/*!< To indicate that the call context is in 
	Forking procedure. It is to be set when the call is being established and
	reset when the call is finally established.*/
	IFX_CMGR_FLAG_CALL_ID_NOT_GIVEN,/*!< This flag when set indicates 
	that the  Call-Init Fuction has not returned and thus any call-back
	done on the agent would result in a failure. This is to be set when 
	the Call-Initiate is invoke and reset when Call-Initiate is returned*/
	IFX_CMGR_FLAG_RTP_MEDIA_SESSION_ON,/*!< Flag to indicate that the RTP Media Session
	is ON. Set after invoking RTP start Session. Reset after stop session*/
#ifdef FAX_SUPPORT
	IFX_CMGR_FLAG_FAX_MEDIA_SESSION_ON,/*!< Flag to indicate that the FAX Media Session
	is ON. Set after invoking FAX start Session. Reset after stop session*/
	IFX_CMGR_FLAG_ENABLE_FAX,/*!< Flag to indicate that the FAX Media Session
	is to be started. Set after invoking FAX to indicate to Media Start Function 
	that FAX has to be started. Reset after invoke FaxSessionStart.*/
	IFX_CMGR_FLAG_WAITING_FOR_TCP_FAX,/*!< Flag to indicate that the FAX agent is
	listening on TCP Fax server port. Set after invoking FAX agent to start 
	listening for incoming fax connections on TCP. Reset after invoke FaxSessionStop 
	or FaxServerListen with lsietning disable flag on.*/
	IFX_CMGR_FLAG_FAX_INITIATOR, /*!< Flag indicates that the side in question is
	the side which initiated the FAX negotiation*/
	IFX_CMGR_FLAG_FAX_FXS_ON_HK, /*!< Flag to indicate that the FAX session in 
	progress was disrupted due to an on-hook from the FXS port.*/
#endif
	IFX_CMGR_FLAG_DONT_SEND_NTFY, /*!< Flag to indicate that no further notify's
	should be sent on the call ID. Used in case of Voip_Int_Voip tx*/
 	IFX_CMGR_FLAG_MEDIA_NEG_IN_PROG,/*!< Flag indicates that a Media Negotiation 
	is happening. Its to ensure that simultaneous media negotiations do not occur
	on a call. Its set in IFX_CMGR_MediaNegReq and reset in IFX_CMGR_MediaNegRsp*/
	IFX_CMGR_FLAG_NO_NEG_RSP_TO_PEER,/*!< Flag indicates that the response 
	recieved is not to be propogated to the Peer. This also indicates that the
	media negotiation request was triggered by the CMGR and not the peer agent.*/
	IFX_CMGR_FLAG_MEDIA_CFG_DONE, /*!< Flag indicates that the MEDIA CFG has been
	invoked for this call & the next time MEDIA MODIFY needs to be invoked. Set
	after MediaCfg & Reset on Call completion*/	
	IFX_CMGR_FLAG_MAX /*!< Terminator*/
}e_IFX_CMGR_Flags;

/*!
	\brief	These enums define the type of transfer
*/
typedef enum
{
	IFX_CMGR_BTX_INT_VOIP_VOIP=1,/*!< Extension, RV1, RV2 transfer scenario*/
	IFX_CMGR_BTX_INT_INT_INT,/*!< All internal parties*/
	IFX_CMGR_BTX_INT_VOIP_INT,/*!< Context Change*/ 
	IFX_CMGR_BTX_INT_INT_VOIP,/*!< Two extension parties and one VoIP party*/	
	IFX_CMGR_BTX_VOIP_INT_VOIP,/*!< RV1, Extension, RV2 transfer scenario*/
	IFX_CMGR_BTX_MAX_TYPE,

	IFX_CMGR_ATX_INT_VOIP_VOIP,/*!< Extension, RV1, RV2 transfer scenario*/
	IFX_CMGR_ATX_INT_INT_INT,/*!< All internal parties*/
	IFX_CMGR_ATX_INT_VOIP_INT,/*!< Context Change*/
	IFX_CMGR_ATX_INT_INT_VOIP,/*!< Context Change*/
	IFX_CMGR_ATX_VOIP_INT_VOIP,/*!< RV1, Extension, RV2 transfer scenario*/
	IFX_CMGR_ATX_MAX_TYPE
}e_IFX_CMGR_TypeOfTransfer;

/*!
	\brief States for the Call leg
*/
typedef enum
{
	IFX_CMGR_STATE_IDLE = 0, /*!< Call State Idle*/
	IFX_CMGR_SEND_RESP_PENDING,/*!< CMGR has to send a response to the agent*/
	IFX_CMGR_RECV_RESP_PENDING,/*!< CMGR has to receive a response from agent*/
	IFX_CMGR_STATE_RINGING,/*!< leg is ringing*/
	IFX_CMGR_STATE_RINGBACK,/*!< Leg is playing ringback*/
	IFX_CMGR_STATE_CONV,/*!< Leg is conversation*/
	IFX_CMGR_STATE_HELD,/*!< Leg is held by local agent*/
	IFX_CMGR_STATE_TX_STATUS_WAIT,/*!< This call leg is in transfer 
											  and finally will be transformed 
											  into a call leg of the resultant call*/
	IFX_CMGR_STATE_CALL_LEG_TX,/*!< This call leg is in transfer and will be 
										  deleted once the transfer is through*/
	IFX_CMGR_STATE_DISRUPT_WAIT,/*!< This call leg is in Transfer is just 
											waiting to be disrupted*/
	IFX_CMGR_STATE_BUSY,/*!< leg is busy condition -cannot accept calls*/
	IFX_CMGR_STATE_MAX/*!< Terminator*/
}e_IFX_CMGR_CallState;

/* 
	\brief If the state is response pending, 
			then response is pending for which Req.
 */
typedef enum
{
	IFX_CMGR_RESP_PEND_INVITE=1, /*!< Response Pending for an Invite Req*/
	IFX_CMGR_RESP_PEND_HOLD, /*!< Response Pending for a Hold Req*/
	IFX_CMGR_RESP_PEND_RESUME,/*!< Response Pending for Resume Req*/
	IFX_CMGR_RESP_PEND_ATX,/*!< Response Pending for Attended Transfer Req*/
	IFX_CMGR_RESP_PEND_BTX,/*!< Response Pending for Blind Transfer Req*/
	IFX_CMGR_RESP_PEND_MAX/*!< Terminator*/
}e_IFX_CMGR_RespPendEvent;

/*!
	\Flags indicating the Media Negotiation status*/
typedef enum
{	
	IFX_CMGR_OFFER_RXD=1, /*SDP Offer received but answer not sent*/
	IFX_CMGR_OFFER_SENT /*SDP Offer sent  but answer not received*/
}e_IFX_CMGR_MediaNegStatus;


typedef x_IFX_MMGR_JitterBuffer_Conf x_IFX_CMGR_JB_Info;

typedef x_IFX_MMGR_TelephonyEvent_Info x_IFX_CMGR_TelEvtInfo;


/*!
	\brief Information for SIP Network agent
*/
typedef struct x_IFX_CMGR_VoipLegInfo
{
	x_IFX_CMGR_VoipAddr xRemAddr; /*!< Address of the Remote Party*/
	x_IFX_CMGR_VoipAddr xLocalVlAddr; /*!< Address of the Local Party*/

	e_IFX_CMGR_MediaNegStatus eNegStatus; /*!< Status of media negotiation*/

	x_IFX_CMGR_CodecParams xNegCodecInfo; /*!< The codecs that are negotiated*/	
	x_IFX_CMGR_CodecParams xOfferedCodecInfo; /*!< The codecs that are 
												  locally avaiable or were offered*/
	x_IFX_CMGR_RtpParams xNegRtpParams;/*!< Negotiated RTP params*/
	x_IFX_CMGR_CodecParams xTempCodecInfo; /*Codecs used for Offer-Answer 
												 during Hold and resume*/	
	x_IFX_CMGR_RtpParams xTempRtpParams;/*!< Temp RTP Params- used during 
													  Hold & Resume*/

#ifdef FAX_SUPPORT
	x_IFX_CMGR_FaxParams axFaxParams[IFX_MAX_FAX_PROTO];/*!< Negotiated 
																				FAX params*/
#endif
	
	x_IFX_CMGR_JB_Info xJbInfo; /*!< Jitter Buffer related information*/	
	x_IFX_CMGR_TelEvtInfo xRemTelEvtInfo; /*!< Remote Telephony event info*/
	x_IFX_CMGR_TelEvtInfo xLocTelEvtInfo; /*!< Local Telephony event info*/
	
	x_IFX_CMGR_VoipAddr axCallFwdList[IFX_MAX_CALL_FWD_LIST];/*!< List to prevent 
																			 cyclic forwarding*/
	uint8 ucCallFwdCount;/*!< Number of elements in the Call fwd list count*/
	uint8 ucLineId; /*!< Needed for NA to get all the VoIP line information*/
	boolean bSilenceSupEnabled; /*Flag to indicate that Silence Supression
											has been enabled*/
	char8 szDevChannelName[IFX_MMGR_MAX_CHANNEL_NAME]; /*!< Device name of the 
																											 	coder channel */
}x_IFX_CMGR_VoipLegInfo;

/*!
	\brief Information for FXO agent
*/
typedef x_IFX_CMGR_FxoInfo x_IFX_CMGR_FxoLegInfo;

/*!
	\brief Information for DECT agent
*/
typedef struct
{
	x_IFX_CMGR_CodecParams xNegCodecInfo; /*!< The codec that is negotaited for the 
											EXTN leg*/
	x_IFX_CMGR_CodecParams xOfferedCodecInfo; /*!< The codecs that are 
												  locally avaiable or were offered*/	
	x_IFX_CMGR_CodecParams xTempCodecInfo; /*Codecs used for Offer-Answer 
											during MediaNegReq and MediaNegRsp*/ 
	x_IFX_CMGR_CallParams xCallParams; /*Needed for the Purpose of re-use*/
}x_IFX_CMGR_ExtnLegInfo;

/*!
	\brief Union Of Information for the Agent which owns the Call Leg
*/
typedef union
{
	x_IFX_CMGR_VoipLegInfo xVoipLegInfo;/*!< Info for NA*/
	x_IFX_CMGR_FxoLegInfo xFxoLegInfo;/*!< Info for FXO agent*/
	x_IFX_CMGR_ExtnLegInfo xExtnLegInfo;/*!< Info for EXTN agent*/
}ux_IFX_CMGR_LegOwnerInfo;

/*!
	\brief Struct Of Information for the Agent which owns the Call Leg
*/
typedef struct
{
	e_IFX_CMGR_CallType eOwnerType;	/*!< Could be VoIP/FXO/EXTN*/
	char8 szEndptId[IFX_MAX_ENDPOINTID_LEN]; /*!< The endpoint-id for the 
														 agent owning this call leg*/
	ux_IFX_CMGR_LegOwnerInfo uxLegOwnerInfo;/*!< Union of Info needed 
															for each owning agent*/
}x_IFX_CMGR_LegOwnerInfo;

/*Just for a declaration*/
struct x_IFX_CMGR_CallContext;

/*!
	\brief Call Leg structure that contains all the informaton about one leg
			 of the call.
*/
typedef struct x_IFX_CMGR_CallLeg
{
	e_IFX_CMGR_StructStatus eStructStatus; /*!< Is this Call Leg in Use?*/
	uint32 uiCallId;/*!< Call Id of the call-leg - May not be needed*/
	x_IFX_CMGR_LegOwnerInfo xLegOwnerInfo;
	x_IFX_CMGR_CallBackList* pxCallBackList;/*!< Pointer to the right CB info structure
															To be populated after the Call-Initiate*/
	x_IFX_CMGR_CallBackList* pxRtpCB;/*!< Pointer to the RTP agent CB info structure
															To be populated after the Call-Initiate*/
#ifdef FAX_SUPPORT
	x_IFX_CMGR_CallBackList* pxFaxCB;/*!< Pointer to the FAX agent CB info structure
															To be populated after the Call-Initiate*/
#endif /*FAX_SUPPORT*/
	
	e_IFX_CMGR_CallState eCurrState; /*!< Current state of the call*/
	e_IFX_CMGR_CallState ePrevState; /*!< Previous state of the call*/
	e_IFX_CMGR_RespPendEvent eRespPendEvt;	/*!< Response Pending for 
														  which event, if any*/
	e_IFX_CMGR_Direction eDirection; /*!< Is this call leg, the call 
													initiator or receiver-Will help 
													in case of call forking*/
	struct x_IFX_CMGR_CallContext* pxCurrCnxt; /*!< Pointer to access 
																this call-leg's call context*/
	void* pvPrivateData; /*!< For the use of the Agent only - Mapped to Call_Id*/
	struct x_IFX_CMGR_CallLeg* pxPeer; /*!< Pointer to the peer call leg - Assigned 
														 after the call has been established*/
	struct x_IFX_CMGR_CallLeg* pxChild; /*!< For the purpose of transfer*/
	struct x_IFX_CMGR_CallLeg* pxParent; /*!< For the purpose of transfer*/
	uint32 uiConfReqId; /*!< The Req Id if this call 
								 is in a conference*/
	x_IFX_CMGR_CallParams xCallParams; /*Needed for the Purpose of re-use*/
	uint32 uiRepCallId; /*!< For the purpose of passing to the NA in ATX*/
	boolean bByeRcvd; /* A release has been received on this Call Leg. Its
	used in case of Tx intiaitor. Used to tell the status to the party later.*/
}x_IFX_CMGR_CallLeg;

#define IFX_CMGR_MAX_LEGS_PER_CNXT IFX_CMGR_MAX_AGENTS
#define IFX_CMGR_MIN_LEGS_PER_CNXT 2

typedef enum{
	IFX_CMGR_STAR_DIAL_IN_PROGRESS,
	IFX_CMGR_DEFLECTION_IN_PROGRESS
}e_IFX_CMGR_SS_Flags;

/*Call Context*/
typedef struct x_IFX_CMGR_CallContext
{
	e_IFX_CMGR_StructStatus eStructStatus; /*!< Is this Call Cnxt in Use?*/
	int32 iResId; /*!< Resource Id needed for MM calls*/
	int32 iResIdForTransfer; /*!< Resource Id needed for call transfer*/
	e_IFX_CMGR_BasicCallType eBasicCallType; /*!< Basic Call Type*/
	
	struct x_IFX_CMGR_CallContext *pxPeerAtxCnxt;/*!< Other call in 
																  Attended Transfer*/
	e_IFX_CMGR_TypeOfTransfer eTypeOfTransfer;/*!< To indicate the type of 
		transfer that is happening, if any*/
	/* Max number of call legs the Cnxt can have */
	x_IFX_CMGR_CallLeg* pxCallLegs[IFX_CMGR_MAX_LEGS_PER_CNXT]; 
	uint8 ucNumCallLegs; /*!< Number of Call legs in this context*/
	
	uint16 unFlags; /*!< FLAGS as per the enum above*/
	uint16 unSSCallFlag; /*!< Flag for supplementry servises */
	char8 szDeflecteeEid[IFX_MAX_ENDPOINTID_LEN]; /*!< The endpoint-id for the Deflectee*/
}x_IFX_CMGR_CallContext;

/*!
 \brief Maximum number of calls that can be supported in the system
*/
#define IFX_CMGR_MAX_CALLS IFX_CMGR_MAX_CALL_CNXT

/*!
 	\brief Struct which will have a global variable in the CMGR
*/
typedef struct
{
	x_IFX_CMGR_EndptInfo axEndptInfo[IFX_CMGR_MAX_AGENTS];	 
	/*!< Arry of pointers to structures containig EIDs and CB pointers */
	x_IFX_CMGR_CallContext axCallCnxt[IFX_CMGR_MAX_CALL_CNXT];	
	/*!< Array of call cnxts*/
	x_IFX_CMGR_CallLeg axCallLeg[IFX_CMGR_MAX_CALL_LEGS];
	/*!< Array of call Legs*/
	x_IFX_CMGR_ReqContext axReqCnxt[IFX_CMGR_MAX_REQ_CNXT];
	/*!< Array of Req Info structures*/
	x_IFX_CMGR_ReqLeg axReqLeg[IFX_CMGR_MAX_REQ_LEGS];
	/*!< Array of Req legs structures*/
	uint32 auiCallIdList[IFX_CMGR_MAX_CALL_LEGS];
	/*!< Array of current call IDs in the system*/
	uint32 auiReqIdList[IFX_CMGR_MAX_REQ_LEGS];
	/*!< Array of current request IDs in the system*/
	uint8 ucDebugId; /*!< Debug ID needed for Call manager module*/
}x_IFX_CMGR_CallMgrInfo;


/*!
 	\brief Enum indicating the type of structure to operate on
*/
typedef enum
{
	IFX_CMGR_CALL_LEG=1,/*!< Call Leg*/
	IFX_CMGR_CALL_CNXT,/*!< Call Context*/
	IFX_CMGR_REQ_LEG,/*!< Req Leg*/
	IFX_CMGR_REQ_CNXT,/*!< Req Info*/
	IFX_CMGR_ENDPT_INFO,/*!< Endpt Info*/
}e_IFX_CMGR_StructType;

typedef e_IFX_Return (*pfn_IFX_CMGR_CreateCall)
		  						(
								 	OUT uint32* puiCallId,
									IN x_IFX_CMGR_AddressInfo *pxFrom, 
									IN x_IFX_CMGR_AddressInfo *pxTo, 
								 	IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason,
					 				IN void* pvPrivateData
					 			);
								
typedef e_IFX_Return (*pfn_IFX_CMGR_AcceptCall)
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxCallLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								);
								

typedef e_IFX_Return (*pfn_IFX_CMGR_AnswerCall)
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxCallLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								);


typedef e_IFX_Return (*pfn_IFX_CMGR_HoldCallSuccess)
		  						(
								 	IN x_IFX_CMGR_CallLeg* pxCallLeg,
								 	OUT e_IFX_CMGR_Status* peStatus,
									OUT e_IFX_ReasonCode* peReason
								);
								
typedef e_IFX_Return (*pfn_IFX_CMGR_BTx)
		  (
				IN x_IFX_CMGR_CallLeg* pxCallLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				OUT e_IFX_TransferStatus* peStatus,	
				OUT e_IFX_ReasonCode* peReason
		  );
typedef e_IFX_Return (*pfn_IFX_CMGR_ATx)
		  (
				IN x_IFX_CMGR_CallLeg* pxCallLeg,
				IN x_IFX_CMGR_AddressInfo* pxTarget,
				IN uint32 uiReplacesCallId,
				OUT e_IFX_TransferStatus* peStatus,	
				OUT e_IFX_ReasonCode* peReason
		  );

x_IFX_CMGR_CallContext* IFX_CMGR_GetCallCnxtPtr(uint32 uiCallId);
x_IFX_CMGR_CallLeg* IFX_CMGR_GetCallLegPtr(uint32 uiCallId);
x_IFX_CMGR_ReqContext* IFX_CMGR_GetReqCnxtPtr(uint32 uiReqId);
x_IFX_CMGR_ReqLeg* IFX_CMGR_GetReqLegPtr(uint32 uiReqId);
e_IFX_Return IFX_CMGR_GetCBList(IN char8* szEndptId,
					 									OUT x_IFX_CMGR_CallBackList** ppxCB);
#endif /*__IFX_CMGR_H__*/
