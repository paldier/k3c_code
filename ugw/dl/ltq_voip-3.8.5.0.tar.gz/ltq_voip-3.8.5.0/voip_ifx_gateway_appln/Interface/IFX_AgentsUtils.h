#ifndef __IFX_AGENTS_UTILS__
#define __IFX_AGENTS_UTILS__

void IFX_AGU_GetCallerIdInfo(
	              IN x_IFX_CMGR_AddressInfo* pxAddr,
	              OUT char8* pszCallerName,
	              OUT char8* pszCallerNumber );

e_IFX_Return IFX_AGU_SetCallForward(
	                   IN char8*  pszEnptId,
										 IN e_IFX_DP_Action eDpAction,
										 IN char8* szDialOut,
										 IN char8 ucDbgId );

e_IFX_Return IFX_AGU_BlindTransfer(
	                   IN char8* pszEnptId,
	                   IN uint32 uiCallId,
	                   IN char8* szDialOut,
	                   IN uchar8 ucDbgId,
										 OUT e_IFX_TransferStatus* peTxState );
//#define HEX_DUMP

#ifdef HEX_DUMP
void IFX_AGU_HEX_DUMP(uchar8* pucBuf, int size);
#else
#define IFX_AGU_HEX_DUMP( pucBuf, size)
#endif

#endif //__IFX_AGENTS_UTILS__
