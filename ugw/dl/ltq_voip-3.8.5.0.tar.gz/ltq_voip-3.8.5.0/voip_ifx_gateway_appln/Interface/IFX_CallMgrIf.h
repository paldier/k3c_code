/*****************************************************************************
 **   FILE NAME       : IFX_CallMgrIf.h 
 **   PROJECT         : ADSL DECT GW
 **   MODULES         : Call-Manager 
 **   SRC VERSION     : 0.1
 **   DATE            : 23/March/2007 
 **   AUTHOR          : ADSL VoIP DECT VoIP Application Team
 **   DESCRIPTION     : This file contains the functions and the data structures 
 **							exposed by the call manager to the different agents
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#ifndef __IFX_CMGR_IF_H__
#define __IFX_CMGR_IF_H__


/*! \file IFX_CallMgrIf.h
    \brief This File contains the Constants, enumerations, related Data
    structures and functions for using the  functionality provided
    by the Call Manager.
*/
/** \defgroup GW_APIs Gateway Application APIs
    \brief This section describes the interfaces provided by 
	different modules of the Gateway Application.
*/
/* @{ */

/** \defgroup CMGR_API Call Manager
	\brief This section lists the services provided by the Call Manager
*/
/* @} */

/** \addtogroup CMGR_API Call Manager
	\brief This section lists the services provided by the Call Manager
*/
/* @{ */

/** \defgroup CMGR_CC_functions Call Control Service
	\brief This section lists the functions provided by the Call Manager for 
			Call Control Services.  This section also lists the callback 
			functions provided by the agent(s) for call control services.
*/
/* @{ */

struct x_IFX_CMGR_CallBackList;

/*! 
    \brief Enum defining the type of the call
*/
typedef enum
{
	IFX_CMGR_TYPE_VOIP=0,		/*!< Indicates VoIP call */
	IFX_CMGR_TYPE_FXO=1,	/*!< Indicates PSTN/ISDN call */
	IFX_CMGR_TYPE_EXTN=2,	/*!< Indicates internal (extension)  call */
}e_IFX_CMGR_CallType;

/*!
    \brief Enum defining the status of a request
*/

typedef enum
{
	IFX_CMGR_STATUS_SUCCESS=0, /*!< Indicates that the request resulted in a sucess*/
	IFX_CMGR_STATUS_FAIL=1, /*!< Indicates that the request resulted in a failure*/
	IFX_CMGR_STATUS_PENDING=2/*!< Indicates that the final result is pending*/
}e_IFX_CMGR_Status;

/*!
  \brief Enum defining the Call register category
 */
typedef enum {
	IFX_CR_DIALED=0,/*!< Dialled Call Entries*/
	IFX_CR_RECEIVED=1,/*!< Received Call Entries*/
	IFX_CR_MISSED=2/*!< Missed Call Entries*/
}e_IFX_CallRegisterType;

/*! \brief Enum defining the types of endpoints */
typedef enum {
	IFX_EP_FXS=1,/*!< Endpoint Type : FXS*/
	IFX_EP_FXO=2,/*!< Endpoint Type : FXO*/
	IFX_EP_DECT=3/*!< Endpoint Type : DECT*/
}e_IFX_EndptType;
 

/*! \brief Enum defining Call Forward Types*/
typedef enum {
	IFX_CALL_FWD_UNCONDITIONAL = 0x01, /*!< Forward calls, Unconditional. */
	IFX_CALL_FWD_BUSY = 0x02, /*!< Forward calls, only if phone is Busy. */
	IFX_CALL_FWD_ON_NO_ANSWER = 0x04, /*!< Forward calls, if Not Answered. */
	IFX_CALL_FWD_DND = 0x08, /*!< Forward calls, when DND is set. */
	IFX_CALL_FWD_VOICE_MAIL = 0x10 /*!< Forward calls To Voice Mail. */
}e_IFX_CallForwardType; 


/*! \brief Enum defining options for enabling/disabling Calling features, For e.g. Caller ID*/
typedef enum
{
	IFX_CMGR_DONT_CARE = 0, /*!< Don't Care */
	IFX_CMGR_DISABLE=1, /*!< Disable */
	IFX_CMGR_ENABLE=2, /*!< Enable */
}e_IFX_CMGR_FeatStatus;

/*! \brief  Structure containing VoIP(SIP) Address Information */
typedef x_IFX_CalledAddr x_IFX_CMGR_VoipAddr;

/*!
 	\brief Length of the date field
*/
#define IFX_CMGR_MAX_DATE_LEN 30
/*!
 	\brief Length of the time field
*/
#define IFX_CMGR_MAX_TIME_LEN 30

/*!
 	\brief Number of Registration Servers
*/
#define IFX_NO_OF_REG_SERVER 2

/*!
 	\brief Structure for Caller-Id information - Additional Parameters
*/
typedef struct
{
	char8 szDateOfCall[IFX_CMGR_MAX_DATE_LEN]; /*!< Date of Call*/
	char8 szTimeOfCall[IFX_CMGR_MAX_TIME_LEN];	/*!< Time of Call*/
	char8 szDisplayName[IFX_MAX_DISP_NAME];/*!< Display name of the caller*/
}x_IFX_CMGR_CidInfo;

/*!
	\brief Structure for FXO related address information
*/
typedef struct
{
	char8 szPhoneNumber[IFX_MAX_ENDPOINTID_LEN]; /*!< Phone Number.  For PSTN/ISDN FXO Calls, 
	Empty for two stage dialing  and contains target number in 
	case of one stage dialing.*/
	char8 szFxoLineId[IFX_MAX_ENDPOINTID_LEN]; /*!< FXO Id identifying the FXO 
								line in case of multiple
								FXO ports. Only to be filled by FXO agent(s). 
								Will be equal to the MSN number of the FXO.*/			
	x_IFX_CMGR_CidInfo xCidInfo; /*!< Structure for additional parameters received in CID*/
}x_IFX_CMGR_FxoInfo;

/*!
	\brief Union of different types of Addresses
*/
typedef union
{	
	x_IFX_CMGR_VoipAddr xVoipAddr; /*!< Structure containing the VoIP Address */
	x_IFX_CMGR_FxoInfo xFxoInfo; /*!<  Structure containing the FXO Address*/ 
	char8 szEndptId[IFX_MAX_ENDPOINTID_LEN]; /*!< Endpoint Id in case of 
													  	an internal call*/
}ux_IFX_CMGR_AddressInfo;

/*!
 	\brief Structure containing address, based on the type of address
*/
typedef struct
{
	e_IFX_CMGR_CallType eAddressType; /*!< VoIP/PSTN/Internal */
	ux_IFX_CMGR_AddressInfo uxAddressInfo; /*!< Union of addresses*/
  uchar8 ucLineId; /*!< Line Identifier */
}x_IFX_CMGR_AddressInfo;

/*!
	\brief  Structure containing DTMF digits related information, 
			  like the digits themselves, the transmission method etc.
*/
typedef struct
{
	char8 szDigits[IFX_MAX_ENDPOINTID_LEN];/*!< Digit String*/
}x_IFX_CMGR_DgtInfo;

/*! \brief Structure containing the list of codecs and related information */
typedef x_IFX_CodecList x_IFX_CMGR_CodecParams;

/*! \brief Structure containing parameters needed for Fax transmission */
typedef x_IFX_FaxParams x_IFX_CMGR_FaxParams;

/*!  	\brief Structure containing RTP Parameters */
typedef x_IFX_RtpParams x_IFX_CMGR_RtpParams;

#if 0
/*! \brief Structure containing Media Parameters */
typedef struct
{
	x_IFX_CMGR_CodecParams xCodecParams;/*!< Structure containing Codec List info */
	x_IFX_CMGR_RtpParams xRtpParams;/*!< Structure containing Codec RTP info*/
	x_IFX_CMGR_FaxParams axFaxParams[IFX_MAX_FAX_PROTO];/*!< Structure containing parameters 
																			needed for Fax transmission*/	
}x_IFX_CMGR_VoipMediaParams;
#endif
/*! \brief Structure containing media related parameters for SIP Agent */
typedef x_IFX_MediaParams x_IFX_CMGR_VoipMediaParams; 

/*!
	\brief Structure needed for SIP Agent parameters
*/
typedef struct
{
	x_IFX_CMGR_VoipMediaParams xVoipMediaParams; /*!< Structure containing parameters related to VoIP 
																  media*/
	x_IFX_CMGR_VoipAddr xFwdAddr;/*!< Structure containing the VoIP Address.  The Forward address to apply to the
											CallInitiate Request, before the CallInitiate 
											returns - Used for UNCF etc.*/
	uint32 uiReplacesCallId;/*!< Replaces Call Id, in case of a replaces call */	
	boolean bSupressCallerId;/*!< Flag used to suppress Caller-Id transmission for VoIP */
	char8 szPhoneNumber[IFX_MAX_ENDPOINTID_LEN]; /*!< Remote PSTN Number.  Used in an outgoing
	PSTN to VoIP call. The remote PSTN  number is passed to the remote VOIP
	party in a FXO->Voip call.*/
}x_IFX_CMGR_VoipParams;

/*!
	\brief Structure containing media related parameters for DECT Agent
*/
typedef struct
{
	x_IFX_CMGR_CodecParams xCodecParams;/*!< Structure containing Codec List info */
}x_IFX_CMGR_ExtnMediaParams;


/*!
	\brief Structure containing parameters of the FXO
*/
typedef struct
{
	boolean bEmergency;/*!< Flag for emergency calls.  Is the call an emergency call */
}x_IFX_CMGR_FxoParams;

/*!	
	\brief Structure containing parameters for Extensions
*/
typedef struct
{
	x_IFX_CMGR_ExtnMediaParams xExtnMediaParams;/*!< Structure containing DECT 
																 Media info */
	e_IFX_CMGR_FeatStatus eCallerIdStatus;/*!< Setting for Caller-Id transmission/suppression for VoIP */
	boolean bWideBandCapable;/*!< Flag indicating Wideband capability.  Needed For FXS ports */
	boolean bEmergency;/*!< Flag for emergency calls */
	char8 cRingCount;/*!< Ring Count*/
}x_IFX_CMGR_ExtnParams;

/*!
 	\brief Union containing parameters for Endpoint and Network Agents
*/
typedef union
{
	x_IFX_CMGR_VoipParams xVoipParams;/*!< Parameters needed for SIP Agent*/
   x_IFX_CMGR_FxoParams xFxoParams; /*!< Parameters needed for FXO Agents*/
   x_IFX_CMGR_ExtnParams xExtnParams; /*!< Parameters needed for FXS / DECT Agents*/
}ux_IFX_CMGR_CallParams;

/*!
	\brief Structure containing the type of agent and the union of call parameters
*/
typedef struct
{
	e_IFX_CMGR_CallType eAgentType; /*!< Agent type*/
	ux_IFX_CMGR_CallParams uxCallParams;/*!< Union of call parameters for the agent(s)*/
}x_IFX_CMGR_CallParams;


/*!
 	\brief Union containing media parameters for both the DECT and the SIP Agent.
	This is needed in case of codec/rtp change from the DECT leg of 
	the call or the VoIP leg. This will be used in functions and callback function(s)
	to change media params during offer/answer as well as during a call.
*/
typedef union
{
	x_IFX_CMGR_VoipMediaParams xVoipMediaParams;/*!< Media Parameters needed 
																for SIP Agent*/
	x_IFX_CMGR_ExtnMediaParams xExtnMediaParams; /*!< Media Parameters needed for 
																 DECT Agent*/
}ux_IFX_CMGR_MediaParams;

/*!
	\brief Structure containing the type of agent and the union of media parameters
*/
typedef struct
{
	e_IFX_CMGR_CallType eAgentType; /*!< Agent type - DECT Agent / SIP Agent */
	ux_IFX_CMGR_MediaParams uxMediaParams;/*!< Union of media parameters for the agent*/
}x_IFX_CMGR_MediaParams;


/*!
	\brief Structure containing the parameters related to SIP registration
*/

typedef struct
{
	x_IFX_CalledAddr xSrvrAddr;  /*!< RegServer Address */
	uint32 uiExpVal;			 /*!< Registration Expire Time */
	uint16 unLineId	;			 /*!< Line Id */
	boolean bRetryFlag;			 /*!< If NA should keep retrying incase Registration fails */

}x_IFX_CMGR_RegParams;

/*!
	\brief Structure containing the parameters related to Registration Server
*/

typedef struct
{
	uchar8 ucNoOfServer; /*!< Number of Servers */
	x_IFX_CalledAddr axSrvrAddr[IFX_NO_OF_REG_SERVER]; /*!< RegServer Address */
	uint32 uiExpVal; /*!< Registration Expire Time */
	uint16 unLineId	; /*!< Line Id */
}x_IFX_CMGR_RegServerInfo;


/*********************BASIC CALL CONTROL****************************/

/*! 
    \brief  This function gets the media parameters during 
	the call handling procedure.  This function shall be invoked by 
	the agents (endpoint and network)  after invocation of 
	IFX_CMGR_CallInitiate,  pfn_IFX_CMGR_RemoteCallAccept 
	or pfn_IFX_CMGR_RemoteCallAnswer. This function may also be 
	invoked during the Call Hold and Call Resume scenarios. This function 
	returns the media parameters for a valid Call Identifier passed.  
	The media parameters are returned as an OUT parameter.  
    \param[in]  uiCallId The identifier of the call
    \param[out] pxMediaParams - The reference to the media parameters
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_MediaParamsGet(
					 			IN uint32 uiCallId,
								OUT x_IFX_CMGR_MediaParams* pxMediaParams);

/*! 
    \brief  This function sets the media parameters during the call handing 
	procedure.  The media parameters are received during the SIP 
	media negotiation procedure involving SDP answer with a PRACK or an ACK.
	This function shall be invoked by the SIP Agent to set the media 
	parameters.  This function sets the media parameters for a 
	valid Call Identifier.
    \param[in]  uiCallId The identifier of the call
    \param[in] pxMediaParams - The reference to the media parameters.
    \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_MediaParamsSet(
					 			IN uint32 uiCallId,
								IN x_IFX_CMGR_MediaParams* pxMediaParams);


/*! 
    \brief  This function is used to change the media during a call by issuing
	a request. This function shall be invoked by the SIP Agent or the 
	DECT agent when they propose to change the media (codec) during a call.  
	This function shall be invoked by the SIP Agent upon receiving a 
	SIP UPDATE message to change the media.   In the case of DECT, this 
	function shall be invoked by the DECT Agent, when the DECT handset 
	offers a new set of codecs.  
    \param[in]  uiCallId The identifier of the call
    \param[in,out] pxMediaParams The reference to the media parameters.
	\param[out]	peStatus The status of the request : One of 
			SUCCESS/FAILED/PENDING
	\param[out]	peReason The reason code for a specific action by the function
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_MediaNegReq(
					 			IN uint32 uiCallId,
								IN_OUT x_IFX_CMGR_MediaParams* pxMediaParams,
								OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason
								);


/*! 
    \brief  This function is used to change the media during a call.  This 
	function shall be invoked by an agent (SIP Agent or DECT Agent)
	to respond to a previously issued pfn_IFX_CMGR_NegMediaReq.  
	The agent returns the final set of negotiated codec(s) in the response.
    \param[in] uiCallId The identifier of the call
    \param[in] pxMediaParams The reference to the media parameters.
	\param[in,out]	peStatus The status of the request : One of SUCCESS/FAILED
	\param[in,out]	peReason The reason code for a specific action by the function
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_MediaNegRsp(
					 			IN uint32 uiCallId,
								IN x_IFX_CMGR_MediaParams* pxMediaParams,
								IN_OUT e_IFX_CMGR_Status* peStatus,
					 			IN_OUT e_IFX_ReasonCode* peReason
								);


/*!	
   \brief      This function initiates a call setup request.  This function 
                  shall be called by the agent(s) whenever they need to make a call.
  
  \param[out]  puiCallId The identifier of the call
   \param[in]  pxTo The VoIP address/extension number/PSTN Phone 
                   number identifying the called party. 
	For the call initiated between FXS/DECT endpoints and VoIP, this in 
	the address URI subfield contains info in the form user(at the rate)domain and 
	in the call type subfield contains VoIP. 
	For the call initiated between FXS/DECT endpoints and PSTN, this 
	contains the destination PSTN number. 
	For the call initiated between FXS/DECT endpoints and  FXS/DECT 
	endpoints,  this contains the peer party's extension (internal) number. 
	For the call initiated from PSTN, this shall contain two different values 
	depending on the FXO Line mode,
	When the FXO Line is in the Gateway mode, this contains the remote 
	VoIP URI. 
	When the FXO Line is in the forwarding mode, this contains the FXO 
	Line ID (own phone number).
	For incoming calls from the VoIP interface, this contains the URI of the 
	VoIP Line to which the call is destined.
   \param[in]  pxFrom The VoIP address/extension number/PSTN 
	Phone number identifying the calling party.
	For the call initiated from FXS/DECT endpoints, the address subfield 
	contains their own endpoint id and the call type subfield contains internal. 
	For incoming calls from PSTN, this shall contain FXO Line id  and the 
	PSTN number in the phone number subfield.
	For incoming calls from VoIP, this shall contain the address of the remote 
	VoIP party in the address subfield and VoIP in the call type subfield.
   \param[in,out] pxCallParams Contains additional parameters for the call. 
	Agents implement their own structure that is given to the CMGR.
	In some cases the CMGR has to respond back immediately (like for 
	e.g unconditional call forward.) In such cases this is also used as 
	an out parameter.
   \param[out] peStatus The status of the request. The possible values are:
	1) IFX_CMGR_STATUS_SUCCESS : The call has been answered.
	2) IFX_CMGR_STATUS_FAIL: The call request cannot be fulfilled. 
		The reason for the failure is in the peReason parameter.
	3) IFX_CMGR_STATUS_PENDING: The call request is pending. 
		The call setup has not yet failed/succeeded. The reason field 
		gives the reason for the pending status.
		
		This function populates the peStatus and peReason to indicate
			the state of the called party if the status of the called party is 
			available synchronously. This may obliviate the need to invoke 
			distinct callback functions on the call initiator informing the
			the called party status. For example, consider the case of a call 
			received by the FXO agent. The FXO agent (in most
			cases) responds synchronously to the request by returning
			the status as IFX_CMGR_STATUS_SUCCESS. This indicates that the
			call has been answered by it. The FXO agent does not invoke
			IFX_CMGR_CallAnswer function in course of the 
			pfn_IFX_CMGR_CallIncoming callback function. The Call Manager then, 
			to inform the call initiating agent (say SIP Agent) shall return 
			the status as IFX_CMGR_STATUS_SUCCESS. This indicates to the 
			SIP Agent that the call has been answered and also makes the 
			pfn_IFX_CMGR_RemoteCallAnswer callback function redundant. Hence the 
			callback function in question is not invoked by the call manager.
			The idea is that if a call initiator can be informed of the peer
			state, synchronously, then the status and reason fields would be
			used instead of the callback functions. The callback functions 
			are reserved for asynchronously received peer state notifications.
			
   \param[out]	peReason The reason for the status. 
	If the status is a failure, the following reason(s) are possible: 
		IFX_NO_RESOURCE,  IFX_CALL_FORWARD, 
		IFX_MEDIA_MISMATCH, IFX_ENDPOINT_BUSY,
		IFX_USER_NOT_FOUND,IFX_TERMINATED. 
	If the status is pending, then the following reason(s) are possible: 
		IFX_ENDPOINT_RINGING:  Indicating that the peer 
		party is ringing.  This is also an indication to the invoking agent to 
		apply a ringback tone. 
	If the status is success, then the following reason(s) are possible:
		IFX_CALL_ANSWERED: Indicating that the call has been answered. 
	If a reason does not apply or it is unknown, then value would 
	be IFX_MAX_REASON.
   \param[in] pvPrivateData Pointer to the private data needed by an agent. 
	The CMGR shall maintain this pointer and return it to the agent whenever 
	the agent asks for it or in every subsequent request on the same Call Id.	
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_CallInitiate(
					 OUT uint32 *puiCallId, 
					 IN x_IFX_CMGR_AddressInfo *pxFrom, 
					 IN x_IFX_CMGR_AddressInfo *pxTo, 
					 IN_OUT x_IFX_CMGR_CallParams *pxCallParams, 
					 OUT e_IFX_CMGR_Status* peStatus,
					 OUT e_IFX_ReasonCode* peReason,
					 IN void* pvPrivateData
					 );

/*!	
   \brief      This function deflects a call.  This function 
                  shall be called by the agent(s) whenever they need to deflect a call.
  
  \param[in]  uiCurrentCallId The identifier of the call
   \param[in]  pxTo The VoIP address/extension number 
               identifying the deflected-To party. 
	\param[out] peReason This parameter provides the specific reason in case of a 
				       failure. For all other cases the reason is IFX_MAX_REASON.
	This Function calls IFX_CMGR_CallInitiate function to make a call between 
	original caller and deflected-To number.
	If the status is success, then the following reason(s) are possible:
		IFX_CALL_ANSWERED: Indicating that the call has been answered. 
	If a reason does not apply or it is unknown, then value would 
	be IFX_MAX_REASON.
   \return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_CMGR_CallDeflect(
                IN uint32 uiCurrentCallId,
                IN x_IFX_CMGR_AddressInfo *pxTo,
                OUT e_IFX_ReasonCode *peReason);

/*!
	\brief 	This function informs the Call Manager that an agent has
	accepted the incoming call and is for example, ringing the endpoint.  This
	shall be invoked by the agent(s) as a response to the 
	pfn_IFX_CMGR_CallIncoming callback function.
	
	\param[in]	 uiCallId The identifier of the call
	\param[out]	peStatus The status of the request. The value of this
					is IFX_CMGR_STATUS_SUCCESS unless the function has 
					been invoked in an incorrect call state. In such a state, 
					the status is IFX_CMGR_STATUS_FAIL.
	\param[out]	peReason This parameter provides the specific reason in case of a 
				       failure. For all other cases the reason is IFX_MAX_REASON.
				The status and reason parameters are simply to report failures
		like invocation of the function in an incorrect state etc.
		Under normal scenarios, this is IFX_CMGR_STATUS_SUCCESS.
		with reason IFX_MAX_REASON.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			The status and reason parameters are simply to report failures
					like invocation of the function in an incorrect state etc.
					In normal scenarios, this would be IFX_CMGR_STATUS_SUCCESS
					with reason IFX_MAX_REASON.
*/
e_IFX_Return IFX_CMGR_CallAccept(
								IN uint32 uiCallId,
					 			OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason
								);							

/*!
	\brief	This function informs the Call Manager that an agent has 
	answered the call.  This shall be invoked by the agent(s) after receiving 
	the input from the user to answer the call.  In the case of SIP Agent,
	this shall be invoked upon receiving the 200 OK message from the 
	called party.  In the case of FXO agent, this shall be invoked upon 
	receiving a pfn_IFX_CMGR_CallIncoming.
	\param[in]	uiCallId The identifier of the call
	\param[out]	peStatus The status of the request. The value of this
					is IFX_CMGR_STATUS_SUCCESS unless the function has 
					been invoked in an incorrect call state. In such a state, 
					the status is IFX_CMGR_STATUS_FAIL.
	\param[out]	peReason This parameter provides the specific reason in case of a 
				       failure. For all other cases the reason is IFX_MAX_REASON.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			The status and reason parameters are simply to report failures
					like invocation of the function in an incorrect state etc.
					In normal scenarios, this would be IFX_CMGR_STATUS_SUCCESS
					with reason IFX_MAX_REASON.
 */
e_IFX_Return IFX_CMGR_CallAnswer(
								IN uint32 uiCallId,
					 			OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason
							);							

/*!
	\brief	This function is used to put an active call on hold.  This function 
	is invoked by the agent(s) when it wants to put an ongoing call on hold.  This
	function shall be invoked by the agent(s) upon receiving the input from the user
	to put a call on hold.  In the case of SIP Agent, this function shall be invoked 
	when the remote VoIP party sends a message indicating a call being put on
	hold.
	
	In certain cases the request issued by an agent may be responded
	to synchronously by the CMGR. In such cases, the result of the request is
	set in the peStatus and peReason parameters by the call manager.
	Thus call manager does not invoke the pfn_IFX_CMGR_CallHoldRsp  
	if the status is not IFX_CMGR_STATUS_PENDING.
	
	\param[in]	 uiCallId The identifier of the call
	\param[out]	peStatus The status of the request. The possible values are:
					1) IFX_CMGR_STATUS_SUCCESS : The call is HELD successfully.
					2) IFX_CMGR_STATUS_FAIL: The call hold request cannot be 
					fulfilled. The reason for the failure is in the peReason parameter.
					3) IFX_CMGR_STATUS_PENDING: The call hold request is  
					pending. The request has not yet failed/succeeded. 
	\param[out]	peReason The reason for the status. If the status
					is a failure, the reason could be IFX_MEDIA_MISMATCH.
					If a reason does not apply or is unknown, then value is
					IFX_MAX_REASON.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			In certain cases the request issued by an agent may be responded
					to synchonously. In such cases, the result of the request is
					set in the peStatus and peReason parameters by the call manager.
					Thus call manager DOES NOT invoke the pfn_IFX_CMGR_CallHoldRsp  
					if the status is NOT IFX_CMGR_STATUS_PENDING.
 */
e_IFX_Return IFX_CMGR_CallHold(
							IN uint32 uiCallId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason /*If Failure*/
							);							
/*!
	\brief	This function is used to resume a held call.  This function is 
	invoked by the agent(s) when it wants to resume a held call.  This function
	shall be invoked by the agent(s) upon receiving the input from the user
	to resume a held call.  In the case of SIP Agent, this function shall be 
	invoked when the remote VoIP party sends a message indicating a held
	call being resumed.
	
	In certain cases the request issued by an agent may be responded
	to synchronously. In such cases, the result of the request is
	set in the peStatus and peReason parameters by the call manager.
	Thus call manager does not invoke the pfn_IFX_CMGR_CallResumeRsp  
	if the status is not IFX_CMGR_STATUS_PENDING.
					
	\param[in]	 uiCallId The identifier of the call
	\param[out]	peStatus The status of the request. The possible values are:
					1) IFX_CMGR_STATUS_SUCCESS : The call is now
						ACTIVE.
					2) IFX_CMGR_STATUS_FAIL: The call resume request 
						cannot be fulfilled. The reason for the failure is in the 
						peReason parameter.
					3) IFX_CMGR_STATUS_PENDING: The call resume request 
						is pending. The request has not yet failed/succeeded. 
					
	\param[out]	peReason The reason for the status. If the status
					is a failure, the reason could be IFX_MEDIA_MISMATCH.
					If a reason does not apply or is unknown, then value is
					IFX_MAX_REASON.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			In certain cases the request issued by an agent may be responded
					to synchonously. In such cases, the result of the request is
					set in the peStatus and peReason parameters by the call manager.
					Thus call manager DOES NOT invoke the pfn_IFX_CMGR_CallResumeRsp  
					if the status is NOT IFX_CMGR_STATUS_PENDING.
 */
e_IFX_Return IFX_CMGR_CallResume(
								IN uint32 uiCallId,
								OUT e_IFX_CMGR_Status* peStatus,
								OUT e_IFX_ReasonCode* peReason 
								);							

/*!
	\brief	This function is used to put an active call on hold.  In particular, 
	this function is invoked by the agent(s) as a response to a 
	pfn_IFX_CMGR_RemoteCallHold.  The CMGR invokes the 
	pfn_IFX_CMGR_RemoteCallHold callback function when it receives a request
	to put an active on hold from the remote party.  This function conveys the 
	agent's response to the CMGR for an incoming Call Hold request.
	
	This function should only be invoked by an agent in case it cannot
	respond to a request synchronously (via the peStatus and peReason
	in the pfn_IFX_CMGR_RemoteCallHold callback). This should not be 
	invoked within the body of the pfn_IFX_CMGR_RemoteCallHold 
	callback function.
	
	\param[in]	 uiCallId The identifier of the call
	\param[in,out]	 peStatus The status of the request : One of the followingt
						1) IFX_CMGR_STATUS_SUCCESS : The call can now be
							HELD.
						2) IFX_CMGR_STATUS_FAIL: The call hold request 
							cannot be fulfilled. The reason for the failure is in the 
							peReason parameter.
	\param[in,out]	peReason The reason.  Incase of failure, this parameter provides the 
						specific reason. If reason is not applicable then the reason may
						be IFX_MAX_REASON.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			This function should ONLY be invoked by an agent in case it cannot
					respond to a request synchronously (via the peStatus and peReason
					in the pfn_IFX_CMGR_RemoteCallHold call back). This should NOT be 
					invoked in course of the pfn_IFX_CMGR_RemoteCallHold call-back.
 */
e_IFX_Return IFX_CMGR_CallHoldRsp(
									IN uint32 uiCallId,
									IN_OUT e_IFX_CMGR_Status* peStatus,
									IN_OUT e_IFX_ReasonCode* peReason
									);							

/*!
	\brief	This function is used to resume a held call.  In particular, 
	this function is invoked by the agent(s) as a response to a 
	pfn_IFX_CMGR_RemoteCallResume.  The CMGR invokes the 
	pfn_IFX_CMGR_RemoteCallResume callback function when it receives a request
	to resume a held call from the remote party.  This function conveys the 
	agent's response to the CMGR for an incoming Call Resume request.
	
	This function should only be invoked by an agent in case it cannot
	respond to a request synchronously (via the peStatus and peReason
	in the pfn_IFX_CMGR_RemoteCallResume callback function). 
	This should not be invoked within the body of the 
	pfn_IFX_CMGR_RemoteCallResume callback function.
	
	\param[in]	 uiCallId The identifier of the call
	\param[in,out]	 peStatus The status of the request : One of the following:
						1) IFX_CMGR_STATUS_SUCCESS : 
							The call is now ACTIVE.
						2) IFX_CMGR_STATUS_FAIL: The call resume request 
							cannot be fulfilled. The reason for the failure is in the 
							peReason parameter.
	\param[in,out]	peReason The reason.  Incase of failure, this parameter provides the 
						specific reason. If reason is not applicable then the reason may
						be IFX_MAX_REASON.
   \return     IFX_SUCCESS or IFX_FAILURE

	\note			This function should ONLY be invoked by an agent in case it cannot
					respond to a request synchronously (via the peStatus and peReason
					in the pfn_IFX_CMGR_RemoteCallResume call back). This should NOT be 
					invoked in course of the pfn_IFX_CMGR_RemoteCallResume call-back.
 */
e_IFX_Return IFX_CMGR_CallResumeRsp
							(
							IN uint32 uiCallId,
							IN_OUT e_IFX_CMGR_Status* peStatus,
							IN_OUT e_IFX_ReasonCode* peReason 
							);														

/*!
	\brief	This function terminates an ongoing call or rejects an incoming
	call.  This function is invoked by the agent(s) to terminate an ongoing call or
	reject an incoming call.  
	Will be invoked by an agent when it wants 
				release an ongoing call or to reject an incoming call. 
	\param[in]	 uiCallId The identifier of the call
	\param[in]	 eReleaseReason  provides the reason for call release, if any. 
	\param[in]	 pxFwdAddr the address to contact in case of incoming VoIP call 
					 rejection. Used only by the NA to inform a 301/302 received.
	\param[out]	peStatus The status of the request. The value of this
					would be IFX_CMGR_STATUS_SUCCESS unless the function has 
					been invoked in an incorrect call state. That would entail
					the status to be IFX_CMGR_STATUS_FAIL.
	\param[out]	peStatusReason Incase of failure, this parameter provides the 
					specific reason. In all other cases the reason would be
					IFX_MAX_REASON.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			The status and reason parameters are simply to report failures
					like invocation of the function in an incorrect state etc.
					In normal scenarios, this would be IFX_CMGR_STATUS_SUCCESS
					with reason IFX_MAX_REASON.
 */
e_IFX_Return IFX_CMGR_CallRelease(
							IN uint32 uiCallId,
							IN e_IFX_ReasonCode eReleaseReason,
							IN x_IFX_CMGR_VoipAddr* pxFwdAddr,			
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peStatusReason /*If Failure*/
							);							


/*!
	\brief	This function forwards the dialled digits to the Call Manager.  
	The agent(s) invoke this function to send the DTMF digits dialled by the 
	user.  The Call Manager then sends the digits to the remote party either 
	through the SIP INFO Method or RFC 2833 RTP event packets.
	\param[in]	 uiCallId The identifier of the call
	\param[in]	 pxDgtInfo The digit string and type of transmission method
	\param[out]	 peStatus is the status of the Req
	\param[out]	 peReason  Incase of failure, this parameter provides the 
					 specific reason.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_DigitsInCallSnd(
							IN uint32 uiCallId, 
							IN x_IFX_CMGR_DgtInfo *pxDgtInfo,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason
							);	

/*!
	\brief	This function helps to bring calls (minimum of two) into a conference.  
	This function is invoked by the agent(s).  This function notifies the Call Manager
	on the need to bring calls into a conference.
	\param[in]	puiCallId      The identifiers of the calls that have to be brought 
					into conference
	\param[in]	ucNumCallIds The number of calls that have to be 
					brought into the conference
	\param[out]	puiReqId 	The Request Identifier generated for the 
					Conference Request 
	\param[out]	peStatus The status of the request. The possible values are:
					1) IFX_CMGR_STATUS_SUCCESS : The conference is now
						ACTIVE.
					2) IFX_CMGR_STATUS_FAIL: The conference request 
						cannot be fulfilled.
					3) IFX_CMGR_STATUS_PENDING: The conference request 
						is pending. The request has not yet failed/succeeded. 
						
				Irrespective of the conference request status (success/failure), 
				the Call Manager shall not invoke pfn_IFX_CMGR_ConfStatus. 
				The peStatus and peReason indicate the conference status.
	\param[out]	peReason The reason for the status. 
					If a reason does not apply or is unknown, then value is
					IFX_MAX_REASON.
	\param[in] pvPrivateData The private data for use by the agent. Its is
					mapped to the Request Identifier. It is returned to the agent on
					request based on the Request Identifier.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note		   In case the conference request suceeds/fails in course of this 
					function, the call manager shall NOT invoke 
					pfn_IFX_CMGR_ConfStatus. The peStatus and peReason shall indicate 
					the conference status.
 */
e_IFX_Return IFX_CMGR_ConfMake(
							IN uint32* puiCallId, 
							IN uint32 ucNumCallIds,
							OUT uint32* puiReqId,
							OUT e_IFX_CMGR_Status* peStatus,
							OUT e_IFX_ReasonCode* peReason, /*In case of failure*/  
							IN void* pvPrivateData
							);	

/*!
	\brief	This function helps to break a conference into individual calls.
	This function is invoked by the agent(s).  This function notifies the Call Manager
	on the need to break a conference.
	\param[in]	uiReqId The Request Identifier generated for the 
					Conference Break Request
	\param[out]	peStatus The status of the request. The possible values are:
					1) IFX_CMGR_STATUS_SUCCESS : The conference is now
						IN-ACTIVE.
					2) IFX_CMGR_STATUS_FAIL: The conference break request 
						cannot be fulfilled.
					3) IFX_CMGR_STATUS_PENDING: The conference request 
						is pending. The request has not yet failed/succeeded. 
				
				Irrespective of the conference break request status (success/failure), 
				the Call Manager shall not invoke pfn_IFX_CMGR_ConfStatus. 
				The peStatus and peReason indicate the conference status.
				
	\param[out]	peReason The reason for the status. 
					If a reason does not apply or is unknown, then value is
					IFX_MAX_REASON.

   \return     IFX_SUCCESS or IFX_FAILURE
	\note		   In case the conference break request suceeds/fails in course of 
					this function, the call manager shall NOT invoke 
					pfn_IFX_CMGR_ConfStatus. The peStatus and peReason shall indicate 
					the conference status.
 */
e_IFX_Return IFX_CMGR_ConfBreak(
							IN uint32 uiReqId,
							OUT e_IFX_CMGR_Status * peStatus,
							OUT e_IFX_ReasonCode * peReason /*In case of failure*/
							);	


/*!
	\brief	This functions helps to start the Fax transmission.  This function
	informs the Call Manager to overlay the voice connection with the fax
	connection.  This function shall be invoked by the FXS and FXO agent(s),
	\param[in]	uiCallId The call identifier for the call
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_FaxStart(
					 		IN uint32 uiCallId
					 );

/**********************************Callbacks**************************************/

/*! 
    \brief     This callback function gets the Media Parameters.  This callback
	function is registered only by the agents that need media
	negotiation, viz., the SIP Agent and the DECT Agent.  This callback function
	is invoked by the Call Manager (only on the SIP Agent or the DECT Agent)
	after the invocation of either the IFX_CMGR_CallAccept 
	or the IFX_CMGR_CallAnswer function(s).  The Call Manager may also 
	invoke this function during the Call Hold and Call Resume scenarios. In 
	case of a call hold request from a remote party the SIP Agent shall 
	call IFX_CMGR_CallHold function in course of which the CMGR shall 
	invoke this callback function.
    \param[in]  uiCallId The identifier of the call
    \param[out] pxMediaParams The reference to the media parameters
	 \param[in] pvPrivateData The private data for use by the agent
    \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_MediaParamsGet)(
					 			IN uint32 uiCallId,
								OUT x_IFX_CMGR_MediaParams* pxMediaParams,
								IN void* pvPrivateData);


/*! 
    \brief  This callback function is used to change the media during a call. 
	This function shall be registered only by the agents
	that need media negotiation, viz., SIP Agent and DECT Agent.  The 
	SIP Agent invokes the IFX_CMGR_MediaNegReq when the remote party 
	in the call triggers a request to change the media.  The Call Manager
	in response to that invocation, calls this function.  In the case of DECT, 
	the offer is initiated from the DECT handset.  
    \param[in]  uiCallId The identifier of the call
    \param[in,out] pxMediaParams The reference to the media parameters.
	\param[out]	peStatus The status of the request : One of SUCCESS/FAILED/PENDING
	\param[out]	peReason The reason code for a specific action by the function
	 \param[in] pvPrivateData The private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_MediaNegReq)(
					 			IN uint32 uiCallId,
								IN_OUT x_IFX_CMGR_MediaParams* pxMediaParams,
								OUT e_IFX_CMGR_Status* peStatus,
					 			OUT e_IFX_ReasonCode* peReason,
								IN void* pvPrivateData
								);


/*! 
    \brief  This callback function is used to change the media during a call.
	This function shall be registered only by the agents
	that need media negotiation, viz., SIP Agent and DECT Agent.  This
	callback function is called by the Call Manager to inform an agent about 
	the status of the media change request it had initiated through 
	the IFX_CMGR_MediaNegReq function.  This function is invoked on the SIP Agent 
	or the DECT agent to respond with the final answer. It is  also be used by 
	the SIP Agent to give an SDP answer to the UPADTE/ReInvite request it had received.
    \param[in]  uiCallId The identifier of the call
    \param[in] pxMediaParams - The reference to the media parameters.
	\param[in,out] peStatus The status of the request : One of SUCCESS/FAILED
	\param[in,out]	peReason The reason code for a specific action by the function
	\param[in] pvPrivateData The private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_MediaNegRsp)(
					 			IN uint32 uiCallId,
								IN x_IFX_CMGR_MediaParams * pxMediaParams,
								IN_OUT e_IFX_CMGR_Status * peStatus,
					 			IN_OUT e_IFX_ReasonCode * peReason,
								IN void * pvPrivateData
								);


/*!
	\brief      This callback function initiates a call setup request.  This function 
                  is called by the Call Manager when it receives an incoming call
		notification.  All agents shall register this callback function with 
		the Call Manager to receive incoming call notifications.
 	\param[in]	uiCallId The identifier of the call for this endpoint
	\param[in]  pxFrom The VoIP address/endpoint Id (Extension number)
	identifying the calling party.  If this function is invoked on the SIP 
	Agent, this structure shall contain the VoIP Line URI as address and the 
	VoIP as the call type.  If this function is invoked on the DECT or FXS 
	agents, depending on the call originator (VoIP or FXO), this structure shall 
	contain a SIP Address or PSTN number.  If this function is invoked on the 
	FXO agent, depending on the call originator (Extensions or VoIP), this 
	structure shall contain the Extension number or the VoIP address.
	 \param[in]  pxTo The address/endpoint id (Extension number) identifying 
	 the called party. If this function is invoked on the FXS or DECT agents, 
	 this structure contains the endpoint id.  If this function is invoked on 
	 the FXO agent, this structure shall contain the Line Id of the FXO Line. 
	 The PSTN number if any, shall be put in the PSTN number field.  If this
	 function is invoked on the SIP Agent, it shall contain the Voice Line URI.	
	 \param[in] pxCallParams Additional parameters for the call. Agents implement 
	their own structure that is given to the CMGR. 
	\param[out]	peStatus The status of the request. The possible values are:
					1) IFX_CMGR_STATUS_SUCCESS : The call has been 
						answered.
					2) IFX_CMGR_STATUS_FAIL: The call request cannot be
						fulfilled. The reason for the failure is in the peReason
						parameter below.
					3) IFX_CMGR_STATUS_PENDING: The call requeest is 
						pending. The call has not yet failed/succeeded. The reason
						field below gives the reason for the pending status.
	This function populates the peStatus and peReason to indicate
			the state of the called party if the status of the called party is 
			available synchronously. This obliviates the need to invoke 
			distinct functions on the agents requesting the the status of the 
			call request. For example, consider the case of a call 
			received by the FXO agent. The FXO agent (in most
			cases) responds synchronously to the request by returning
			the status as IFX_CMGR_STATUS_SUCCESS. This indicates that the
			call has been answered by it. The FXO agent does not invoke
			IFX_CMGR_CallAnswer function in course of the 
			pfn_IFX_CMGR_CallIncoming callback function. The Call Manager then, 
			to inform the call initiating agent (e.g SIP Agent) shall return 
			the status as IFX_CMGR_STATUS_SUCCESS. This indicates to the 
			SIP Agent that the call has been answered and also makes the 
			pfn_IFX_CMGR_RemoteCallAnswer callback function redundant. Hence the 
			callback function in question is not invoked by the call manager.
			The idea is that if a call initiator can be informed of the called party
			state, synchronously, then the status and reason fields would be
			used instead of the callback functions. The callback functions 
			are reserved for asynchronously provided notifications.
		          \param[out] peStatus The status of the request. The possible values are:
				1) IFX_CMGR_STATUS_SUCCESS : The call has been answered.
				2) IFX_CMGR_STATUS_FAIL: The call request cannot be fulfilled. 
					The reason for the failure is in the peReason parameter.
				3) IFX_CMGR_STATUS_PENDING: The call request is pending. 
					The call setup has not yet failed/succeeded. The reason field 
					gives the reason for the pending status.		
	\param[out]	peReason The reason for the status. If the status
					is a failure, the reason may be: IFX_NO_RESOURCE, 
					IFX_CALL_FORWARD, IFX_MEDIA_MISMATCH, IFX_ENDPOINT_BUSY,
					IFX_USER_NOT_FOUND,IFX_TERMINATED. 
					If the status is pending, then the reason may be 
					IFX_ENDPOINT_RINGING, which indicates that the invoked party 
					is ringing. 
					If the status is success, the reason could be IFX_CALL_ANSWERED
					indicating that the call has been answered. 
					If a reason does not apply or is unknown, then value should be
					IFX_MAX_REASON.
	\param[out] ppvPrivateData Pointer to the private data needed by the
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it or in every subsequent
					request on the same call id.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			This function expects the peStatus and peReason to indicate
					the state of the invoked entity if the status is available 
					synchronously. 
					This obviates the need to invoke distinct functions on the 
					call manager informing it about the status of the call request. 
					For example, assume that the call-back is invoked on the analog
					FXS agent. The analog FXS agent checks if it can accept the call
					and then applies ringing on the endpoint to indicate to the
					user that a call is waiting for him/her. All this may happen in
					a synchronous manner and thus the call-back is returned with
					pestatus as IFX_CMGR_STATUS_PENDING and the peReason as
					IFX_ENDPOINT_RINGING. The analog FXS agent DOES NOT invoke the
					IFX_CMGR_CallAccept function. The reason and status given the analog
					FXS agent are returned to the call initiating agent (say SIP NA)
					as OUT parameters in the IFX_CMGR_CallInitiate function which it had
					invoked. This indicates to the SIP NA that the remote party is
					ringing. The pfn_IFX_CMGR_RemoteCallAccept call-back is NOT USED
					on the SIP NA in this case.
					
					The idea is that if a call status can be informed synchronously, 
					then the status and reason fields would be used instead of the 
					distinct function calls. The functions are reserved for asynchronously 
					provided notifications.
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_CallIncoming)(
					 IN uint32 uiCallId, 
					 IN x_IFX_CMGR_AddressInfo *pxFrom,
					 IN x_IFX_CMGR_AddressInfo *pxTo, 
					 IN x_IFX_CMGR_CallParams *pxCallParams, 
					 OUT e_IFX_CMGR_Status* peStatus,
					 OUT e_IFX_ReasonCode* peReason,
					 OUT void **ppvPrivateData
					 );
/*!
	\brief	This callback function informs the acceptance of a call by the called 
	party.  All agents shall register this callback function with 
	the Call Manager to receive call accept notifications from called
	parties .This function is invoked by the Call Manager on the call initiating 
	agent to inform that the call terminating agent has accepted the call and the 
	destined endpoint managed by the agent is ringing.  This function is called
	by the Call Manager after the called party agent on behalf of the destination
	endpoint invokes the IFX_CMGR_CallAccept function.
	
	This callback function shall be invoked on a call intiating agent 
	only when the response is asynchronously received from the 
	called party. In cases where the response is received and 
	delivered synchronoulsy, the invocation of this callback 
	function is not necessary.
	
	\param[in]	 uiCallId The identifier of the call
	\param[in]  pvPrivateData Pointer to the private data needed by an agent. 
		The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			This call-back shall be invoked on a call intiating agent 
					ONLY when the response is asynchronously received from the peer
					entity. In cases where the response was received & delivered
					synchronoulsy, this Call-Back is not invoked. For example
					a SIP NA to analog FXS call.
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_RemoteCallAccept)(
								IN uint32 uiCallId,
					 			IN void* pvPrivateData
								);							

/*!
	\brief	This callback function informs the answering of a call by the called 
	party.  All agents shall register this callback function with the Call Manager 
	to receive call answer notifications from called parties. This function is 
	invoked by the Call Manager on the call initiating agent to inform that 
	the call terminating agent has answered the call. This function is called 
	by the Call Manager after the called party agent on behalf of the 
	destination endpoint invokes the IFX_CMGR_CallAnswer function.
	
	This callback function shall be invoked on a call initiating agent 
	only when the response is asynchronously received from the called
	party. In cases where the response is received and delivered
	synchronoulsy, the invocation of this callback function is not 
	necessary.
	
	\param[in]	 uiCallId The identifier of the call
	\param[in]  pvPrivateData Pointer to the private data needed by an agent. The 
	CMGR shall maintain this pointer and return it to the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			This call-back shall be invoked on a call intiating agent 
					ONLY when the response is asynchronously received from the peer
					entity. In cases where the response was received & delivered
					synchronoulsy, this Call-Back is not invoked. For example
					a SIP NA to analog FXO call.
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_RemoteCallAnswer)(
								IN uint32 uiCallId,
					 			IN void* pvPrivateData
							);							

 /*!
	\brief	This callback function informs the call being put on hold from the remote end.
	All agents shall register this callback function with the Call Manager to 
	receive remote call hold notifications.  This function is invoked by the Call 
	Manager on an agent involved in a call to inform that the remote party in 
	the call has initiated a call hold procedure.  This function is called by the
	Call Manager after an agent involved in the call informs of the initiation
	of call hold by invoking IFX_CMGR_CallHold function.
	
	This callback function is invoked by the Call Manager
	requesting permission of an agent to let the remote party put 
	the call on hold. The agent in question may accept/reject the 
	request synchronously or asynchronously.  In case it decides to 
	accept/reject the request synchronously, it has to fill the 
	peStatus and peReason with the correct status and reason. 
	It shall not invoke the IFX_CMGR_CallHoldRsp from within
	this function.  In case the request is answered asynchronously, 
	then agent is supposed to invoke IFX_CMGR_CallHoldRsp 
	to provide the final status.
	
	\param[in]	 uiCallId The identifier of the call
	\param[out]	 peStatus The status of the request as given by the agent
						1) IFX_CMGR_STATUS_SUCCESS : The call can now be
							HELD.
						2) IFX_CMGR_STATUS_FAIL: The call hold request 
							cannot be fulfilled. The reason for the failure is in the 
							peReason parameter.
						3) IFX_CMGR_STATUS_PENDING: The request has not
							yet been answered. 
	\param[out]	peReason The reason.  Incase of failure, this parameter provides the 
						specific reason. If reason is not applicable then the reason may
						be IFX_MAX_REASON.
	\param[in]  pvPrivateData Pointer to the private data needed by an
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			This call-back is present to request permission of an agent to
					let the peer agent put the call on hold. The agent in question 
					may accept/reject the request synchronously or asynchronoulsy.
					In case it decides to accept/reject the request synchronoulsy,
					it has to fill the peStatus and peReason with the correct 
					status and reason. It shall NOT invoke the IFX_CMGR_CallHoldRsp
					function in course of the call-back. In case the request is answered
					asynchronously, then agent is supposed to invoke 
					IFX_CMGR_CallHoldRsp to provide the final status.
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_RemoteCallHold)(
							IN uint32 uiCallId,
					 		OUT e_IFX_CMGR_Status* peStatus,
					 		OUT e_IFX_ReasonCode* peReason,
					 		IN void* pvPrivateData
							);							
 /*!
	\brief	This callback function informs the held call being resumed from the remote end.
	All agents shall register this callback function with the Call Manager to 
	receive remote call resume notifications.  This function is invoked by the Call 
	Manager on an agent involved in a call hold scenarioto inform that the 
	remote party in the call has initiated a call resume procedure.  This function 
	is called by the Call Manager after an agent involved in the call hold informs 
	of the resumption of the call invoking IFX_CMGR_CallResume function.
	
	This callback function is invoked by the Call Manager
	requesting permission of an agent to let the remote party 
	resume the held. The agent in question may accept/reject the 
	request synchronously or asynchronously.  In case it decides to 
	accept/reject the request synchronously, it has to fill the 
	peStatus and peReason with the correct status and reason. 
	It shall not invoke the IFX_CMGR_CallResumeRsp from within
	this function.  In case the request is answered asynchronously, 
	then agent is supposed to invoke IFX_CMGR_CalResumeRsp 
	to provide the final status.
	
	\param[in]	 uiCallId The identifier of the call
	\param[out]	 peStatus The status of the request as given by the agent
						1) IFX_CMGR_STATUS_SUCCESS : The call can now be
							RESUMED.
						2) IFX_CMGR_STATUS_FAIL: The call resume request 
							cannot be fulfilled. The reason for the failure is in the 
							peReason parameter.
						3) IFX_CMGR_STATUS_PENDING: The request has not
							yet been answered. 
	\param[out]	peReason The reason.  Incase of failure, this parameter provides the 
						specific reason. If reason is not applicable then the reason may
						be IFX_MAX_REASON.
	\param[in]  pvPrivateData Pointer to the private data needed by an
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			This call-back is present to request permission of an agent to
					let the peer agent resume the held call. The agent in question 
					may accept/reject the request synchronously or asynchronoulsy.
					In case it decides to accept/reject the request synchronoulsy,
					it has to fill the peStatus and peReason with the correct 
					status and reason. It shall NOT invoke the IFX_CMGR_CallResumeRsp
					function in course of the call-back. In case the request is answered
					asynchronously, then agent is supposed to invoke 
					IFX_CMGR_CallResumeRsp to provide the final status.
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_RemoteCallResume)(
								IN uint32 uiCallId,
					 			OUT e_IFX_CMGR_Status* peStatus,
								OUT e_IFX_ReasonCode* peReason,
					 			IN void* pvPrivateData
								);															

/*!
	\brief	This callback function is used to asynchronously respond to a Call Hold request.
	This function gives the status of a call hold request issued.
	All agents shall register this callback function with the Call Manager to 
	receive response for their remote call hold requests. The Call Manager 
	invokes this function on an agent if it was not able to convey the 
	status of the call hold request (IFX_CMGR_CallHold) when it was issued.
	\param[in]	 uiCallId The identifier of the call
	\param[in]	 eStatus The status of the request as given by the agent:
						1) IFX_CMGR_STATUS_SUCCESS : The call is now
							HELD.
						2) IFX_CMGR_STATUS_FAIL: The call hold request 
							cannot be fulfilled. The reason for the failure is in the 
							peReason parameter.
						3) IFX_CMGR_STATUS_PENDING: The request has not
							yet been answered. 
	\param[in]	eReason The reason.  Incase of failure, this parameter provides the 
						specific reason. If reason is not applicable then the reason may
						be IFX_MAX_REASON.
	\param[in]  pvPrivateData Pointer to the private data needed by an
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			This call-back is to inform the request initiating agent about
					the status of its request, which was recived asynchronously.
					This will not be invoked if the status was received 
					synchronously, in which case the response would be filled in
					the status and reason parameters of the IFX_CMGR_CallHold 
					function.
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_CallHoldRsp)(
									IN uint32 uiCallId,
									IN e_IFX_CMGR_Status eStatus,
									IN e_IFX_ReasonCode eReason, 
					 				IN void* pvPrivateData
									);							

/*!
	\brief	This callback function is used to asynchronously respond to a Call Resume request.
	This function gives the status of a call resume request issued.
	All agents shall register this callback function with the Call Manager to 
	receive response for their remote call resume requests. The Call Manager 
	invokes this function on an agent if it was not able to convey the 
	status of the callresume request (IFX_CMGR_CallResume) when it was issued.
	\param[in]	 uiCallId The identifier of the call
	\param[in]	 eStatus The status of the request as given by the agent
						1) IFX_CMGR_STATUS_SUCCESS : The call is now
							RESUMED.
						2) IFX_CMGR_STATUS_FAIL: The call resume request 
							cannot be fulfilled. The reason for the failure is in the 
							peReason parameter.
						3) IFX_CMGR_STATUS_PENDING: The request has not
							yet been answered. 
	\param[in]	eReason The reason.  Incase of failure, this parameter provides the 
						specific reason. If reason is not applicable then the reason may
						be IFX_MAX_REASON.
	\param[in]  pvPrivateData Pointer to the private data needed by an
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
	\note			This call-back is to inform the request initiating agent about
					the status of its request, which was recived asynchronously.
					This will not be invoked if the status was received 
					synchronously, in which case the response would be filled in
					the status and reason parameters of the IFX_CMGR_CallResume 
					function.
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_CallResumeRsp)
							(
								IN uint32 uiCallId,
								IN e_IFX_CMGR_Status eStatus,
								IN e_IFX_ReasonCode eReason, 
						 		IN void* pvPrivateData
							);														

/*!
	\brief	This function is used to terminate an ongoing call. 
	All agents shall register this callback function with the Call Manager to 
	receive notifications if the remote party releases the call. 
	This function is invoked by the Call Manager on an agent involved in a 
	call to inform that the call is released by the remote party.  The
	call release may be triggered through the user.  
	\param[in]	uiCallId The identifier of the call
	\param[in]	eRelease The Reason parameter provides the reason for 
					call termination/disruption/rejection
	\param[in]  pxFwdAddr The address that the call has to be forwarded to.
					It is only relevant for the SIP Agent.
	\param[in]  pvPrivateData Pointer to the private data needed by an
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it.
	\return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_RemoteCallRelease)(
							IN uint32 uiCallId,
							IN e_IFX_ReasonCode eReleaseReason,
							IN x_IFX_CMGR_VoipAddr *pxFwdAddr,
					 		IN void* pvPrivateData
							);							

/*!
	\brief	This callback function is used to inform the agents about the 
	call forward status.  Agents that require the information regarding calls
	being forwarded shall register this callback function with the Call Manager.
	This function is invoked by the Call Manager to inform the FXS, DECT and
	FXO agents that a VoIP call initiated from them has been forwarded.  The
	agents may use the information for their display.
	\param[in]	uiCallId The identifier of the call
	\param[in]	eReason The reason parameter provides the reason for 
					call forwarding, if any. If reason is MOVED_PERM,
					the call initiator agent needs to change the 
					address information in the address book (speed dial list).
	\param[in]	pxFwdAddr The address to which the remote party 
					has forwarded the call to.
	\param[out] pbFwdAllow Flag that the agent uses to indicate to the
					CMGR if it wants to allow the CMGR to make a new call to the
					pxFwdAddr address
	\param[in]  pvPrivateData Pointer to the private data needed by an
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it.
	\return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_CallFwdInfo)(
							IN uint32 uiCallId,
							IN e_IFX_ReasonCode eReason, 			
							IN x_IFX_CMGR_VoipAddr* pxFwdAddr,			
							OUT boolean* pbFwdAllow,
					 		IN void* pvPrivateData
							);							
/*!
	\brief	This callback function is used to receive digits during a call.
	Agents that want to receive digits during the call shall register this 
	callback function with the Call Manager.  This function is invoked by
	the Call Manager on an agent to give the digits to the agent.  An example
	is the case of SIP INFO messages carrying DTMF digits during a VoIP
	call.
	\param[in]	uiCallId The identifier of the call
	\param[in]	pxDigitInfo The digit string. May contain one or more digits.
	\param[in]  pvPrivateData Pointer to the private data needed by an
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_DigitsInCallRcv)(
							IN uint32 uiCallId, 
							IN x_IFX_CMGR_DgtInfo *pxDigitInfo, 
					 		IN void* pvPrivateData
							);	

/*!
	\brief	This function asynchronously reports the status of a conference 
	Make or Break) request.  Agents that require the information regarding 
	conference status being forwarded shall register this callback function 
	with the Call Manager. The Call Manager shall invoke this functions on the 
	agent(s) (FXS and DECT) only if it is not able to communicate the status 
	of the conference request through the IFX_CMGR_MakeConf or 
	IFX_CMGR_BreakConf function.  
	\param[in]	ReqId The Request identifier generated for this request 
	\param[in]	eStatus The status of the request. The possible values are:
					1) IFX_CMGR_STATUS_SUCCESS : The conference is now
						Enabled/disabled.
					2) IFX_CMGR_STATUS_FAIL: The conference request 
						cannot be fulfilled.
	\param[in]	eReason The reason for the status.
					If the reason is IFX_CMGR_CONF_ENABLED it The 
					conference is currently enabled.
					If the reason is IFX_CMGR_CONF_DISABLED it The 
					conference is currently disabled.
					If a reason does not apply or is unknown, then value is
					IFX_MAX_REASON.
	\param[in]  pvPrivateData Pointer to the private data needed by an
					agent. The CMGR shall maintain this pointer and return it to
					the agent whenever the agent asks for it. The private data is
					mapped to the request id.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_ConfStatus)(
							IN uint32 ReqId,
							IN e_IFX_CMGR_Status eStatus,
							IN e_IFX_ReasonCode eReason,
					 		IN void* pvPrivateData
							);	

/* @} */ /*function section for Call Control ends*/
/*******************************************************************************
 * This section is only needed for the RTP agent.  - START -
 ******************************************************************************/

/** \defgroup CMGR_RTP_AGT_functions RTP Service
	\brief This section lists the functions provided by the Call Manager for the
			 RTP Agent
*/

/* @{ */
/*!
	\brief Maximum length of the device name string
*/
#define IFX_CMGR_MAX_DEVICE_NAME_LEN 32

/*!
	\brief	Structure(s)  for communication between the Call Manager and the RTP Agent
*/
typedef struct
{
	uint32 uiCallId; /*!< Call Id for the session*/
	char8 szCoderDeviceName[IFX_CMGR_MAX_DEVICE_NAME_LEN];/*!< Coder Device like /dev/vmmc1*/
	uint32 uiSsrcNumber;/*!< SSRC Number*/
	uint32 uiSequenceNumber;/*!< Sequence Number*/
	x_IFX_CMGR_RtpParams xRtpParams;/*!< Info for RTP IP address etc*/
}x_IFX_CMGR_RtpAgentInfo;

/*To be invoked by the CMGR and implemented only by the RTP agent*/
/*!
	\brief This callback function is used to start a RTP Session for a VoIP Call.  
	The  RTP Agent registers this callback function with the call manager.  The 
	Call Manager invokes this function to create a session after the voice media
	parameters have been successfully negotiated between the parties 
	involved in the call.
	\param[in]	pxRtpAgentInfo The RTP session and media related parameters
   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_RtpSessionStart)
		  			(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo
					 );
/*!
	\brief This callback function is used to stop/terminate a RTP Session for a 
	VoIP Call.  The  RTP Agent registers this callback function with the call manager.  The 
	Call Manager invokes this function to terminate a session after the parties
	involved in the call, agree to terminate the call during signaling. 
	\param[in]	pxRtpAgentInfo The RTP session and media related parameters
   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_RtpSessionStop)
		  		(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo
				 );
/*!
	\brief This callback function is used to modify the parameters of a RTP Session.
	The  RTP Agent registers this callback function with the call manager.  The 
	Call Manager invokes this function to modify the session parameters after 
	the voice media parameters have been successfully re-negotiated between the parties 
	involved in the call.
	\param[in]	pxRtpAgentInfo The RTP session and media related parameters
   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_RtpSessionModify)
		  		(IN x_IFX_CMGR_RtpAgentInfo* pxRtpAgentInfo);

/*!
	\brief	This function provides the asynchronous error reporting from the RTP
	Agent.  The RTP Agent invokes this function to report errors when the RTP
	session is in progress.
	\param[in]	 uiCallId The identifier of the call
	\param[in]	 eErrCode Error code.  Incase of failure, this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_RtpMediaError(IN uint32 uiCallId,
					 					 IN e_IFX_ReasonCode eErrCode);
#ifndef LIST_ACCESS
/*******************************************************************************
 * This section is only needed for the DECT Agent - List Access Notifications
 ******************************************************************************/
 /*!
	\brief	Enum listing different kinds of Lists.  Some of the lists
	described below are shared with DECT / CAT iq.
*/
typedef enum
{
	IFX_CMGR_LA_MISSED_CALLS=0,	/*!< Missed Calls List */
	IFX_CMGR_LA_OUTGOING_CALLS=1,	/*!< Outgoing Calls List */
	IFX_CMGR_LA_INCOMING_ACCEPT_CALLS=2,		/*!< Incoming accepted Calls List */
	IFX_CMGR_LA_CONTACTS=3,	/*!< Contacts List */
	IFX_CMGR_LA_LINE_SETTINGS_ASSOC=4,	/*!< Line settings associations list */
	IFX_CMGR_LA_LINE_SETTINGS_CF=5,	/*!< Line settings Call forwarding list */
	IFX_CMGR_LA_LINE_SETTINGS_PSTN=6,	/*!< Line settings PSTN list */
	IFX_CMGR_LA_INTERNAL_NAMES=7, /*!< Internal Names list */
	IFX_CMGR_LA_SYSTEM_SETTINGS=8, /*!< DECT System settings list */
	IFX_CMGR_COMMON_CONTACTS=9	/*!< Indicates Common Contacts */
}e_IFX_CMGR_LA_Type;

/*!
	\brief	This function provides the notification for the changes in the list. This
	function is invoked by the Configuration Agent when it receives notification
	from MAPI-Voice, upon change in any list object to inform the changes to a 
	shared list.  The Call Manager in turn invokes the callback function of the 
	DECT Agent passing the Old and New List objects and the List type to enable it 
	to send the notification to the concerned DECT handsets.
	\param[in] eLAType	Type of the list
	\param[in] pxOld	Old Data buffer
	\param[in] pxNew	New Data buffer 
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_ListAccessNtfy(e_IFX_CMGR_LA_Type eLAType, void * pxOld, void * pxNew);

/*!
	\brief	This callback function provides the notification for the changes in the list. 
	The DECT Agent registers this callback with the Call Manager for receiving List 
	Change Notifications.  The Call Manager invokes the Callback, once for each DECT 
	Endpoint, providing the Handset Id of the handset to be notified, list type 
	and the corresponding Old and New List Objects. The DECT Agent then sends the List 
	Change Notification to the concerned PPs. 
	\param[in] pszEndPtId	Pointer to the Endpoint Structure
	\param[in] eLAType		Type of the list
	\param[in] pxOld	Old Data buffer
	\param[in] pxNew	New Data buffer
   \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_ListAccessNtfn)(
								IN char8 *pszEndPtId, 
					 			IN e_IFX_CMGR_LA_Type eLAType,
								IN void *pxOld,
								IN void *pxNew);

/*!
	\brief	This callback function provides the interface to free MAPI-Voice objects. 
	The DECT Agent registers this callback with the Call Manager to free the Old 
	and New MAPI-Voice Objects subsequent to the notification to the DECT handsets. 
	The Call Manager invokes this callback function after calling the List Change 
	Notification callback, once for each DECT Endpoint.This callback is an indication 
	to the DECT Agent that the List objects are no longer required and can be freed.
	\param[in] eLAType Type of the list
	\param[in] pxOld	Old Data buffer
	\param[in] pxNew	New Data buffer
   \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_ListAccessFreeVmapiObj)(
					 			IN e_IFX_CMGR_LA_Type eLAType,
								IN void *pxOld,
								IN void *pxNew);
#endif

/*!
	\brief	This function provides the interface to set the date and time at an endpoint. 
	This function is invoked by the Call Manager when it receives notification
	regarding the change of system date and time.  The DECT agent passes the received
	information over the air interface to the DECT handset(s).
	\param[in] pxOld	Old Date and Time buffer
	\param[in] pxNew	New Date and Time buffer
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_DateTimeNtfy(void * pxOld, void * pxNew);

/*!
	\brief	This callback function provides the interface to obtain the date and
	time from an endpoint.  
	\param[in] pszEndPtId Pointer to the Endpoint Identifier
	\param[in] pxOld	Old Data buffer
	\param[in] pxNew	New Data buffer
   \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_DateTimeNtfn)(
                IN char8 *pszEndPtId, 
								IN void *pxOld,
								IN void *pxNew);

/*!
	\brief	This function provides the interface to set the context for
	the Attended transfer Context.
	\param[in] uiCallId	The identifier of the call
	\param[in] uiRepCallId	The identifier of the replacement call
	\param[out] peReason Pointer to the reason code
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_SetAtxCnxt (
				IN uint32 uiCallId,
				IN uint32 uiRepCallId,
				OUT e_IFX_ReasonCode* peReason);

/*******************************************************************************
 * This section is only needed for the RTP agent.  - END -
 ******************************************************************************/
/* @} */ /*function section for RTP agent ends*/

/*******************************************************************************
 * This section is only needed for the FAX agent.  - START -
 ******************************************************************************/
/** \defgroup CMGR_FAX_AGT_functions FAX Service
	\brief This section lists the functions provided by the Call Manager for the
			 FAX Agent
*/

/* @{ */

/*!
	\brief	Structure(s) needed for communication between the Call Manager and the Fax Agent
*/
typedef struct
{
	uint32 uiCallId; /*!< Call Id for the session*/
	boolean bStopListen; /*!< Flag to request the Fax agent to stop listening on 
												 	a T.38 TCP server port*/
	char8 szCoderDeviceName[IFX_CMGR_MAX_DEVICE_NAME_LEN];/*!< Coder Device like /dev/vmmc1*/
	x_IFX_CMGR_FaxParams axFaxParams[IFX_MAX_FAX_PROTO]; /*!< Fax Info negotiated from the config*/
	boolean bFaxInitiator; /*!< Fax Initiator*/
	boolean bFaxOnHk; /*!< The fax was disconnected by an Oh-hook from the FXS
										 side or not.*/
}x_IFX_CMGR_FaxAgentInfo;

/*To be invoked by the CMGR and implemented only by the FAX agent*/
/*!
	\brief This callback function is used to indicate to the FAX agent to start 
	waiting for incoming FAX TCP connections. The Fax Agent registers this 
	callback function with the call manager.  The Call Manager invokes this 
	function to provide a TCP port for the Fax agent to start listening on.
	\param[in]	pxFaxAgentInfo The Fax media related parameters

   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_FaxServerListen)
		  			(IN x_IFX_CMGR_FaxAgentInfo* pxFaxAgentInfo);

/*!
	\brief This callback function is used to start a Fax Session for a FoIP Call.  
	The  Fax Agent registers this callback function with the call manager.  The 
	Call Manager invokes this function to create a session after the fax media
	parameters have been successfully negotiated between the parties 
	involved in the call.
	\param[in]	pxFaxAgentInfo The Fax media related parameters

   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_FaxSessionStart)
		  			(IN x_IFX_CMGR_FaxAgentInfo* pxFaxAgentInfo);
/*!
	\brief This callback function is used to stop/terminate a Fax Session for a 
	FoIP Call.  The  Fax Agent registers this callback function with the call manager.  The 
	Call Manager invokes this function to terminate a session after the parties
	involved in the call, agree to terminate the call during signaling. 
	\param[in]	pxFaxAgentInfo The Fax media related parameters

   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_FaxSessionStop)
		  		(IN x_IFX_CMGR_FaxAgentInfo* pxFaxAgentInfo);
/*!
	\brief	To be invoked by the Fax agent and implemented by the CMGR. 
				Informs the CMGR about any error that may have occured.
	\param[in]	 uiCallId The identifier of the call
	\param[in]	 eErrCode Incase of failure, this parameter provides the specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_FaxMediaError(IN uint32 uiCallId,
					 					 IN e_IFX_ReasonCode eErrCode);

/*!
	\brief	This function provides the asynchronous error and status reporting 
	from the Fax Agent.  The Fax Agent invokes this function to report status and 
	errors when the Fax session is in progress.  A typical case of status reporting
	is the completion of fax reception.
	\param[in]	 uiCallId The identifier of the call
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_FaxSessionEnd(IN uint32 uiCallId);
/*******************************************************************************
 * This section is only needed for the FAX agent.  - END -
 ******************************************************************************/
/* @} */ /*function section for FAX agent ends*/

/*******************************************************************************
 * This section is only needed for the SIP registration purpose for
 * Configuration agent and SIP Agent.  - START -
 *******************************************************************************/
/** \defgroup CMGR_CONFIG_functions Configuration Service
 * 			  Services
	\brief This section lists the functions provided by the Call Manager for 
			 Configuration Services
*/
/* @{ */

/*To be invoked by the Configuration agent and implemented by the CMGR*/

/*!
	\brief This function helps in the registration and deregistration of 
	the VoIP Line(s).  This function is invoked by the Configuration agent 
	to trigger a SIP registration/deregistration request.  
	\param[in] pxRegServerInfo Pointer to the Registration Server Info 
	\param [in,out] puiReqId The request identifier for this register/unregister 
			request. If this parameter is non-zero, it is an OUT parameter 
						else it is an IN parameter.
	\param [out] peStatus The status of the request
	\param [out] peReason The reason.  Incase of failure, this parameter provides the 
					 specific reason
	 \param[in] pvPrivateData The private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_Register(
							IN x_IFX_CMGR_RegServerInfo *pxRegServerInfo,
							IN_OUT uint32* puiReqId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason,
							IN void* pvPrivateData);
 
/*!
	\brief This callback function  helps in registration and deregistration of the
	VoIP Lines.  The SIP Agent registers this function at the Call Manager.  This
	function sends out a SIP registration / deregistration message to the SIP
	registrar.  The Call Manager invokes this callback upon receiving a registration/
	deregistration request from the Configuration Agent.
	\param[in] pxRegParams Pointer to registration parameters 
	\param[in] uiReqId The request identifier for this register/unregister 
						request
	\param[out] peStatus The status of the request 
	\param[out] peReason The reason.  Incase of failure, this parameter provides the 
					specific reason
	 \param[in,out] ppvPrivateData The private data for use by the agent.
	 				When the callback is invoked for the first time, this will 
					be an IN parameter.  For further requests this will
					be an OUT parameter.
  \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_Register)(	
							IN x_IFX_CMGR_RegParams *pxRegParams,
							IN uint32 uiReqId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason,
							IN_OUT void** ppvPrivateData
							);
/*!
	\brief This function informs the status on the registration/deregistration 
	request(s).  The SIP Agent invokes this function to inform the Call Manager
	on the status of the registration/deregistration request(s).  The SIP Agent
	invokes this function upon receiving the SIP response for the registration
	request from the Registrar.
	\param[in] uiReqId The request identity for this registration request
	\param[in] uiExpVal The time for which registration was accepted. 
	\param[in] eStatus The status of the requested operation
	\param[in] eReason The reason.  Incase of failure, this parameter provides 
					the specific reason
  \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_RegisterRsp(
							IN uint32 uiReqId,
							IN uint32 uiExpVal,
							IN e_IFX_CMGR_Status eStatus,
							IN e_IFX_ReasonCode eReason
							);	
/*!
	\brief 	This callback function informs the status on the 
	registration/deregistration request(s).  The Configuration Agent registers 
	this function with the Call Manager.  The Call Manager invokes this 
	function to inform the Configuration Agent on the status of the 
	registration/deregistration request(s).  The Call Manager
	invokes this function upon receiving the status of the registration
	request from the SIP Agent.
	\param[in] uiReqId The request identity for this registration request
	\param[in] uiExpVal The time for which registration was accepted. 
	\param[in] eStatus The status of the requested operation
	\param[in] eReason The reason.  Incase of failure, 
				  this parameter provides the specific reason
	 \param[in] pvPrivateData The private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_RegisterRsp)(
							IN uint32 uiReqId,
							IN uint32 uiExpVal,
							IN e_IFX_CMGR_Status eStatus,
							IN e_IFX_ReasonCode eReason,
							IN void* pvPrivateData
							);	


/*******************************************************************************
 * This section is only needed for the SIP registration purpose for
 * Configuration agent and SIP Agent.  - END -
 *******************************************************************************/
/*******************************************************************************
 * This section is only needed for the Configuration agent.  - START -
 *******************************************************************************/
/*!
	\brief This function disconnects all ongoing calls on a VoIP Line.
	This function is invoked by the Configuration Agent to disconnect
	all the calls for a VoIP line.  The Configuration Agent invokes this function
	upon receiving particular events (e.g disabling of VoIP Line) from a 
	configuration entity.  
	\param[in] unLineId The identification for the VoIP Line
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_CallsDiscForLine(
					                 /*VoIP Line Info for which calls have to be released*/
					                               IN uint16 unLineId);

/*!
	\brief This function disconnects all ongoing calls on an endpoint.
	This function is invoked by the Configuration Agent to disconnect
	all the calls on an endpoint.  The Configuration Agent invokes this function
	upon receiving particular events (e.g change of endpoint id) from a 
	configuration entity.  
	\param[in] szEndptId	The identification for the endpoint
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_CallsDiscForEndpt(
					                 /*Endpoint ID for which calls have to be released*/
					                                IN char8* szEndptId);

/*!
	\brief This function disconnects all ongoing calls on the system. 
	This function is invoked by the Configuration Agent to disconnect
	all the calls on the system.   
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_AllCallsDisc(void);

/*!
	\brief Structure used for notification of Voice Mail
*/
typedef struct
{
	boolean bNewMsg; /*!< Flag to indicate new mesage*/
	uint16 unNumOfUnread; /*!< Number of unread messages*/
	uint16 unTotalMsg; /*!< Total number of messages*/
}x_IFX_CMGR_VoiceMailNotifyInfo;

#ifdef CAT_IQ2_0
/*!
	\brief Structure used for notification of Voice Mail
*/
typedef struct
{
	uchar8 ucLineId;/*!< Line Identifier*/
	char8* acEndptId[IFX_MAX_ENDPOINTID_LEN];/*!< Endpoint Identifier*/
}x_IFX_CMGR_VoiceMailEPNotify;
#endif


/*!
	\brief This function  helps in subscription to the Voice mail
	service.  This function is invoked by the Configuration agent 
	to trigger a SIP subscription request. 
	\param[in] unLineId The VoIP Line ID requested 
	\param[in] uiExpVal The time for which subscription  is requested.
				  Zero for unsubscribe request
	\param [in,out] puiReqId is the request identifier for this subscribe 
						request
	\param [ out]	 peStatus The status of the request 
	\param [ out]	 peReason The reason.  Incase of failure, this parameter provides the specific reason
	 \param[in] pvPrivateData The private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_VM_Subn(
					 		IN uint16 unLineId,
							IN uint32 uiExpVal,
							IN_OUT uint32* puiReqId,
							OUT e_IFX_CMGR_Status *peStatus,
							OUT e_IFX_ReasonCode *peReason,
							IN void* pvPrivateData
					 		);

/*!
	\brief This callback function informs the status on the voice mail subscription 
	request(s).  The Configuration Agent registers this function with the 
	Call Manager. The Call Manager invokes this function to inform the 
	Configuration Agent on the status of the subscription request(s).  
	The Call Manager invokes this function upon receiving the status of the 
	subscription request from the SIP Agent.
	\param[in] uiReqId The request identity for this subscription request
	\param[in] uiExpVal The time for which subscription was accepted. 
	\param[in] eStatus The status of the requested operation
	\param[in] eReason The reason.  Incase of failure, 
				  this parameter provides the specific reason
	 \param[in] pvPrivateData The private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_VM_SubnRsp)(
							IN uint32 uiReqId,
							IN uint32 uiExpVal,
							IN e_IFX_CMGR_Status eStatus,
							IN e_IFX_ReasonCode eReason,
							IN void* pvPrivateData
							);

/*!
	\brief This callback function forwards the notifications received on a 
	subscription for the voice mail service.  The Configuration Agent registers 
	this function with the Call Manager. The Call Manager invokes this function 
	to inform the Configuration Agent on the notifications received on the 
	subscription.  The Call Manager invokes this function upon receiving the 
	notifications from the SIP Agent.
	\param[in] uiReqId The request identifier for this subscription request
	\param[in] pxNotifyInfo the body of the notify message
	 \param[in] pvPrivateData The private data for use by the agent
   \return     IFX_SUCCESS or IFX_FAILURE
*/
typedef e_IFX_Return (*pfn_IFX_CMGR_VM_NtfnRcv)(
							IN uint32 uiReqId,
							IN x_IFX_CMGR_VoiceMailNotifyInfo* pxNotifyInfo,
							IN void* pvPrivateData
							);


/* @} */
/*******************************************************************************
 *  This section is only needed for the Configuration agent.  - END -
 *******************************************************************************/


/* ****************************************************************************
 * functions that need to be invoked by Agents for Subscription manipulations
 * ****************************************************************************/

/** \defgroup CMGR_SUBS_functions Subscribe/Notify Service
 * 			  Services
	\brief This section lists the functions provided by the Call Manager for 
			Subscribe Notify Services
*/
/* @{ */
/*!
	\brief	This function activates the automatic redial on busy feature on 
	a VoIP Line.  This function is invoked by an Agent, FXS or DECT,  when they 
	need to enable automatic redial to a remote VoIP party. The need to enable
	the automatic redial arises when the user requests for it at an endpoint,
	Upon receiving the request from the agent(s), the Call Manager initiates 
	the subscription procedure with the remote VoIP party.  This function 
	shall be invoked only by the FXS or DECT agents.
	\param[in]	pxTo The address of the busy remote party
	\param[in] pxFrom The address of the request initiator, the FXS or DECT
				endpoints (Extensions)
	\param[in] bActivate Flag indicating if the request is for activation
					or deactivation of the feature.
 	\param[in,out] puiReqId The request identifier for the request. During 
					activation it, this is treated as an OUT parameter.
					For a subsequent deactivation, this is treated as an IN
					parameter.
	\param[out] peStatus The status of the request : One of pending/success/failure
	\param[out]	peRespCode The response code in case of failure
	 \param[in] pvPrivateData The private data for use by the agent
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_ARD_Activate(
					 	IN x_IFX_CMGR_AddressInfo* pxTo,
					 	IN x_IFX_CMGR_AddressInfo* pxFrom,
						IN boolean bActivate,
						IN_OUT uint32* puiReqId,
						OUT e_IFX_CMGR_Status* peStatus,
						OUT e_IFX_ReasonCode* peRespCode,
						IN void* pvPrivateData
					 );	
/*!
	\brief	This callback function informs the status on the automatic redial
	on busy request(s).  The agents, viz., FXS and DECT, register this function 
	with the Call Manager to receive status information on the automatic 
	redial request.  The Call Manager invokes this function to inform the 
	FXS/DECT Agent(s)  on the status of the subscription request(s).  
	The Call Manager invokes this function upon receiving the status of the 
	automatic redial subscription request from the SIP Agent.  This function 
	is essential for the Call Manager. The status of the request cannot
	be reported as a return value of the IFX_CMGR_ARD_Activate because
	it involves interaction with the remote VoIP party.
	\param[in]	uiReqId The request identifier
	\param[in] eSubsStatus The status: One of pending/success/failure
	\param[in] eRespCode The response code in case of failure
	 \param[in] pvPrivateData The private data for use by the agent
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_ARD_Status)(
					 	IN uint32 uiReqId,
						IN e_IFX_CMGR_Status eSubsStatus,
						IN e_IFX_ReasonCode eRespCode,
						IN void* pvPrivateData
					 );

/*!
	\brief	This callback function forwards the notifications received on
	the subscription for automatic redial on busy.  The agents, FXS and DECT, 
	register this function with the Call Manager to receive notifications on
	the subscription for the automatic redial request.  The Call Manager invokes this 
	function to inform the FXS/DECT Agent(s)  on the notifications received on
	the subscription request(s).  The Call Manager invokes this function upon receiving 
	the notifications on the automatic redial subscription request from the SIP Agent. 
	\param[in]	uiReqId The request identifier, 
	\param[in]	eRemoteStatus Remote Party status.  Indicates if the remote party 
				is now free to take a call or not
	\param[in] eRespCode The response code in case of failure. Contains a value enum in 
				case Notify Terminated is received.
	 \param[in] pvPrivateData The private data for use by the agent
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_ARD_NtfnRcv)(
					 	IN uint32 uiReqId,
						IN e_IFX_CMGR_Status eRemoteStatus, 
						IN e_IFX_ReasonCode eRespCode,
						IN void* pvPrivateData
					 );
/*! 
	\brief	This callback function is used to report the endpoints availability for an
	automatic redial on busy subscription request received.  The agents, FXS 
	and DECT, register this function with the Call Manager to report the 
	availability of their endpoints.  In particular, this function performs the 
	following tasks:
	a.) Ask agent(s) about the current status of their endpoints(busy/free)
	b.) If the endpoint in contention is busy currently, request agent(s) to 
		invoke a function as soon as the endpoint is free
	Based on the response received, the Call Manager sends out a notification 
	to the remote party on the subscription.
	\param[in]	uiReqId The request identifier,  
	\param[in] bEnable Flag to indicate to the agent that the callback function
			is being called for enabling Auto Redial.
	\param[in] szEndptId is the Endpoint for which this request is destined.
	\param[out]	peLocalStatus Local Status.  Indicates if the local endpoint is free 
					to take a call or not,
	\param[in] ppvPrivateData The private data for use by the agent. Its
					set by the agent while the enable ARD request and is passed
					back by the CMGR while disabling the ARD.
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_ARD_Register)(
					 	IN uint32 uiReqId,
						IN boolean bEnable,
						IN char8* szEndptId,
						OUT e_IFX_CMGR_Status* peLocalStatus,
						IN void ** ppvPrivateData
					 );

/*!
	\brief	This function communicates the availability of an endpoint.  This
	function is invoked by the FXS or DECT agent(s) to inform the Call Manager
	that the endpoint in contention is free.  This function is invoked by the 
	FXS or DECT agent(s) in response to the pfn_IFX_CMGR_ARD_Register callback
	function.  Upon receiving this information, the Call Manager, initiates the 
	notification to the remote party on the subscription.  The agent can delete
	the request identifier associated with the request after invocation of 
	this function.
	\param[in]	uiReqId The request identifier,
	\param[in]	eLocalStatus Local Status.  Indicates if the local endpoint is free 
					to take a call or not,
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_ARD_Ntf(
					 	IN uint32 uiReqId,
						IN e_IFX_CMGR_Status eLocalStatus 
					 );

/************************ functions & CallBacks For NA only***********************/

/*!
	\brief	Enum listing different kinds of subscriptions
*/
typedef enum
{
	IFX_CMGR_SUBS_VOICE_MAIL=0, /*!< Indicates that the event is Voice Mail*/
	IFX_CMGR_SUBS_AUTO_REDIAL=1,/*!< Indicates that the event is Auto Redial*/
	IFX_CMGR_SUBS_MAX=2 /*!< Indicates Max Subscription codes */
}e_IFX_CMGR_SubsEvent;

/*!
	\brief Structure for Notification for Auto Redial
*/
typedef struct
{
	boolean bRemoteFree;/*!< Flag to indicate if the remote party is 
								 	 free for a call*/
}x_IFX_CMGR_ARD_NotifyInfo;


/*!
	\brief Union of Notification information  for all events 
*/
typedef union
{
	x_IFX_CMGR_VoiceMailNotifyInfo xVmNtfyInfo;/*!< Voice Mail notify Info*/
	x_IFX_CMGR_ARD_NotifyInfo xAutoNtfyInfo;/*!< Auto Redial Notify Info*/
}ux_IFX_CMGR_NotifyInfo;

/*!
	\brief Structure containing notification information for all events 
*/
typedef struct
{
	e_IFX_CMGR_SubsEvent eSubsEvt;/*!< Identifying the type of notify event*/
	x_IFX_CMGR_AddressInfo xFromAddress;/*!< The source of the unsolicited notify*/
	x_IFX_CMGR_AddressInfo xToAddress;/*!< The destination of the unsolicited notify*/
	ux_IFX_CMGR_NotifyInfo uxNotifyInfo;/*!< Info about the event*/
}x_IFX_CMGR_NotifyInfo;

/*!
	\brief	This callback function helps to subscribe on an event with a 
	remote party.  The SIP Agent registers this function with the Call Manager.
	This callback function is invoked by the Call Manager on the SIP Agent to
	request the SIP Agent to subscribe with a remote party for a certain event.
	\param[in] pxToAddr The remote party to subscribe to. 
	\param[in] unLineId The local Line identifier
	\param[in] eSubsEvt The subscription event
	\param[in] uiReqId The request identifier for this transaction
	\param[in,out] peStatus The status of the request: One of pending/success/failure
	\param[out]	peRespCode The response code in case of failure
	\param[in,out] ppvPrivateData The private data for use by the agent. 
						This parameter wil be treated as an OUT parameter
						if the uiReqId has been generated the first time. 
						It will be treated as an IN parameter if the uiReqId is old.
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_SubnSnd)(
					 	IN x_IFX_CMGR_AddressInfo* pxToAddr,
					 	IN uint16 unLineId,
						IN e_IFX_CMGR_SubsEvent eSubsEvt,
					 	IN uint32 uiReqId,
						OUT e_IFX_CMGR_Status* peStatus,
						IN_OUT e_IFX_ReasonCode* peRespCode,
						IN_OUT void ** ppvPrivateData
					 );

/*!
	\brief	This function reports the status of the subscription request.
	The SIP Agent invokes this function as a response to the pfn_IFX_CMGR_SubnSnd
	callback function.  This function is invoked by the SIP Agent after it 
	receives an acceptance / rejection from the remote party for the subscription
	request.  
	\param[in]	uiReqId The request identifier
	\param[in] uiExpTime The time for which the subscription was accepted
	\param[in]  eSubsStatus The status of the requested subscription
	\param[in]	eRespCode The response code in case of failure
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_SubnStatus(
					 	IN uint32 uiReqId,
						IN uint32 uiExpTime,
						IN e_IFX_CMGR_Status eSubsStatus,
						IN e_IFX_ReasonCode eRespCode);

/*!
	\brief	This function informs about the notify received on a subscription.
	This function is invoked by the SIP Agent when it receives a SIP NOTIFY
	message from a remote party or server on a subscription.  The Call Manager
	upon receiving this information forwards the notification message internally
	to the agents.
	\param[in,out] puiReqId The request identifier
	\param[in] uiExpTime The time for which the subscription has been active
	\param[in]  pxNotifyInfo The information carried in the SIP NOTIFY message.
	\param[out] peNotifyAccepted The response from the Call Manager to indicate if
					a 200 OK for the notify is to be sent out. 
					This information is needed to handle unsolicited notify(s).
	\param[out] peReason The reason for possible rejection
	\param[in] pvPrivateData The private data for use by the agent.
						This will be populated if the *puiReqId value is Zero.
						This means that the SIP Agent is reauesting the 
						Call Manager to generate a new request id for 
						an unsolicited notify.  The parameter should be null,
						when a normal notify is being reported, as it is on an 
						already existing ReqId.
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_NtfnRcv(
					 	IN_OUT uint32* puiReqId,
						IN uint32 uiExpTime,
						IN x_IFX_CMGR_NotifyInfo* pxNotifyInfo,
						OUT e_IFX_CMGR_Status *peNotifyAccepted,
						OUT e_IFX_ReasonCode *peReason,
						IN void* pvPrivateData
					 );
/*!
	\brief	This function informs about an incoming subscription request 
	from a remote party.  This function is invoked by the SIP Agent when it 
	receives a SIP subscription request from a remote party or server for a subscription
	request.  The Call Manager upon receiving this request, depending on the 
	event involved in the subscription, communicates to the agent(s).
	\param[in]  eSubsEvt The subscription event type
	\param[in]  pxFrom The address of the remote party
	\param[in]  pxTo The VoIP Line for which the subscription is received
 	\param[in,out] puiExpTime The subscription expiry time accepted by the 
				Call Manager
	\param[in]	pvPrivateData The private data for the use of the SIP Agent
	\param[out]	punLineId The voice line identifier to be used for this transaction.
 	\param[out]	puiReqId The request identifier
	\param[out] peStatus The subscription response by the destined party
	\param[out]	peReason The reason code in case of failure
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_SubnRcv(
						IN e_IFX_CMGR_SubsEvent eSubsEvt,
					 	IN x_IFX_CMGR_AddressInfo* pxFrom,
					 	IN x_IFX_CMGR_AddressInfo* pxTo,
						IN_OUT uint32* puiExpTime,
						IN void* pvPrivateData,
						OUT uint16 *punLineId,
					 	OUT uint32* puiReqId,
						OUT e_IFX_CMGR_Status* peStatus,
						OUT e_IFX_ReasonCode* peReason);

/*!
	\brief	This callback function informs about the status of a requested
	subscription.  The SIP Agent shall register this function with the Call Manager
	to gather information on the status of the subscription request.
	The Call Manager shall invoke this function to inform the
	SIP Agent about the status of a previously requested subscription.  The
	Call Manager invokes this function in response to a IFX_CMGR_SubnRcv
	function.  The Call Manager will invoke this function only if a response 
	cannot be prepared when processing the IFX_CMGR_SubnRcv.
 	\param[in]	uiReqId The request identifier
	\param[in] uiExpTime The time for which the subscription is accepted
	\param[in] eSubsStatus The subscription status from the remote party
	\param[in]	eRespCode The response code in case of failure
	 \param[in] pvPrivateData The private data for use by the agent
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_SubnStatus)(
					 	IN uint32 uiReqId,
						IN uint32 uiExpTime,
						IN e_IFX_CMGR_Status eSubsStatus,
						IN e_IFX_ReasonCode eRespCode,
						IN void* pvPrivateData
					 );
/*!
	\brief	This callback function helps in sending a SIP NOTIFY message on
	an accepted subscription.  The SIP Agent registers this function with the 
	Call Manager to know when to send a SIP Notify message.  The trigger to 
	issue a notification comes from the FXS or DECT agent(s) and the Call Manager
	invokes this function as a consequence.  The SIP Agent upon receiving
	this information, sends a NOTIFY message to the remote party.
	\param[in]	uiReqId The request identifier
	\param[in]  pxNotifyInfo The information carried in the NOTIFY message.
					To be sent out over the network.
	\param[out] peStatus The status for the send notify request				
	\param[out]	peRespCode The response code in case of failure
	 \param[in] pvPrivateData The private data for use by the agent
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_NtfnSnd)(
					 	IN uint32 uiReqId,
						IN x_IFX_CMGR_NotifyInfo *pxNotifyInfo,
						OUT e_IFX_CMGR_Status* peStatus,
						OUT e_IFX_ReasonCode* peRespCode,
						IN void* pvPrivateData
					 );
/* @} */

/* ****************************************************************************
 * functions that need to be invoked by Agents for Subscription manipulations
 * ****************************************************************************/

/* ****************************************************************************
 * functions & Callbacks for Transfers
 * ****************************************************************************/

/** \defgroup CMGR_TXFER_functions Transfer Service
	\brief This section lists the functions provided by the Call Manager 
	 for Blind and Attended Transfer Services.
*/
/* @{ */

/*!
	\brief Enum containing the transfer states 
*/
typedef enum
{
	IFX_CMGR_TRANSFER_ACCEPTED=0, /*!< Transfer accepted by the Transferee */
	IFX_CMGR_TRANSFER_REJECTED=1,/*!< Transfer rejected by Transferee */
	IFX_CMGR_TRANSFER_PENDING=2,/*!< Transfer response pending from the Transferee */
	IFX_CMGR_TRANSFER_PROCEEDING=3, /*!< 100 response received */
	IFX_CMGR_TRANSFER_RINGING=4, /*!< 180 response received */
	IFX_CMGR_TRANSFER_ANSWERED=5, /*!< 200 response received */
	IFX_CMGR_TRANSFER_FAILED=6, /*!< Non 2XX final response received */
}e_IFX_TransferStatus;



/*!
	\brief This callback function is used for replacement of the call identifiers
	during the transfer scenarios.  The agents register this function with the 
	call manager.  This function is invoked by the Call Manager during the 
	call transfer.
	\param[in] uiOldCallId The call identifier to be replaced
	\param[in] uiNewCallId The call identifier to be used from now on
	\param[in,out] ppvPrivateData The private data mapped to the old call identifier. 
						The agent can modify it to the new call identifier while returning the
						function.
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_CallIdReplace)
							(
								IN uint32 uiOldCallId,
								IN uint32 uiNewCallId,
								IN_OUT void ** ppvPrivateData
							);

/*!
	\brief This function helps to achieve the blind call transfer.  This function 
	is invoked by an agent (FXS or DECT or SIP)  when it needs  
	to transfer a call on one of its endpoints to the mentioned 
	destination (endpoint/address). The TargetAddress
	may contain a PSTN number if the call is being transferred to PSTN
	or it may contain the complete VoIP address if the call is being transferred
	to VoIP.
	\param[in]	uiCallId The call identifier of the call to transfer
	\param[in]	pxTargetAddr The address and type of the transfer target. This could
					be VoIP/PSTN/Extension number.
 	\param[out]	peTransferStatus Transfer status.  Transfer accepted or not.
 	\param[out]	peRespCode Response code in case the transfer request was
					not accepted
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_BlindTx(
					 	IN uint32 uiCallId,
						/*The Target party's address*/
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						/*Agent may get Accepted/Rejected*/ 
						OUT e_IFX_TransferStatus* peTransferStatus,
						/*Agent may get Reason for Rejection*/ 
						OUT e_IFX_ReasonCode *peRespCode
					 );	
/*!
	\brief	This callback function handles blind call transfer requests.
	The agents supporting blind call transfer shall register this function with 
	the call manager.  This callback function is invoked by the Call Manager 
	asking an Agent, FXS or DECT if it wants to transfer a call on one of its
	endpoints to the mentioned endpoint/address. The TargetAddress
	may contain a PSTN number if the call is being transferred to PSTN 
	or it may contain the complete VoIP address if the call is being transferred
	to VoIP.
	\param[in]	uiCallId The call identifier of the call to transfer
	\param[in]	pxTargetAddr The address of a voice line or a PSTN number
					or the extension number
 	\param[out]	peTransferStatus Transfer Status: Accepted/Not accepted
 	\param[out]	peRespCode Response code in case the transfer request was
					not accepted
	\param[in]  pvPrivateData The private data for the use of the agent.
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_BlindTxReq)(
					 	IN uint32 uiCallId,
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						OUT e_IFX_TransferStatus* peTransferStatus,
						OUT e_IFX_ReasonCode *peRespCode,
						IN void* pvPrivateData
					 );	
					 					

/*!
	\brief This function confirms the willingness on the agent's part to
	transfer the call on one of its endpoints.  This function is invoked by an Agent,  when it
	wants to allow a call to be transferred.  In the case of the SIP Agent, this
	function is also used to accept a REFER and the NOTIFY.
	\param[in]	uiCallId The call identifier of the call in transfer
	\param[in]	eTransferStatus Transfer Status, used for accepting/rejecting a 
					Transfer request (Refer) before the transfer starts. 
					This is called by the Transferee.  This parameter 
					is also used for notifying the Call Manager about about reception 
					of Notify 180/Notify 200 events,  when called by the 
					transfareee in the middle of transfer.
	\param[in] eRespCode The reason for a possible Transfer request rejection.
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_BlindTxStatus(
					 	IN uint32 uiCallId,
						IN e_IFX_TransferStatus eTransferStatus,
						IN e_IFX_ReasonCode eRespCode 
					 );	

/*!
	\brief This callback function reports the status of a blind call transfer 
	request.  This function is registered by agents that need the status 
	information on the blind call transfer request(s), issued.This callback 
	function is invoked by the Call Manager on an Agent, FXS or DECT when it 
	 needs to inform the agents that the call  transfer requested by it has 
	succeeded/failed.  This is also invoked when the SIP Agent is to be 
	requested for sending of a 1XX/18X/2XX notification. This function is
	also invoked on the FXS or DECT agent(s) to inform them about the remote 
	party's state, in the process of forming the new call.
	\param[in]	uiCallId The call identifier of the call in transfer
	\param[in]	eTransferStatus TransferStatus is used for informing the transferer about 
					the transferee's decision on accepting/rejecting the
					transfer request (Refer) before the transfer starts. Its also used
					to notify the agent about the state of the new call being formed,
					i.e. to send NOTIFY.
	\param[in] eRespCode The reason for a possible Transfer request rejection.
	\param[in]  pvPrivateData The private data for the use of the agent.
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_BlindTxStatus)(
					 	IN uint32 uiCallId,
						/* Used for notifying the agent about 
							the state of the new call being formed*/ 
						IN e_IFX_TransferStatus eTransferStatus, 
						/*Reason for Failure*/
						IN e_IFX_ReasonCode eRespCode,
						IN void* pvPrivateData
					 );	


/************************Attended Transfer****************************/

/*!
 	\brief This function helps to achieve the attended call transfer.  This 
	function is invoked by an agent (FXS or DECT or SIP)  when it needs  
	to transfer a call on one of its endpoints to the mentioned 
	destination (endpoint/address). The TargetAddress may contain 
	a PSTN number if the call is being transferred to PSTN
	or it may contain the complete VoIP address if the call is being transferred
	to VoIP.  The ReplacesCallId contains the call identifier to be 
	sent in/received from the Replaces header.  The Refer has to be sent 
	on the first call identifier. 
	\param[in] uiCallId The call identifier on which Refer is to be sent/received
	\param[in] uiReplacesCallId Replaces Call identifier is sent/received in the replaces header
	\param[in] pxTargetAddr Target Address is used by the SIP Agent to inform the CMGR 
				  about the target address
	\param[out] peTransferStatus Transfer request accepted or not.
	\param[out] peRespCode Reason code for transfer request rejection.
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_AttendedTx(
					 	/*call identifier on which Refer is sent or received*/
					 	IN uint32 uiCallId,
					 	/*call identifier which is sent/received to/from the replaces header*/
						IN uint32 uiReplacesCallId,
						/*Only for use by NA - Not required by other agents*/
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						/*Agent may get Accepted/Rejected*/ 
						OUT e_IFX_TransferStatus* peTransferStatus,
						/*Agent may get Reason for Rejection*/ 
						OUT e_IFX_ReasonCode *peRespCode
					 );	

/*!
	\brief	This callback function handles attended call transfer requests.
	The agents supporting attended call transfer shall register this function with 
	the call manager.  This callback function is invoked by the Call Manager 
	asking an Agent, FXS or DECT if it wants to transfer a call on one of its
	endpoints to the mentioned endpoint/address. The TargetAddress
	may contain a PSTN number if the call is being transferred to PSTN 
	or it may contain the complete VoIP address if the call is being transferred
	to VoIP.  This function is also used by the SIP Agent to send out a
	REFER with Replaces.
	\param[in] uiCallId The call identifier of the call
	\param[in] uiReplacesCallId Replacement Call identifier is sent/received in 
				the replaces header. 
	\param[in] pxTargetAddr Target Address.  Can be used by DECT for display.
	\param[out] peTransferStatus Transfer request accepted or not.
	\param[out] peRespCode Reason code for transfer request rejection.
	\param[in]  pvPrivateData The private data for the use of the agent.
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_AttendedTxReq)(
					 	/*This will the call identifier that is relevant to the B side */
					 	IN uint32 uiCallId,
					 	/*Only for NA - To send a Refer with Replaces*/
						IN uint32 uiReplacesCallId,
						/*Only for use by DECT may be for display*/
						IN x_IFX_CMGR_AddressInfo* pxTargetAddr,
						/*Agent may fill IFX_TRANSFER_ACCEPTED/REJECTED*/
						OUT e_IFX_TransferStatus* peTransferStatus,
						/*Agent may fill Reason for Rejection*/
						OUT e_IFX_ReasonCode *peRespCode,
						IN void* pvPrivateData
					 );	

/*!
 	\brief	This function confirms the willingness on the agent's part to
	transfer the call on one of its endpoints.  This function is invoked by an Agent,  when it
	wants to allow a call to be transferred.  In the case of the SIP Agent, this
	function is also used to accept a REFER and the NOTIFY.
	\param[in]	uiCallId The call identifier of the call in transfer
	\param[in]	eTransferStatus Transfer Status, used for accepting/rejecting a 
					Transfer request (Refer) before the transfer starts. 
					This is called by the Transferee.  This parameter 
					is also used for notifying the Call Manager about about reception 
					of Notify 180/Notify 200 events,  when called by the 
					transfareee in the middle of transfer.
	\param[in] eRespCode The reason for a possible Transfer request rejection.
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_AttendedTxStatus(
					 	/*Call Id for the B side Call that was being transferred*/
					 	IN uint32 uiCallId,
						/* Used for accepting/rejecting a Transfer request 
						 * (Refer) before the transfer starts -Called by the Transferee.
						 * Used for notifying the CMGR about about 
						 * reception of Notify 180/Notify 200 events. - When called 
						 * by B Side in middle of transfer.*/
						IN e_IFX_TransferStatus eTransferStatus,
						/*Reason for a possible Refer Rejection/Failure*/
						IN e_IFX_ReasonCode eRespCode 
					 );	

/*!
	\brief	This callback function reports the status of a attended call transfer 
	request.  This function is registered by agents that need the status 
	information on the blind call transfer request(s), issued.This callback 
	function is invoked by the Call Manager on an Agent, FXS or DECT when it 
	 needs to inform the agents that the call  transfer requested by it has 
	succeeded/failed.  This is also invoked when the SIP Agent is to be 
	requested for sending of a 1XX/18X/2XX notification. This function is
	also invoked on the FXS or DECT agent(s) to inform them about the remote 
	party's state, in the process of forming the new call.
	\param[in]	uiCallId The call identifier of the call in transfer,
	\param[in]	eTransferStatus TransferStatus is used for informing the transferer about 
					the transferee's decision on accepting/rejecting the
					transfer request (Refer) before the transfer starts. Its also used
					to notify the agent about the state of the new call being formed,
					i.e. to send NOTIFY.
	\param[in] eRespCode The reason for a possible Transfer request rejection.
	\param[in]  pvPrivateData The private data for the use of the agent.
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_AttendedTxStatus)(
					 	IN uint32 uiCallId,
						/* Used for notifying the agent about 
							the state of the new call being formed*/ 
						IN e_IFX_TransferStatus eTransferStatus, 
						/*Reason for Failure*/
						IN e_IFX_ReasonCode eRespCode,
						IN void* pvPrivateData
					 );	
/* @} */

/* ****************************************************************************
 * functions & Callbacks for Transfers - END
 * ****************************************************************************/

/* ****************************************************************************
 * functions & Callbacks for SMS - START
 * ****************************************************************************/
#ifdef MESSAGE_SUPPORT
/** \defgroup CMGR_Msg_functions SMS Services
	\brief This section lists the functions provided by the Call Manager for 
	 message Services.
*/
/* @{ */

/*!
 \brief Maximum length of SMS body string
 */
#define IFX_MSG_MAX_BODY_SZ 160

/*!
 \brief Maximum length of SMS body string
 */
#define IFX_MSG_MAX_PER_LINE 5 

#define IFX_MAX_MSG_HDL 5

typedef struct {
	uint32 uiMsgHdl;
	uint32 uiReqId;
}x_IFX_Msg_Hndls;

typedef enum {
	IFX_MSG_IN=1,
	IFX_MSG_OUT=2,
	IFX_MSG_MAX=3
}e_IFX_MsgBox;

/*! 
 	 \brief Structure for Message storage 
*/
typedef struct
{
  char8 acUserName[IFX_MAX_USR_NAME];
	boolean bMsgUnread;/*!< Read or Unread  0=UnRead, 1= Read*/
	char8 szMsgBody[IFX_MSG_MAX_BODY_SZ];/*!< Message Body*/
	uint32 uiMsgHdl;/*!< Message Id - Unique identifier for the SMS*/
}x_IFX_CMGR_Msg_Info;

/* ****************************************************************************
 * functions that need to be invoked by the Agents for message manipulations
 * ****************************************************************************/
/*!
 	\brief	This function retrieves the SMS.  This function is invoked by an 
	Agent, viz., DECT, when it needs to retreive a specific message from the 
	Call Manager. The agent invokes this function after getting a notification 
	from the user asking for the contents of a particular message.  
	The message is retrieved using the message identifier.  The complete message 
	is returned in the function.
	\param[in,out]	pxMsgInfo Pointer to the message Information structure. 
					unMsgId is the Msg Identification in the structure that will be 
					filled by the Call Manager while returning the function. 
	\return IFX_SUCCESS or IFX_FAILURE
 */
					 					
e_IFX_Return IFX_CMGR_Msg_Read(IN uchar8 uiLindId,
																 IN uint32 uiMsgHdl,
																 OUT x_IFX_CMGR_Msg_Info* pxMsgInfo);

e_IFX_Return IFX_CMGR_Msg_Delete(IN uchar8 uiLindId,
																    IN uint32 uiMsgHdl);

				 					
/*!
 	\brief This function retrieves all the message headers.  This function is 
	invoked by an agent, viz., DECT, when it needs to retrieve all the message
	headers.  The agent invokes this function after getting a notification from
	the user asking for the listing of all messages.  An example is that the
	user selects the Inbox option in the DECT handset.  This function
	only returns the header(s) of the messages, not the body of the messages.
	
 	\param[in]	szEndptId The Endpoint Id of an endpoint managed by the DECT agent
 	\param[out]	ppaxMsgInfo Pointer to an array of pointers containing 
					the Msg Information sans the message body. The body shall be NULL.
					This memory has to be freed by the caller.
	\param[out] puiMessageArrayLen The Length of header array 
	\return IFX_SUCCESS or IFX_FAILURE */
 e_IFX_Return IFX_CMGR_Msg_GetHdrs(IN  uchar8 uiLindId,
														      IN  e_IFX_MsgBox eBox,
															    OUT x_IFX_CMGR_Msg_Info *pxMsgInfo,
															    OUT uint16* puiCount);

/*!
	\brief This function reports the status of a previously issued
	
	This function is invoked by the SIP Agent/FXO agent to inform the CMGR 
			about the status of a previously requested message.
	\param[in] unMsgId is the ID of the message
	\param[in] eMsgStatus is the status and caries values like 
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_Msg_Status(
									IN uint32 unMsgId,
									IN e_IFX_CMGR_Status eMsgStatus
					 			);	


/* !
	\brief This function helps to send out a message.  This function is invoked by an 
	Agent when it needs to send a message to a remote VoIP/PSTN party. 
	This function can be invoked by the FXO and SIP agents.
 	\param[in] pxFrom The message From Address. 
	\param[in] pxTo The Msg To Address.
	\param[in] szMsgBody The complete text body of the message
	\param[out] punMsgId The pointer to the Msg identifier
	\param[out] peMsgStatus The Status of the MESSAGE request 
	\param[out] peReason is the reason for failure
	\return IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_Msg_Send(	IN x_IFX_CMGR_AddressInfo *pxFrom,
																	IN x_IFX_CMGR_AddressInfo *pxTo,
														      IN char8* szMsgBody,
																	OUT uint32* puiMsgHdl,
																	OUT e_IFX_CMGR_Status* peStatus,
																	OUT e_IFX_ReasonCode* peReason);

/* ****************************************************************************
 * Callbacks that need to be invoked by the CMGR for Msg manipulations
 * ****************************************************************************/

/*!
	\brief This callback function invoked by  CMGR when it needs 
			 to inform the Agent about a new Message. This would be invoked on the 
			 FXO,DECT and NA to send a message over their respective networks. 
 	\param[in] pxFrom is the Msg From Address. 
	\param[in] pxTo is the Msg To Address. 
	\param[in] szMsgBody The complete text body of the Message. Maybe NULL 
				  for SMS to DECT
	\param[in] bUnread Indicates to the DECT agent that the message is new. 
				  To be ignored by NA
	\param[in] unMsgId is the pointer to the Msg id
	\param[out] peMsgStatus is the Status of the Msg request 
	\param[out] peReason is the reason for failure
	\return IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_Msg_Rcv)(
									IN x_IFX_CMGR_AddressInfo *pxFrom,
									IN x_IFX_CMGR_AddressInfo *pxTo,
									IN char8* szMsgBody,
									IN uint32 unMsgId,
								  IN uchar8 ucLineId,
									OUT e_IFX_ReasonCode* peReason);

/*!
	\brief	This callback function helps in retrieving the message status.
	Agents that need to make use of the SMS feature shall register
	this callback function with the call manager.  The Call Manager
	invokes this function on the (DECT) agent to inform the status of 
	an message sent previously,
	
	\param[in] unMsgId The message identifier
	\param[in] eMsgStatus The status, caries values like 
	\return IFX_SUCCESS or IFX_FAILURE
 */

typedef e_IFX_Return (*pfn_IFX_CMGR_Msg_Status)(
									IN uint32 unMsgHdl,
									IN e_IFX_CMGR_Status eMsgStatus
					 			);
/* @} */
#endif // MESSAGE_SUPPORT

/** \defgroup CMGR_MISC_functions Misc Service
	\brief This section lists the functions provided by the Call Manager for 
		Miscellaneous Services
*/
/*******************************************************************************
 * This section is only needed for Init & Shut - START -
 *******************************************************************************/

/* @{ */
/*!
	\brief The Endpoint identification to be used by the SIP Agent while registering with 
			the Call manager.
*/
#define IFX_NA_ENDPT_ID "-1"
/*!
	\brief The Endpoint identification to be used by the RTP Agent while registering with 
			the Call manager.
*/
#define IFX_RTP_AGENT_ENDPT_ID "-2"
/*!
	\brief The Endpoint identification to be used by the Fax Agent while registering with 
			the Call manager.
*/
#define IFX_FAX_AGENT_ENDPT_ID "-3"
/*!
	\brief The Endpoint identification to be used by the Configuration Agent while registering with 
			the Call manager.
*/
#define IFX_CFG_AGENT_ENDPT_ID "-4"

/*!
	\brief This function initializes the Call Manager.  This function
	is invoked during the boot up by the Configuration Agent.
	This function is called at bootup time to allow Call Manager
	to set its house in order.
	\param[in] ucDebugId The Debug identification to be used by the Call Manager
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_Init(IN uint8 ucDebugId);
/*!
	\brief This function shuts down the Call Manager,  This function
	is invoked by the Call Manager to o clean up the Call Manager.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_Shut(void);

/*!
	\brief	This function registers the agent callback functions with 
	the Call Manager.  This function will be invoked by an agent on 
	behalf an endpoint it serves to register the various callback functions it 
	implements. This agent invokes the function during its initialization.
	\param[in]	 aszEndptId The array of identifier of the Endpoint(s)
	\param[in]    uiNumOfEndpt The number of Endpoints in the array
	\param[in]	 pxCallBackList The list of function pointers
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallBacksRegister(
								IN char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
								IN uint32 uiNumOfEndpt,
								IN struct x_IFX_CMGR_CallBackList* pxCallBackList
								);

/*!
	\brief	This function unregisters the agent callback functions with 
	the Call Manager.  This function will be invoked by an agent on 
	behalf an endpoint it serves to unregister the various callback functions 
	it implements.   This agent invokes the function during its shutdown.  The 
	agents may also invoke this function when run-time disabling of some 
	features is possible.
	\param[in]	 aszEndptId The array of identifiers of the Endpoint(s)
	\param[in]   uiNumOfEndpt Number of Endpoints in the array 
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_CallBacksUnRegister(
								IN char8 aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
								IN uint32 uiNumOfEndpt
								);
/* CID type II functions*/
/*!
	\brief This function forwards the off-hook CID information.
	This function is used by an the FXO agent to send a CID type II info
	during a call.  The FXO agent invokes this function upon receiving
	offhook CID information on the FXO interface.
	\param[in] uiCallId The call identifier of the Call,
	\param[in] szPhoneNumber The number from which the CID was received
	\param[in] pxAddCidInfo The additional CID information
   \return    IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_OffHkCidSnd( 
					 IN uint32 uiCallId,
					 IN char8* szPhoneNumber,
					 IN x_IFX_CMGR_CidInfo* pxAddCidInfo
					 );
					 				 
/*!
	\brief This callback function receives the offhook CID information.
	The Call Manager invokes this function to inform the (DECT)  agent 
	that a type II (offhook) CID has been received during the call.  The CID
	information is passed in the function.
	\param[in]	uiCallId The call identifier of the Call
	\param[in] szPhoneNumber The number from which the CID was received
	\param[in] pxAddCidInfo The additional CID information
   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_OffHkCidRcv)( 
					 IN uint32 uiCallId, 
					 IN char8* szPhoneNumber,
					 IN x_IFX_CMGR_CidInfo* pxAddCidInfo
					 );

/*Send Message functions*/
/*!
	\brief This function transparently exchanges messages between
	agents.  The agents invoke this function to send a message to
	another agent without the intervention of the call manager.
	\param[in]	pxFrom Address of the sending party
	\param[in]	pxTo Address of the receiving party
	\param[in]	pvInfo Pointer to the transparent information
	\param[in]	unSize Size of the information in the void pointer
	\param [out] peStatus The status of the request 
	\param [out] peReason The reason.  Incase of failure, this parameter provides the 
					 specific reason
   \return     IFX_SUCCESS or IFX_FAILURE
 */
e_IFX_Return IFX_CMGR_InfoSnd( 
					 IN x_IFX_CMGR_AddressInfo* pxFrom,
					 IN x_IFX_CMGR_AddressInfo* pxTo,
					 IN void* pvInfo,
					 IN uint16 unSize,
					 OUT e_IFX_CMGR_Status *peStatus,
					 OUT e_IFX_ReasonCode *peReason
					 );
					 				 
/*!
	\brief 	This callback function informs about a message to be delivered.
	The Call Manager invokes this function on an agent to inform the agent about a message 
	from another agent and delivers the message.  The message was sent via 
	the IFX_CMGR_SendInfo function.
	\param[in]	pxFrom Address of the sending party
	\param[in]	pxTo Address of the receiving party
	\param[in]	pvInfo Pointer to the transparent information
	\param[in]	unSize Size of the information in the void pointer
	\param[in]	peStatus The status of the request as given by the agent
	\param[in]	peReason The reason.  Incase of failure, this parameter provides the 
						specific reason. If reason is not applicable then the reason may
						be IFX_MAX_REASON.
   \return     IFX_SUCCESS or IFX_FAILURE
 */
typedef e_IFX_Return (*pfn_IFX_CMGR_InfoRcv)( 
					 IN x_IFX_CMGR_AddressInfo* pxFrom,
					 IN x_IFX_CMGR_AddressInfo* pxTo,
					 IN void* pvInfo,
					 IN uint16 unSize,
					 OUT e_IFX_CMGR_Status* peStatus,
					 OUT e_IFX_ReasonCode* peReason
					 );
/*!
	\brief This function is used to get a VoIP line identifier for a particular 
	request identifier.  This function is used by the SIP Agent. 
	\param[in] uiReqId The request identifier for this request
	\param[out] punLineId The Line ID requested 
	\param[out] peReason The reason.  Incase of failure, 
				  this parameter provides the specific reason
  \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_LineIdFromReqIdGet(
									IN uint32 uiReqId ,
									OUT uint16* punLineId ,
									OUT e_IFX_ReasonCode *peReason /*If Failure*/
									);

/*!
	\brief This function is used to get a VoIP line identifier 
		for a particular Call Identifier.  This function is used by the SIP Agent. 
	\param[in] uiCallId The call Id for this Call
	\param[out] punLineId The Line ID requested 
	\param[out] peReason The reason.  Incase of failure, 
				  this parameter provides the specific reason
  \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_LineIdFromCallIdGet(
					 				IN uint32 uiCallId ,
									OUT uint16* punLineId ,
									OUT e_IFX_ReasonCode *peReason /*If Failure*/
					 				);
/*!
	\brief This function is used to get the private data for a 
		particular the Call Identifier.  This function is used by agents
		operating with the private data.
	\param[in]  uiCallId The call identifier for which private data is requested.
	\param[out]	 ppvPrivateData The pointer to pointer in which the 
					private data would be returned.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_PrivateDataFromCallIdGet( IN uint32 uiCallId,
					 				OUT void **ppvPrivateData);

/*!
	\brief This function is used to set the private data for a 
		particular the Call Identifier.  This function is used by agents
		operating with the private data.
	\param[in]  uiCallId The call identifier for which 
				private data attachment is requested.
	\param[in]	 pvPrivateData The pointer in which the private data is supplied.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_PrivateDataToCallIdSet( IN uint32 uiCallId,
					 				IN void *pvPrivateData);

/*!
	\brief This function is used to get the private data for a 
		particular the Request Identifier.  This function is used by agents
		operating with the private data.
	\param[in]  uiReqId The request identifier for which private data attachment is requested.
	\param[out]	 ppvPrivateData The pointer to pointer in which the 
					private data would be returned.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_PrivateDataFromReqIdGet( IN uint32 uiReqId,
					 				OUT void **ppvPrivateData);

/*!
	\brief This function is used to set the private data for a 
		particular the Request Identifier.  This function is used by agents
		operating with the private data.
	This function is called by the agent to set the private data to a Call Id
	\param[in]  uiReqId The request identifier for which private data 
			attachment is requested.
	\param[in]	 pvPrivateData The pointer in which the 
					private data is supplied.
   \return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CMGR_PrivateDataToReqIdSet( IN uint32 uiReqId,
					 				IN void *pvPrivateData);
/*!
 \brief Structure containing the callback function pointers that the agents need to 
 		  implement.
*/
typedef struct x_IFX_CMGR_CallBackList
{
	/* DO not CHANGE POSITION OF THE callback functions IN THIS STRUCTURE*/
	/*Basic Call Control - Mandatory for EXTN/FXO/VoIP */
	pfn_IFX_CMGR_CallIncoming pfnCallIncoming; /*!< Callback function for incoming call*/
	pfn_IFX_CMGR_RemoteCallAccept pfnRemoteCallAccept; /*!< Callback function for accept call*/
	pfn_IFX_CMGR_RemoteCallAnswer pfnRemoteCallAnswer; /*!< Callback function for answer call*/
	pfn_IFX_CMGR_RemoteCallHold pfnRemoteCallHold;/*!< Callback function for hold call*/
	pfn_IFX_CMGR_RemoteCallResume pfnRemoteCallResume;/*!< Callback function for resume call*/
	pfn_IFX_CMGR_CallHoldRsp pfnCallHoldRsp;/*!< Callback function for hold response*/
	pfn_IFX_CMGR_CallResumeRsp pfnCallResumeRsp;/*!< Callback function for resume response*/
	pfn_IFX_CMGR_RemoteCallRelease pfnRemoteCallRelease;/*!< Callback function for remote release*/

	/* Mandatory for Voip*/
	pfn_IFX_CMGR_MediaParamsGet pfnGetMediaParams; /*!< Callback function for getting media params*/
	pfn_IFX_CMGR_MediaNegReq pfnMediaNegReq;/*!< Callback function for request to negotiate media*/	
	pfn_IFX_CMGR_MediaNegRsp pfnMediaNegRsp;/*!< Callback function for response of negotiate media*/
	
	/*Transfer - Mandatory for EXTN/FXO/VoIP */
	pfn_IFX_CMGR_BlindTxReq pfnBlindTxReq; /*!< Callback function to request blind transfer*/
	pfn_IFX_CMGR_BlindTxStatus pfnBlindTxStatus; /*!< Callback function for blind transfer status*/	
	pfn_IFX_CMGR_AttendedTxReq pfnAttendedTxReq; /*!< Callback function to request attended transfer*/	
	pfn_IFX_CMGR_AttendedTxStatus pfnAttendedTxStatus; /*!< Callback function for attended transfer status*/	
	/*Transfer - Mandatory for EXTN/FXO */
	pfn_IFX_CMGR_CallIdReplace pfnCallIdRep; /*!< Replaces the call id in some tx cases*/

	/*Media Call backs - Mandatory for Rtp Agent*/
	pfn_IFX_CMGR_RtpSessionStart pfnRtpSessionStart;/*!< Callback function for start session*/	
	pfn_IFX_CMGR_RtpSessionStop pfnRtpSessionStop;/*!< Callback function for stop session*/	
	pfn_IFX_CMGR_RtpSessionModify pfnRtpSessionModify;/*!< Callback function for modify session*/	
	
	/*Media Call backs - Mandatory for Fax Agent*/
	pfn_IFX_CMGR_FaxSessionStart pfnFaxSessionStart;/*!< Callback function for start session*/	
	pfn_IFX_CMGR_FaxServerListen pfnFaxServerListen;/*!< Callabck function to listen for TCP*/
	pfn_IFX_CMGR_FaxSessionStop pfnFaxSessionStop;/*!< Callback function for stop session*/
	
	/* Digits CB  - Mandatory for NA*/	
	pfn_IFX_CMGR_DigitsInCallRcv	pfnDigitsInCallRcv;/*!< Callback function for receiving digits in call*/

	pfn_IFX_CMGR_ConfStatus pfnConfStatus;/*!< Callback function for getting status of a conference related request*/
	pfn_IFX_CMGR_CallFwdInfo pfnCallFwdInfo;/*!< Callback function to inform the address where call has been forwarded*/
	
	/*Mandatory For NA */
	pfn_IFX_CMGR_Register pfnRegister;/*!< Callback function for SIP registration*/
	pfn_IFX_CMGR_SubnSnd pfnSubnSnd; /*!< Callback function for sending subscribe*/	
	pfn_IFX_CMGR_NtfnSnd pfnNtfnSnd;/*!< Callback function to send notify*/
	pfn_IFX_CMGR_SubnStatus pfnSubnStatus; /*!< Callback function for subscribe status*/	
	
	/*Mandatory for Config Agent*/
	pfn_IFX_CMGR_RegisterRsp pfnRegisterRsp;/*!< Callback function for SIP registration response*/
	pfn_IFX_CMGR_VM_SubnRsp pfnVM_SubnRsp;/*!< Used for response to voice mail subscription*/
	pfn_IFX_CMGR_VM_NtfnRcv pfnVM_NtfnRcv;/*!< call when a notify for voice mail is received*/
	
	pfn_IFX_CMGR_ARD_Status pfnARD_Status;/*!< Callback function for Auto Redial status*/
	pfn_IFX_CMGR_ARD_NtfnRcv pfnARD_NtfnRcv;/*!< Callback function for notify*/
	pfn_IFX_CMGR_ARD_Register pfnARD_Reg;/*!< Callback function for Auto Redial request*/
			  
#ifdef MESSAGE_SUPPORT			  
	pfn_IFX_CMGR_SMS_SmsStatus pfnSmsStatus;/*!< Callback function to inform agent about sms status*/
	pfn_IFX_CMGR_SMS_SmsRcv pfnSmsRcv;/*!< Callback function to inform agent an 
																 	sms received from a remote party*/
	pfn_IFX_CMGR_Msg_Status pfnMsgStatus;/*!< Callback function to inform agent about sms status*/
	pfn_IFX_CMGR_Msg_Rcv pfnMsgRcv;/*!< Callback function to inform agent an 
																 	sms received from a remote party*/
#endif

	pfn_IFX_CMGR_InfoRcv pfnInfoRcv;/*!< Callback function for send message function*/
	pfn_IFX_CMGR_OffHkCidRcv pfnOffHkCidRcv;/*!< Callback function for CID-II display (in the DECT handset)*/
/* List Access */
	pfn_IFX_CMGR_ListAccessNtfn pfnListAccess; /*!< Callback function for List notifications */
	pfn_IFX_CMGR_ListAccessFreeVmapiObj pfnFreeVmapiObj; /*!< Callback function for free up of MAPI objects*/
	pfn_IFX_CMGR_DateTimeNtfn pfnDateTime; /*!< Callback function for Date and Time */
}x_IFX_CMGR_CallBackList;
/*******************************************************************************
 * This section is only needed for Init & Shut - END -
 *******************************************************************************/
/* @} */
/* @} */
#endif /*__IFX_CMGR_IF_H__*/
