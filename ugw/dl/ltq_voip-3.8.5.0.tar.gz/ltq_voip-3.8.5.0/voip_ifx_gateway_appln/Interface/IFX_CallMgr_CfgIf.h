/*****************************************************************************
 **   FILE NAME       : IFX_CallMgr_CfgIf.h 
 **   PROJECT         : ADSL DECT GW
 **   MODULES         : Call-Manager 
 **   SRC VERSION     : 0.1
 **   DATE            : 23/March/2007 
 **   AUTHOR          : ADSL VoIP DECT VoIP Application Team
 **   DESCRIPTION     : This file contains the functions and the data structures 
 **							        used by call manager to get/set configuration parameters.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#ifndef __IFX_CMGR_EXTERN_H__
#define __IFX_CMGR_EXTERN_H__

/*! \file IFX_CallMgr_CfgIf.h
	\brief This file contains interface functions for configuration. These utility APIs
	       are used by Call Manager and agents.
*/

/** \defgroup VoIP_LIB_API VoIP Library Interfaces
    \brief This section describes the API provided by different modules of the 
    VoIP Library.  The Management API for Voice, Configuration API, SIP
    Toolkit API and RTP Toolkit API are described.
*/
/* @{ */
/* @} */ /* VoIP Lib API */

/** \ingroup VoIP_LIB_API
        \defgroup CONFIG_API Configuration
    	\brief This section describes the Configuration API for agents and
        Call Manager
*/

/** \ingroup CONFIG_API
        \defgroup CIF_CMGR Configuration Service for Call Manager
    	\brief This section describes the Configuration APIs defined
        for the usage of the Call Manager.
*/
/* @{ */
/*!
	\brief This function is used to get default FAX port configured. 
	\param[out] pszEndptId On return, this contians default FAX port.	
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_DefaultFaxPortGet(
	                 OUT char8* pszEndptId,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is used to get default voice line id for an endpoint.
	\param[in] szEndptId Id of the endpoint
	\param[out] pucLineId On return, this contains default voice line id.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_EndptDefaultVLGet(
	                 IN char8* szEndptId,
	                 OUT uchar8* pucLineId,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is used to get voice line status.
	\param[in] ucLineId Voice Line Id.
	\param[out] pbEnabled On return, this contains IFX_TRUE, if line is enabled &
							registered else IFX_FALSE.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_VLStatusGet(
	                 IN uchar8 ucLineId,
									 OUT boolean* pbEnabled,
	                 OUT e_IFX_ReasonCode* peReason );

/* Function duplicated in IFX_Agents_CfgIf.h 
 * Hence doxygen code comments removed from here	
 */
e_IFX_Return IFX_CIF_FxoVLIdGet(
	                 IN char8* szFxoEndpointId,
	                 OUT uchar8* pucVoiceLineId,
	                 OUT e_IFX_ReasonCode* peReason );
/*!
	\brief This function is used to get default FXO line id for an endpoint.
	\param[in] szEndptId Id of the endpoint
	\param[out] szFxoEndpointId On return, this contains default FXO line id.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE.
*/

e_IFX_Return IFX_CIF_EndptDefaultFxoLineGet(
	                 IN char8* szEndptId,
	                 OUT char8* szFxoEndpointId,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is used to get the line ids associated with a endpoint.
	\param[in] szEndptId Id of the endpoint
	\param[in,out] pucSize Size of the paLines array. On successful return this
	           contains number of lines associated with szEndptId endpoint.
	\param[out] paLines Pointer to hold associated line ids of the endpoint. This 
	           array must be large enough to hold IFX_MAX_LINES line id.
	\param[out] peReason On failure, this indicates reason for failure.
	\return If pucSize is not sufficient, this function return IFX_FAILURE with reason as
	        IFX_INSUFFICIENT_SIZE and actual size required is passed in pucSize. 
*/

e_IFX_Return IFX_CIF_EndptLinesGet(
	                 IN char8* szEndptId,
	                 IN_OUT uchar8* pucSize,
	                 OUT uchar8* paLines,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is used to get the type of the endpoint.
	\param[in] szEndptId Id of the endpoint
	\param[out] peEpType Pointer to e_IFX_EndPointType. Type of the endpoint is
	            returned in this parameter.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_EndptTypeGet(
	                 IN char8* szEndptId,
	                 OUT e_IFX_EndptType* peEpType,
	                 OUT e_IFX_ReasonCode* peReason  );
/*!
	\brief This function retrieves the Voice Profile identifier list.
	\param[in] szEndptId Endpoint Id.
	\param[out] pxCodecParams Struct to hold codec info.
	\param[out] peReason Reason code. Indicates reason for failure.
	\return IFX_SUCCESS or IFX_FAILURE - Failure to retrive config data.
	*/
e_IFX_Return IFX_CIF_EndptCodecListGet(
	               IN char8* szEndptId, 
	               OUT x_IFX_CodecList* pxCodecParams,
	               OUT e_IFX_ReasonCode* peReason  );
/*!
	\brief This function is called to get endpoints associated with FXO line.
	\param[in] szFxoEndpointId FXO endpoint id.
	\param[in,out] pucSize size of the array szaEndpointList. Number of endpoints
	           associated with the FXO line is returned. 
	\param[out] aszEndpointList Array that holds endpoint ids. This array must be
	           large enough to hold maximum endpoints present in the system.
	           ( paEndpointList is double dimensional array to hold endpoint 
	           ids, that is strings. )
	\param[out] peReason On failure, this indicates reason for failure.
	\return If pucSize is not sufficient, this function return IFX_FAILURE with reason as
					IFX_INSUFFICIENT_SIZE and actual size required is passed in pucSize. 
*/
e_IFX_Return IFX_CIF_FxoLineEndptListGet(
	                 IN char8* szFxoEndpointId,
	                 IN_OUT uchar8* pucSize,
	                 OUT char8 aszEndpointList[][IFX_MAX_ENDPOINTID_LEN],
	                 OUT e_IFX_ReasonCode* peReason ); 

/* Duplicated declaration - Doxygen comments removed */
e_IFX_Return IFX_CIF_FxoModeGet(
	                 IN char8* szFxoEndpointId,
	                 OUT boolean* pbGwMode,
	                 OUT e_IFX_ReasonCode* peReason  );


/* Line related configuration APIs */

/*!
	\brief This function is used to get the voice line id using SIP URI
	\param[in] pxAddress Pointer to address. It should contain VoIP address.	
	\param[out] pucVoiceLineId voice line id associated with given SIP URI is 
	           returned in this parameter. -1 indicates no voice line for the
	           given SIP URI.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLFromUrlGet(
	                 IN x_IFX_CalledAddr* pxAddress,
	                 OUT uchar8* pucVoiceLineId,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function is used to get URL (address) of a voice line.
	\param[in] ucVoiceLineId Voice Line Id.
	\param[in] pxAddress Pointer to address. On return, contians line's address.	
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_UrlFromVLGet(
	                 IN uchar8 ucVoiceLineId,
	                 OUT x_IFX_CalledAddr* pxAddress,	              
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function is used to get the voice line mode.
	\param[in] ucVoiceLineId Voice line Id	
	\param[in] pbGwMode Pointer to Boolean. On return this parameter contains
	           IFX_TRUE for gateway mode, IFX_FALSE for Forwarding mode.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLModeGet(
	                 IN uchar8 ucVoiceLineId,
	                 OUT boolean* pbGwMode,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is used to check whether call waiting is enabled on voice 
	       line. 
	\param[in] ucVoiceLineId Voice line id.
	\param[out] pbEnabled If call waiting is enabled on default line of the 
	            endpoint, IFX_TRUE is returned in this parameter.
	\param[out] peReason On failure, this indicates reason for failure.
	\return If line is disabled or does not exist IFX_FAILURE is returned, else
	        function returns IFX_SUCCES.
*/
e_IFX_Return IFX_CIF_VLCallWaitingCheck(
	               IN uchar8 ucVoiceLineId,
	               OUT boolean* pbEnabled,
	               OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is used to get endpoint list associated with a voice line.	
	\param[in] ucVoiceLineId voice Line id
	\param[in] bGwMode The endpoint list returned depends on this mode. If 
	           IFX_TRUE, only network endpoints (now only FXO) are returned
	           in list. Else all terminal endpoints associated with this line are
	           retunred in list.
	\param[in,out] pucSize size of the array szaEndpointList. Number of endpoints
	            associated with the FXO line is returned. 
	\param[out] aszEndptList Array that holds endpoint ids. This array must be
	            large enough to hold maximum endpoints present in the system.
	\param[out] peReason On failure, this indicates reason for failure.
	\return If line is disabled or does not exist IFX_FAILURE is returned. If 
	        pucSize is not sufficient, this function returns IFX_FAILURE with reason 
	        as IFX_INSUFFICIENT_SIZE and actual size required is passed in 
	        pucSize. 
*/
e_IFX_Return IFX_CIF_VLEndptListGet(
	                 IN uchar8 ucVoiceLineId,
									 IN boolean bGwMode,
	                 IN_OUT uchar8* pucSize,
	                 OUT char8 aszEndptList[][IFX_MAX_ENDPOINTID_LEN],
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is used to retrieve voice line codec list and codec 
	       parameters.
	\param[in] ucVoiceLineId voice line id.
	\param[out] pCodecParams Pointer to codec parameter struct. On return this
	             contains codec list supported by line and codec parameters.
	\param[out] peReason On failure, this indicates reason for failure.
	\return If line is disabled or does not exist IFX_FAILURE is returned, else
	        function returns IFX_SUCCES.
*/
e_IFX_Return IFX_CIF_VLCodecInfoGet(
	                 IN uchar8 ucVoiceLineId, 
	                 OUT x_IFX_CodecList* pCodecParams,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function is used to retrieve RTP media information for a voice line.
	       If this function returns IFX_SUCCESS then call IFX_ReleasePort to release
	       allocated RTP ports.
	\param[in] ucVoiceLineId voice line id.
	\param[in] pRtpMediaCfg Pointer to x_IFX_RtpParams. On return, this contains RTP
	           media information.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLRtpMediaCfgGet(
	                 IN uchar8 ucVoiceLineId, 
	                 OUT x_IFX_RtpParams* pRtpMediaCfg,
	                 OUT e_IFX_ReasonCode* peReason  );


/*!
	\brief This function is used to retrieve FAX media information of a voice line.
	       If this function returns IFX_SUCCESS then call IFX_ReleasePort to release
	       allocated FAX ports.
	\param[in] ucVoiceLineId voice line id.
	\param[in] uiFaxTrProto FAX Transport protocol type for which FAX parameters are 
	           needed. Pass IFX_TRPROTO_UDP for UDP and IFX_TRPROTO_TCP for TCP.
	\param[out] pxFaxParms Pointer to x_IFX_FaxParams, that carries fax info on return.
	\param[out] pbSupported  Pointer to boolean, that tells whether given FAX transport
             protocol is supported or not.	
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLFaxMediaCfgGet(
	                 IN uchar8 ucVoiceLineId,
					 IN uint32 uiFaxTrProto, 
	                 OUT x_IFX_FaxParams* pxFaxParms,
					 OUT boolean* pbSupported,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function releases port allocated in IFX_CIF_VLFaxMediaCfgGet and
	       IFX_CIF_VLRtpMediaCfgGet. This function should be called if these two
	       function returns IFX_SUCCESS. If not called, these functions fail.
	\param[in] unPort Port number to be released 
	\param[in] ePortType Port type 
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_ReleasePort(IN uint16 unPort, IN e_IFX_TransportType ePortType);

/*!
	\brief This function is used to retrieve call forward information of voice line.
	\param[in] ucVoiceLineId Voice line Id.
	\param[in] eCfType Call Forward Information requested.
	\param[out] pbEnabled On return this indicate whether eCfType is enabled or not
	\param[out] pucRingCount If the Call Forward on No Answer is enabled, then 
							the phone for this many number of rings.
	\param[out] pxCfAddr Pointer to x_IFX_CalledAddr. On return this contains 
	            address call forward address mentioned in eCfType.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLCallFwdInfoGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN e_IFX_CallForwardType eCfType,
	                 OUT boolean* pbEnabled,
					 OUT uchar8* pucRingCount,
	                 OUT x_IFX_CalledAddr* pxCfAddr,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function is used to get DND status of a voice line.
	\param[in] ucVoiceLineId Voice line id.
	\param[in] pbEnabled IFX_TRUE returned if DND is enabled.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLDNDStatusGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN boolean* pbEnabled, 
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function is used to get Anonymous call block status of a voice 
	       line.
	\param[in] ucVoiceLineId Voice line id.
	\param[in] pbEnable IFX_TRUE returned if Anonymous call block is enabled.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLAnonCallBlkStatusGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN boolean* pbEnable, 
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function is used to get CID status of a voice line.
	\param[in] ucVoiceLineId Voice line id.
	\param[in] pbEnable IFX_TRUE returned if CID is enabled.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_VLCidStatusGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN boolean* pbEnable, 
	                 OUT e_IFX_ReasonCode* peReason  );
/*!
	\brief This function is used to add new entry into call register. 
	\param[in] eCrType Type of the call register
	\param[in] ucLineId voice line id.
	\param[in] pxAddress Pointer to x_IFX_CMGR_AddressInfo.
	\param[out] peReason On failure, this indicates reason for failure.
	\return Returns IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return IFX_CIF_CallRegisterAdd(
	                 IN e_IFX_CallRegisterType eCrType,
	                 IN uchar8 ucLineId,
	                 IN x_IFX_CMGR_AddressInfo* pxAddress,
	                 OUT e_IFX_ReasonCode* peReason  );

/*!
	\brief This function retrieves jitter buffer configuration for a voice line.
	\param[in] ucLineId Voice Line id
	\param[out] pxJB_Conf Pointer to x_IFX_MMGR_JitterBuffer_Conf. On successful
	             return this contains jitter buffer parameters.
	\param[out] peReason On failure, this indicates reason for failure.
	\return If failed to  retrive config data, this function returns IFX_FAILURE, else
	        returns IFX_SUCCESS
 */
e_IFX_Return IFX_CIF_VLJBCfgGet(
	                 IN uchar8 ucLineId,
	                 OUT x_IFX_MMGR_JitterBuffer_Conf* pxJB_Conf,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function retrieves SID for a voice line.
	\param[in] ucLineId Voice Line id
	\param[out] pbSidEnabled Pointer to boolean. On successful return this 
	            indicates whether SID is enabled.
	\param[out] peReason On failure, this indicates reason for failure.
	\return If failed to  retrive config data, this function returns IFX_FAILURE, else
	        returns IFX_SUCCESS
 */
e_IFX_Return IFX_CIF_VLSIDCheck(
	                 IN uchar8 ucLineId,
	                 OUT boolean* pbSidEnabled,
	                 OUT e_IFX_ReasonCode* peReason );

/*!
	\brief This function retrieves DTMF transmission type for a voice line.
	\param[in] ucLineId Voice Line id
	\param[out] peType Pointer to e_IFX_DtmfType. On successful return this 
	            indicates DTMF transmission method for given voice line.
	\param[out] punDynPayNum Pointer to uint16. On return this will contain 
	            dynamic payload number for RFC2833 event.
	\param[out] peReason On failure, this indicates reason for failure.
	\return If failed to retrive config data, this function returns IFX_FAILURE, else
	        returns IFX_SUCCESS
 */
e_IFX_Return IFX_CIF_VLDigitMethodGet(
	                 IN uchar8 ucLineId,
	                 OUT e_IFX_DtmfType* peType,
	                 OUT uint16* punDynPayNum,
	                 OUT e_IFX_ReasonCode* peReason );
/*!
	\brief This function retrieves the voice mail status of a given voice line
	\param[in] ucVoiceLineId Voice Line id
	\return If failed not subsribed for voice mail notifications else a success
 */

e_IFX_Return IFX_CIF_VLVMStatusGet(
                   IN uchar8 ucVoiceLineId);
				   
/*!
	\brief This function retrieves the Call Forward domain address
	\param[in] ucVoipLineId VoIP Line id
	\param[out] pxFwdAddr Forwarding address
	\return If failed to retrieve config data, this function returns IFX_FAILURE, else
	        returns IFX_SUCCESS
 */
e_IFX_Return IFX_CIF_GetCallFrwdDomain (IN uint8 ucVoipLineId,
                                        OUT x_IFX_CMGR_VoipAddr* pxFwdAddr);
										
/* @} */ /* CIF for Call Manager - Functions */


#endif/* __IFX_CMGR_EXTERN_H__*/
