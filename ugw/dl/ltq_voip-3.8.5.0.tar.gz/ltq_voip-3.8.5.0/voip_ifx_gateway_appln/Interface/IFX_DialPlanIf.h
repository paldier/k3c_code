/*****************************************************************************
 **   FILE NAME       : IFX_DP.h 
 **   PROJECT         : ADSL DECT GW
 **   MODULES         : Call-Manager 
 **   SRC VERSION     : 0.1
 **   DATE            : 23/March/2007 
 **   AUTHOR          : ADSL VoIP DECT VoIP Application Team
 **   DESCRIPTION     : This file contains the APIs and the data structures 
 **							exposed by the call manager to the different agents
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS, DIS of RM
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

#ifndef __IFX_DP__
#define __IFX_DP__

/*! \file IFX_DialPlanIf.h
    \brief This File contains the Constants, enumerations, related Data
    structures and functions for using the Dial/Numbering Plan functionality
   
*/
/** \addtogroup GW_APIs Gateway Application APIs
    \brief This section lists the functions provided by different modules
*/
/* @{ */
/** \defgroup UTIL_APIs Utilities
	\brief This section lists the functions provided for various utilities
*/
/* @} */

/** \addtogroup UTIL_APIs Utilities
	\brief This section lists the functions provided for various utilities
*/
/* @{ */

/** \defgroup DP_APIs Dial Plan Service
	\brief This section lists the functions provided for realising the 
	Dial Plan functionality
*/


/* @{ */

/*!
	\brief Enumeration containing the Dial plan actions
 */

typedef enum
{
/* 0 */	IFX_DP_ANON_CALLBLOCK_ACTV=0,/*!<Action: Activate Anonymous call blocking. */
/* 1 */	IFX_DP_ANON_CALLBLOCK_DEACTV=1,/*!<Action: Deactivate Anonymous call blocking. */
/* 2 */	IFX_DP_AUTO_REDIAL_ACTV=2,/*!< Action: Auto Redial activate.*/
/* 3 */	IFX_DP_AUTO_REDIAL_DEACTV=3,/*!< Action:Auto Redial deactivate.*/
/* 4 */	IFX_DP_DND_ACTV=4,/*!< Action: DND activate.*/
/* 5 */	IFX_DP_DND_DEACTV=5,/*!< Action: DND deactivate. */
/* 6 */	IFX_DP_CALLWAITING_ACTV=6,/*!< Action: Call waiting activate. */
/* 7 */	IFX_DP_CALLWAITING_DEACTV=7,/*!< Action: Call waiting deactivate. */
/* 8 */	IFX_DP_CALLWAITING_PERCALL_ACTV=8,/*!< Action: Call waiting activate per call. */
/* 9 */	IFX_DP_CALLWAITING_PERCALL_DEACTV=9,/*!< Action: Call waiting deactivate per call. */
/*10 */	IFX_DP_UNC_CFWD_ACTV=10,/*!< Action: Activate unconditional call forward. */
/*11 */	IFX_DP_UNC_CFWD_DEACTV=11,/*!< Action: Deactivate unconditional call forward. */
/*12 */	IFX_DP_BUSY_CFWD_ACTV=12,/*!< Action: Activate call forward on busy.*/
/*13 */	IFX_DP_BUSY_CFWD_DEACTV=13,/*!< Action: Deactivate call forward on busy. */
/*14 */	IFX_DP_NOANS_CFWD_ACTV=14,/*!< Action: Activate call forward on No answer. */
/*15 */	IFX_DP_NOANS_CFWD_DEACTV=15,/*!< Action: Deactivate call forward on No answer. */
/*16 */	IFX_DP_CID_BLOCK_ACTV=16,/*!< Action: Activate Caller ID block. */
/*17 */	IFX_DP_CID_BLOCK_DEACTV=17,/*!< Action: Deactivate Caller ID block. */
/*18 */	IFX_DP_CID_BLOCK_PERCALL_ACTV=18,/*!< Action: Activate Caller ID block per call. */
/*19 */	IFX_DP_CID_BLOCK_PERCALL_DEACTV=19,/*!< Action: Deactivate Caller ID block per call. */
#ifdef DIAL_PLAN_REMOVE
/*20 */	IFX_DP_DEF_OUTBOUND_INTERFACE_PSTN=20,/*!< Action: Set default outbound interface to PSTN. */
/*21 */	IFX_DP_DEF_OUTBOUND_INTERFACE_VOIP=21,/*!< Action: Set default outbound interface to VOIP.*/
#endif
/*22 */	IFX_DP_BLIND_TX=20,/*!< Action: Blind transfer. */
#ifdef DIAL_PLAN_REMOVE
/*23 */	IFX_DP_PSTN_HOOKFLASH=23,/*!< Action: PSTN hook flash. */
#endif
/*24 */	IFX_DP_CALL_RETURN=21,/*!< Action: Dial Call return. */
/*25 */	IFX_DP_CALLWAITING_REJECT=22,/*!< Action: Reject waiting call. */
/*26 */	IFX_DP_VOICEMAIL_RETRIVAL=23,/*!< Action: Voicemail retrieval. */
/*27 */	IFX_DP_NON_DEFAULT_VL_DIAL=24,/*!< Action: Dial using non-default voice line. */
/*28 */	IFX_DP_DISCONNECT_LASTACTV_CALLL=25,/*!< Action: Disconnect last active call. */
/*29 */	IFX_DP_RESUME_LASTACTV_CALLL=26,/*!< Action: Resume last active call. */
/*30 */	IFX_DP_RESUME_NON_LASTACTV_CALLL=27,/*!< Action: Resume Non-Last active call. */
/*31 */	IFX_DP_CONFERENCE=28,/*!< Action: Conference */
/*32 */	IFX_DP_SPEED_DIAL=29,/*!< Action: Speed dial */
/*33 */	IFX_DP_EXTENSION_DIAL=30,/*!< Action: Extension dialing (PBX Functionality). */
#ifdef DIAL_PLAN_REMOVE
/*34 */	IFX_DP_SERV_SIDE_CFG=34,/*!< Action: Server side configuration. */
#endif
/*35 */	IFX_DP_TWO_STAGE_PSTN_DIALING=31,/*!< Action: Two stage PSTN dialing.*/
/*36 */	IFX_DP_LOCAL_PSTN_CALLS=32,/*!< Action: Local PSTN calls. */
#ifdef DIAL_PLAN_REMOVE
/*37 */	IFX_DP_LOCAL_VOIP_CALLS=37,/*!< Action: Local VOIP calls. */
/*38 */	IFX_DP_STD_PSTN_CALLS=38,/*!< Action: PSTN STD calls. */
/*39 */	IFX_DP_STD_VOIP_CALLS=39,/*!< Action: VOIP STD calls. */
/*40 */	IFX_DP_ISD_PSTN_CALLS=40,/*!< Action: ISD PSTN Calls. */
/*41 */	IFX_DP_ISD_VOIP_CALLS=41,/*!< Action:  ISD VOIP Calls. */
#endif
/*42 */	IFX_DP_EMERGENCY_CALLS=33,/*!< Action: Emergency calls. */
/*43 */	IFX_DP_DIALDEFAULT_DEF_IF=34,/*!< Action: Dialout using default interface. */
#ifdef DIAL_PLAN_REMOVE
/*44 */	IFX_DP_DIRECT_IP_CALLS=44,/*!< Action: Direct IP dialing. */
#endif
#ifdef ENABLE_DBG_THR_PHONE
				IFX_DP_ENABLE_DEBUGS,
#endif
//#ifdef DECT_SUPPORT //For DECT
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
#ifdef ENABLE_PIN_CODE_CFG_THR_PHONE
				IFX_DP_CHANGE_BASE_PIN,
#endif
#ifdef DEBUG_COSIC
         IFX_DP_DEBUG_COSIC,   /** COSIC debug enable */ 
#endif
#endif //DECT_SUPPORT
#ifdef DELAYED_HOTLINE
				IFX_DP_DHL_ACTV,/*!< Action: DND activate.*/
				IFX_DP_DHL_DEACTV,/*!< Action: DND deactivate. */
#endif

/*45 */	IFX_DP_MAX_DP_ACTIONS/*!< Action: MAX Actions. */
}e_IFX_DP_Action;

/*!
	\brief Structure containing a dial plan rule.  The dial plan maintains an
	array of such structures.
 */
typedef struct 
{
		  char8 szPrefix [42];/*!< Actual prefix*/
		  uchar8 ucMin;/*!< Min digits including prefix*/
		  uchar8 ucMax;/*!< Max Digits including prefix*/
		  uchar8 ucDgtRmv;/*!< Num of  digits to be removed*/
		  uchar8 ucPosRmv;/*!< Position of digits to be removed*/
		  char8 cDgtIns;/*!< Digit to be inserted*/
		  uchar8 ucPosIns;/*!< Position of digits to be inserted*/
		  char8 cDgtReplace;/*!< The replacement digit*/
		  uchar8 ucPosReplace;/*!< Position to be replaced*/
		  e_IFX_DP_Action eAction;/*!< Action associated*/
		  char8 acAction[42];/*!< Verbal description of the action*/
}x_IFX_DP_Rule;

/*!
	\brief Global parameter for Minimum digits
*/
extern uchar8 gucMindgts;
/*!
	\brief Global parameter for Maximum digits
*/
extern uchar8 gucMaxdgts;
/*Explaination of IN/OUT parameters*/
/* OUT ucAction:- Explained below, it can have following values:- */

/*!
	\brief	For this output, the invoking agent is expected to start the half 
				interdigit timer and invoke the dial plan again with the next digit
			  	if received within the timelimit or attach 'S' to the accumulated 
				digits and invoke the Dial plan if the timer fires and no digit 
				is received.
 */
# define IFX_DP_ST_SMALL_TIM 1

/*!
	\brief	For this output, the invoking agent is expected to start the 
	Full interdigit timer and invoke the dial plan again with the next digit if 
	received within the timelimit or attach 'T' to the accumulated digits and 
	invoke the Dial plan if the timer fires and no digit is received */
# define IFX_DP_ST_LARGE_TIM 2

/*!
	\brief For this output, the agent is expected to dial-out, using the rule 
	pxDpruleMatched. For the Action, agent can always access the 
	pxDpruleMatched->eAction. (Which will have the enumerated value). 
	The valid out string will be present in the szDialoutString.
 */
# define IFX_DP_DIALOUT 3

/*!
	\brief For this output, the agent is supposed to play error 
	tone indicating the error in dialing
 */
# define IFX_DP_MISMATCH 4

/*! 
	\brief 	This function matches a digit with the Dial Plan.  
	This function is to be called by the the agent when it gets a digit 
	and needs to be parsed by the dial plan. The dial plan supports two 
	types of dialing:
		1) Digit by Digit dialing.
		2) Block Dialing (One time dialing of digits). 
	\param[in]	szDigitPattern Digits dialed by the user.
					Every time, an agent gets new digit(s), 
					it has to be concatinated to the string and passed to the dial plan.
	\param[in]	bFinished Flag indicating whether the dialing is finished(1 = Finished, 0 = Not)
	\param[out]	pucAction The action that has to be taken
  					by the invoking agent.
	\param[out]	szDialOutString String to be dialed out.
	\param[out]	pxDpRuleMatched On return this structure contains the matched rule.
	\param[out]	pucInterdigitTimer Timer to be started
	\return     IFX_SUCCESS or IFX_FAILURE
*/
e_IFX_Return  IFX_DP_Match(
					 IN char8 *szDigitPattern,
					 IN boolean bFinished,
					 OUT uchar8 *pucAction,
					 OUT char8 *szDialOutString,
					 OUT x_IFX_DP_Rule *pxDpRuleMatched,
					 OUT uint16* pucInterdigitTimer 
			);

/*! 
    \brief     This function populates the dial plan.  This function is invoked
	the agent when the dial plan needs to be (re)populated.
	\param[in]  paxDpRules Pointer to the array of Dial Plan Rule structures
	\param[in]  ucNumDpRules Number of entries in the array.
	\param[in]  ucShortInterDigitTimer Short Interdigit timeout Value.
	\param[in]  ucLongInterDigitTimer Full Interdigit timeout value
	\param[in]  ucDgbId The Debug Identifier for debugging.
	\return     IFX_SUCCESS or IFX_FAILURE
*/

e_IFX_Return IFX_DP_DialPlanPopulate(IN x_IFX_DP_Rule * paxDpRules, 
										IN uchar8 ucNumDpRules,
										IN uint16 ucShortInterDigitTimer,
										IN uint16 ucLongInterDigitTimer,
										IN uchar8 ucDgbId
										);


/* @} */
/* @} */


#endif /*__IFX_DP__*/
