/*****************************************************************************
 **   FILE NAME       :IFX_LoadMgr.h 
 **   PROJECT         :
 **   MODULES         :
 **   SRC VERSION     :
 **   DATE            : 
 **   AUTHOR          : ATA Application Team
 **   DESCRIPTION     : This file contains the APIs and the data structures 
 **						exposed by the Load manager.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS
 **   COPYRIGHT       : Copyright © 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **   Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
******************************************************************************/
/*! \file IFX_LoadMgr.h 
    \brief This File contains the Constants, enumerations, related Data
    structures and API's for using the functionality provided
    by the Load Manager.
*/
#ifndef __IFX_LM_IF_H__
#define __IFX_LM_IF_H__
#define IFX_LM_BASE_LOAD 0
#define IFX_LM_MAX_CPU_USAGE 10000
/* !\enum e_IFX_MM_Return
    \brief Enumerations for the Load Manager return types
*/
typedef enum
{
	IFX_LM_NO_CPU_RESOURCE = -5,
	IFX_LM_INVALID_ARGUMENT,
	IFX_LM_SUCCESS = 0,
}e_IFX_LM_Return;
/* Following is the enumeration of the types of resources */
/* FXS_SIG_CHANNEL comprises of ALM + DTMFR + CIDT + UTG 
 * FXO_SIG_CHANNEL comprises of DCCTRL + DTMFT + DTMFR + CPTD +
 *   CIDR
 */
/* !\enum e_IFX_LM_Resource
    \brief Enumerations for the Load Manager resource types
*/
typedef enum
{
	IFX_LM_RES_CODEC,       /*!< Codec resource */
	IFX_LM_RES_FXO_SIG_CHANNEL, /*!< FXO signalling channel resource, 
								 consists of DCCTRL + DTMFT + DTMFR +
								 CPTD + CIDR */
	IFX_LM_RES_FXS_SIG_CHANNEL, /*!< FXS signalling channel resource,
								 consists of ALM + DTMFR + CIDT + UTG
								 */
	/* Lec for narrow band fxs with a tail length of 16ms */
	IFX_LM_RES_FXS_NB_LEC_16, /*!< Lec for narrow band fxs with a tail
							    length of 16ms */
	/* Lec for narrow band fxs with a tail length of 8ms */
	IFX_LM_RES_FXS_NB_LEC_8,   /*!< Lec for narrow band fxs with a tail
							   length of 8ms */
	/* Lec for wide band fxs with a tail length of 16ms */
	IFX_LM_RES_FXS_WB_LEC_16,  /*!< Lec for wide band fxs with a tail 
							   length of 16ms */
	/* Lec for wide band fxs with a tail length of 8ms */
	IFX_LM_RES_FXS_WB_LEC_8,   /*!< Lec for wide band fxs with a tail 
							   length of 8ms */
	IFX_LM_RES_FXO_LEC_16,     /*!< Lec for FXO with a tail length of 
							    16 ms */
	IFX_LM_RES_FXO_LEC_8,       /*!< Lec for FXO with a tail length of 
							   8 ms */
	/* Fax tones detection resource */
	IFX_LM_RES_MFTD,            /*!< Fax tones detection resource */
	IFX_LM_RES_MAX
}e_IFX_LM_Resource;

/*! \struct x_IFX_LM_Resource
    \brief  Resource type information such as type of resource and 
	additional info for example, type of codec incase the resource 
	type is codec 
*/
typedef struct
{
	e_IFX_LM_Resource eResourceType;  /*!< Type of Load manager resource */
	/* Valid only when eResourceType == IFX_LM_RES_CODEC */
	uchar8 ucNoOfCodecs;  /*!< Number of codecs,Valid only when 
						  eResourceType == IFX_LM_RES_CODEC */
	x_IFX_MMGR_CodecList xCodecList; /*!< List of codecs */
}x_IFX_LM_Resource;
/*! \struct x_IFX_LM_InitParams
    \brief  Load manager Initialization Parameter.
*/
typedef struct
{
	uchar8 aucCPU_Usage[IFX_LM_RES_MAX]; /*!< Array containg the percentage
	                                     of CPU uasge for all the types of 
	                                     resources,except for the codec resource */
	uchar8 aucCPU_Usage_Codecs[IFX_MMGR_CODEC_MAX]; /*!< Array containg the percentage
	                                     of CPU uasge for all the types of 
	                                     codecs */
}x_IFX_LM_InitParams;
/** \defgroup APIs Gw Appln API's
    \brief This section lists the api's provided by different modules
*/
/* @{ */


/** \defgroup LM_APIs Load Manager API's
	\brief This section lists the api's provided by the Load Manager
*/

/*! \method     IFX_LM_Init
    \brief      This API is the initialization routine 
	            for the Load manager. The initialization parameters contains
				the percentage of CPU usage by all the resources.This API 
				also reserves the base load of the system.
    \param[in]  pxInitParams - pointer to x_IFX_LM_InitParams
	\return     IFX_LM_SUCCESS or IFX_LM_FAILURE
*/
/* This is the Initialization API for the Load Manager */
e_IFX_LM_Return IFX_LM_Init(
						 IN x_IFX_LM_InitParams *pxInitParams
						 );

/*! \method     IFX_LM_LoadReserve
    \brief      This API reserves the load for a resource if its permissable.
	            It calculates the cpu usage for the requested resource and
				checks whether the resource could be run on the device, if 
				the CPU usage does not goes to 100% ,the load for this resource
				is added and success returned.
				If the resource type requested is of type codec, a list of codecs
				also needs to be provided as parameter, in which case
				the API returns a modified list of codecs that could
				be run on the device.
    \param[in,out]  pxResource - pointer to x_IFX_LM_Resource
	\return     IFX_LM_SUCCESS or IFX_LM_FAILURE
*/
e_IFX_LM_Return IFX_LM_LoadReserve(
								IN_OUT x_IFX_LM_Resource *pxResource,
                                uchar8 *pucCpuUsage
								);
/*! \method     IFX_LM_LoadFree
    \brief      This API frees the cpu usage for a type of resource.
	            If a list of codecs is provided the load of the most
				heavy codec will be freed by this API.
    \param[in]  pxResource - pointer to x_IFX_LM_Resource
	\return     IFX_LM_SUCCESS 
*/								
e_IFX_LM_Return IFX_LM_LoadFree(
							 IN x_IFX_LM_Resource *pxResource
							 );
/*! \method     IFX_LM_Shut
    \brief      This API is the de-initialization routine of the Load 
	             manager.
    \return     IFX_LM_SUCCESS 
*/				
e_IFX_LM_Return IFX_LM_LoadCompute(
								   	IN_OUT x_IFX_LM_Resource *pxResource,
									IN_OUT uchar8 *pucLoadValue
									);
e_IFX_LM_Return IFX_LM_AddCpuUsage(uchar8 ucCpuUsage);
e_IFX_LM_Return IFX_LM_LoadValueFree(uchar8 ucCpuUsage);

e_IFX_LM_Return IFX_LM_Shut(
						    );
#endif 
