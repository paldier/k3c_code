/*****************************************************************************
 **   FILE NAME       :IFX_MediaMgrCore.h 
 **   PROJECT         :
 **   MODULES         :
 **   SRC VERSION     :
 **   DATE            : 
 **   AUTHOR          : ATA Application Team
 **   DESCRIPTION     : This file contains the APIs and the data structures 
 **						exposed by the Media manager to the different agents
 **                     and the call manager.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/

/*! \file IFX_MediaMgrCore.h
    \brief This File contains the Constants, enumerations, related Data
    structures and API's for using the functionality provided
    by the Media Manager
*/
/** \addtogroup APIs Gw Appln API's
    \brief This section lists the api's provided by different modules
*/
/* @{ */


/** \defgroup MM_APIs Media Manager API's
	\brief This section lists the api's provided by the Media Manager
*/
/* @} */

/** \addtogroup MM_APIs Media Manager API's
	\brief This section lists the api's provided by the Media Manager
*/
/* @{ */

#ifndef __IFX_MMGR_CORE_H__
#define __IFX_MMGR_CORE_H__
#define IFX_MMGR_USA_RING_CADENCE {0xff,0xff,0xff,0xff,0xff}
#define IFX_MMGR_USA_RING_CADENCE_BIT_NR  80
#define IFX_MMGR_USA_RB_CADENCE {0xf0}
#define IFX_MMGR_JAPAN_RING_CADENCE {0xff,0xff,0xf0}
#define IFX_MMGR_JAPAN_RING_CADENCE_BIT_NR 60
#define IFX_MMGR_JAPAN_RB_CADENCE {0xff,0xff,0xf0}
#define IFX_MMGR_CHINA_RING_CADENCE {0xff,0xff,0xf0}
#define IFX_MMGR_CHINA_RING_CADENCE_BIT_NR 100
#define IFX_MMGR_CHINA_RB_CADENCE {0xff,0xff,0xf0}

#define IFX_MMGR_FXO_OFFHOOK 0x01
#define IFX_MMGR_FXO_ONHOOK 0x02
#define IFX_MMGR_FXO_HOOKFLASH 0x03
#ifndef IFX_OS_OpenFile
#define IFX_OS_OpenFile open
#endif
#define IFX_OS_Malloc malloc
#define IFX_OS_Free free
#define IFX_MMGR_CALL_MAX 2
#define IFX_MMGR_FSK_BUF 255
#define IFX_MMGR_RING_CADENCE_RESOLUTION 50
/*! \brief Enumeration defining the type of resource 
*/
typedef enum
{
    IFX_MMGR_NONE,
	IFX_MMGR_FXS_RESOURCE,         /*!< FXS Resource */
	IFX_MMGR_FXO_RESOURCE,   /*!< FXO Resource */
	IFX_MMGR_CODER_RESOURCE, /*!< CODER Resource */
	IFX_MMGR_DECT_RESOURCE   /*!< DECT Resource */
}e_IFX_MMGR_ResourceType;

typedef enum
{
	IFX_MMGR_LEC_NONE, /*!< LEC not configured */
	IFX_MMGR_LEC_NE,   /*!< Near end LEC,should be configured on FXS channel */
	IFX_MMGR_LEC_FE,    /*!< Far end LEC,should be configure on FXO channel  */
	IFX_MMGR_LEC_ES=5    /*!< Echo suppressor,should be configured for Dect Channel  */
}e_IFX_MMGR_LecType;

/*! 
	\brief Signalling Channel Info
	*/
typedef struct
{
	uint16 unChannelNum; /*!<  channel number to which this signalling 
							      channel is attached */
	uint16 unSigChaNum;
	int32 iFd;  /*!< Fd of the signalling channel */
}x_IFX_MMGR_SIG_Channel;

/*! \brief structure defining a FXS resource */
typedef struct
{
	char8 szChannelName[IFX_MMGR_MAX_CHANNEL_NAME];  /*!< Name of the device 
								  channel associated with this resource */
	uint16 unChannelNum;         /* Channel Number of the FXS */
	char8 szEndPtId[IFX_MAX_ENDPOINTID_LEN];  /*!< End Point Id of this
											    Resource */
	int32 iInterfaceId;                       /*!< Physical Interface identifier
										 of the resource. This remains fixed.*/
	int32 iFd;                               /*!< File descriptor of the 
											 opened channel */
    struct x_IFX_MMGR_Data_Channel *pxDC[2];                  /*!< Signalling channel 
							assigned to this resource. */
	uint16 unNoOfDataChannels; /*!< Number of data channels added to this resource */
	e_IFX_MMGR_LecType eLecType; /*!< Type of LEC configured on this channel*/
    boolean bIsLecEnabled;
    boolean bIsLecConf;
	uchar8 ucLecTailLength;          /*!< Tail length of the LEC algorithm.
						  Valid only when eLecType is not IFX_MMGR_LEC_NONE */
	boolean bIsWideBandEnabled; /*!< Flag to indicate whether the end point 
								  supports wideband */
    uint16 unVolumeLevel;
#define IFX_MMGR_PLAYING_TONE 0x01
#define IFX_MMGR_RINGING      0x02
#define IFX_MMGR_USE_DEFAULT_CODER 0x04
#define IFX_MMGR_SIG_CH_ALLOCATED 0x08
	uint32 uiServiceFlag;
	uchar8 ucNoOfCalls;
}x_IFX_MMGR_Fxs_Channel;


typedef struct
{
	char8 szChannelName[IFX_MMGR_MAX_CHANNEL_NAME];  /*!< Name of the device 
								  channel associated with this resource */
	uint16 unChannelNum;         /* Channel Number of the Duslic */
	uint16 unPcmChannelNum;
    char8 szPcmChannelName[IFX_MMGR_MAX_CHANNEL_NAME];
	int32 iPcmFd;
	char8 szEndPtId[IFX_MAX_ENDPOINTID_LEN];  /*!< End Point Id of this
											    Resource */
	int32 iInterfaceId;                       /*!< Physical Interface identifier
										 of the resource. This remains fixed.*/
	int32 iFd;                               /*!< File descriptor of the 
											 opened channel */
	struct x_IFX_MMGR_Data_Channel *pxDC;                 /*!< Signalling channel 
							assigned to this resource. */
    boolean bIsLecEnabled;
    boolean bIsLecConf;
	e_IFX_MMGR_LecType eLecType; /*!< Type of LEC configured on this channel*/
	uchar8 ucLecTailLength;          /*!< Tail length of the LEC algorithm.
						  Valid only when eLecType is not IFX_MMGR_LEC_NONE */
     uint16 unVolumeLevel;
#define IFX_MMGR_PLAYING_TONE 0x01
#define IFX_MMGR_RINGING      0x02
	uint32 uiServiceFlag;           
}x_IFX_MMGR_Fxo_Channel;
/*! \brief Dect channel Information 
*/
typedef struct
{
	char8 szChannelName[IFX_MAX_ENDPOINTID_LEN];  /*!< Name of the device 
								  channel associated with this resource */
	int32 iFd;                               /*!< File descriptor of the 
											 opened channel */
	boolean bIsFree;                   /*!< Flag to indicate whether this channel is 
									   already being used */
	char8 szEndPtId[IFX_MAX_ENDPOINTID_LEN];  /*!< End Point Id of this
											    Resource */
	int32 iInterFaceId;                       /*!< Physical Interface identifier
										 of the resource. This remains fixed.*/
    uint16 unChannelNum;
	x_IFX_MMGR_CodecList xReqCodecList ; /*!< codecs requested with dectResAlloc */
	x_IFX_MMGR_CodecList xResCodecList; /*!< List 
					        of codecs that can run on this coder channel */
#define IFX_MMGR_DECT_SIG 0x01
#define IFX_MMGR_DECT_IN_CALL 0x02
#define IFX_MMGR_DECT_ENABLED 0x04
#define IFX_MMGR_DECT_ACTIVE 0x08
//	int  iFlag;
	int32 uiServiceFlag;
	uchar8 ucNoOfCalls;
}x_IFX_MMGR_Dect_Channel;



typedef union
{
	x_IFX_MMGR_Fxs_Channel *pxFxs;
	x_IFX_MMGR_Fxo_Channel *pxFxo;
	x_IFX_MMGR_Dect_Channel *pxDect;
}ux_IFX_MMGR_Dest_Resource;
typedef struct
{
	char8 szChannelName[IFX_MAX_ENDPOINTID_LEN];  /*!< Name of the device 
								  channel associated with this resource */
	uint16 unChannelNum;          /*!< Channel number */
	uint16 unDestResChNum;        /*!< Destination channel number to which this data channel has been added */
	int32 iFd;                               /*!< File descriptor of the 
											 opened channel */
	e_IFX_MMGR_ResourceType eDestResType ; /* Destination resourcetype to which this coder is added */
	ux_IFX_MMGR_Dest_Resource uxDestResource; /* Destination reource to whhich this coder is added */
	boolean bIsCoderFree;    /*!< Flag to indicate whether the coder is 
									   already being used */
	boolean bIsAddedToEndPt;       /*!< Flag to indicate whether this channel is already added 
									   already being used */
	x_IFX_MMGR_CodecList xCodecList; /*!< List 
					        of codecs that can run on this coder channel */
	x_IFX_MMGR_TelephonyEvent_Info xTelEventInfo; /*!< Telephony event reporting information */
	x_IFX_MMGR_JitterBuffer_Conf xJbCfg; /*!< Jitter Buffer configuration */
	x_IFX_MMGR_CodecList *pxCodecList;
    uint32 uiSSRC;
    uint16 unSeqNo;
#define IFX_MMGR_RES_USED_AS_SIG 0x01
#define IFX_MMGR_JB_CONFIGURED 0x02
#define IFX_MMGR_RES_USED_AS_CODER 0x04
#define IFX_MMGR_CODER_NOT_ADDED 0x08
#define IFX_MMGR_USED_ONLY_AS_SIG_RESOURCE 0x10
#define IFX_MMGR_TONE_PLAYING 0x20
	uint32 uiServiceFlag;
	boolean bIsFxs;
}x_IFX_MMGR_Data_Channel;
/*! \brief union conaining all the resources Info 
*/
typedef union
{
	x_IFX_MMGR_Fxs_Channel *pxFxsResource; /*!< FXS Resource Info */
	x_IFX_MMGR_Fxo_Channel *pxFxoResource; /*!< FXO Resource Info */
	x_IFX_MMGR_Data_Channel *pxCoderResource; /*!< Coder Resource Info */
	x_IFX_MMGR_Dect_Channel *pxDectResource; /*!< Dect Resource Info */
}ux_IFX_MMGR_Resource_Channels;

typedef struct
{
	e_IFX_MMGR_ResourceType eResType;
	ux_IFX_MMGR_Resource_Channels uxChannel;
}x_IFX_MMGR_ResourceInfo;

#define IFX_MMGR_CALL_LEGS 2
typedef struct 
{
	int32 iResourceId;  /*!< Resource context identifier */
	int32 iAdditionalResId; /*!< Additional Id of the resource */
	x_IFX_MMGR_Data_Channel *pxCoder; /*!< Coder Info - used for voip calls */
	x_IFX_MMGR_ResourceInfo axResInfo[IFX_MMGR_CALL_LEGS]; /*!< Resources in this context */
	x_IFX_MMGR_CodecList *apxDectCodecList[IFX_MMGR_CALL_LEGS];
	e_IFX_MMGR_TypeOfCall eTypeOfCall;
	struct x_IFX_MMGR_ResourceContext *pxAddResContext;
#define IFX_MMGR_XCONNECTED 0x01
#define IFX_MMGR_LOAD_FREED 0x02
#define IFX_MMGR_SESSION_CFGD 0x04
    uint32 uiServiceFlag;
}x_IFX_MMGR_ResourceContext;
#define IFX_MMGR_MAX_FORK_ENDPT 8
typedef struct
{
	int32 iResourceId;
	e_IFX_MMGR_TypeOfCall eTypeOfCall;
	e_IFX_MMGR_ResourceType eForkingResType;
	x_IFX_MMGR_Data_Channel *pxCoder;
	x_IFX_MMGR_Fxo_Channel *pxFxo;
	uint16 unNoOfEndPts;
	x_IFX_MMGR_ResourceInfo axResInfo[IFX_MMGR_MAX_FORK_ENDPT];
	x_IFX_MMGR_CodecList *apxDectCodecList[IFX_MMGR_MAX_FORK_ENDPT];
	uchar8 ucMaxLoad;
   uint32 uiServiceFlag;
}x_IFX_MMGR_ForkingResContext;


/*!
   \brief This structure defines all the reosurces in the system and keep
    the information for the same 
	*/
typedef struct
{
	int32 iDspDevFd;   /*!< Fd of the DSP control device */
	int32 iFxoDevFd; /*!< Fd of the FXO control device */
	uint16 unNoOfFxs;  /*!< Number of Fxs resource */
	x_IFX_MMGR_Fxs_Channel *paxFxsEndPts; /*!< FXS resource information */
	uint16 unNoOfFxo; /*!< Number of FXO resources */
	x_IFX_MMGR_Fxo_Channel *paxFxoEndPts; /*!< FXO Resource information */
	uint16 unNoOfDect; /*!< Number of DECT resources */
    x_IFX_MMGR_Dect_Channel *paxDectEndPts; /*!< Dect Resources information */
	uint16 unNoOfCoders; /*!< Number of Coder Resources */
	x_IFX_MMGR_Data_Channel *paxCoders; /*!< Coder resource information */
}x_IFX_MMGR_Resources;

typedef struct
{
	x_IFX_MMGR_Tone axTones[IFX_MMGR_MAX_TONE];
	uchar8 ucStartIndex;
    uint16 unNoOfTones;
}x_IFX_MMGR_Tone_Info;
/*!
   \brief This structure defines a conference 
   */
typedef enum
{
	IFX_MMGR_FXS_VOIP_VOIP,
	IFX_MMGR_FXS_VOIP_FXS,
	IFX_MMGR_FXS_VOIP_DECT,
	IFX_MMGR_FXS_VOIP_FXO,
	IFX_MMGR_FXS_DECT_FXS,
	IFX_MMGR_FXS_DECT_DECT,
	IFX_MMGR_FXS_FXO_DECT,
	IFX_MMGR_FXS_FXO_FXS,
	IFX_MMGR_FXS_FXS_FXO,
	IFX_MMGR_FXS_FXS_VOIP,
	IFX_MMGR_FXS_FXS_FXS,
	IFX_MMGR_FXS_DECT_FXO,
	IFX_MMGR_FXS_FXS_DECT,

	IFX_MMGR_DECT_DECT_DECT,
	IFX_MMGR_DECT_FXS_FXS,
	IFX_MMGR_DECT_VOIP_VOIP,
	IFX_MMGR_DECT_VOIP_DECT,
	IFX_MMGR_DECT_VOIP_FXS,
	IFX_MMGR_DECT_VOIP_FXO,
	IFX_MMGR_DECT_DECT_FXO,
	IFX_MMGR_DECT_FXS_DECT
}e_IFX_MMGR_ConferenceType;

typedef struct
{
	int32 iConferenceId; /*!< conference Identifier */
	uchar8 ucNoOfParties; /*!< Number of parties in the conference */
	x_IFX_MMGR_ResourceContext *paxConfParties[2]; /*!< Resources involved in the conference */
	int32 iFd;          /*!< Fd of the resource to operate on -- to be used for disable
	                    mixing to avoid a search again */
	uint16 unChannelNum;    /*!< Channel number of the other resource */
	e_IFX_MMGR_ConferenceType eConfType; /* Type of the conference -- to be used for 
										 disabling the mixing */
	uint32 uiServiceFlag; /*!< Flag to store some state information */
}x_IFX_MMGR_ConferenceContext;

typedef struct
{
	uint32 uiRx;
	uint32 uiTx;
	e_IFX_MMGR_PcmCodecType ePcmCodec; 
}x_IFX_MMGR_PcmConfig;

typedef e_IFX_MMGR_Return (*pfnResReserveForCall)(int32* iResourceId,
								x_IFX_MMGR_ResourceInfo *pxFrom,
								x_IFX_MMGR_ResourceInfo *pxTo,
								x_IFX_MMGR_CodecList *pxCodecList1,
								x_IFX_MMGR_CodecList *pxCodecList2
								);
typedef e_IFX_MMGR_Return (*pfnResFreeForCall)(int32 iResourceId,
							x_IFX_MMGR_ResourceInfo *pxFrom,
							x_IFX_MMGR_ResourceInfo *pxTo
							);

e_IFX_MMGR_Return IFX_MMGR_DSP_Dev_Init(x_IFX_MMGR_Device_Info *pxDev,
                                         x_IFX_MMGR_FdSet *pxFdSet);

e_IFX_MMGR_Return IFX_MMGR_FXO_Dev_Init(x_IFX_MMGR_Device_Info *pxDevInfo, 
                                        x_IFX_MMGR_FdSet *pxFdSet);

e_IFX_MMGR_Return IFX_MMGR_Fxs_Channel_Init(x_IFX_MMGR_FXS_Resources *pxFxsRes)
;

e_IFX_MMGR_Return IFX_MMGR_Fxo_Channel_Init(x_IFX_MMGR_FXO_Resources *pxFxoRes);

e_IFX_MMGR_Return IFX_MMGR_Dect_Channel_Init(x_IFX_MMGR_DECT_Resources *pxDectRes);

e_IFX_MMGR_Return IFX_MMGR_Data_Channel_Init(x_IFX_MMGR_Coder_Resources *pxCoderRes);

e_IFX_MMGR_Return IFX_MMGR_CountrySettingsUpdate(
							x_IFX_MMGR_CountrySettingsParams *pxParams
												);

e_IFX_MMGR_Return IFX_MMGR_ForkingResContextDealloc(
				                                      x_IFX_MMGR_ForkingResContext *pxResContext
							                                      );
e_IFX_MMGR_Return IFX_MMGR_ForkingResContextGet(
																	 int32 iResourceId,
                                   x_IFX_MMGR_ForkingResContext **ppxResContext
					                                     );
e_IFX_MMGR_Return IFX_MMGR_ConfContextAlloc(
                                     x_IFX_MMGR_ConferenceContext **ppxConfContext
		                                      );
e_IFX_MMGR_Return IFX_MMGR_ConfContextDealloc(
                                    x_IFX_MMGR_ConferenceContext *pxConfContext
				                                      );
e_IFX_MMGR_Return IFX_MMGR_ConfContextGet(int32 iConfId,
                                          x_IFX_MMGR_ConferenceContext **ppxConfContext);
e_IFX_MMGR_Return IFX_MMGR_AllocateCoder(x_IFX_MMGR_Data_Channel **ppxCoder,boolean bIsFxs);
e_IFX_MMGR_Return IFX_MMGR_DeAllocCoder(x_IFX_MMGR_Data_Channel *pxCoder);
e_IFX_MMGR_Return IFX_MMGR_AllocDect(x_IFX_MMGR_Dect_Channel **ppxDect,
																	uint16 *puiChNum);
e_IFX_MMGR_Return IFX_MMGR_DeAllocDect(x_IFX_MMGR_Dect_Channel *pxDect);
e_IFX_MMGR_Return IFX_MMGR_FreeResInfoGet(x_IFX_MMGR_ForkingResContext *pxResContext,
																		  x_IFX_MMGR_ResourceInfo **ppxResInfo
																													  );
e_IFX_MMGR_Return IFX_MMGR_ResInfoGet(
															x_IFX_MMGR_ForkingResContext *pxResContext,
															x_IFX_MMGR_ResourceInfo *pxSearchResInfo,
															x_IFX_MMGR_ResourceInfo **ppxResInfo
															     );
e_IFX_MMGR_Return IFX_MMGR_StoreCodecInfo(x_IFX_MMGR_ForkingResContext *pxResContext,
																		  x_IFX_MMGR_ResourceInfo *pxResInfo,
																			  x_IFX_MMGR_CodecList *pxCodec);
e_IFX_MMGR_Return IFX_MMGR_FreeCodecInfo(x_IFX_MMGR_ForkingResContext *pxResContext,
																		  x_IFX_MMGR_ResourceInfo *pxResInfo
																													  );

e_IFX_MMGR_Return IFX_MMGR_DeAllocCoder(x_IFX_MMGR_Data_Channel *pxCoder);

int32 IFX_MMGR_GenerateresourceId();

e_IFX_MMGR_Return IFX_MMGR_SearchEndptResource(char8* pszEndPtId,
									IN_OUT x_IFX_MMGR_ResourceInfo *pxResInfo);

e_IFX_MMGR_Return IFX_MMGR_AllocSigResource(char* pszendPtId);

e_IFX_MMGR_Return IFX_MMGR_AllocateSigResourceForFxs(x_IFX_MMGR_Fxs_Channel *pxFxs);

e_IFX_MMGR_Return IFX_MMGR_AllocateSigResourceForFxo(x_IFX_MMGR_Fxo_Channel *pxFxo);

e_IFX_MMGR_Return IFX_MMGR_DeAllocateSigResource(char8 *pszEndPtId);

e_IFX_MMGR_Return IFX_MMGR_DeAllocateSigResourceForFxs(x_IFX_MMGR_Fxs_Channel *pxFxs);

e_IFX_MMGR_Return IFX_MMGR_DeAllocateSigResourceForFxo(x_IFX_MMGR_Fxo_Channel *pxFxo);

e_IFX_MMGR_Return IFX_MMGR_ResourceContextGet(int32 iResourceId ,
									x_IFX_MMGR_ResourceContext **ppxResContext);


e_IFX_MMGR_Return IFX_MMGR_EnableLec(x_IFX_MMGR_ResourceInfo *pxRes,
									 uchar8 *pucCpuUsage
									 );

e_IFX_MMGR_Return IFX_MMGR_DisableLec(x_IFX_MMGR_ResourceInfo *pxRes,
									 uchar8 *pucCpuUsage
									 );
/* Extn Call */
e_IFX_MMGR_Return IFX_MMGR_ResReserveForExtnCall(int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									);

e_IFX_MMGR_Return IFX_MMGR_ResFreeForExtnCall(int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									);
/* Extn-Voip Call */
e_IFX_MMGR_Return IFX_MMGR_ResReserveForExtnVoipCall(int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									);
e_IFX_MMGR_Return IFX_MMGR_ResFreeForExtnVoipCall(int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									);
/* Extn - FXO Call */
e_IFX_MMGR_Return IFX_MMGR_ResReserveForExtnFxoCall(int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									);
e_IFX_MMGR_Return IFX_MMGR_ResFreeForExtnFxoCall(int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									);
/* Fxo - Extn Call */
e_IFX_MMGR_Return IFX_MMGR_ResFreeForFxoExtnCall(
									int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									);

e_IFX_MMGR_Return IFX_MMGR_ResReserveForFxoExtnCall(
									int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									);
/* VOIP-FXO Call */

e_IFX_MMGR_Return IFX_MMGR_ResReserveForVoipFxoCall(
									int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									);
e_IFX_MMGR_Return IFX_MMGR_ResFreeForVoipFxoCall(int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									);
/* VOIP -Extn Call */
e_IFX_MMGR_Return IFX_MMGR_ResReserveForVoipExtnCall(
									int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									);
e_IFX_MMGR_Return IFX_MMGR_ResFreeForVoipExtnCall(int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									);
/* FXO-VOIP Call */
e_IFX_MMGR_Return IFX_MMGR_ResReserveForFxoVoipCall(
									int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									);
e_IFX_MMGR_Return IFX_MMGR_ResFreeForFxoVoipCall(int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									);


e_IFX_MMGR_Return IFX_MMGR_GetEndPtId(e_IFX_MMGR_ResourceType eRestype ,
			   						uint16 unChannelNum,
									IN_OUT char **ppszEndPtId);

e_IFX_MMGR_Return IFX_MMGR_ConfigureCoderSettings(
								x_IFX_MMGR_Data_Channel *pxCoder,
								x_IFX_MMGR_MediaParams *Params);

e_IFX_MMGR_Return IFX_MMGR_XConnect(x_IFX_MMGR_ResourceContext *pxResContext);

e_IFX_MMGR_Return IFX_MMGR_XDisConnect(x_IFX_MMGR_ResourceContext *pxResContext);
int32 IFX_MMGR_GetFd(char8* pszEndPtId);
int32 IFX_MMGR_GetSigFd(char8* pszEndPtId);

uint32 IFX_MMGR_GenerateSSRC(void);
uint16 IFX_MMGR_GenerateSeqNum(void);
e_IFX_MMGR_Return IFX_MMGR_GetDspEvents(
						                           IN int32 iFd,
					                            IN_OUT x_IFX_MMGR_DeviceEvents *pxDeviceEvent,
																		   IN_OUT int32 *puiNoOfEndPts
						                            );
e_IFX_MMGR_Return IFX_MMGR_GetFxoEvents(
						                           IN int32 iFd,
					                            IN_OUT x_IFX_MMGR_DeviceEvents *pxDeviceEvent,
																	   IN_OUT int32 *puiNoOfEndPts
						                            );
e_IFX_MMGR_Return IFX_MMGR_IsUpdateCodecPossible(
																			x_IFX_MMGR_ResourceContext *pxResContext,
																		 	x_IFX_MMGR_CodecList *pxNewList);
int32 IFX_MMGR_GetSigFd(char8* pszEndPtId);
int32 IFX_MMGR_GetFd(char8* pszEndPtId);
int32 IFX_MMGR_GetToneIndex(e_IFX_MMGR_ToneType eToneType);


e_IFX_MMGR_Return IFX_MMGR_DuslicChipInit();
e_IFX_MMGR_Return IFX_MMGR_LoadResDect(x_IFX_MMGR_Dect_Channel *pxDect,
									   x_IFX_MMGR_CodecList *pxCodec
									);
e_IFX_MMGR_Return IFX_MMGR_TAPI_FlushErr(int32 iDevFd);
#endif /*__IFX_MMGR_CORE__*/










	









    
