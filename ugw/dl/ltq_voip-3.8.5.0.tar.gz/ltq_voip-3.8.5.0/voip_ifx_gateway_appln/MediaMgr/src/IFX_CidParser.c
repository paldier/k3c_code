#include "IFX_Config.h"
#include "IFX_MediaMgrTypes.h"
#include "IFX_MediaMgrIf.h"
#include <stdio.h>
#include <stdlib.h>

#define IFX_MMGR_FAIL -1
#define IFX_MMGR_SUCCESS 0
#define IFX_MMGR_ASCII_US 31
#define IFX_MMGR_ASCII_DEL 127
#define IFX_MMGR_FSK_NAME_LEN 40
#define printf(...)
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeDateTime(
				  uchar8* pcData, uchar8 ucLen, void  **pvParam)
{
	x_IFX_MMGR_FSK_DateTime *pxDate;
	pxDate = malloc(sizeof(x_IFX_MMGR_FSK_DateTime));
	if(pxDate == NULL)
	{
		printf(" Memory allocation error \n");
		return IFX_MMGR_FAIL;
	}
	pxDate->ucMonth = (*pcData++ - '0') << 4;
	pxDate->ucMonth |= *pcData++ - '0';
	pxDate->ucDay = (*pcData++ - '0' ) << 4;
	pxDate->ucDay |= *pcData++ - '0';
	pxDate->ucHour = (*pcData++ - '0') << 4;
	pxDate->ucHour |= *pcData++ - '0';
	pxDate->ucMin = (*pcData++ - '0') << 4;
    pxDate->ucMin |= *pcData++ - '0';
	*pvParam = pxDate;
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_IsValidChar(uchar8 ucData)
{
	if((ucData > IFX_MMGR_ASCII_US) && (ucData < IFX_MMGR_ASCII_DEL))
	{
		return IFX_MMGR_SUCCESS;
	}
	else
	{
		return IFX_MMGR_FAIL;
	}
}
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeText(uchar8 *pucData ,
	   									uchar8 ucLen, 
										void **pvParam)
{
	uchar8 ucIndex = 0;
	uchar8 ucIndx = 0;
	uchar8 *paucText = malloc(IFX_MMGR_FSK_NAME_LEN);
	printf(" In Decode Text \n");
	if(!paucText)
	{
		printf("Memory Allocation Error \n");
		return IFX_MMGR_FAIL;
	}
	while( ucIndex != ucLen)
	{
		if(IFX_MMGR_IsValidChar(pucData[ucIndex]) == IFX_MMGR_SUCCESS)
		{
			paucText[ucIndx++] = pucData[ucIndex++];
		}
		else
		{
			ucIndex++;
		}
		if (ucIndx == IFX_MMGR_FSK_NAME_LEN-1)
			break;
	}
	paucText[ucIndx] = '\0';
	*pvParam = paucText;
	printf(" Decoded text successfully\n");
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeAbsReason(uchar8 *pucData ,
	   									uchar8 ucLen, 
										void **pvParam)
{
	uchar8 *pucAbsReason = NULL;
	if(ucLen > 1)
	{
		printf(" Invalid parameter size \n");
		return IFX_MMGR_FAIL;
	}
	pucAbsReason = malloc(sizeof(uchar8));
	if (!pucAbsReason)
		return IFX_MMGR_FAIL;

	*pucAbsReason = *pucData;
	*pvParam = pucAbsReason;
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeVisInd(uchar8 *pucData ,
	   									uchar8 ucLen, 
										void **pvParam)
{
	uchar8 *pucVisInd = NULL;
	if(ucLen > 1)
	{
		printf(" Invalid parameter size \n");
		return IFX_MMGR_FAIL;
	}
	pucVisInd = malloc(sizeof(uchar8));
	if (!pucVisInd)
		return IFX_MMGR_FAIL;
	*pucVisInd = *pucData;
	*pvParam = pucVisInd;
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeMsgInd(uchar8 *pucData ,
	   									uchar8 ucLen, 
										void **pvParam)
{
	x_IFX_MMGR_FSK_MsgId *pxMsgId;
	pxMsgId = malloc(sizeof(x_IFX_MMGR_FSK_MsgId));
	if(!pxMsgId)
	{
		printf( " Memory Allocation Error \n");
		return IFX_MMGR_FAIL;
	}
	pxMsgId->ucMsgId = pucData[0];
	pxMsgId->unMsgRef = pucData[1] << 8;
	pxMsgId->unMsgRef |= pucData[2];
	*pvParam = pxMsgId;
	return IFX_MMGR_SUCCESS;
}

e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeCallType(uchar8 *pucData,
											  uchar8 ucLen,
											  void **pvParam)
{
	e_IFX_MMGR_FSK_CallType *peCallType;
	peCallType = malloc(sizeof(e_IFX_MMGR_FSK_CallType));
	if(!peCallType)
	{
		printf( " Memory Allocation Error \n");
		return IFX_MMGR_FAIL;
	}
	*peCallType = pucData[0];
	*pvParam = peCallType;
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeNumOfMsg(uchar8 *pucData,
											  uchar8 ucLen,
											  void **pvParam)
{
	uchar8 *pucNoOfMsg;
	pucNoOfMsg = malloc(sizeof(uchar8));
	if(!pucNoOfMsg)
	{
		printf( " Memory Allocation Error \n");
		return IFX_MMGR_FAIL;
	}
	*pucNoOfMsg = pucData[0];
	*pvParam = pucNoOfMsg;
	return IFX_MMGR_SUCCESS;
}
#define IFX_MMGR_FSK_DecodeCallFwdType IFX_MMGR_FSK_DecodeNumOfMsg
#define IFX_MMGR_FSK_DecodeCallerType IFX_MMGR_FSK_DecodeNumOfMsg
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeCharge(uchar8 *pucData,
											  uchar8 ucLen,
											  void **pvParam)
{
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeCallDuration(uchar8 *pucData,
											  uchar8 ucLen,
											  void **pvParam)
{
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeCarrierId(uchar8 *pucData,
											  uchar8 ucLen,
											  void **pvParam)
{
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_FSK_InValidParam(uchar8 *pucData,
											  uchar8 ucLen,
											  void **pvParam)
{
				printf(" InValid paramter \n");
	return IFX_MMGR_SUCCESS;
}



e_IFX_MMGR_Return IFX_MMGR_FSK_FreeData(x_IFX_MMGR_FSK_Data *pxFsk)
{
	uint16 unCount;
	if(!pxFsk)
	{
		return IFX_MMGR_SUCCESS;
	}
	for(unCount=0; unCount< IFX_MMGR_FSK_MAX_PARAMS;unCount++)
	{
		if(pxFsk->apvParams[unCount])
		{
			free(pxFsk->apvParams[unCount]);
			pxFsk->apvParams[unCount] = 0;
		}
	}
	return IFX_MMGR_SUCCESS;
}

		
typedef e_IFX_MMGR_Return (*pfnDecodeParams) (uchar8 *pucData, uchar8 ucLen, void **ppvParam);
pfnDecodeParams pfnDecoder[] = {
				IFX_MMGR_FSK_InValidParam,
				IFX_MMGR_FSK_DecodeDateTime,
				IFX_MMGR_FSK_DecodeText,/* CLI */
				IFX_MMGR_FSK_DecodeText, /* Called id */
				IFX_MMGR_FSK_DecodeAbsReason,
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_DecodeText, /* Name */
				IFX_MMGR_FSK_DecodeAbsReason, /* Name absence Reason */
				IFX_MMGR_FSK_InValidParam, /* Undefined Param */
				IFX_MMGR_FSK_InValidParam, /* Undefined Param */
				IFX_MMGR_FSK_DecodeVisInd, /* Visual Indication */
				IFX_MMGR_FSK_InValidParam,
				IFX_MMGR_FSK_DecodeMsgInd, /* Message Indication */
				IFX_MMGR_FSK_DecodeText, /* Last Msg CLI */
				IFX_MMGR_FSK_DecodeDateTime, /* Complementry Date and time */
				IFX_MMGR_FSK_DecodeText, /* Complementry CLI */
				IFX_MMGR_FSK_DecodeCallType, /* Call Type */
				IFX_MMGR_FSK_DecodeText, /* First Called CLI */
				IFX_MMGR_FSK_DecodeNumOfMsg, /* Number of messages */
				IFX_MMGR_FSK_InValidParam, /* Undefined Param */
				IFX_MMGR_FSK_DecodeCallFwdType, /* Call Forward type */
				IFX_MMGR_FSK_DecodeCallerType, /* Caller Type */
				IFX_MMGR_FSK_InValidParam,
				IFX_MMGR_FSK_InValidParam,
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_DecodeText, /* Redirecting Number */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_DecodeCharge, /* Charge */
				IFX_MMGR_FSK_DecodeCharge, /* Additional charge */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_DecodeCallDuration, /* Call duration */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
			  IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_InValidParam,/* Undefined param */
				IFX_MMGR_FSK_DecodeCarrierId /* Carrier Id */
				};
	


e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeFskData(uchar8* pucData,
	   										int32 ucLen,
											x_IFX_MMGR_FSK_Data *pxFsk)
{
	uchar8 ucIndex=0;
	uchar8 ucParamLen;
	e_IFX_MMGR_FSK_ParamType eParamType;
	pxFsk->eMsgType = pucData[0];
	if(pucData[ucIndex] == IFX_MMGR_FSK_MSG_CALL_SETUP)
	{
		printf("  call setup Msg Type\n");
	}
	ucIndex++;
	while(ucIndex != ucLen)
	{
		/* Parse the parameters */
		eParamType = pucData[ucIndex++];
		if (eParamType >= IFX_MMGR_FSK_PARAM_CARRIER_ID){
			printf(" Param %d is not supported\n",eParamType);
			return IFX_MMGR_FAIL;
		}
		printf(" Decoding param %d\n",eParamType);
		/*if(eParamType > IFX_MMGE_CID_PARAM_EXTN)
		{
			printf("Invalid Param Type \n");
			return IFX_MMGR_FAIL;
		}*/
		ucParamLen = pucData[ucIndex++];
		if(pfnDecoder[eParamType](pucData+ucIndex,ucParamLen,&pxFsk->apvParams[eParamType]) != IFX_MMGR_SUCCESS)
		{
			printf(" Decoding failed for param type %d\n",eParamType);
			return IFX_MMGR_FAIL;
		}
		pxFsk->aeParams[eParamType] = eParamType;
		ucIndex += ucParamLen;
	}
	return IFX_MMGR_SUCCESS;
}



