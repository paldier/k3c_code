/*****************************************************************************
 **   FILE NAME       :IFX_LoadMgr.c
 **   PROJECT         :
 **   MODULES         :
 **   SRC VERSION     :
 **   DATE            : 
 **   AUTHOR          : gateway ATA Application Team
 **   DESCRIPTION     : This file contains the APIs and the data structures 
 **						exposed by the Load manager.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **   Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
******************************************************************************/
#include <stdio.h>
#include <memory.h>
#include "IFX_Config.h"
#include "IFX_MediaMgrTypes.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MediaMgr.h"
#include "IFX_LM_If.h"
#define printf(...) 
static x_IFX_LM_InitParams stxCpuUsageValues;
static int32 iCurrentCpuUsage;

e_IFX_LM_Return IFX_LM_LoadCompute(
								   	IN_OUT x_IFX_LM_Resource *pxResource,
									IN_OUT uchar8 *pucLoadValue
									);
e_IFX_LM_Return IFX_LM_AddCpuUsage(uchar8 ucCpuUsage);
e_IFX_LM_Return IFX_LM_LoadValueFree(uchar8 ucCpuUsage);

/*! \method     IFX_LM_Init
    \brief      This API is the initialization routine 
	            for the Load manager. The initialization parameters contains
				the percentage of CPU usage by all the resources.This API 
				also reserves the base load of the system.
    \param[in]  pxInitParams - pointer to x_IFX_LM_InitParams
	\return     IFX_LM_SUCCESS or IFX_LM_FAILURE
*/
/* This is the Initialization API for the Load Manager */
e_IFX_LM_Return IFX_LM_Init(
						 IN x_IFX_LM_InitParams *pxInitParams
						 )
{
	memcpy(&stxCpuUsageValues,pxInitParams,sizeof(x_IFX_LM_InitParams));
	iCurrentCpuUsage = IFX_LM_BASE_LOAD;
	return IFX_LM_SUCCESS;
}
e_IFX_LM_Return IFX_MMGR_SortCodecs(IN x_IFX_MMGR_CodecList *pxCodecList)
{
		 int32 i,j;
		 uchar8 *pucCpuUsage;
		 x_IFX_MMGR_CodecInfo temp;
		 pucCpuUsage = &stxCpuUsageValues.aucCPU_Usage_Codecs[0];

		 if (pxCodecList->ucNoOfCodecs > IFX_MMGR_CODEC_MAX)
			 return IFX_LM_INVALID_ARGUMENT;

		 for (i = (pxCodecList->ucNoOfCodecs - 1); i >= 0; i--)
		 {
		     for (j = 1; j <= i; j++)
				 {
		     		if (pucCpuUsage[pxCodecList->axCodecs[j-1].eCodecType]
													 	< pucCpuUsage[pxCodecList->axCodecs[j].eCodecType])
						{
						   memcpy(&temp,&pxCodecList->axCodecs[j-1],sizeof(x_IFX_MMGR_CodecInfo));
						   memcpy(&pxCodecList->axCodecs[j-1],
											&pxCodecList->axCodecs[j],sizeof(x_IFX_MMGR_CodecInfo));
						   memcpy(&pxCodecList->axCodecs[j],
															 &temp,sizeof(x_IFX_MMGR_CodecInfo));
						}
				}
		}
		 
    return IFX_LM_SUCCESS;
}

/*! \method     IFX_LM_LoadReserve
    \brief      This API reserves the load for a resource if its permissable.
	            It calculates the cpu usage for the requested resource and
				checks whether the resource could be run on the device, if 
				the CPU usage does not goes to 100% ,the load for this resource
				is added and success returned.
				If the resource type requested is of type codec, a list of codecs
				also needs to be provided as parameter, in which case
				the API returns a modified list of codecs that could
				be run on the device.
    \param[in,out]  pxResource - pointer to x_IFX_LM_Resource
	\return     IFX_LM_SUCCESS or IFX_LM_FAILURE
*/
e_IFX_LM_Return IFX_LM_LoadReserve(
								IN_OUT x_IFX_LM_Resource *pxResource,
								IN_OUT uchar8 *pucLoadValue
								)
{
    uchar8 ucCpuUsage;
	if(IFX_LM_LoadCompute(pxResource,&ucCpuUsage) != IFX_LM_SUCCESS)
	{
		printf("Load compute returned failure \n");
		/*return IFX_LM_NO_CPU_RESOURCE;*/
		return IFX_MMGR_SUCCESS;
	}
	if(iCurrentCpuUsage + ucCpuUsage < IFX_LM_MAX_CPU_USAGE)
	{
		iCurrentCpuUsage += ucCpuUsage;
        if(pucLoadValue)
        {
            *pucLoadValue = ucCpuUsage;
        }
				return IFX_MMGR_SUCCESS;
	}
    
	else
	{
		printf("No CPU Resource available\n");
		/*return IFX_LM_NO_CPU_RESOURCE;*/
		return IFX_MMGR_SUCCESS;

	}


}

/*! \method     IFX_LM_LoadFree
    \brief      This API frees the cpu usage for a type of resource.
	            If a list of codecs is provided the load of the most
				heavy codec will be freed by this API.
    \param[in]  pxResource - pointer to x_IFX_LM_Resource
	\return     IFX_LM_SUCCESS 
*/								
e_IFX_LM_Return IFX_LM_LoadFree(
							   x_IFX_LM_Resource *pxResource
							 )
{
    uchar8 ucCpuUsage;
    x_IFX_MMGR_CodecList xCodecList ;
	if(pxResource->eResourceType != IFX_LM_RES_CODEC)
	{
		ucCpuUsage = stxCpuUsageValues.aucCPU_Usage[pxResource->eResourceType];
		
	}
	else
	{
		memcpy(&xCodecList,&pxResource->xCodecList,sizeof(x_IFX_MMGR_CodecList));
		IFX_MMGR_SortCodecs(&xCodecList);
		ucCpuUsage = stxCpuUsageValues.aucCPU_Usage_Codecs[xCodecList.axCodecs[0].eCodecType];
	}
	iCurrentCpuUsage -= ucCpuUsage;
	if(iCurrentCpuUsage < 0)
					iCurrentCpuUsage = 0;
	return IFX_MMGR_SUCCESS;
}

e_IFX_LM_Return IFX_LM_LoadValueFree(uchar8 ucCpuUsage
								)
{
				iCurrentCpuUsage -= ucCpuUsage;
				return IFX_MMGR_SUCCESS;
}
e_IFX_LM_Return IFX_LM_AddCpuUsage(uchar8 ucCpuUsage)
{
				iCurrentCpuUsage += ucCpuUsage;
				return IFX_MMGR_SUCCESS;
}


e_IFX_LM_Return IFX_LM_LoadCompute(
								   	IN_OUT x_IFX_LM_Resource *pxResource,
									IN_OUT uchar8 *pucLoadValue
									)
{
    uchar8 ucCpuUsage=0;
	x_IFX_MMGR_CodecList xCodecList,xTempList;
	int16 nCount,nCtr,nOutIndex=0, i=0;
    x_IFX_MMGR_CodecInfo *pxCodecInfo;
    printf("In LoadCompute \n");
	if(pxResource->eResourceType != IFX_LM_RES_CODEC)
	{
        printf("Correct!!!\n");
		ucCpuUsage = stxCpuUsageValues.aucCPU_Usage[pxResource->eResourceType];
		
	}
	else
	{
		memcpy(&xCodecList,&pxResource->xCodecList,sizeof(x_IFX_MMGR_CodecList));
		IFX_MMGR_SortCodecs(&xCodecList);
		for(nCount=0;nCount<pxResource->xCodecList.ucNoOfCodecs;nCount++)
		{
			ucCpuUsage = stxCpuUsageValues.aucCPU_Usage_Codecs[xCodecList.axCodecs[nCount].eCodecType];
			printf(" Current cpu usage is %d \n",iCurrentCpuUsage);
			printf(" Codec %d cpu usage is %d\n",xCodecList.axCodecs[nCount].eCodecType,ucCpuUsage);
			if(iCurrentCpuUsage + ucCpuUsage < IFX_LM_MAX_CPU_USAGE)
			{
				xCodecList.ucNoOfCodecs -= nCount;
				break;
			}
		}
		if(nCount == pxResource->xCodecList.ucNoOfCodecs || nCount >= IFX_MMGR_CODEC_MAX || nCount+xCodecList.ucNoOfCodecs > IFX_MMGR_CODEC_MAX)
		{
			printf(" Current cpu usage is %d \n",iCurrentCpuUsage);
			printf("No Cpu resource to run the codecs\n");
			return IFX_LM_NO_CPU_RESOURCE;
		}
		//memcpy(xTempList.axCodecs,&xCodecList.axCodecs[nCount],sizeof(x_IFX_MMGR_CodecInfo)*xCodecList.ucNoOfCodecs);
		for (i=0; i<xCodecList.ucNoOfCodecs; i++){
			memcpy(&xTempList.axCodecs[i],&xCodecList.axCodecs[nCount+i],sizeof(x_IFX_MMGR_CodecInfo));
		}
		xTempList.ucNoOfCodecs = xCodecList.ucNoOfCodecs;
		/* Now prepare the output list in the same order it was input */
		memset(&xCodecList,0,sizeof(x_IFX_MMGR_CodecList));
		for(nCount=0;nCount<pxResource->xCodecList.ucNoOfCodecs;nCount++)
		{
			pxCodecInfo = &pxResource->xCodecList.axCodecs[nCount];
			for(nCtr=0;nCtr<xTempList.ucNoOfCodecs;nCtr++)
			{
				if(pxCodecInfo->eCodecType == xTempList.axCodecs[nCtr].eCodecType)
				{
					memcpy(&xCodecList.axCodecs[nOutIndex],&xTempList.axCodecs[nCtr],sizeof(x_IFX_MMGR_CodecInfo));
					nOutIndex++;
				}
			}
		}
		xCodecList.ucNoOfCodecs = xTempList.ucNoOfCodecs;
		memcpy(&pxResource->xCodecList,&xCodecList,sizeof(x_IFX_MMGR_CodecList));
	}
	*pucLoadValue = ucCpuUsage;
	return IFX_LM_SUCCESS;
}

e_IFX_LM_Return IFX_LM_LoadValFree(uchar8 ucCpuUsage)
{
	iCurrentCpuUsage -= ucCpuUsage;
	return IFX_LM_SUCCESS;
}

/*! \method     IFX_LM_Shut
    \brief      This API is the de-initialization routine of the Load 
	             manager.
    \return     IFX_LM_SUCCESS 
*/				
e_IFX_LM_Return IFX_LM_Shut(
						    )
{
	return IFX_LM_SUCCESS;
}











