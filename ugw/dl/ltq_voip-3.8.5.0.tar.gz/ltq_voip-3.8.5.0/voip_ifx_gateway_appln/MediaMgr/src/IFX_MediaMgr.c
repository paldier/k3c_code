/*****************************************************************************
 **   FILE NAME       :IFX_MediaMgr.c
 **   PROJECT         :
 **   MODULES         :
 **   SRC VERSION     :
 **   DATE            : 
 **   AUTHOR          : Gateway Application Team
 **   DESCRIPTION     : This file contains the APIs and the data structures 
 **						exposed by the Media manager to the different agents
 **                     and the call manager.
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/
#include <stdio.h>
#include <memory.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include "IFX_Config.h"
#include "IFX_MediaMgrTypes.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MediaMgr.h"
#include "IFX_LM_If.h"
#include "IFX_TapiIf.h"
//#include "ifx_types.h"
#include "drv_tapi_io.h"
#include <drv_tapi_event_io.h>
#include "drv_tapi_qos_io.h"
#include "ifx_os.h"
#include "ifx_debug.h"
#define IFX_MMGR_MAX_RESOURCE_CONTEXT 14
#define IFX_MMGR_MAX_CONF_CONTEXT 8
#define  IFX_MMGR_LEC_TAIL_LEN_8 8
#define  IFX_MMGR_LEC_TAIL_LEN_16 16
#define  IFX_MMGR_DANUBE_PORT "/dev/danube-port"
#define printf(...) 
 uchar8 vucMmgrModId;
extern e_IFX_MMGR_Return IFX_MMGR_SigDetect(int32 iFd, boolean bEnable);
static x_IFX_MMGR_Resources stxResources;
#define GLOBAL_VAR_OVERWRITE
#ifndef GLOBAL_VAR_OVERWRITE
static x_IFX_MMGR_ResourceContext 
       staxResourceContext[IFX_MMGR_MAX_RESOURCE_CONTEXT];
#else
x_IFX_MMGR_ResourceContext *staxResourceContext;
#endif
static x_IFX_MMGR_Tone_Info stxToneInfo;
static int32 stiResourceId  = 1;
//static int32 stiDanubePortFd;

#ifdef ENABLE_FXO
extern boolean vbFxoEnable;
#endif

#ifdef CVOIP_SUPPORT
static int32 iNumOfPcmAlloted;
extern uchar8 vaucPcmChannelNo[6];
#endif
x_IFX_MMGR_ForkingResContext 
       staxForkingResContext[IFX_MMGR_MAX_RESOURCE_CONTEXT];
x_IFX_MMGR_ConferenceContext staxConfContext[IFX_MMGR_MAX_CONF_CONTEXT];
char8 szFileName[] = "IFX_MediaMgr.c";
pfnResReserveForCall pafnResReserveForCall[] = {
				IFX_MMGR_ResReserveForExtnCall,
				IFX_MMGR_ResReserveForExtnVoipCall,
				IFX_MMGR_ResReserveForVoipExtnCall,
				IFX_MMGR_ResReserveForFxoVoipCall,
				IFX_MMGR_ResReserveForVoipFxoCall,
		    IFX_MMGR_ResReserveForFxoExtnCall,
				IFX_MMGR_ResReserveForExtnFxoCall
				};
pfnResFreeForCall pafnResFreeForCall[] = {
				IFX_MMGR_ResFreeForExtnCall,
				IFX_MMGR_ResFreeForExtnVoipCall,
		    IFX_MMGR_ResFreeForVoipExtnCall,
				IFX_MMGR_ResFreeForFxoVoipCall,
				IFX_MMGR_ResFreeForVoipFxoCall,
				IFX_MMGR_ResFreeForFxoExtnCall,
				IFX_MMGR_ResFreeForExtnFxoCall
				};

/* Extern functions */
e_IFX_MMGR_Return IFX_MMGR_FSK_DecodeFskData(uchar8* pucData,
                        int32 ucLen,
                      x_IFX_MMGR_FSK_Data *pxFsk);
e_IFX_MMGR_Return IFX_MMGR_TAPI_GetEvents(int32 iChFd ,IFX_TAPI_EVENT_t *paxEventInfo);

e_IFX_MMGR_Return IFX_MMGR_Init(x_IFX_MMGR_InitParams *pxInitParams,
                                IN int32 iDbgId,
                                OUT x_IFX_MMGR_FdSet *pxFdSet)
{
	x_IFX_LM_InitParams xLMInitParams = {{0,9,9,9,7,14,11,12,9,4},
					              {0,10,10,13,13,19,19,10,13,13,13,15,12,16,16,19,5}};
	e_IFX_MMGR_Return eRet = IFX_MMGR_SUCCESS;
#ifdef GLOBAL_VAR_OVERWRITE
  staxResourceContext=calloc(1,sizeof(x_IFX_MMGR_ResourceContext)*IFX_MMGR_MAX_RESOURCE_CONTEXT);
#endif
	vucMmgrModId = iDbgId;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	/* Validate the input parameters */
	if(pxInitParams == NULL)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Invalid Parameter");
		eRet = IFX_MMGR_INVALID_PARAMETER;
		goto ERROR_HDLR;
	}
    memset(pxFdSet,0,sizeof(x_IFX_MMGR_FdSet));
	/* Initialize the DSP device i.e. the vmmc device */
	if(IFX_MMGR_DSP_Dev_Init(&pxInitParams->xDSPDevice,
                pxFdSet)!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "DSP Dev Init Failed");
		eRet = IFX_MMGR_DSP_DEV_INIT_FAILED;
	    goto ERROR_HDLR;	
	}
  sleep(5);
  if(IFX_MMGR_Data_Channel_Init(&pxInitParams->xCoderRes) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Data channel Init Failed");
		eRet = IFX_MMGR_CHANNEL_INIT_FAILED;
		goto ERROR_HDLR;
	}



#if !(defined(SLIC121))
  	if(IFX_MMGR_TAPI_ConfigurePcmIf(stxResources.iDspDevFd)
								!= IFX_MMGR_SUCCESS)
  {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Configuring the PCM IF  Failed");
       return IFX_MMGR_FAIL;
  	}
#endif


#ifndef DISABLE_FXS
  if(IFX_MMGR_Fxs_Channel_Init(&pxInitParams->xFxsRes) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Fxs Channel Init Failed");
		eRet = IFX_MMGR_CHANNEL_INIT_FAILED;
		goto ERROR_HDLR;
	}
#endif

#ifdef ENABLE_FXO
	if(vbFxoEnable){
	/* Initialize the FXO device i.e. Duslic device */
	if(IFX_MMGR_FXO_Dev_Init(&pxInitParams->xFXODevice,
                pxFdSet) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "FXO Dev Init Failed");
		eRet = IFX_MMGR_FXO_DEV_INIT_FAILED;
		goto ERROR_HDLR;
	}

   if(IFX_MMGR_Fxo_Channel_Init(&pxInitParams->xFxoRes) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Fxo Channel Init Failed");
			eRet = IFX_MMGR_CHANNEL_INIT_FAILED;
			goto ERROR_HDLR;
		}
	}
#endif
#if defined(DECT_SUPPORT) || defined (CVOIP_SUPPORT)
		printf("CMGR-CVOIP, Calling IFX_MMGR_Dect_Channel_Init\n");
    if(IFX_MMGR_Dect_Channel_Init(&pxInitParams->xDectRes) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "dect Channel Init Failed");
		eRet = IFX_MMGR_CHANNEL_INIT_FAILED;
		goto ERROR_HDLR;
	}
#endif
    
	/* Initialize the load manager */
	if(IFX_LM_Init(&xLMInitParams) != IFX_LM_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "LM Init Failed");
		eRet = IFX_MMGR_LM_INIT_FAILED;
		goto ERROR_HDLR;
	}
#ifndef DISABLE_FXS
    /* Set the country settings parameters */
	if(IFX_MMGR_CountrySettingsUpdate(&pxInitParams->xSettingparams) 
												!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Updating Country Settings Failed");
		eRet = IFX_MMGR_INIT_FAILED;
		goto ERROR_HDLR;
	}
#endif
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return eRet;
ERROR_HDLR:
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Failure");
	return eRet;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DSP_Dev_Init
 *  Description       : Function is responsible for initializing the DSP device
 *  Input Values      : pxDev -  Device info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_DSP_Dev_Init(x_IFX_MMGR_Device_Info *pxDev,
                                        x_IFX_MMGR_FdSet *pxFdSet
                                        )
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Entry");
	
	if(pxDev == NULL){
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Invalid Parameter");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,"Opening ",
					pxDev->szDeviceName);
	/* open the device fd */
	stxResources.iDspDevFd = IFX_OS_OpenFile(pxDev->szDeviceName,O_RDONLY);
	if(stxResources.iDspDevFd < 0) 
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Opening the DSP device Failed");
		return IFX_MMGR_FAIL;
	}
	/*Chintan:- Clean up before use*/
	 if(ioctl(stxResources.iDspDevFd,IFX_TAPI_DEV_STOP) < 0 ) {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Clean up failed - proceeding anyway");
	 }
	/*Chintan*/
  pxFdSet->aiFd[(pxFdSet->ucNoOfFds)++] = stxResources.iDspDevFd;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
#ifdef ENABLE_FXO
/*****************************************************************************
 *  Function Name     : IFX_MMGR_FXO_Dev_Init
 *  Description       : Function is responsible for initializing the FXO device
 *  Input Values      : pxDev -  Device info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_FXO_Dev_Init(x_IFX_MMGR_Device_Info *pxDevInfo, 
                                        x_IFX_MMGR_FdSet *pxFdSet
                                        )
{
	if(pxDevInfo == NULL)	{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"Dev Info Null");
		return IFX_MMGR_INVALID_PARAMETER;
	}
#ifndef SLIC121
	/* open the device fd */
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,"Opening ",
					pxDevInfo->szDeviceName);
	stxResources.iFxoDevFd = IFX_OS_OpenFile(pxDevInfo->szDeviceName,O_RDONLY);
	if(stxResources.iFxoDevFd < 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Opening the FXo device Failed");
		return IFX_MMGR_FAIL;
	}
	pxFdSet->aiFd[(pxFdSet->ucNoOfFds)++] = stxResources.iFxoDevFd;
#else
  stxResources.iFxoDevFd = stxResources.iDspDevFd;
#endif
#ifdef TEREDIAN
	/*Teridian specifc PCM Config */
  if(IFX_MMGR_SUCCESS != IFX_MMGR_Teridian_CfgPCMInterface(stxResources.iFxoDevFd)){
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Teredian FXO Config PCM failed");
		return IFX_MMGR_FAIL;
  }
#elif SLIC121
  /*No dev specific Config*/
#else
	if(IFX_MMGR_TAPI_Duslic_Init(stxResources.iFxoDevFd,
     &pxDevInfo->uxDevParams.xFxoParam) != IFX_MMGR_SUCCESS)
	{
		return IFX_MMGR_FAIL;
	}
#endif
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
#endif
/*****************************************************************************
 *  Function Name     : IFX_MMGR_Fxs_Channel_Init
 *  Description       : Function is responsible for initializing the FXS channel 
 *  Input Values      : pxFxsRes -  FXS info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_Fxs_Channel_Init(x_IFX_MMGR_FXS_Resources *pxFxsRes)
{
	x_IFX_MMGR_Fxs_Channel *pxFxsChannel,*paxFxsChannel;
	x_IFX_MMGR_FXS_ResourceInfo *pxFxsInfo;
    uint16 nCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	paxFxsChannel = (x_IFX_MMGR_Fxs_Channel*)
									IFX_OS_Malloc(pxFxsRes->unNoOfFxsResources 
                   * sizeof(x_IFX_MMGR_Fxs_Channel));
	if(paxFxsChannel == NULL)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Memory Allocation Failed");
		return IFX_MMGR_MEMORY_ERROR;
	}
	memset(paxFxsChannel,0,
		pxFxsRes->unNoOfFxsResources*sizeof(x_IFX_MMGR_Fxs_Channel));
	stxResources.paxFxsEndPts = paxFxsChannel;
#ifdef UTA	
    /* Only 1 FXS channel on UTA board */
    stxResources.unNoOfFxs = 1;
	for(nCount=0; nCount < 1;nCount++)
#else
    stxResources.unNoOfFxs = pxFxsRes->unNoOfFxsResources;
	for(nCount=0; nCount < pxFxsRes->unNoOfFxsResources;nCount++)
#endif
	{
        pxFxsChannel = &stxResources.paxFxsEndPts[nCount];
		pxFxsInfo = &pxFxsRes->pxFxsInfo[nCount];
		strcpy(pxFxsChannel->szChannelName,pxFxsInfo->szChannelName);
		pxFxsChannel->iFd = IFX_OS_OpenFile(pxFxsChannel->szChannelName,O_RDWR);
		if(pxFxsChannel->iFd < 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Opening Fxs Channel Failed");
			goto ERROR_HDLR;
		}
		/* Call the TAPI service to initialize the channels */
		if(IFX_MMGR_TAPI_ChannelInit(pxFxsChannel->iFd,0,IFX_MMGR_FXS_RESOURCE,
			                         pxFxsRes->pucFw,
									 pxFxsRes->iFWSize,
									 pxFxsRes->pucCoeffcient,
									 pxFxsRes->iCoefficientSize)< 0)
		{
			printf("error initializing the FXS channel \n");
			goto ERROR_HDLR;
		}
        if(IFX_MMGR_TAPI_SetLineFeedStandBy(pxFxsChannel->iFd) != IFX_MMGR_SUCCESS)
        {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Setting Line Feed Failed");
            return IFX_MMGR_FAIL;
        }
		strcpy(pxFxsChannel->szEndPtId,pxFxsInfo->szEndPtId);
		pxFxsChannel->iInterfaceId = pxFxsInfo->iInterfaceId;
		pxFxsChannel->bIsWideBandEnabled = pxFxsInfo->bIsWideBandEnabled;
		pxFxsChannel->bIsLecEnabled = pxFxsInfo->bIsLecEnabled;
		pxFxsChannel->ucLecTailLength = pxFxsInfo->cLecTailLength;
		pxFxsChannel->unVolumeLevel = pxFxsInfo->unVolumeLevel;
		pxFxsChannel->unChannelNum = pxFxsInfo->unChannelNum;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
ERROR_HDLR:
	if(paxFxsChannel)
	{
		IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Failure");
		IFX_OS_Free(paxFxsChannel);
	}
	return IFX_MMGR_FAIL;

}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_Fxo_Channel_Init
 *  Description       : Function is responsible for initializing the FXO channel 
 *  Input Values      : pxFxsRes -  FXO info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_Fxo_Channel_Init(x_IFX_MMGR_FXO_Resources *pxFxoRes)
{
	x_IFX_MMGR_Fxo_Channel *pxFxoChannel,*paxFxoChannel;
	x_IFX_MMGR_FXO_ResourceInfo *pxFxoInfo;
    uint16 nCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	paxFxoChannel = (x_IFX_MMGR_Fxo_Channel*)IFX_OS_Malloc(
									 pxFxoRes->unNoOfFxoResources 
                    * sizeof(x_IFX_MMGR_Fxo_Channel));
	if(paxFxoChannel == NULL)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Memory Allocation  Failed");
		return IFX_MMGR_MEMORY_ERROR;
	}
    memset(paxFxoChannel,0,pxFxoRes->unNoOfFxoResources 
                           * sizeof(x_IFX_MMGR_Fxo_Channel));
	stxResources.paxFxoEndPts = paxFxoChannel;
  stxResources.unNoOfFxo = pxFxoRes->unNoOfFxoResources;
	for(nCount=0; nCount < pxFxoRes->unNoOfFxoResources;nCount++)
	{
        pxFxoChannel = &stxResources.paxFxoEndPts[nCount];
		pxFxoInfo = &pxFxoRes->pxFxoInfo[nCount];
		pxFxoChannel->iInterfaceId = pxFxoInfo->iInterfaceId;
		pxFxoChannel->bIsLecEnabled = pxFxoInfo->bIsLecEnabled;
		pxFxoChannel->ucLecTailLength = pxFxoInfo->ucLecTailLength;
		pxFxoChannel->unChannelNum = pxFxoInfo->unChannelNum;
		strcpy(pxFxoChannel->szChannelName,pxFxoInfo->szChannelName);
#ifndef SLIC121
		strcpy(pxFxoChannel->szPcmChannelName,pxFxoInfo->szPcmChannelName);
#endif
		pxFxoChannel->iFd = IFX_OS_OpenFile(pxFxoChannel->szChannelName,O_RDWR);
		if(pxFxoChannel->iFd < 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Opening the fxo channel  Failed");
			goto ERROR_HDLR;
		}
#ifndef SLIC121
		pxFxoChannel->iPcmFd = IFX_OS_OpenFile(pxFxoChannel->szPcmChannelName,O_RDWR);
		if(pxFxoChannel->iPcmFd < 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Opening the pcm channel  Failed");
			goto ERROR_HDLR;
		}
#endif
		 /*Call the TAPI service to initialize the channels */
				if(IFX_MMGR_TAPI_ChannelInit(pxFxoChannel->iFd,
								     pxFxoChannel->iPcmFd,IFX_MMGR_FXO_RESOURCE,
			               NULL,0,
									 pxFxoRes->pucCoefficient,
									 pxFxoRes->iCoefficientSize)< 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Initializing the fxo channel  Failed");
			goto ERROR_HDLR;
		}
		strcpy(pxFxoChannel->szEndPtId,pxFxoInfo->szEndPtId);
#if 0
		if(IFX_MMGR_TAPI_PcmChannelConfig(pxFxoChannel->iPcmFd,
							pxFxoChannel->iFd,1) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Configuring the PCM Channel  Failed");
			return IFX_MMGR_FAIL;
		}
#endif
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
ERROR_HDLR:
	if(paxFxoChannel)
	{
		IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Failure");
		IFX_OS_Free(paxFxoChannel);
	}
	return IFX_MMGR_FAIL;
}

/*****************************************************************************
 *  Function Name     : IFX_MMGR_Dect_Channel_Init
 *  Description       : Function is responsible for initializing the FXO channel 
 *  Input Values      : pxFxsRes -  FXO info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_Dect_Channel_Init(
								x_IFX_MMGR_DECT_Resources *pxDectRes
								            )
{
	x_IFX_MMGR_Dect_Channel *pxDectChannel,*paxDectChannel;
	x_IFX_MMGR_DECT_ResourceInfo *pxDectInfo;
    uint16 nCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	paxDectChannel = (x_IFX_MMGR_Dect_Channel*)IFX_OS_Malloc(
									pxDectRes->unNoOfDectResources 
                    * sizeof(x_IFX_MMGR_Dect_Channel));
	if(paxDectChannel == NULL)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Memory Allocation  Failed");
		return IFX_MMGR_MEMORY_ERROR;
	}
    memset(paxDectChannel,0,pxDectRes->unNoOfDectResources 
                           * sizeof(x_IFX_MMGR_Dect_Channel));
	stxResources.paxDectEndPts = paxDectChannel;
    stxResources.unNoOfDect = pxDectRes->unNoOfDectResources;
	for(nCount=0; nCount < pxDectRes->unNoOfDectResources;nCount++)
	{
		pxDectInfo = &pxDectRes->pxDectInfo[nCount];
    pxDectChannel = &stxResources.paxDectEndPts[nCount];
		#ifdef CVOIP_SUPPORT
		//if(nCount < 4 ){
		#endif
		printf("CMGR-CV, channel no:%d, name:%s\n",pxDectInfo->unChannelNum,pxDectInfo->szChannelName);
		pxDectChannel->unChannelNum = pxDectInfo->unChannelNum;
		pxDectChannel->bIsFree = IFX_TRUE;
		strcpy(pxDectChannel->szChannelName,pxDectInfo->szChannelName);
#ifdef CVOIP_SUPPORT
		pxDectChannel->szEndPtId[0] = '1' + nCount;
		pxDectChannel->szEndPtId[1] = 0;
#endif
		pxDectChannel->iFd = IFX_OS_OpenFile(pxDectChannel->szChannelName,O_RDWR);
		if(pxDectChannel->iFd < 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Opening the Dect Channel  Failed");
			goto ERROR_HDLR;
		}
		printf("CMGR-CV just after open fd is %d\n",pxDectChannel->iFd);
		#ifdef CVOIP_SUPPORT
		//}
		#endif
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
ERROR_HDLR:
	if(paxDectChannel)
	{
		IFX_OS_Free(paxDectChannel);
		IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Failure");
	}
	return IFX_MMGR_FAIL;
}

/*****************************************************************************
 *  Function Name     : IFX_MMGR_Coder_Channel_Init
 *  Description       : Function is responsible for initializing the Coder 
 *						channel 
 *  Input Values      : pxFxsRes -  Coder info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_Data_Channel_Init(
								x_IFX_MMGR_Coder_Resources *pxCoderRes
								            )
{
	x_IFX_MMGR_Data_Channel *pxCoderChannel,*paxCoderChannel;
	x_IFX_MMGR_Coder_ResourceInfo *pxCoderInfo;
    uint16 nCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	paxCoderChannel = (x_IFX_MMGR_Data_Channel*)
					IFX_OS_Malloc(pxCoderRes->unNoOfCoderResources 
                      * sizeof(x_IFX_MMGR_Data_Channel));
	if(paxCoderChannel == NULL)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Memory Allocation  Failed");
		return IFX_MMGR_MEMORY_ERROR;
	}
    memset(paxCoderChannel,0,pxCoderRes->unNoOfCoderResources 
                      * sizeof(x_IFX_MMGR_Data_Channel));
	stxResources.paxCoders = paxCoderChannel;
    stxResources.unNoOfCoders = pxCoderRes->unNoOfCoderResources;
	for(nCount=0; nCount < pxCoderRes->unNoOfCoderResources;nCount++)
	{
        pxCoderChannel = &stxResources.paxCoders[nCount];
		pxCoderInfo = &pxCoderRes->pxCoderInfo[nCount];
		strcpy(pxCoderChannel->szChannelName,pxCoderInfo->szChannelName);
		printf("CMGR-CV, data channel no:%d, name:%s\n",pxCoderInfo->unChannelNum,pxCoderInfo->szChannelName);
		pxCoderChannel->iFd = IFX_OS_OpenFile(pxCoderChannel->szChannelName,O_RDWR);
		printf("CMGR-CV data just after open fd is %d\n",pxCoderChannel->iFd);
		if(pxCoderChannel->iFd < 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Opening the data channel Failed");
			goto ERROR_HDLR;
		}
		/* Call the TAPI service to initialize the channels */
		if(IFX_MMGR_TAPI_ChannelInit(pxCoderChannel->iFd,0,IFX_MMGR_CODER_RESOURCE,
			                         	 pxCoderRes->pucFw,pxCoderRes->iFWSize,
																 pxCoderRes->pucCoeffcient,
																 pxCoderRes->iCoefficientSize) < 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Initializing the data channel Failed");
			goto ERROR_HDLR;
		}
#if 0
		if(IFX_MMGR_TAPI_EnableMftd(pxCoderChannel->iFd,nCount,1) 
				!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Enabling the MFTD Failed");
			goto ERROR_HDLR;
		}
#endif
		pxCoderChannel->unChannelNum = nCount;
    pxCoderChannel->bIsCoderFree = IFX_TRUE;
		
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
ERROR_HDLR:
	if(paxCoderChannel)
	{
		IFX_OS_Free(paxCoderChannel);
		IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Failure");
	}
	return IFX_MMGR_FAIL;
}

/*****************************************************************************
 *  Function Name     : IFX_MMGR_CountrySettingsUpdate
 *  Description       : Function is responsible for initializing the Coder 
 *						channel 
 *  Input Values      : pxFxsRes -  Coder info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_CountrySettingsUpdate(
							x_IFX_MMGR_CountrySettingsParams *pxParams
												)
{
	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memcpy(&stxToneInfo.axTones[0],&pxParams->axTones[0],
                    sizeof(x_IFX_MMGR_Tone)*IFX_MMGR_MAX_TONE);
	stxToneInfo.unNoOfTones = pxParams->unNoOfTones;
    /* Add the default tones */
	for(unCount=0;unCount< pxParams->unNoOfTones;unCount++)
	{
    	if(unCount == IFX_MMGR_MAX_TONE)
		{
			continue;
		}
		if(IFX_MMGR_TAPI_AddTone(stxResources.paxFxsEndPts[0].iFd,
						&stxToneInfo.axTones[unCount]) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Adding the Tone Type Failed");
			return IFX_MMGR_FAIL;
		}
  }
	/* Update the hook validation timings */
	for(unCount=0 ; unCount <  stxResources.unNoOfFxs; unCount++)
	{
		if(IFX_MMGR_TAPI_HookTimeUpdate(stxResources.paxFxsEndPts[unCount].iFd,pxParams)
		< 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Updating the hook timings Failed");
			return IFX_MMGR_FAIL;
		}
	/* Configure the Cid standard */
		if(IFX_MMGR_TAPI_CidConfigure(stxResources.paxFxsEndPts[unCount].iFd,
												pxParams->eCidStd)< 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Configuring the CID Std Failed");
			return IFX_MMGR_FAIL;
		}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_AllocateResourceContext
 *  Description       : Function is responsible allocating a resource context. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ResourceContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
static e_IFX_MMGR_Return IFX_MMGR_AllocateResourceContext(
                                     x_IFX_MMGR_ResourceContext **ppxResContext
                                     )
{

	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(unCount=0; unCount < IFX_MMGR_MAX_RESOURCE_CONTEXT;unCount++)
	{
		if(staxResourceContext[unCount].iResourceId == 0)
		{
			*ppxResContext = &staxResourceContext[unCount];
			break;
		}
	}
	if(unCount == IFX_MMGR_MAX_RESOURCE_CONTEXT)
	{
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DeAllocateResourceContext
 *  Description       : Function is responsible de-allocating a resource context. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ResourceContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
static e_IFX_MMGR_Return IFX_MMGR_DeAllocateResourceContext(
                                      x_IFX_MMGR_ResourceContext *pxResContext
                                      )
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
#if 0
	if(pxResContext->apxDectCodecList[0])
		IFX_OS_Free(pxResContext->apxDectCodecList[0]);
	if(pxResContext->apxDectCodecList[1])
		IFX_OS_Free(pxResContext->apxDectCodecList[1]);
#endif
	memset(pxResContext,0,sizeof(x_IFX_MMGR_ResourceContext));
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ForkingResContextAlloc
 *  Description       : Function is responsible allocating a 
 *                      Forking resource context. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ForkingResContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
static e_IFX_MMGR_Return IFX_MMGR_ForkingResContextAlloc(
                                     x_IFX_MMGR_ForkingResContext **ppxResContext
                                     )
{

	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(unCount=0; unCount < IFX_MMGR_MAX_RESOURCE_CONTEXT;unCount++)
	{
		if(staxForkingResContext[unCount].iResourceId == 0)
		{
			*ppxResContext = &staxForkingResContext[unCount];
			break;
		}
	}
	if(unCount == IFX_MMGR_MAX_RESOURCE_CONTEXT)
	{
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ForkingResContextDealloc
 *  Description       : Function is responsible de-allocating a resource context. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ResourceContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ForkingResContextDealloc(
                                      x_IFX_MMGR_ForkingResContext *pxResContext
                                      )
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	uchar8 ucCount = 0;
	for (ucCount=0; ucCount<IFX_MMGR_MAX_FORK_ENDPT; ucCount++){
		if(pxResContext->apxDectCodecList[ucCount]){
			IFX_OS_Free(pxResContext->apxDectCodecList[ucCount]);
			pxResContext->apxDectCodecList[ucCount] = NULL;
		}
	}

	memset(pxResContext,0,sizeof(x_IFX_MMGR_ForkingResContext));
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ForkingResContextGet
 *  Description       : Function is responsible for searching a forking 
 *                      resource context for a resource id.
 *  Input Values      : iResourceId - ResourceId
						**ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ForkingResContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ForkingResContextGet(
									 int32 iResourceId,
                                     x_IFX_MMGR_ForkingResContext **ppxResContext
                                     )
{

	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	*ppxResContext = NULL;
	if(iResourceId == 0)
	{
			return IFX_MMGR_FAIL;
	}
	for(unCount=0; unCount < IFX_MMGR_MAX_RESOURCE_CONTEXT;unCount++)
	{
		if(staxForkingResContext[unCount].iResourceId == iResourceId)
		{
			*ppxResContext = &staxForkingResContext[unCount];
			break;
		}
	}
	if(unCount == IFX_MMGR_MAX_RESOURCE_CONTEXT)
	{
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ConfContextAlloc
 *  Description       : Function is responsible allocating a 
 *                      Forking resource context. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ForkingResContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ConfContextAlloc(
                                     x_IFX_MMGR_ConferenceContext **ppxConfContext
                                     )
{

	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(unCount=0; unCount < IFX_MMGR_MAX_CONF_CONTEXT;unCount++)
	{
		if(staxConfContext[unCount].iConferenceId == 0)
		{
			*ppxConfContext = &staxConfContext[unCount];
			break;
		}
	}
	if(unCount == IFX_MMGR_MAX_CONF_CONTEXT)
	{
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ConfContextDealloc
 *  Description       : Function is responsible de-allocating a resource context. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ResourceContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ConfContextDealloc(
                                      x_IFX_MMGR_ConferenceContext *pxConfContext
                                      )
{

	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(pxConfContext,0,sizeof(x_IFX_MMGR_ConferenceContext));
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ConfContextDealloc
 *  Description       : Function is responsible de-allocating a resource context. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ResourceContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ConfContextGet(int32 iConfId,
                                x_IFX_MMGR_ConferenceContext **ppxConfContext)
{
    uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(unCount=0; unCount< IFX_MMGR_MAX_CONF_CONTEXT ; unCount++)
	{
		if(staxConfContext[unCount].iConferenceId == iConfId)
		{
			*ppxConfContext = &staxConfContext[unCount];
			break;
		}
	}
	if(unCount == IFX_MMGR_MAX_RESOURCE_CONTEXT)
		return IFX_MMGR_FAIL;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

/*****************************************************************************
 *  Function Name     : IFX_MMGR_AllocateCoder
 *  Description       : Function is responsible allocating a coder resource. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ResourceContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_AllocateCoder(x_IFX_MMGR_Data_Channel **ppxCoder,
																				 boolean bIsFxsRes)
{
	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(unCount=0 ; unCount < stxResources.unNoOfCoders; unCount++)
	{
		if(stxResources.paxCoders[unCount].bIsCoderFree)
		{
			*ppxCoder = &stxResources.paxCoders[unCount];
			stxResources.paxCoders[unCount].bIsCoderFree = IFX_FALSE;
			if(bIsFxsRes) {
  				if( IFX_MMGR_SigDetect((*ppxCoder)->iFd,1) != IFX_MMGR_SUCCESS) {
							IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Activate Tone Detection failed");
					return IFX_MMGR_NO_RESOURCE;
				}
				(*ppxCoder)->bIsFxs = 1;
		}
		break;
	 }
	}
	if(unCount == stxResources.unNoOfCoders)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "No Coders Available");
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DeAllocCoder
 *  Description       : Function is responsible allocating a coder resource. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ResourceContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_DeAllocCoder(x_IFX_MMGR_Data_Channel *pxCoder)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	//printf("########<DeAllocCoder> Freeing Chnnl = %d \n",pxCoder->iFd);
	if(pxCoder->bIsFxs) {
			IFX_MMGR_SigDetect(pxCoder->iFd,0); 
	}
	pxCoder->bIsFxs = 0;
	pxCoder->bIsCoderFree = IFX_TRUE;
	pxCoder->eDestResType = IFX_MMGR_NONE;
	pxCoder->uxDestResource.pxFxs = NULL;
	memset(&pxCoder->xCodecList,0,sizeof(x_IFX_MMGR_CodecList));
	pxCoder->uiServiceFlag = 0;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_AllocDect
 *  Description       : Function is responsible allocating a dect resource. 
 *  Input Values      : **ppxDect -  pointer to pointer to 
 *                      x_IFX_MMGR_Dect_channel
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_AllocDect(x_IFX_MMGR_Dect_Channel **ppxDect,
									uint16 *puiChNum)
{
	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	#ifdef CVOIP_SUPPORT
	if(iNumOfPcmAlloted  == 4)
  {
    return IFX_MMGR_FAIL;
  }

	for(unCount=0; unCount< stxResources.unNoOfDect - 2; unCount++)
	#else 
	for(unCount=0; unCount< stxResources.unNoOfDect; unCount++)
	#endif
	{
		if(stxResources.paxDectEndPts[unCount].bIsFree)
		{
			*ppxDect = &stxResources.paxDectEndPts[unCount];
			*puiChNum = stxResources.paxDectEndPts[unCount].unChannelNum;
			stxResources.paxDectEndPts[unCount].bIsFree = IFX_FALSE;
			#ifdef CVOIP_SUPPORT
			 iNumOfPcmAlloted ++;
			#endif
			break;
		}
	}
	#ifdef DECT_SUPPORT
	if(unCount == stxResources.unNoOfDect)
	{
		return IFX_MMGR_FAIL;
	}
	#endif
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DeAllocDect
 *  Description       : Function is responsible de-allocating a dect channel. 
 *  Input Values      : **ppxDect -  pointer to pointer to 
 *                      x_IFX_MMGR_Dect_Channel
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_DeAllocDect(x_IFX_MMGR_Dect_Channel *pxDect)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	pxDect->bIsFree = IFX_TRUE;
	memset(&pxDect->xResCodecList,0,sizeof(x_IFX_MMGR_CodecList));
	pxDect->uiServiceFlag = 0;
	#ifdef CVOIP_SUPPORT
       iNumOfPcmAlloted --;
  #endif

	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DeAllocCoder
 *  Description       : Function is responsible allocating a coder resource. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ResourceContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_FreeResInfoGet(
						x_IFX_MMGR_ForkingResContext *pxResContext,
						x_IFX_MMGR_ResourceInfo **ppxResInfo
										  )
{
	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(unCount=0;unCount < IFX_MMGR_MAX_FORK_ENDPT; unCount++)
	{
		if(pxResContext->axResInfo[unCount].uxChannel.pxFxsResource == NULL)
		{
			
			*ppxResInfo = &pxResContext->axResInfo[unCount];
      printf("\n unCount = %d,Add of Free Resource = %p\n",unCount,*ppxResInfo);
			break;
		}
	}
	if(unCount == IFX_MMGR_MAX_FORK_ENDPT)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "No Free Res Info Slot Available");
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResInfoGet
 *  Description       : 
 *  Input Values      : 
 *                      
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResInfoGet(
							x_IFX_MMGR_ForkingResContext *pxResContext,
							x_IFX_MMGR_ResourceInfo *pxSearchResInfo,
							x_IFX_MMGR_ResourceInfo **ppxResInfo
								     )
{
	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(unCount=0;unCount < IFX_MMGR_MAX_FORK_ENDPT; unCount++)
	{
		if(pxResContext->axResInfo[unCount].uxChannel.pxFxsResource
						== pxSearchResInfo->uxChannel.pxFxsResource)
		{
			
			*ppxResInfo = &pxResContext->axResInfo[unCount];
			break;
		}
		else if (pxResContext->axResInfo[unCount].uxChannel.pxDectResource
								== pxSearchResInfo->uxChannel.pxDectResource)
		{
						*ppxResInfo = &pxResContext->axResInfo[unCount];
						break;
		}
	}
	if(unCount == IFX_MMGR_MAX_FORK_ENDPT)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Res Info Not Found");
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

/*******************************************************************
  *  Function Name    : IFX_MMGR_StoreCodecInfo
  *  Description      : This function adds the dect codec to the forking 
  *                      resource context.
  *  Input Values     : Num
  *  Output Values    : None
  *  Return Value     : ASCII Value of the input
  *  Notes            :
  *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_StoreCodecInfo(x_IFX_MMGR_ForkingResContext *pxResContext,
										  x_IFX_MMGR_ResourceInfo *pxResInfo,
										  x_IFX_MMGR_CodecList *pxCodec)
{
	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(unCount=0;unCount < IFX_MMGR_MAX_FORK_ENDPT; unCount++)
	{
		if (pxResContext->axResInfo[unCount].uxChannel.pxDectResource
								== pxResInfo->uxChannel.pxDectResource && pxCodec != NULL)
		{
			pxResContext->apxDectCodecList[unCount] = 
				IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
			memcpy(pxResContext->apxDectCodecList[unCount],pxCodec,
					sizeof(x_IFX_MMGR_CodecList));
			break;
		}
	}
	if(unCount == IFX_MMGR_MAX_FORK_ENDPT)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Res Info Not Found");
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*******************************************************************
  *  Function Name    : IFX_MMGR_FreeCodecInfo
  *  Description      : This frees the dect codec from the forking 
  *                      resource context.
  *  Input Values     : Num
  *  Output Values    : None
  *  Return Value     : ASCII Value of the input
  *  Notes            :
  *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_FreeCodecInfo(
						x_IFX_MMGR_ForkingResContext *pxResContext,
						x_IFX_MMGR_ResourceInfo *pxResInfo
										  )
{
	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(unCount=0;unCount < IFX_MMGR_MAX_FORK_ENDPT; unCount++)
	{
		if (pxResContext->axResInfo[unCount].uxChannel.pxDectResource
								== pxResInfo->uxChannel.pxDectResource)
		{
			if (pxResContext->apxDectCodecList[unCount]){
				IFX_OS_Free(pxResContext->apxDectCodecList[unCount]);
				pxResContext->apxDectCodecList[unCount] = 0;
			}
			break;
		}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}


int32 IFX_MMGR_GenerateresourceId()
{
	return stiResourceId++;
}
/*******************************************************************
  *  Function Name    : IFX_MMGR_GetAsciiVal
  *  Description      : This API starts computes the ASCII value.
  *  Input Values     : Num
  *  Output Values    : None
  *  Return Value     : ASCII Value of the input
  *  Notes            :
  *********************************************************************/
STATIC uchar8 IFX_MMGR_GetAsciiVal(uchar8 ucNum)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
      switch(ucNum)
      {
        case 10:
            return  '*';
        case 11:
            return '0';
        case 12:
            return  '#';
        default:
            return ucNum + '0';
      }
}
/*******************************************************************
  *  Function Name    : IFX_MMGR_GetDtmfIndex
  *  Description      : This API starts computes the ASCII value.
  *  Input Values     : Num
  *  Output Values    : None
  *  Return Value     : ASCII Value of the input
  *  Notes            :
  *********************************************************************/
STATIC uchar8 IFX_MMGR_GetDtmfIndex(uchar8 ucNum)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
      switch(ucNum)
      {
        case '*':
            return  10;
        case '0':
            return 11;
        case '#':
            return  12;
        default:
            return ucNum - '0';
			}

}

/*****************************************************************************
 *  Function Name     : IFX_MMGR_SearchEndptResource
 *  Description       : Function is responsible allocating a coder resource. 
 *  Input Values      : **ppxResContext -  pointer to pointer to 
 *                      x_IFX_MMGR_ResourceContext
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
/* This fuction is used to search the endpt Resource */
e_IFX_MMGR_Return IFX_MMGR_SearchEndptResource(char8* pszEndPtId,
									IN_OUT x_IFX_MMGR_ResourceInfo *pxResInfo)
{
//	x_IFX_MMGR_ResourceInfo *pxResInfo;
	uint16 nCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);

	//UGW_SW-3020 issue:Fix:Added below line
	pxResInfo->eResType = IFX_MMGR_NONE;
	/* Search in the Fxs endpt pool */
	for(nCount=0; nCount < stxResources.unNoOfFxs; nCount++)
	{
		pxResInfo->uxChannel.pxFxsResource = &stxResources.paxFxsEndPts[nCount];
		if(!strcmp(pszEndPtId,pxResInfo->uxChannel.pxFxsResource->szEndPtId))
		{
			pxResInfo->eResType	= IFX_MMGR_FXS_RESOURCE;
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			"Res found for FXS EpId ",pszEndPtId);
			return IFX_MMGR_SUCCESS;
		}
	}
	/* Search in the Fxo endpt pool */
	for(nCount=0; nCount < stxResources.unNoOfFxo; nCount++)
	{
		pxResInfo->uxChannel.pxFxoResource = &stxResources.paxFxoEndPts[nCount];
		if(!strcmp(pszEndPtId,pxResInfo->uxChannel.pxFxoResource->szEndPtId))
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			"Res found for FXO EpId ",pszEndPtId);
			pxResInfo->eResType	= IFX_MMGR_FXO_RESOURCE;
			return IFX_MMGR_SUCCESS;
		}
	}
	/* Search in the Dect endpt pool */
	for(nCount=0; nCount < stxResources.unNoOfDect; nCount++)
	{
		pxResInfo->uxChannel.pxDectResource = 
			        &stxResources.paxDectEndPts[nCount];
    /*printf("\n Count=%d,pxResInfo->uxChannel.pxDectResource->szEndPtId = %s\n",nCount,
           (pxResInfo->uxChannel.pxDectResource->szEndPtId[0] != '\0')?
           pxResInfo->uxChannel.pxDectResource->szEndPtId:"NULL");*/
		if(!strcmp(pszEndPtId,pxResInfo->uxChannel.pxDectResource->szEndPtId))
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
			"Res found for DECT EpId ",pszEndPtId);
			pxResInfo->eResType = IFX_MMGR_DECT_RESOURCE;
			return IFX_MMGR_SUCCESS;
		}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Failed");
	return IFX_MMGR_FAIL;
}
/* This function has to be modified */
uint32 IFX_MMGR_GenerateSSRC(void)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	  return IFX_MD5_GetRandomValue();	
}
uint16 IFX_MMGR_GenerateSeqNum(void)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
		uint32 uiSeq = 0;
		uiSeq =  1 + (int) (65535.0 * (rand() / (RAND_MAX + 1.0)));
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
		return uiSeq;
    // return 1; Chaitanya - To ensure that the SEQ number is random
}

/*****************************************************************************
 *  Function Name     : IFX_MMGR_ComputeCpuUsage
 *  Description       : Function computes the cpu usage for a type of Resource 
 *  Input Values      : pxResInfo -  pointer to resource info
 *						
 *  Output Values     : pucCpuUsage
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ComputeCpuUsage(x_IFX_MMGR_ResourceInfo *pxResInfo,
										   x_IFX_MMGR_CodecList *pxCodecList,
										   OUT uchar8 *pucCpuUsage
										   )
{
	x_IFX_LM_Resource xLMRes;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);

	switch(pxResInfo->eResType)
	{
	case IFX_MMGR_FXS_RESOURCE:
		if(pxResInfo->uxChannel.pxFxsResource->bIsLecEnabled)
		{
			if(pxResInfo->uxChannel.pxFxsResource->ucLecTailLength 
									== IFX_MMGR_LEC_TAIL_LEN_8)
			{
				xLMRes.eResourceType = IFX_LM_RES_FXS_NB_LEC_8;
			}
			else 
			{
				xLMRes.eResourceType = IFX_LM_RES_FXS_NB_LEC_16;
			}
			if(IFX_LM_LoadCompute(&xLMRes,pucCpuUsage) !=
													IFX_LM_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Load Compute Failed");
				return IFX_MMGR_FAIL;
			}
		}
		break;
	case IFX_MMGR_FXO_RESOURCE:
		if(pxResInfo->uxChannel.pxFxoResource->bIsLecEnabled)
		{
			if(pxResInfo->uxChannel.pxFxoResource->ucLecTailLength 
									== IFX_MMGR_LEC_TAIL_LEN_8)
			{
				xLMRes.eResourceType = IFX_LM_RES_FXS_NB_LEC_8;
			}
			else 
			{
				xLMRes.eResourceType = IFX_LM_RES_FXS_NB_LEC_16;
			}
			if(IFX_LM_LoadCompute(&xLMRes,pucCpuUsage) !=
													IFX_LM_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Load Compute Failed");
				return IFX_MMGR_FAIL;
			}
		}
		break;
	case IFX_MMGR_DECT_RESOURCE:
		*pucCpuUsage = 0;
		//return IFX_MMGR_SUCCESS;
		break;
	default:
	     ;
	//	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
    //              __FUNCTION__,"Failure");
	//	return IFX_MMGR_FAIL;
	}
	if(pxCodecList)
	{
			xLMRes.eResourceType = IFX_LM_RES_CODEC;
			memcpy(&xLMRes.xCodecList,
	    		   pxCodecList,
			   		sizeof(x_IFX_MMGR_CodecList));
			if(IFX_LM_LoadCompute(&xLMRes,pucCpuUsage) !=
													IFX_LM_SUCCESS)
			{
					return IFX_MMGR_SUCCESS;
			}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_SigResAlloc
 *  Description       : Function is responsible for allocating a signalling 
 *						resource to a FXS/FXO endpt
 *  Input Values      : pszendPtId -  endpt Id
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_SigResAlloc(char* pszEndPtId,void *ptr)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
	e_IFX_MMGR_Return eRetVal;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Invalid EndPt Id");
		return IFX_MMGR_FAIL;
	}
	if(xResInfo.eResType == IFX_MMGR_FXS_RESOURCE)
	{
		eRetVal = IFX_MMGR_AllocateSigResourceForFxs(
								xResInfo.uxChannel.pxFxsResource);
		if(eRetVal != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Error allocating Sig Resource");
		}
		/* Enable Tone detection */    
		return eRetVal;
	}
	else if(xResInfo.eResType == IFX_MMGR_FXO_RESOURCE)
	{
		eRetVal = IFX_MMGR_AllocateSigResourceForFxo(
								xResInfo.uxChannel.pxFxoResource);
		if(eRetVal != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Error allocating Sig Resource");
		}
		return eRetVal;
	}
	else
	{
		IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,__LINE__,__FUNCTION__,"Failure");
		return IFX_MMGR_INVALID_PARAMETER;
	}
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_AllocateSigResourceForFxs
 *  Description       : Function is responsible for allocating a signalling 
 *						resource to a FXS endpt
 *  Input Values      : pxFxs -  fxs channel info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_AllocateSigResourceForFxs(x_IFX_MMGR_Fxs_Channel *pxFxs)
{
	//uint16 nCount;
	x_IFX_MMGR_Data_Channel *pxDC;
    x_IFX_LM_Resource xSigRes;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(pxFxs->uiServiceFlag & IFX_MMGR_SIG_CH_ALLOCATED)
	{
		pxDC = (x_IFX_MMGR_Data_Channel *)pxFxs->pxDC[0];
		return IFX_MMGR_SUCCESS;
	}
	/* The resource is of FXS type, so allocate a signalling channel o it */
	/* Search for a free sig channel */
	if(IFX_MMGR_AllocateCoder(&pxDC,1) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Alloc Data Channel Failed");
		return IFX_MMGR_NO_RESOURCE;
	}				
	memset(&xSigRes,0,sizeof(xSigRes));
	/* Reserve the load for a signalling channel by calling Load manager api */
	xSigRes.eResourceType = IFX_LM_RES_FXS_SIG_CHANNEL;
	if(IFX_LM_LoadReserve(&xSigRes,NULL) != IFX_LM_SUCCESS)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Load Reserve Failed");
		IFX_MMGR_DeAllocCoder(pxDC);
		return IFX_MMGR_FAIL;
    }
	/* Add the data channel to the FXS channel */
	if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxDC->iFd,pxFxs->unChannelNum)
														!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Adding data Channel to Analog Failed");
		IFX_MMGR_DeAllocCoder(pxDC);
		return IFX_MMGR_FAIL;
	}
    pxDC->eDestResType = IFX_MMGR_FXS_RESOURCE;
    pxDC->uxDestResource.pxFxs = pxFxs;
	pxFxs->pxDC[0] = (struct x_IFX_MMGR_Data_Channel*)pxDC;
	pxFxs->uiServiceFlag |= IFX_MMGR_SIG_CH_ALLOCATED;
	pxDC->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_AllocateSigResourceForFxo
 *  Description       : Function is responsible for allocating a signalling 
 *						resource to a FXO endpt
 *  Input Values      : pxFxo -  fxo channel info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_AllocateSigResourceForFxo(
										x_IFX_MMGR_Fxo_Channel *pxFxo)
{
	uint16 nCount;
	x_IFX_MMGR_Data_Channel *pxDC=NULL;
    x_IFX_LM_Resource xSigRes ;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xSigRes,0,sizeof(x_IFX_LM_Resource));
	if(pxFxo->uiServiceFlag & IFX_MMGR_SIG_CH_ALLOCATED)
	{
		return IFX_MMGR_SUCCESS;
	}
	/* The resource is of FXS type, so allocate a signalling channel o it */
	/* Search for a free sig channel */
	for(nCount=0; nCount<stxResources.unNoOfCoders; nCount++)
	{
		pxDC = &stxResources.paxCoders[nCount];
		if(pxDC->bIsCoderFree)
			break;
	}
	if(nCount == stxResources.unNoOfCoders)
		/* There is no signalling channel available so return a failure */
		return IFX_MMGR_NO_RESOURCE;
	/* Reserve the load for a signalling channel by calling Load manager api */
	xSigRes.eResourceType = IFX_LM_RES_FXO_SIG_CHANNEL;
	if(IFX_LM_LoadReserve(&xSigRes,NULL) < 0)
		return IFX_MMGR_FAIL;
#ifndef SLIC121
	if(IFX_MMGR_TAPI_AddDataChannelToPcm(pxDC->iFd,pxFxo->unPcmChannelNum)
														!= IFX_MMGR_SUCCESS)
#else
	/* Add the data channel to the Analog channel */
  if(IFX_MMGR_SUCCESS != IFX_MMGR_TAPI_AddDataChannelToAnalog(pxDC->iFd,pxFxo->unChannelNum))
#endif
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Adding data Channel to Pcm/ALM Failed");
		return IFX_MMGR_FAIL;
	}
	pxFxo->pxDC = (struct x_IFX_MMGR_Data_Channel*)pxDC;
    pxDC->eDestResType = IFX_MMGR_FXO_RESOURCE;
    pxDC->uxDestResource.pxFxo = pxFxo;
	pxFxo->uiServiceFlag |= IFX_MMGR_SIG_CH_ALLOCATED;
	pxDC->bIsCoderFree = IFX_FALSE;
	pxDC->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_SigResDealloc
 *  Description       : Function is responsible for de-allocating a signalling 
 *						resource .
 *  Input Values      : pszEndPtId -  endpt id
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_SigResDealloc(char8 *pszEndPtId)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
		if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Invalid Endpt Id");
			return IFX_MMGR_FAIL;
		}
		if(xResInfo.eResType == IFX_MMGR_FXS_RESOURCE)
		{
			IFX_MMGR_DeAllocateSigResourceForFxs(xResInfo.uxChannel.pxFxsResource);
		}
		else if(xResInfo.eResType == IFX_MMGR_FXO_RESOURCE)
		{
			IFX_MMGR_DeAllocateSigResourceForFxo(xResInfo.uxChannel.pxFxoResource);
		}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

/*****************************************************************************
 *  Function Name     : IFX_MMGR_DeAllocateSigResourceForFxs
 *  Description       : Function is responsible for de-allocating a signalling 
 *						resource to a FXS endpt
 *  Input Values      : pxFxs -  fxs channel info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return 
IFX_MMGR_DeAllocateFXSDataChannel (x_IFX_MMGR_Data_Channel *pxDC,
																	 x_IFX_MMGR_Fxs_Channel *pxFxs)
{

	printf("<FreeFxsData> Entry\n");
  if( IFX_MMGR_SigDetect(pxDC->iFd,0) != IFX_MMGR_SUCCESS) {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "failed");
		return IFX_MMGR_NO_RESOURCE;
	}
	/*END*/

		pxDC->uiServiceFlag &= ~IFX_MMGR_RES_USED_AS_SIG;
	if((pxDC->uiServiceFlag & IFX_MMGR_RES_USED_AS_CODER) == 0)
	{
		/* Remove the data channel to the FXS channel */
        if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxDC->iFd,pxFxs->unChannelNum)
															!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Removing Data channel from Analog Failed");
			return IFX_MMGR_FAIL;
		}
    	pxDC->eDestResType = IFX_MMGR_NONE;
    	pxDC->uxDestResource.pxFxs = NULL;
		pxDC->bIsCoderFree = IFX_TRUE;
		pxDC->bIsFxs = 0;
	}
	pxFxs->uiServiceFlag &= ~IFX_MMGR_SIG_CH_ALLOCATED;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");

	return IFX_SUCCESS;
}

/*****************************************************************************
 *  Function Name     : IFX_MMGR_DeAllocateSigResourceForFxs
 *  Description       : Function is responsible for de-allocating a signalling 
 *						resource to a FXS endpt
 *  Input Values      : pxFxs -  fxs channel info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_DeAllocateSigResourceForFxs(
										x_IFX_MMGR_Fxs_Channel *pxFxs)
{
	x_IFX_LM_Resource xSigRes;
  x_IFX_MMGR_Data_Channel *pxDC;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(!( pxFxs->uiServiceFlag & IFX_MMGR_SIG_CH_ALLOCATED))
	{
			return IFX_MMGR_SUCCESS;
	}
	memset(&xSigRes,0,sizeof(x_IFX_LM_Resource));
	/* Free the load for a signalling channel by calling Load manager api */
	xSigRes.eResourceType = IFX_LM_RES_FXS_SIG_CHANNEL;
	if(IFX_LM_LoadFree(&xSigRes) < 0){
		return IFX_MMGR_FAIL;
	}
    pxDC = (x_IFX_MMGR_Data_Channel*)pxFxs->pxDC[0];
#if 1 // Chintan
	/*COC -Power savings changes STARTn */
  if( IFX_MMGR_SigDetect(pxDC->iFd,0) != IFX_MMGR_SUCCESS) {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "failed");
		return IFX_MMGR_NO_RESOURCE;
	}
	/*END*/

		pxDC->uiServiceFlag &= ~IFX_MMGR_RES_USED_AS_SIG;
	if((pxDC->uiServiceFlag & IFX_MMGR_RES_USED_AS_CODER) == 0)
	{
		/* Remove the data channel to the FXS channel */
        if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxDC->iFd,pxFxs->unChannelNum)
															!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Removing Data channel from Analog Failed");
			return IFX_MMGR_FAIL;
		}
    	pxDC->eDestResType = IFX_MMGR_NONE;
    	pxDC->uxDestResource.pxFxs = NULL;
		pxDC->bIsCoderFree = IFX_TRUE;
		pxDC->bIsFxs = 0;
		pxFxs->pxDC[0] = NULL;
	}
	pxFxs->uiServiceFlag &= ~IFX_MMGR_SIG_CH_ALLOCATED;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
#endif
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DeAllocateSigResourceForFxo
 *  Description       : Function is responsible for de-allocating a signalling 
 *						resource to a FXO endpt
 *  Input Values      : pxFxo -  fxo channel info
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_DeAllocateSigResourceForFxo(
											x_IFX_MMGR_Fxo_Channel *pxFxo)
{
	x_IFX_LM_Resource xSigRes;
    x_IFX_MMGR_Data_Channel *pxDC;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	/* Free the load for a signalling channel by calling Load manager api */
	if(!( pxFxo->uiServiceFlag & IFX_MMGR_SIG_CH_ALLOCATED))
	{
			return IFX_MMGR_SUCCESS;
	}
	memset(&xSigRes,0,sizeof(x_IFX_LM_Resource));
	xSigRes.eResourceType = IFX_LM_RES_FXO_SIG_CHANNEL;
	if(IFX_LM_LoadFree(&xSigRes) < 0)
		return IFX_MMGR_FAIL;
	pxDC = (x_IFX_MMGR_Data_Channel*)pxFxo->pxDC;
	pxDC->uiServiceFlag &= ~IFX_MMGR_RES_USED_AS_SIG;
	if((pxDC->uiServiceFlag & IFX_MMGR_RES_USED_AS_CODER) == 0)
	{
#ifndef SLIC121
		if(IFX_MMGR_TAPI_RemoveDataChannelFromPcm(pxDC->iFd,pxFxo->unChannelNum)
															!= IFX_MMGR_SUCCESS)
#else
		/* Remove the data channel from the Analog channel */
    if( IFX_MMGR_SUCCESS != IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxDC->iFd,pxFxo->unChannelNum))
#endif
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Removing Data channel from Pcm/Analog Failed");
		}
        pxDC->eDestResType = IFX_MMGR_NONE;
        pxDC->uxDestResource.pxFxo = NULL;
		pxDC->bIsCoderFree = IFX_TRUE;
		pxFxo->pxDC = NULL;
	}
	pxFxo->uiServiceFlag &= ~IFX_MMGR_SIG_CH_ALLOCATED;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DectResAlloc
 *  Description       : Function is responsible for allocating a DECT 
 *						resource .
 *  Input Values      : pszendPtId -  endpt Id
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_DectResAlloc(IN char* pszEndPtId ,
	   									OUT uint16 *puiChNum ,
										IN_OUT x_IFX_MMGR_CodecList *pxCodec
										)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
	x_IFX_MMGR_Dect_Channel *pxDect;
#ifdef DECT_SUPPORT
	x_IFX_MMGR_CodecInfo xCodecInfo;
    x_IFX_LM_Resource xCodecRes;
	memset(&xCodecRes,0,sizeof(xCodecRes));
#endif
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) == IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                     "End pt Id  Found");
		*puiChNum = xResInfo.uxChannel.pxDectResource->unChannelNum;
		return IFX_MMGR_SUCCESS;
    }
    if(IFX_MMGR_AllocDect(&pxDect,puiChNum) != IFX_MMGR_SUCCESS)
	{
		return IFX_MMGR_FAIL;
	}	
#ifdef DECT_SUPPORT
	if(pxCodec)
	{
		memcpy(&xCodecRes.xCodecList,pxCodec,sizeof(x_IFX_MMGR_CodecList));
		xCodecRes.eResourceType = IFX_LM_RES_CODEC;
		if(IFX_LM_LoadReserve(&xCodecRes,NULL) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "LoadReserve Failed for Dect Codecs");
			IFX_MMGR_DeAllocDect(pxDect);
			return IFX_MMGR_FAIL;

		}

		memcpy(pxCodec,&xCodecRes.xCodecList,sizeof(x_IFX_MMGR_CodecList));
		memcpy(&pxDect->xReqCodecList,pxCodec,sizeof(x_IFX_MMGR_CodecList));
		memcpy(&pxDect->xResCodecList,pxCodec,sizeof(x_IFX_MMGR_CodecList)); /* narendra - redundant statement */
	}
    /* Configure the KPI channel corresponding to this dect channel */	
	if(IFX_MMGR_TAPI_KpiCfg(pxDect->iFd,*puiChNum) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "Kpi Configuration Failed");
		return IFX_MMGR_FAIL;
	}
	memset(&xCodecInfo,0,sizeof(x_IFX_MMGR_CodecInfo)); /* narendra - redundant statement */
	if(IFX_MMGR_TAPI_DectChCfg(pxDect->iFd) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Dect Channel Configuration Failed");
		pxDect->bIsFree = IFX_TRUE;
		return IFX_MMGR_FAIL;
	}
#endif
	strcpy(pxDect->szEndPtId,pszEndPtId);
	pxDect->uiServiceFlag |= IFX_MMGR_DECT_SIG;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DectResDealloc
 *  Description       : Function is responsible for allocating a DECT 
 *						resource .
 *  Input Values      : pszendPtId -  endpt Id
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_DectResDealloc(IN char8* pszEndPtId)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
    x_IFX_LM_Resource xCodecRes;
	x_IFX_MMGR_Dect_Channel *pxDect;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xCodecRes,0,sizeof(xCodecRes));
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "End pt  Not Id  Found");
		return IFX_MMGR_FAIL;
	}
	pxDect = xResInfo.uxChannel.pxDectResource;

	if(!(pxDect->uiServiceFlag & IFX_MMGR_DECT_IN_CALL) )
	{
		memcpy(&xCodecRes.xCodecList,&pxDect->xResCodecList,sizeof(x_IFX_MMGR_CodecList));
		xCodecRes.eResourceType = IFX_LM_RES_CODEC;
		IFX_LM_LoadFree(&xCodecRes);
		pxDect->bIsFree = IFX_TRUE;
		pxDect->szEndPtId[0] = '\0';
		memset(&pxDect->xResCodecList,
				0,sizeof(x_IFX_MMGR_CodecList));
	}
	xResInfo.uxChannel.pxDectResource->uiServiceFlag &= ~IFX_MMGR_DECT_SIG;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_FreeDectCh(x_IFX_MMGR_Dect_Channel *pxDect)
{
	x_IFX_LM_Resource xCodecRes;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	pxDect->ucNoOfCalls--;//ASK?????
	if(pxDect->ucNoOfCalls == 0)
	{
		pxDect->uiServiceFlag &= ~IFX_MMGR_DECT_IN_CALL;
		if(!(pxDect->uiServiceFlag & IFX_MMGR_DECT_SIG))
		{
			pxDect->szEndPtId[0] = '\0';
			memcpy(&xCodecRes,&pxDect->xResCodecList,sizeof(x_IFX_MMGR_CodecList));
			xCodecRes.eResourceType = IFX_LM_RES_CODEC;
			IFX_LM_LoadFree(&xCodecRes);
			pxDect->bIsFree = IFX_TRUE;
			pxDect->uiServiceFlag = 0;
		}
	}
/*	if(pxDect->ucNoOfCalls < 0)
	{
		pxDect->ucNoOfCalls = 0;
	}*/
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DectResActivate
 *  Description       : Function is responsible for configuring a dect channel 
 *                      with a coder and activating it 
 *  Input Values      : pszendPtId -  endpt Id
 *                      pxCodec - pointer to the codec.
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_DectResActivate(IN char* pszEndPtId ,
										   IN x_IFX_MMGR_CodecInfo *pxCodec,
										   IN boolean bECOn)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "End pt Id not Found");
		return IFX_MMGR_FAIL;
	}
	if(xResInfo.uxChannel.pxDectResource->uiServiceFlag & IFX_MMGR_DECT_ACTIVE)
	{
					//printf("Dect Resource already activated\n");
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Dect Resource already activated");
					return IFX_MMGR_SUCCESS;
	}
#ifdef DECT_SUPPORT
	if(IFX_MMGR_TAPI_DectChCfg(xResInfo.uxChannel.pxDectResource->iFd) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Dect Channel Configuration Failed");
		return IFX_MMGR_FAIL;
	}
	if(IFX_MMGR_TAPI_DectEncSet(xResInfo.uxChannel.pxDectResource->iFd,pxCodec)
		   						!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Dect Enc Set Failed");
		return IFX_MMGR_FAIL;
	}
	if(IFX_MMGR_TAPI_DectActivate(xResInfo.uxChannel.pxDectResource->iFd) 
								!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Dect Activation Set Failed");
		return IFX_MMGR_FAIL;
	}
	/*Echo Suppression*/
	if(bECOn){
		printf("Turning on Echo Suppression\n");
		if(IFX_MMGR_TAPI_DectECConfigure(xResInfo.uxChannel.pxDectResource->iFd,1)!= IFX_MMGR_SUCCESS)
		{
		printf("Turning on Echo Suppression failed\n");
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              		     "Configuring the Echo suppression on  for dect Failed");
		}
	}
/* Echo suppression End*/
	xResInfo.uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_ACTIVE;
#endif

#ifdef CVOIP_SUPPORT
	/*		if(IFX_MMGR_CODEC_G722_64==*pxCodec){
					xPcmConfig[xResInfo.uxChannel.pxDectResource->unChannelNum].ePcmCodec = 
																		IFX_MMGR_CODEC_PCM_G722_64;
			}
			else if (IFX_MMGR_CODEC_G726_32){
				xPcmConfig[xResInfo.uxChannel.pxDectResource->unChannelNum].ePcmCodec =
																					IFX_MMGR_CODEC_PCM_G726_32;
			}*/
			printf("MMGR-CV Dect Resfd id %d,Endptid:%s\n",xResInfo.uxChannel.pxDectResource->iFd,pszEndPtId);
if(IFX_MMGR_TAPI_PcmChannelConfig(xResInfo.uxChannel.pxDectResource->iFd,
              (int32)vaucPcmChannelNo[atoi(pszEndPtId)-1],IFX_MMGR_TRUE) != IFX_MMGR_SUCCESS)
      {
        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                          "Configuring the PCM Channel  Failed for Dect ");
        return IFX_MMGR_FAIL;
      }

	xResInfo.uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_ACTIVE;
#endif
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_DectResDeActivate
 *  Description       : Function is responsible for de-activating a dect channel 
 *  Input Values      : pszendPtId -  endpt Id
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_DectResDeActivate(IN char* pszEndPtId 
										   	)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "End pt Id not Found");
		return IFX_MMGR_FAIL;
	}
	if(!(xResInfo.uxChannel.pxDectResource->uiServiceFlag & IFX_MMGR_DECT_ACTIVE))
	{
					return IFX_MMGR_SUCCESS;
	}
#ifdef DECT_SUPPORT
	/*Echo Suppression*/
	if(IFX_MMGR_TAPI_DectECConfigure(xResInfo.uxChannel.pxDectResource->iFd,0)!= IFX_MMGR_SUCCESS)
	{
		printf("Turning off Echo Suppression failed\n");
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              		     "Configuring the Echo suppression Off for dect Failed");
	}
/* Echo suppression End*/
	xResInfo.uxChannel.pxDectResource->uiServiceFlag &= ~IFX_MMGR_DECT_ACTIVE;
	if(IFX_MMGR_TAPI_DectDeActivate(xResInfo.uxChannel.pxDectResource->iFd) 
								!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Dect Activation Set Failed");
		return IFX_MMGR_FAIL;
	}
#endif
#ifdef CVOIP_SUPPORT 
		printf("aaaaaEndptid is %s",pszEndPtId);
if(IFX_MMGR_TAPI_PcmChannelConfig(xResInfo.uxChannel.pxDectResource->iFd,
              (int32)vaucPcmChannelNo[atoi(pszEndPtId)-1],IFX_MMGR_FALSE) != IFX_MMGR_SUCCESS)
      {
        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                          "Configuring the PCM Channel  Failed for Dect PCM");
        return IFX_MMGR_FAIL;
      }
	xResInfo.uxChannel.pxDectResource->uiServiceFlag &= ~IFX_MMGR_DECT_ACTIVE;
#endif
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_SetFxoHook
 *  Description       : Function is responsible for setting the fxo line to  
 *						off hook
 *  Input Values      : pszendPtId -  endpt Id
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_SetFxoHook(char8* pszEndPtId,uint32 uiHookMode)
{
    x_IFX_MMGR_ResourceInfo xResInfo;
    int32 iFd;
	#ifndef SLIC121
		boolean bAct= IFX_MMGR_FALSE;
	#endif
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    if(pszEndPtId == NULL)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "EndPt Id is Null");
        return IFX_MMGR_INVALID_PARAMETER;
    }
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "EndPt Id not Found");
		return IFX_MMGR_FAIL;
	}
    if(xResInfo.eResType == IFX_MMGR_FXO_RESOURCE)
    {
        iFd = IFX_MMGR_GetFd(pszEndPtId);
        if(iFd < 0)
        {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Invalid Fd");
        }
        if(IFX_MMGR_TAPI_SetHookMode(iFd,uiHookMode) != IFX_MMGR_SUCCESS)
        {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Set HookMode Failed");
            return IFX_MMGR_FAIL;
        }

			if(uiHookMode == IFX_MMGR_FXO_ONHOOK)
			{
						#ifndef SLIC121
							bAct = IFX_MMGR_FALSE;
						#endif
			}
			else if(uiHookMode == IFX_MMGR_FXO_OFFHOOK)
			{
						#ifndef SLIC121
							bAct = IFX_MMGR_TRUE;
						#endif
			}
#ifndef SLIC121
			if(IFX_MMGR_TAPI_PcmChannelConfig(xResInfo.uxChannel.pxFxoResource->iPcmFd,
							xResInfo.uxChannel.pxFxoResource->iFd,bAct) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
       	                  "Configuring the PCM Channel  Failed");
				return IFX_MMGR_FAIL;
			}
#endif
    }
    else
    {
        return IFX_MMGR_FAIL;
    }
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_SetOffHook
 *  Description       : Function is responsible for setting the fxo line to  
 *						off hook
 *  Input Values      : pszendPtId -  endpt Id
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_OffHookSet(char8* pszEndPtId)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    if(pszEndPtId == NULL)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Endpt Id is Null");
        return IFX_MMGR_INVALID_PARAMETER;
    }
    if( IFX_MMGR_SetFxoHook(pszEndPtId,IFX_MMGR_FXO_OFFHOOK) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Set Fxo Off Hook Failed");
			return IFX_MMGR_FAIL;
		}
#if 0
		if(IFX_MMGR_TAPI_PcmChannelConfig(pxFxoChannel->iPcmFd,
							pxFxoChannel->iFd,1) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Configuring the PCM Channel  Failed");
			return IFX_MMGR_FAIL;
		}
#endif
		return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_OnHookSet
 *  Description       : Function is responsible for setting the fxo line to  
 *						on hook
 *  Input Values      : pszendPtId -  endpt Id
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_OnHookSet(char8* pszEndPtId)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    if(pszEndPtId == NULL)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Endpt Id is Null");
        return IFX_MMGR_INVALID_PARAMETER;
    }
    if(IFX_MMGR_SetFxoHook(pszEndPtId,IFX_MMGR_FXO_ONHOOK) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Set Fxo On Hook Failed");
			return IFX_MMGR_FAIL;
		}
#if 0
		if(IFX_MMGR_TAPI_PcmChannelConfig(pxFxoChannel->iPcmFd,
							pxFxoChannel->iFd,0) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                         "Configuring the PCM Channel  Failed");
			return IFX_MMGR_FAIL;
		}
#endif
		return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_SetHookFlash
 *  Description       : Function is responsible for setting the fxo line to  
 *						on hook
 *  Input Values      : pszendPtId -  endpt Id
 *  Output Values     : None
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_HookFlashSet(char8* pszEndPtId)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    if(pszEndPtId == NULL)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Endpt Id is Null");
        return IFX_MMGR_INVALID_PARAMETER;
    }
    return IFX_MMGR_SetFxoHook(pszEndPtId,IFX_MMGR_FXO_HOOKFLASH);
}
    
/*! 
    \brief         This function sends out a FSK data on a FXS channel.
	               A siganlling resource should already be available
				   with the endpt before calling this function. 
	\param[in]     pszEndptId - identifier of the endpoint.
	\param[in]     pucData - Pointer to FSK data
	\param[in]     iDataSize - Size of the FSK data
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_FSKDataSnd(
							 IN char8* pszEndPtId,
							 IN uchar8* pucData,
							 IN int32 iDataSize
							 )
{
	int32 iFd;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	iFd = IFX_MMGR_GetSigFd(pszEndPtId);
    if(iFd < 0)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Invalid Fd");
    }
#if 0
    if(IFX_MMGR_TAPI_FSKDataSnd(iFd,uiHookMode,pucData,iDataSize) != IFX_MMGR_SUCCESS)
    {
        printf("Error sending the FSK data \n");
        return IFX_MMGR_FAIL;
    }
#endif
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*! 
    \brief         This function gets a FSK data which was received on a FXO channel.
				   A siganlling resource should already be available
				   with the endpt before calling this function. 
	\param[in]     pszEndptId - identifier of the endpoint.
	\param[in,out] pucData - Pointer to FSK data
	\param[in,out] iDataSize - Size of the FSK data
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_FSKDataRcv(
							 IN char8* pszEndPtId,
							 IN_OUT x_IFX_MMGR_FSK_Data *pxFskData
							 )
{
	int32 iFd;
	uchar8 acFskData[IFX_MMGR_FSK_BUF];
	int32 iLen;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	iFd = IFX_MMGR_GetSigFd(pszEndPtId);
    if(iFd < 0)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Invalid Fd");
    }
#if 1
    if(IFX_MMGR_TAPI_FSKDataRcv(iFd,acFskData,&iLen) != IFX_MMGR_SUCCESS)
    {
        printf("Error sending the FSK data \n");
        return IFX_MMGR_FAIL;
    }
#endif
		if(IFX_MMGR_FSK_DecodeFskData(acFskData,iLen,pxFskData) != IFX_MMGR_SUCCESS)
		{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Decode Fsk Failed");
				return IFX_MMGR_FAIL;
		}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
#if 0
/*! 
    \brief         This function starts a CID transmitter on a FXS endpt.
   	\param[in]     pszEndptId - identifier of the endpoint.
	\param[in]     pxCidparams - pointer to cid parameters
 	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no
				   signalling resource is
 					   already allocated or IFX_MMGR_FAIL
 */

e_IFX_MMGR_Return IFX_MMGR_CidTxStart(
							  IN char8* pszEndptId,
							  IN x_IFX_MMGR_CidParams *pxCidParams
							  )
{
	int32 iFd;
	iFd = IFX_MMGR_GetSigFd(pszEndptId);
	if(iFd < 0)
	{
		printf("Error in getting the Sig fd\n");
		return IFX_MMGR_FAIL;
	}

	return IFX_MMGR_TAPI_CidSend(iFd,pxCidParams->szCallerName,pxCidParams->szCallerNumber);
}
#endif

e_IFX_MMGR_Return IFX_MMGR_ResourceContextGet(int32 iResourceId ,
											  x_IFX_MMGR_ResourceContext **ppxResContext)
{
	uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	*ppxResContext = NULL;
	if(iResourceId == 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                     "Invalid Resource Id");
		return IFX_MMGR_FAIL;
	}
	for(unCount=0; unCount< IFX_MMGR_MAX_RESOURCE_CONTEXT ; unCount++)
	{
		if(staxResourceContext[unCount].iResourceId == iResourceId)
		{
			*ppxResContext = &staxResourceContext[unCount];
			break;
		}
	}
	if(unCount == IFX_MMGR_MAX_RESOURCE_CONTEXT)
	{
		IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Failure");
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

/*! 
    \brief         This function reserves all the resources required for a call 
                   to go through.This will be called by the Call manager during 
 				   setting up a call. Based on the inputs, this function will find out 
				   the type of resources required for the call and will reserve them 
				   if available. Also it will query the load manager whether the 
				   resource algorithm can be run and updates the load manager with 
				   the new value of CPU usage. In case of FXS-FXS internal call this 
				   function pre-allocates loads for running two LEC algorithms on both 
				   the FXS channels and in the case of FXS-VOIP call it will allocate 
				   a coder channel to the FXS channel if its not already allocated 
				   and updates the load manager with the new value of CPU usage.
				   The two codec list should be provided to be used on
				   the DECT and the Coder channel respectively, in case of DECT to 
				   VOIP call.
				   These list should be provided based on the type of call.
				   pxCodecList1 and pxCodecList2  has to passed as NULL for a FXS-FXS call
                   iAdditionalResourceId is should be non zero, for 
                   resuing a already allocated resource.It means 
                   the same resource can be identified with two 
                   different resourceIds.
				   It also returns the actual list of codecs that could be used for the call.
				   This function supports the forking feature for a VOIP/FXO incoming call.
				   To acheive this feature this function should be called multiple times
				   with the same resourceid.
				   
	\param[in,out] iResourceId - identifier of the resource context.
	\param[in,out] iAdditionalResourceId - additional identifier of the same resource context.
    \param[in]     bGenerateAddId - Flag to indicate that a additional resourceId has to be 
	               generated.
	\param[in]     pszFromId - Endpt Identifier of the initiating end.
	\param[in]     pszToId - Endpt Identifier of the terminating end.
	\param[in]     eCall - Type of call (VOIP/NON_VOIP)
	\param[in,out] paxCodecList1 - pointer to the codec list 1.
	\param[in,out] paxCodecList2 - pointer to the codec list 2.
	\return        IFX_MMGR_SUCCESS ,IFX_MMGR_FAIL,IFX_MMGR_NO_RESOURCE
*/
e_IFX_MMGR_Return IFX_MMGR_ResReserveForCall(
								   IN_OUT int32 *piResourceId,
							 	/* should be zero for non forking scenario */
								   OUT int32 *piAdditionalResourceId,
								   IN boolean bGenerateAddId,
								   IN_OUT char8* pszFromId,
								   IN char8* pszToId,
								   IN e_IFX_MMGR_TypeOfCall eCallType,
								   IN_OUT x_IFX_MMGR_CodecList *paxCodecList1,
								   IN_OUT x_IFX_MMGR_CodecList *paxCodecList2
								   )
{
	x_IFX_MMGR_ResourceInfo xResTo, xResFrom;
    x_IFX_MMGR_ResourceContext *pxResContext;
    x_IFX_MMGR_ResourceContext *pxNewResContext;
	x_IFX_LM_Resource xVoipRes;
	x_IFX_MMGR_CodecList *pxVoipCodec=NULL, *pxDectCodec = 0;
	uchar8 ucCpuUsage,ucOldCpuUsage;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
		
	if(IFX_MMGR_SearchEndptResource(pszFromId,&xResFrom) != IFX_MMGR_SUCCESS)
	{
	}
	if(IFX_MMGR_SearchEndptResource(pszToId,&xResTo) != IFX_MMGR_SUCCESS)
	{
	  	uint16 unCh;
    	if(eCallType == IFX_MMGR_CALL_VOIP_EXTN || 
					eCallType == IFX_MMGR_CALL_EXTN_EXTN || 
					eCallType == IFX_MMGR_CALL_FXO_EXTN) 
		{
			/* TBD Dect special Handling */
			if(IFX_MMGR_DectResAlloc(pszToId,&unCh,paxCodecList2) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                	     "Invalid Resource Id");
				return IFX_MMGR_FAIL;
			}
		}
	}
    if(eCallType == IFX_MMGR_CALL_VOIP_EXTN || 
			 eCallType == IFX_MMGR_CALL_EXTN_EXTN || 
			 eCallType == IFX_MMGR_CALL_FXO_EXTN)
		{
			if(IFX_MMGR_SearchEndptResource(pszToId,&xResTo) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                	     "Dect Channel allocation Failed");
				return IFX_MMGR_FAIL;
			}
		}
		 
  if(bGenerateAddId && *piResourceId)
	{
			
		if(IFX_MMGR_ResourceContextGet(*piResourceId,&pxResContext)
									 	!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               	     "Resource Context not Found");
			return IFX_MMGR_FAIL;
		}
		if(IFX_MMGR_AllocateResourceContext(&pxNewResContext) < 0)
		{
			return IFX_MMGR_MEMORY_ERROR;
		}
		memcpy(pxNewResContext,pxResContext,sizeof(x_IFX_MMGR_ResourceContext));
		if(eCallType == IFX_MMGR_CALL_EXTN_VOIP)
		{
			/* Re-Reserve the load for the extn */
			if(paxCodecList1 && paxCodecList1->ucNoOfCodecs)
			{
				pxDectCodec = paxCodecList1;
			}
			pxVoipCodec = paxCodecList2;
			if(!pxVoipCodec)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                	     "Voip Codecs is Null");
				IFX_MMGR_DeAllocateResourceContext(pxNewResContext);
				return IFX_MMGR_FAIL;
			}
			pxNewResContext->eTypeOfCall = IFX_MMGR_CALL_EXTN_VOIP;
			memcpy(&pxNewResContext->axResInfo[0],&xResFrom,sizeof(x_IFX_MMGR_ResourceInfo));
		}

		else if(eCallType == IFX_MMGR_CALL_VOIP_EXTN)
		{
			if(paxCodecList2 && paxCodecList2->ucNoOfCodecs)
			{
				pxDectCodec = paxCodecList2;
			}
			pxVoipCodec = paxCodecList1;
			if(!pxVoipCodec)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                	     "Voip Codecs is Null");
				IFX_MMGR_DeAllocateResourceContext(pxNewResContext);
				return IFX_MMGR_FAIL;
			}
			pxNewResContext->eTypeOfCall = IFX_MMGR_CALL_VOIP_EXTN;
			memcpy(&pxNewResContext->axResInfo[0],&xResFrom,sizeof(x_IFX_MMGR_ResourceInfo));
		}
		else if(eCallType  == IFX_MMGR_CALL_VOIP_FXO)
		{
			pxVoipCodec = paxCodecList1;
			if(!pxVoipCodec)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                	     "Voip Codecs is Null");
				IFX_MMGR_DeAllocateResourceContext(pxNewResContext);
				return IFX_MMGR_FAIL;
			}
			pxNewResContext->eTypeOfCall = IFX_MMGR_CALL_VOIP_FXO;
			memcpy(&pxNewResContext->axResInfo[0],&xResFrom,sizeof(x_IFX_MMGR_ResourceInfo));

		}
		else if(eCallType == IFX_MMGR_CALL_FXO_VOIP)
		{
			pxVoipCodec = paxCodecList2;
			if(!pxVoipCodec)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                	     "Voip Codecs is Null");
				IFX_MMGR_DeAllocateResourceContext(pxNewResContext);
				return IFX_MMGR_FAIL;
			}
			pxNewResContext->eTypeOfCall = IFX_MMGR_CALL_FXO_VOIP;
			memcpy(&pxNewResContext->axResInfo[0],&xResFrom,sizeof(x_IFX_MMGR_ResourceInfo));
		}
		if(pxVoipCodec)
			memcpy(&xVoipRes.xCodecList,pxVoipCodec,sizeof(x_IFX_MMGR_CodecList));
		xVoipRes.eResourceType = IFX_LM_RES_CODEC;
		if(IFX_LM_LoadCompute(&xVoipRes,&ucCpuUsage) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
            	     "Load compute failed");
		}
		memcpy(&xVoipRes.xCodecList,&pxResContext->pxCoder->xCodecList,sizeof(x_IFX_MMGR_CodecList));
		xVoipRes.eResourceType = IFX_LM_RES_CODEC;
		if(IFX_LM_LoadCompute(&xVoipRes,&ucOldCpuUsage) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
		{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               	     "Load compute failed");
		}
		if(ucCpuUsage > ucOldCpuUsage)
		{
			/* Free the load reserved earlier */
			//IFX_LM_LoadFree(&pxResContext->pxCoder->xCodecList);
			memcpy(&xVoipRes.xCodecList,&pxResContext->pxCoder->xCodecList,sizeof(x_IFX_MMGR_CodecList));
			xVoipRes.eResourceType = IFX_LM_RES_CODEC;
			IFX_LM_LoadFree(&xVoipRes);
			if(IFX_LM_LoadReserve(&xVoipRes,&ucCpuUsage) != IFX_LM_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		     "Load Reserve For Voip Failed");
				return IFX_MMGR_FAIL;
			}
			pxResContext->uiServiceFlag |= IFX_MMGR_LOAD_FREED;
			if(pxDectCodec && pxDectCodec->ucNoOfCodecs)
			{
				if(IFX_MMGR_LoadResDect(pxResContext->axResInfo[0].uxChannel.pxDectResource,
							            pxDectCodec) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   			 "Load Reserve For Dect Codecs Failed");
					return IFX_MMGR_FAIL;
				}
			}
		}
		else
		{
			pxNewResContext->uiServiceFlag |= IFX_MMGR_LOAD_FREED;
		}
		if(pxVoipCodec)
			memcpy(&pxNewResContext->pxCoder->xCodecList,pxVoipCodec,sizeof(x_IFX_MMGR_CodecList));
		pxNewResContext->iResourceId = *piAdditionalResourceId = IFX_MMGR_GenerateresourceId();
		pxNewResContext->pxAddResContext = (struct x_IFX_MMGR_ResourceContext*)pxResContext;
		pxNewResContext->eTypeOfCall = eCallType;
		pxResContext->pxAddResContext = (struct x_IFX_MMGR_ResourceContext*)pxNewResContext;
		return IFX_MMGR_SUCCESS;
	}
    if(pafnResReserveForCall[eCallType](piResourceId,&xResFrom,&xResTo,
				paxCodecList1,paxCodecList2) != IFX_MMGR_SUCCESS)
	{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               	     "Res Reserve For Call Failed");
			return IFX_MMGR_FAIL;
	}

	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*! 
    \brief         This function frees all the resources that was reserved for a call.
	               A resource is identified with the tuple(iResourseId,iFromId,iToId).
				   This function needs to be called while terminating a call.It actually deallocates 
				   the resources if required and frees the load usage for that particular resource.
  	\param[in]     iResourceId - identifier of the resource context.
	\param[in]     pszFromId - Endpt Identifier of the initiating end.
	\param[in]     pszToId - Endpt Identifier of the terminating end.
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_FAIL 
*/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForCall(
								IN int32 iResourceId,
								IN char8* pszFromId,
								IN char8* pszToId
								)
{
	x_IFX_MMGR_ResourceContext *pxResContext = NULL;
	x_IFX_MMGR_ForkingResContext *pxForkingResContext;
	x_IFX_MMGR_ResourceInfo xResFrom,xResTo;
	e_IFX_MMGR_TypeOfCall eTypeOfCall;
	x_IFX_LM_Resource xVoipRes;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_SearchEndptResource(pszFromId,&xResFrom) != IFX_MMGR_SUCCESS)
	{
	}
	if(IFX_MMGR_SearchEndptResource(pszToId,&xResTo) != IFX_MMGR_SUCCESS)
	{
	}
  /* Search the forking Resource Context first */
	if(IFX_MMGR_ForkingResContextGet(iResourceId,&pxForkingResContext)
											!= IFX_MMGR_SUCCESS)
	{

		if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResContext) != IFX_MMGR_SUCCESS)
		{
			return IFX_MMGR_FAIL;
		}
	}
	if(pxForkingResContext)
	{
			printf(" Forking Ctx found\n");
			eTypeOfCall = pxForkingResContext->eTypeOfCall;
			if(pxForkingResContext->iResourceId == 0)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		     "Invalid Resource Id");
				return IFX_MMGR_FAIL;
			}
	}
	else if (pxResContext)
	{
			eTypeOfCall = pxResContext->eTypeOfCall;
			if(pxResContext->iResourceId == 0)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		     "Invalid Resource Id");
				return IFX_MMGR_FAIL;
			}
			if(pxResContext->pxAddResContext)
			{
				x_IFX_MMGR_ResourceContext *pxResCtx;
				pxResCtx = (x_IFX_MMGR_ResourceContext*)pxResContext->pxAddResContext;
				if(!(pxResContext->uiServiceFlag & IFX_MMGR_LOAD_FREED))
				{
					//IFX_LM_LoadFree(&pxResContext->pxCoder->xCodecList);
					memcpy(&xVoipRes.xCodecList,&pxResCtx->pxCoder->xCodecList,sizeof(x_IFX_MMGR_CodecList));
					xVoipRes.eResourceType = IFX_LM_RES_CODEC;
					if(IFX_LM_LoadReserve(&xVoipRes,NULL) != IFX_LM_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		    		 "Load Reserve For Voip Failed");
						return IFX_MMGR_FAIL;
					}
				}

				pxResCtx->pxAddResContext = NULL;
				IFX_MMGR_DeAllocateResourceContext(pxResContext);
				printf(" returning success\n");
				return IFX_MMGR_SUCCESS;
			}
	}else{
		return IFX_MMGR_FAIL;
	}
	if(pafnResFreeForCall[eTypeOfCall]
			(iResourceId,&xResFrom,&xResTo) != IFX_MMGR_SUCCESS)
	{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		     "ResFreeForCall Failed");
		return IFX_MMGR_FAIL;
	}	
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

e_IFX_MMGR_Return IFX_MMGR_EnableLec(x_IFX_MMGR_ResourceInfo *pxRes,
									 uchar8 *pucCpuUsage
									 )
{
    uchar8 ucTailLength;
    ucTailLength = pxRes->uxChannel.pxFxsResource->ucLecTailLength ;
	x_IFX_LM_Resource xLecRes;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(pxRes->eResType == IFX_MMGR_FXS_RESOURCE)
	{
		if(pxRes->uxChannel.pxFxsResource->bIsLecEnabled)
			pxRes->uxChannel.pxFxsResource->ucNoOfCalls++;
		if((pxRes->uxChannel.pxFxsResource->bIsLecEnabled) && !pxRes->uxChannel.pxFxsResource->bIsLecConf )
		{
			if(ucTailLength == 8)
			{
				xLecRes.eResourceType = IFX_LM_RES_FXS_NB_LEC_8;
			}
			else 
			{
				xLecRes.eResourceType = IFX_LM_RES_FXS_NB_LEC_16;
			}
			if(IFX_LM_LoadReserve(&xLecRes,pucCpuUsage) != IFX_LM_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		     "Load Reserve For LEC Failed");
				return IFX_MMGR_FAIL;
			}
			if(IFX_MMGR_TAPI_LecConfigure(pxRes->uxChannel.pxFxsResource->iFd,
                 IFX_MMGR_LEC_NE,ucTailLength,IFX_MMGR_TRUE)!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		     "Configuring the LEC Failed");
			}
			pxRes->uxChannel.pxFxsResource->bIsLecConf = IFX_TRUE;
		}
	}
	if(pxRes->eResType == IFX_MMGR_FXO_RESOURCE && !pxRes->uxChannel.pxFxoResource->bIsLecConf)
	{
		if(pxRes->uxChannel.pxFxoResource->bIsLecEnabled)
		{
			if(ucTailLength == 8)
			{
				xLecRes.eResourceType = IFX_LM_RES_FXO_LEC_8;
			}
			else 
			{
				xLecRes.eResourceType = IFX_LM_RES_FXO_LEC_16;
			}
			if(IFX_LM_LoadReserve(&xLecRes,pucCpuUsage) != IFX_LM_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		     "Load Reserve For LEC Failed");
				return IFX_MMGR_FAIL;
			}
#ifndef SLIC121
			if(IFX_MMGR_TAPI_LecConfigure(pxRes->uxChannel.pxFxoResource->iPcmFd,
														 	IFX_MMGR_LEC_FE,ucTailLength,IFX_MMGR_TRUE)
																!= IFX_MMGR_SUCCESS)
#else
			if(IFX_MMGR_TAPI_LecConfigure(pxRes->uxChannel.pxFxoResource->iFd,
														 	IFX_MMGR_LEC_FE,ucTailLength,IFX_MMGR_TRUE)
																!= IFX_MMGR_SUCCESS)
#endif
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		     "Configuring the LEC Failed");
			}
			pxRes->uxChannel.pxFxoResource->bIsLecConf = IFX_TRUE;
		}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}

e_IFX_MMGR_Return IFX_MMGR_LecDisable(int32 iResourceId)
{
	x_IFX_MMGR_ResourceContext *pxResourceContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResourceContext) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	     "Resource Context Not Found");
		return IFX_MMGR_INVALID_PARAMETER;
	}
			if(IFX_MMGR_TAPI_LecConfigure(pxResourceContext->axResInfo[0].uxChannel.pxFxsResource->iFd,
									 	IFX_MMGR_LEC_NONE,16,IFX_MMGR_FALSE)
																!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	    	 "Configuring the LEC Failed");
			}
			/*
	if(IFX_MMGR_DisableLec(&pxResourceContext->axResInfo[0],NULL) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	     "Disabling the LEC Failed");
		return IFX_MMGR_FAIL;
	}*/
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

e_IFX_MMGR_Return IFX_MMGR_DisableLec(x_IFX_MMGR_ResourceInfo *pxRes,
									 uchar8 *pucCpuUsage
									 )
{
    uchar8 ucTailLength;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    ucTailLength = pxRes->uxChannel.pxFxsResource->ucLecTailLength ;
	x_IFX_LM_Resource xLecRes;
	if(pxRes->eResType == IFX_MMGR_FXS_RESOURCE)
	{
		if(pxRes->uxChannel.pxFxsResource->bIsLecConf){
			pxRes->uxChannel.pxFxsResource->ucNoOfCalls--;
		}else{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	    	 "LEC not configured");
			return IFX_SUCCESS;
		}
		if(pxRes->uxChannel.pxFxsResource->bIsLecEnabled &&
			   	pxRes->uxChannel.pxFxsResource->bIsLecConf && 
				!pxRes->uxChannel.pxFxsResource->ucNoOfCalls)
		{
			if(ucTailLength == 8)
			{
				xLecRes.eResourceType = IFX_LM_RES_FXS_NB_LEC_8;
			}
			else 
			{
				xLecRes.eResourceType = IFX_LM_RES_FXS_NB_LEC_16;
			}
			if(IFX_LM_LoadFree(&xLecRes) != IFX_LM_SUCCESS)
			{
				
				return IFX_MMGR_FAIL;
			}
			if(IFX_MMGR_TAPI_LecConfigure(pxRes->uxChannel.pxFxsResource->iFd,
									 	IFX_MMGR_LEC_NONE,ucTailLength,IFX_MMGR_FALSE)
																!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	    	 "Configuring the LEC Failed");
			}
			pxRes->uxChannel.pxFxsResource->bIsLecConf = IFX_FALSE;
		}
	}
	if(pxRes->eResType == IFX_MMGR_FXO_RESOURCE && pxRes->uxChannel.pxFxoResource->bIsLecConf)
	{
		if(pxRes->uxChannel.pxFxoResource->bIsLecEnabled)
		{
			if(ucTailLength == 8)
			{
				xLecRes.eResourceType = IFX_LM_RES_FXO_LEC_8;
			}
			else 
			{
				xLecRes.eResourceType = IFX_LM_RES_FXO_LEC_16;
			}
			if(IFX_LM_LoadFree(&xLecRes) != IFX_LM_SUCCESS)
			{
				
				return IFX_MMGR_FAIL;
			}
#ifndef SLIC121
			if(IFX_MMGR_TAPI_LecConfigure(pxRes->uxChannel.pxFxoResource->iPcmFd,
										IFX_MMGR_LEC_NONE,ucTailLength,IFX_MMGR_FALSE)
											!= IFX_MMGR_SUCCESS)
#else
			if(IFX_MMGR_TAPI_LecConfigure(pxRes->uxChannel.pxFxoResource->iFd,
										IFX_MMGR_LEC_NONE,ucTailLength,IFX_MMGR_FALSE)
											!= IFX_MMGR_SUCCESS)
#endif
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	    	 "Configuring the LEC Failed");
			}
			pxRes->uxChannel.pxFxoResource->bIsLecConf = IFX_FALSE;
		}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}

e_IFX_MMGR_Return IFX_MMGR_LoadResDect(x_IFX_MMGR_Dect_Channel *pxDect,
									   x_IFX_MMGR_CodecList *pxCodec
									)
{
	x_IFX_MMGR_CodecList xCodecList;
	x_IFX_LM_Resource xCodecRes;
	uint16 nCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(!pxCodec)
	{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   	 "pxCodec is NULL");
			return IFX_MMGR_FAIL;
	}
	memcpy(&xCodecList,pxCodec,sizeof(x_IFX_MMGR_CodecList));
	IFX_MMGR_SortCodecs(&xCodecList);
	for(nCount=0; nCount < xCodecList.ucNoOfCodecs;nCount++)
	{
		if(pxDect->xResCodecList.axCodecs[0].eCodecType == xCodecList.axCodecs[nCount].eCodecType)
		{
			break;
		}
	}
	if(nCount == xCodecList.ucNoOfCodecs)
	{
		memcpy(&xCodecRes.xCodecList,&pxDect->xResCodecList,sizeof(x_IFX_MMGR_CodecList));
		xCodecRes.eResourceType = IFX_LM_RES_CODEC;
		IFX_LM_LoadFree(&xCodecRes);
		memcpy(&xCodecRes.xCodecList,pxCodec,sizeof(x_IFX_MMGR_CodecList));
		if(IFX_LM_LoadReserve(&xCodecRes,NULL) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   	 "LoadReserve for Dect Codecs Failed");
			return IFX_MMGR_FAIL;
		}
		memcpy(pxCodec,&xCodecRes.xCodecList,sizeof(x_IFX_MMGR_CodecList));
		memcpy(&pxDect->xResCodecList,&xCodecRes.xCodecList,sizeof(x_IFX_MMGR_CodecList));
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResourceReserveForExtnCall
 *  Description       : Function is responsible for reserving all the resources  
 *						for extn-extn call.
 *  Input Values      : pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *                      pxCodec1 - Codec list 1
 *                      pxCodec2 - Codec list 2
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResReserveForExtnCall(
											int32 *piResourceId,
											x_IFX_MMGR_ResourceInfo *pxResFrom,
											x_IFX_MMGR_ResourceInfo *pxResTo,
											x_IFX_MMGR_CodecList *pxCodec1,
											x_IFX_MMGR_CodecList *pxCodec2
											)
{
	e_IFX_MMGR_ResourceType eResTypeTo, eResTypeFrom;
	x_IFX_MMGR_ResourceContext *pxResContext;
  x_IFX_MMGR_ResourceContext *pxOldResContext;
  x_IFX_MMGR_ForkingResContext *pxForkingResContext;
	x_IFX_LM_Resource xCodecRes;
  x_IFX_MMGR_ResourceInfo *pxResInfo;
  uchar8 ucCpuUsage,ucOldCpuUsage;

	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xCodecRes,0,sizeof(x_IFX_LM_Resource));
	if( pxResFrom == NULL || pxResTo == NULL) 
	{
		return IFX_MMGR_INVALID_PARAMETER;
	}
	eResTypeFrom = pxResFrom->eResType;
	eResTypeTo = pxResTo->eResType;
  /* Star Dialing */
  if(IFX_MMGR_ForkingResContextGet(*piResourceId,&pxForkingResContext) == IFX_MMGR_SUCCESS)
  {
	  IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   "CASE 1 : ForkingResContext Found!");
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
		        "Resource Id ",pxForkingResContext->iResourceId);

    /* Calculate the new cpu usage */
    if(IFX_MMGR_ComputeCpuUsage(pxResTo,pxCodec2,&ucCpuUsage) != IFX_MMGR_SUCCESS)
    {
      IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Computing the cpu Usage");
      return IFX_MMGR_FAIL;
    }

    if(ucCpuUsage > pxForkingResContext->ucMaxLoad)
    {
      /* This is third forking call */
      IFX_LM_LoadValFree(pxForkingResContext->ucMaxLoad);
      pxForkingResContext->ucMaxLoad = ucCpuUsage;
    }

    /* Get a free resource info slot */
    if(IFX_MMGR_FreeResInfoGet(pxForkingResContext,&pxResInfo) != IFX_MMGR_SUCCESS)
    {
      return IFX_MMGR_FAIL;
    }

    /* This Check might be ommitted as Star Dialing is applicable only to Dect Endpts */
    if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
    {
       IFX_MMGR_StoreCodecInfo(pxForkingResContext,pxResInfo,pxCodec2);
       pxResTo->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
    }

    memcpy(pxResInfo,pxResTo,sizeof(x_IFX_MMGR_ResourceInfo));
    (pxForkingResContext->unNoOfEndPts)++;
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
			"Number of Forking Endpts ",pxForkingResContext->unNoOfEndPts);
  }
  else if(IFX_MMGR_ResourceContextGet(*piResourceId,&pxOldResContext) == IFX_MMGR_SUCCESS)
  {
	  IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   	 "CASE 2 : ResourceContext Found!");
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
		        "Resource Id ",pxOldResContext->iResourceId);

    if(IFX_MMGR_ForkingResContextAlloc(&pxForkingResContext) != IFX_MMGR_SUCCESS)
    {
       IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "ForkingResContext Allocation Failed");
       return IFX_MMGR_MEMORY_ERROR;
    }

    pxForkingResContext->iResourceId = pxOldResContext->iResourceId;

    /*Copy From and To Dect Resources at indices 0 and 1 respectively */
    memcpy(&pxForkingResContext->axResInfo[0],
           &pxOldResContext->axResInfo[0],
           2*sizeof(x_IFX_MMGR_ResourceInfo));//Copy <From> and <To>

    pxForkingResContext->unNoOfEndPts = 1;
    pxForkingResContext->eTypeOfCall = IFX_MMGR_CALL_EXTN_EXTN;

    /* Need to check the cpu usage of the new call */
    /* This Check might be ommitted as Star Dialing is applicable only to Dect Endpts */
    if((pxOldResContext->axResInfo[0].eResType == IFX_MMGR_DECT_RESOURCE)&&
      (pxOldResContext->axResInfo[1].eResType == IFX_MMGR_DECT_RESOURCE)) 
    {
       /* To Resources start at index 1 */
       if(IFX_MMGR_StoreCodecInfo(pxForkingResContext,&pxOldResContext->axResInfo[0],
                          pxOldResContext->apxDectCodecList[0]) != IFX_MMGR_SUCCESS)
       {
          IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "iStore Codec Info for dect failed");
       }
       if(IFX_MMGR_StoreCodecInfo(pxForkingResContext,&pxOldResContext->axResInfo[1],
                          pxOldResContext->apxDectCodecList[1]) != IFX_MMGR_SUCCESS)
       {
          IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                 "iStore Codec Info for dect failed");
       }
    }

    if(IFX_MMGR_ComputeCpuUsage(&pxOldResContext->axResInfo[1],pxOldResContext->apxDectCodecList[1],
                                &ucOldCpuUsage) != IFX_MMGR_SUCCESS)
    {
      return IFX_MMGR_FAIL;
    }

    if(IFX_MMGR_ComputeCpuUsage(pxResTo,pxCodec2,&ucCpuUsage) != IFX_MMGR_SUCCESS)
    {
      return IFX_MMGR_FAIL;
    }

    pxForkingResContext->ucMaxLoad = (ucCpuUsage > ucOldCpuUsage)? ucCpuUsage : ucOldCpuUsage;

    /* Get a free resource info slot */
    if(IFX_MMGR_FreeResInfoGet(pxForkingResContext,&pxResInfo) != IFX_MMGR_SUCCESS)
    {
      return IFX_MMGR_FAIL;
    }

    /* This Check might be ommitted as Star Dialing is applicable only to Dect Endpts */
    if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
    {
      IFX_MMGR_StoreCodecInfo(pxForkingResContext,pxResInfo,pxCodec2);
    }

    memcpy(pxResInfo,pxResTo,sizeof(x_IFX_MMGR_ResourceInfo));
    (pxForkingResContext->unNoOfEndPts)++;
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
			"Number of Forking Endpts ",pxForkingResContext->unNoOfEndPts);
    IFX_MMGR_DeAllocateResourceContext(pxOldResContext);
  }
  else
	if(*piResourceId == 0)
	{
	  IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   	 "CASE 3 : No Forking!");
		if(IFX_MMGR_AllocateResourceContext(&pxResContext) < 0)
		{
      IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Allocate Resource Context Failed");
			return IFX_MMGR_MEMORY_ERROR;
		}
		/* Generate a new resourceId and this denotes a new 
			 request not a forking request */
		*piResourceId = IFX_MMGR_GenerateresourceId();

		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
		        "Resource Id ",*piResourceId);
		if(eResTypeFrom == IFX_MMGR_FXS_RESOURCE)
		{
			if(IFX_MMGR_EnableLec(pxResFrom,NULL) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   			 "Enabling the LEC Failed");
				return IFX_MMGR_FAIL;
			}
		}

		if(eResTypeTo == IFX_MMGR_FXS_RESOURCE)
		{
			if(IFX_MMGR_EnableLec(pxResTo,NULL) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   			 "Enabling the LEC Failed");
				return IFX_MMGR_FAIL;
			}
		}

		/* Reserve the loads for the codecs on dect channels if required */
		if( eResTypeFrom == IFX_MMGR_DECT_RESOURCE || 
										eResTypeTo == IFX_MMGR_DECT_RESOURCE)
		{
			if(eResTypeFrom == IFX_MMGR_DECT_RESOURCE )
			{
				if(IFX_MMGR_LoadResDect(pxResFrom->uxChannel.pxDectResource,pxCodec1) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   			 "Load Reserve For Dect Codecs Failed");
					return IFX_MMGR_FAIL;
				}
				pxResContext->apxDectCodecList[0] = IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
				memcpy(pxResContext->apxDectCodecList[0],pxCodec1,sizeof(x_IFX_MMGR_CodecList));
				pxResFrom->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
			}
			if(eResTypeTo == IFX_MMGR_DECT_RESOURCE)
			{
				if(IFX_MMGR_LoadResDect(pxResTo->uxChannel.pxDectResource,pxCodec2) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   			 "Load Reserve For Dect Codecs Failed");
					return IFX_MMGR_FAIL;
				}
				pxResContext->apxDectCodecList[1] = IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
				memcpy(pxResContext->apxDectCodecList[1],pxCodec2,sizeof(x_IFX_MMGR_CodecList));
				pxResTo->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
			}
		}
		pxResContext->iResourceId = *piResourceId;
		memcpy(&pxResContext->axResInfo[0],pxResFrom,
										sizeof(x_IFX_MMGR_ResourceInfo));
		memcpy(&pxResContext->axResInfo[1],pxResTo,
										sizeof(x_IFX_MMGR_ResourceInfo));
		pxResContext->eTypeOfCall = IFX_MMGR_CALL_EXTN_EXTN;
		
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResourceFreeForExtnCall
 *  Description       : Function is responsible for reserving all the resources  
 *						for extn-extn call.
 *  Input Values      : pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *                      pxCodec1 - Codec list 1
 *                      pxCodec2 - Codec list 2
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForExtnCall(
									int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
  x_IFX_MMGR_ForkingResContext *pxForkingResContext;
  x_IFX_MMGR_ResourceInfo *pxResInfo;
  uint16 unCount;

	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);

	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResContext) == IFX_MMGR_SUCCESS)
  {
	  IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   			 "CASE 1 : Resource Context Found!");
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
			"Resource Id ",iResourceId);

	  if(pxResFrom->eResType == IFX_MMGR_FXS_RESOURCE)
	  {
		  if(IFX_MMGR_DisableLec(pxResFrom,NULL) != IFX_MMGR_SUCCESS)
		  {
			  IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Disabling the LEC Failed");
			  return IFX_MMGR_FAIL;
		  }
	  }

	  if(pxResTo->eResType == IFX_MMGR_FXS_RESOURCE)
	  {
		  if(IFX_MMGR_DisableLec(pxResTo,NULL) != IFX_MMGR_SUCCESS)
		  {
			  IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Disabling the LEC Failed");
			  return IFX_MMGR_FAIL;
		  }
	  }

	  if(pxResFrom->eResType == IFX_MMGR_DECT_RESOURCE)
	  {
			if (pxResContext->apxDectCodecList[0]){
		  	IFX_OS_Free(pxResContext->apxDectCodecList[0]);
		  	pxResContext->apxDectCodecList[0] = 0;
			}
		  IFX_MMGR_FreeDectCh(pxResFrom->uxChannel.pxDectResource);
	  }

	  if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
	  {
			if (pxResContext->apxDectCodecList[1]){
		  	IFX_OS_Free(pxResContext->apxDectCodecList[1]);
		  	pxResContext->apxDectCodecList[1] = 0;
			}
		  IFX_MMGR_FreeDectCh(pxResTo->uxChannel.pxDectResource);
	  }

	  /* Dect handling to be determinded */
	  IFX_MMGR_DeAllocateResourceContext(pxResContext);
  }
  /* Star Dialing */
  else if(IFX_MMGR_ForkingResContextGet(iResourceId,&pxForkingResContext)
                        == IFX_MMGR_SUCCESS)
  {
	  IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   			 "CASE 2 : ForkingResourceContext Found!");
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
			"Forking Resource Id ",iResourceId);

    if(IFX_MMGR_ResInfoGet(pxForkingResContext,pxResTo,&pxResInfo)
                        != IFX_MMGR_SUCCESS)
    {
      IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Coulnot find the Resource Info");
      return IFX_MMGR_FAIL;
    }

    for(unCount=0; unCount < IFX_MMGR_MAX_FORK_ENDPT ; unCount++)
    {
      if(pxForkingResContext->axResInfo[unCount].\
          uxChannel.pxFxsResource == pxResTo->uxChannel.pxFxsResource)
      {
	        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_ATA_STRING_INFO,
        	   			 "Resource found.Free forking Resource for Endpoint", 
                   pxResTo->uxChannel.pxDectResource->szEndPtId);
          memset(&pxForkingResContext->axResInfo[unCount],
               0,
               sizeof(x_IFX_MMGR_ResourceInfo));
          if(pxForkingResContext->apxDectCodecList[unCount])
          {
            IFX_OS_Free(pxForkingResContext->apxDectCodecList[unCount]);
            pxForkingResContext->apxDectCodecList[unCount] = NULL;
          }
      }
    }
    (pxForkingResContext->unNoOfEndPts)--;
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
			"Number of Forking Endpts ",pxForkingResContext->unNoOfEndPts);

    /* If the number of endpts is one re-construct the resource context */
    if(pxForkingResContext->unNoOfEndPts == 1)
    {
	    IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	   			 "Number of Forking Endpts is 1");
      IFX_LM_LoadValueFree(pxForkingResContext->ucMaxLoad);
      if(IFX_MMGR_AllocateResourceContext(&pxResContext) != IFX_MMGR_SUCCESS)
      {
        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Allocate Resource Ctx Failed");
        return IFX_MMGR_FAIL;
      }
      /* Re-reserve the new cpu usage */
      /* For FXS Call its not required */
      /* For Dect we need to reserve the load */

      pxResContext->iResourceId = pxForkingResContext->iResourceId;
      pxResContext->eTypeOfCall = IFX_MMGR_CALL_EXTN_EXTN;

      /* Copy From resource to resource context */
      memcpy(&pxResContext->axResInfo[0],
             &pxForkingResContext->axResInfo[0],
             sizeof(x_IFX_MMGR_ResourceInfo));

      /* Copy Non Null To resource to resource context */
      for(unCount=1; unCount < IFX_MMGR_MAX_FORK_ENDPT ; unCount++)
      {
        if(pxForkingResContext->axResInfo[unCount].uxChannel.\
                pxFxsResource != NULL)
        {
          memcpy(&pxResContext->axResInfo[1],
               &pxForkingResContext->axResInfo[unCount],
               sizeof(x_IFX_MMGR_ResourceInfo));
          break;
        }
      }

			if (unCount == IFX_MMGR_MAX_FORK_ENDPT)
				return IFX_MMGR_FAIL;

      /*This check might not be needed with Star Dialing because its applicable only to DECT Endpts */
      if(pxResContext->axResInfo[0].eResType == IFX_MMGR_DECT_RESOURCE)
      {
        if(IFX_MMGR_LoadResDect(pxResContext->axResInfo[0].uxChannel.pxDectResource,
           pxForkingResContext->apxDectCodecList[0]) != IFX_MMGR_SUCCESS)
        {
          IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                   "Load Reserve For Dect Codecs Failed");
          return IFX_MMGR_FAIL;
        }
        pxResContext->apxDectCodecList[0] = IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
        memcpy(pxResContext->apxDectCodecList[0],
               pxForkingResContext->apxDectCodecList[0],
               sizeof(x_IFX_MMGR_CodecList));
        pxResContext->axResInfo[0].uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
      }

      /*This check might not be needed with Star Dialing because its applicable only to DECT Endpts */
      if(pxResContext->axResInfo[1].eResType == IFX_MMGR_DECT_RESOURCE)
      {
        if(IFX_MMGR_LoadResDect(pxResContext->axResInfo[1].uxChannel.pxDectResource,
           pxForkingResContext->apxDectCodecList[unCount]) != IFX_MMGR_SUCCESS)
        {
          IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Load Res for dect codecs  Failed");
          return IFX_MMGR_FAIL;
        }
        pxResContext->apxDectCodecList[1] = IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
        memcpy(pxResContext->apxDectCodecList[1],
            pxForkingResContext->apxDectCodecList[unCount],
            sizeof(x_IFX_MMGR_CodecList));
        pxResContext->axResInfo[1].uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
      }

      IFX_MMGR_ForkingResContextDealloc(pxForkingResContext);
    }
  }//Forking Context
/*
  else{
   IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
            "FAILURE!!!!");
   return IFX_MMGR_FAIL;
  }
*/
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResReserveForExtnVoipCall
 *  Description       : Function is responsible for reserving all the resources  
 *						for extn-extn call.
 *  Input Values      : pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *                      pxCodec1 - Codec list 1
 *                      pxCodec2 - Codec list 2
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResReserveForExtnVoipCall(
										int32 *piResourceId,
										x_IFX_MMGR_ResourceInfo *pxResFrom,
										x_IFX_MMGR_ResourceInfo *pxResTo,
										x_IFX_MMGR_CodecList *pxCodec1,
										x_IFX_MMGR_CodecList *pxCodec2
										)
{
    x_IFX_MMGR_Data_Channel *pxDC,*pxCoder;
    x_IFX_LM_Resource xCodecRes;
		x_IFX_MMGR_ResourceContext *pxResContext;

	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xCodecRes,0,sizeof(xCodecRes));
	if(IFX_MMGR_AllocateResourceContext(&pxResContext) 
									!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Allocating the Resource Context Failed");
		return IFX_MMGR_MEMORY_ERROR;
	}
	*piResourceId = IFX_MMGR_GenerateresourceId();
	/* If the extn is of type FXS */
	if(pxResFrom->eResType == IFX_MMGR_FXS_RESOURCE)
	{
		if(IFX_MMGR_EnableLec(pxResFrom,NULL) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Enabling the LEC Failed");
			return IFX_MMGR_FAIL;
		}
		/* Check whether a data channel is already available with the fxs resource */
		if(pxResFrom->uxChannel.pxFxsResource->pxDC[0])
		{
     		pxDC = (x_IFX_MMGR_Data_Channel*) pxResFrom->uxChannel.pxFxsResource->pxDC[0];
			
			if(!(pxDC->uiServiceFlag 
				& IFX_MMGR_RES_USED_AS_CODER))
			{
				/* The signalling channel already allocated can be used a coder resource */
				pxResContext->pxCoder = (x_IFX_MMGR_Data_Channel*)pxResFrom->uxChannel.pxFxsResource->pxDC[0];
				pxDC->uiServiceFlag |= IFX_MMGR_RES_USED_AS_CODER;
			}

			/* A new coder is required */
			else//ASK:???
			{
				if(IFX_MMGR_AllocateCoder(&pxCoder,1) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "No Data Channels Available");
					return IFX_MMGR_NO_RESOURCE;
				}
				pxResContext->pxCoder = pxCoder;
				/* Add the coder channel to the analog channel */
				if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxCoder->iFd,
                   pxResFrom->uxChannel.pxFxsResource->unChannelNum) 
									!= IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Adding the data channel to analog Failed");
					IFX_MMGR_DeAllocCoder(pxCoder);
					return IFX_MMGR_FAIL;
				}
				pxResFrom->uxChannel.pxFxsResource->pxDC[1] = (struct x_IFX_MMGR_Data_Channel*)pxCoder;
				pxCoder->eDestResType = IFX_MMGR_FXS_RESOURCE;
				pxCoder->uxDestResource.pxFxs = pxResFrom->uxChannel.pxFxsResource;
				pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_CODER;
			}
		}
	}
	/* If the extn is of type Dect */
	else if(pxResFrom->eResType == IFX_MMGR_DECT_RESOURCE)
	{

		if(pxCodec1)
		{
			if(IFX_MMGR_LoadResDect(pxResFrom->uxChannel.pxDectResource,pxCodec1) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Load Reserve For Dect Codecs  Failed");
				return IFX_MMGR_FAIL;
			}
			pxResContext->apxDectCodecList[0] = IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
			memcpy(pxResContext->apxDectCodecList[0],pxCodec1,sizeof(x_IFX_MMGR_CodecList));
			pxResFrom->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
		}
		if(IFX_MMGR_AllocateCoder(&pxCoder,0) != IFX_MMGR_SUCCESS)
		{
			if(pxCodec1)
			{
				memcpy(&xCodecRes.xCodecList,pxCodec1,sizeof(x_IFX_MMGR_CodecList));
				xCodecRes.eResourceType = IFX_LM_RES_CODEC;
				IFX_LM_LoadFree(&xCodecRes);
			}
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Allocate Coder Failed");
			return IFX_MMGR_NO_RESOURCE;
		}
		pxResContext->pxCoder = pxCoder;
		/* Add the coder channel to the dect channel */
		if(IFX_MMGR_TAPI_AddDataChannelToDect(pxCoder->iFd,
           pxResFrom->uxChannel.pxDectResource->unChannelNum) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Adding data channel to dect Failed");
			IFX_MMGR_DeAllocCoder(pxCoder);
			if(pxCodec1)
				memcpy(&xCodecRes.xCodecList,pxCodec1,sizeof(x_IFX_MMGR_CodecList));
			xCodecRes.eResourceType = IFX_LM_RES_CODEC;
			IFX_LM_LoadFree(&xCodecRes);
			return IFX_MMGR_FAIL;
		}
		pxResFrom->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
	}
	
	memcpy(&xCodecRes.xCodecList,pxCodec2,sizeof(x_IFX_MMGR_CodecList));
	xCodecRes.eResourceType = IFX_LM_RES_CODEC;
	if(IFX_LM_LoadReserve(&xCodecRes,NULL) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Load Reserve for VOIP Codecs Failed");
		/* Free the cpu usage of the dect codecs */
		if(pxResFrom->eResType == IFX_MMGR_DECT_RESOURCE)
		{
			memcpy(&xCodecRes.xCodecList,pxCodec2,sizeof(x_IFX_MMGR_CodecList));//ASK:COdec1???
			IFX_LM_LoadFree(&xCodecRes);
		}
		return IFX_MMGR_FAIL;
	}
	memcpy(pxCodec2,&xCodecRes.xCodecList,sizeof(x_IFX_MMGR_CodecList));//ASK:Why??
	memcpy(&pxResContext->pxCoder->xCodecList,pxCodec2,sizeof(x_IFX_MMGR_CodecList));//ASk???
	pxResContext->iResourceId = *piResourceId;
	pxResContext->eTypeOfCall = IFX_MMGR_CALL_EXTN_VOIP;
	memcpy(&pxResContext->axResInfo[0],pxResFrom,sizeof(x_IFX_MMGR_ResourceInfo));
//ASK:TO???
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResFreeForExtnVoipCall
 *  Description       : Function is responsible for reserving all the resources  
 *						for extn-extn call.
 *  Input Values      : pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     :
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForExtnVoipCall(int32 iResourceId,
							                     x_IFX_MMGR_ResourceInfo *pxResFrom,
												 x_IFX_MMGR_ResourceInfo *pxResTo
									             )
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	x_IFX_LM_Resource xCodecRes;
	boolean bRemove = IFX_FALSE;
	x_IFX_MMGR_Data_Channel *pxCoder;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);

	memset(&xCodecRes,0,sizeof(x_IFX_LM_Resource));
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResContext) 
										!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Resource Context Not Found");
		return IFX_MMGR_FAIL;
	}
		/* Stop the ENC/DEC on the coder channel first */
	if(IFX_MMGR_TAPI_StopDecoding(pxResContext->pxCoder->iFd)
							 	!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Stop Decoding Failed");
		return IFX_MMGR_FAIL;
	}
	if(IFX_MMGR_TAPI_StopEncoding(pxResContext->pxCoder->iFd) 
									!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Stop Encoding Failed");
		return IFX_MMGR_FAIL;
	}
	/* Free the CPu Usage first */
	memcpy(&xCodecRes.xCodecList,
		   &pxResContext->pxCoder->xCodecList,sizeof(x_IFX_MMGR_CodecList));
	xCodecRes.eResourceType = IFX_LM_RES_CODEC;
	if(IFX_LM_LoadFree(&xCodecRes) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Load Free Failed");
		return IFX_MMGR_FAIL;
	}
	
	if(pxResContext->axResInfo[0].eResType == IFX_MMGR_FXS_RESOURCE)
	{

					//UGW_SW-3020 issue:Fix:Added check for res Type IFX_MMGR_NONE
		if(pxResFrom->eResType != IFX_MMGR_NONE){
			if(IFX_MMGR_DisableLec(pxResFrom,NULL) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Disabling the LEC Failed");
				return IFX_MMGR_FAIL;
			}
		}
		if(pxResContext->pxCoder == 
					(x_IFX_MMGR_Data_Channel*)pxResContext->axResInfo[0].\
					     uxChannel.pxFxsResource->pxDC[0])
		{
			printf("<MM_FreeExtnVoIP> Freeing DC 0\n");
			//UGW_SW-3020 issue:Fix:Added check for res Type IFX_MMGR_NONE
			if((pxResFrom->eResType==IFX_MMGR_NONE)||
					(!pxResFrom->uxChannel.pxFxsResource->pxDC[1]))
			{
				printf("<MM_FreeExtnVoIP> Resting Used-as-coder flag\n");
					pxResContext->pxCoder->uiServiceFlag &=
						~IFX_MMGR_RES_USED_AS_CODER;
					/* If this coder is not used as signalling channel remove it */
					if(!(pxResContext->pxCoder->uiServiceFlag & IFX_MMGR_RES_USED_AS_SIG))
					{
						printf("<MM_FreeExtnVoIP> Chnl not used as Sig Remove=true\n");
						bRemove = IFX_TRUE;
					}
			}
			else
			{
				printf("<MM_FreeExtnVoIP> Second Chnnl in use\n");
				pxResContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[0] = 
					pxResContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[1];
				bRemove = IFX_TRUE;
				pxCoder = (x_IFX_MMGR_Data_Channel*)pxResContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[0];
				if(pxResContext->pxCoder->uiServiceFlag & IFX_MMGR_RES_USED_AS_SIG){
					pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
				}
				pxResContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[1] = NULL;
			}
		}
		else if(pxResContext->pxCoder == 
										(x_IFX_MMGR_Data_Channel*)pxResContext->axResInfo[0].\
										uxChannel.pxFxsResource->pxDC[1])
		{
			printf("<MM_FreeExtnVoIP> Freeing DC 1\n");
			bRemove = IFX_TRUE;
		}
		if(bRemove)
		{
			if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxResContext->pxCoder->iFd,
				pxResContext->axResInfo[0].uxChannel.pxFxsResource->unChannelNum)
										 	!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Removing the data channel from analog Failed");
				return IFX_MMGR_FAIL;
			}
			pxResContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[1] = NULL;
			IFX_MMGR_DeAllocCoder(pxResContext->pxCoder);
		}
			
	}
	if(pxResContext->axResInfo[0].eResType == IFX_MMGR_DECT_RESOURCE)
	{
			if(IFX_MMGR_TAPI_RemoveDataChannelFromDect(pxResContext->pxCoder->iFd,
				pxResContext->axResInfo[0].uxChannel.pxDectResource->unChannelNum)
										 	!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Removing the data channel from dect Failed");
				return IFX_MMGR_FAIL;
			}
			
			IFX_MMGR_FreeDectCh(pxResContext->axResInfo[0].uxChannel.pxDectResource);
			if (pxResContext->apxDectCodecList[0]){
				IFX_OS_Free(pxResContext->apxDectCodecList[0]);
				pxResContext->apxDectCodecList[0] = 0;
			}
			IFX_MMGR_DeAllocCoder(pxResContext->pxCoder);
	}

	IFX_MMGR_DeAllocateResourceContext(pxResContext);
	
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResReserveForExtnFxoCall
 *  Description       : Function is responsible for reserving all the resources  
 *						for extn-fxo call.
 *  Input Values      : pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *                      pxCodec1 - Codec list 1
 *                      pxCodec2 - Codec list 2
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResReserveForExtnFxoCall(
											int32 *piResourceId,
									        x_IFX_MMGR_ResourceInfo *pxResFrom,
										    x_IFX_MMGR_ResourceInfo *pxResTo,
											x_IFX_MMGR_CodecList *pxCodec1,
											x_IFX_MMGR_CodecList *pxCodec2
											)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
    x_IFX_LM_Resource xCodecRes;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xCodecRes,0,sizeof(x_IFX_LM_Resource));
	if(IFX_MMGR_AllocateResourceContext(&pxResContext) != IFX_MMGR_SUCCESS)
	{
		return IFX_MMGR_MEMORY_ERROR;
	}
	*piResourceId = IFX_MMGR_GenerateresourceId();
	/* for the fxo call only far end lec has to be configured on the fxo channel */
	if(IFX_MMGR_EnableLec(pxResTo,NULL) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Enabling Lec on Fxo Failed");
		return IFX_MMGR_FAIL;
	}
	if(pxResFrom->eResType == IFX_MMGR_DECT_RESOURCE)
	{
		if(pxCodec1)
		{
			if(IFX_MMGR_LoadResDect(pxResFrom->uxChannel.pxDectResource,pxCodec1) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Load Reserve For dect codecs Failed");
				return IFX_MMGR_FAIL;
			}
			pxResContext->apxDectCodecList[0] = IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
			memcpy(pxResContext->apxDectCodecList[0],pxCodec1,sizeof(x_IFX_MMGR_CodecList));
			pxResFrom->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
		}
	}
	pxResContext->iResourceId = *piResourceId;
	memcpy(&pxResContext->axResInfo[0],pxResFrom,sizeof(x_IFX_MMGR_ResourceInfo));
	memcpy(&pxResContext->axResInfo[1],pxResTo,sizeof(x_IFX_MMGR_ResourceInfo));
	pxResContext->eTypeOfCall = IFX_MMGR_CALL_EXTN_FXO;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResFreeForExtnFxoCall
 *  Description       : Function is responsible for reserving all the resources  
 *						for extn-fxo call.
 *  Input Values      : 
 *						pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForExtnFxoCall(
							int32 iResourceId,
							x_IFX_MMGR_ResourceInfo *pxResFrom,
							x_IFX_MMGR_ResourceInfo *pxResTo
							  )
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResContext) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Resource Context Not Found");
		return IFX_MMGR_FAIL;
	}
	if(IFX_MMGR_DisableLec(pxResTo,NULL) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Disabling the LEC Failed");
		return IFX_MMGR_FAIL;
	}
	/* Dect handling to be determined later */
	IFX_MMGR_DeAllocateResourceContext(pxResContext);
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResReserveForFxoExtnCall
 *  Description       : Function is responsible for reserving all the resources  
 *						for fxo-extn call.
 *  Input Values      : pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *                      pxCodec1 - Codec list 1
 *                      pxCodec2 - Codec list 2
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResReserveForFxoExtnCall(
									int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									)
{
	x_IFX_MMGR_ResourceContext *pxOldResContext;
    x_IFX_MMGR_ForkingResContext *pxForkingResContext;
	x_IFX_MMGR_ResourceInfo *pxResInfo;
	x_IFX_MMGR_ResourceContext *pxResContext;
//    x_IFX_LM_Resource xCodecRes = {0};
	int32 iResourceId;
    uchar8 ucCpuUsage;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	
		/* This is a forking scenario */
		if(IFX_MMGR_ForkingResContextGet(*piResourceId,&pxForkingResContext) 
											== IFX_MMGR_SUCCESS)
		{
			if(IFX_MMGR_ComputeCpuUsage(pxResTo,pxCodec2,&ucCpuUsage) 
									!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Computing the cpu Usage");
				return IFX_MMGR_FAIL;
			}
			/* If the new cpu usage is more then, update the maxusage */
			if(ucCpuUsage > pxForkingResContext->ucMaxLoad)
			{
				/* This is third forking call */
				IFX_LM_LoadValFree(pxForkingResContext->ucMaxLoad);
				IFX_LM_AddCpuUsage(ucCpuUsage);
				pxForkingResContext->ucMaxLoad = ucCpuUsage;
			}
			
			/* Get a free resource info slot */
			if(IFX_MMGR_FreeResInfoGet(pxForkingResContext,&pxResInfo) 
												!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Couldn't get a Resource info slot");
				return IFX_MMGR_FAIL;
			}
      memcpy(pxResInfo,pxResTo,sizeof(x_IFX_MMGR_ResourceInfo));
			if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				IFX_MMGR_StoreCodecInfo(pxForkingResContext,pxResInfo,pxCodec2);
				pxResTo->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
			}
			(pxForkingResContext->unNoOfEndPts)++;

		}
		else if(IFX_MMGR_ResourceContextGet(*piResourceId,&pxOldResContext) == IFX_MMGR_SUCCESS)
		{
			/* This is the second forking ,so allocate a forking resource context */
			if(IFX_MMGR_ForkingResContextAlloc(&pxForkingResContext) 
										!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Allocating a Forking Resource context Failed");
				return IFX_MMGR_MEMORY_ERROR;
			}
			pxForkingResContext->iResourceId = pxOldResContext->iResourceId;
			pxForkingResContext->pxFxo = 
				      pxOldResContext->axResInfo[0].uxChannel.pxFxoResource;
			memcpy(&pxForkingResContext->axResInfo[0],
				&pxOldResContext->axResInfo[1],sizeof(x_IFX_MMGR_ResourceInfo));
			pxForkingResContext->unNoOfEndPts = 1;
			pxForkingResContext->eTypeOfCall = IFX_MMGR_CALL_FXO_EXTN;
			/* Need to check the cpu usage of the new call */
			/* A FLEC is always required for a FXO call so , this load 
			   will remain the same */
			 if(pxOldResContext->axResInfo[1].eResType == IFX_MMGR_DECT_RESOURCE)
			{
				/* Re-compute the cpu usage of dect res and just store it .. no need to reserve */
				
				if(IFX_MMGR_StoreCodecInfo(pxForkingResContext,&pxOldResContext->axResInfo[1],
													pxOldResContext->apxDectCodecList[1]) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "iStore Codec Info for dect failed");
				}
				if(IFX_MMGR_ComputeCpuUsage(&pxOldResContext->axResInfo[1],pxOldResContext->apxDectCodecList[1],
																&ucCpuUsage) 
									!= IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Computing the cpu usage Failed");
					return IFX_MMGR_FAIL;
				}
				pxForkingResContext->ucMaxLoad = ucCpuUsage;
			}
			if(IFX_MMGR_ComputeCpuUsage(&pxOldResContext->axResInfo[1],pxCodec2,
									&pxForkingResContext->ucMaxLoad) 
									!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Computing the cpu usage Failed");
				return IFX_MMGR_FAIL;
			}
			if(IFX_MMGR_ComputeCpuUsage(pxResTo,pxCodec2,
									&ucCpuUsage) 
									!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Computing the cpu usage Failed");
				return IFX_MMGR_FAIL;
			}
			if(ucCpuUsage > pxForkingResContext->ucMaxLoad)
			{
				pxForkingResContext->ucMaxLoad = ucCpuUsage;
			}
			IFX_LM_AddCpuUsage(pxForkingResContext->ucMaxLoad);

			/* Get a free resource info slot */
			if(IFX_MMGR_FreeResInfoGet(pxForkingResContext,&pxResInfo) 
												!= IFX_MMGR_SUCCESS)
			{
				return IFX_MMGR_FAIL;
			}
      memcpy(pxResInfo,pxResTo,sizeof(x_IFX_MMGR_ResourceInfo));
			if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				IFX_MMGR_StoreCodecInfo(pxForkingResContext,pxResInfo,pxCodec2);
			}
			(pxForkingResContext->unNoOfEndPts)++;
			IFX_MMGR_DeAllocateResourceContext(pxOldResContext);
		}
		 
	else
	{
		if(IFX_MMGR_AllocateResourceContext(&pxResContext) != IFX_MMGR_SUCCESS)
		{
			return IFX_MMGR_MEMORY_ERROR;
		}
		iResourceId = IFX_MMGR_GenerateresourceId();
		/* for the fxo call only far end lec has to be configured on the fxo channel */
		if(IFX_MMGR_EnableLec(pxResFrom,NULL) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Enabling the LEC Failed");
			return IFX_MMGR_FAIL;
		}
		if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
		{
			if(pxCodec2)
			{
				if(IFX_MMGR_LoadResDect(pxResTo->uxChannel.pxDectResource,pxCodec2) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Load Reserve for Dect Codecs Failed");
					return IFX_MMGR_FAIL;
				}
				pxResContext->apxDectCodecList[1] = IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
				memcpy(pxResContext->apxDectCodecList[1],pxCodec2,sizeof(x_IFX_MMGR_CodecList));
				pxResTo->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
			}
		}
		pxResContext->iResourceId = *piResourceId = iResourceId;
		memcpy(&pxResContext->axResInfo[0],
			pxResFrom,
			sizeof(x_IFX_MMGR_ResourceInfo));
		memcpy(&pxResContext->axResInfo[1],
			pxResTo,
			sizeof(x_IFX_MMGR_ResourceInfo));
		pxResContext->eTypeOfCall = IFX_MMGR_CALL_FXO_EXTN;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResFreeForFxoExtnCall
 *  Description       : Function is responsible for freeing all the resources  
 *						for fxo-extn call.
 *  Input Values      : iResourceId - Resource Id.
 *						pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForFxoExtnCall(
										int32 iResourceId,
										x_IFX_MMGR_ResourceInfo *pxResFrom,
										x_IFX_MMGR_ResourceInfo *pxResTo
										)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	x_IFX_MMGR_ForkingResContext *pxForkingResContext;
	x_IFX_LM_Resource xCodecRes ;
    x_IFX_MMGR_ResourceInfo *pxResInfo;
    uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xCodecRes,0,sizeof(x_IFX_LM_Resource));
	/* Search the resource id in Resource context first */
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResContext) == 
										IFX_MMGR_SUCCESS)
	{
		if(IFX_MMGR_DisableLec(&pxResContext->axResInfo[0],NULL) 
												!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Load Reserve For Dect codecs Failed");
			return IFX_MMGR_FAIL;
		}
		if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
		{
			if (pxResContext->apxDectCodecList[1]){
				IFX_OS_Free(pxResContext->apxDectCodecList[1]);
				pxResContext->apxDectCodecList[1] = 0;
			}
			IFX_MMGR_FreeDectCh(pxResContext->axResInfo[1].uxChannel.pxDectResource);
		}
		IFX_MMGR_DeAllocateResourceContext(pxResContext);
		/* No Resources are reseerved for FXS endpt so no need to do anything */
	}
	else if(IFX_MMGR_ForkingResContextGet(iResourceId,&pxForkingResContext) 
												== IFX_MMGR_SUCCESS)
	{
		if(IFX_MMGR_ResInfoGet(pxForkingResContext,pxResTo,&pxResInfo) 
												!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "ResInfo slot not found ");
			return IFX_MMGR_FAIL;
		}
		memset(pxResInfo,0,sizeof(x_IFX_MMGR_ResourceInfo));
		(pxForkingResContext->unNoOfEndPts)--;
		/* If the number of endpts is one re-construct the resource context */
		if(pxForkingResContext->unNoOfEndPts == 1)
		{
			IFX_LM_LoadValueFree(pxForkingResContext->ucMaxLoad);
			if(IFX_MMGR_AllocateResourceContext(&pxResContext) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "allocating a Resource Context Failed ");
				return IFX_MMGR_FAIL;
			}
			/* Re-reserve the new cpu usage */
			/* For FXS Call its not required */
			/* For Dect we need to reserve the load */

			pxResContext->iResourceId = pxForkingResContext->iResourceId;
			pxResContext->axResInfo[0].uxChannel.pxFxoResource = 
											pxForkingResContext->pxFxo;
			pxResContext->axResInfo[0].eResType = IFX_MMGR_FXO_RESOURCE;
			pxResContext->eTypeOfCall = IFX_MMGR_CALL_FXO_EXTN;
			for(unCount=0; unCount < IFX_MMGR_MAX_FORK_ENDPT ; unCount++)
			{
				if(pxForkingResContext->axResInfo[unCount].uxChannel.\
								pxFxsResource != NULL)
				{
					memcpy(&pxResContext->axResInfo[1],
						   &pxForkingResContext->axResInfo[unCount],
						   sizeof(x_IFX_MMGR_ResourceInfo));
				}
			}
			if(pxResContext->axResInfo[1].eResType == IFX_MMGR_DECT_RESOURCE)
			{
				memcpy(&xCodecRes.xCodecList,
					&pxResContext->axResInfo[1].uxChannel.pxDectResource->xResCodecList,
					sizeof(x_IFX_MMGR_CodecList));
				xCodecRes.eResourceType = IFX_LM_RES_CODEC;
				if(IFX_LM_LoadReserve(&xCodecRes,NULL) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					 "Load Reserve for dect codecs failed ");
					return IFX_MMGR_FAIL;
				}
				
			}
			IFX_MMGR_ForkingResContextDealloc(pxForkingResContext);
		}
#if 0
		else
		{
			for(unCount=0; unCount < IFX_MAX_ENDPTS ; unCount++)
			{
				if(pxForkingResContext->axResInfo[unCount].\
					uxChannel.pxFxsResource == pxResTo->uxChannel.pxFxsResource)
				{
					memset(&pxResContext->axResInfo[1],
						   0,
						   sizeof(x_IFX_MMGR_ResourceInfo));
				}
			}
		}
#endif
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResReserveForVoipCall
 *  Description       : Function is responsible for freeing all the resources  
 *						for fxo-extn call.
 *  Input Values      : iResourceId - Resource Id.
 *						pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResReserveForVoipCall(
								  x_IFX_MMGR_ResourceContext *pxResContext,
									x_IFX_MMGR_ResourceInfo *pxFxo,
									x_IFX_MMGR_CodecList *pxCodec
									)
{
	x_IFX_LM_Resource xCodecRes;
	x_IFX_MMGR_Data_Channel *pxCoder;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xCodecRes,0,sizeof(x_IFX_LM_Resource));
	memcpy(&xCodecRes.xCodecList,pxCodec,sizeof(x_IFX_MMGR_CodecList));
	xCodecRes.eResourceType = IFX_LM_RES_CODEC;
	if(IFX_LM_LoadReserve(&xCodecRes,NULL) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Load Reserve for VOIP codecs failed ");
		return IFX_MMGR_FAIL;
	}
	memcpy(pxCodec,&xCodecRes.xCodecList,sizeof(x_IFX_MMGR_CodecList));
	/* Configure the LEC on the FXO port */
	if(IFX_MMGR_EnableLec(pxFxo,NULL) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Enabling the LEC on the FXO port Failed ");
		return IFX_MMGR_FAIL;
	}
	/* its assumed that a data channel is already allocated to the fxo channel */
	if(pxFxo->uxChannel.pxFxoResource->pxDC)
	{
		pxResContext->pxCoder = (x_IFX_MMGR_Data_Channel *)
														pxFxo->uxChannel.pxFxoResource->pxDC;
		pxResContext->pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_CODER;
		memcpy(&pxResContext->pxCoder->xCodecList,pxCodec,sizeof(x_IFX_MMGR_CodecList));
	}
	else
	{
		if(IFX_MMGR_AllocateCoder(&pxCoder,0) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Allocate Coder Failed");
			IFX_MMGR_DisableLec(pxFxo,NULL);
			return IFX_MMGR_FAIL;
		}
#ifndef SLIC121
		if(IFX_MMGR_TAPI_AddDataChannelToPcm(pxCoder->iFd,
			pxFxo->uxChannel.pxFxoResource->unPcmChannelNum)!= IFX_MMGR_SUCCESS)
#else
		if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxCoder->iFd,
			pxFxo->uxChannel.pxFxoResource->unChannelNum)!= IFX_MMGR_SUCCESS)
#endif
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Add Data Channel to Fxo Failed");
			IFX_MMGR_DisableLec(pxFxo,NULL);
			return IFX_MMGR_FAIL;
		}
    pxCoder->eDestResType = IFX_MMGR_FXO_RESOURCE;
    pxCoder->uxDestResource.pxFxo = pxFxo->uxChannel.pxFxoResource;
		pxResContext->pxCoder = pxCoder;
		pxFxo->uxChannel.pxFxoResource->pxDC = (struct x_IFX_MMGR_Data_Channel*)pxCoder;
		pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_CODER;
		pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
	  pxFxo->uxChannel.pxFxoResource->uiServiceFlag |= IFX_MMGR_SIG_CH_ALLOCATED;
		memcpy(&pxResContext->pxCoder->xCodecList,pxCodec,sizeof(x_IFX_MMGR_CodecList));
	}
	memcpy(&pxResContext->axResInfo[0],pxFxo,sizeof(x_IFX_MMGR_ResourceInfo));
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResFreeForVoipCall
 *  Description       : Function is responsible for freeing all the resources  
 *						for voip call.
 *  Input Values      : iResourceId - Resource Id.
 *						pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForVoipCall(
									x_IFX_MMGR_ResourceContext *pxResContext,
									x_IFX_MMGR_ResourceInfo *pxResFxo
									)
{
	x_IFX_LM_Resource xCodecRes;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xCodecRes,0,sizeof(x_IFX_LM_Resource));
	memcpy(&xCodecRes.xCodecList,
		&pxResContext->pxCoder->xCodecList,
		sizeof(x_IFX_MMGR_CodecList));
	xCodecRes.eResourceType = IFX_LM_RES_CODEC;
	if(IFX_LM_LoadFree(&xCodecRes) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Load Free for voip codecs Failed");
		return IFX_MMGR_FAIL;
	}
	/* Configure the LEC on the FXO port */
	if(IFX_MMGR_DisableLec(pxResFxo,NULL) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Disablre LEC Failed");
		return IFX_MMGR_FAIL;
	}
	if(IFX_MMGR_TAPI_StopEncoding(pxResContext->pxCoder->iFd) != IFX_MMGR_SUCCESS)
	{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Stop Encoding Failed");
			return IFX_MMGR_FAIL;
	}
	if(IFX_MMGR_TAPI_StopDecoding(pxResContext->pxCoder->iFd) != IFX_MMGR_SUCCESS)
	{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Stop Decoding Failed");
			return IFX_MMGR_FAIL;
	}
	pxResContext->pxCoder->uiServiceFlag &= ~IFX_MMGR_RES_USED_AS_CODER;
	IFX_MMGR_DeAllocateResourceContext(pxResContext);
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResReserveForVoipFxoCall
 *  Description       : Function is responsible for freeing all the resources  
 *						for fxo-extn call.
 *  Input Values      : iResourceId - Resource Id.
 *						pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResReserveForVoipFxoCall(
									int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_AllocateResourceContext(&pxResContext) < 0)
	{
			return IFX_MMGR_MEMORY_ERROR;
	}
  *piResourceId =  pxResContext->iResourceId = IFX_MMGR_GenerateresourceId();
	if(IFX_MMGR_ResReserveForVoipCall(pxResContext,pxResTo,pxCodec1) != IFX_MMGR_SUCCESS)
	{
		return IFX_MMGR_FAIL;
	}
	pxResContext->eTypeOfCall = IFX_MMGR_CALL_VOIP_FXO;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResFreeForVoipFxoCall
 *  Description       : Function is responsible for freeing all the resources  
 *						for voip call.
 *  Input Values      : iResourceId - Resource Id.
 *						pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForVoipFxoCall(
									int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResContext) 
											!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Resource Context Not Found");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	if(IFX_MMGR_ResFreeForVoipCall(pxResContext,pxResTo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "ResFreeForVoipCall Failed");
		return IFX_MMGR_FAIL;
	}
	IFX_MMGR_DeAllocateResourceContext(pxResContext);
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResReserveForFxoVoipCall
 *  Description       : Function is responsible for freeing all the resources  
 *						for fxo-extn call.
 *  Input Values      : iResourceId - Resource Id.
 *						pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResReserveForFxoVoipCall(
									int32 *piResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo,
									x_IFX_MMGR_CodecList *pxCodec1,
									x_IFX_MMGR_CodecList *pxCodec2
									)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_AllocateResourceContext(&pxResContext) < 0)
	{
			return IFX_MMGR_MEMORY_ERROR;
	}
  *piResourceId =  pxResContext->iResourceId = IFX_MMGR_GenerateresourceId();

	pxResContext->eTypeOfCall = IFX_MMGR_CALL_FXO_VOIP;
	if(IFX_MMGR_ResReserveForVoipCall(pxResContext,pxResFrom,pxCodec2) 
									!= IFX_MMGR_SUCCESS)
	{
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResFreeForVoipFxoCall
 *  Description       : Function is responsible for freeing all the resources  
 *						for voip call.
 *  Input Values      : iResourceId - Resource Id.
 *						pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForFxoVoipCall(
									int32 iResourceId,
									x_IFX_MMGR_ResourceInfo *pxResFrom,
									x_IFX_MMGR_ResourceInfo *pxResTo
									)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResContext) 
											!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Resource Context Not Found");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	if(IFX_MMGR_ResFreeForVoipCall(pxResContext,pxResFrom) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "ResFreeForVoipCall Failed");
		return IFX_MMGR_FAIL;
	}
	IFX_MMGR_DeAllocateResourceContext(pxResContext);
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
		return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResReserveForVoipExtnCall
 *  Description       : Function is responsible for reserving all the resources  
 *						for voip-extn call.
 *  Input Values      : pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *                      pxCodec1 - Codec list 1
 *                      pxCodec2 - Codec list 2
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResReserveForVoipExtnCall(int32 *piResourceId,
														 x_IFX_MMGR_ResourceInfo *pxResFrom,
														 x_IFX_MMGR_ResourceInfo *pxResTo,
														 x_IFX_MMGR_CodecList *pxCodec1,
														 x_IFX_MMGR_CodecList *pxCodec2
														 )
{
	x_IFX_MMGR_ResourceContext *pxOldResContext;
	x_IFX_MMGR_ForkingResContext *pxForkingResContext;
	x_IFX_MMGR_ResourceContext *pxResContext;
	x_IFX_MMGR_ResourceInfo *pxResInfo;
	x_IFX_MMGR_Data_Channel *pxCoder;
	x_IFX_MMGR_CodecList *pxCodec;
    x_IFX_LM_Resource xCodecRes;
	int32 iResourceId;
    uchar8 ucCpuUsage,ucOldCpuUsage;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xCodecRes,0,sizeof(xCodecRes));
/*	if(*piResourceId != 0)
	{*/
		/* This is a forking scenario */
			if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				  pxCodec = pxCodec2;
			}
			else
			{
					pxCodec = NULL;
			}
		if(IFX_MMGR_ForkingResContextGet(*piResourceId,&pxForkingResContext)
                                                     == IFX_MMGR_SUCCESS)
		{
            /* Calculate the new cpu usage */
			if(IFX_MMGR_ComputeCpuUsage(pxResTo,pxCodec,&ucCpuUsage) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Computing the cpu Usage");
				return IFX_MMGR_FAIL;
			}
            if(ucCpuUsage > pxForkingResContext->ucMaxLoad)
            {
			    /* This is third forking call */
			    IFX_LM_LoadValFree(pxForkingResContext->ucMaxLoad);
                pxForkingResContext->ucMaxLoad = ucCpuUsage;
            }
            /* Get a free resource info slot */
			if(IFX_MMGR_FreeResInfoGet(pxForkingResContext,&pxResInfo)
                                                 != IFX_MMGR_SUCCESS)
			{
				return IFX_MMGR_FAIL;
			}
			if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				IFX_MMGR_StoreCodecInfo(pxForkingResContext,pxResInfo,pxCodec2);
				pxResTo->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
			}
      memcpy(pxResInfo,pxResTo,sizeof(x_IFX_MMGR_ResourceInfo));
			(pxForkingResContext->unNoOfEndPts)++;

		}
		else if(IFX_MMGR_ResourceContextGet(*piResourceId,&pxOldResContext) == IFX_MMGR_SUCCESS)
		{

			if(IFX_MMGR_ForkingResContextAlloc(&pxForkingResContext) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "ForkingResContext Allocation Failed");
				return IFX_MMGR_MEMORY_ERROR;
			}
			pxForkingResContext->iResourceId = pxOldResContext->iResourceId;
			pxForkingResContext->pxCoder = 
				      pxOldResContext->pxCoder;
			memcpy(&pxForkingResContext->axResInfo[0],
				&pxOldResContext->axResInfo[0],sizeof(x_IFX_MMGR_ResourceInfo));
			pxForkingResContext->unNoOfEndPts = 1;
			pxForkingResContext->eTypeOfCall = IFX_MMGR_CALL_VOIP_EXTN;
			/* Need to check the cpu usage of the new call */
			if(pxOldResContext->axResInfo[0].eResType==IFX_MMGR_FXS_RESOURCE)
			{
				if(IFX_MMGR_DisableLec(&pxOldResContext->axResInfo[0],NULL) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Enabling the LEC Failed");
					return IFX_MMGR_FAIL;
				}
			}
			else if(pxOldResContext->axResInfo[0].eResType == IFX_MMGR_DECT_RESOURCE)
			{
				/* Re-compute the cpu usage of dect res and just store it .. no need to reserve */
				/*TBD */
				/* Use valid codec list, if all the handsets are in ringback state it crashes*/
				int i;
				for (i=0; i<IFX_MMGR_CALL_LEGS; i++){
					if (pxOldResContext->apxDectCodecList[i])
						break;
				}
				if (i<IFX_MMGR_CALL_LEGS) {
					if(IFX_MMGR_StoreCodecInfo(pxForkingResContext,&pxOldResContext->axResInfo[0],
													pxOldResContext->apxDectCodecList[i]) != IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "iStore Codec Info for dect failed");
					}
				}
				else {
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "DECT codec not found");
				}
			}
			if(IFX_MMGR_ComputeCpuUsage(&pxOldResContext->axResInfo[0],pxOldResContext->apxDectCodecList[1],
															&ucOldCpuUsage) != IFX_MMGR_SUCCESS)
			{
				return IFX_MMGR_FAIL;
			}
			if(IFX_MMGR_ComputeCpuUsage(pxResTo,pxCodec,&ucCpuUsage) != IFX_MMGR_SUCCESS)
			{
				return IFX_MMGR_FAIL;
			}
			pxForkingResContext->ucMaxLoad = ucCpuUsage > ucOldCpuUsage ? 
												ucCpuUsage : ucOldCpuUsage;
			/* Get a free resource info slot */
			if(IFX_MMGR_FreeResInfoGet(pxForkingResContext,&pxResInfo) != IFX_MMGR_SUCCESS)
			{
				return IFX_MMGR_FAIL;
			}
			if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				IFX_MMGR_StoreCodecInfo(pxForkingResContext,pxResInfo,pxCodec2);
			}
			
      memcpy(pxResInfo,pxResTo,sizeof(x_IFX_MMGR_ResourceInfo));
			(pxForkingResContext->unNoOfEndPts)++;
			IFX_MMGR_DeAllocateResourceContext(pxOldResContext);
		}
		 
	else
	{
		boolean bisFxsRes = (pxResTo->eResType == IFX_MMGR_FXS_RESOURCE)?1:0;
		if(IFX_MMGR_AllocateResourceContext(&pxResContext) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Allocate Resource Context Failed");
			return IFX_MMGR_MEMORY_ERROR;
		}
		if(IFX_MMGR_AllocateCoder(&pxCoder,bisFxsRes) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Allocate Coder Failed");
			return IFX_MMGR_FAIL;
		}
		memcpy(&xCodecRes.xCodecList,pxCodec1,sizeof(x_IFX_MMGR_CodecList));
		xCodecRes.eResourceType = IFX_LM_RES_CODEC;
		if(IFX_LM_LoadReserve(&xCodecRes,NULL) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "LoadReserve for voip codecs Failed");
			IFX_MMGR_DeAllocateResourceContext(pxResContext);
			IFX_MMGR_DeAllocCoder(pxCoder);
			return IFX_MMGR_FAIL;
		}
		memcpy(pxCodec1,&xCodecRes.xCodecList,sizeof(x_IFX_MMGR_CodecList));
		pxCoder->uiServiceFlag |= IFX_MMGR_CODER_NOT_ADDED;
		pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_CODER;
		iResourceId = IFX_MMGR_GenerateresourceId();
		if(pxResTo->eResType == IFX_MMGR_FXS_RESOURCE)
		{
			if(IFX_MMGR_EnableLec(pxResTo,NULL) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Enabling LEC Failed");
				return IFX_MMGR_FAIL;
			}
		}
		if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
		{
			if(pxCodec2)
			{
				if(IFX_MMGR_LoadResDect(pxResTo->uxChannel.pxDectResource,pxCodec2) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				 "Load Reserve for Dect Codecs Failed");
					return IFX_MMGR_FAIL;
				}
				pxResContext->apxDectCodecList[1] = IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
				memcpy(pxResContext->apxDectCodecList[1],pxCodec1,sizeof(x_IFX_MMGR_CodecList));
				pxResTo->uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
			}
		}
		pxResContext->iResourceId = *piResourceId = iResourceId;
		memcpy(&pxCoder->xCodecList,pxCodec1,sizeof(x_IFX_MMGR_CodecList));
		memcpy(&pxResContext->axResInfo[0],pxResTo,sizeof(x_IFX_MMGR_ResourceInfo));
		pxResContext->pxCoder = pxCoder;
		pxResContext->eTypeOfCall = IFX_MMGR_CALL_VOIP_EXTN;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_ResFreeForVoipExtnCall
 *  Description       : Function is responsible for freeing all the resources  
 *						for voip-extn call.
 *  Input Values      : iResourceId - Resource Id.
 *						pxResFrom -  From res info
 *                      pxResFrom -  From res info
 *  Output Values     : piResourceId - ResourceId
 *  Return Value      : IFX_MMGR_SUCCESS - On Success
 *                      IFX_MMGR_FAIL - On Failure
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ResFreeForVoipExtnCall(
										int32 iResourceId,
										x_IFX_MMGR_ResourceInfo *pxResFrom,
										x_IFX_MMGR_ResourceInfo *pxResTo
										)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	x_IFX_MMGR_ForkingResContext *pxForkingResContext;
	x_IFX_LM_Resource xCodecRes ;
    x_IFX_MMGR_ResourceInfo *pxResInfo;
	x_IFX_MMGR_Data_Channel *pxCoder;
    uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	memset(&xCodecRes,0,sizeof(x_IFX_LM_Resource));
	/* Search the resource id in Resource context first */
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResContext) == 
										IFX_MMGR_SUCCESS)
	{
		/* Stop the ENC/DEC on the coder channel first */
		if(IFX_MMGR_TAPI_StopDecoding(pxResContext->pxCoder->iFd)
									 	!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Stop Decoding Failed");
			return IFX_MMGR_FAIL;
		}
		if(IFX_MMGR_TAPI_StopEncoding(pxResContext->pxCoder->iFd) 
										!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Stop Encoding Failed");
			return IFX_MMGR_FAIL;
		}
		/* Free the CPu Usage  */
		memcpy(&xCodecRes.xCodecList,
		&pxResContext->pxCoder->xCodecList,sizeof(x_IFX_MMGR_CodecList));
		xCodecRes.eResourceType = IFX_LM_RES_CODEC;
		if(IFX_LM_LoadFree(&xCodecRes) != (e_IFX_LM_Return) IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		 "Load Free Failed");
			return IFX_MMGR_FAIL;
		}

		if(pxResTo->eResType == IFX_MMGR_FXS_RESOURCE)
		{
			if(IFX_MMGR_DisableLec(pxResTo,NULL) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 "Disabling the LEC Failed");
				return IFX_MMGR_FAIL;
			}
			if(pxResContext->pxCoder == (x_IFX_MMGR_Data_Channel*)pxResTo->uxChannel.pxFxsResource->pxDC[0])
			{
				if(!pxResTo->uxChannel.pxFxsResource->pxDC[1])
				{
						pxResContext->pxCoder->uiServiceFlag &=
							~IFX_MMGR_RES_USED_AS_CODER;
				}
				else
				{
					pxResTo->uxChannel.pxFxsResource->pxDC[0] = 
							pxResTo->uxChannel.pxFxsResource->pxDC[1];
					if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxResContext->pxCoder->iFd,
         	          pxResTo->uxChannel.pxFxsResource->unChannelNum) 
										!= IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 		"Remove Data Channel from Analog Failed");
						return IFX_MMGR_FAIL;
					}
					if(pxResContext->pxCoder->uiServiceFlag & IFX_MMGR_RES_USED_AS_SIG)
					{
						pxCoder =(x_IFX_MMGR_Data_Channel*)pxResTo->uxChannel.pxFxsResource->pxDC[0];
						pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
					}
				/*(x_IFX_MMGR_Data_Channel)(pxResFrom->uxChannel.pxFxsResource->pxDC[0]).uiServiceFlag &=
						~IFX_MMGR_RES_USED_AS_CODER;*/
			 	}
			}
			else if(pxResContext->pxCoder == 
										(x_IFX_MMGR_Data_Channel*)pxResFrom->uxChannel.pxFxsResource->pxDC[1])
			{
					if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxResContext->pxCoder->iFd,
         	          pxResTo->uxChannel.pxFxsResource->unChannelNum) 
										!= IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 		"Remove Data Channel from Analog Failed");
						return IFX_MMGR_FAIL;
					}
			}
		}

		else if(pxResTo->eResType == IFX_MMGR_DECT_RESOURCE)
		{
			if(IFX_MMGR_TAPI_RemoveDataChannelFromDect(pxResContext->pxCoder->iFd,
				pxResTo->uxChannel.pxDectResource->unChannelNum) 
					    != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			 		"Remove Data Channel from Dect Failed");
			}
			if (pxResContext->apxDectCodecList[0]){
				IFX_OS_Free(pxResContext->apxDectCodecList[0]);
				pxResContext->apxDectCodecList[0] = 0;
      }
			if (pxResContext->apxDectCodecList[1]){
				IFX_OS_Free(pxResContext->apxDectCodecList[1]);
				pxResContext->apxDectCodecList[1] = 0;
			}
			IFX_MMGR_FreeDectCh(pxResContext->axResInfo[0].uxChannel.pxDectResource);
		}
		IFX_MMGR_DeAllocCoder(pxResContext->pxCoder);
		IFX_MMGR_DeAllocateResourceContext(pxResContext);
		/* No Resources are reseerved for FXS endpt so no need to do anything */
	}
	else if(IFX_MMGR_ForkingResContextGet(iResourceId,&pxForkingResContext) 
												== IFX_MMGR_SUCCESS)
	{
		if(IFX_MMGR_ResInfoGet(pxForkingResContext,pxResTo,&pxResInfo) 
												!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Coulnot find the Resource Info");
			return IFX_MMGR_FAIL;
		}
		memset(pxResInfo,0,sizeof(x_IFX_MMGR_ResourceInfo));//ASK:This is a problem
		(pxForkingResContext->unNoOfEndPts)--;
		/* If the number of endpts is one re-construct the resource context */
		if(pxForkingResContext->unNoOfEndPts == 1)
		{
			IFX_LM_LoadValueFree(pxForkingResContext->ucMaxLoad);
			if(IFX_MMGR_AllocateResourceContext(&pxResContext) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Allocate Resource Ctx Failed");
				return IFX_MMGR_FAIL;
			}
			/* Re-reserve the new cpu usage */
			/* For FXS Call its not required */
			/* For Dect we need to reserve the load */

			pxResContext->iResourceId = pxForkingResContext->iResourceId;
			pxResContext->pxCoder = pxForkingResContext->pxCoder;
			/*pxResContext->axResInfo[0].uxChannel.pxCoderResource = 
											pxForkingResContext->pxCoder;
			pxResContext->axResInfo[0].eResType = IFX_MMGR_CODER_RESOURCE;*/
			pxResContext->eTypeOfCall = IFX_MMGR_CALL_VOIP_EXTN;
			for(unCount=0; unCount < IFX_MMGR_MAX_FORK_ENDPT ; unCount++)
			{
				if(pxForkingResContext->axResInfo[unCount].uxChannel.\
								pxFxsResource != NULL)
				{
					memcpy(&pxResContext->axResInfo[0],
						   &pxForkingResContext->axResInfo[unCount],
						   sizeof(x_IFX_MMGR_ResourceInfo));
					break;
				}
			}
			if(unCount<IFX_MMGR_MAX_FORK_ENDPT 
				&& pxResContext->axResInfo[0].eResType == IFX_MMGR_DECT_RESOURCE)//ASK:How dect???
			{
				if(IFX_MMGR_LoadResDect(pxResContext->axResInfo[0].uxChannel.pxDectResource,
				pxForkingResContext->apxDectCodecList[unCount]) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Load Res for dect codecs  Failed");
					return IFX_MMGR_FAIL;
				}
				pxResContext->apxDectCodecList[0] = IFX_OS_Malloc(sizeof(x_IFX_MMGR_CodecList));
				memcpy(pxResContext->apxDectCodecList[0],
						pxForkingResContext->apxDectCodecList[unCount],
						sizeof(x_IFX_MMGR_CodecList));
				pxResContext->axResInfo[0].uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_DECT_IN_CALL;
				
			}
			IFX_MMGR_ForkingResContextDealloc(pxForkingResContext);
		}
		else
		{
			for(unCount=0; unCount < IFX_MMGR_MAX_FORK_ENDPT ; unCount++)
			{
				if(pxForkingResContext->axResInfo[unCount].\
					uxChannel.pxFxsResource == pxResTo->uxChannel.pxFxsResource)
				{
					memset(&pxForkingResContext->axResInfo[unCount],
						   0,
						   sizeof(x_IFX_MMGR_ResourceInfo));
					if(pxForkingResContext->apxDectCodecList[unCount])
					{
						IFX_OS_Free(pxForkingResContext->apxDectCodecList[unCount]);
						pxForkingResContext->apxDectCodecList[unCount] = NULL;
					}
				}
			}
		}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_ResMove(
								IN char8* pszFromId,
								IN char8* pszToId,
								IN int32 iResourceId
							/*	IN x_IFX_MMGR_CodecList *pxCodecs */
								)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	x_IFX_MMGR_ResourceInfo xResInfoTo,xResInfoFrom;
	x_IFX_MMGR_Data_Channel *pxCoder,*pxNewCoder;
	x_IFX_MMGR_Fxs_Channel *pxFxs;
	x_IFX_MMGR_Fxo_Channel *pxFxo;
	x_IFX_MMGR_Dect_Channel *pxDect;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	/* Locate the resource context */
    if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResContext) 
										!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Resource Context Not Found");
		return IFX_MMGR_FAIL;
	}
	/* Locate the endpt where this context has to be moved */
	if(IFX_MMGR_SearchEndptResource(pszToId,&xResInfoTo) 
									!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Invalid EndPt Id");
		return IFX_MMGR_FAIL;
	}
	if(IFX_MMGR_SearchEndptResource(pszFromId,&xResInfoFrom) 
									!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Invalid EndPt Id");
		return IFX_MMGR_FAIL;
	}
	pxCoder = pxResContext->pxCoder;
	/* Check if this is the only coder available with the source */
	if(xResInfoFrom.eResType == IFX_MMGR_FXS_RESOURCE)
	{
		pxFxs = xResInfoFrom.uxChannel.pxFxsResource;
		if(pxResContext->pxCoder == (x_IFX_MMGR_Data_Channel*)pxFxs->pxDC[0])
		{
			/* Allocate a coder for siganlling purpose */
			if(!pxFxs->pxDC[1])
			{
				if(IFX_MMGR_AllocateCoder(&pxNewCoder,1) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"AllocateCoder Failed");
					return IFX_MMGR_FAIL;
				}
				pxResContext->pxCoder->uiServiceFlag &= ~IFX_MMGR_RES_USED_AS_SIG;
				if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxNewCoder->iFd,
									pxFxs->unChannelNum) != IFX_MMGR_SUCCESS)
				{
					IFX_MMGR_DeAllocCoder(pxNewCoder);
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Add Data Channel To analog Failed");
					return IFX_MMGR_FAIL;
				}
				pxNewCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
				pxNewCoder->eDestResType = IFX_MMGR_FXS_RESOURCE;
				pxNewCoder->uxDestResource.pxFxs = pxFxs;
				pxFxs->pxDC[0] = (struct x_IFX_MMGR_Data_Channel *)pxNewCoder;
			}
			else
			{
			  pxFxs->pxDC[0] = pxFxs->pxDC[1];
				pxFxs->pxDC[1] = NULL;
			  pxCoder = (x_IFX_MMGR_Data_Channel *)pxFxs->pxDC[0];
				pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
			}
			if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxResContext->pxCoder->iFd,
										pxFxs->unChannelNum) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Remove Data Channel From analog Failed");
				return IFX_MMGR_FAIL;
			}
		}
		else if(pxResContext->pxCoder == (x_IFX_MMGR_Data_Channel*)pxFxs->pxDC[1])
		{
			if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxResContext->pxCoder->iFd,
										pxFxs->unChannelNum) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Remove Data Channel From analog Failed");
				return IFX_MMGR_FAIL;
			}
			pxFxs->pxDC[1] = NULL;
		}

	}
	else if(xResInfoFrom.eResType == IFX_MMGR_DECT_RESOURCE)
	{
		pxDect = xResInfoFrom.uxChannel.pxDectResource;
		if(IFX_MMGR_TAPI_RemoveDataChannelFromDect(pxResContext->pxCoder->iFd,
									pxDect->unChannelNum) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Remove Data Channel From Dect Failed");
			return IFX_MMGR_FAIL;
		}
	}

	/* Now Add the Resource to the destination */
	if(xResInfoTo.eResType == IFX_MMGR_FXS_RESOURCE)
	{
		pxFxs = xResInfoTo.uxChannel.pxFxsResource;
		/* Add the Data channel to this resource */
		if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxResContext->pxCoder->iFd,
									pxFxs->unChannelNum) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Add Data Channel To analog Failed");
			return IFX_MMGR_FAIL;
		}
		pxResContext->pxCoder->eDestResType = IFX_MMGR_FXS_RESOURCE;
		pxResContext->pxCoder->uxDestResource.pxFxs = pxFxs;

		/* Check if a signalling channel is allocated */
		if(pxFxs->pxDC[0])
		{
			pxCoder = (x_IFX_MMGR_Data_Channel *)pxFxs->pxDC[0];
			if(!(pxCoder->uiServiceFlag & IFX_MMGR_RES_USED_AS_CODER))
			{
				if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxCoder->iFd,
						pxFxs->unChannelNum) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Remove Data Channel From analog Failed");
					return IFX_MMGR_FAIL;
				}
				IFX_MMGR_DeAllocCoder(pxCoder);
				pxFxs->pxDC[0] = (struct x_IFX_MMGR_Data_Channel *)pxResContext->pxCoder;
				pxResContext->pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
			}
			else
			{
				pxFxs->pxDC[1] = (struct x_IFX_MMGR_Data_Channel *)pxResContext->pxCoder;
			}
		}
		else
		{
			pxFxs->pxDC[0] = (struct x_IFX_MMGR_Data_Channel *)pxResContext->pxCoder;
			pxFxs->uiServiceFlag |= IFX_MMGR_SIG_CH_ALLOCATED;
			pxResContext->pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
		}
		
	}
	else if(xResInfoTo.eResType == IFX_MMGR_FXO_RESOURCE)
	{
		 pxFxo = xResInfoTo.uxChannel.pxFxoResource;
		 /* Remove the signalling the signalling channel if its already 
				available */
		 pxCoder = (x_IFX_MMGR_Data_Channel *)pxFxo->pxDC;
		 if(pxCoder)
		 {
#ifndef SLIC121
				if(IFX_MMGR_TAPI_RemoveDataChannelFromPcm(pxCoder->iFd,
						pxFxo->unPcmChannelNum) != IFX_MMGR_SUCCESS)
#else
				if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxCoder->iFd,
						pxFxo->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Remove Data Channel From Pcm Failed");
					return IFX_MMGR_FAIL;
				}
				IFX_MMGR_DeAllocCoder(pxCoder);
				pxFxo->pxDC = (struct x_IFX_MMGR_Data_Channel *)pxResContext->pxCoder;
				pxResContext->pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
		 }
#ifndef SLIC121
		 /* Add the new Data Channel */
		 if(IFX_MMGR_TAPI_AddDataChannelToPcm(pxResContext->pxCoder->iFd,
									pxFxo->unPcmChannelNum) != IFX_MMGR_SUCCESS)
#else
		 if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxResContext->pxCoder->iFd,
									pxFxo->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				
		 {
		  	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Add Data Channel to Pcm Failed");
				return IFX_MMGR_FAIL;
		 }
		 pxResContext->pxCoder->eDestResType = IFX_MMGR_FXO_RESOURCE;
		 pxResContext->pxCoder->uxDestResource.pxFxo = pxFxo;
		 pxFxo->uiServiceFlag |= IFX_MMGR_SIG_CH_ALLOCATED;
		 pxResContext->eTypeOfCall = IFX_MMGR_CALL_FXO_VOIP;
	}
	else if(xResInfoTo.eResType == IFX_MMGR_DECT_RESOURCE)
	{
		//x_IFX_MMGR_CodecInfo xCodec = {0};
		//xCodec.eCodecType = IFX_MMGR_CODEC_G722_64;
		pxDect = xResInfoTo.uxChannel.pxDectResource;
		if(IFX_MMGR_TAPI_AddDataChannelToDect(pxCoder->iFd,
									pxDect->unChannelNum) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Add Data Channel To Dect Failed");
			return IFX_MMGR_FAIL;
		}
		pxCoder->eDestResType = IFX_MMGR_NONE;
	}
	memcpy(&pxResContext->axResInfo[0],&xResInfoTo,sizeof(x_IFX_MMGR_ResourceInfo));
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
  return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_DeviceEventsGet(
                           IN int32 iFd,
                           IN_OUT x_IFX_MMGR_DeviceEvents *pxDeviceEvent,
						   IN_OUT int32 *puiNoOfEndPts
                           )
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	  *puiNoOfEndPts = IFX_MMGR_MAX_FXS_CHANNELS+IFX_MMGR_MAX_FXO_CHANNELS;
    memset(pxDeviceEvent,0,(*puiNoOfEndPts)*sizeof(x_IFX_MMGR_DeviceEvents));
#ifndef SLIC121
    /* Check on which device the event has occured */
    if(iFd == stxResources.iFxoDevFd)
    {
        /* handle the Fxo event */
        if(IFX_MMGR_GetFxoEvents(iFd,pxDeviceEvent,puiNoOfEndPts) 
									!= IFX_MMGR_SUCCESS)
        {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Get Fxo Event  Failed");
            return IFX_MMGR_FAIL;
        }
    }
    else if(iFd == stxResources.iDspDevFd)
    {
        /* Handle the signalling channel and FXS events */
        if(IFX_MMGR_GetDspEvents(iFd,pxDeviceEvent,puiNoOfEndPts) 
										!= IFX_MMGR_SUCCESS)
        {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Get DSP Event  Failed");
                         return IFX_MMGR_FAIL;
        }
    }
    else
    {
        return IFX_MMGR_FAIL;
    }
#else
   if(iFd == stxResources.iDspDevFd){

     /*Fetch FXO, FXS and Signalling Channel Events.*/
     if(IFX_MMGR_GetDspEvents(iFd,pxDeviceEvent,puiNoOfEndPts) 
				!= IFX_MMGR_SUCCESS){

  			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              		"Get DSP Event  Failed");
        return IFX_MMGR_FAIL;
     }
   }else{
     return IFX_MMGR_FAIL;
    }

#endif
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_GetDspEvents
*  Description      : This Function queries the events on the device
*  Input Values     : iFd
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_GetDspEvents(
                           IN int32 iFd,
                           IN_OUT x_IFX_MMGR_DeviceEvents *pxDeviceEvent,
						   IN_OUT int32 *puiNoOfEndPts
                           )
{
	static IFX_TAPI_EVENT_t *paxEventInfo = NULL;
	IFX_TAPI_EVENT_t xEventInfo;
	uint16 unCount = 0;
  int32 iRetVal;
    x_IFX_MMGR_Data_Channel *pxCoder;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(paxEventInfo == NULL)
	{
             /* As there are 6 dect channels, so number of coders should be 4+2 */
		paxEventInfo = (IFX_TAPI_EVENT_t*)
  		IFX_OS_Malloc((stxResources.unNoOfCoders+2) * sizeof(IFX_TAPI_EVENT_t));
		if(paxEventInfo == NULL)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Memory Allocation Failed");
			return IFX_MMGR_MEMORY_ERROR;
		}
	}
#if 1
  memset(&xEventInfo,0,sizeof(xEventInfo));
  memset(paxEventInfo,0, (stxResources.unNoOfCoders+2)*sizeof(xEventInfo));
  xEventInfo.ch = IFX_TAPI_EVENT_ALL_CHANNELS;
  if(IFX_MMGR_TAPI_GetEvents(iFd,&xEventInfo)
										!= IFX_MMGR_SUCCESS){
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Get Device ALL Events Failed");
		return IFX_MMGR_FAIL;
  }
  if(xEventInfo.ch < (stxResources.unNoOfCoders+2)) {
		memcpy(&paxEventInfo[xEventInfo.ch], &xEventInfo,sizeof(xEventInfo));
	}
	else {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Event on Invalid Channel");
		return IFX_MMGR_FAIL;
	}
#else  
	paxEventInfo[0].ch = IFX_TAPI_EVENT_ALL_CHANNELS;
             /* As there are 6 dect channels, so number of coders should be 4+2 */
    for(unCount=0;unCount< (stxResources.unNoOfCoders+2);unCount++)
   {
        paxEventInfo[unCount].ch = unCount;
	    if(IFX_MMGR_TAPI_GetEvents(iFd,&paxEventInfo[unCount])
										!= IFX_MMGR_SUCCESS)
	    {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Get Device Events Failed");
		    return IFX_MMGR_FAIL;
	    }
    }
#endif
	/* Copy the end point Ids */
	for(unCount=0;unCount < stxResources.unNoOfFxs; unCount++)
	{
		strcpy(pxDeviceEvent[unCount].szEndPtId,
                stxResources.paxFxsEndPts[unCount].szEndPtId);
	}
	for(unCount= 0 ;unCount < stxResources.unNoOfFxo ; unCount++)
	{
		strcpy(pxDeviceEvent[unCount + stxResources.unNoOfFxs].szEndPtId,
                stxResources.paxFxoEndPts[unCount].szEndPtId);
	}

    /* Now gather the FXS and the SIG events */
	for(unCount=0; unCount< stxResources.unNoOfCoders;unCount++)
	{
		int16 nDigCnt = 0;
		uint16 unDestChNum=0;
    do
		{
			printf("\n Event Rcvd=%x and MMGR Expected is %x   \n",paxEventInfo[unCount].id,IFX_TAPI_EVENT_LT_GR909_RDY);
			if(paxEventInfo[unCount].id == IFX_TAPI_EVENT_LT_GR909_RDY)
			{
				if(IFX_MMGR_TAPI_GetGR909Result(
						stxResources.paxFxsEndPts[unCount].iFd,
					&pxDeviceEvent[unCount].xGR909Result)!= IFX_MMGR_SUCCESS)
				{
			        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               			 "IFX_MMGR_TAPI_GetGR909Result Failed");
				}
          		if(IFX_MMGR_TAPI_SetLineFeedStandBy(stxResources.paxFxsEndPts[unCount].iFd) != IFX_MMGR_SUCCESS)
          		{
			        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               			 "Setting Line Feed Failed");
                	return IFX_MMGR_FAIL;
          		}
				pxDeviceEvent[unCount].uiEvents |= IFX_MMGR_EVENT_GR909_RESULT;
			}
			else if((paxEventInfo[unCount].id &  IFX_TAPI_EVENT_TYPE_MASK) == 
                                            IFX_TAPI_EVENT_TYPE_FXS)
			{
				
				/* Fill up the events for the FXS Channel */
				if(paxEventInfo[unCount].id == IFX_TAPI_EVENT_FXS_ONHOOK)
				{
          if(IFX_MMGR_TAPI_SetLineFeedStandBy(stxResources.paxFxsEndPts[unCount].iFd) != IFX_MMGR_SUCCESS)
          {
			        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Setting Line Feed Failed");
                return IFX_MMGR_FAIL;
          }
					pxDeviceEvent[unCount].uiEvents |= IFX_MMGR_EVENT_ONHOOK;
				}

				if(paxEventInfo[unCount].id == IFX_TAPI_EVENT_FXS_OFFHOOK)
				{
          if(IFX_MMGR_TAPI_SetLineFeedActive(stxResources.paxFxsEndPts[unCount].iFd) != IFX_MMGR_SUCCESS)
          {
			        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "Setting Line Feed Failed");
                return IFX_MMGR_FAIL;
          }
					pxDeviceEvent[unCount].uiEvents |= IFX_MMGR_EVENT_OFFHOOK;
				}
				if(paxEventInfo[unCount].id == IFX_TAPI_EVENT_FXS_FLASH)
				{
					pxDeviceEvent[unCount].uiEvents |= IFX_MMGR_EVENT_HOOK_FLASH;
				}
				
			}
#ifdef SLIC121
      else if((paxEventInfo[unCount].id &  IFX_TAPI_EVENT_TYPE_MASK) ==
                                            IFX_TAPI_EVENT_TYPE_FXO){

        /* These are FXO events */
        if(paxEventInfo[unCount].id == IFX_TAPI_EVENT_FXO_RING_START)
        {
          pxDeviceEvent[stxResources.unNoOfFxs].uiEvents |= IFX_MMGR_EVENT_RING_START;
        }
        if(paxEventInfo[unCount].id == IFX_TAPI_EVENT_FXO_RING_STOP)
        {
          pxDeviceEvent[stxResources.unNoOfFxs].uiEvents |= IFX_MMGR_EVENT_RING_STOP;
        }
       }
#endif
			/* Fill up the events that have occured on the Signalling Channel */
			pxCoder = &stxResources.paxCoders[unCount];
			/* If this coder is not allocated to any fxo or fxs channel then
                   continue with the next iteration */
			if((pxCoder->eDestResType == IFX_MMGR_NONE) ||
				 !(pxCoder->uiServiceFlag & IFX_MMGR_RES_USED_AS_SIG))
			{
				//printf(" ##Other Event received on channel %d is %x\n",unCount,paxEventInfo[unCount].id); 
				break;
			}
			else if(pxCoder->eDestResType == IFX_MMGR_FXS_RESOURCE)
			{
				if(pxCoder->uxDestResource.pxFxs != NULL)
				unDestChNum = pxCoder->uxDestResource.pxFxs->unChannelNum;
			}
			else if(pxCoder->eDestResType == IFX_MMGR_FXO_RESOURCE)
			{
#ifndef SLIC121
				unDestChNum = pxCoder->uxDestResource.pxFxo->unChannelNum
                      +stxResources.unNoOfFxs;
#else
				unDestChNum = pxCoder->uxDestResource.pxFxo->unChannelNum;
#endif
			}
			switch(paxEventInfo[unCount].id)
			{
				case IFX_TAPI_EVENT_FAXMODEM_DIS:
					pxDeviceEvent[unDestChNum].uiEvents |= 
										IFX_MMGR_EVENT_FAXMODEM_DIS;
					break;
				case IFX_TAPI_EVENT_FAXMODEM_CED:
					pxDeviceEvent[unDestChNum].uiEvents |= 
										IFX_MMGR_EVENT_FAXMODEM_CED;
					break;
				case IFX_TAPI_EVENT_FAXMODEM_CNGFAX:
					pxDeviceEvent[unDestChNum].uiEvents |= 
										IFX_MMGR_EVENT_FAXMODEM_CNGFAX;
					break;
				case IFX_TAPI_EVENT_CID_RX_END:
					pxDeviceEvent[unDestChNum].uiEvents |= IFX_MMGR_EVENT_CID_DATA;
					break;
  			case IFX_TAPI_EVENT_CID_RX_CAS:
					pxDeviceEvent[unDestChNum].uiEvents |= IFX_MMGR_EVENT_CID_RX_CAS;
					break;
	  		case IFX_TAPI_EVENT_TONE_DET_CPT:
					pxDeviceEvent[unDestChNum].uiEvents |= 
													IFX_MMGR_EVENT_TONE_DETECTION_END;
		  		break;
				case IFX_TAPI_EVENT_DTMF_DIGIT:
                    pxDeviceEvent[unDestChNum].uiEvents |= 
												IFX_MMGR_EVENT_DIGIT;
					pxDeviceEvent[unDestChNum].aucDigits[nDigCnt++] =
						IFX_MMGR_GetAsciiVal(paxEventInfo[unCount].data.dtmf.digit);
					pxDeviceEvent[unDestChNum].ucNoOfDigits = nDigCnt;
                    break;
				case IFX_TAPI_EVENT_TONE_GEN_END:
										break;
				case IFX_TAPI_EVENT_CID_TX_INFO_END:
										break;
				case IFX_TAPI_EVENT_CID_TX_NOACK_ERR:
										break;
				
				default:
					/* The Media Manager is not interested in any other events */
					break;
				
			}
			memset(&paxEventInfo[unCount],0,sizeof(IFX_TAPI_EVENT_TYPE_t));
			paxEventInfo[unCount].ch = unCount;
			iRetVal = IFX_MMGR_TAPI_GetEvents(iFd,&paxEventInfo[unCount]);
			if((paxEventInfo[unCount].id == IFX_TAPI_EVENT_NONE) || (iRetVal < 0))
			{
					pxDeviceEvent[unDestChNum].ucNoOfDigits = nDigCnt;
					break;
			}
		}while(1);
	}
#if 0
	for(unCount=0 ; unCount< iNoOfEndPts; unCount++)
	{
		if(pxDeviceEvent[unCount].uiEvents == 0)
		{
			memcpy(&pxDeviceEvent[unCount],&pxDeviceEvent[unCount + 1],sizeof(x_IFX_MMGR_DeviceEvents));
			/* No need to memset the structure */
			pxDeviceEvent[unCount + 1].uiEvents = 0;
			(*puiNoOfEndPts)--;
		}
	}
#endif
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_GetFxoEvents
*  Description      : This Function queries the events on the device
*  Input Values     : iFd
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_GetFxoEvents(
                           IN int32 iFd,
                           IN_OUT x_IFX_MMGR_DeviceEvents *pxDeviceEvent,
						   IN_OUT int32 *puiNoOfEndPts
                           )
{
	static IFX_TAPI_EVENT_t *paxEventInfo = NULL;
    int32 iRetVal;
    uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(paxEventInfo == NULL)
	{
		paxEventInfo = (IFX_TAPI_EVENT_t*)
  		IFX_OS_Malloc(*puiNoOfEndPts * sizeof(IFX_TAPI_EVENT_t));
		if(paxEventInfo == NULL)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Memory Allocation Failed");
			return IFX_MMGR_MEMORY_ERROR;
		}
	}
	/* Copy the end point Ids */
	for(unCount=0;unCount < stxResources.unNoOfFxo; unCount++)
	{
		strcpy(pxDeviceEvent[unCount].szEndPtId,
		stxResources.paxFxoEndPts[unCount].szEndPtId);
	}
	paxEventInfo[0].ch = 0;
	if(IFX_MMGR_TAPI_GetEvents(iFd,paxEventInfo)!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Get Events From device Failed");
		return IFX_MMGR_FAIL;
	}
    for(unCount=0;unCount< stxResources.unNoOfFxo;unCount++)
	{
		do
		{
				/* These are FXO events */
				if(paxEventInfo[unCount].id == IFX_TAPI_EVENT_FXO_RING_START)
				{
					pxDeviceEvent[unCount].uiEvents |= IFX_MMGR_EVENT_RING_START;
				}
				if(paxEventInfo[unCount].id == IFX_TAPI_EVENT_FXO_RING_STOP)
				{
					pxDeviceEvent[unCount].uiEvents |= IFX_MMGR_EVENT_RING_STOP;
				}
			memset(&paxEventInfo[unCount],0,sizeof(IFX_TAPI_EVENT_TYPE_t));
			paxEventInfo[unCount].ch = unCount;
			iRetVal = IFX_MMGR_TAPI_GetEvents(iFd,&paxEventInfo[unCount]);
      printf("\n Event= %x, Fd= %d Channel= %d\n",paxEventInfo[unCount].id,iFd,paxEventInfo[unCount].ch);
			if((paxEventInfo[unCount].id == IFX_TAPI_EVENT_NONE) || (iRetVal < 0))
			{
				break;
			}
		}while(1);
	}
	*puiNoOfEndPts = stxResources.unNoOfFxo;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}   
/*! 
    \brief         This function gets the another phone offhook status.
				   This function could be used to check whether a FXS 
				   already has a FXO call setup using the hardware relay.
	\param[in]     pszEndptId - identifier of the endpoint,should be 
				   FXO endpt id.
	\param[in,out] puiApohStatus - Pointer to APOH status
	               Its bitmask of either IFX_MMGR_EVENT_APOH or 
				   IFX_MMGR_EVENT_NOPOH
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_ApohStatusGet(
										 IN char8* pszEndptId,
										 IN_OUT uint32 *puiApohStatus
										 )
{
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}



e_IFX_MMGR_Return IFX_MMGR_GetEndPtId(e_IFX_MMGR_ResourceType eResType ,
                                     uint16 unChannelNum,
                                     IN_OUT char **ppszEndPtId)
{
    uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(eResType == IFX_MMGR_FXS_RESOURCE)
	{
		for(unCount=0;unCount<stxResources.unNoOfFxs;unCount++)
		{
			if(stxResources.paxFxsEndPts[unCount].unChannelNum == unChannelNum)
			{
				*ppszEndPtId = &stxResources.paxFxsEndPts[unCount].szEndPtId[0];
				return IFX_MMGR_SUCCESS;
			}
		}
	}
	if(eResType == IFX_MMGR_FXO_RESOURCE)
	{
		for(unCount=0;unCount<stxResources.unNoOfFxo;unCount++)
		{
			if(stxResources.paxFxoEndPts[unCount].unChannelNum == unChannelNum)
			{
				*ppszEndPtId = stxResources.paxFxoEndPts[unCount].szEndPtId;
				return IFX_MMGR_SUCCESS;
			}
		}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

/*! 
    \brief         This API configures the media for a voip call.The media configuration 
	               needs to be done before starting a RTP session. This API configure 
				   the coder channel with the list of codecs provided, enables 
				   the VAD if requested for, configures the telephony event parameters,
				   configures the jitter buffer and starts enc/dec on the coder channel.
				   Additionaly it generates the ssrc and the sequence number for the RTP
				   session.
				   The out parameter contains the ssrc and sequence number of the RTP 
				   stream.
   	\param[in]     iResourceId - identifier of the resource context.
	\param[in]     pxMediaParams - pointer to media parameters.
	\param[out]     pxSessionInfo - pointer to session Info.
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_FAIL 
*/

e_IFX_MMGR_Return IFX_MMGR_MediaCfg(
							 IN int32 iResourceId,
							 IN x_IFX_MMGR_MediaParams *pxMediaParams,
							 OUT x_IFX_MMGR_SessionInfo *pxSessionInfo
							 )
{
	x_IFX_MMGR_ResourceContext *pxResourceContext = NULL;
	x_IFX_MMGR_ForkingResContext *pxForkingResContext = NULL;
	//x_IFX_MMGR_ResourceInfo *pxFrom ;
	e_IFX_MMGR_TypeOfCall eTypeOfCall=0;
    x_IFX_MMGR_Data_Channel *pxCoder=NULL,*pxDC;
	uint32 uiSSRC;
	uint16 unSeqNo;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(pxMediaParams == NULL)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid paramter");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResourceContext) != IFX_MMGR_SUCCESS)
	{
		if(IFX_MMGR_ForkingResContextGet(iResourceId,&pxForkingResContext) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
      	  	"Resource Context Not Found");
			return IFX_MMGR_INVALID_PARAMETER;
		}
	}
	if(pxResourceContext)
	{
		eTypeOfCall = pxResourceContext->eTypeOfCall;
		//pxFrom = &pxResourceContext->axResInfo[0];
      	pxCoder = pxResourceContext->pxCoder;
	}
	else if(pxForkingResContext)
	{
		eTypeOfCall = pxForkingResContext->eTypeOfCall;
      	pxCoder = pxForkingResContext->pxCoder;
	}
	switch(eTypeOfCall)
	{
		case IFX_MMGR_CALL_EXTN_EXTN:
		case IFX_MMGR_CALL_EXTN_FXO:
		case IFX_MMGR_CALL_FXO_EXTN:
			if(!pxResourceContext)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"X Connect not allowed during forking");
				return IFX_MMGR_FAIL;
			}
			if(pxMediaParams->uiOptions & IFX_MMGR_XCONNECT)
			{
				if(IFX_MMGR_XConnect(pxResourceContext) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"X Connect Failed");
					return IFX_MMGR_FAIL;
				}
			}
			if(pxMediaParams->uiOptions & IFX_MMGR_XDISCONNECT)
			{
				if(IFX_MMGR_XDisConnect(pxResourceContext) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"X DisConnect Failed");
					return IFX_MMGR_FAIL;
				}
			}
			break;
		case IFX_MMGR_CALL_EXTN_VOIP:
		case IFX_MMGR_CALL_VOIP_EXTN:
		case IFX_MMGR_CALL_FXO_VOIP:
		case IFX_MMGR_CALL_VOIP_FXO:
			uiSSRC = IFX_MMGR_GenerateSSRC();
			unSeqNo = IFX_MMGR_GenerateSeqNum();
			pxSessionInfo->uiSSRC = pxCoder->uiSSRC = uiSSRC;
			pxSessionInfo->unSeqNo = pxCoder->unSeqNo = unSeqNo;
			strcpy(pxSessionInfo->szDevChannelName,
				pxCoder->szChannelName);
			if((pxCoder->uiServiceFlag & IFX_MMGR_CODER_NOT_ADDED) && pxResourceContext)
			{
				if(pxResourceContext->axResInfo[0].eResType == 
													IFX_MMGR_FXS_RESOURCE)
				{
					if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxResourceContext->pxCoder->iFd,
						pxResourceContext->axResInfo[0].uxChannel.pxFxsResource->unChannelNum) 
									!= IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Add Data Channel to Analog Failed");
						return IFX_MMGR_FAIL;
					}
					//UGW_SW-3020 issue:Fix
					if((struct x_IFX_MMGR_Data_Channel *)pxCoder!=pxResourceContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[0]){
						pxResourceContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[1] = 
																(struct x_IFX_MMGR_Data_Channel *)pxCoder;
					}
					pxCoder->eDestResType = IFX_MMGR_FXS_RESOURCE;
					pxCoder->uxDestResource.pxFxs = 
					pxResourceContext->axResInfo[0].uxChannel.pxFxsResource;
					
					pxDC = (x_IFX_MMGR_Data_Channel*)
									pxResourceContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[0];
					if(!(pxDC->uiServiceFlag & IFX_MMGR_RES_USED_AS_CODER))
					{
						if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxDC->iFd,
							pxResourceContext->axResInfo[0].uxChannel.pxFxsResource->unChannelNum) 
										!= IFX_MMGR_SUCCESS)
						{
							IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"Remove data Channel from Analog Failed");
							return IFX_MMGR_FAIL;
						}
						if(pxDC->uiServiceFlag & IFX_MMGR_RES_USED_AS_SIG)
						{
							pxCoder->uiServiceFlag |= IFX_MMGR_RES_USED_AS_SIG;
						}
						IFX_MMGR_DeAllocCoder(pxDC);
						pxResourceContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[0]
									 	= (struct x_IFX_MMGR_Data_Channel *)pxCoder;
						pxResourceContext->axResInfo[0].uxChannel.pxFxsResource->pxDC[1]
									 	= NULL;
					}
				}
				else if(pxResourceContext->axResInfo[0].eResType == 
													IFX_MMGR_DECT_RESOURCE)
				{
					if(IFX_MMGR_TAPI_AddDataChannelToDect(pxResourceContext->pxCoder->iFd,
						pxResourceContext->axResInfo[0].uxChannel.pxDectResource->unChannelNum) 
									!= IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"Add data channel to Analog Failed");
						return IFX_MMGR_FAIL;
					}
				}
				pxResourceContext->pxCoder->uiServiceFlag &= ~IFX_MMGR_CODER_NOT_ADDED;
			}
#if 0
				if(pxResourceContext->axResInfo[0].eResType == 
													IFX_MMGR_DECT_RESOURCE)
				{
				if(IFX_MMGR_TAPI_DectActivate(pxResourceContext->axResInfo[0].uxChannel.pxDectResource->iFd) != IFX_MMGR_SUCCESS)
				{
		//IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
      		printf( "Dect Channel activation Failed");
					return IFX_MMGR_FAIL;
				}
				}
#endif
			if(IFX_MMGR_ConfigureCoderSettings(pxCoder,
				pxMediaParams) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Configuring the Coder Settings Failed");
				return IFX_MMGR_FAIL;
			}
			break;
	}
	if(pxResourceContext)
	{
		pxResourceContext->uiServiceFlag |= IFX_MMGR_SESSION_CFGD;
	}
	else if(pxForkingResContext)
	{
		pxForkingResContext->uiServiceFlag |= IFX_MMGR_SESSION_CFGD;
	}

	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*!
    \brief         This API modifies the on-going media session.   
                   Voip Call hold/resume can be realized by using this 
                   API. 
   	\param[in]     iResourceId - identifier of the resource context.
	\param[in]     pxMediaParams - pointer to media parameters.
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_FAIL 
*/

e_IFX_MMGR_Return IFX_MMGR_MediaModify(
							 IN int32 iResourceId,
							 IN x_IFX_MMGR_MediaParams* pxMediaParams
							 )
{
	x_IFX_MMGR_ResourceContext *pxResourceContext = NULL;
	//x_IFX_MMGR_ResourceInfo *pxFrom ;
	x_IFX_MMGR_ForkingResContext *pxForkingResContext = NULL;
	e_IFX_MMGR_TypeOfCall eTypeOfCall=0;
	x_IFX_MMGR_Data_Channel *pxCoder=NULL;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(pxMediaParams == NULL)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Parameter");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResourceContext) != IFX_MMGR_SUCCESS)
	{
		if(IFX_MMGR_ForkingResContextGet(iResourceId,&pxForkingResContext) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
      	  		"Resource Context Not Found");
			return IFX_MMGR_INVALID_PARAMETER;
		}
	}
	if(pxResourceContext)
	{
		if(!(pxResourceContext->uiServiceFlag & IFX_MMGR_SESSION_CFGD))
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Media Session Not Started");
			return IFX_MMGR_FAIL;
		}
		eTypeOfCall = pxResourceContext->eTypeOfCall;
		//pxFrom = &pxResourceContext->axResInfo[0];
      	pxCoder = pxResourceContext->pxCoder;
	}
	else if(pxForkingResContext)
	{
		if(!(pxForkingResContext->uiServiceFlag & IFX_MMGR_SESSION_CFGD))
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Media Session Not Started");
			return IFX_MMGR_FAIL;
		}
		eTypeOfCall = pxForkingResContext->eTypeOfCall;
      	pxCoder = pxForkingResContext->pxCoder;
	}
	switch(eTypeOfCall)
	{
		case IFX_MMGR_CALL_EXTN_EXTN:
		case IFX_MMGR_CALL_EXTN_FXO:
		case IFX_MMGR_CALL_FXO_EXTN:
			if(pxMediaParams->uiOptions & IFX_MMGR_XCONNECT)
			{
				if(pxResourceContext==NULL || IFX_MMGR_XConnect(pxResourceContext) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"X Connect Failed");
					return IFX_MMGR_FAIL;
				}
			}
			if(pxMediaParams->uiOptions & IFX_MMGR_XDISCONNECT)
			{
				if(pxResourceContext==NULL || IFX_MMGR_XDisConnect(pxResourceContext) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"X DisConnect Failed");
					return IFX_MMGR_FAIL;
				}
			}
			break;
		case IFX_MMGR_CALL_EXTN_VOIP:
		case IFX_MMGR_CALL_VOIP_EXTN:
		case IFX_MMGR_CALL_FXO_VOIP:
		case IFX_MMGR_CALL_VOIP_FXO:
			if(IFX_MMGR_ConfigureCoderSettings(pxCoder,
										  pxMediaParams) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Configuring the Coder Settings Failed");
				return IFX_MMGR_FAIL;
			}
			break;
        default:
            return IFX_MMGR_FAIL;
    }
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}
    


e_IFX_MMGR_Return IFX_MMGR_ConfigureCoderSettings(
									x_IFX_MMGR_Data_Channel *pxCoder,
									x_IFX_MMGR_MediaParams *pxMediaParams)
{
	x_IFX_MMGR_CodecList xCodecList;
	boolean bRtpCfgReq = IFX_FALSE;
	int32 iFd ;
	iFd = pxCoder->iFd;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(pxMediaParams->uiOptions & IFX_MMGR_STOP_ENCODING)
	{
		if(IFX_MMGR_TAPI_StopEncoding(iFd) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Stop Encoding Failed");
			return IFX_MMGR_FAIL;
		}
	}
	if(pxMediaParams->uiOptions & IFX_MMGR_STOP_DECODING)
	{
		if(IFX_MMGR_TAPI_StopDecoding(iFd) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Stop Decoding Failed");
			return IFX_MMGR_FAIL;
		}
	}
	if(pxMediaParams->uiOptions & IFX_MMGR_JB_CONFIGURE)
	{
  		memcpy(&pxCoder->xJbCfg,
						 &pxMediaParams->xJBCfg,
						sizeof(x_IFX_MMGR_JitterBuffer_Conf));
			if(IFX_MMGR_TAPI_JitterBufferConfig(iFd,
											&pxCoder->xJbCfg) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"JB Cfg  Failed");
				return IFX_MMGR_FAIL;
			}
	}
	if(pxMediaParams->uiOptions & IFX_MMGR_TELEPHONY_EVENT_CONFIG)
	{
		 memcpy(&pxCoder->xTelEventInfo,
						&pxMediaParams->xTelEventInfo,
						sizeof(x_IFX_MMGR_TelephonyEvent_Info));
			bRtpCfgReq = IFX_TRUE;
	}
	if(bRtpCfgReq)
	{
			if(IFX_MMGR_TAPI_RtpConfig(iFd,pxCoder->unSeqNo,
										pxCoder->uiSSRC,
									&pxMediaParams->xTelEventInfo) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Rtp Config Failed");
				return IFX_MMGR_FAIL;
			}
	}
	if(pxMediaParams->uiOptions & IFX_MMGR_UPDATE_CODEC_LIST)
	{
#if 0
			if(IFX_MMGR_IsUpdateCodecPossible(pxResContext,&pxMediaParams->xCodecList)
										 					!= IFX_MMGR_SUCCESS)
			{
					printf("Updatation of Codecs failed\n");
					return IFX_MMGR_FAIL;
			}
#endif
			memcpy(&xCodecList,&pxMediaParams->xCodecList,sizeof(x_IFX_MMGR_CodecList));
			pxCoder->pxCodecList = &xCodecList;
			if(IFX_MMGR_TAPI_PayLoadTblSet(iFd,&xCodecList) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Updating the payload table Failed");
				return IFX_MMGR_FAIL;
			}
	}
	if(pxMediaParams->uiOptions & IFX_MMGR_SET_ENC_TYPE)
	{
		if((pxCoder->xCodecList.axCodecs[0].\
				eCodecType != IFX_MMGR_CODEC_NONE)
				|| (pxCoder->xCodecList.\
				axCodecs[0].eCodecType != IFX_MMGR_CODEC_T38))
		{
		if(IFX_MMGR_TAPI_StopDecoding(iFd) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Stop Decoding Failed");
			return IFX_MMGR_FAIL;
		}
		if(IFX_MMGR_TAPI_StopEncoding(iFd) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Stop Encoding Failed");
			return IFX_MMGR_FAIL;
		}
			if(IFX_MMGR_TAPI_SetEncType(iFd,
						&pxMediaParams->xCodecList.axCodecs[0]) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"SetEncType Failed");
				return IFX_MMGR_FAIL;
			}
		}
	}
	if(pxMediaParams->uiOptions & IFX_MMGR_START_ENCODING)
	{
		if((pxCoder->xCodecList.axCodecs[0].\
			eCodecType != IFX_MMGR_CODEC_NONE)
			|| (pxCoder->xCodecList.\
			axCodecs[0].eCodecType != IFX_MMGR_CODEC_T38))
		{
		if(IFX_MMGR_TAPI_StopDecoding(iFd) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Stop Decoding Failed");
			return IFX_MMGR_FAIL;
		}
		if(IFX_MMGR_TAPI_StopEncoding(iFd) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Stop Encoding Failed");
			return IFX_MMGR_FAIL;
		}
			if(IFX_MMGR_TAPI_SetEncType(iFd,
						&pxMediaParams->xCodecList.axCodecs[0]) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"SetEncType Failed");
				return IFX_MMGR_FAIL;
			}
			if(IFX_MMGR_TAPI_StartEncoding(iFd) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Start Encoding Failed");
				return IFX_MMGR_FAIL;
			}
		/* TBD */
			if(IFX_MMGR_TAPI_StartDecoding(iFd) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Start Decoding Failed");
				return IFX_MMGR_FAIL;
			}
		}
	}
	if(pxMediaParams->uiOptions & IFX_MMGR_SID_ACTIVATE)
	{
		if(IFX_MMGR_TAPI_ConfigureVad(iFd, 1) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Vad Cfg Failed");
			return IFX_MMGR_FAIL;
		}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
                  __FUNCTION__,"Success");
		return IFX_MMGR_SUCCESS;
}

e_IFX_MMGR_Return IFX_MMGR_IsUpdateCodecPossible(
											x_IFX_MMGR_ResourceContext *pxResContext,
										 	x_IFX_MMGR_CodecList *pxNewList)
{
		x_IFX_MMGR_CodecList *pxCodecList;
		x_IFX_MMGR_CodecInfo *pxNewCodecInfo;
		uint16 unCount,unCtr;
		boolean bCodecMatched = IFX_TRUE;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
		pxCodecList = &pxResContext->pxCoder->xCodecList;
		for(unCount=0;unCount < pxNewList->ucNoOfCodecs; unCount++)
		{
				if(bCodecMatched == IFX_FALSE)
								break;
				pxNewCodecInfo = &pxNewList->axCodecs[unCount];
				for(unCtr=0; unCtr < pxCodecList->ucNoOfCodecs; unCtr++)
				{
						if(pxNewCodecInfo->eCodecType == pxCodecList->axCodecs[unCtr].eCodecType)
						{
								bCodecMatched = IFX_TRUE;
						}
						else
						{
								bCodecMatched = IFX_FALSE;
						}
				}
		 }
		if(bCodecMatched)
		{
			IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
            	      __FUNCTION__,"Success");
			return IFX_MMGR_SUCCESS;
		}
		else
		{
			IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
            	      __FUNCTION__,"Failure");
			return IFX_MMGR_FAIL;
		}
}
e_IFX_MMGR_Return IFX_MMGR_XConnect(x_IFX_MMGR_ResourceContext *pxResContext)
{
	x_IFX_MMGR_ResourceInfo *pxFrom , *pxTo;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	pxFrom = &pxResContext->axResInfo[0];
	pxTo = &pxResContext->axResInfo[1];
	if(pxResContext->uiServiceFlag & IFX_MMGR_XCONNECTED)
	{
		/* Resources already connected */
		return IFX_MMGR_SUCCESS;
	}
	if(pxFrom->eResType == IFX_MMGR_FXS_RESOURCE)
	{
		if(pxTo->eResType == IFX_MMGR_FXS_RESOURCE)
		{
			if(IFX_MMGR_TAPI_AddAnalogToAnalog(pxFrom->uxChannel.pxFxsResource->iFd,
					pxTo->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Analog to Analog  Failed");
				return IFX_MMGR_FAIL;
			}
		}
		if(pxTo->eResType == IFX_MMGR_DECT_RESOURCE)
		{
#if 0
				if(IFX_MMGR_TAPI_DectActivate(pxTo->uxChannel.pxDectResource->iFd) != IFX_MMGR_SUCCESS)
				{
		//IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
      		printf( "Dect Channel activation Failed");
					return IFX_MMGR_FAIL;
				}
#endif
				if(IFX_MMGR_TAPI_AddDectToAnalog(pxTo->uxChannel.pxDectResource->iFd,
					pxFrom->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Dect to Analog  Failed");
					return IFX_MMGR_FAIL;
				}

		}
		if(pxTo->eResType == IFX_MMGR_FXO_RESOURCE)
		{
#ifndef SLIC121
			if(IFX_MMGR_TAPI_AddPcmToAnalog(pxTo->uxChannel.pxFxoResource->iPcmFd,
				pxFrom->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#else
			if(IFX_MMGR_TAPI_AddAnalogToAnalog(pxTo->uxChannel.pxFxoResource->iFd,
				pxFrom->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Pcm/Analog to Analog  Failed");
				return IFX_MMGR_FAIL;
			}
		}
	}
	else if(pxFrom->eResType == IFX_MMGR_FXO_RESOURCE)
	{
		if(pxTo->eResType == IFX_MMGR_FXS_RESOURCE)
		{
#ifndef SLIC121
			if(IFX_MMGR_TAPI_AddPcmToAnalog(pxFrom->uxChannel.pxFxoResource->iPcmFd,
					pxTo->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#else
			if(IFX_MMGR_TAPI_AddAnalogToAnalog(pxFrom->uxChannel.pxFxoResource->iFd,
					pxTo->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Pcm/Analog to Analog  Failed");
				return IFX_MMGR_FAIL;
			}
		}
		if(pxTo->eResType == IFX_MMGR_DECT_RESOURCE)
		{
#ifndef SLIC121
			if(IFX_MMGR_TAPI_AddPcmToDect(pxFrom->uxChannel.pxFxoResource->iPcmFd,
				pxTo->uxChannel.pxDectResource->unChannelNum) != IFX_MMGR_SUCCESS)
#else

		  if(IFX_MMGR_TAPI_AddDectToAnalog(pxTo->uxChannel.pxDectResource->iFd,
         pxFrom->uxChannel.pxFxoResource->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Pcm/Analog to Dect  Failed");
				return IFX_MMGR_FAIL;
			}
		}
	}
	else if(pxFrom->eResType == IFX_MMGR_DECT_RESOURCE)
	{
			if(pxTo->eResType == IFX_MMGR_FXS_RESOURCE)
			{
#ifdef CVOIP_SUPPORT //asdf
				printf("MMGR-CV, addpcmto analog, pcmfd:%d, channelname:%s, fxschannelname:%s\n",pxFrom->uxChannel.pxDectResource->iFd,pxFrom->uxChannel.pxDectResource->szChannelName, pxTo->uxChannel.pxFxsResource->szChannelName);
				if(IFX_MMGR_TAPI_AddPcmToAnalog(pxFrom->uxChannel.pxDectResource->iFd,
								pxTo->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#else
				if(IFX_MMGR_TAPI_AddDectToAnalog(pxFrom->uxChannel.pxDectResource->iFd,
					pxTo->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Dect to Analog  Failed");
					return IFX_MMGR_FAIL;
				}		
			}else
			if(pxTo->eResType == IFX_MMGR_FXO_RESOURCE)
			{
#ifndef SLIC121
				if(IFX_MMGR_TAPI_AddPcmToDect(pxTo->uxChannel.pxFxoResource->iPcmFd,
					pxFrom->uxChannel.pxDectResource->unChannelNum) != IFX_MMGR_SUCCESS)
#else
				if(IFX_MMGR_TAPI_AddDectToAnalog(pxFrom->uxChannel.pxDectResource->iFd,
					 pxTo->uxChannel.pxFxoResource->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Pcm/Analog to Dect  Failed");
					return IFX_MMGR_FAIL;
				}		
			}else
			if(pxTo->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				if(IFX_MMGR_TAPI_AddDectToDect(pxFrom->uxChannel.pxDectResource->iFd,
					pxTo->uxChannel.pxDectResource->unChannelNum) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Dect to Dect  Failed");
					return IFX_MMGR_FAIL;
				}		
			}
	}
	else 
	{
			return IFX_MMGR_FAIL;
	}
	pxResContext->uiServiceFlag |= IFX_MMGR_XCONNECTED;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

e_IFX_MMGR_Return IFX_MMGR_XDisConnect(x_IFX_MMGR_ResourceContext *pxResContext)
{
	x_IFX_MMGR_ResourceInfo *pxFrom , *pxTo;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	pxFrom = &pxResContext->axResInfo[0];
	pxTo = &pxResContext->axResInfo[1];
	if((pxResContext->uiServiceFlag & IFX_MMGR_XCONNECTED) == 0)
	{
		/* Resources already disconnected */
		return IFX_MMGR_SUCCESS;
	}
	if(pxFrom->eResType == IFX_MMGR_FXS_RESOURCE)
	{
		if(pxTo->eResType == IFX_MMGR_FXS_RESOURCE)
		{
			if(IFX_MMGR_TAPI_RemoveAnalogFromAnalog(pxFrom->uxChannel.pxFxsResource->iFd,
					pxTo->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Remove Analog from Analog  Failed");
				return IFX_MMGR_FAIL;
			}
		}
		if(pxTo->eResType == IFX_MMGR_DECT_RESOURCE)
		{
				if(IFX_MMGR_TAPI_RemoveDectFromAnalog(pxTo->uxChannel.pxDectResource->iFd,
					pxFrom->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Remove Dect from Analog  Failed");
					return IFX_MMGR_FAIL;
				}
		}
		if(pxTo->eResType == IFX_MMGR_FXO_RESOURCE)
		{
#ifndef SLIC121
			if(IFX_MMGR_TAPI_RemovePcmFromAnalog(pxTo->uxChannel.pxFxoResource->iPcmFd,
				pxFrom->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#else
			if(IFX_MMGR_TAPI_RemoveAnalogFromAnalog(pxTo->uxChannel.pxFxoResource->iFd,
				pxFrom->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Remove Pcm/Analog from Analog  Failed");
				return IFX_MMGR_FAIL;
			}
		}
	}
	if(pxFrom->eResType == IFX_MMGR_FXO_RESOURCE)
	{
		if(pxTo->eResType == IFX_MMGR_FXS_RESOURCE)
		{
#ifndef SLIC121
			if(IFX_MMGR_TAPI_RemovePcmFromAnalog(pxFrom->uxChannel.pxFxoResource->iPcmFd,
					pxTo->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#else
			if(IFX_MMGR_TAPI_RemoveAnalogFromAnalog(pxFrom->uxChannel.pxFxoResource->iFd,
					pxTo->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Remove Pcm/Analog from Analog  Failed");
				return IFX_MMGR_FAIL;
			}
		}
		if(pxTo->eResType == IFX_MMGR_DECT_RESOURCE)
		{
#ifndef SLIC121
				if(IFX_MMGR_TAPI_RemovePcmFromDect(pxFrom->uxChannel.pxFxoResource->iPcmFd,
					pxTo->uxChannel.pxDectResource->unChannelNum) != IFX_MMGR_SUCCESS)
#else
				if(IFX_MMGR_TAPI_RemoveDectFromAnalog(pxTo->uxChannel.pxDectResource->iFd,
					pxFrom->uxChannel.pxFxoResource->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Remove Pcm/Analog from  Dect  Failed");
					return IFX_MMGR_FAIL;
				}		
		}
	}
	if(pxFrom->eResType == IFX_MMGR_DECT_RESOURCE)
	{
			if(pxTo->eResType == IFX_MMGR_FXS_RESOURCE)
			{
				if(IFX_MMGR_TAPI_RemoveDectFromAnalog(pxFrom->uxChannel.pxDectResource->iFd,
						pxTo->uxChannel.pxFxsResource->unChannelNum) != IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Remove Dect from Analog  Failed");
						return IFX_MMGR_FAIL;
					}
			}else
			if(pxTo->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				if(IFX_MMGR_TAPI_RemoveDectFromDect(pxFrom->uxChannel.pxDectResource->iFd,
						pxTo->uxChannel.pxDectResource->unChannelNum) != IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Remove Dect from Dect  Failed");
						return IFX_MMGR_FAIL;
					}
			}
			else
			if(pxTo->eResType == IFX_MMGR_FXO_RESOURCE)
			{
#ifndef SLIC121
				if(IFX_MMGR_TAPI_RemovePcmFromDect(pxTo->uxChannel.pxFxoResource->iPcmFd,
					pxFrom->uxChannel.pxDectResource->unChannelNum) != IFX_MMGR_SUCCESS)
#else
				if(IFX_MMGR_TAPI_RemoveDectFromAnalog(pxFrom->uxChannel.pxDectResource->iFd,
          pxTo->uxChannel.pxFxoResource->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Remove Pcm/Analog from Dect  Failed");
					return IFX_MMGR_FAIL;
				}		
			}
	}
	pxResContext->uiServiceFlag &= ~IFX_MMGR_XCONNECTED;
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

/*!
    \brief         This API plays a DTMF tone locally. This API could be used by FXO 
	               agents which sometimes needs to send DTMF tones to the CO. 
    \param[in]     pszEndptId - identifier of the endpoint
	\param[in]     ucDigit - ascii value of digit whose dtmf tone has to be played.
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no signalling resource is
				   already allocated or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_DtmfPlayLocal(
								 IN char8* pszEndptId,
								 IN uchar8 ucDigit
								 )
{
	uchar8 ucToneIndex;
	int32 iFd;
	x_IFX_MMGR_ResourceInfo xResInfo;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_SearchEndptResource(pszEndptId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Invalid EndPt Id");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	ucToneIndex = IFX_MMGR_GetDtmfIndex(ucDigit);
	iFd = IFX_MMGR_GetSigFd(pszEndptId);
	if(xResInfo.eResType == IFX_MMGR_FXS_RESOURCE || xResInfo.eResType == IFX_MMGR_FXO_RESOURCE)
	{
		if(IFX_MMGR_TAPI_PlayTone(iFd,ucToneIndex)
									!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"PlayTone Failed");
			return IFX_MMGR_FAIL;
		}
	}
	else if(xResInfo.eResType == IFX_MMGR_DECT_RESOURCE)
	{
		if(IFX_MMGR_TAPI_DectPlayTone(iFd,ucToneIndex)
									!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"PlayTone Failed");
			return IFX_MMGR_FAIL;
		}
	}

	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
	
}
/*!
    \brief         This API stops a DTMF tone locally.  
    \param[in]     pszEndptId - identifier of the endpoint
	\return        IFX_MMGR_SUCCESS 
*/
e_IFX_MMGR_Return IFX_MMGR_DtmfStopLocal(
								 IN char8* pszEndptId
									 )
{
	int32 iFd;
	x_IFX_MMGR_ResourceInfo xResInfo;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_SearchEndptResource(pszEndptId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Invalid EndPt Id");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	iFd = IFX_MMGR_GetSigFd(pszEndptId);
	if(xResInfo.eResType == IFX_MMGR_FXS_RESOURCE || xResInfo.eResType == IFX_MMGR_FXO_RESOURCE)
	{
		if(IFX_MMGR_TAPI_StopTone(iFd)
									!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"PlayTone Failed");
			return IFX_MMGR_FAIL;
		}
	}
	else if(xResInfo.eResType == IFX_MMGR_DECT_RESOURCE)
	{
		if(IFX_MMGR_TAPI_DectStopTone(iFd)
									!= IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"PlayTone Failed");
			return IFX_MMGR_FAIL;
		}
	}
	
	return IFX_MMGR_SUCCESS;
}
/*!
    \brief         This API plays a DTMF tone remotely. 
    \param[in]     iResId - identifier of the resource
	\param[in]     ucDigit - ascii value of digit whose dtmf tone has to be played.
	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no signalling resource is
				   already allocated or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_DtmfPlayRemote(
								 IN int32 iResId,
								 IN char8* pszRemoteId,
								 IN char8* pszLocalId,
								 IN uchar8 ucDigit
								 )
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	x_IFX_MMGR_ResourceInfo xResInfoLoc, xResInfoRem;
	int32 iFd=0;
	uchar8 ucToneIndex;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    if(IFX_MMGR_ResourceContextGet(iResId,&pxResContext) != IFX_MMGR_SUCCESS)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Could not find the Resource Context");
        return IFX_MMGR_FAIL;
    }
	if(IFX_MMGR_SearchEndptResource(pszLocalId,&xResInfoLoc) != IFX_MMGR_SUCCESS)
	{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
      			"Invalid EndPt Id");
			return IFX_MMGR_INVALID_PARAMETER;
	}
	if(pxResContext->eTypeOfCall == IFX_MMGR_CALL_EXTN_EXTN ||
			pxResContext->eTypeOfCall == IFX_MMGR_CALL_EXTN_FXO ||
			pxResContext->eTypeOfCall == IFX_MMGR_CALL_FXO_EXTN)
	{
		if(IFX_MMGR_SearchEndptResource(pszRemoteId,&xResInfoRem) != IFX_MMGR_SUCCESS)
		{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
      			"Invalid EndPt Id");
				return IFX_MMGR_INVALID_PARAMETER;
		}
		
		iFd = IFX_MMGR_GetSigFd(pszRemoteId);
	}
	ucToneIndex = IFX_MMGR_GetDtmfIndex(ucDigit);
	switch(pxResContext->eTypeOfCall)
	{
			case IFX_MMGR_CALL_VOIP_FXO:
			case IFX_MMGR_CALL_FXO_VOIP:
				/* Do nothing */
				break;
			case IFX_MMGR_CALL_EXTN_EXTN:
				if(xResInfoRem.eResType == IFX_MMGR_FXS_RESOURCE)
				{
					if(xResInfoLoc.eResType == IFX_MMGR_DECT_RESOURCE)
					{
						if(xResInfoLoc.uxChannel.pxDectResource->uiServiceFlag & IFX_MMGR_TONE_PLAYING)
						{
								IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"Tone already being played");
								return IFX_MMGR_FAIL;
						}
						
						else if(IFX_MMGR_TAPI_PlayTone(iFd,ucToneIndex)
										!= IFX_MMGR_SUCCESS)
						{
							IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"PlayTone Failed");
							return IFX_MMGR_FAIL;
						}
						//xResInfoLoc.uxChannel.pxFxoResource->uiServiceFlag |= IFX_MMGR_TONE_PLAYING;
					}
				}
				if(xResInfoRem.eResType == IFX_MMGR_DECT_RESOURCE)
				{
					if(xResInfoLoc.eResType == IFX_MMGR_DECT_RESOURCE)
					{
						if(xResInfoLoc.uxChannel.pxDectResource->uiServiceFlag & IFX_MMGR_TONE_PLAYING)
						{
								IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"Tone already being played");
								return IFX_MMGR_FAIL;
						}
						if(IFX_MMGR_TAPI_DectPlayTone(iFd,ucToneIndex)
										!= IFX_MMGR_SUCCESS)
						{
							IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"PlayTone Failed");
							return IFX_MMGR_FAIL;
						}
						//xResInfoLoc.uxChannel.pxDectResource->uiServiceFlag |= IFX_MMGR_TONE_PLAYING;
					}
				}
				break;
			case IFX_MMGR_CALL_EXTN_VOIP:
			case IFX_MMGR_CALL_VOIP_EXTN:
				if(xResInfoLoc.eResType == IFX_MMGR_DECT_RESOURCE)
				{
#if 1
						if(pxResContext->pxCoder->uiServiceFlag & IFX_MMGR_TONE_PLAYING)
						{
								IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"Tone already being played");
								return IFX_MMGR_FAIL;
						}
						/* send the RFC2833 is  set , generate the packet */

						if(pxResContext->pxCoder->xTelEventInfo.\
								eEventTransMode == 
								IFX_MMGR_TEL_EVENT_RFC_2833)
						{
							if(IFX_MMGR_TAPI_GenerateRFC2833Packet(
										pxResContext->pxCoder->iFd,
										ucDigit) != IFX_MMGR_SUCCESS)
							{
								IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        							"RFC 2833 packet generation Failed");
								return IFX_MMGR_FAIL;
							}
						}
						else if(pxResContext->pxCoder->xTelEventInfo.\
								eEventTransMode == 
								IFX_MMGR_TEL_EVENT_VOICE_IN_BAND)
						{	
							if(IFX_MMGR_TAPI_PlayToneNetwork(pxResContext->pxCoder->iFd,
										ucToneIndex)
										!= IFX_MMGR_SUCCESS)
							{
								IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        							"PlayTone Failed");
								return IFX_MMGR_FAIL;
							}
						}
						else if(pxResContext->pxCoder->xTelEventInfo.\
								eEventTransMode == 
								IFX_MMGR_TEL_EVENT_VOICE_IN_BAND_RFC_2833)
						{	
							if(IFX_MMGR_TAPI_GenerateRFC2833Packet(
										pxResContext->pxCoder->iFd,ucDigit) 
									     != IFX_MMGR_SUCCESS)
							{
								IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        							"RFC 2833 packet generation Failed");
								return IFX_MMGR_FAIL;
							}
							if(IFX_MMGR_TAPI_PlayToneNetwork(pxResContext->pxCoder->iFd,
										ucToneIndex)
										!= IFX_MMGR_SUCCESS)
							{
								IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        							"PlayTone Failed");
								return IFX_MMGR_FAIL;
							}
						}
#endif
	//					pxResContext->pxCoder->uiServiceFlag |= IFX_MMGR_TONE_PLAYING;
				}
				break;
			case IFX_MMGR_CALL_EXTN_FXO:
				if(xResInfoLoc.eResType == IFX_MMGR_DECT_RESOURCE)
				{
						if(xResInfoRem.uxChannel.pxFxoResource->uiServiceFlag & IFX_MMGR_TONE_PLAYING)
						{
								IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"Tone already being played");
								return IFX_MMGR_FAIL;
						}
						else if(IFX_MMGR_TAPI_PlayTone(iFd,ucToneIndex)
										!= IFX_MMGR_SUCCESS)
						{
							IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"PlayTone Failed");
							return IFX_MMGR_FAIL;
						}
						//xResInfoRem.uxChannel.pxFxoResource->uiServiceFlag |= IFX_MMGR_TONE_PLAYING;
				}
				break;
			case IFX_MMGR_CALL_FXO_EXTN:
				if(xResInfoRem.eResType == IFX_MMGR_DECT_RESOURCE)
				{
						if(xResInfoLoc.uxChannel.pxFxoResource->uiServiceFlag & IFX_MMGR_TONE_PLAYING)
						{
								IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"Tone already being played");
								return IFX_MMGR_FAIL;
						}
						else if(IFX_MMGR_TAPI_DectPlayTone(iFd,ucToneIndex)
										!= IFX_MMGR_SUCCESS)
						{
							IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"PlayTone Failed");
							return IFX_MMGR_FAIL;
						}
//						xResInfoLoc.uxChannel.pxFxoResource->uiServiceFlag |= IFX_MMGR_TONE_PLAYING;
				}
				break;
			default:
							IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        						"Invalid Call Type");
				return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}

/*!
    \brief         This API stops a DTMF tone remotely.  
    \param[in]     pszEndptId - identifier of the endpoint
	\return        IFX_MMGR_SUCCESS 
*/
e_IFX_MMGR_Return IFX_MMGR_DtmfStopRemote(
								 IN int32 iResId
									 )
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    if(IFX_MMGR_ResourceContextGet(iResId,&pxResContext) != IFX_MMGR_SUCCESS)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Could not find the Resource Context");
        return IFX_MMGR_FAIL;
    }
	
	return IFX_MMGR_TAPI_StopTone(pxResContext->pxCoder->iFd);
}

int32 IFX_MMGR_GetSigFd(char8* pszEndPtId)
{
	int32 iFd = -1;
	x_IFX_MMGR_ResourceInfo xResInfo;
    x_IFX_MMGR_Data_Channel *pxDC;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Invalid EndPt Id");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	if(xResInfo.eResType == IFX_MMGR_FXS_RESOURCE)
	{
        pxDC = (x_IFX_MMGR_Data_Channel*)xResInfo.uxChannel.pxFxsResource->pxDC[0];
        if(!pxDC)
        {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Signalling Channel not allocated");
            return IFX_MMGR_NO_RESOURCE;
        }
		iFd = pxDC->iFd;
		
	}
	if(xResInfo.eResType == IFX_MMGR_FXO_RESOURCE)
	{
        pxDC = (x_IFX_MMGR_Data_Channel*)xResInfo.uxChannel.pxFxoResource->pxDC;
        if(!pxDC)
        {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Signalling Channel not allocated");
            return IFX_MMGR_NO_RESOURCE;
        }
		iFd = pxDC->iFd;
	}
	if(xResInfo.eResType == IFX_MMGR_DECT_RESOURCE)
	{
		iFd = xResInfo.uxChannel.pxDectResource->iFd;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
	return iFd;
}
int32 IFX_MMGR_GetFd(char8* pszEndPtId)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid EndPt Id");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	if(xResInfo.eResType == IFX_MMGR_FXS_RESOURCE)
	{
        return xResInfo.uxChannel.pxFxsResource->iFd;
		
	}
	if(xResInfo.eResType == IFX_MMGR_FXO_RESOURCE)
	{
        return xResInfo.uxChannel.pxFxoResource->iFd;
	}
	if(xResInfo.eResType == IFX_MMGR_DECT_RESOURCE)
	{
		return xResInfo.uxChannel.pxDectResource->iFd;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Failure");
	return IFX_MMGR_FAIL;
}

/*******************************************************************
*  Function Name    : IFX_MMGR_GetToneIndex
*  Description      : This API is used to get the Tone index in the 
*                   : Tone Table
*  Input Values     : eToneType
*  Output Values    : None
*  Return Value     : Index in the Tone Table
*  Notes            :
*********************************************************************/
int32 IFX_MMGR_GetToneIndex(e_IFX_MMGR_ToneType eToneType)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
  if(eToneType >= IFX_MMGR_MAX_TONE)
  {
    return IFX_MMGR_FAIL;
  }
  return stxToneInfo.axTones[eToneType].ucIndex;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TonePlay
*  Description      : This API is used to Play a tone 
*  Input Values     : pszEndPtId,eToneType,pxCidParams
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCES/IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TonePlay(char8* pszEndPtId,
									e_IFX_MMGR_ToneType eToneType,
									x_IFX_MMGR_CidParams *pxCidParams)
{
	int32 iFd;
    uchar8 ucIndex;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	  x_IFX_MMGR_ResourceInfo xResInfo;
		IFX_MMGR_ToneStop(pszEndPtId);
    iFd = IFX_MMGR_GetSigFd(pszEndPtId);
    if(iFd < 0)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Fd");
        return IFX_MMGR_NO_RESOURCE;
    }
    if(eToneType == IFX_MMGR_MAX_TONE)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Tone Type");
		return IFX_MMGR_FAIL;
    }
    if((pxCidParams == NULL) && (eToneType == IFX_MMGR_RING_TONE))
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Cid Params not Provided");
       return IFX_MMGR_FAIL;
    }
    ucIndex = IFX_MMGR_GetToneIndex(eToneType);
    if(ucIndex == (uchar8)IFX_MMGR_FAIL)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Tone Type");
		return IFX_MMGR_FAIL;
    }
    if(pxCidParams != NULL )
    { 
		iFd = IFX_MMGR_GetSigFd(pszEndPtId);
		if(eToneType == IFX_MMGR_RING_TONE)
		{
			if(IFX_MMGR_TAPI_RingStart(iFd,pxCidParams) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Start Ringing Failed");
				return IFX_MMGR_FAIL;
			}
		}
		else if(eToneType == IFX_MMGR_CALL_WAITING_TONE)
		{
						
			if(IFX_MMGR_TAPI_PlayTone(iFd,ucIndex) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
       	 			"PlayTone Failed");
				return IFX_MMGR_FAIL;
			}
			
			if(IFX_MMGR_TAPI_CidSend(iFd,pxCidParams) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Cid Send Failed");
				return IFX_MMGR_FAIL;
			}
		}
	}
	else
	{
		if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
		{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Invalid Endpt Id");
				return IFX_MMGR_FAIL;
		}
		if(xResInfo.eResType == IFX_MMGR_DECT_RESOURCE)
		{
        printf("Play DECT tone\n");
				if(IFX_MMGR_TAPI_DectPlayTone(iFd,ucIndex) != IFX_MMGR_SUCCESS)
				{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"PlayTone Failed");
						return IFX_MMGR_FAIL;
				}
		}
		else if(IFX_MMGR_TAPI_PlayTone(iFd,ucIndex) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"PlayTone Failed");
			return IFX_MMGR_FAIL;
		}
       // IFX_MMGR_SetPlayingToneState(pszEndPtId);
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
      
 return IFX_MMGR_SUCCESS;
}

/*******************************************************************
*  Function Name    : IFX_MMGR_ToneStop
*  Description      : This API is used to Play a tone 
*  Input Values     : pszEndPtId,eToneType,pxCidParams
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCES/IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_ToneStop(char8* pszEndPtId)
{
		
    int32 iFd ;
		x_IFX_MMGR_ResourceInfo xResInfo;
    /* Get the ALM fd */
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
		if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
		{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Invalid Endpt Id");
				return IFX_MMGR_FAIL;
		}
		if(xResInfo.eResType == IFX_MMGR_DECT_RESOURCE)
		{
    		iFd = IFX_MMGR_GetSigFd(pszEndPtId);
        printf("Stopping DECT tone\n");
        IFX_MMGR_TAPI_DectStopTone(iFd);
		}
		else
		{
   		iFd = IFX_MMGR_GetFd(pszEndPtId);
    		if(iFd < 0)
    	{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Invalid Fd");
				return IFX_MMGR_FAIL;
    	}
    	else
    	{
      	  IFX_MMGR_TAPI_RingStop(iFd);
    	}
    	/* Get the signalling fd associated wuth this endpt*/
    	iFd = IFX_MMGR_GetSigFd(pszEndPtId);
    	if(iFd < 0)
    	{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Invalid Fd");
    	}
    	else
    	{
      	  IFX_MMGR_TAPI_StopTone(iFd);

    	}
		}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_CptdStart
*  Description      : This API is used to Play a tone 
*  Input Values     : pszEndPtId,eToneType,pxCidParams
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCES/IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_CptdStart(IN char8* pszEndPtId,
                                     IN e_IFX_MMGR_ToneType eToneType
                                    )
{
	int32 iFd;
    uchar8 ucIndex;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    iFd = IFX_MMGR_GetSigFd(pszEndPtId);
    if(iFd < 0)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Fd");
        return IFX_MMGR_NO_RESOURCE;
    }
    ucIndex = IFX_MMGR_GetToneIndex(eToneType);
    if(ucIndex == (uchar8)IFX_MMGR_FAIL)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Tone Type");
    }
    if(IFX_MMGR_TAPI_StartCptd(iFd,ucIndex) != IFX_MMGR_SUCCESS)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Start Cptd Failed");
        return IFX_MMGR_FAIL;
    }
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_CptdStop
*  Description      : This API is used to Play a tone 
*  Input Values     : pszEndPtId,eToneType,pxCidParams
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCES/IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_CptdStop(IN char8* pszEndPtId
                                    )
{
	int32 iFd;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    iFd = IFX_MMGR_GetSigFd(pszEndPtId);
    if(iFd < 0)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Fd");
        return IFX_MMGR_NO_RESOURCE;
    }
    if(IFX_MMGR_TAPI_StopCptd(iFd) != IFX_MMGR_SUCCESS)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Stop Cptd Fd");
        return IFX_MMGR_FAIL;
    }
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}
    
/*! 
    \brief         This function starts a CID receiver on a FXO endpt.
     			   This function needs to envoked the moment a ring event is 
    			   detected on the FXO end point. 
  	\param[in]     pszEndptId - identifier of the endpoint.
	\param[in]     eCidRxMode - Mode of Cid Rx (OffHook/OnHook)
 	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no
				   signalling resource is
 					   already allocated or IFX_MMGR_FAIL
 */

e_IFX_MMGR_Return IFX_MMGR_CidRxStart(
							  IN char8* pszEndPtId,
							  IN e_IFX_MMGR_CidRxMode eCidRxMode
							  )
{
    int32 iFd;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    iFd = IFX_MMGR_GetSigFd(pszEndPtId);
    if(iFd < 0)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Fd");
    }
    if(IFX_MMGR_TAPI_StartCidRx(iFd,eCidRxMode) != IFX_MMGR_SUCCESS)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"StartCidRx Failed");
        return IFX_MMGR_FAIL;
    }
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}

/*! 
    \brief         This function stops a CID receiver on a FXO endpt.
  	\param[in]     pszEndptId - identifier of the endpoint.
 	\return        IFX_MMGR_SUCCESS
 */

e_IFX_MMGR_Return IFX_MMGR_CidRxStop(
							  					IN char8* pszEndPtId
					 							)
{
    int32 iFd;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    iFd = IFX_MMGR_GetSigFd(pszEndPtId);
    if(iFd < 0)
    {
    }
    if(IFX_MMGR_TAPI_StopCidRx(iFd) != IFX_MMGR_SUCCESS)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Stop Failed");
        return IFX_MMGR_FAIL;
    }
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}
/*! 
    \brief         This function starts a CID transmitter on a FXS endpt.
   	\param[in]     pszEndptId - identifier of the endpoint.
	\param[in]     pxCidparams - pointer to cid parameters
 	\return        IFX_MMGR_SUCCESS , IFX_MMGR_NO_RESOURCE incase no
				   signalling resource is
 					   already allocated or IFX_MMGR_FAIL
 */
e_IFX_MMGR_Return IFX_MMGR_CidTxStart(char8* pszEndPtId,
                                      IN x_IFX_MMGR_CidParams *pxCidParams
                                      )
{
    int32 iFd;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
    iFd = IFX_MMGR_GetSigFd(pszEndPtId);
    if(iFd < 0)
    {
    }
    if(IFX_MMGR_TAPI_CidSend(iFd,pxCidParams) != IFX_MMGR_SUCCESS)
    {
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"CidSend Failed");
        return IFX_MMGR_FAIL;
    }
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
    return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_GetOtherExtnRes
							 (x_IFX_MMGR_ResourceInfo *pxResInfo, 
							 x_IFX_MMGR_ResourceContext *pxResourceContext,
							 x_IFX_MMGR_ResourceInfo **ppxResInfo
							)
{
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	
	if(pxResourceContext->axResInfo[0].uxChannel.pxFxsResource == pxResInfo->uxChannel.pxFxsResource)
	{
		*ppxResInfo = &pxResourceContext->axResInfo[1];
	}
	else
	{
		*ppxResInfo = &pxResourceContext->axResInfo[0];
	}
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_GetFxoRes(IN x_IFX_MMGR_ResourceContext *pxResourceContext, 
								IN_OUT x_IFX_MMGR_Fxo_Channel **ppxFxo)
{
	if(pxResourceContext->axResInfo[0].eResType == IFX_MMGR_FXO_RESOURCE)
	{
		*ppxFxo = pxResourceContext->axResInfo[0].uxChannel.pxFxoResource;
	}
	else if(pxResourceContext->axResInfo[1].eResType == IFX_MMGR_FXO_RESOURCE)
	{
		*ppxFxo = pxResourceContext->axResInfo[1].uxChannel.pxFxoResource;
	}
	else
	{
		return IFX_MMGR_FAIL;
	}
	return IFX_MMGR_SUCCESS;
}
/*!
      \brief         This function starts mixing of voice from different 
                     resources.This service is needed for acheiving 
                     n-way call confernce irrespective of the type of call.
      \param[in]     pszEndPtId - End point Id of the initiator.
      \param[in,out]     iConfernceId - Conference identifier
      \param[in]     iNoOfParties - No of participants 
      \param[in]     paiResourceId - pointer to array of resourceIds 
      \return        IFX_MMGR_SUCCESS , IFX_MMGR_FAIL 
                                                        */
e_IFX_MMGR_Return IFX_MMGR_MixingEnable(
                                        IN char8* pszEndPtId,
                                        IN_OUT int32 *piConfernceId,
                                        IN int32 iNoOfParties,
                                        IN int32 *paiResourceId
                                        )
{
	x_IFX_MMGR_ResourceInfo xResInfo,xConfResInfo[2],*pxOtherExtnRes,*pxOtherExtnRes1;
	x_IFX_MMGR_ResourceContext *paxResContext[2];
	x_IFX_MMGR_ConferenceContext *pxConfContext;
	x_IFX_MMGR_Fxo_Channel *pxFxoRes;
	e_IFX_MMGR_TypeOfCall eTypeOfCall1 ,eTypeOfCall2; 
    uint16 unCount;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);

	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Endpt Id");
		return IFX_MMGR_FAIL;
	}
	if(IFX_MMGR_ConfContextAlloc(&pxConfContext) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Allocate Conf Context Failed");
		return IFX_MMGR_FAIL;
	}
	if (iNoOfParties < 2)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Insufficient data");
		return IFX_MMGR_FAIL;
	}
	for(unCount = 0; unCount <  iNoOfParties;unCount++)
	{
		if(IFX_MMGR_ResourceContextGet(paiResourceId[unCount],
					&paxResContext[unCount]) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Resource Context Not Found");
			return IFX_MMGR_FAIL;
		}
		if(paxResContext[unCount]->axResInfo[0].uxChannel.pxFxsResource == 
                xResInfo.uxChannel.pxFxsResource)
		{
			memcpy(&xConfResInfo,&paxResContext[unCount]->axResInfo[1],sizeof(x_IFX_MMGR_ResourceInfo));
		}
		else
		{
			memcpy(&xConfResInfo,&paxResContext[unCount]->axResInfo[0],sizeof(x_IFX_MMGR_ResourceInfo));
		}

	}
	/* If both the calls are of type of VOIP , no need to do anything ... they are already 
		 in conference 
		 */
	if(xResInfo.eResType == IFX_MMGR_FXS_RESOURCE || xResInfo.eResType == IFX_MMGR_DECT_RESOURCE)
	{
		eTypeOfCall1 = paxResContext[0]->eTypeOfCall;
		eTypeOfCall2 = paxResContext[1]->eTypeOfCall;
		if(((eTypeOfCall1 == IFX_MMGR_CALL_EXTN_VOIP) 
				 || (eTypeOfCall2 == IFX_MMGR_CALL_VOIP_EXTN))
				&& 
			 ((eTypeOfCall2 == IFX_MMGR_CALL_EXTN_VOIP) 
				|| (eTypeOfCall2 == IFX_MMGR_CALL_VOIP_EXTN)))
		{
			pxConfContext->eConfType = IFX_MMGR_FXS_VOIP_VOIP;
			/* Nothing to be done .. they are already in conference */
		}
		/* If call 1 is of type voip and call 2 is of type extn */
		else if(((eTypeOfCall1 == IFX_MMGR_CALL_EXTN_VOIP)
			|| (eTypeOfCall1 == IFX_MMGR_CALL_VOIP_EXTN)) && 
			 (eTypeOfCall2 == IFX_MMGR_CALL_EXTN_EXTN))
		{
			pxConfContext->paxConfParties[0] = paxResContext[0];
			pxConfContext->paxConfParties[1] = paxResContext[1];
			if(IFX_MMGR_GetOtherExtnRes(&xResInfo,paxResContext[1],&pxOtherExtnRes)
											!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Could not get the other extn");
				return IFX_MMGR_FAIL;
			}
			if(pxOtherExtnRes->eResType == IFX_MMGR_FXS_RESOURCE)
			{
				pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxFxsResource->unChannelNum;
				pxConfContext->iFd = paxResContext[0]->pxCoder->iFd;
				if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Data Channel To analog Failed");
					return IFX_MMGR_FAIL;
				}
				pxConfContext->eConfType = IFX_MMGR_FXS_VOIP_FXS;
			}
			else if(pxOtherExtnRes->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxDectResource->unChannelNum;
				pxConfContext->iFd = paxResContext[0]->pxCoder->iFd;
				if(IFX_MMGR_TAPI_AddDataChannelToDect(pxConfContext->iFd,
							pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Data Channel To Dect Failed");
					return IFX_MMGR_FAIL;
				}
				pxConfContext->eConfType = IFX_MMGR_FXS_VOIP_DECT;
			}

		}
		else if( ( (eTypeOfCall1 == IFX_MMGR_CALL_EXTN_EXTN) && 
			  ( (eTypeOfCall2 == IFX_MMGR_CALL_EXTN_VOIP) ||
			 	  (eTypeOfCall2 == IFX_MMGR_CALL_VOIP_EXTN))
				))
		{
			pxConfContext->paxConfParties[0] = paxResContext[0];
			pxConfContext->paxConfParties[1] = paxResContext[1];
			if(IFX_MMGR_GetOtherExtnRes(&xResInfo,paxResContext[0],&pxOtherExtnRes)!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Could not get the other extn");
				return IFX_MMGR_FAIL;
			}
			if(pxOtherExtnRes->eResType == IFX_MMGR_FXS_RESOURCE)
			{
				pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxFxsResource->unChannelNum;
				pxConfContext->iFd = paxResContext[1]->pxCoder->iFd;
				if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Data Channel To analog Failed");
					return IFX_MMGR_FAIL;
				}
				pxConfContext->eConfType = IFX_MMGR_FXS_FXS_VOIP;
			}
			else if(pxOtherExtnRes->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxDectResource->unChannelNum;
				pxConfContext->iFd = paxResContext[1]->pxCoder->iFd;
				if(IFX_MMGR_TAPI_AddDataChannelToDect(pxConfContext->iFd,
							pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Data Channel To Dect Failed");
					return IFX_MMGR_FAIL;
				}
				pxConfContext->eConfType = IFX_MMGR_FXS_VOIP_DECT;
			}
		}
		else if( ( (eTypeOfCall1 == IFX_MMGR_CALL_EXTN_EXTN) 
						  && 
			       ( (eTypeOfCall2 == IFX_MMGR_CALL_EXTN_FXO) || 
							 (eTypeOfCall2 == IFX_MMGR_CALL_FXO_EXTN)
							)
						 )
					 )
		{
			if(IFX_MMGR_GetOtherExtnRes(&xResInfo,paxResContext[0],&pxOtherExtnRes)!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Could not get the other extn");
				return IFX_MMGR_FAIL;
			}
			if(IFX_MMGR_GetFxoRes(paxResContext[1],&pxFxoRes) != IFX_MMGR_SUCCESS)
			{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Couldnot get Fxo Resource");
					return IFX_MMGR_FAIL;
			}
			pxConfContext->eConfType = IFX_MMGR_FXS_FXS_FXO;
			if(pxOtherExtnRes->eResType == IFX_MMGR_FXS_RESOURCE)
			{
				pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxFxsResource->unChannelNum;
#ifndef SLIC121
				pxConfContext->iFd = pxFxoRes->iPcmFd;
				if(IFX_MMGR_TAPI_AddPcmToAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#else
				pxConfContext->iFd = pxFxoRes->iFd;
				if(IFX_MMGR_TAPI_AddAnalogToAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Pcm/Analog Channel To analog Failed");
					return IFX_MMGR_FAIL;
				}
				pxConfContext->eConfType = IFX_MMGR_FXS_FXS_FXO;
			}
			else if(pxOtherExtnRes->eResType == IFX_MMGR_DECT_RESOURCE)
			{
#ifndef SLIC121 
				pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxDectResource->unChannelNum;
				pxConfContext->iFd = pxFxoRes->iPcmFd;
				if(IFX_MMGR_TAPI_AddPcmToDect(pxConfContext->iFd,
							pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#else
				pxConfContext->unChannelNum = pxFxoRes->unChannelNum;
				pxConfContext->iFd = pxOtherExtnRes->uxChannel.pxDectResource->iFd;
				if(IFX_MMGR_TAPI_AddDectToAnalog(pxConfContext->iFd,
							pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Pcm/Analog Channel To Dect Failed");
					return IFX_MMGR_FAIL;
				}
				pxConfContext->eConfType = IFX_MMGR_FXS_DECT_FXO;
			}
		}
		/* If call 1 is Fxo and call 2 is Extn */
		if( (  (eTypeOfCall1 == IFX_MMGR_CALL_EXTN_FXO) ||
				   (eTypeOfCall1 == IFX_MMGR_CALL_FXO_EXTN) 
				) && 
		       (eTypeOfCall2 == IFX_MMGR_CALL_EXTN_EXTN)
			)
		{
			if(IFX_MMGR_GetOtherExtnRes(&xResInfo,paxResContext[1],&pxOtherExtnRes)!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Could not get the other extn");
				return IFX_MMGR_FAIL;
			}
			if(IFX_MMGR_GetFxoRes(paxResContext[0],&pxFxoRes) != IFX_MMGR_SUCCESS)
			{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Couldnot get Fxo Resource");
					return IFX_MMGR_FAIL;
			}
			if(pxOtherExtnRes->eResType == IFX_MMGR_FXS_RESOURCE)
			{
				pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxFxsResource->unChannelNum;
#ifndef SLIC121
				pxConfContext->iFd = pxFxoRes->iPcmFd;
				if(IFX_MMGR_TAPI_AddPcmToAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#else
				pxConfContext->iFd = pxFxoRes->iFd;
				if(IFX_MMGR_TAPI_AddAnalogToAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Pcm/Analog Channel To Analog Failed");
					return IFX_MMGR_FAIL;
				}
				pxConfContext->eConfType = IFX_MMGR_FXS_FXO_DECT;
			}
			else if(pxOtherExtnRes->eResType == IFX_MMGR_DECT_RESOURCE)
			{
#ifndef SLIC121 
				pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxDectResource->unChannelNum;
				pxConfContext->iFd = pxFxoRes->iPcmFd;
				if(IFX_MMGR_TAPI_AddPcmToDect(pxConfContext->iFd,
							pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#else
				pxConfContext->unChannelNum = pxFxoRes->unChannelNum;
				pxConfContext->iFd = pxOtherExtnRes->uxChannel.pxDectResource->iFd;
				if(IFX_MMGR_TAPI_AddDectToAnalog(pxConfContext->iFd,
							pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
				{
					IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        				"Add Pcm/Analog Channel To Dect Failed");
					return IFX_MMGR_FAIL;
				}
				pxConfContext->eConfType = IFX_MMGR_FXS_FXO_DECT;
			}
		}
		/* If Call 1 and Call 2 is of type Extn */
		else if((eTypeOfCall1 == IFX_MMGR_CALL_EXTN_EXTN) && 
			 (eTypeOfCall2 == IFX_MMGR_CALL_EXTN_EXTN))
		{
			if(IFX_MMGR_GetOtherExtnRes(&xResInfo,paxResContext[0],&pxOtherExtnRes)!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Could not get the other extn");
				return IFX_MMGR_FAIL;
			}
			if(IFX_MMGR_GetOtherExtnRes(&xResInfo,paxResContext[1],&pxOtherExtnRes1)!= IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        			"Could not get the other extn");
				return IFX_MMGR_FAIL;
			}
			if(pxOtherExtnRes->eResType == IFX_MMGR_FXS_RESOURCE)
			{
				if(pxOtherExtnRes1->eResType == IFX_MMGR_FXS_RESOURCE)
				{
					pxConfContext->unChannelNum = pxOtherExtnRes1->uxChannel.pxFxsResource->unChannelNum;
					pxConfContext->iFd = pxOtherExtnRes->uxChannel.pxFxsResource->iFd;
					if(IFX_MMGR_TAPI_AddAnalogToAnalog(pxConfContext->iFd,
									pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Add analog Channel To analog Failed");
						return IFX_MMGR_FAIL;
					}
					if(xResInfo.eResType == IFX_MMGR_FXS_RESOURCE)
					{
						pxConfContext->eConfType = IFX_MMGR_FXS_FXS_FXS;
					}
					else
					{
						pxConfContext->eConfType = IFX_MMGR_DECT_FXS_FXS;
					}
				}
				else if(pxOtherExtnRes1->eResType == IFX_MMGR_DECT_RESOURCE)
				{
					pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxFxsResource->unChannelNum;
					pxConfContext->iFd = pxOtherExtnRes1->uxChannel.pxDectResource->iFd;
					if(IFX_MMGR_TAPI_AddDectToAnalog(pxConfContext->iFd,
									pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Add Dect Channel To analog Failed");
						return IFX_MMGR_FAIL;
					}
					if(xResInfo.eResType == IFX_MMGR_FXS_RESOURCE)
					{
						pxConfContext->eConfType = IFX_MMGR_FXS_FXS_DECT;
					}
					else
					{
						pxConfContext->eConfType = IFX_MMGR_DECT_FXS_DECT;
					}
					//pxConfContext->eConfType = IFX_MMGR_FXS_FXS_DECT;
				}
			}
			else if(pxOtherExtnRes->eResType == IFX_MMGR_DECT_RESOURCE)
			{
				if(pxOtherExtnRes1->eResType == IFX_MMGR_DECT_RESOURCE)
				{
					pxConfContext->unChannelNum = pxOtherExtnRes->uxChannel.pxDectResource->unChannelNum;
					pxConfContext->iFd = pxOtherExtnRes1->uxChannel.pxDectResource->iFd;
					if(IFX_MMGR_TAPI_AddDectToDect(pxConfContext->iFd,
									pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Add Dect Channel To Dect Failed");
						return IFX_MMGR_FAIL;
					}
					pxConfContext->eConfType = IFX_MMGR_FXS_DECT_DECT;
				}
				else if(pxOtherExtnRes1->eResType == IFX_MMGR_FXS_RESOURCE)
				{
					pxConfContext->unChannelNum = pxOtherExtnRes1->uxChannel.pxFxsResource->unChannelNum;
					pxConfContext->iFd = pxOtherExtnRes->uxChannel.pxDectResource->iFd;
					if(IFX_MMGR_TAPI_AddDectToAnalog(pxConfContext->iFd,
									pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
					{
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        					"Add Dect Channel To analog Failed");
						return IFX_MMGR_FAIL;
					}
					pxConfContext->eConfType = IFX_MMGR_FXS_FXS_DECT;
				}
			}
		}
		else if(  ((eTypeOfCall1 == IFX_MMGR_CALL_EXTN_VOIP) || 
				       (eTypeOfCall1 == IFX_MMGR_CALL_VOIP_EXTN)
				      )&&
				     ((eTypeOfCall2 == IFX_MMGR_CALL_EXTN_FXO) ||
				      (eTypeOfCall2 == IFX_MMGR_CALL_FXO_EXTN))
				)
		{
			if(IFX_MMGR_GetFxoRes(paxResContext[1],&pxFxoRes) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		    "Add Dect Channel To analog Failed");
				return IFX_MMGR_FAIL;
			}
			pxConfContext->iFd = paxResContext[0]->pxCoder->iFd;
#ifndef SLIC121
			pxConfContext->unChannelNum = pxFxoRes->unPcmChannelNum;
			if(IFX_MMGR_TAPI_AddDataChannelToPcm(pxConfContext->iFd,
												pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#else
			pxConfContext->unChannelNum = pxFxoRes->unChannelNum;
			if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxConfContext->iFd,
												pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		    "Add Dect Channel To PCM/analog Failed");
				return IFX_MMGR_FAIL;
			}
			pxConfContext->eConfType = IFX_MMGR_FXS_VOIP_FXO;

		}
		else if(  ((eTypeOfCall2 == IFX_MMGR_CALL_EXTN_VOIP) || 
				   (eTypeOfCall2 == IFX_MMGR_CALL_VOIP_EXTN)
				  )&&
				   ((eTypeOfCall1 == IFX_MMGR_CALL_EXTN_FXO) ||
				   (eTypeOfCall1 == IFX_MMGR_CALL_FXO_EXTN))
				)
		{
			if(IFX_MMGR_GetFxoRes(paxResContext[0],&pxFxoRes) != IFX_MMGR_SUCCESS)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		    "Add Dect Channel To analog Failed");
				return IFX_MMGR_FAIL;
			}
			pxConfContext->iFd = paxResContext[1]->pxCoder->iFd;
#ifndef SLIC121
			pxConfContext->unChannelNum = pxFxoRes->unPcmChannelNum;
			if(IFX_MMGR_TAPI_AddDataChannelToPcm(pxConfContext->iFd,
												pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#else
			pxConfContext->unChannelNum = pxFxoRes->unChannelNum;
			if(IFX_MMGR_TAPI_AddDataChannelToAnalog(pxConfContext->iFd,
												pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)

#endif
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		    "Add Dect Channel To PCM/analog Failed");
				return IFX_MMGR_FAIL;
			}
			pxConfContext->eConfType = IFX_MMGR_FXS_VOIP_FXO;

		}
	}
	else
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Invalid Parameter");
		IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Failure");
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*!
      \brief         This function stops mixing of voice media on two different 
                       resources.
      \param[in]     iConfernceId - Conference identifier
      \param[in]     iNoOfParties - No of participants 
      \param[in]     paiResourceId - pointer to array of resourceIds 
      \return        IFX_MMGR_SUCCESS , IFX_MMGR_FAIL 
                                    */
e_IFX_MMGR_Return IFX_MMGR_MixingDisable(
                                         IN int32 iConfernceId,
                                         IN int32 iNoOfParties,
                                         IN int32* paiResourceId
                                        )
{
    x_IFX_MMGR_ConferenceContext *pxConfContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_ConfContextGet(iConfernceId, &pxConfContext) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Confernce Context Not Found");
		return IFX_MMGR_FAIL;
	}
	switch(pxConfContext->eConfType)
	{
	case IFX_MMGR_FXS_VOIP_VOIP:
	case IFX_MMGR_DECT_VOIP_VOIP:
		break;
	case IFX_MMGR_FXS_VOIP_FXS:
	case IFX_MMGR_FXS_FXS_VOIP:
	case IFX_MMGR_DECT_VOIP_FXS:
		if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxConfContext->iFd,
					pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Remove Data Channel From Analog Failed");
			return IFX_MMGR_FAIL;
		}
			break;
	case IFX_MMGR_FXS_FXO_FXS:
	case IFX_MMGR_FXS_FXS_FXO:
#ifndef SLIC121
		if(IFX_MMGR_TAPI_RemovePcmFromAnalog(pxConfContext->iFd,
					pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#else
		if(IFX_MMGR_TAPI_RemoveAnalogFromAnalog(pxConfContext->iFd,
					pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Remove Pcm/Analog Channel From Analog Failed");
			return IFX_MMGR_FAIL;
		}
		break;
	case IFX_MMGR_FXS_VOIP_DECT:
	case IFX_MMGR_DECT_VOIP_DECT:
		if(IFX_MMGR_TAPI_RemoveDataChannelFromDect(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Remove Data Channel From Dect Failed");
			return IFX_MMGR_FAIL;
		}
		break;
	case IFX_MMGR_FXS_DECT_DECT:
	case IFX_MMGR_DECT_DECT_DECT:
		if(IFX_MMGR_TAPI_RemoveDectFromDect(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Remove Dect Channel From Dect Failed");
			return IFX_MMGR_FAIL;
		}
		break;

	case IFX_MMGR_FXS_DECT_FXS:
	case IFX_MMGR_DECT_FXS_DECT:
	case IFX_MMGR_FXS_FXS_DECT:
	
		if(IFX_MMGR_TAPI_RemoveDectFromAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Remove Dect Channel From analog Failed");
			return IFX_MMGR_FAIL;
		}
		break;

	case IFX_MMGR_FXS_FXO_DECT:
	case IFX_MMGR_DECT_DECT_FXO:
#ifndef SLIC121 
		if(IFX_MMGR_TAPI_RemovePcmFromDect(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#else
		if(IFX_MMGR_TAPI_RemoveDectFromAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Remove Pcm/Analog Channel From Dect Failed");
			return IFX_MMGR_FAIL;
		}
		break;

	case IFX_MMGR_DECT_FXS_FXS:
		if(IFX_MMGR_TAPI_RemoveAnalogFromAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Remove analog Channel From analog Failed");
			return IFX_MMGR_FAIL;
		}
		break;

	case IFX_MMGR_FXS_VOIP_FXO:
	case IFX_MMGR_DECT_VOIP_FXO:
#ifndef SLIC121
		if(IFX_MMGR_TAPI_RemoveDataChannelFromPcm(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#else
		if(IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(pxConfContext->iFd,
								pxConfContext->unChannelNum) != IFX_MMGR_SUCCESS)
#endif
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        		"Remove data channel from pcm/Analog Failed");
			return IFX_MMGR_FAIL;
		}
		break;
   default:
     break;
	}
	IFX_MMGR_ConfContextDealloc(pxConfContext);
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
        return IFX_MMGR_SUCCESS;
}
/*! 
    \brief      This function re-configures the attributes set on a
	            channel interface . These attributes may for example be 
				endpoint Id, wideband support, codec to be used in case of 
				DECT channel,etc.
    \param[in]  iInterfaceId - interface id of the channel.
	\param[in]  pszEndPtId - endpoint identifier.
	\param[in]  pxChannelParams - pointer to x_IFX_MMGR_ChannelParams.
    \return     IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_ChannelReCfg(
	                                     IN int32 iInterfaceId,
										IN char8* pszEndPtId,
										x_IFX_MMGR_ChannelParams* pxChannelParams)
{
	uint16 nCount;
	x_IFX_MMGR_Fxs_Channel *pxFxsResource;
	x_IFX_MMGR_Fxo_Channel *pxFxoResource;
	x_IFX_MMGR_Dect_Channel *pxDectResource;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	for(nCount=0; nCount < stxResources.unNoOfFxs; nCount++)
	{
		pxFxsResource = &stxResources.paxFxsEndPts[nCount];
		if(iInterfaceId == pxFxsResource->iInterfaceId)
		{
			strcpy(pxFxsResource->szEndPtId,pszEndPtId);
			pxFxsResource->bIsWideBandEnabled = pxChannelParams->bIsWideBandEnabled;
			pxFxsResource->bIsLecEnabled = pxChannelParams->bIsLecEnabled;
			pxFxsResource->ucLecTailLength = pxChannelParams->cLecTailLength;
			//pxFxsResource->unVolumeLevel = pxFxsInfo->unVolumeLevel;
		}
	}
	/* Search in the Fxo endpt pool */
	for(nCount=0; nCount < stxResources.unNoOfFxo; nCount++)
	{
		pxFxoResource = &stxResources.paxFxoEndPts[nCount];
		if(iInterfaceId == pxFxoResource->iInterfaceId)
		{
			strcpy(pxFxoResource->szEndPtId,pszEndPtId);
			pxFxoResource->bIsLecEnabled = pxChannelParams->bIsLecEnabled;
			pxFxoResource->ucLecTailLength = pxChannelParams->cLecTailLength;
		}
	}
	/* Search in the Dect endpt pool */
	for(nCount=0; nCount < stxResources.unNoOfDect; nCount++)
	{
		pxDectResource = &stxResources.paxDectEndPts[nCount];
		if(iInterfaceId == pxDectResource->iInterFaceId)
		{
		}
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
e_IFX_MMGR_Return IFX_MMGR_MftdEnable(int32 iResourceId,boolean bEnable)
{
	x_IFX_MMGR_ResourceContext *pxResourceContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,szFileName);
	if(IFX_MMGR_ResourceContextGet(iResourceId,&pxResourceContext) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Resource Context Not Found");
		return IFX_MMGR_INVALID_PARAMETER;
	}
	if(IFX_MMGR_TAPI_EnableMftd(pxResourceContext->pxCoder->iFd,pxResourceContext->pxCoder->unChannelNum,bEnable) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
        	"Enabling/Disabling the signal detection Failed");
		return IFX_MMGR_FAIL;
	}
	IFX_DBGA( vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_EXIT_INFO,
          	      __FUNCTION__,"Success");
	return IFX_MMGR_SUCCESS;
}
/*! 
    \brief         This function starts the GR909 testing on one of the FXS port.  
	\param[in]     pszEndptId Endpoint identifier.
	\param[in]     
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/

e_IFX_MMGR_Return IFX_MMGR_GR909TestStart(char8* pszEndPtId, x_IFX_MMGR_GR909_Param* pxParam)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Invalid EndPt Id");
		return IFX_MMGR_FAIL;
	}
#if 0 /* Need to comment this if GR909 Library is linked since it does it internally*/
  if(IFX_MMGR_TAPI_SetLineFeedDisabled(xResInfo.uxChannel.pxFxsResource->iFd) != IFX_MMGR_SUCCESS)
  {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Setting Line Feed Failed");
      return IFX_MMGR_FAIL;
  }
#endif
	/*Somany error occured previously, since the errors are not handled before just trying to flush out all previous error*/
	IFX_MMGR_TAPI_FlushErr(stxResources.iDspDevFd);
	return IFX_MMGR_TAPI_GR909TestStart(xResInfo.uxChannel.pxFxsResource->iFd,pxParam);
}
/*! 
    \brief         This function sets the line feed on the FXS to standby.  
	This function is invoked by the FXS agent to put the FXS channel to power  
	saving mode i.e. Stand by mode whenever the user goes on-hook.   
	\param[in]     pszEndptId Endpoint identifier.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/

e_IFX_MMGR_Return IFX_MMGR_SetFxsToStandBy(char8* pszEndPtId)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Invalid EndPt Id");
		return IFX_MMGR_FAIL;
	}
  if(IFX_MMGR_TAPI_SetLineFeedStandBy(xResInfo.uxChannel.pxFxsResource->iFd) != IFX_MMGR_SUCCESS)
  {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Setting Line Feed Failed");
      return IFX_MMGR_FAIL;
  }
	return IFX_MMGR_SUCCESS;
}
/*! 
    \brief         This function sets the line feed on the FXS to Active.  
	\param[in]     pszEndptId Endpoint identifier.
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_SetFxsToActive(char8* pszEndPtId)
{
	x_IFX_MMGR_ResourceInfo xResInfo;
	if(IFX_MMGR_SearchEndptResource(pszEndPtId,&xResInfo) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                    "Invalid EndPt Id");
		return IFX_MMGR_FAIL;
	}
  if(IFX_MMGR_TAPI_SetLineFeedActive(xResInfo.uxChannel.pxFxsResource->iFd) != IFX_MMGR_SUCCESS)
  {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Setting Line Feed Failed");
      return IFX_MMGR_FAIL;
  }
	return IFX_MMGR_SUCCESS;
}
/*! 
    \brief         This function gives the durartion of one Ring cadence.
	\param[out]     piTime pointer to Integer .
	\return        IFX_MMGR_SUCCESS or IFX_MMGR_FAIL
*/
e_IFX_MMGR_Return IFX_MMGR_RingCadenceTimeGet(int32 *piTime)
{
	x_IFX_MMGR_Tone *pxTone;
	pxTone = &stxToneInfo.axTones[IFX_MMGR_RING_TONE];
	if(pxTone->uiNoOfCadences > 1)
	{
		*piTime = pxTone->uiCadenceduration[1] + pxTone->uiCadenceduration[0];
	}
	else
	{
		*piTime = pxTone->uiCadenceduration[0] + pxTone->uiPause;
	}
    return IFX_MMGR_SUCCESS;
}
#ifdef VOIP_NEWVMAPI
/*****************************************************************************
 *  Function Name     : IFX_MMGR_GetFwSuppCodec
 *  Description       : Gets the supported codec list
 *  Input Values      :
 *  Output Values     : uiSuppCodec - supported codecs
 *  Return Value      :IFX_MMGR_SUCCESS/IFX_MMGR_FAIL
 *
 *  Notes             :
 ****************************************************************************/

e_IFX_MMGR_Return IFX_MMGR_check_FwSupp(uint32* uiSuppCodec)
{
    IFX_int32_t nCapNr = 0;
    IFX_int32_t nIndex = 0;
    IFX_TAPI_CAP_t *pCapList = IFX_NULL;
	uint32 uiFwSuppCodec = 0;
    if(ioctl(stxResources.iDspDevFd, IFX_TAPI_CAP_NR, (int) &nCapNr) < 0)
    {
        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                      "Getting Capability list size failed");

        return IFX_MMGR_FAIL;
    }
    pCapList = IFX_OS_Malloc(nCapNr * sizeof(IFX_TAPI_CAP_t));
    if (IFX_NULL == pCapList)
    {
        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                      "pCapList is null");

        return IFX_MMGR_FAIL;
    }

    memset(pCapList, 0, sizeof(nCapNr * sizeof(IFX_TAPI_CAP_t)));
    if(ioctl(stxResources.iDspDevFd, IFX_TAPI_CAP_LIST, pCapList) < 0)
    {
        IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                      "Get Cap list failed");
        IFX_OS_Free(pCapList);
        return IFX_MMGR_FAIL;
    }
    for (nIndex = 0; nIndex < nCapNr; nIndex++)
    {
        IFX_TAPI_CAP_t *pCap = &pCapList[nIndex];
        if(pCap->captype == IFX_TAPI_CAP_TYPE_CODEC)
        {
			switch(pCap->cap){
				case IFX_TAPI_COD_TYPE_ALAW:
					uiFwSuppCodec |= IFX_VMAPI_CODEC_G711_ALAW;
					break;
                case IFX_TAPI_COD_TYPE_MLAW:
					uiFwSuppCodec |= IFX_VMAPI_CODEC_G711_ULAW;
                    break;
                case IFX_TAPI_COD_TYPE_G729:
					uiFwSuppCodec |= IFX_VMAPI_CODEC_G729_8;
                    break;
                case IFX_TAPI_COD_TYPE_G723_63:
                case IFX_TAPI_COD_TYPE_G723_53:
					uiFwSuppCodec |= IFX_VMAPI_CODEC_G723;
                    break;
                case IFX_TAPI_COD_TYPE_G726_16:
					uiFwSuppCodec |= IFX_VMAPI_CODEC_G726_16;
                    break;
                case IFX_TAPI_COD_TYPE_G726_24:
					uiFwSuppCodec |= IFX_VMAPI_CODEC_G726_24;
                    break;
                case IFX_TAPI_COD_TYPE_G726_32:
					uiFwSuppCodec |= IFX_VMAPI_CODEC_G726_32;
                    break;
                case IFX_TAPI_COD_TYPE_G726_40:
					uiFwSuppCodec |= IFX_VMAPI_CODEC_G726_40;
                    break;
                case IFX_TAPI_COD_TYPE_G722_64:
					uiFwSuppCodec |= IFX_VMAPI_CODEC_G722_64;
                    break;
			}
        }
		else if(pCap->captype == IFX_TAPI_CAP_TYPE_T38)
		{
			uiFwSuppCodec |= IFX_VMAPI_CODEC_T38;
		}
    }

	*uiSuppCodec = uiFwSuppCodec;
	IFX_OS_Free(pCapList);
	return IFX_MMGR_SUCCESS;
}
#endif

#ifdef UDP_REDIRECT
/*****************************************************************************
 *  Function Name     : IFX_MMGR_QosStart
 *  Description       : 
 *  Input Values      : 
 *  Output Values     : 
 *  Return Value      : 
 *                      
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_QosStart (/*char* pcDevName*/ int32 iResId, uint32 uiLocalIp, uint16 uiLocalPort,
																		 uint32 uiRemIP,uint16 uiRemPort)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Entry");
	QOS_INIT_SESSION xQos;
#if 1	
	if(IFX_MMGR_ResourceContextGet(iResId,&pxResContext) != IFX_MMGR_SUCCESS){
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Failed");
			return IFX_MMGR_FAIL;
	}
	if((pxResContext == NULL)||(pxResContext->pxCoder == NULL)){
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Null Pointers");
			return IFX_MMGR_FAIL;
	}
#else	
  iFd = IFX_OS_OpenFile(pcDevName,O_RDONLY); 
	if(iFd < 0){
	  printf("<MMGR_QoSStart> !!!! Open FAILED !!!!");
		return IFX_MMGR_FAIL;
	}
	printf("<MMGR_QoSStart> SrcAddr = %d, ScrPort = %d, DestAddr = %d DestPort = %d\n",
				uiLocalIp,uiLocalPort,uiRemIP,uiRemPort);
	printf("Coder FD is %d\n",pxResContext->pxCoder->iFd);

#endif	
	memset(&xQos,0,sizeof(QOS_INIT_SESSION));
	xQos.srcAddr = uiLocalIp;
	xQos.srcPort = uiLocalPort;
	xQos.destAddr = uiRemIP;
	xQos.destPort = uiRemPort;

	ioctl(/*iFd*/ pxResContext->pxCoder->iFd,FIO_QOS_START,&xQos);
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
 *  Function Name     : IFX_MMGR_QosActivate
 *  Description       : 
 *  Input Values      : 
 *  Output Values     : 
 *  Return Value      : 
 *                      
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_QosActivate (int32 iResId,uint16 uiLocalPort)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	if(IFX_MMGR_ResourceContextGet(iResId,&pxResContext) != IFX_MMGR_SUCCESS){
	 printf("<MMGR_QoSStop> !!!! FAILED !!!!");
			return IFX_MMGR_FAIL;
	}
	printf("<MMGR_QoSStart> Fd = %d, ScrPort = %d \n",
				pxResContext->pxCoder->iFd,uiLocalPort);

	ioctl(pxResContext->pxCoder->iFd,FIO_QOS_ACTIVATE,uiLocalPort);
	return IFX_MMGR_SUCCESS;
}



/*****************************************************************************
 *  Function Name     : IFX_MMGR_QosStop
 *  Description       : 
 *  Input Values      : 
 *  Output Values     : 
 *  Return Value      : 
 *                      
 *  Notes             :
 ****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_QosStop(int32 iResId,uint16 uiLocalPort)
{
	x_IFX_MMGR_ResourceContext *pxResContext;
	if(IFX_MMGR_ResourceContextGet(iResId,&pxResContext) != IFX_MMGR_SUCCESS){
	 printf("<MMGR_QoSStop> !!!! FAILED !!!!");
			return IFX_MMGR_FAIL;
	}
	printf("<MMGR_QoSStart> Fd = %d, ScrPort = %d \n",
				pxResContext->pxCoder->iFd,uiLocalPort);

	ioctl(pxResContext->pxCoder->iFd,FIO_QOS_STOP,uiLocalPort);
#if 0
	 printf("<MMGR_QoSStop> !!!! Invoking ioctl for clean-up !!!!");
	 ioctl(pxResContext->pxCoder->iFd,FIO_QOS_CLEAN,0);
#endif	 
	return IFX_MMGR_SUCCESS;
}
#endif



/*Problems in the code:*/
//1. Resource Id Not freed: stiResourceId?
