/*****************************************************************************
	iFX_TAPI_PCM_CFG_t xPCMConfig = {0};
 **   FILE NAME       :IFX_MMGR_TapiIf.c
 **   PROJECT         :
 **   MODULES         :
 **   SRC VERSION     :
 **   DATE            : 
 **   AUTHOR          : Gateway Application Team
 **   DESCRIPTION     : This file contains the APIs and the data structures 
 **						exposed by the TAPI 
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
*****************************************************************************/
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <time.h>
//#include "ifx_types.h"
#include "drv_tapi_io.h"
#include "IFX_Config.h"
#include "IFX_MediaMgrTypes.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MediaMgr.h"
#include "lib_tapi_lt_gr909.h"
//extern int32 Ifxphone_LT_GR909_Start(int32 fd_line, boolean b_euLike, uint32  meas_mask);
//extern int32 Ifxphone_LT_GR909_Stop(int32 iFd);
//extern int32 Ifxphone_LT_GR909_GetResults (int32  fd_line,IFX_LT_GR909_RESULT_t *p_res);
#ifdef ENABLE_FXO
	#ifdef TEREDIAN
			#include "73m1966_io.h"
	#elif SLIC121
  #else
		#include "drv_duslic_io.h"
		#include "drv_duslic.h"
	#endif
#endif

#include <drv_tapi_event_io.h>
#include <vmmc_io.h>
#include "IFX_TapiIf.h"
#include "drv_tapi_kpi_io.h"
#ifdef CONFIG_AMAZON_S
#include <asm/amazon_s/amazon_s_gpio.h>
//#elif defined CONFIG_DANUBE
//#include <asm/danube/port.h>
#endif
#include "ifx_debug.h"
extern uchar8 vucMmgrModId;
#define printf(...)

#ifdef CVOIP_SUPPORT
extern x_LTQ_CVOIP_PcmConfig xPcmConfig[4];
#endif

e_IFX_MMGR_Return IFX_MMGR_SigDetect(int32 iFd, boolean bEnable);

int32 staeTapiCodec[IFX_MMGR_CODEC_MAX] = 
{
	[IFX_MMGR_CODEC_NONE] = IFX_TAPI_COD_TYPE_UNKNOWN,
	[IFX_MMGR_CODEC_ALAW] = IFX_TAPI_COD_TYPE_ALAW,
	[IFX_MMGR_CODEC_MLAW] = IFX_TAPI_COD_TYPE_MLAW,
	[IFX_MMGR_CODEC_G729_AB] = IFX_TAPI_COD_TYPE_G729,
	[IFX_MMGR_CODEC_G729_E] = IFX_TAPI_COD_TYPE_G729_E,
	[IFX_MMGR_CODEC_G723_5_3] = IFX_TAPI_COD_TYPE_G723_53,
	[IFX_MMGR_CODEC_G723_6_3] = IFX_TAPI_COD_TYPE_G723_63,
	[IFX_MMGR_CODEC_G728] = IFX_TAPI_COD_TYPE_G728,
	[IFX_MMGR_CODEC_G726_16] = IFX_TAPI_COD_TYPE_G726_16,
	[IFX_MMGR_CODEC_G726_24] = IFX_TAPI_COD_TYPE_G726_24,
	[IFX_MMGR_CODEC_G726_32] = IFX_TAPI_COD_TYPE_G726_32,
	[IFX_MMGR_CODEC_G726_40] = IFX_TAPI_COD_TYPE_G726_40,
	[IFX_MMGR_CODEC_G722_64] = IFX_TAPI_COD_TYPE_G722_64,
	[IFX_MMGR_CODEC_G722_1_24] = IFX_TAPI_COD_TYPE_G7221_24,
	[IFX_MMGR_CODEC_G722_1_32] = IFX_TAPI_COD_TYPE_G7221_32,
	[IFX_MMGR_CODEC_ILBC] = IFX_TAPI_COD_TYPE_ILBC_133
};

/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_Duslic_Init
*  Description      : This API INitializes the Duslic Device.
*  Input Values     : Duslic Device Fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESS,IFX_MMGR_FAIL
*  Notes            :
* *********************************************************************/
//#ifdef ENABLE_FXO
//#ifndef TEREDIAN
//#ifndef SLIC121
#if defined(ENABLE_FXO) && !(defined(TEREDIAN) || defined(SLIC121))
e_IFX_MMGR_Return IFX_MMGR_TAPI_Duslic_Init(int32 iDuslicFd,x_IFX_MMGR_FxoDevparam *pxDevParam)
{
	DUS_BasicDeviceInit_t xDusDevInit ;
	DUS_IO_INIT_t xDusInit            ;
	memset(&xDusDevInit,0,sizeof(DUS_BasicDeviceInit_t));
	memset(&xDusInit,0,sizeof(DUS_IO_INIT_t));
	xDusDevInit.AccessMode = DUS_ACCESS_SPI;
	xDusDevInit.nIrqNum = 95;
	if(ioctl(iDuslicFd, FIO_DUS_BASICDEV_INIT, &xDusDevInit)< 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Duslic Basic Init Failed, exiting");
		return IFX_MMGR_FAIL;
		
	}
	return IFX_MMGR_SUCCESS;
}
#endif
//#endif
//#endif
//#endif
/*******************************************************************
*  Function Name    : 
*  Description      : 
*  Input Values     : 
*  Output Values    : 
*  Return Value     : 
*  Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_ChannelInit(int32 iChFd,
											int32 iPcmFd,
											e_IFX_MMGR_ResourceType eChType,
											uchar8 *pucFw,int32 iFwSize,
											uchar8* pucCoefficient,
											int32 iCoefficientSize)
{
	VMMC_IO_INIT xVmmcInit ;
	IFX_TAPI_CH_INIT_t xInitParam;
	int32 iRetVal;

#ifdef ENABLE_FXO
	IFX_TAPI_LINE_TYPE_CFG_t xLineCfg = {0};
	IFX_TAPI_LINE_VOLUME_t xVol;
	#ifdef TEREDIAN
		M1966_CH_INIT_STRUCT_t terInit;
  	IFX_TAPI_CH_INIT_t terTapiChInit;
  	memset(&terInit, 0, sizeof(M1966_CH_INIT_STRUCT_t));
  	memset(&terTapiChInit, 0, sizeof(IFX_TAPI_CH_INIT_t));
	#elif SLIC121
    VMMC_DWLD_t oBBD_Data;
    memset(&oBBD_Data, 0, sizeof(VMMC_DWLD_t));
  #else
		DUS_IO_INIT_t xDusInit            = {0};
		memset(&xDusInit,0,sizeof(DUS_IO_INIT_t));
	#endif
#endif
  memset(&xVmmcInit,0,sizeof(VMMC_IO_INIT));
  memset(&xInitParam,0,sizeof(IFX_TAPI_CH_INIT_t));

	switch(eChType)
	{
	case IFX_MMGR_FXS_RESOURCE:
	{
	 VMMC_DWLD_t oBBD_Data;
	 memset(&oBBD_Data, 0, sizeof(VMMC_DWLD_t));
	 oBBD_Data.buf = pucCoefficient;
	 oBBD_Data.size = iCoefficientSize;
	 iRetVal = ioctl(iChFd,FIO_BBD_DOWNLOAD,&oBBD_Data);
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,"FXS Init");
	}
	break;
	case IFX_MMGR_CODER_RESOURCE:
		xVmmcInit.pPRAMfw  = pucFw;
    	xVmmcInit.pram_size = iFwSize;
		xVmmcInit.pBBDbuf = pucCoefficient;
		xVmmcInit.bbd_size = iCoefficientSize;
		xInitParam.pProc = (void*) &xVmmcInit;
		
		xInitParam.nMode = IFX_TAPI_INIT_MODE_VOICE_CODER;
		iRetVal = ioctl(iChFd, IFX_TAPI_CH_INIT, (int)&xInitParam);
		if (iRetVal < 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                        "Error Initializing the channel");
			return IFX_MMGR_FAIL;
		}
		iRetVal= IFX_MMGR_SigDetect(iChFd,0 /*Disable*/);
		break;

#ifdef ENABLE_FXO
	case IFX_MMGR_FXO_RESOURCE:
		xInitParam.nMode = IFX_TAPI_INIT_MODE_PCM_PHONE;
#ifdef TEREDIAN
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                       "Teredian  channel Init");
    terTapiChInit.nMode = IFX_TAPI_INIT_MODE_PCM_PHONE;
    terTapiChInit.pProc = &terInit;
    if( ioctl(iChFd, IFX_TAPI_CH_INIT, &terTapiChInit) < 0)
#elif SLIC121
    /* This configures TAPI Chan after reading Fxo Chan co-efficients
       from firmware file for FXS i.e. FXS BBD File */
    oBBD_Data.buf = pucCoefficient;
    oBBD_Data.size = iCoefficientSize;
    if( ioctl(iChFd, FIO_BBD_DOWNLOAD, &oBBD_Data) < 0)
#else
		xDusInit.nFlags = DUS_NO_CRAM_DWLD/*NO_CRAM_DWLD*/;
		xInitParam.nMode = IFX_TAPI_INIT_MODE_PCM_PHONE;
		xInitParam.pProc = &xDusInit;
		/* As of now the co-efficients need not be downloaded */
		if((iRetVal=ioctl(iChFd, IFX_TAPI_CH_INIT, &xInitParam))< 0)
#endif
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                       "FXO channel Init  failed");
			return IFX_MMGR_FAIL;
		}
		xLineCfg.lineType = IFX_TAPI_LINE_TYPE_FXO;
		xLineCfg.nDaaCh = 0;
		if(ioctl(iChFd,IFX_TAPI_LINE_TYPE_SET, &xLineCfg)< 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Setting the TAPI channel to FXO mode failed");
			return IFX_MMGR_FAIL;
		}

   memset(&xVol, 0, sizeof(IFX_TAPI_LINE_VOLUME_t));
   xVol.nGainRx = 0;
   xVol.nGainTx = 0;
   /* Set volume */
   if( ioctl(iChFd, IFX_TAPI_PHONE_VOLUME_SET, &xVol) < 0 ){
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Setting the TAPI channel to FXO mode failed");
   }     
	/*	if(IFX_MMGR_TAPI_PcmChannelConfig(iPcmFd,iChFd,1) != IFX_MMGR_SUCCESS)
		{
			printf("Configuring the pcm channel failed\n");
			return IFX_MMGR_FAIL;
		}*/
		break;
#endif
	case IFX_MMGR_DECT_RESOURCE:
  default:
		break;
	}
	return IFX_MMGR_SUCCESS;
}

#ifdef TEREDIAN
//#if 1
/*******************************************************************
  *  Function Name    : IFX_MMGR_Teridian_CfgPCMInterface
  *  Description      : Once FXO Device opened, PCM Interface needs to
												be configured during INIT time only.

  *  Input Values     : FXO Device FD
  *  Output Values    :
  *  Return Value     :
  *  Notes            :
  * *********************************************************************/
e_IFX_MMGR_Return 
IFX_MMGR_Teridian_CfgPCMInterface(uint32 uiFxoDevFd)
{
	IFX_TAPI_PCM_IF_CFG_t xPcmIfCfg = {0};
  memset(&xPcmIfCfg, 0, sizeof(IFX_TAPI_PCM_IF_CFG_t));

   /* Use PCM clock slave mode */
   xPcmIfCfg.nOpMode = IFX_TAPI_PCM_IF_MODE_SLAVE;

   xPcmIfCfg.nDCLFreq = IFX_TAPI_PCM_IF_DCLFREQ_2048;
   xPcmIfCfg.nDoubleClk = IFX_DISABLE;

   xPcmIfCfg.nSlopeTX = IFX_TAPI_PCM_IF_SLOPE_RISE;
   xPcmIfCfg.nSlopeRX = IFX_TAPI_PCM_IF_SLOPE_FALL;
   xPcmIfCfg.nOffsetTX = IFX_TAPI_PCM_IF_OFFSET_NONE;
   xPcmIfCfg.nOffsetRX = IFX_TAPI_PCM_IF_OFFSET_NONE;
   xPcmIfCfg.nDrive = IFX_TAPI_PCM_IF_DRIVE_ENTIRE;
   xPcmIfCfg.nShift = IFX_DISABLE;

	 if( ioctl(uiFxoDevFd, IFX_TAPI_PCM_IF_CFG_SET, (IFX_int32_t) &xPcmIfCfg)< 0){
      IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "FXO PCM configuration Failed!!");
     return IFX_MMGR_SUCCESS;
  }
  IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Done !!");
    return IFX_MMGR_SUCCESS;

}
#endif 
                              
#ifndef SLIC121
/*******************************************************************
  *  Function Name    :
  *  Description      : Configure PCM Interface on DSP Device.
												
  *  Input Values     :
  *  Output Values    :
  *  Return Value     :
  *  Notes            :
********************************************************************/
e_IFX_MMGR_Return 
IFX_MMGR_TAPI_ConfigurePcmIf(int32 iFd)
{
	IFX_TAPI_PCM_IF_CFG_t xPcmIfCfg = {0};
	xPcmIfCfg.nOpMode = IFX_TAPI_PCM_IF_MODE_MASTER;
	xPcmIfCfg.nDCLFreq = IFX_TAPI_PCM_IF_DCLFREQ_2048;
	xPcmIfCfg.nDoubleClk    = IFX_DISABLE;
//#ifndef CVOIP_SUPPORT
#if 1
	xPcmIfCfg.nSlopeTX = IFX_TAPI_PCM_IF_SLOPE_RISE;
	xPcmIfCfg.nSlopeRX = IFX_TAPI_PCM_IF_SLOPE_FALL;
#else
	xPcmIfCfg.nSlopeTX = IFX_TAPI_PCM_IF_SLOPE_FALL;
	xPcmIfCfg.nSlopeRX = IFX_TAPI_PCM_IF_SLOPE_RISE;
#endif
	xPcmIfCfg.nOffsetTX = IFX_TAPI_PCM_IF_OFFSET_NONE;
	xPcmIfCfg.nOffsetRX = IFX_TAPI_PCM_IF_OFFSET_NONE;
	xPcmIfCfg.nDrive = IFX_TAPI_PCM_IF_DRIVE_ENTIRE;
	xPcmIfCfg.nShift = IFX_DISABLE;
	if( ioctl(iFd, IFX_TAPI_PCM_IF_CFG_SET, (IFX_int32_t) &xPcmIfCfg)< 0)
	{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "PCm Interface configuration Failed!!");
	   return IFX_MMGR_SUCCESS;
	}
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,"Done !!");
    return IFX_MMGR_SUCCESS;

}

/*******************************************************************
  *  Function Name    : IFX_MMGR_TAPI_PcmChannelConfig
  *  Description      : During Call setup or Call releaes time activate or
												deactivate FXS PCM chnnl  and FXO PCM chnnl. In case
												deactivate action- CFG_PCM_SET is not required.
  *  Input Values     :
  *  Output Values    :
  *  Return Value     :
  *  Notes            :
  * *********************************************************************/
e_IFX_MMGR_Return 
IFX_MMGR_TAPI_PcmChannelConfig(int32 iPcmFd,int32 iFxoFd,boolean bAct)
{
	 IFX_TAPI_PCM_CFG_t xPCMConfig = {0};
	 IFX_TAPI_LINE_VOLUME_t xVolumeParam = {0};
		int ret = 0;
		if(bAct)
			printf("===========Activating Pcm..\n");
		else
			printf("===========Deactivating Pcm..\n");
#ifdef TEREDIAN
	 xPCMConfig.nTimeslotRX = 0;
	 xPCMConfig.nTimeslotTX = 0;
#else
	 xPCMConfig.nTimeslotRX = 1;
	 xPCMConfig.nTimeslotTX = 0;
#endif
	 xPCMConfig.nHighway = 0;
	 xPCMConfig.nResolution = IFX_TAPI_PCM_RES_ALAW_8BIT ;

#ifdef CVOIP_SUPPORT
	xPCMConfig.nTimeslotRX = xPCMConfig.nTimeslotTX = xPcmConfig[iFxoFd-1].nTimeslotTX;//10;
	xPCMConfig.nResolution = IFX_TAPI_PCM_RES_NB_ALAW_8BIT;
#endif
	printf("======Txslot:%d, RxSlot:%d, PcmChno:%d\n",xPCMConfig.nTimeslotTX,xPCMConfig.nTimeslotRX,iFxoFd);
//#ifdef TEREDIAN
   if(bAct) 
//#endif
	{
	 		if (ioctl(iPcmFd, IFX_TAPI_PCM_CFG_SET, &xPCMConfig) < 0){
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "PCm  configuration Failed!!");
			
	    return IFX_MMGR_FAIL;
	 	}
		printf("Calling ioctl IFX_TAPI_PCM_CFG_SET Rx Slot %d Tx Slot %d HighWay Number %d Codec %d\n",
										xPCMConfig.nTimeslotRX,xPCMConfig.nTimeslotTX,xPCMConfig.nHighway,
										IFX_TAPI_PCM_RES_WB_G722);
#ifndef CVOIP_SUPPORT
		#ifdef TEREDIAN
	 		xPCMConfig.nTimeslotRX = 0;
	 		xPCMConfig.nTimeslotTX = 0;
		#else
	 		xPCMConfig.nTimeslotRX = 0;
	 		xPCMConfig.nTimeslotTX = 1;
		#endif
			if(iFxoFd){
			 		if (ioctl(iFxoFd, IFX_TAPI_PCM_CFG_SET, &xPCMConfig) < 0){
						IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "FXO configuration failed!!");
	    		return IFX_MMGR_FAIL;
	 			}
			}
#endif

  }

	 ret = ioctl(iPcmFd, IFX_TAPI_PCM_ACTIVATION_SET, bAct);
	 if(ret < 0){
      IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "PCm  activation Failed!!");
               printf("PCm  activation Failed!!, error code %d\n",ret);
	    return IFX_MMGR_FAIL;
	 }
#ifndef CVOIP_SUPPORT
 if(iFxoFd){
	 if(ioctl(iFxoFd, IFX_TAPI_PCM_ACTIVATION_SET,bAct ) < 0){
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Act/Deactivation of PCM on FXO Chnl  failed!!");
	    return IFX_MMGR_FAIL;
	 }
	}
#endif
	 xVolumeParam.nGainRx = 0;
	 xVolumeParam.nGainTx = 0;

	 if(bAct){
		 if(ioctl(iPcmFd,IFX_TAPI_PCM_VOLUME_SET,&xVolumeParam)<0){
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Error setting the Pcm Volume");
		 return IFX_MMGR_FAIL;
	 	}
	 }

	 return IFX_MMGR_SUCCESS;
}

#endif
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetLineFeedStandBy(int32 iFd)
{
  int32 iRetVal;
	/* Set the Line Feed */
#ifdef CONFIG_DANUBE
	iRetVal = ioctl(iFd, IFX_TAPI_LINE_FEED_SET, (int)IFX_TAPI_LINE_FEED_STANDBY);
#else
	iRetVal = ioctl(iFd, IFX_TAPI_LINE_FEED_SET, (int)IFX_TAPI_LINE_FEED_STANDBY);/*Added to bring line out from disabled if its disabled*/
	//iRetVal = ioctl(iFd, IFX_TAPI_LINE_FEED_SET, (int)IFX_TAPI_LINE_FEED_PHONE_DETECT);
#endif
	if (iRetVal < 0)
	{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Error Setting the Line feed!!!");
			return IFX_MMGR_FAIL;
	}
	return iRetVal;
}
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetLineFeedActive(int32 iFd)
{
  int32 iRetVal;
	/* Set the Line Feed */
	iRetVal = ioctl(iFd, IFX_TAPI_LINE_FEED_SET, (int)IFX_TAPI_LINE_FEED_ACTIVE);
	if (iRetVal < 0)
	{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Error Setting the Line feed!!!");
			return IFX_MMGR_FAIL;
	}
	return iRetVal;
}
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetLineFeedDisabled(int32 iFd)
{
  int32 iRetVal;
	/* Set the Line Feed */
	iRetVal = ioctl(iFd, IFX_TAPI_LINE_FEED_SET, (int)IFX_TAPI_LINE_FEED_DISABLED);
	if (iRetVal < 0)
	{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Error Setting the Line feed to Disabled!!!");
			return IFX_MMGR_FAIL;
	}
	return iRetVal;
}
e_IFX_MMGR_Return IFX_MMGR_TAPI_GetEvents(int32 iChFd ,IFX_TAPI_EVENT_t *paxEventInfo)
{
    return ioctl(iChFd,IFX_TAPI_EVENT_GET,paxEventInfo);
}
/*******************************************************************
* *  Function Name    : IFX_MMGR_TAPI_StartCptd
* *  Description      : This API starts the call progress tone detection
* *  Input Values     : channel fd and the tone index
* *  Output Values    : None
* *  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
* *  Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_StartCptd(IN int32 iChFd,
							 IN uchar8 ucIndex
							 )
{
  IFX_TAPI_TONE_CPTD_t xToneCptd;
  memset(&xToneCptd,0,sizeof(IFX_TAPI_TONE_CPTD_t));
  xToneCptd.tone = ucIndex;
  xToneCptd.signal = IFX_TAPI_TONE_CPTD_DIRECTION_TX;
  if (ioctl(iChFd, IFX_TAPI_TONE_CPTD_START, &xToneCptd)< 0)
  {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "starting CPTD failed!!!");
	  	return IFX_MMGR_FAIL;
  }
  return IFX_MMGR_SUCCESS;
}
/*******************************************************************
* *  Function Name    : IFX_MMGR_TAPI_StopCptd
* *  Description      : This API starts the call progress tone detection
* *  Input Values     : channel fd and the tone index
* *  Output Values    : None
* *  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
* *  Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_StopCptd(IN int32 iChFd
							 )
{
    return ioctl(iChFd,IFX_TAPI_TONE_CPTD_STOP,0);

}
/*******************************************************************
* *  Function Name    : IFX_MMGR_TAPI_StartCidRx
* *  Description      : This API starts the Cid Rx
* *  Input Values     : channel fd and the tone index
* *  Output Values    : None
* *  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
* *  Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_StartCidRx(IN int32 iChFd,
                                           IN e_IFX_MMGR_CidRxMode eCidRxMode
							 )
{
  if (ioctl(iChFd, IFX_TAPI_CID_RX_START, eCidRxMode)< 0)
  {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "starting CidRx failed!!!");
	  	return IFX_MMGR_FAIL;
  }
  return IFX_MMGR_SUCCESS;
}
/*******************************************************************
* *  Function Name    : IFX_MMGR_TAPI_StopCidRx
* *  Description      : This API stops the Cid Rx
* *  Input Values     : channel fd 
* *  Output Values    : None
* *  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
* *  Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_StopCidRx(IN int32 iChFd
							              )

{
  if (ioctl(iChFd, IFX_TAPI_CID_RX_STOP, 0)< 0)
  {
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "stoping CidRx failed!!!");
	  	return IFX_MMGR_FAIL;
  }
  return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_PlayTone
*   Description      : This API starts the call progress tone detection
*   Input Values     : channel fd and the tone index
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_PlayTone(IN int32 iChFd,
							 IN uchar8 ucIndex
							 )
{
	return ioctl(iChFd,IFX_TAPI_TONE_LOCAL_PLAY,ucIndex);

}


/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_StopTone
*   Description      : This API stops a already tone being played
*   Input Values     : channel fd 
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_StopTone(
										IN int32 iChFd
										 )
{
	return ioctl(iChFd,IFX_TAPI_TONE_LOCAL_PLAY,0);

}
/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_PlayToneNetwork
*   Description      : This API starts the call progress tone detection
*   Input Values     : channel fd and the tone index
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_PlayToneNetwork(IN int32 iChFd,
							 IN uchar8 ucIndex
							 )
{
	return ioctl(iChFd,IFX_TAPI_TONE_NET_PLAY,ucIndex);

}
/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_StopTone
*   Description      : This API stops a already tone being played
*   Input Values     : channel fd 
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_StopToneNetwork(
										IN int32 iChFd
										 )
{
	return ioctl(iChFd,IFX_TAPI_TONE_NET_PLAY,0);

}
/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_DectPlayTone
*   Description      : This API starts the tone play on the Dect channel
*   Input Values     : channel fd and the tone index
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectPlayTone(IN int32 iChFd,
							 IN uchar8 ucIndex
							 )
{
   printf("Play DECT tone ioctl\n");
	return ioctl(iChFd,IFX_TAPI_TONE_DECT_PLAY,ucIndex);

}
/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_DectStopTone
*   Description      : This API stops a already tone being played
*   Input Values     : channel fd 
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectStopTone(
										IN int32 iChFd
										 )
{
   printf("Stopping DECT tone ioctl\n");
	return ioctl(iChFd,IFX_TAPI_TONE_DECT_STOP,0);

}

/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_SetRingCadence
*   Description      : This API sets the Ringing cadence
*   Input Values     : channel fd 
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetRingCadence(
										 IN int32 iChFd,
										 IN x_IFX_MMGR_Tone *pxTone
										 )
{
	uchar8 ucBit[] = { 0,0x01,0x03,0x07,0x0f,0x1f,0x3f,0x7f};
	uchar8 ucNoOfBits,ucNoOfBytes;
	int i;
	uint32 ucTotalCaddence;
	IFX_TAPI_RING_CADENCE_t xRingCadence;
	memset(&xRingCadence,0,sizeof(IFX_TAPI_RING_CADENCE_t));
	printf(" On Time duration %d\n",pxTone->uiCadenceduration[0]);
	ucNoOfBits = pxTone->uiCadenceduration[0] / IFX_MMGR_RING_CADENCE_RESOLUTION;
	ucNoOfBytes = ucNoOfBits / 8;
	ucNoOfBits = ucNoOfBits % 8; /* Remaining no of bits */
	memset(&xRingCadence.data,0xff,ucNoOfBytes);
	xRingCadence.data[ucNoOfBytes] = ucBit[ucNoOfBits]<<ucNoOfBits;
	if(pxTone->uiNoOfCadences > 1)
	{
					ucTotalCaddence = pxTone->uiCadenceduration[1] + pxTone->uiCadenceduration[0];
					printf(" cadence count > 1 total duration %d\n",ucTotalCaddence);
	}
	else
	{
					ucTotalCaddence = pxTone->uiCadenceduration[0] + pxTone->uiPause;
	printf(" On Time duration ..... %d\n",pxTone->uiCadenceduration[0]);
					
					printf(" Pause duration %d\n",pxTone->uiPause);
					printf(" cadence count == 1 total duration %d\n",ucTotalCaddence);
	}
	xRingCadence.nr = ucTotalCaddence / IFX_MMGR_RING_CADENCE_RESOLUTION;

	printf(" Setting the ring cadence of size %d\n",xRingCadence.nr);
	for(i=0;i<xRingCadence.nr/8;i++)
	{
					printf(" data %x\n",xRingCadence.data[i]);
	}
	return ioctl(iChFd,IFX_TAPI_RING_CADENCE_HR_SET,&xRingCadence);
}
void IFX_MMGR_TAPI_PrepareCidData(
								  IFX_TAPI_CID_MSG_t *pxCidMsg,
								  IFX_TAPI_CID_MSG_ELEMENT_t *paxMsg,
                                  uchar8 ucNoOfMsg,
								  x_IFX_MMGR_CidParams *pxCidParams
								  )
{
	struct timeval xTime;
    struct tm *ptm;
	char acDate[IFX_MMGR_MAX_TOKEN+5];
	memset(pxCidMsg,0,sizeof(IFX_TAPI_CID_MSG_t));
    memset(paxMsg,0,sizeof(IFX_TAPI_CID_MSG_ELEMENT_t)*ucNoOfMsg);
	if(gettimeofday(&xTime,NULL) < 0)
    {
        /* Log the Error */
    }
    ptm = localtime(&xTime.tv_sec);
		if (ptm)
    	strftime(acDate,IFX_MMGR_MAX_TOKEN+5,"%D%R",ptm);
    pxCidMsg->messageType = IFX_TAPI_CID_MT_CSUP;
	if(pxCidParams->eTxType == IFX_MMGR_ONHOOK)
	{
		printf(" cid mode on hook\n");
		pxCidMsg->txMode = IFX_TAPI_CID_HM_ONHOOK;
	}
	else if (pxCidParams->eTxType == IFX_MMGR_OFFHOOK)
	{
		printf(" cid mode off hook\n");
		pxCidMsg->txMode = IFX_TAPI_CID_HM_OFFHOOK;
	}
	pxCidMsg->nMsgElements = 3;
	
	if(NULL != strcasestr(pxCidParams->szCallerName,"anonymous")){
		/* Fill the Reason for absence of name */
		paxMsg[0].value.elementType = IFX_TAPI_CID_ST_ABSNAME;
		paxMsg[0].value.element = IFX_TAPI_CID_ABSREASON_UNAV;
		printf(" Cid Caller name %s\n",pxCidParams->szCallerName);
	}
	else{
		/* Fill the Callers name */
		paxMsg[0].string.elementType = IFX_TAPI_CID_ST_NAME;
		paxMsg[0].string.len = strlen(pxCidParams->szCallerName);
		printf(" Cid Caller name %s\n",pxCidParams->szCallerName);
	}
	if(NULL != strcasestr(pxCidParams->szCallerNumber,"anonymous")){
		paxMsg[1].value.elementType = IFX_TAPI_CID_ST_ABSCLI;
		paxMsg[1].value.element = IFX_TAPI_CID_ABSREASON_UNAV;
		printf(" Cid Caller nmber %s\n",pxCidParams->szCallerNumber);
	}
	else{
    	/* Calling Number */
    	paxMsg[1].string.elementType = IFX_TAPI_CID_ST_CLI;
    	paxMsg[1].string.len = strlen(pxCidParams->szCallerNumber);
		strcpy((char8 *)paxMsg[1].string.element,pxCidParams->szCallerNumber);
		printf(" Cid Caller nmber %s\n",pxCidParams->szCallerNumber);
	}
    /* Fill up the Date and Time */
    paxMsg[2].date.elementType = IFX_TAPI_CID_ST_DATE;
    sscanf(acDate,"%d",&paxMsg[2].date.month);
    sscanf(acDate+3,"%d",&paxMsg[2].date.day);
    sscanf(acDate+8,"%d",&paxMsg[2].date.hour);
    sscanf(acDate+11 ,"%d",&paxMsg[2].date.mn);
    pxCidMsg->message = paxMsg;
}


/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_RingStart
*   Description      : This API starts a ringing service on FXS along with cid tx
*   Input Values     : channel fd 
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
int32 IFX_MMGR_TAPI_RingStart(
								 int32 iChFd,
								 x_IFX_MMGR_CidParams *pxCidParams
								 )
{
	
    
    IFX_TAPI_CID_MSG_t xCidMsg;
    IFX_TAPI_CID_MSG_ELEMENT_t xMsg[IFX_MMGR_MAX_MSG_LENGTH];
    IFX_MMGR_TAPI_PrepareCidData(&xCidMsg,&xMsg[0],
                        IFX_MMGR_MAX_MSG_LENGTH,pxCidParams);
	return ioctl(iChFd,IFX_TAPI_CID_TX_SEQ_START,&xCidMsg);
	//return ioctl(iChFd,IFX_TAPI_RING_START,&xCidMsg);
}

/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_StopRinging
*   Description      : This API stops a ringing service on FXS 
*   Input Values     : channel fd 
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
int32 IFX_MMGR_TAPI_RingStop(IN int32 iChFd)
{
	return ioctl(iChFd,IFX_TAPI_RING_STOP,0);
}
/*******************************************************************
*   Function Name    : IFX_MMGR_TAPI_CidSend
*   Description      : This API starts a CID Tx on FXS 
*   Input Values     : channel fd 
*   Output Values    : None
*   Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*   Notes            :
* *********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_CidSend(
								 int32 iChFd,
								 x_IFX_MMGR_CidParams *pxCidParams
								 )
{
	IFX_TAPI_CID_MSG_t xCidMsg;
	IFX_TAPI_CID_MSG_ELEMENT_t xMsg[IFX_MMGR_MAX_MSG_LENGTH];
	memset(&xCidMsg,0,sizeof(xCidMsg));
	memset(&xMsg,0,sizeof(xMsg));
	IFX_MMGR_TAPI_PrepareCidData(&xCidMsg,&xMsg[0],IFX_MMGR_MAX_MSG_LENGTH,pxCidParams);
	return ioctl(iChFd,IFX_TAPI_CID_TX_SEQ_START,&xCidMsg);
}

/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_AddTone
*  Description      : This Function adds a tone to the tone table
*  Input Values     : Channel Num,Tone 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
int32 IFX_MMGR_TAPI_AddTone(int32 iChannelFd,x_IFX_MMGR_Tone *pxTone)
{
	int32 iRetVal;
	IFX_TAPI_TONE_t xTone;
	uint32 uiCount;

	/* Validation */
	if(pxTone->eToneType == IFX_MMGR_RING_TONE)
	{
				return 	IFX_MMGR_TAPI_SetRingCadence(iChannelFd,pxTone);
	}
	else
	{
		if(pxTone->uiNoOfCadences > IFX_TAPI_TONE_STEPS_MAX)
		{
			return IFX_MMGR_FAIL;
		}
		if(pxTone->ucNoOfFreqComp > 4)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "No of Frequency Components is greater than 4!");
			return IFX_MMGR_FAIL;
		}
		for(uiCount=0; uiCount < pxTone->ucNoOfFreqComp; uiCount++)
		{
			if((pxTone->xFrequencies[0].uiFrequency >= 4000) 
			|| (pxTone->xFrequencies[0].iGain <= -300) || 
			(pxTone->xFrequencies[0].iGain >= 0))
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               		"TAPI Invalid Gain an Frerquency values provided");
				return IFX_MMGR_FAIL;
			}
		}
		memset(&xTone,0,sizeof(xTone));
		xTone.simple.format = IFX_TAPI_TONE_TYPE_SIMPLE;
		xTone.simple.index = pxTone->eToneType + IFX_MMGR_TONE_INDEX_START;
		xTone.simple.freqA = pxTone->xFrequencies[0].uiFrequency;
		xTone.simple.freqB = pxTone->xFrequencies[1].uiFrequency;
		xTone.simple.freqC = pxTone->xFrequencies[2].uiFrequency;
		xTone.simple.freqD = pxTone->xFrequencies[3].uiFrequency;
		/* Set the levels of the frequency components */
		xTone.simple.levelA = pxTone->xFrequencies[0].iGain;
		xTone.simple.levelB = pxTone->xFrequencies[1].iGain;
		xTone.simple.levelC = pxTone->xFrequencies[2].iGain;
		xTone.simple.levelD = pxTone->xFrequencies[3].iGain;
		for(uiCount = 0 ; 
				uiCount < pxTone->uiNoOfCadences; 
				uiCount++)
		{
			if(pxTone->uiCadenceduration[uiCount] > IFX_MMGR_MAX_CADENCE_DURATION)
			{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               	"Error: Invalid Cadence duration!");
				return IFX_MMGR_FAIL;
			}
			xTone.simple.cadence[uiCount] = pxTone->uiCadenceduration[uiCount];
			if((pxTone->uiCadencePattern[uiCount] & IFX_MMGR_FREQUENCY_1) == IFX_MMGR_FREQUENCY_1)
			{
			xTone.simple.frequencies[uiCount] |= IFX_TAPI_TONE_FREQA;
	
			}
			if((pxTone->uiCadencePattern[uiCount] & IFX_MMGR_FREQUENCY_2) == IFX_MMGR_FREQUENCY_2)
			{
				xTone.simple.frequencies[uiCount] |= IFX_TAPI_TONE_FREQB;
			}
			if((pxTone->uiCadencePattern[uiCount] & IFX_MMGR_FREQUENCY_3) == IFX_MMGR_FREQUENCY_3)
			{
				xTone.simple.frequencies[uiCount] |= IFX_TAPI_TONE_FREQC;
			}
			if((pxTone->uiCadencePattern[uiCount] & IFX_MMGR_FREQUENCY_4) == IFX_MMGR_FREQUENCY_4)
			{
				xTone.simple.frequencies[uiCount] |= IFX_TAPI_TONE_FREQD;
			}
			if((pxTone->uiCadencePattern[uiCount] & IFX_MMGR_MODULATION) == IFX_MMGR_MODULATION)
			{
				xTone.simple.modulation[uiCount] |=	IFX_TAPI_TONE_MODULATION_ON;
			}
		}
		xTone.simple.loop = pxTone->ucLoop;
		xTone.simple.pause = pxTone->uiPause;
		/* add simple tone to the tone table */
		iRetVal = ioctl ( iChannelFd,IFX_TAPI_TONE_TABLE_CFG_SET,(int32)&xTone);

		if(iRetVal < 0)
		{
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
               "Add Tone ioctl failed");
			return IFX_MMGR_FAIL;
		}
		else
		{
			pxTone->ucIndex = pxTone->eToneType + IFX_MMGR_TONE_INDEX_START;
		}
	}
	return IFX_MMGR_SUCCESS;
}


e_IFX_MMGR_Return IFX_MMGR_TAPI_StartEncoding(int32 iFd)
{
	return ioctl(iFd,IFX_TAPI_ENC_START,0);
}

e_IFX_MMGR_Return IFX_MMGR_TAPI_StopEncoding(int32 iFd)
{
	return ioctl(iFd,IFX_TAPI_ENC_STOP,0);
}

e_IFX_MMGR_Return IFX_MMGR_TAPI_StopDecoding(int32 iFd)
{
	return ioctl(iFd,IFX_TAPI_DEC_STOP,0);
}
e_IFX_MMGR_Return IFX_MMGR_TAPI_StartDecoding(int32 iFd)
{
	return ioctl(iFd,IFX_TAPI_DEC_START,0);
}


e_IFX_MMGR_Return IFX_MMGR_TAPI_ConfigureVad(int32 iFd,boolean bOn)
{
	if(bOn)
		return ioctl(iFd,IFX_TAPI_ENC_VAD_CFG_SET,IFX_TAPI_ENC_VAD_ON);
	else
		return ioctl(iFd,IFX_TAPI_ENC_VAD_CFG_SET,IFX_TAPI_ENC_VAD_NOVAD);
}

e_IFX_MMGR_Return IFX_MMGR_TAPI_JitterBufferConfig(
																			int32 iFd,
																			x_IFX_MMGR_JitterBuffer_Conf *pxJBConf)
{
	IFX_TAPI_JB_CFG_t tapi_jb_conf;
  memset(&tapi_jb_conf, 0x00, sizeof(IFX_TAPI_JB_CFG_t));
#if 0 // TapiDemo Value
  tapi_jb_conf.nJbType      =  IFX_TAPI_JB_TYPE_FIXED;
  tapi_jb_conf.nPckAdpt     =  IFX_TAPI_JB_PKT_ADAPT_DATA;
  tapi_jb_conf.nScaling     =  0x16;   /* Scaling factor */
  tapi_jb_conf.nInitialSize =  0x0190; /* Inital JB size 50 ms */
  tapi_jb_conf.nMinSize     =  0x00A0; /* Min.   JB size 20 ms */
  tapi_jb_conf.nMaxSize     =  0x0320; /* Max.   JB size 100 ms */
#endif
	tapi_jb_conf.nJbType      =  pxJBConf->ucJBType;
  tapi_jb_conf.nPckAdpt     =  pxJBConf->ucPacketAdaptation;
  tapi_jb_conf.nScaling     =  pxJBConf->ucscaling;  
  tapi_jb_conf.nInitialSize =  pxJBConf->unInitialSize; 
  tapi_jb_conf.nMinSize     =  pxJBConf->unMinSize; 
  tapi_jb_conf.nMaxSize     =  pxJBConf->unMaxSize; /* Max.   JB size 100 ms */


  return ioctl(iFd,IFX_TAPI_JB_CFG_SET,(int32) &tapi_jb_conf);
}

e_IFX_MMGR_Return IFX_MMGR_TAPI_TelephonyEventConfigure(int32 iFd,x_IFX_MMGR_TelephonyEvent_Info *pxTelInfo)
{
	/* TBD */
	return IFX_MMGR_SUCCESS;
}

e_IFX_MMGR_Return IFX_MMGR_TAPI_LecConfigure(
																						int32 iFd,
																						e_IFX_MMGR_LecType eLecType ,
																						uchar8 ucTailLen,
																						boolean bNlp)
{
	IFX_TAPI_WLEC_CFG_t xLec = {0};

	if(eLecType == IFX_MMGR_LEC_NE)	{
		xLec.nType = IFX_TAPI_WLEC_TYPE_NE;
	}

	if(bNlp){ 
		xLec.bNlp = IFX_TAPI_WLEC_NLP_ON;
	}

	else{
	 xLec.nType = IFX_TAPI_WLEC_TYPE_OFF;
   xLec.bNlp = IFX_TAPI_WLEC_NLP_OFF;
	}
	return ioctl(iFd, IFX_TAPI_WLEC_PHONE_CFG_SET, &xLec);
}


e_IFX_MMGR_Return IFX_MMGR_TAPI_DectECConfigure(
																						int32 iFd,
																						boolean bOn)
{
	IFX_TAPI_DECT_EC_CFG_t dect_ec_cfg;
	memset (&dect_ec_cfg, 0, sizeof(dect_ec_cfg));
	if(bOn)
		dect_ec_cfg.nType = IFX_TAPI_EC_TYPE_ES; 
	else
		dect_ec_cfg.nType = IFX_TAPI_EC_TYPE_OFF; 

	return ioctl ( iFd, IFX_TAPI_DECT_EC_CFG_SET, (int)&dect_ec_cfg);
}


e_IFX_MMGR_Return IFX_MMGR_TAPI_SetEncType(int32 iFd,x_IFX_MMGR_CodecInfo *pxCodec)
{
	int32 iFrameLen = 20;	
	int32 ret;
	IFX_TAPI_ENC_CFG_t xEncCfg={0};

	switch(pxCodec->ucPacketLength){
		case 10:
			iFrameLen = IFX_TAPI_COD_LENGTH_10;
			break;
		case 20:
			iFrameLen = IFX_TAPI_COD_LENGTH_20;
			break;
		case 30:
			iFrameLen = IFX_TAPI_COD_LENGTH_30;
			break;
		case 40:
			iFrameLen = IFX_TAPI_COD_LENGTH_40;
			break;
		case 60:
			iFrameLen = IFX_TAPI_COD_LENGTH_60;
			break;
		default:
			iFrameLen = IFX_TAPI_COD_LENGTH_20;
			break;
	}
	printf("<GH>CodecType %d\n",pxCodec->eCodecType);
	printf("<GH>Frame Len %d\n",iFrameLen);
	xEncCfg.nEncType = staeTapiCodec[pxCodec->eCodecType];
	xEncCfg.nFrameLen = iFrameLen;

	if((ret=ioctl(iFd,IFX_TAPI_ENC_CFG_SET,(int32)&xEncCfg)) < 0){
		printf("Return val %d\n",ret);
		return IFX_MMGR_FAIL;
	}

		return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
*  Function Name   : IFX_APP_AddDataChannelToAnalog
*  Description     : This Function adds/removes a coder channel to a analog 
*                    channel
*  Input Values    : coder Channel Fd and analog channel no.
*  Output Values   : none
*  Return Value    : success/fail
*  Notes           :
****************************************************************************/
int32 IFX_MMGR_TAPI_AddDataChannelToAnalog(int32 iFd,uint16 nAnalogChNum)
{
	IFX_TAPI_MAP_DATA_t xDataMap;
	memset(&xDataMap,0,sizeof(xDataMap));
	xDataMap.nDstCh = nAnalogChNum;
	xDataMap.nChType = IFX_TAPI_MAP_TYPE_PHONE;
	return ioctl(iFd,IFX_TAPI_MAP_DATA_ADD,&xDataMap);
}
/*****************************************************************************
*  Function Name   : IFX_APP_RemoveDataChannelFromAnalog
*  Description     : This Function removes a coder channel from a analog 
*                    channel
*  Input Values    : coder Channel Fd and analog channel no.
*  Output Values   : none
*  Return Value    : success/fail
*  Notes           :
****************************************************************************/
int32 IFX_MMGR_TAPI_RemoveDataChannelFromAnalog(int32 iFd,uint16 nAnalogChNum)
{
	IFX_TAPI_MAP_DATA_t xDataMap;
	memset(&xDataMap,0,sizeof(xDataMap));
	xDataMap.nDstCh = nAnalogChNum;
	xDataMap.nChType = IFX_TAPI_MAP_TYPE_PHONE;
	printf("<Tapi_RemoveDataCh> Chnl No = %d \n",nAnalogChNum);
	return ioctl(iFd,IFX_TAPI_MAP_DATA_REMOVE,&xDataMap);
}
/*****************************************************************************
*  Function Name   : IFX_APP_AddDataChannelToPcm
*  Description     : This Function adds a coder channel to a Pcm 
*                    channel
*  Input Values    : coder Channel Fd and analog channel no.
*  Output Values   : none
*  Return Value    : success/fail
*  Notes           :
****************************************************************************/
int32 IFX_MMGR_TAPI_AddDataChannelToPcm(int32 iFd,uint16 nPcmChNum)
{
	IFX_TAPI_MAP_DATA_t xDataMap;
	memset(&xDataMap,0,sizeof(xDataMap));
	xDataMap.nDstCh = nPcmChNum;
	xDataMap.nChType = IFX_TAPI_MAP_TYPE_PCM;
	return ioctl(iFd,IFX_TAPI_MAP_DATA_ADD,&xDataMap);
}
/*****************************************************************************
*  Function Name   : IFX_APP_RemoveDataChannelFromAnalog
*  Description     : This Function removes a coder channel from a analog 
*                    channel
*  Input Values    : coder Channel Fd and analog channel no.
*  Output Values   : none
*  Return Value    : success/fail
*  Notes           :
****************************************************************************/
int32 IFX_MMGR_TAPI_RemoveDataChannelFromPcm(int32 iFd,uint16 nPcmChNum)
{
	IFX_TAPI_MAP_DATA_t xDataMap;
	memset(&xDataMap,0,sizeof(xDataMap));
	xDataMap.nDstCh = nPcmChNum;
	xDataMap.nChType = IFX_TAPI_MAP_TYPE_PCM;
	return ioctl(iFd,IFX_TAPI_MAP_DATA_REMOVE,&xDataMap);
}

/*****************************************************************************
*  Function Name   : IFX_APP_AddAnalogToAnalog
*  Description     : This Function adds an analog channel to an analog 
*                    channel
*  Input Values    : Analog Channel Fd and analog channel no.
*  Output Values   : none
*  Return Value    : success/fail
*  Notes           :
****************************************************************************/
int32 IFX_MMGR_TAPI_AddAnalogToAnalog(int32 iFd,uint16 unAnalogChNum)
{
	IFX_TAPI_MAP_PHONE_t xPhoneMap={0};
	xPhoneMap.nPhoneCh = unAnalogChNum;
	return ioctl(iFd,IFX_TAPI_MAP_PHONE_ADD,&xPhoneMap);
}
/*****************************************************************************
*  Function Name   : IFX_APP_RemoveAnalogFromAnalog
*  Description     : This Function removes an analog channel from an analog 
*                    channel
*  Input Values    : Analog Channel Fd and analog channel no.
*  Output Values   : none
*  Return Value    : success/fail
*  Notes           :
****************************************************************************/
int32 IFX_MMGR_TAPI_RemoveAnalogFromAnalog(int32 iFd,uint16 unAnalogChNum)
{
	IFX_TAPI_MAP_PHONE_t xPhoneMap={0};
	xPhoneMap.nPhoneCh = unAnalogChNum;
	return ioctl(iFd,IFX_TAPI_MAP_PHONE_REMOVE,&xPhoneMap);
}

/*****************************************************************************
 **  Function Name   : IFX_APP_AddAnalogToPCM
 **  Description     : This Function adds/removes an PCM channel to an analog
 **                    channel
 **  Input Values    : PCM Channel Fd and analog channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_AddPcmToAnalog(int32 iFd,uint16 unAnalogChNum)
{
	IFX_TAPI_MAP_PCM_t xPcmMap = {0};
	xPcmMap.nDstCh = unAnalogChNum;
#ifdef CVOIP_SUPPORT
	xPcmMap.nChType = IFX_TAPI_MAP_TYPE_DEFAULT;
#else
	xPcmMap.nChType = IFX_TAPI_MAP_TYPE_PHONE;
#endif
	
	printf("Calling ioctl IFX_TAPI_MAP_PCM_ADD Channel Number %d Map type %d\n",
										unAnalogChNum,IFX_TAPI_MAP_TYPE_PHONE);
	return ioctl(iFd,IFX_TAPI_MAP_PCM_ADD,&xPcmMap);
}

/*****************************************************************************
 **  Function Name   : IFX_APP_AddPcmToDect
 **  Description     : This Function adds/removes an PCM channel to a DECT
 **                    channel
 **  Input Values    : PCM Channel Fd and DECT channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_AddPcmToDect(int32 iFd,uint16 unDectChNum)
{
	IFX_TAPI_MAP_PCM_t xPcmMap = {0};
	xPcmMap.nDstCh = unDectChNum;
	xPcmMap.nChType = IFX_TAPI_MAP_TYPE_DECT;
	return ioctl(iFd,IFX_TAPI_MAP_PCM_ADD,&xPcmMap);
}
/*****************************************************************************
 **  Function Name   : IFX_APP_RemoveAnalogFromPCM
 **  Description     : This Function removes an PCM channel to an analog
 **                    channel
 **  Input Values    : PCM Channel Fd and analog channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_RemovePcmFromAnalog(int32 iFd,uint16 unAnalogChNum)
{
   IFX_TAPI_MAP_PCM_t xPcmMap = {0};
   xPcmMap.nDstCh = unAnalogChNum;
   xPcmMap.nChType = IFX_TAPI_MAP_TYPE_DEFAULT;
   return ioctl(iFd,IFX_TAPI_MAP_PCM_REMOVE,&xPcmMap);
}

/*****************************************************************************
 **  Function Name   : IFX_APP_RemoveDectFromPCM
 **  Description     : This Function removes an PCM channel to a DECT
 **                    channel
 **  Input Values    : PCM Channel Fd and analog channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_RemovePcmFromDect(int32 iFd,uint16 unDectChNum)
{
   IFX_TAPI_MAP_PCM_t xPcmMap = {0};
   xPcmMap.nDstCh = unDectChNum;
   xPcmMap.nChType = IFX_TAPI_MAP_TYPE_DECT;
   return ioctl(iFd,IFX_TAPI_MAP_PCM_REMOVE,&xPcmMap);
}

/*****************************************************************************
 **  Function Name   : IFX_APP_AddDataChannelToPCM
 **  Description     : This Function adds/removes a coder channel to a PCM
 **                    channel
 **  Input Values    : coder Channel Fd and PCM channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_AddDataChannelToPCM(int32 iFd,uint16 nPCMChNum)
{
   IFX_TAPI_MAP_DATA_t xDataMap;
   memset(&xDataMap,0,sizeof(xDataMap));
   xDataMap.nDstCh = nPCMChNum;
   xDataMap.nChType = IFX_TAPI_MAP_TYPE_PCM;
   return ioctl(iFd,IFX_TAPI_MAP_DATA_ADD,&xDataMap);
}
/*****************************************************************************
 **  Function Name   : IFX_APP_RemoveDataChannelFromPCM
 **  Description     : This Function adds/removes a coder channel to a PCM
 **                    channel
 **  Input Values    : coder Channel Fd and PCM channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_RemoveDataChannelFromPCM(int32 iFd,uint16 nPCMChNum)
{
   IFX_TAPI_MAP_DATA_t xDataMap;
   memset(&xDataMap,0,sizeof(xDataMap));
   xDataMap.nDstCh = nPCMChNum;
   xDataMap.nChType = IFX_TAPI_MAP_TYPE_PCM;
   return ioctl(iFd,IFX_TAPI_MAP_DATA_REMOVE,&xDataMap);
}

/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_HookTimeUpdate
*  Description      : This Function Configures the Hook Timings
*  Input Values     : Channel Num, 
*  Output Values    : None
*  Return Value     : IFX_APP_SUCCESSESS,IFX_APP_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_HookTimeUpdate(int32 iChFd,x_IFX_MMGR_CountrySettingsParams *pxParams)
{
  IFX_TAPI_LINE_HOOK_VT_t xHookParams;
  memset(&xHookParams,0,sizeof(xHookParams));
	int32 iRetVal;

#if 1
  /* Set the Off Hook Time */
  xHookParams.nType =
                    IFX_TAPI_LINE_HOOK_VT_HOOKOFF_TIME;
  xHookParams.nMinTime = pxParams->uiOffHookMinDuration;
  xHookParams.nMaxTime = pxParams->uiOffHookMaxDuration;
  iRetVal =  ioctl(iChFd,IFX_TAPI_LINE_HOOK_VT_SET,&xHookParams);
  if(iRetVal < 0)
  {
	 printf("Error in Updating the Off Hook duration!!");
    return iRetVal;
  }
  /* Set the On Hook Time */
  xHookParams.nType = IFX_TAPI_LINE_HOOK_VT_HOOKON_TIME;
  xHookParams.nMinTime = pxParams->uiOnHookMinDuration;
  xHookParams.nMaxTime = pxParams->uiOnHookMaxDuration;
  iRetVal =  ioctl(iChFd,IFX_TAPI_LINE_HOOK_VT_SET,&xHookParams);
  if(iRetVal < 0)
  {
	  printf("Error in Updating the ON Hook duration!!");
     return iRetVal;
  }
#endif
  /* Set the hook flash time */
  xHookParams.nType = IFX_TAPI_LINE_HOOK_VT_HOOKFLASH_TIME;
  xHookParams.nMinTime = pxParams->uiHookFlashMinDuration;
  xHookParams.nMaxTime = pxParams->uiHookFlashMaxDuration;
  return ioctl(iChFd,IFX_TAPI_LINE_HOOK_VT_SET,&xHookParams);
  /* Set the hook flash time */
}

/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_CidConfigure
*  Description      : This Function Configures CID Settings
*  Input Values     : Channel Num, 
*  Output Values    : None
*  Return Value     : IFX_APP_SUCCESSESS,IFX_APP_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_CidConfigure(int32 iChFd,e_IFX_MMGR_CidStd eCidType)
{
	IFX_TAPI_CID_CFG_t xCidCfg;
	memset(&xCidCfg,0,sizeof(IFX_TAPI_CID_CFG_t));
	if(eCidType == IFX_MMGR_CID_STD_TELCORDIA)
	{
		xCidCfg.nStandard = IFX_TAPI_CID_STD_TELCORDIA;
		printf(" Cid Std Telcordia\n");
	}
	else if(eCidType == IFX_MMGR_CID_STD_ETSI)
		xCidCfg.nStandard = IFX_TAPI_CID_STD_ETSI_FSK;
	else if(eCidType == IFX_MMGR_CID_STD_NTT)
		xCidCfg.nStandard = IFX_TAPI_CID_STD_NTT;
	else if(eCidType == IFX_MMGR_CID_STD_SIN)
		xCidCfg.nStandard = IFX_TAPI_CID_STD_SIN;
	else
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Invalid Cid Std");
		return IFX_MMGR_FAIL;
	}
	if(ioctl(iChFd,IFX_TAPI_CID_CFG_SET,&xCidCfg) < 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "iConfiguring the CID Std");
		return IFX_MMGR_FAIL;
	}
	return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_SetOffHook
*  Description      : This Function sets the fxo line to offhook
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_SetHookMode(int32 iChFd,uint32 uiHookMode)
{
#ifdef SLIC121
	static int i =0;
	IFX_TAPI_FXO_LINE_MODE_t param;

	if (i == 0) {
		memset (&param, 0, sizeof (param));

		// set FXO line mode to ACTIVE
		param.mode = IFX_TAPI_FXO_LINE_MODE_ACTIVE;

		if (ioctl (iChFd, IFX_TAPI_FXO_LINE_MODE_SET, (IFX_uintptr_t) &param) != IFX_SUCCESS)
			IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, "FXO Activate Failed ");

		i++;
	}
#endif

    if(uiHookMode == IFX_MMGR_FXO_OFFHOOK)
    {
        return ioctl(iChFd,IFX_TAPI_FXO_HOOK_SET,1);
    }
    if(uiHookMode == IFX_MMGR_FXO_ONHOOK)
    {
        return ioctl(iChFd,IFX_TAPI_FXO_HOOK_SET,0);
    }
    return IFX_MMGR_FAIL;
}

/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_PayLoadTblSet
*  Description      : This Function sets up the payload type table
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_PayLoadTblSet(int32 iChFd,
											  x_IFX_MMGR_CodecList *pxCodecList
											  )
{
	IFX_TAPI_PKT_RTP_PT_CFG_t xRtpPtTbl;
	x_IFX_MMGR_CodecInfo *pxCodecInfo;
    uint16 unCount;
	if(pxCodecList == NULL)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Codec List is Empty");
		return IFX_MMGR_FAIL;
	}
	memset(&xRtpPtTbl,99,sizeof(IFX_TAPI_PKT_RTP_PT_CFG_t));
	for(unCount = 0; unCount < pxCodecList->ucNoOfCodecs; unCount++)
	{
		pxCodecInfo = &pxCodecList->axCodecs[unCount];
		xRtpPtTbl.nPTup[staeTapiCodec[pxCodecInfo->eCodecType]] =
								pxCodecInfo->ucIANA_PayloadType;
		xRtpPtTbl.nPTdown[staeTapiCodec[pxCodecInfo->eCodecType]] = 
									pxCodecInfo->ucIANA_PayloadType;
	}
	return ioctl(iChFd, IFX_TAPI_PKT_RTP_PT_CFG_SET, (IFX_int32_t) &xRtpPtTbl);
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_RTPConfig
*  Description      : This Function sets up the RTP parameters
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_RtpConfig(
										  IN int32 iChFd,
										  IN uint16 unSeqNo,
										  IN int32 iSSRC,
										  IN x_IFX_MMGR_TelephonyEvent_Info *pxTelEvent
										  )
{
	IFX_TAPI_PKT_RTP_CFG_t xRtpCfg;
	memset(&xRtpCfg,0,sizeof(IFX_TAPI_PKT_RTP_CFG_t));
	xRtpCfg.nSeqNr = unSeqNo;
	xRtpCfg.nSsrc = iSSRC;
	if(pxTelEvent->eEventTransMode  == IFX_MMGR_TEL_EVENT_NONE)
	{
		xRtpCfg.nEventPT = 127;
		xRtpCfg.nEventPlayPT = 127;/*pxTelEvent->ucPayLoadTypeRx ;*/
		xRtpCfg.nEvents = IFX_TAPI_PKT_EV_OOB_BLOCK;
		xRtpCfg.nPlayEvents = IFX_TAPI_PKT_EV_OOBPLAY_MUTE;
	}
	else if(pxTelEvent->eEventTransMode == IFX_MMGR_TEL_EVENT_VOICE_IN_BAND)
	{
		xRtpCfg.nEvents = IFX_TAPI_PKT_EV_OOB_NO ;
		xRtpCfg.nEventPT = 127;
		/*xRtpCfg.nEventPT = pxTelEvent->ucPayLoadTypeTx;*/
		xRtpCfg.nPlayEvents = IFX_TAPI_PKT_EV_OOBPLAY_MUTE;
	}
	else if(pxTelEvent->eEventTransMode == IFX_MMGR_TEL_EVENT_RFC_2833)
	{
		xRtpCfg.nEvents = IFX_TAPI_PKT_EV_OOB_ONLY ;
		xRtpCfg.nEventPT = pxTelEvent->ucPayLoadTypeTx;
	}
	else if(pxTelEvent->eEventTransMode == IFX_MMGR_TEL_EVENT_VOICE_IN_BAND_RFC_2833)
	{
		xRtpCfg.nEvents = IFX_TAPI_PKT_EV_OOB_ALL ;
		xRtpCfg.nEventPT = pxTelEvent->ucPayLoadTypeTx;
	}

	if(0 == xRtpCfg.nEventPT) {
		xRtpCfg.nEventPT =127;
	}
	if(pxTelEvent->eAction == IFX_MMGR_TEL_EVENT_MUTE)
	{
		xRtpCfg.nPlayEvents = IFX_TAPI_PKT_EV_OOBPLAY_MUTE;
	}
	else if(pxTelEvent->eAction == IFX_MMGR_TEL_EVENT_PLAY)
	{
		if(pxTelEvent->ucPayLoadTypeRx == pxTelEvent->ucPayLoadTypeTx)
		{
			xRtpCfg.nPlayEvents = IFX_TAPI_PKT_EV_OOBPLAY_PLAY;
		}
		else
		{
			xRtpCfg.nPlayEvents = IFX_TAPI_PKT_EV_OOBPLAY_APT_PLAY;
		}
	}
	return ioctl(iChFd, IFX_TAPI_PKT_RTP_CFG_SET, &xRtpCfg);
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_DectChCfg
*  Description      : This Function sets up the RTP parameters
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectChCfg(
								      IN int32 iFd)
{
	IFX_TAPI_DECT_CFG_t xDectCfg;
	IFX_TAPI_DECT_ENC_CFG_SET_t xDectEncCfg;

	memset(&xDectCfg, 0 , sizeof(IFX_TAPI_DECT_CFG_t));
	memset(&xDectEncCfg, 0 , sizeof(IFX_TAPI_DECT_ENC_CFG_SET_t)); /* narendra - redundant statement */
	
	//Mahipati: This fails if channel is already activated ???
	IFX_MMGR_TAPI_DectDeActivate(iFd); 

	/* narendra - where is xDectCfg getting populated */
	if(ioctl(iFd, IFX_TAPI_DECT_CFG_SET, &xDectCfg) < 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Dect Cfg Failed");
		return IFX_MMGR_FAIL;
	}
#if 0 
	xDectEncCfg.nEncType = IFX_TAPI_DECT_ENC_TYPE_G726_32;
	xDectEncCfg.nFrameLen = IFX_TAPI_DECT_ENC_LENGTH_10;
	if(ioctl(iFd, IFX_TAPI_DECT_ENC_CFG_SET, &xDectEncCfg) < 0)
	{
		printf("Dect codec configuration failed\n");
		return IFX_MMGR_FAIL;
	}
#endif
	return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_DectChCfg
*  Description      : This Function sets up the RTP parameters
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectActivate(
								      IN int32 iFd)
{
	if(ioctl(iFd , IFX_TAPI_DECT_ACTIVATION_SET, IFX_ENABLE) < 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Dect Channel Activation Failed");
		return IFX_MMGR_FAIL;
	}
#if 0
	if(ioctl(iFd,IFX_TAPI_TONE_DECT_STOP,0) < 0)
	{
					printf("stop tone on dect failed\n");
	}
#endif
	return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_DectEncSet
*  Description      : This Function sets the ENC type on the dect channel
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectEncSet(
								      IN int32 iFd,
									  x_IFX_MMGR_CodecInfo *pxCodec)
{
	IFX_TAPI_DECT_ENC_CFG_SET_t xDectEncCfg;
	memset(&xDectEncCfg, 0 , sizeof(IFX_TAPI_DECT_ENC_CFG_SET_t));
	/* This is the default lenght being used */
	xDectEncCfg.nFrameLen = IFX_TAPI_DECT_ENC_LENGTH_10;
	switch(pxCodec->eCodecType)
	{
		case IFX_MMGR_CODEC_G722_64 :
			xDectEncCfg.nEncType = IFX_TAPI_DECT_ENC_TYPE_G722_64;
			break;
		case IFX_MMGR_CODEC_G726_32:
			xDectEncCfg.nEncType = IFX_TAPI_DECT_ENC_TYPE_G726_32;
			break;
		default:
			return IFX_MMGR_FAIL;
	}
#if 1 
	if(ioctl(iFd, IFX_TAPI_DECT_ENC_CFG_SET, &xDectEncCfg) < 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Dect Enc Cfg Failed");
		return IFX_MMGR_FAIL;
	}
#endif
	return IFX_MMGR_SUCCESS;
}

/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_DectChCfg
*  Description      : This Function sets up the RTP parameters
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_DectDeActivate(
								      IN int32 iFd)
{
	if(ioctl(iFd , IFX_TAPI_DECT_ACTIVATION_SET, IFX_DISABLE) < 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Dect Channel Deactivation  Failed");
		return IFX_MMGR_FAIL;
	}
	return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_AddDectToDect
*  Description      : This Function connects two dect channels
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_AddDectToDect(
								      IN int32 iFd,
									  IN uint16 unChannelNum)
{
	IFX_TAPI_MAP_DECT_t xDectMap;
	memset(&xDectMap,0,sizeof(xDectMap));
	xDectMap.nDstCh = unChannelNum;
	xDectMap.nChType = IFX_TAPI_MAP_TYPE_DECT;
	if(ioctl(iFd, IFX_TAPI_MAP_DECT_ADD , &xDectMap) < 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Error Adding Dect to Dect");
		return IFX_MMGR_FAIL;
	}
	return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_RemoveDectFromDect
*  Description      : This Function connects two dect channels
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_RemoveDectFromDect(
								      IN int32 iFd,
									  IN uint16 unChannelNum)
{
	IFX_TAPI_MAP_DECT_t xDectMap;
	memset(&xDectMap,0,sizeof(xDectMap));
	xDectMap.nDstCh = unChannelNum;
	xDectMap.nChType = IFX_TAPI_MAP_TYPE_DECT;
	if(ioctl(iFd, IFX_TAPI_MAP_DECT_REMOVE , &xDectMap) < 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          "Error Removing Dect from Dect");
		return IFX_MMGR_FAIL;
	}
	return IFX_MMGR_SUCCESS;
}
/*****************************************************************************
*  Function Name   : IFX_APP_AddDataChannelToDect
*  Description     : This Function adds/removes a coder channel to a dect 
*                    channel
*  Input Values    : coder Channel Fd and analog channel no.
*  Output Values   : none
*  Return Value    : success/fail
*  Notes           :
****************************************************************************/
int32 IFX_MMGR_TAPI_AddDataChannelToDect(int32 iFd,uint16 nDectChNum)
{
	IFX_TAPI_MAP_DATA_t xDataMap;
	memset(&xDataMap,0,sizeof(xDataMap));
	xDataMap.nDstCh = nDectChNum;
#ifdef CVOIP_SUPPORT
	xDataMap.nChType = IFX_TAPI_MAP_TYPE_PCM;
#else
	xDataMap.nChType = IFX_TAPI_MAP_TYPE_DECT;
#endif
	return ioctl(iFd,IFX_TAPI_MAP_DATA_ADD,&xDataMap);
}
/*****************************************************************************
*  Function Name   : IFX_APP_RemoveDataChannelFromDect
*  Description     : This Function removes a coder channel from a dect 
*                    channel
*  Input Values    : coder Channel Fd and analog channel no.
*  Output Values   : none
*  Return Value    : success/fail
*  Notes           :
****************************************************************************/
int32 IFX_MMGR_TAPI_RemoveDataChannelFromDect(int32 iFd,uint16 nDectChNum)
{
	IFX_TAPI_MAP_DATA_t xDataMap;
	memset(&xDataMap,0,sizeof(xDataMap));
	xDataMap.nDstCh = nDectChNum;
	xDataMap.nChType = IFX_TAPI_MAP_TYPE_DECT;
	return ioctl(iFd,IFX_TAPI_MAP_DATA_REMOVE,&xDataMap);
}
/*****************************************************************************
 **  Function Name   : IFX_APP_AddDectToAnalog
 **  Description     : This Function adds/removes an dect channel to an analog
 **                    channel
 **  Input Values    : dect Channel Fd and analog channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_AddDectToAnalog(int32 iFd,uint16 unAnalogChNum)
{
	IFX_TAPI_MAP_DECT_t xDectMap = {0};
	xDectMap.nDstCh = unAnalogChNum;
	xDectMap.nChType = IFX_TAPI_MAP_TYPE_PHONE;
#ifdef CVOIP_SUPPORT
	printf("Calling ioctl IFX_TAPI_MAP_PCM_ADD Channel Number %d Map type %d\n",
										unAnalogChNum,IFX_TAPI_MAP_TYPE_PHONE);
	return ioctl(iFd,IFX_TAPI_MAP_PCM_ADD,&xDectMap);
	
#else
	return ioctl(iFd,IFX_TAPI_MAP_DECT_ADD,&xDectMap);
#endif
}
#if 0
/*****************************************************************************
 **  Function Name   : IFX_APP_AddDectToDect
 **  Description     : This Function adds/removes an dect channel to an Dect
 **                    channel
 **  Input Values    : dect Channel Fd and analog channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_AddDectToDect(int32 iFd,uint16 unDectChNum)
{
	IFX_TAPI_MAP_DECT_t xDectMap = {0};
	xDectMap.nDstCh = unDectChNum;
	xDectMap.nChType = IFX_TAPI_MAP_TYPE_DECT;
	return ioctl(iFd,IFX_TAPI_MAP_DECT_ADD,&xDectMap);
}
#endif

/*****************************************************************************
 **  Function Name   : IFX_APP_RemoveDectFromAnalog
 **  Description     : This Function removes an dect channel to an analog
 **                    channel
 **  Input Values    : dect Channel Fd and analog channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_RemoveDectFromAnalog(int32 iFd,uint16 unAnalogChNum)
{
   IFX_TAPI_MAP_DECT_t xDectMap = {0};
   xDectMap.nDstCh = unAnalogChNum;
   xDectMap.nChType = IFX_TAPI_MAP_TYPE_PHONE;
#ifdef CVOIP_SUPPORT
	printf("Calling ioctl IFX_TAPI_MAP_PCM_REMOVE Channel Number %d Map type %d\n",
										unAnalogChNum,IFX_TAPI_MAP_TYPE_PHONE);
	
   return ioctl(iFd,IFX_TAPI_MAP_PCM_REMOVE,&xDectMap);
#else
   return ioctl(iFd,IFX_TAPI_MAP_DECT_REMOVE,&xDectMap);
#endif
}
#if 0
/*****************************************************************************
 **  Function Name   : IFX_APP_RemoveDectFromDect
 **  Description     : This Function removes an dect channel to a DECT
 **                    channel
 **  Input Values    : dect Channel Fd and Dect channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
int32 IFX_MMGR_TAPI_RemoveDectFromDect(int32 iFd,uint16 unDectChNum)
{
   IFX_TAPI_MAP_DECT_t xDectMap = {0};
   xDectMap.nDstCh = unDectChNum;
   xDectMap.nChType = IFX_TAPI_MAP_TYPE_DECT;
   return ioctl(iFd,IFX_TAPI_MAP_DECT_REMOVE,&xDectMap);
}
#endif
/*****************************************************************************
 **  Function Name   : IFX_APP_KpiConfig
 **  Description     : This Function removes an dect channel to an analog
 **                    channel
 **  Input Values    : dect Channel Fd and analog channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_KpiCfg(int32 iFd,int32 iKpiChNum)
{
	IFX_TAPI_KPI_CH_CFG_t xKpiChCfg;
	memset(&xKpiChCfg,0,sizeof(IFX_TAPI_KPI_CH_CFG_t));
	xKpiChCfg.nStream = IFX_TAPI_KPI_STREAM_DECT;
	xKpiChCfg.nKpiCh = IFX_TAPI_KPI_GROUP2 | iKpiChNum;
	return ioctl(iFd, IFX_TAPI_KPI_CH_CFG_SET, &xKpiChCfg);
}
/*****************************************************************************
 **  Function Name   : IFX_MMGR_SigDetect
 **  Description     : This Function Enables/Disables Signal detection
 **     
 **  Input Values    : dect Channel Fd and analog channel no.
 **  Output Values   : none
 **  Return Value    : success/fail
 **  Notes           :
 *****************************************************************************/
e_IFX_MMGR_Return IFX_MMGR_SigDetect(int32 iFd, boolean bEnable)
{
		int32 iRetVal;
    IFX_TAPI_SIG_DETECTION_t xSigDetect;
    memset(&xSigDetect,0,sizeof(IFX_TAPI_SIG_DETECTION_t));
		static uint32 i = 		
    (	IFX_TAPI_SIG_DISRX|IFX_TAPI_SIG_DISTX|IFX_TAPI_SIG_DIS|IFX_TAPI_SIG_CEDRX|
  		IFX_TAPI_SIG_CEDTX|IFX_TAPI_SIG_CED|IFX_TAPI_SIG_CNGFAXRX|IFX_TAPI_SIG_CNGFAXTX|
   		IFX_TAPI_SIG_CNGFAX|IFX_TAPI_SIG_CNGMODRX|IFX_TAPI_SIG_CNGMODTX|IFX_TAPI_SIG_CNGMOD|
   		IFX_TAPI_SIG_PHASEREVRX|IFX_TAPI_SIG_PHASEREVTX|IFX_TAPI_SIG_PHASEREV|IFX_TAPI_SIG_AMRX|
   		IFX_TAPI_SIG_AMTX|IFX_TAPI_SIG_AM|IFX_TAPI_SIG_TONEHOLDING_ENDRX|IFX_TAPI_SIG_TONEHOLDING_ENDTX|
   		IFX_TAPI_SIG_TONEHOLDING_END|IFX_TAPI_SIG_CEDENDRX|IFX_TAPI_SIG_CEDENDTX|IFX_TAPI_SIG_CEDEND|
   		IFX_TAPI_SIG_V8BISRX|IFX_TAPI_SIG_V8BISTX|IFX_TAPI_SIG_DTMFTX|IFX_TAPI_SIG_EXT_CASBELL|
		IFX_TAPI_SIG_EXT_CASBELLTX|IFX_TAPI_SIG_EXT_CASBELLRX);
    
	 xSigDetect.sig = i;
	 /* Enable Signal Detetion */
		if(bEnable){
        iRetVal = ioctl(iFd,IFX_TAPI_SIG_DETECT_ENABLE,
                        &xSigDetect);
		}
		else {
        iRetVal = ioctl(iFd,IFX_TAPI_SIG_DETECT_DISABLE,
                        &xSigDetect);
			printf("<Tapi_SigDetect> Disable MFTD\n");
			IFX_MMGR_TAPI_EnableMftd(iFd,0,bEnable);
			printf("<Tapi_SigDetect> Disable LEC \n");
			IFX_MMGR_TAPI_LecConfigure(iFd,0,0,0);

		}

		if(iRetVal < 0)
		{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          	"Error Enabling - Disabling the signal detection");
				return IFX_MMGR_FAIL;
		}
			return IFX_MMGR_SUCCESS;

}

e_IFX_MMGR_Return IFX_MMGR_TAPI_EnableMftd(int32 iFd,uint16 unChannelNum, boolean bEnable)
{
		int32 iRetVal;
    IFX_TAPI_SIG_DETECTION_t xSigDetect;
	 

    memset(&xSigDetect,0,sizeof(IFX_TAPI_SIG_DETECTION_t));
	 
    xSigDetect.sig = IFX_TAPI_SIG_CEDTX;
		 
		if(bEnable)
		{
        iRetVal = ioctl(iFd,
                        IFX_TAPI_SIG_DETECT_ENABLE,
                        &xSigDetect);
		}
		else
		{
        iRetVal = ioctl(iFd,
                        IFX_TAPI_SIG_DETECT_DISABLE,
                        &xSigDetect);
		}
		if(iRetVal < 0)
		{
				IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          	"Error Enabling the siganle detection");
				return IFX_MMGR_FAIL;
		}
			return IFX_MMGR_SUCCESS;
}
/*******************************************************************
*  Function Name    : IFX_MMGR_TAPI_FSKDataRcv
*  Description      : This Function gets the cid data from the sig channel
*  Input Values     : Channel fd 
*  Output Values    : None
*  Return Value     : IFX_MMGR_SUCCESSESS,IFX_MMGR_FAIL
*  Notes            :
*********************************************************************/
e_IFX_MMGR_Return IFX_MMGR_TAPI_FSKDataRcv(
											int32 iFd,
											uchar8* pucData,
											int32 *piDataSize
		)
{
	IFX_TAPI_CID_RX_DATA_t xCidRxData;
	memset(&xCidRxData,0,sizeof(IFX_TAPI_CID_RX_DATA_t));
	if(ioctl(iFd,IFX_TAPI_CID_RX_DATA_GET,&xCidRxData) < 0)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          	"TAPI Error getting the CID Rx Data");
		return IFX_MMGR_FAIL;
	}
	*piDataSize = xCidRxData.nSize;
	memcpy(pucData,&xCidRxData.data[0],xCidRxData.nSize);

/*
	memcpy(pucData,xCidRxData.data,xCidRxData.nSize);
	*piDataSize = xCidRxData.nSize;*/
	return IFX_MMGR_SUCCESS;
}

e_IFX_MMGR_Return IFX_MMGR_TAPI_GenerateRFC2833Packet(int32 iFd, uchar8 ucDigit)
{
	//IFX_TAPI_PKT_EV_GENERATE_CFG_t xEvCfg = {0};
	IFX_TAPI_PKT_EV_GENERATE_t xEvent = {0};
	//xEvCfg.local = IFX_TRUE;
#if 0
	if(ioctl(iFd, IFX_TAPI_PKT_EV_GENERATE_CFG,&xEvCfg)!= IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          	"TAPI  RFC 2833 Event Cfg Failed");
		return IFX_MMGR_FAIL;
	}
#endif
	xEvent.event = ucDigit;
	xEvent.action = IFX_TAPI_EV_GEN_START;
	/* Generate the packet for 80 ms duration */
	xEvent.duration = 8;
	if(ioctl(iFd,IFX_TAPI_PKT_EV_GENERATE,&xEvent) != IFX_MMGR_SUCCESS)
	{
		IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
          	"TAPI  RFC 2833 Event Generation Failed");
		return IFX_MMGR_FAIL;
	}
	return IFX_MMGR_SUCCESS;
}
#if 0
/** GR909 test start */
typedef struct
{
   /** Device number (in). */
   uint16 dev;
   /** Channel number (in). */
   uint16 ch;
   /** GR909 powerline frequency to use.
    See \ref IFX_TAPI_GR909_POWERLINE_FREQ_t. */
   int32     pl_freq;
   /** GR909 test mask as value or combination of tests in
       \ref IFX_TAPI_GR909_TEST_t. */
   uint32                  test_mask;
} IFX_TAPI_GR909_START_t_Local;
#endif
e_IFX_MMGR_Return IFX_MMGR_TAPI_FlushErr(int32 iDevFd)
{
	IFX_TAPI_Error_t error;
	return  ioctl(iDevFd, IFX_TAPI_LASTERR, (int32)&error);
}
e_IFX_MMGR_Return IFX_MMGR_TAPI_GR909TestStart(int32 iFd,x_IFX_MMGR_GR909_Param *pxParam)
{
	int32 iRet;
#if 0
	IFX_TAPI_GR909_START_t_Local x_GR909_Start;
	memset(&x_GR909_Start,0,sizeof(x_GR909_Start));
	x_GR909_Start.pl_freq=IFX_TAPI_GR909_EU_50HZ;
	x_GR909_Start.test_mask=pxParam->uiTests;
	sleep(1);
	if(IFX_SUCCESS != ioctl(iFd,IFX_TAPI_GR909_START,&x_GR909_Start))
	{
		printf("\n IFX_TAPI_GR909_START ioctl failed \n");
	}
#endif
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Calling GR909 Start Lib ");
	//iRet= Ifxphone_LT_GR909_Start(iFd,((pxParam->eFreq == IFX_TAPI_GR909_EU_50HZ) ? IFX_TRUE : IFX_FALSE),pxParam->uiTests);
	iRet= Ifxphone_LT_GR909_Start(iFd,IFX_TRUE,pxParam->uiTests);
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"after Calling GR909 Start Lib ");
	return iRet;
}
e_IFX_MMGR_Return IFX_MMGR_TAPI_GR909TestStop(int32 iFd)
{
	//return ioctl(iFd,IFX_TAPI_GR909_STOP,0);
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Calling GR909 Stop Lib ");
	return Ifxphone_LT_GR909_Stop(iFd);
}

e_IFX_MMGR_Return IFX_MMGR_TAPI_GetGR909Result(int32 iFd, x_IFX_MMGR_GR909_Result *pxResult)
{
	int32 iRet;
	IFX_LT_GR909_RESULT_t xGR909Results;
	memset(&xGR909Results,0,sizeof(IFX_LT_GR909_RESULT_t));
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"Calling GR909 Results Lib ");
	iRet= Ifxphone_LT_GR909_GetResults(iFd, &xGR909Results);
	//return ioctl(iFd,IFX_TAPI_GR909_RESULT,pxResult);
	if(iRet == IFX_SUCCESS)
	{
		//pxResult->uiValidResult = xGR909Results.
		pxResult->uiPassedResult = xGR909Results.valid_mask;

		pxResult->nHPT_AC_R2G = xGR909Results.hpt.f_hpt_ac_r2g;
		pxResult->nHPT_AC_T2G = xGR909Results.hpt.f_hpt_ac_t2g;
		pxResult->nHPT_AC_T2R = xGR909Results.hpt.f_hpt_ac_t2r;
		pxResult->nHPT_DC_R2G = xGR909Results.hpt.f_hpt_dc_r2g;
		pxResult->nHPT_DC_T2G = xGR909Results.hpt.f_hpt_dc_t2g;
		pxResult->nHPT_DC_T2R = xGR909Results.hpt.f_hpt_dc_t2r;

		pxResult->nFEMF_AC_R2G = xGR909Results.femf.f_femf_ac_r2g;
		pxResult->nFEMF_AC_T2G = xGR909Results.femf.f_femf_ac_t2g; 
		pxResult->nFEMF_AC_T2R = xGR909Results.femf.f_femf_ac_t2r;
		pxResult->nFEMF_DC_R2G = xGR909Results.femf.f_femf_dc_r2g;
		pxResult->nFEMF_DC_T2G = xGR909Results.femf.f_femf_dc_t2g;
		pxResult->nFEMF_DC_T2R = xGR909Results.femf.f_femf_dc_t2r; 

		pxResult->nRFT_R2G = xGR909Results.rft.f_rft_r2g;
		pxResult->nRFT_T2G = xGR909Results.rft.f_rft_t2g;
		pxResult->nRFT_T2R = xGR909Results.rft.f_rft_t2r;

		pxResult->nROH_T2R_L = xGR909Results.roh.f_roh_t2r_l;
		pxResult->nROH_T2R_H = xGR909Results.roh.f_roh_t2r_h;

		pxResult->nRIT_RES = xGR909Results.rit.f_rit_res;

	}
	IFX_DBGA(vucMmgrModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
				"after Calling GR909 Results Lib ");
	return iRet;
}











	

											
