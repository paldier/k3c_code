/**************************************************************************
 **   SRC_FILE          :IFX_DP.h 
 **   PROJECT           : DECT-VOIP GW
 **   MODULES          : 
 **   SRC VERSION       : v0.1
 **   DATE                  : 
 **   AUTHOR            : Voip-Gw Team
 **   DESCRIPTION   : 
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$ 
 **   $Date$ 
 **   $Revisions$
 **   $Log$
 **************************************************************************/
# ifndef __IFX_DP_H____
# define __IFX_DP_H____

# define ST_SMALL_TIM IFX_DP_ST_SMALL_TIM
# define ST_LARGE_TIM IFX_DP_ST_LARGE_TIM
# define DIALOUT IFX_DP_DIALOUT
# define MISMATCH IFX_DP_MISMATCH
                                                                                                                             
# define MATCHED 1
# define CONTINUE 1
# define NOT_MATCHED 0
                                                                                                                             
# define PARTIAL 0
# define FULL 1
                                                                                                                             
# define IFX_IS_RUL_DIG(x) ((x >= '0' && x <= '9') || x == '*' || x == '#' || x == '['|| x == ']')
# define IFX_IS_TEL_DIG(x) ((x >= '0' && x <= '9') || x == '*' || x == '#')
                                                                                                                             
# ifdef DEBUGS_DP
# define Printf printf
# else
# define Printf(...);
# endif

typedef x_IFX_DP_Rule dp_rule;
e_IFX_Return
IFX_DP_RulePrefixGet(IN e_IFX_DP_Action eAction,
                     OUT char8 *pszPrefix);                                                                                                                             
/*Possible values for the state*/
# define NO_MATCH_STATE 0
# define PARTIAL_MATCH_STATE 1
                                                                                                                             
typedef struct
{
 uchar8 ucDpstate;/*state of dial plan FSM, caller will initialize it to NO_MATCH_STATE*/
 uchar8 ucIndex;/*Will contain index of the reule, caller will initialize it to MAX*/
 uchar8 NumRulesMatchedLast;/*Number of dial plan rules matched in last iteration,initialize it to 0*/
 uchar8 ucTim;
}x_dp_pvt_data;
/**For debugging*/
# define IFX_DP_GetAction(eAction) (aszDpActions[eAction])

# endif /* __IFX_DP_H____*/
























