/**************************************************************************
 **   SRC_FILE          :
 **   PROJECT           : DECT-VOIP GW
 **   MODULES          :
 **   SRC VERSION       : v0.1
 **   DATE                  :
 **   AUTHOR            : Voip-Gw Team
 **   DESCRIPTION   :
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
 **************************************************************************/
# ifndef __MISC_H__
# define __MISC_H__
/*enumeration for firewall ports*/
typedef enum
{
                                                                                                                             
   VOIP_SIGNAL_PORT_UDP=0,
   VOIP_SIGNAL_PORT_TCP,
   VOIP_DATA_SPORT,
   VOIP_DATA_EPORT,
   VOIP_TCP_CLIENT_SPORT,
   VOIP_TCP_CLIENT_EPORT,
   FAX_SPORT,
   FAX_LISTEN_EPORT,
   FAX_EPORT,
                                                                                                                             
   OLD_VOIP_SIGNAL_PORT_UDP,
   OLD_VOIP_SIGNAL_PORT_TCP,
   OLD_VOIP_DATA_SPORT,
   OLD_VOIP_DATA_EPORT,
   OLD_VOIP_TCP_CLIENT_SPORT,
   OLD_VOIP_TCP_CLIENT_EPORT,
   OLD_FAX_SPORT,
   OLD_FAX_LISTEN_EPORT,
   OLD_FAX_EPORT,
                                                                                                                             
   VOIP_SIP_PRIORITY,
   VOIP_RTP_PRIORITY,
                                                                                                                             
   OLD_VOIP_SIP_PRIORITY,
   OLD_VOIP_RTP_PRIORITY,
   IFX_MAX_FIREWALL_CFG
                                                                                                                             
}e_IFX_FirewallCfg;

/*Structure for firewall ports*/
typedef struct
{
   uint16  aFwPort[IFX_MAX_FIREWALL_CFG];
                                                                                                                             
}x_IFX_FirewallCfg;

/**A utility function which converts IP address in to standard format*/
e_IFX_Return IFX_ConvertIPAddr ( IN char8 *pcInDigitString,
                                 OUT char8* pcOUTDigitString);
/*A utility function to get time of day*/
e_IFX_Return IFX_GetDateTime(char8 *acDate,char8 *acTime);

/*A Utility function to get two time events and gives number whichever is earlier */
int32 IFX_CompareDateTime(char8 *acTimeOfEvent1,char8 *acTimeOfEvent2);

/* This routine converts Hex string into Hex:Hex: ... format */
void IFX_CIF_ConvertHexToString(char8* pszString, uchar8* puHex, 
																												uint16 unHexLen);

/* This routine converts string Hex:Hex: ... into hex string */
uint16 IFX_CIF_ConvertStringToHex(uchar8* puHex, char8* pszString);

# endif /*__MISC_H__*/


