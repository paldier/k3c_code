/***********************************************************************
*   SRC_FILE           : IFX_MsgRtr.c
*   PROJECT            : VoIP Gateway Subsystem
*   MODULES            : Gateway Application
*   SRC VERSION        : V1.0
*   DATE               : 21/05/2007
*   AUTHOR             : Gw Appln Team
*   DESCRIPTION        :
*   FUNCTIONS          :
*   COMPILER           : mips(el)-linux-gcc
*   REFERENCE          :
*   COPYRIGHT          :Copyright © 2004
*                       Infineon Technologies AG
*                       St. Martin Strasse 53; 81669 München, Germany
*   DESCLAIMER         :Any use of this Software is subject to the conclusion
*                       of a respective License Agreement.
*                       Without such a License Agreement no rights to the
*                       Software are granted.
*   Version Control Section
*   $Author$ 
*   $Date$
*   $Revisions$
*   $Log$       Revision history
***********************************************************************/

#ifndef __MSGRTR_H__
#define __MSGRTR_H__

#define IFX_MAX_FDS				20


typedef struct
{
    x_IFX_MSGRTR_FdInfo       xFdInfo;
    pfn_IFX_MSGRTR_FdCallback   pfnFdCallback; /* 
												 *	if NULL, then this 
												 *	index is assumed to 
												 *	be free 
												 */

} x_IFX_MSGRTR_FdCbInfo;

typedef struct
{
    char8                            acEndptId[IFX_MAX_ENDPOINTID_LEN];
    pfn_IFX_MSGRTR_EventCallback    pfnEventCallback; /* if NULL, then this is free */

} x_IFX_MSGRTR_EndptCbInfo;

typedef struct
{
    x_IFX_MSGRTR_FdCbInfo          xFdCbInfo[IFX_MAX_FDS];
    pfn_IFX_MSGRTR_SipFdCallback   pfnSipFdCallback;
    pfn_IFX_MSGRTR_SipFdCallback   pfnDectFdCallback;
    x_IFX_MSGRTR_EndptCbInfo       xEndptCbInfo[IFX_MAX_ENDPTS];

} x_IFX_MSGRTR_CallBackInfo;



#endif /* __MSGRTR_H__ */


