/**************************************************************************
 **   SRC_FILE          : ifx_cif_ConfigIfc.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES           : Config Interface 
 **   SRC VERSION       : v0.1
 **   DATE              : 
 **   AUTHOR            : Mahipati Deshpande
 **   DESCRIPTION       : 
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$ 
 **   $Date$ 
 **   $Revisions$
 **   $Log$
*******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "ifx_common_defs.h"
#include "IFX_Config.h"

#include "ifx_vmapi_common.h"
#include "ifx_vmapi.h"
#include "ifx_vmapi_api.h"
#include "IFX_Misc.h"
#include "ifx_os.h"

#include "IFX_CallMgrIf.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_CallMgr_CfgIf.h"
#include "IFX_Agents_CfgIf.h"

#ifdef DECT_SUPPORT
#include "IFX_DECT_Stack.h"
#include "IFX_DECT_USU.h"
#include "IFX_DECT_LAU.h"
#include "IFX_DECT_ListAccess.h"
#endif

#include <unistd.h>
#define printf(...)

#define IFX_DECTAPP_MAX_LINES 4
#define IFX_DECTAPP_MAX_DECT_ENDPTS 6
#ifdef DECT_SUPPORT
extern uchar8 vucMissCallReadStatusNtfyFlag;  //For Missed Call Read Status Change Notification
#endif
extern int32 viNewMissedCall;
/* External declarations */
extern int IFX_VMAPI_Init();

#ifdef DECT_SUPPORT
extern x_IFX_DECT_ListInfo vaxListInfo[IFX_DECTAPP_MAX_DECT_ENDPTS][IFX_DECT_LAU_MAX_SESS_PER_HS];
#endif


typedef struct {
	uchar8 ucInterfaceId; /** Interface id of the endpoint */
	e_IFX_EndptType eType; /** Endpoint type */
	char8  szEndptId[IFX_MAX_ENDPOINTID_LEN]; /** Endpoint identifier */
	uchar8 ucDefaultVL; /** Default voice line id of endpoint */
}x_IFX_CIF_EndptData;

/*! \brief This structure is used to store configuration information needed for
	         configuration agent.
*/
typedef struct {
	x_IFX_CIF_EndptData axEndptData[IFX_MAX_ENDPTS];
}x_IFX_CIF_ConfigInfo;

/* Used to store profile RTP/RTCP port range */
typedef struct {
	uint16 unMinRtpPort;
	uint16 unMaxRtpPort;
	uint16 unMinFaxPort;
	uint16 unMaxFaxPort;
	uint16 unNextRtpPort;
	uint16 unNextFaxPort;
}x_IFX_CIF_ProfileMediaPorts;

extern uint16 vunDialToneLength;

/* If line id is not valid, this macro returns IFX_FAILURE */
#define IFX_CIF_VALIDATE_VOICELINE(VoiceLineId, peRsn)  \
	if( VoiceLineId <= 0 || ((VoiceLineId)-1) > IFX_MAX_LINES) \
	{ \
		*peRsn = IFX_CIF_INVALID_VOICELINE; \
		return IFX_FAILURE; \
	}
/* If line is disabled, this macro returns IFX_FAILURE */
#define IFX_CIF_VALIDATE_VOICELINE_STATUS(pxVlInfo,peRsn) \
	if( IFX_VMAPI_VL_STATE_ENABLED != (pxVlInfo)->ucVoiceLineStatus ) \
	{ \
		*peRsn = IFX_CIF_VOICELINE_DISABLED;\
		return IFX_FAILURE;\
	}

#define ifx_cif_cpyToVmapiAddr(pxVmapiAddr, pxAddr) \
	{ \
	   memcpy(pxVmapiAddr,pxAddr,sizeof(x_IFX_VMAPI_Address)); \
	}

#define ifx_cif_cpyFromVmapiAddr(pxAddr,pxVmapiAddr) \
	{ \
		memcpy((pxAddr),(pxVmapiAddr),sizeof(x_IFX_CalledAddr)); \
	}

#define IFX_CIF_copySubsInfoFromVmapi(pxCif, pxVmapi) \
{ \
		(pxCif)->bIsRegistered = (pxVmapi)->bIsRegistered; \
		IFX_CIF_ConvertStringToHex((pxCif)->aucIPUI, (char8 *)(pxVmapi)->aucIPUI); \
		IFX_CIF_ConvertStringToHex((pxCif)->aucTPUI, (char8 *)(pxVmapi)->aucTPUI); \
		IFX_CIF_ConvertStringToHex((pxCif)->aucAuthKey, (char8 *)(pxVmapi)->aucAuthKey); \
		IFX_CIF_ConvertStringToHex((pxCif)->aucCipherKey, (char8 *)(pxVmapi)->aucCipherKey); \
		(pxCif)->ucServiceClass = (pxVmapi)->ucServiceClass; \
		(pxCif)->ucModelId = (pxVmapi)->ucModelId; \
    (pxCif)->uiTermCap = (pxVmapi)->uiTermCapab;\
	}
#ifdef ULE_SUPPORT
#define IFX_CIF_copyUleInfoFromVmapi(pxCif, pxVmapi) \
{ \
		(pxCif)->bIsRegistered = (pxVmapi)->bIsRegistered; \
		IFX_CIF_ConvertStringToHex((pxCif)->aucIPUI, (char8 *)(pxVmapi)->aucIPUI);\
		IFX_CIF_ConvertStringToHex((pxCif)->aucTPUI, (char8 *)(pxVmapi)->aucTPUI);\
		IFX_CIF_ConvertStringToHex((pxCif)->aucAuthKey, (char8 *)(pxVmapi)->aucAuthKey);\
		IFX_CIF_ConvertStringToHex((pxCif)->aucCipherKey, (char8 *)(pxVmapi)->aucCipherKey);\
		(pxCif)->ucServiceClass = (pxVmapi)->ucServiceClass; \
		(pxCif)->ucModelId = (pxVmapi)->ucModelId; \
    (pxCif)->uiTermCap = (pxVmapi)->uiTermCapab;\
	}
#endif
#define IFX_CIF_copySubsInfoToVmapi(pxVmapi, pxCif) \
	{ \
		(pxVmapi)->bIsRegistered = (pxCif)->bIsRegistered; \
		IFX_CIF_ConvertHexToString((char8 *)(pxVmapi)->aucIPUI, (pxCif)->aucIPUI, \
									 																		IFX_VMAPI_IPUI_SIZE); \
		IFX_CIF_ConvertHexToString((char8 *)(pxVmapi)->aucTPUI, (pxCif)->aucTPUI,\
		                                                                                                    IFX_VMAPI_TPUI_SIZE);\
		IFX_CIF_ConvertHexToString((char8 *)(pxVmapi)->aucAuthKey, (pxCif)->aucAuthKey, \
																										IFX_VMAPI_AUTH_KEY_SIZE); \
		IFX_CIF_ConvertHexToString((char8 *)(pxVmapi)->aucCipherKey, (pxCif)->aucCipherKey,\
																									IFX_VMAPI_CIPHER_KEY_SIZE); \
		(pxVmapi)->ucServiceClass = (pxCif)->ucServiceClass; \
		(pxVmapi)->ucModelId = (pxCif)->ucModelId; \
    (pxVmapi)->uiTermCapab = (pxCif)->uiTermCap;\
	}
#ifdef ULE_SUPPORT
#define IFX_CIF_copyUleInfoToVmapi(pxVmapi, pxCif) \
	{ \
		(pxVmapi)->bIsRegistered = (pxCif)->bIsRegistered; \
		IFX_CIF_ConvertHexToString((char8 *)(pxVmapi)->aucIPUI, (pxCif)->aucIPUI,IFX_VMAPI_IPUI_SIZE); \
		IFX_CIF_ConvertHexToString((char8 *)(pxVmapi)->aucTPUI, (pxCif)->aucTPUI,IFX_VMAPI_TPUI_SIZE); \
		IFX_CIF_ConvertHexToString((char8 *)(pxVmapi)->aucAuthKey, (pxCif)->aucAuthKey,IFX_VMAPI_AUTH_KEY_SIZE); \
		IFX_CIF_ConvertHexToString((char8 *)(pxVmapi)->aucCipherKey, (pxCif)->aucCipherKey,IFX_VMAPI_CIPHER_KEY_SIZE); \
		(pxVmapi)->ucServiceClass = (pxCif)->ucServiceClass; \
		(pxVmapi)->ucModelId = (pxCif)->ucModelId; \
    (pxVmapi)->uiTermCapab = (pxCif)->uiTermCap;\
	}
#endif
#ifdef DECT_PART
void LTQ_Init_ParamsFromDectPart();
#endif
#ifdef DECT_SUPPORT
e_IFX_Return IFX_CIF_DectBasicParamsGet(char8* pszBasePin, uchar8* pucBitMap,
                                        x_IFX_DECT_EnhancedStackCfg *pxEnhancedStackCfg);
#endif

e_IFX_Return IFX_CIF_EndptDataGet(
	                   IN char8* szEndpoint, 
	                   OUT x_IFX_CIF_EndptData** pxEndptData,
										 OUT e_IFX_ReasonCode* peReason);

e_IFX_Return IFX_CIF_LineAssocSet(IN uchar8,IN uchar8); 
e_IFX_Return IFX_CIF_VLVMSubEventGet(
	               IN uchar8 ucVoiceLineId,
								 IN boolean bDepositAddr,
								 OUT x_IFX_CalledAddr* pxAddr,
								 OUT uint16* punSubExpiryTime);
e_IFX_Return IFX_CIF_IsPortFree(uint16 unPort, e_IFX_TransportType ePortType);
e_IFX_Return IFX_CIF_AllocPort(uint16 unPort, e_IFX_TransportType ePortType);
e_IFX_Return IFX_CIF_FreePort(uint16 unRelPort, e_IFX_TransportType ePortType);


e_IFX_Return
  IFX_CIF_NoOfEntriesGet(IN uchar8 ucListId,
			                   IN uchar8 ucLineId, 
                         OUT uchar8 *pucNoOfEntries);

e_IFX_Return IFX_CIF_CNIPGet(IN boolean,IN uchar8,IN char8 *,IN OUT char8 *);
e_IFX_Return
  IFX_CIF_NoOfUnreadGet(IN uchar8 ucLineId,OUT uchar8 *pucNoOfUnread);
e_IFX_Return IFX_CIF_StoreXram(IN uchar8 *pCont);
e_IFX_Return IFX_CIF_StoreValuesFromModem(e_IFX_VMAPI_ObjectId eObj,IN void *buf);
e_IFX_Return 
  IFX_CIF_AssocLineIdsGet(IN uchar8 ucHandset,OUT uchar8 *pucLineIdList); 

e_IFX_Return 
  IFX_CIF_ModifiedNamePP(IN void *pxOld,IN void *pxNew,OUT uchar8 *pucHandset);

e_IFX_Return
IFX_CIF_LineChange(IN void *pxOld,IN void *pxNew,OUT uchar8 *ucLineId);

e_IFX_Return
IFX_CIF_PSTNLineChange(IN void *pxOld,IN void *pxNew,OUT uchar8 *ucLineId);

e_IFX_Return
IFX_CIF_CallFeatChange(IN void *pxOld,IN void *pxNew,OUT uchar8 *ucLineId);

e_IFX_Return
IFX_CIF_SystemChange(IN void *pxOld,IN void *pxNew);

#ifdef DECT_SUPPORT
e_IFX_Return
IFX_CIF_MissedCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_MissedCallList *pxMissedCallList);

e_IFX_Return
IFX_CIF_MissedCallListSet(IN uchar8 ucLineId, IN x_IFX_DECT_LAU_MissedCallList *pxMissedCallList,
                          IN uchar8 ucOp);

e_IFX_Return
 IFX_CIF_OutgoingCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_OutgoingCallList *pxOutgoingCallList);

e_IFX_Return
IFX_CIF_IncomingCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_IncomingCallList *pxIncomingCallList);

e_IFX_Return
 IFX_CIF_AllCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_AllCallList *pxAllCallList);

e_IFX_Return
 IFX_CIF_AllIncomingCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_AllIncomingCallList *pxAllIncomingCallList);

e_IFX_Return
IFX_CIF_LineGet(OUT x_IFX_DECT_LAU_LineSettingsList *pxLineList);


e_IFX_Return
IFX_CIF_SystemGet(OUT x_IFX_DECT_LAU_SystemSettingsList *pxSystemList);


e_IFX_Return
IFX_CIF_IntNameGet(OUT x_IFX_DECT_LAU_IntNameList *pxIntList);
boolean IFX_CIF_IsInterceptAllowed(uchar8 ucHandsetId);
boolean IFX_CIF_IsIntrusionAllowed(uchar8 ucLineId);

e_IFX_Return
IFX_CIF_ContactListGet(OUT x_IFX_DECT_LAU_ContactList *pxContactList, uchar8 ucLineId);
e_IFX_Return
IFX_CIF_CommonContactListGet(OUT x_IFX_DECT_LAU_ContactList *pxContactList);

e_IFX_Return
IFX_CIF_SystemSet(IN x_IFX_DECT_LAU_SystemSettingsList *pxSysList);

e_IFX_Return
IFX_CIF_LineSet(IN x_IFX_DECT_LAU_LineSettingsList *pxLineSetList,
                IN uchar8 ucOp);

e_IFX_Return
IFX_CIF_IntNameSet(IN x_IFX_DECT_LAU_IntNameList *pxListName,
                   IN uchar8 ucOp);

e_IFX_Return
IFX_CIF_ContactListSet(IN x_IFX_DECT_LAU_ContactListEntry *pxDectContact,
											 IN uchar8 *pcLineIdList,
                       IN uchar8 ucOp);

e_IFX_Return
IFX_CIF_CommonContactListSet(IN x_IFX_DECT_LAU_ContactListEntry *pxDectContact,
                       IN uchar8 ucOp);
e_IFX_Return
  IFX_CIF_OutgoingCallListSet(IN uchar8 ucLineId, IN x_IFX_DECT_LAU_OutgoingCallList *pxOutgoingCallList,
                              IN uchar8 ucOp);

e_IFX_Return
  IFX_CIF_IncomingCallListSet(IN uchar8 ucLineId, IN x_IFX_DECT_LAU_IncomingCallList *pxIncomingCallList,
                              IN uchar8 ucOp);

e_IFX_Return
  IFX_CIF_RegisteredPPsGet(OUT uchar8 *pucRegisteredHS);

e_IFX_Return 
IFX_CIF_GetLineName(IN uchar8 ucLineId, OUT char8 *pcLineName);
#endif
e_IFX_Return 
IFX_CIF_FreeVmapiObj(IN e_IFX_CMGR_LA_Type eLAType,
                      IN void *pxOld,
                      IN void *pxNew);

e_IFX_Return IFX_CIF_GetRtpDscp(uchar8 *pucDscp);


#define IFX_CIF_GET_FLAGS	    0
#define IFX_CIF_SETOPP_FLAG	  IFX_VMAPI_OP_MOD
#define IFX_CIF_OPP_ADD_FLAG	IFX_OP_ADD
#define IFX_CIF_MOD_FLAG	    IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ
#define IFX_CIF_ADD_FLAG	    0 

/*
 * Note 1: Since voice line id can not be greater than IFX_MAX_LINES, voice
 *	line id is used to index into axLineInfo of x_IFX_CIF_ConfigInfo. (no
 *	searching is required).
 */
x_IFX_CIF_ConfigInfo vxConfigInfo;
x_IFX_CIF_ProfileMediaPorts axProfileMediaPorts[IFX_MAX_PROFILES];
#define IFX_USED_PORT_ARRAY_SIZE (IFX_MMGR_MAX_CODER_CHANNELS*3)
uint32 vauiUsedPorts[IFX_USED_PORT_ARRAY_SIZE];

e_IFX_Return IFX_CIF_Init()
{
	x_IFX_VMAPI_VoiceServPhyIf xPhyIf = {{{{""}}}};
	uchar8 aucProfileId[IFX_MAX_PROFILES]={0};
	uchar8 ucCnt = 0;
	x_IFX_CIF_EndptData* pxEndpt = vxConfigInfo.axEndptData;
	e_IFX_Return eRet = IFX_SUCCESS;
  IFX_VMAPI_Init();

{
      int32 iRet=0,j=0;
	  x_IFX_VMAPI_VoiceService xVoiceServ;
      memset(&xVoiceServ,0,sizeof(xVoiceServ));
      xVoiceServ.iid.config_owner = IFX_VOIP;
      iRet = ifx_get_VoiceService(&xVoiceServ,0);
      if(iRet != IFX_VMAPI_SUCCESS)
      {
        printf("Cannot GET Voice Service\n");
        return IFX_FAILURE;
      } 


      /* Max number of profiles reached. Throw an error.*/
      /* Get the position of the last created LineId from the LineIdList */
      while(xVoiceServ.ucLineIdList[j] != 0)
      {
        j++;
      }
    
      /* Max number of lines reached. Throw an error.*/
      if( j == 0)
      {
        printf("voip_errors.htm");
        return IFX_FAILURE;
      }
	  else
	  {
        printf("J is %d\n",j);
	  }

	}

	while( ucCnt < IFX_MAX_ENDPTS )
	{
		xPhyIf.ucInterfaceId = ucCnt+1;
		xPhyIf.iid.config_owner = IFX_VOIP;

		if( IFX_VMAPI_SUCCESS != 
			ifx_get_VoicePhyInterface(&xPhyIf,IFX_CIF_GET_FLAGS) )
		{
			eRet = IFX_FAILURE;
			break;
		}

		pxEndpt[ucCnt].ucInterfaceId = xPhyIf.ucInterfaceId;
		if( IFX_VMAPI_VOICE_PORT_TYPE_FXS == xPhyIf.ucPortType )
		{
			x_IFX_VMAPI_FxsPhyIf xFxsPhyIf = {{{{""}}}};
			
			xFxsPhyIf.xVoiceServPhyIf.ucInterfaceId = xPhyIf.ucInterfaceId;
      xFxsPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS != 
				ifx_get_FxsPhyInterface(&xFxsPhyIf,IFX_CIF_GET_FLAGS) )
			{
				eRet = IFX_FAILURE;
				break;
			}
			
			pxEndpt[ucCnt].eType = IFX_EP_FXS;
			strcpy(pxEndpt[ucCnt].szEndptId, (char8 *)xFxsPhyIf.ucEndPtId);
			pxEndpt[ucCnt].ucDefaultVL = xFxsPhyIf.ucVoiceLineId;
			
		}
		else if( IFX_VMAPI_VOICE_PORT_TYPE_FXO == xPhyIf.ucPortType )
		{
			x_IFX_VMAPI_FxoPhyIf xFxoPhyIf = {{{{""}}}};
			
			xFxoPhyIf.xVoiceServPhyIf.ucInterfaceId = xPhyIf.ucInterfaceId;
      xFxoPhyIf.iid.config_owner = IFX_VOIP;

			if( IFX_VMAPI_SUCCESS != 
				ifx_get_FxoPhyInterface(&xFxoPhyIf,IFX_CIF_GET_FLAGS) )
			{
				eRet = IFX_FAILURE;
				break;
			}			

			pxEndpt[ucCnt].eType = IFX_EP_FXO;
			strcpy(pxEndpt[ucCnt].szEndptId, (char8 *)xFxoPhyIf.ucEndPtId);
			pxEndpt[ucCnt].ucDefaultVL = xFxoPhyIf.ucVoiceLineId;
		}
#if defined(DECT_SUPPORT) || defined (CVOIP_SUPPORT)
		else if( IFX_VMAPI_VOICE_PORT_TYPE_DECT == xPhyIf.ucPortType )
		{
			x_IFX_VMAPI_DectHandset xDectHs = {0};
			//memset(&xDectHs, 0 ,sizeof(xDectHs));

			xDectHs.xVoiceServPhyIf.ucInterfaceId = xPhyIf.ucInterfaceId;
      xDectHs.iid.config_owner = IFX_VOIP;
				
			if( IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xDectHs,IFX_CIF_GET_FLAGS))
			{
				eRet = IFX_FAILURE;
				break;
			}			
			pxEndpt[ucCnt].eType = IFX_EP_DECT;
			strcpy(pxEndpt[ucCnt].szEndptId, (char8 *)xDectHs.ucEndPtId);
			pxEndpt[ucCnt].ucDefaultVL = xDectHs.ucVoiceLineId;
		}
#endif
		++ucCnt;
	}

	if( IFX_SUCCESS != eRet )
		return eRet;
	
	/* Get RTP RTCP port for all profiles */

	if( IFX_SUCCESS == (eRet =IFX_CIF_ProfileIdListGet(aucProfileId)))
	{
		ucCnt = 0;
		while(ucCnt < IFX_MAX_PROFILES && aucProfileId[ucCnt] > 0)
		{
			IFX_CIF_UpdateProfilePorts(aucProfileId[ucCnt]);
			++ucCnt;
		} /* While */
		
	}
#if 0
	else
	{
		printf("\n%s: IFX_CIF_ProfileIdListGet FAILED",__FUNCTION__);
	}
#endif
					
	return eRet;
}

e_IFX_Return IFX_CIF_EndptListGet(
	                 IN e_IFX_EndptType eEpType,
	                 IN_OUT uchar8* pucSize,
	                 OUT char8 aszEndpointList[][IFX_MAX_ENDPOINTID_LEN],
									 OUT e_IFX_ReasonCode* peReason)
{
	x_IFX_CIF_EndptData* pxEndpt = vxConfigInfo.axEndptData;
	uchar8 ucCnt = 0;
	
/*	if( *pucSize < IFX_MMGR_MAX_FXO_CHANNELS )
	{
		*peReason = IFX_CIF_INSUFFICIENT_ARRAY_SIZE;
		return IFX_FAILURE;
	}*/

	*pucSize = 0;

	while( ucCnt < IFX_MAX_ENDPTS )
	{
		if( eEpType == pxEndpt->eType )
		{
			strcpy(aszEndpointList[*pucSize],pxEndpt->szEndptId);
			++(*pucSize);
		}

		++pxEndpt;
		++ucCnt;
	}
	return IFX_SUCCESS;
}


e_IFX_Return IFX_CIF_EndptDataUpdate(
	                 IN char8* szOldEndptIf,
	                 IN char8* szNewEndptId,
	                 IN uchar8 ucDefaultVL,
									 OUT e_IFX_ReasonCode* peReason)
{
	
	x_IFX_CIF_EndptData* pxEndptData;
	e_IFX_Return eRet;

	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szOldEndptIf,&pxEndptData,peReason)) )
	{
		strcpy(pxEndptData->szEndptId,szNewEndptId);
		printf("Changing Endpoint %s :: Default Line=%d\n",szOldEndptIf,ucDefaultVL );
		pxEndptData->ucDefaultVL = ucDefaultVL;
	}
	return eRet;
}

e_IFX_Return IFX_UpdateEnptDefaultLine()
{
	x_IFX_CIF_EndptData* pxEndpt = vxConfigInfo.axEndptData;
	uchar8 ucCnt = 0;

	while( ucCnt < IFX_MAX_ENDPTS )
	{
		if( IFX_EP_FXS == pxEndpt->eType )
		{
			x_IFX_VMAPI_FxsPhyIf xFxsPhyIf = {{{{""}}}};
			
			xFxsPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndpt->ucInterfaceId;
      xFxsPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxsPhyInterface(&xFxsPhyIf,IFX_CIF_GET_FLAGS) )
			{
				pxEndpt->ucDefaultVL = xFxsPhyIf.ucVoiceLineId;
			}
		}
		else if( IFX_EP_FXO == pxEndpt->eType )
		{
			x_IFX_VMAPI_FxoPhyIf xFxoPhyIf = {{{{""}}}};
			
			xFxoPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndpt->ucInterfaceId;
      xFxoPhyIf.iid.config_owner = IFX_VOIP;

			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxoPhyInterface(&xFxoPhyIf,IFX_CIF_GET_FLAGS) )
			{
				pxEndpt->ucDefaultVL = xFxoPhyIf.ucVoiceLineId;
			}			
		}
#ifdef DECT_SUPPORT
		else if( IFX_EP_DECT == pxEndpt->eType )
		{
			x_IFX_VMAPI_DectHandset xDectHs = {0};

			xDectHs.xVoiceServPhyIf.ucInterfaceId = pxEndpt->ucInterfaceId;
      xDectHs.iid.config_owner = IFX_VOIP;
				
			if( IFX_VMAPI_SUCCESS == ifx_get_DectHandset(&xDectHs,IFX_CIF_GET_FLAGS))
			{
				pxEndpt->ucDefaultVL = xDectHs.ucVoiceLineId;
			}			
		}
#endif
		++ucCnt;
		++pxEndpt;
	}

	return IFX_SUCCESS;
}

e_IFX_Return IFX_CIF_CountryNameGet(OUT char8* pszCountryName)
{
	x_IFX_VMAPI_VoiceService xVoiceSrv = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	*pszCountryName = '\0';
  xVoiceSrv.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_VoiceService(&xVoiceSrv,IFX_CIF_GET_FLAGS))
	{
		char8* pszConfigCountry = 0;

		//printf("\n Country Id = %x\n", xVoiceSrv.uiCountrySet);
	
		switch(xVoiceSrv.uiCountrySet)
		{
			case IFX_VMAPI_COUNTRY_USA:	pszConfigCountry = "USA"; break;
			case IFX_VMAPI_COUNTRY_GERMANY: pszConfigCountry = "GERMANY"; break;
			case IFX_VMAPI_COUNTRY_CHINA: pszConfigCountry = "CHINA"; break;
			case IFX_VMAPI_COUNTRY_TAIWAN: pszConfigCountry = "TAIWAN"; break;
			//case IFX_VMAPI_COUNTRY_INDIA: pszConfigCountry = "INDIA"; break;
			case IFX_VMAPI_COUNTRY_JAPAN: pszConfigCountry = "JAPAN"; break;
			default:
			{
				pszConfigCountry = "USA";
				printf("Unknown Country. Taking Default Country Settings \n\n");
			}
		}
		if(pszConfigCountry)
		{
			printf("\n\n ********* Country Configured :: %s **************\n\n",
									pszConfigCountry);
			strcpy(pszCountryName, pszConfigCountry);
			eRet =IFX_SUCCESS;
		}
	}
	return eRet;	
}
e_IFX_Return IFX_CIF_FxoEnableGet(){

	x_IFX_VMAPI_Misc xMisc = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

  xMisc.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_Misc(&xMisc,IFX_CIF_GET_FLAGS) )
	{
		if(xMisc.ucFxoEnable)
			eRet = IFX_SUCCESS;
	}
	return eRet;
}

e_IFX_Return IFX_CIF_FxEndptResInfoGet(
	               IN char8* szEndptId, 
	               OUT x_IFX_CIF_FxResourceInfo* pxFxResInfo,
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_CIF_EndptData* pxEndptData;

	e_IFX_Return eRet ;
	
  if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szEndptId,&pxEndptData,peReason)) )
	{
		eRet = IFX_FAILURE;
		memset(pxFxResInfo,0,sizeof(x_IFX_CIF_FxResourceInfo));
		pxFxResInfo->iInterfaceId = pxEndptData->ucInterfaceId;
		pxFxResInfo->unVolumeLevel = 0; //TODO: Volume??
		pxFxResInfo->cLecTailLength = 16;

		if( pxEndptData->eType == IFX_EP_FXS )
		{
			x_IFX_VMAPI_FxsPhyIf xFxsPhyIf = {{{{""}}}};
		
			xFxsPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xFxsPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxsPhyInterface(&xFxsPhyIf,IFX_CIF_GET_FLAGS) )
			{
				pxFxResInfo->bIsWideBandEnabled = xFxsPhyIf.bWideBandCapable;
				strcpy(pxFxResInfo->szChannelName, xFxsPhyIf.acChannelString);
				pxFxResInfo->bIsLecEnabled = xFxsPhyIf.bEnableEchoCancel;
				eRet = IFX_SUCCESS;
			}
			else
				*peReason = IFX_CIF_CONFIG_ERROR;
		}
		else if( pxEndptData->eType == IFX_EP_FXO )
		{
			x_IFX_VMAPI_FxoPhyIf xFxoPhyIf = {{{{""}}}};
		
			xFxoPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xFxoPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxoPhyInterface(&xFxoPhyIf,IFX_CIF_GET_FLAGS) )
			{
#ifdef SLIC121
				strcpy(pxFxResInfo->szChannelName,"/dev/vmmc13");
#else
				strcpy(pxFxResInfo->szChannelName, xFxoPhyIf.acChannelString);
#endif
				pxFxResInfo->bIsLecEnabled = xFxoPhyIf.bEnableEchoCancel;
				eRet = IFX_SUCCESS;
			}
			else
				*peReason = IFX_CIF_CONFIG_ERROR;
		}
#if defined ( DECT_SUPPORT ) || defined(CVOIP_SUPPORT)
		else if( pxEndptData->eType == IFX_EP_DECT )
		{
			x_IFX_VMAPI_DectHandset xDectHs = {0};
			xDectHs.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xDectHs.iid.config_owner = IFX_VOIP;
				
			if( IFX_VMAPI_SUCCESS == ifx_get_DectHandset(&xDectHs,IFX_CIF_GET_FLAGS))
			{
				strcpy(pxFxResInfo->szChannelName,xDectHs.acChannelString);
			}			
			eRet = IFX_SUCCESS;
		}
#endif
		else
		{
			//printf("\n%s::%d   Wrong Endpoint Type....\n",__FUNCTION__,__LINE__);
			*peReason = IFX_CIF_INVALID_ENDPOINT;
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_DeviceListGet(
	               IN uchar8 ucSize,
	               OUT char8 aszDeviceList[][IFX_MAX_DEV_STR_LEN],
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_VoiceService xVoiceSrv = {{{{""}}}};
  uchar8 ucDvcCnt = 0;

	*peReason = IFX_MAX_REASON;
  xVoiceSrv.iid.config_owner = IFX_VOIP;

	if( IFX_MAX_DEVICES > ucSize )
	{
		*peReason = IFX_CIF_INSUFFICIENT_ARRAY_SIZE;
	
	} else if( IFX_VMAPI_SUCCESS == 
							ifx_get_VoiceService(&xVoiceSrv,IFX_CIF_GET_FLAGS))
	{
		while(	ucDvcCnt < IFX_MAX_DEVICES )
		{
			strcpy(aszDeviceList[ucDvcCnt],xVoiceSrv.acDeviceList[ucDvcCnt]); 
			++ucDvcCnt;
		} 
	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return (IFX_MAX_REASON == *peReason )?IFX_SUCCESS:IFX_FAILURE;

}

e_IFX_Return IFX_CIF_EndptCodecListGet( 
	               IN char8* szEndptId, 
	               OUT x_IFX_CodecList* pxCodecParams,
	               OUT e_IFX_ReasonCode* peReason  )
{
	e_IFX_Return eRet = IFX_SUCCESS;

	pxCodecParams->unNoOfCodecs = 0;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
	x_IFX_CIF_EndptData* pxEndptData;
  if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szEndptId,&pxEndptData,peReason)) &&
		 pxEndptData->eType 	== IFX_EP_DECT )
	{
		x_IFX_VMAPI_DectHandset xDectHs;
		x_IFX_CodecList xDectCodecList;
		
		memset(&xDectHs,0,sizeof(x_IFX_CodecList));
		memset(&xDectCodecList,0,sizeof(x_IFX_CodecList));
		xDectHs.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
    xDectHs.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS == ifx_get_DectHandset(&xDectHs,IFX_CIF_GET_FLAGS) )
		{
			if( xDectHs.bWideBandCapable )
			{
				xDectCodecList.unNoOfCodecs = 2;
				xDectCodecList.axCodec[0].uiCodec = IFX_G722_64;
				xDectCodecList.axCodec[1].uiCodec = IFX_G726_32;
			}
			else
			{
				xDectCodecList.unNoOfCodecs = 1;
				xDectCodecList.axCodec[0].uiCodec = IFX_G726_32;
			}
		}
		memcpy(pxCodecParams, &xDectCodecList, sizeof(xDectCodecList));
	}
#endif

	return eRet;
}
/*******************************************************************************
* Function Name    : IFX_Get_LineRegInfo 
* Description      :  
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     :
* Notes            :
*******************************************************************************/
e_IFX_Return
IFX_Get_LineRegInfo(OUT boolean* pbRegStatus)
{
  int32 j=0,ucLineId;
  x_IFX_VMAPI_VoiceService xVoiceServ = {{{{""}}}};
  x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
  e_IFX_Return eRet = IFX_SUCCESS;
	if( IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVoiceServ,IFX_CIF_GET_FLAGS))
	{
	  eRet = IFX_FAILURE;
	}

  /* Get the number of lines from the LineIdList */
  while(xVoiceServ.ucLineIdList[j] != 0)
  {
      j++;
  }

  for (ucLineId = 1; ucLineId <= j; ucLineId++)
  {
    xVoiceLine.ucLineId = ucLineId; 
	  if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS) )
	  {
				if ( IFX_VMAPI_VL_STATUS_UP == xVoiceLine.ucLineStatus )
        {
          *pbRegStatus = IFX_TRUE;
           break;
        }
        else
        {
          *pbRegStatus = IFX_FALSE;
        }
	  }
    else
	  {
		  /* Could not get line info...*/
	    eRet = IFX_FAILURE;
	  }
  }
 return eRet;
}

/*
 * If voice line is not enable, don't set status. If voice line reg status not
 * changed, don't set into VMAPI, else get voice line from VMAPI & change reg
 * status and write into VMAPI and also update config info.
 */
e_IFX_Return IFX_CIF_VLRegisterStatusSet(
	                 IN uchar8 ucVoiceLineId,
	                 IN uchar8 ucStatus,
	                 IN uint32 uiExpiresAfter,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;
#ifndef SLIC121
  boolean bRegstatus=0;
#endif
	//memset(&xVoiceLine,0,sizeof(xVoiceLine));
	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);

	xVoiceLine.ucLineId = ucVoiceLineId;
  xVoiceLine.iid.config_owner = IFX_VOIP;
	
	if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xVoiceLine, IFX_CIF_GET_FLAGS))
	{
		xVoiceLine.ucLineStatus = ucStatus; 
		
		if( IFX_VMAPI_SUCCESS == 
				ifx_set_VoiceLine(IFX_CIF_SETOPP_FLAG, &xVoiceLine, IFX_CIF_MOD_FLAG) )
		{
			eRet = IFX_SUCCESS;
		}
		else
		{
			*peReason = IFX_CIF_CONFIG_ERROR;
		}
	}
//#ifndef CONFIG_VR9
#ifndef SLIC121
  if(ucStatus == IFX_VMAPI_VL_STATUS_UP){
         system("echo 255 > /sys/class/leds/voip1_led/brightness");
         }
      else
         {
          IFX_Get_LineRegInfo(&bRegstatus);
          if (bRegstatus == 1)
          {
           system("echo 255 > /sys/class/leds/voip1_led/brightness");
          }
          else
          {
           system("echo 0 > /sys/class/leds/voip1_led/brightness");
          }
         }
#endif
//#endif
	return eRet;
}

/* For checking if subscribed before unsubscribing */
e_IFX_Return IFX_CIF_VLVMStatusGet(
	                 IN uchar8 ucVoiceLineId)
{
	x_IFX_VMAPI_LineEvents xVLEvntSub = {{{{""}}}};
	uchar8 ucIndex = 0;
	e_IFX_Return eRet = IFX_FAILURE;
	e_IFX_ReasonCode eReason;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,&eReason);
	xVLEvntSub.ucLineId = ucVoiceLineId;
  xVLEvntSub.iid.config_owner = IFX_VOIP;

	do {
		
		xVLEvntSub.ucIndex = ++ucIndex;
		
		if( IFX_VMAPI_SUCCESS != ifx_get_LineEvents(&xVLEvntSub,IFX_CIF_GET_FLAGS))
			break;
		else if( IFX_VMAPI_VL_SUBS_EVENT_MWI == xVLEvntSub.uiSubspnEvent )
		{
			eRet = IFX_SUCCESS;
			break;
		}
	} while(1); 

	if( IFX_SUCCESS == eRet )
	{
		if(xVLEvntSub.ucSubspnState == IFX_CMGR_STATUS_SUCCESS ||
			 xVLEvntSub.ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_ACTIVE){
		  eRet=IFX_SUCCESS;
		}
		else{
		  eRet=IFX_FAILURE;
		}
	}
	return eRet;
}




e_IFX_Return IFX_CIF_VLVMStatusSet(
	                 IN uchar8 ucVoiceLineId,
	                 IN uchar8 ucStatus,
	                 IN uint32 uiExpiresAfter,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineEvents xVLEvntSub = {{{{""}}}};
	uchar8 ucIndex = 0;
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);
	xVLEvntSub.ucLineId = ucVoiceLineId;
  xVLEvntSub.iid.config_owner = IFX_VOIP;

	do {
		
		xVLEvntSub.ucIndex = ++ucIndex;
		
		if( IFX_VMAPI_SUCCESS != ifx_get_LineEvents(&xVLEvntSub,IFX_CIF_GET_FLAGS))
			break;
		else if( IFX_VMAPI_VL_SUBS_EVENT_MWI == xVLEvntSub.uiSubspnEvent )
		{
			eRet = IFX_SUCCESS;
			break;
		}
	} while(1); 

	if( IFX_SUCCESS == eRet )
	{
		xVLEvntSub.ucSubspnState = ucStatus;

		if( IFX_VMAPI_SUCCESS != 
			ifx_set_LineEvents(IFX_CIF_SETOPP_FLAG,&xVLEvntSub,IFX_CIF_MOD_FLAG) )
		{
			eRet = IFX_FAILURE;
		}
	}

	if( IFX_FAILURE == eRet )
		*peReason = IFX_CIF_CONFIG_ERROR;

	return eRet;
}

e_IFX_Return IFX_CIF_VLVMWaitingStatusSet(
	                 IN uchar8 ucVoiceLineId,
	                 IN uchar8 ucNoOfWaitingMails,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);

	/* 
	 * Get voice line calling feature. If bEnableMwiIndication is true, write
	 * voice mail waiting status into VMAPI
	 */

	xLineCallingFeature.ucLineId = ucVoiceLineId;
  xLineCallingFeature.iid.config_owner = IFX_VOIP;

	if( IFX_VMAPI_SUCCESS == 
		ifx_get_LineCallingFeatures(&xLineCallingFeature, IFX_CIF_GET_FLAGS) )
	{
		if( xLineCallingFeature.bEnableMwiIndication )
		{
			/* User has disabled message waiting indication, don't set the status */
			xLineCallingFeature.bIsMsgWaiting = 
				(ucNoOfWaitingMails > 0)?IFX_TRUE:IFX_FALSE;
			if( IFX_VMAPI_SUCCESS == ifx_set_LineCallingFeatures(IFX_CIF_SETOPP_FLAG,
																		&xLineCallingFeature,
																		IFX_CIF_MOD_FLAG) )
			{
				eRet = IFX_SUCCESS;
			}
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_IncomingCallBlockCheck(
	                 IN char8* szEndptId, 
	                 IN char8* szCallerAddr,
	                 OUT boolean* pbBlocked,
	                 OUT e_IFX_ReasonCode* peReason )
{

	x_IFX_VMAPI_CallBlock xCallBlock = {{{{""}}}};
	e_IFX_Return eRet = IFX_SUCCESS;

	*pbBlocked = IFX_FALSE;
  xCallBlock.iid.config_owner = IFX_VOIP;
	if( szCallerAddr[0] == '\0' )
		return eRet;

	if( IFX_VMAPI_SUCCESS == ifx_get_CallBlock(&xCallBlock,IFX_CIF_GET_FLAGS) )
	{
		x_IFX_VMAPI_CallBlockEntry* pxBlckAddr = xCallBlock.pxCallBlockList;
		while( pxBlckAddr != NULL ) 
		{
			--xCallBlock.uiNumCallBlockEntries;
			if( !strcasecmp(szCallerAddr, pxBlckAddr->acCallBlockNum))
			{
				*pbBlocked = IFX_TRUE;
				break;
			}

			__ifx_list_GetNext((void**)&pxBlckAddr);
		}

		/* Free call block list */
		ifx_vmapi_freeObjectList(&xCallBlock, IFX_VMAPI_VS_CALL_BLOCK);
	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;	
		eRet = IFX_FAILURE;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_OutgoingCallBlockCheck(
	                 IN char8* szEndptId,
	                 OUT boolean* pbBlocked,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_CallBlock xCallBlock = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	*pbBlocked = IFX_FALSE;
  xCallBlock.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_CallBlock(&xCallBlock,IFX_CIF_GET_FLAGS) )
	{
		*pbBlocked = xCallBlock.bCallBar ;
		eRet = IFX_SUCCESS;
		ifx_vmapi_freeObjectList(&xCallBlock, IFX_VMAPI_VS_CALL_BLOCK);
	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}


e_IFX_Return IFX_CIF_FxsSMSCapablityCheck(
	                 IN   char8* szEndptId,
	                 OUT boolean* pbCapable ,
	                 OUT e_IFX_ReasonCode* peReason )
{

	x_IFX_CIF_EndptData* pxEndptData;
	x_IFX_VMAPI_FxsPhyIf xFxsPhyIf = {{{{""}}}};

	e_IFX_Return eRet ;
	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szEndptId,&pxEndptData,peReason)) )
	{
		eRet = IFX_FAILURE;
		if( pxEndptData->eType == IFX_EP_FXS )
		{
			xFxsPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xFxsPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxsPhyInterface(&xFxsPhyIf,IFX_CIF_GET_FLAGS) )
			{
				*pbCapable = xFxsPhyIf.bSmsCapable;
				eRet = IFX_SUCCESS;
			}
			else
				*peReason = IFX_CIF_CONFIG_ERROR;
		}
		else
		{
			*peReason = IFX_CIF_INVALID_ENDPOINT;
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_FxsWidebandCapablityCheck(
	                 IN   char8* szEndptId,
	                 OUT boolean* pbCapable ,
	                 OUT e_IFX_ReasonCode* peReason )
{

	x_IFX_CIF_EndptData* pxEndptData;
	x_IFX_VMAPI_FxsPhyIf xFxsPhyIf = {{{{""}}}};

	e_IFX_Return eRet ;
	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szEndptId,&pxEndptData,peReason)) )
	{
		eRet = IFX_FAILURE;
		if( pxEndptData->eType == IFX_EP_FXS )
		{
			xFxsPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xFxsPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxsPhyInterface(&xFxsPhyIf,IFX_CIF_GET_FLAGS) )
			{
				*pbCapable = xFxsPhyIf.bWideBandCapable;
				eRet = IFX_SUCCESS;
			}
			else
				*peReason = IFX_CIF_CONFIG_ERROR;
		}
		else
		{
			*peReason = IFX_CIF_INVALID_ENDPOINT;
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_DefaultOutBoundIfGet(
	                 IN   char8* szEndptId,
	                 OUT uchar8* pucIf,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_Misc xMisc = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

  xMisc.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_Misc(&xMisc,IFX_CIF_GET_FLAGS) )
	{
		*pucIf = (IFX_VMAPI_PSTN_NUM == xMisc.defaultOutbndIface)?1:0;
		eRet = IFX_SUCCESS;

	}
	return eRet;
}

e_IFX_Return IFX_CIF_DefaultOutBoundIfSet(
	                 IN  char8* szEndptId, 
	                 IN uchar8  ucIf ,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_Misc xMisc = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

  xMisc.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_Misc(&xMisc,IFX_CIF_GET_FLAGS) )
	{
		if( ucIf != xMisc.defaultOutbndIface )
		{
			xMisc.defaultOutbndIface = ucIf;
			if( IFX_VMAPI_SUCCESS != 
				ifx_set_Misc(IFX_CIF_SETOPP_FLAG, &xMisc,IFX_CIF_MOD_FLAG) )
			{
				*peReason = IFX_CIF_CONFIG_ERROR;
			}
			else
				eRet = IFX_SUCCESS;
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_DefaultFaxPortGet(
	                 OUT char8* pszEndptId,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_Misc xMisc = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;
	
	pszEndptId[0]='\0';
	
  xMisc.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_Misc(&xMisc,IFX_CIF_GET_FLAGS) )
	{
		if( xMisc.defaultFaxIface <= IFX_MAX_ENDPTS && xMisc.defaultFaxIface > 0)
		{
			strcpy(pszEndptId, 
				vxConfigInfo.axEndptData[xMisc.defaultFaxIface-1].szEndptId);
			eRet = IFX_SUCCESS;
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_UnsolicitedNtfyStatusGet(
	                 OUT boolean* pbUnsolNtfy,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_Misc xMisc = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;
	*pbUnsolNtfy = IFX_FALSE;

  xMisc.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_Misc(&xMisc,IFX_CIF_GET_FLAGS) )
	{
		*pbUnsolNtfy = xMisc.bAcceptUnSolNotify;
		eRet = IFX_SUCCESS;
	}

	return eRet;
}
e_IFX_Return IFX_CIF_FxoModeGet(
	                 IN char8* szFxoEndpointId,
	                 OUT boolean* pbGwMode,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_CIF_EndptData* pxEndptData;
	x_IFX_VMAPI_FxoPhyIf xFxoPhyIf = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szFxoEndpointId,&pxEndptData,peReason)) )
	{
		eRet = IFX_FAILURE;
		

		if( IFX_EP_FXO == pxEndptData->eType )
		{
			xFxoPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId; 
      xFxoPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxoPhyInterface(&xFxoPhyIf,IFX_CIF_GET_FLAGS) )
			{
				*pbGwMode = (xFxoPhyIf.ucGatewayMode == IFX_VMAPI_GW_MODE)?IFX_TRUE:IFX_FALSE;
				eRet = IFX_SUCCESS;
			} 
			else
			{
				*peReason = IFX_CIF_CONFIG_ERROR;
			}
		}
		else
		{
			/* szFxoEndpointId is not FXO endpoint */
			*peReason = IFX_CIF_INVALID_ENDPOINT;
		}

	}

	return eRet;
}

e_IFX_Return IFX_CIF_FxoSmsScNumberGet(
	                 IN char8* szFxoEndpointId,
	                 OUT char8* pszSmsScNumber,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_CIF_EndptData* pxEndptData;
	x_IFX_VMAPI_FxoPhyIf xFxoPhyIf = {{{{""}}}};
	e_IFX_Return eRet;

	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szFxoEndpointId,&pxEndptData,peReason)) )
	{
		eRet = IFX_FAILURE;
		if( IFX_EP_FXO == pxEndptData->eType )
		{
			xFxoPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId; 
      xFxoPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxoPhyInterface(&xFxoPhyIf,IFX_CIF_GET_FLAGS))
			{
				strcpy(pszSmsScNumber, xFxoPhyIf.uacSmsScNumber);
				eRet = IFX_SUCCESS;
			} 
			else
			{
				*peReason = IFX_CIF_CONFIG_ERROR;
			}
		}
		else
		{
			/* szFxoEndpointId is not FXO endpoint */
			*peReason = IFX_CIF_INVALID_ENDPOINT;
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_EndptDefaultVLRegStatusCheck(
	                 IN char8* szEndptId,
	                 OUT boolean* pbRegisred,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_VoiceLine xLine = {{{{""}}}};
	uchar8 ucLineId;
	e_IFX_Return eRet;
	/*
	 * Get default voice line id of endpoint.
	 */
	if( IFX_SUCCESS == 
		(eRet=IFX_CIF_EndptDefaultVLGet(szEndptId,
																							&ucLineId,peReason) ) )
	{			
		xLine.ucLineId = ucLineId;
    xLine.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xLine, IFX_CIF_GET_FLAGS))
		{
			*pbRegisred = 
				( IFX_VMAPI_VL_STATUS_UP == xLine.ucLineStatus )?IFX_TRUE:IFX_FALSE;
		}
		else
		{
			eRet = IFX_FAILURE;
			*peReason = IFX_CIF_CONFIG_ERROR;
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_EndptVMStatusCheck(
	                 IN char8* szEndptId,
	                 OUT boolean* pbVMWI,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
    x_IFX_VMAPI_LineEvents xLineEvents = {{{{""}}}};
	uchar8 ucLineId;
	e_IFX_Return eRet;

	*pbVMWI = IFX_FALSE;
	
	if( IFX_SUCCESS == 
		(eRet=IFX_CIF_EndptDefaultVLGet(szEndptId,
																							&ucLineId,peReason) ) )
	{
		xLineCallingFeature.ucLineId = ucLineId;
    xLineCallingFeature.iid.config_owner = IFX_VOIP;

		if( IFX_VMAPI_SUCCESS != 
			ifx_get_LineCallingFeatures(&xLineCallingFeature,IFX_CIF_GET_FLAGS) )
		{ 
		    eRet = IFX_FAILURE;
			*peReason = IFX_CIF_CONFIG_ERROR;
		} 
	    xLineEvents.ucLineId = ucLineId;
        xLineEvents.ucIndex = 1;
      xLineEvents.iid.config_owner = IFX_VOIP;
	    if (IFX_VMAPI_SUCCESS == ifx_get_LineEvents(&xLineEvents,IFX_CIF_GET_FLAGS))
		{
			if ((xLineEvents.ucSubspnState == IFX_VMAPI_VL_SUBS_STATE_ACTIVE) && 
		       (xLineEvents.uiSubspnEvent == IFX_VMAPI_VL_SUBS_EVENT_MWI) &&
			   (xLineCallingFeature.bEnableMwiIndication == IFX_TRUE) &&
			   (xLineCallingFeature.bIsMsgWaiting == IFX_TRUE))
			   {
			   		*pbVMWI = IFX_TRUE;
			   }

		}
		else 
		{
			eRet = IFX_FAILURE;
			*peReason = IFX_CIF_CONFIG_ERROR;
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_EndptVMRetrievalAddrGet(
	                 IN char8* szEndptId,
	                 OUT x_IFX_CalledAddr* pxAddr,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_CIF_EndptData* pxEndptData;
	e_IFX_Return eRet;

	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szEndptId,&pxEndptData,peReason)) )
	{
		uint16 unExpTime;
		eRet =  IFX_CIF_VLVMSubEventGet( pxEndptData->ucDefaultVL, 
																				IFX_FALSE,pxAddr,&unExpTime);
	}

	return eRet;
}

e_IFX_Return IFX_CIF_EndptDefaultVLSet(
	                 IN char8* szEndptId,
	                 OUT uchar8 ucLineId,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_CIF_EndptData* pxEndptData;
	e_IFX_Return eRet ;

	IFX_CIF_VALIDATE_VOICELINE(ucLineId,peReason);

	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szEndptId,&pxEndptData,peReason)) )
	{
		eRet = IFX_FAILURE;

		if( IFX_EP_FXS == pxEndptData->eType )
		{
			x_IFX_VMAPI_FxsPhyIf xFxsPhyIf = {{{{""}}}};
			xFxsPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xFxsPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxsPhyInterface(&xFxsPhyIf,IFX_CIF_GET_FLAGS) )
			{
				xFxsPhyIf.ucVoiceLineId = ucLineId;
				eRet=(IFX_VMAPI_SUCCESS == ifx_set_FxsPhyInterface(IFX_CIF_SETOPP_FLAG,
											&xFxsPhyIf, IFX_CIF_MOD_FLAG) )?IFX_SUCCESS:IFX_FAILURE;
			}
		}
		else if( IFX_EP_FXO == pxEndptData->eType )
		{
			x_IFX_VMAPI_FxoPhyIf xFxoPhyIf = {{{{""}}}};
			xFxoPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xFxoPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxoPhyInterface(&xFxoPhyIf,IFX_CIF_GET_FLAGS))
			{
				xFxoPhyIf.ucVoiceLineId = ucLineId;
				eRet=(IFX_VMAPI_SUCCESS == ifx_set_FxoPhyInterface(IFX_CIF_SETOPP_FLAG,
											&xFxoPhyIf, IFX_CIF_MOD_FLAG) )?IFX_SUCCESS:IFX_FAILURE;
			}
		}
#ifdef DECT_SUPPORT
		else if(  IFX_EP_DECT == pxEndptData->eType )
		{
			x_IFX_VMAPI_DectHandset xDectHs = {0};
			xDectHs.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xDectHs.iid.config_owner = IFX_VOIP;
				
			if( IFX_VMAPI_SUCCESS == ifx_get_DectHandset(&xDectHs,IFX_CIF_GET_FLAGS))
			{
        xDectHs.ucVoiceLineId  = ucLineId;
				eRet = (IFX_VMAPI_SUCCESS == ifx_set_DectHandset(IFX_CIF_SETOPP_FLAG,
														&xDectHs,IFX_CIF_MOD_FLAG))?IFX_SUCCESS:IFX_FAILURE;
			}			
		}
#endif
		
		if( IFX_SUCCESS == eRet )
			pxEndptData->ucDefaultVL = ucLineId;
		/* else
			printf("\n%s : FAILED TO SET DEFAULT VOICE LINE ID FOR %s ENDPOINT",
			__FUNCTION__, szEndptId); */
	} /* endpoint data */

	return eRet;
}

e_IFX_Return IFX_CIF_EndptCallFwdInfoSet(
	                 IN char8* szEndptId, 
	                 IN e_IFX_CallForwardType eCfType,
	                 IN boolean bEnabled,
	                 IN x_IFX_CalledAddr* pxCfAddr,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	x_IFX_VMAPI_Address* pxVmapiAddr = 0;
	uchar8 ucLineId;
	e_IFX_Return eRet;

	if( IFX_SUCCESS == 
		(eRet=IFX_CIF_EndptDefaultVLGet(szEndptId,
																							&ucLineId,peReason) ) )
	{
		eRet = IFX_FAILURE;
		xLineCallingFeature.ucLineId = ucLineId;
    xLineCallingFeature.iid.config_owner = IFX_VOIP;
		
		if( IFX_VMAPI_SUCCESS == 
			ifx_get_LineCallingFeatures(&xLineCallingFeature,
																	IFX_CIF_GET_FLAGS)  )   
		{
			if( !bEnabled )
			{
				/* disable */
				xLineCallingFeature.unCallFwdCfg &= (~eCfType);
			}
			else
			{
				xLineCallingFeature.unCallFwdCfg |= eCfType;

				if(eCfType == IFX_CALL_FWD_UNCONDITIONAL)
					pxVmapiAddr = &xLineCallingFeature.xCfuAddress;
				else if(eCfType == IFX_CALL_FWD_BUSY)
					pxVmapiAddr = &xLineCallingFeature.xCfbAddress;
				else if(eCfType == IFX_CALL_FWD_ON_NO_ANSWER)
					pxVmapiAddr = &xLineCallingFeature.xCfnaAddress;
				else if(eCfType == IFX_CALL_FWD_DND)
					pxVmapiAddr = &xLineCallingFeature.xDndAddress;

				/* If pxTempAddr is null, then call forwarded to voice mail */
				if( pxVmapiAddr )
					ifx_cif_cpyToVmapiAddr(pxVmapiAddr,pxCfAddr);
			}
			
			if( IFX_VMAPI_SUCCESS == 
					ifx_set_LineCallingFeatures(IFX_CIF_SETOPP_FLAG,
																			&xLineCallingFeature,
																			IFX_CIF_MOD_FLAG ) )
			{
				eRet = IFX_SUCCESS;
			}
			
		} /* retrieve calling features */

		if( IFX_SUCCESS != eRet )
			*peReason = IFX_CIF_CONFIG_ERROR;
	} /* get default line */

	return eRet;
}

e_IFX_Return IFX_CIF_EndptDNDStatusSet(
	                 IN char8* szEndptId,
	                 IN boolean bEnable, 
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	uchar8 ucLineId;
	e_IFX_Return eRet;

	if( IFX_SUCCESS == 
		(eRet=IFX_CIF_EndptDefaultVLGet(szEndptId,
																							&ucLineId,peReason) ) )
	{
		eRet = IFX_SUCCESS;
		xLineCallingFeature.ucLineId = ucLineId;
    xLineCallingFeature.iid.config_owner = IFX_VOIP;

		if( IFX_VMAPI_SUCCESS == 
			ifx_get_LineCallingFeatures(&xLineCallingFeature,
																				IFX_CIF_GET_FLAGS) )
		{
			if( xLineCallingFeature.bEnableDnd != bEnable )
			{
				xLineCallingFeature.bEnableDnd = bEnable;
				if( IFX_VMAPI_SUCCESS != 
					ifx_set_LineCallingFeatures(IFX_CIF_SETOPP_FLAG,
																			&xLineCallingFeature,
																			IFX_CIF_MOD_FLAG ) )
				{
					eRet = IFX_FAILURE;
				}
			}

		} /* retrieve calling features */
		if( IFX_SUCCESS != eRet )
			*peReason = IFX_CIF_CONFIG_ERROR;
	} /* get default line */

	return eRet;
}

e_IFX_Return IFX_CIF_EndptAnonymousCallBlockSet(
	                 IN char8* szEndptId,
	                 IN boolean bEnable, 
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	uchar8 ucLineId;
	e_IFX_Return eRet;

	if( IFX_SUCCESS == 
		(eRet=IFX_CIF_EndptDefaultVLGet(szEndptId,
																							&ucLineId,peReason) ) )
	{
		eRet = IFX_SUCCESS;
		xLineCallingFeature.ucLineId = ucLineId; 
    xLineCallingFeature.iid.config_owner = IFX_VOIP;


		if( IFX_VMAPI_SUCCESS == 
			ifx_get_LineCallingFeatures(&xLineCallingFeature,
																				IFX_CIF_GET_FLAGS) )
		{
			if( xLineCallingFeature.bEnableAcb!= bEnable )
			{
				xLineCallingFeature.bEnableAcb = bEnable;
				if( IFX_VMAPI_SUCCESS != 
					ifx_set_LineCallingFeatures(IFX_CIF_SETOPP_FLAG,
																			&xLineCallingFeature,
																			IFX_CIF_MOD_FLAG ) )
				{
					eRet = IFX_FAILURE;
				}
			}

		} /* retrieve calling features */
		if( IFX_SUCCESS != eRet )
			*peReason = IFX_CIF_CONFIG_ERROR;
	} /* get default line */

	return eRet;
}

e_IFX_Return IFX_CIF_EndptCallWaitingSet(
	               IN char8* szEndptId,
	               IN boolean bEnable,
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	uchar8 ucLineId;
	e_IFX_Return eRet;

	if( IFX_SUCCESS == 
		(eRet=IFX_CIF_EndptDefaultVLGet(szEndptId,
																							&ucLineId,peReason) ) )
	{
		eRet = IFX_SUCCESS;
		xLineCallingFeature.ucLineId = ucLineId;
    xLineCallingFeature.iid.config_owner = IFX_VOIP;

		if( IFX_VMAPI_SUCCESS == 
			ifx_get_LineCallingFeatures(&xLineCallingFeature,
																				IFX_CIF_GET_FLAGS) )
		{
			//if( xLineCallingFeature.bEnableDnd != bEnable )
			{
				xLineCallingFeature.bEnableCallWaiting = bEnable;
				if( IFX_VMAPI_SUCCESS != 
					ifx_set_LineCallingFeatures(IFX_CIF_SETOPP_FLAG,
																			&xLineCallingFeature,
																			IFX_CIF_MOD_FLAG ) )
				{
					eRet = IFX_FAILURE;
				}
			}

		} /* retrieve calling features */
		if( IFX_SUCCESS != eRet )
			*peReason = IFX_CIF_CONFIG_ERROR;
	} /* get default line */

	return eRet;
}

e_IFX_Return IFX_CIF_EndptCidStatusSet(
	               IN char8* szEndptId,
	               IN boolean bEnable,
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	uchar8 ucLineId;
	e_IFX_Return eRet;

	if( IFX_SUCCESS == 
		(eRet=IFX_CIF_EndptDefaultVLGet(szEndptId,
																							&ucLineId,peReason) ) )
	{
		eRet = IFX_SUCCESS;
		xLineCallingFeature.ucLineId = ucLineId;
    xLineCallingFeature.iid.config_owner = IFX_VOIP;

		if( IFX_VMAPI_SUCCESS == 
			ifx_get_LineCallingFeatures(&xLineCallingFeature,
																				IFX_CIF_GET_FLAGS) )
		{
				xLineCallingFeature.bEnableCid = bEnable;
				if( IFX_VMAPI_SUCCESS != 
					ifx_set_LineCallingFeatures(IFX_CIF_SETOPP_FLAG,
																			&xLineCallingFeature,
																			IFX_CIF_MOD_FLAG ) )
				{
					eRet = IFX_FAILURE;
				}
		} /* retrieve calling features */
		if( IFX_SUCCESS != eRet )
			*peReason = IFX_CIF_CONFIG_ERROR;
	} /* get default line */

	return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_NoOfEntriesGet
 *  Description     : This internal Api fetches number of entries in a given list.
 *  Input Values    : ucListId - List Identifier
 *                  : ucLineId - Line Identifier
 *  Output Values   : pucNoOfEntries - Number of entries in the list
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           :
 ****************************************************************************/

e_IFX_Return 
IFX_CIF_NoOfEntriesGet(IN uchar8 ucListId,
		                   IN uchar8 ucLineId,
                       OUT uchar8 *pucNoOfEntries){

#ifdef DECT_SUPPORT
   x_IFX_VMAPI_CallRegister xVmapiCall= {{{{""}}}};

   if(NULL == pucNoOfEntries){
	   return IFX_FAILURE;
	   
   }	   
	 *pucNoOfEntries = 0;
         xVmapiCall.ucLineId=ucLineId; 
         xVmapiCall.iid.config_owner = IFX_VOIP;

   x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
   switch(ucListId){
    case IFX_DECT_LAU_MISSED_CALLS:
	  { 	
        if(IFX_VMAPI_SUCCESS != ifx_get_MissCallReg(&xVmapiCall,IFX_VMAPI_OP_DEFAULT)){
          return IFX_FAILURE;
        }
        pxCallRegEntry = xVmapiCall.pxCallRegEntries;

        while(pxCallRegEntry != NULL){
	     //  if(ucLineId == pxCallRegEntry->ucLineId){
            ++(*pucNoOfEntries);
	//	     }	
         __ifx_list_GetNext((void *)&pxCallRegEntry);
        }
        ifx_vmapi_freeObjectList(&xVmapiCall, IFX_VMAPI_VS_MISSCALL_REGISTER);
    }
    break;

    case IFX_DECT_LAU_OUTGOING_CALLS:
		{
        if(IFX_VMAPI_SUCCESS != ifx_get_DialCallReg(&xVmapiCall,IFX_VMAPI_OP_DEFAULT)){
          return IFX_FAILURE;
        }
        pxCallRegEntry = xVmapiCall.pxCallRegEntries;

        while(pxCallRegEntry != NULL){
	     //  if(ucLineId == pxCallRegEntry->ucLineId){
            ++(*pucNoOfEntries);
	//	     }	
         __ifx_list_GetNext((void *)&pxCallRegEntry);
        }
        ifx_vmapi_freeObjectList(&xVmapiCall, IFX_VMAPI_VS_DIALCALL_REGISTER);
    }
	  break;

    case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:
		{
        if(IFX_VMAPI_SUCCESS != ifx_get_RecvCallReg(&xVmapiCall,IFX_VMAPI_OP_DEFAULT)){
          return IFX_FAILURE;
        }
        pxCallRegEntry = xVmapiCall.pxCallRegEntries;

        while(pxCallRegEntry != NULL){
	 //      if(ucLineId == pxCallRegEntry->ucLineId){
            ++(*pucNoOfEntries);
	//	     }	
         __ifx_list_GetNext((void *)&pxCallRegEntry);
        }
        ifx_vmapi_freeObjectList(&xVmapiCall, IFX_VMAPI_VS_RECVCALL_REGISTER);
    }
		break;

		case IFX_DECT_LAU_CONTACTS:
    {
         x_IFX_VMAPI_AddressBook xAddrBook = {{{{""}}}};

         xAddrBook.iid.config_owner = IFX_VOIP;
         if(IFX_VMAPI_SUCCESS != ifx_get_AddrBook(&xAddrBook,IFX_VMAPI_OP_DEFAULT)){
           return IFX_FAILURE;
         }
         *pucNoOfEntries = xAddrBook.ucNoOfAddBookEntries;
         ifx_vmapi_freeObjectList(&xAddrBook, IFX_VMAPI_VS_ADDRESS_BOOK);
		}
	  break;

		case IFX_DECT_LAU_INTERNAL_NAMES:
    {
         x_IFX_VMAPI_DectSystem xVmapiIntNames = {{{{""}}}};
         x_IFX_VMAPI_DectHandset *pxNameTbl = NULL;
         uchar8 i = 0;
         xVmapiIntNames.iid.config_owner = IFX_VOIP;

         if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xVmapiIntNames,IFX_VMAPI_OP_DEFAULT)){
            return IFX_FAILURE;
         }
         pxNameTbl = xVmapiIntNames.pxHandsetTbl;
				 if (pxNameTbl == NULL){
           return IFX_FAILURE;
				 }
         for(i=0; i<IFX_DECT_LAU_MAX_ATTACHED_PP;i++){
           if(pxNameTbl->xSubsInfo.bIsRegistered ){
             ++(*pucNoOfEntries);
           }
           __ifx_list_GetNext((void*)&pxNameTbl);
				 		if (pxNameTbl == NULL)
							break;
         }
         ifx_vmapi_freeObjectList(&xVmapiIntNames,IFX_VMAPI_DECT_SYSTEM);
		}
	  break;

    case IFX_DECT_LAU_SYS_SETTINGS:
        *pucNoOfEntries = 1;
        break;

    case IFX_DECT_LAU_LINE_SETTINGS:
    {
         x_IFX_VMAPI_VoiceService xVmapiLines = {{{{""}}}};
         uchar8 i = 0;
         xVmapiLines.iid.config_owner = IFX_VOIP;

         if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVmapiLines,IFX_VMAPI_OP_DEFAULT)){
           return IFX_FAILURE;
         }
         while(i < (2*IFX_VMAPI_MAX_VOICE_LINES+1) && xVmapiLines.ucLineIdList[i++] != 0){
             ++(*pucNoOfEntries);
         }
         ifx_vmapi_freeObjectList(&xVmapiLines,IFX_VMAPI_VOICE_SERVICE);
    }
		break;

		default:
		    break;
  } 
#endif
  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_MissedCallListGet
 *  Description     : This internal Api fetches Missed Call List entries for 
 *                    the specified line. 
 *  Input Values    : ucLineId - Line Identifier
 *  Output Values   : pxMissedCallList - pointer to Missed call list structure
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
#ifdef DECT_SUPPORT
e_IFX_Return
IFX_CIF_MissedCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_MissedCallList *pxMissedCallList)
{
  x_IFX_VMAPI_CallRegister xVmapiCallReg = {{{{""}}}};
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
  x_IFX_VMAPI_CallRegEntry *pxCallRegHead = NULL;
  int32 i=0;      
  char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]={0};
  e_IFX_Return eRet = IFX_FAILURE;
 
  if((NULL == pxMissedCallList) || (0 == ucLineId)){
    return IFX_FAILURE;
  }
	if(IFX_SUCCESS != IFX_CIF_GetLineName(ucLineId,acLineName))
     return IFX_FAILURE;
  xVmapiCallReg.ucLineId = ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
  printf("\nMissed Call List,Get Info for Line Id %d",ucLineId);
  if(IFX_VMAPI_SUCCESS == ifx_get_MissCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){

    pxCallRegEntry = pxCallRegHead = xVmapiCallReg.pxCallRegEntries;
    if(pxCallRegHead != NULL){
          
      __ifx_list_GetPrev((void*)&pxCallRegEntry);
      pxCallRegHead = pxCallRegEntry;
			if (pxCallRegEntry == NULL)
				return IFX_FAILURE;

      do{
           memcpy(pxMissedCallList->axMissedCallList[i].acCallerNum,pxCallRegEntry->xAddress.acUserName,
                strlen(pxCallRegEntry->xAddress.acUserName));
           memcpy(pxMissedCallList->axMissedCallList[i].acCallerName,pxCallRegEntry->xAddress.acDisplayName,
                strlen(pxCallRegEntry->xAddress.acDisplayName));
           IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
							                  &pxMissedCallList->axMissedCallList[i].xTimeDate);
           pxMissedCallList->axMissedCallList[i].bNew = pxCallRegEntry->bStatus;
					 strcpy(pxMissedCallList->axMissedCallList[i].acLineName,acLineName);
           pxMissedCallList->axMissedCallList[i].ucLineId = pxCallRegEntry->ucLineId;
           pxMissedCallList->axMissedCallList[i].ucNoOfCalls = pxCallRegEntry->ucNoOfCalls;
           pxMissedCallList->axMissedCallList[i].nEntryId = pxCallRegEntry->uiEntryId;
           pxMissedCallList->axMissedCallList[i].ucInternal = 0;

           i++;
         __ifx_list_GetPrev((void*)&pxCallRegEntry);
				 if (pxCallRegEntry == NULL)
					 break;
       }while(pxCallRegEntry != pxCallRegHead); 
    }
    pxMissedCallList->cNoOfEntries = i;
    eRet =  IFX_SUCCESS;
  }
  ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_MISSCALL_REGISTER);
  return eRet;
}
#endif

/******************************************************************************
 *  Function Name   : IFX_CIF_OutgoingCallListGet
 *  Description     : This internal Api fetches Outgoing Call List entries 
 *                    for the specified line.
 *  Input Values    : ucLineId - Line Identifier
 *  Output Values   : pxOutgoingCallList - pointer to Outgoing call list structure
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
#ifdef DECT_SUPPORT
e_IFX_Return
 IFX_CIF_OutgoingCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_OutgoingCallList *pxOutgoingCallList)
{
  x_IFX_VMAPI_CallRegister xVmapiCallReg = {{{{""}}}};
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
  x_IFX_VMAPI_CallRegEntry *pxCallRegHead = NULL;
  int32 i=0;      
  e_IFX_Return eRet = IFX_FAILURE;
  char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]={0};
 
  if((NULL == pxOutgoingCallList)||(0 == ucLineId)){
    return IFX_FAILURE;
  }
	if(IFX_SUCCESS != IFX_CIF_GetLineName(ucLineId,acLineName))
     return IFX_FAILURE;
  xVmapiCallReg.ucLineId = ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS == ifx_get_DialCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){

    pxCallRegEntry = pxCallRegHead = xVmapiCallReg.pxCallRegEntries;
    if(pxCallRegHead != NULL){
          
      __ifx_list_GetPrev((void*)&pxCallRegEntry);
      pxCallRegHead = pxCallRegEntry;
			if (pxCallRegEntry == NULL)
				return IFX_FAILURE;

      do{
           memcpy(pxOutgoingCallList->axOutgoingCallList[i].acCalledNum,pxCallRegEntry->xAddress.acUserName,
               strlen(pxCallRegEntry->xAddress.acUserName));
           if(!strlen(pxCallRegEntry->xAddress.acDisplayName)){
#ifdef SBB /*Not required as D&A TC_FT_NG1.N.16_BV_2109 fails*/
             memcpy(pxOutgoingCallList->axOutgoingCallList[i].acCalledName,pxCallRegEntry->xAddress.acUserName,
                   strlen(pxCallRegEntry->xAddress.acUserName));
#endif
           }else{
             memcpy(pxOutgoingCallList->axOutgoingCallList[i].acCalledName,pxCallRegEntry->xAddress.acDisplayName,
                   strlen(pxCallRegEntry->xAddress.acDisplayName));
            }
           IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
														 &pxOutgoingCallList->axOutgoingCallList[i].xTimeDate);
           strcpy(pxOutgoingCallList->axOutgoingCallList[i].acLineName,acLineName);
           pxOutgoingCallList->axOutgoingCallList[i].ucLineId = pxCallRegEntry->ucLineId;
           pxOutgoingCallList->axOutgoingCallList[i].nEntryId = pxCallRegEntry->uiEntryId;
           pxOutgoingCallList->axOutgoingCallList[i].ucInternal = 0;

           i++;
         __ifx_list_GetPrev((void*)&pxCallRegEntry);
				 if (pxCallRegEntry == NULL)
           break;

      }while(pxCallRegEntry != pxCallRegHead);
    }
    pxOutgoingCallList->cNoOfEntries = i;
    eRet = IFX_SUCCESS;
  }
  ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_DIALCALL_REGISTER);
  return eRet;
}
#endif
/******************************************************************************
 *  Function Name   : IFX_CIF_IncomingCallListGet
 *  Description     : This internal Api fetches Incoming Call List entries
 *                    for the specified line.
 *  Input Values    : ucLineId - Line Identifier 
 *  Output Values   : pxIncomingCallList - pointer to Incoming call list structure
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
#ifdef DECT_SUPPORT
e_IFX_Return
IFX_CIF_IncomingCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_IncomingCallList *pxIncomingCallList)
{
  x_IFX_VMAPI_CallRegister xVmapiCallReg = {{{{""}}}};
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
  x_IFX_VMAPI_CallRegEntry *pxCallRegHead = NULL;
  int32 i=0;
  char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]={0};
  e_IFX_Return eRet = IFX_FAILURE;

  if((NULL == pxIncomingCallList)||(0 == ucLineId)){
    return IFX_FAILURE;
  }
 if(IFX_SUCCESS != IFX_CIF_GetLineName(ucLineId,acLineName))
   return IFX_FAILURE;
  xVmapiCallReg.ucLineId = ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS == ifx_get_RecvCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){

    pxCallRegEntry = pxCallRegHead = xVmapiCallReg.pxCallRegEntries;
    if(pxCallRegHead != NULL){

      __ifx_list_GetPrev((void*)&pxCallRegEntry);
      pxCallRegHead = pxCallRegEntry;
			if (pxCallRegEntry == NULL)
				return IFX_FAILURE;

      do{
           memcpy(pxIncomingCallList->axIncomingCallList[i].acCallerNum,pxCallRegEntry->xAddress.acUserName,
                strlen(pxCallRegEntry->xAddress.acUserName));
           memcpy(pxIncomingCallList->axIncomingCallList[i].acCallerName,pxCallRegEntry->xAddress.acDisplayName,
                strlen(pxCallRegEntry->xAddress.acDisplayName));
           IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
															&pxIncomingCallList->axIncomingCallList[i].xTimeDate);
           strcpy(pxIncomingCallList->axIncomingCallList[i].acLineName,acLineName);
           pxIncomingCallList->axIncomingCallList[i].ucLineId = pxCallRegEntry->ucLineId;
           pxIncomingCallList->axIncomingCallList[i].nEntryId = pxCallRegEntry->uiEntryId;
           pxIncomingCallList->axIncomingCallList[i].ucInternal = 0;

           i++;
         __ifx_list_GetPrev((void*)&pxCallRegEntry);
				 if (pxCallRegEntry == NULL)
           break;

      }while(pxCallRegEntry != pxCallRegHead);
    }
    pxIncomingCallList->cNoOfEntries = i;
    eRet =  IFX_SUCCESS;
  }
  ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_RECVCALL_REGISTER);
  return eRet;
}
/******************************************************************************
 *  Function Name   : IFX_CIF_AllCallListGet
 *  Description     : This internal Api fetches the AllCall List entries for the specified
 *                    line.
 *  Input Values    : ucLineId - Line Identifier
 *  Output Values   : pxAllCallList - pointer to All call list structure
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
 IFX_CIF_AllCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_AllCallList *pxAllCallList){

  x_IFX_VMAPI_CallRegister xVmapiCallReg = {{{{""}}}};
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
  x_IFX_VMAPI_CallRegEntry *pxCallRegHead = NULL;
  int32 i=0;      
 char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]={0};
  if((NULL == pxAllCallList)||(0 == ucLineId)){
    return IFX_FAILURE;
  }
	if(IFX_SUCCESS != IFX_CIF_GetLineName(ucLineId,acLineName))
     return IFX_FAILURE;

  /*Add Missed Call Entries*/
  xVmapiCallReg.ucLineId = ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_MissCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){

    ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_MISSCALL_REGISTER);
    return IFX_FAILURE;
  }
  pxCallRegEntry = pxCallRegHead = xVmapiCallReg.pxCallRegEntries;
  if(pxCallRegHead != NULL){

   __ifx_list_GetPrev((void*)&pxCallRegEntry);
   pxCallRegHead = pxCallRegEntry;
			if (pxCallRegEntry == NULL)
				return IFX_FAILURE;

   do{

     pxAllCallList->axAllCallList[i].cCallListType = IFX_DECT_LAU_CALL_LIST_TYPE_MISSED;
     if(!strlen(pxCallRegEntry->xAddress.acDisplayName))
        memcpy(pxAllCallList->axAllCallList[i].acName,pxCallRegEntry->xAddress.acUserName,
               strlen(pxCallRegEntry->xAddress.acUserName));
     else
        memcpy(pxAllCallList->axAllCallList[i].acName,pxCallRegEntry->xAddress.acDisplayName,
               strlen(pxCallRegEntry->xAddress.acDisplayName));
     memcpy(pxAllCallList->axAllCallList[i].acNum,pxCallRegEntry->xAddress.acUserName,
            strlen(pxCallRegEntry->xAddress.acUserName));
     IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
													&pxAllCallList->axAllCallList[i].xTimeDate);
		 strcpy(pxAllCallList->axAllCallList[i].acLineName,acLineName);
     pxAllCallList->axAllCallList[i].ucLineId = pxCallRegEntry->ucLineId;
     pxAllCallList->axAllCallList[i].nEntryId = pxCallRegEntry->uiEntryId;
     pxAllCallList->axAllCallList[i].ucInternal = 0;

		 i++;
    __ifx_list_GetPrev((void*)&pxCallRegEntry);
		 if (pxCallRegEntry == NULL)
           break;

   }while(pxCallRegEntry != pxCallRegHead);      
  }
  
  ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_MISSCALL_REGISTER);
  memset(&xVmapiCallReg,0,sizeof(x_IFX_VMAPI_CallRegister));

  /*Add Incoming Received Call Entries*/
  xVmapiCallReg.ucLineId = ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_RecvCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){

    ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_RECVCALL_REGISTER);
    return IFX_FAILURE;
  }
  pxCallRegEntry = pxCallRegHead = xVmapiCallReg.pxCallRegEntries;
  if(pxCallRegHead != NULL){

   __ifx_list_GetPrev((void*)&pxCallRegEntry);
   pxCallRegHead = pxCallRegEntry;
	 if (pxCallRegEntry == NULL){
  	 ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_RECVCALL_REGISTER);
     return IFX_FAILURE;
	 }

   do{
     pxAllCallList->axAllCallList[i].cCallListType = IFX_DECT_LAU_CALL_LIST_TYPE_ACCEPTED;
     if(!strlen(pxCallRegEntry->xAddress.acDisplayName))
        memcpy(pxAllCallList->axAllCallList[i].acName,pxCallRegEntry->xAddress.acUserName,
               strlen(pxCallRegEntry->xAddress.acUserName));
     else
        memcpy(pxAllCallList->axAllCallList[i].acName,pxCallRegEntry->xAddress.acDisplayName,
               strlen(pxCallRegEntry->xAddress.acDisplayName));
     memcpy(pxAllCallList->axAllCallList[i].acNum,pxCallRegEntry->xAddress.acUserName,
            strlen(pxCallRegEntry->xAddress.acUserName));
     IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
													&pxAllCallList->axAllCallList[i].xTimeDate);
		 strcpy(pxAllCallList->axAllCallList[i].acLineName,acLineName);
     pxAllCallList->axAllCallList[i].ucLineId = pxCallRegEntry->ucLineId;
     pxAllCallList->axAllCallList[i].nEntryId = pxCallRegEntry->uiEntryId;
     pxAllCallList->axAllCallList[i].ucInternal = 0;

		 i++;
    __ifx_list_GetPrev((void*)&pxCallRegEntry);
   }while(pxCallRegEntry != NULL && pxCallRegEntry != pxCallRegHead);
  }
  
  ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_RECVCALL_REGISTER);
  memset(&xVmapiCallReg,0,sizeof(x_IFX_VMAPI_CallRegister));

  /*Add Outgoing Call Entries*/
  xVmapiCallReg.ucLineId = ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_DialCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){

    ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_DIALCALL_REGISTER);
    return IFX_FAILURE;
  }
  pxCallRegEntry = pxCallRegHead = xVmapiCallReg.pxCallRegEntries;
  if(pxCallRegHead != NULL){

   __ifx_list_GetPrev((void*)&pxCallRegEntry);
   if(pxCallRegEntry == NULL){
		 ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_DIALCALL_REGISTER);
  	 return IFX_FAILURE;
	 }
			pxCallRegHead = pxCallRegEntry;

   do{

     pxAllCallList->axAllCallList[i].cCallListType = IFX_DECT_LAU_CALL_LIST_TYPE_OUTGOING;
     if(!strlen(pxCallRegEntry->xAddress.acDisplayName))
        memcpy(pxAllCallList->axAllCallList[i].acName,pxCallRegEntry->xAddress.acUserName,
               strlen(pxCallRegEntry->xAddress.acUserName));
     else
        memcpy(pxAllCallList->axAllCallList[i].acName,pxCallRegEntry->xAddress.acDisplayName,
               strlen(pxCallRegEntry->xAddress.acDisplayName));
     memcpy(pxAllCallList->axAllCallList[i].acNum,pxCallRegEntry->xAddress.acUserName,
            strlen(pxCallRegEntry->xAddress.acUserName));
     IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
													&pxAllCallList->axAllCallList[i].xTimeDate);
		 strcpy(pxAllCallList->axAllCallList[i].acLineName,acLineName);
     pxAllCallList->axAllCallList[i].ucLineId = pxCallRegEntry->ucLineId;
     pxAllCallList->axAllCallList[i].nEntryId = pxCallRegEntry->uiEntryId;
     pxAllCallList->axAllCallList[i].ucInternal = 0;

		 i++;
    __ifx_list_GetPrev((void*)&pxCallRegEntry);
   }while(pxCallRegEntry != NULL && pxCallRegEntry != pxCallRegHead);
  }
  pxAllCallList->cNoOfEntries = i;

  ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_DIALCALL_REGISTER);
  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_IntNameGet
 *  Description     : This internal Api fetches the Internal Names List entries
 *  Input Values    : 
 *  Output Values   : pxIntNameList - pointer to Line Settings list structure
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
 IFX_CIF_IntNameGet(OUT x_IFX_DECT_LAU_IntNameList *pxIntNameList){

    x_IFX_VMAPI_DectSystem xVmapiIntList = {{{{""}}}};
    x_IFX_VMAPI_DectHandset *pxInttbl = NULL;
		int32 i=0,j=0;

    if(NULL == pxIntNameList){
       return IFX_FAILURE;
    }       
    xVmapiIntList.iid.config_owner = IFX_VOIP;
    if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xVmapiIntList,IFX_VMAPI_OP_DEFAULT)){
       ifx_vmapi_freeObjectList(&xVmapiIntList,IFX_VMAPI_DECT_SYSTEM);
       return IFX_FAILURE;
    	 }
    pxInttbl = xVmapiIntList.pxHandsetTbl;
		if (!pxInttbl)
			return IFX_FAILURE;
    for(j=0;j<IFX_DECT_LAU_MAX_ATTACHED_PP;j++){

      if(pxInttbl != NULL &&  pxInttbl->xSubsInfo.bIsRegistered){

        sprintf(pxIntNameList->axIntNameList[i].acTermIdNum,"%d",(j+1));
        memcpy(pxIntNameList->axIntNameList[i].acName,pxInttbl->ucEndPtName,
               strlen((char8 *)pxInttbl->ucEndPtName));
        pxIntNameList->axIntNameList[i].ucOwn = 0x00;
        pxIntNameList->axIntNameList[i].nEntryId = j+1;
        pxIntNameList->axIntNameList[i].ucCallIntercept=pxInttbl->bIntercept+48;//TODO
        pxIntNameList->axIntNameList[i].uiEditField = IFX_DECT_LAU_IL_FNAME|IFX_DECT_LAU_IL_INTERCEPTION|
																											IFX_DECT_LAU_IL_INTERCEPTION_PIN;
				i++;
			}	
      __ifx_list_GetNext((void*)&pxInttbl);
		}	

    pxIntNameList->cNoOfEntries = i;
    ifx_vmapi_freeObjectList(&xVmapiIntList,IFX_VMAPI_DECT_SYSTEM);
		return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_SystemGet
 *  Description     : This internal Api reads the System Settings List entry.
 *  Input Values    : 
 *  Output Values   : pxSysSetList - pointer to Line Settings list structure
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
 IFX_CIF_SystemGet(OUT x_IFX_DECT_LAU_SystemSettingsList *pxSysSetList){

  x_IFX_VMAPI_SystemVersionRegister xVmapiSysVer = {{{{""}}}};
  x_IFX_VMAPI_DectSystem xVmapiPincode = {{{{""}}}};

  if(NULL == pxSysSetList){
	  return IFX_FAILURE;
  }	  
  pxSysSetList->uiEditField = IFX_DECT_LAU_SSE_PIN|IFX_DECT_LAU_SSE_CLKMSTR|IFX_DECT_LAU_SSE_BASERESET|
                              IFX_DECT_LAU_SSE_PIN_PIN|IFX_DECT_LAU_SSE_CLKMSTR_PIN|IFX_DECT_LAU_SSE_BASERESET_PIN|
                              IFX_DECT_LAU_SSE_NEWPIN|IFX_DECT_LAU_SSE_NEM|IFX_DECT_LAU_SSE_NEWPIN_PIN|
															IFX_DECT_LAU_SSE_NEM_PIN;
	
  xVmapiSysVer.iid.config_owner = IFX_VOIP;
  if(IFX_SUCCESS != ifx_get_Version(&xVmapiSysVer,IFX_VMAPI_OP_DEFAULT)){
     return IFX_FAILURE;
  }
  memcpy(pxSysSetList->acBaseFwVersion,xVmapiSysVer.acFirmwareVer,strlen(xVmapiSysVer.acFirmwareVer));
  xVmapiPincode.iid.config_owner = IFX_VOIP;
  if(IFX_SUCCESS != ifx_get_DectInterface(&xVmapiPincode,IFX_VMAPI_OP_DEFAULT)){
    ifx_vmapi_freeObjectList(&xVmapiPincode,IFX_VMAPI_DECT_SYSTEM);
    return IFX_FAILURE;
  }
	pxSysSetList->cClockMaster =(xVmapiPincode.ucClkMaster==1)?IFX_DECT_LAU_CLOCK_MASTER_FP:IFX_DECT_LAU_CLOCK_MASTER_PP;

  memcpy(pxSysSetList->acPIN,xVmapiPincode.acAuthCode,strlen(xVmapiPincode.acAuthCode));
  memcpy(pxSysSetList->acNewPIN,xVmapiPincode.acAuthCode,strlen(xVmapiPincode.acAuthCode));

   if((xVmapiPincode.ucClkMaster == 1)&&(!strcmp(xVmapiPincode.acAuthCode,"0000"))){
     pxSysSetList->cBaseReset = IFX_DECT_LAU_BASE_RESET_YES;
   }else{
     pxSysSetList->cBaseReset = IFX_DECT_LAU_BASE_RESET_NO;
    }
  pxSysSetList->cEmissionMode=xVmapiPincode.ucNoEmo;

  ifx_vmapi_freeObjectList(&xVmapiSysVer,IFX_VMAPI_VS_VER);
  ifx_vmapi_freeObjectList(&xVmapiPincode,IFX_VMAPI_DECT_SYSTEM);

  return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_CIF_LineGet
 *  Description     : This internal Api fetches Line settings List entries        
 *  Input Values    : 
 *  Output Values   : pxLineSetList - pointer to Line Settings list structure
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
 IFX_CIF_LineGet(OUT x_IFX_DECT_LAU_LineSettingsList *pxLineSetList)
{
	x_IFX_VMAPI_LineCallingFeatures xVmapiLineFeatures = {{{{""}}}};
	x_IFX_VMAPI_DectSystem xVmapiDectHSet = {{{{""}}}};
  x_IFX_VMAPI_VoiceService xVmapiLinesCount= {{{{""}}}};
  x_IFX_VMAPI_DectHandset *pxHStbl = NULL;
	int32 i=0,j=0,k=0,iNumHs=0;
  x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{0}}}};
  x_IFX_VMAPI_FxoPhyIf xFXO = {{{{0}}}};
  
  //char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]={0};

	if(NULL == pxLineSetList){
		return IFX_FAILURE;
	}	
  xVmapiLinesCount.iid.config_owner = IFX_VOIP;
	if(IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVmapiLinesCount,IFX_VMAPI_OP_DEFAULT)){
    ifx_vmapi_freeObjectList(&xVmapiLinesCount,IFX_VMAPI_VOICE_SERVICE);
  	return IFX_FAILURE;
  }
  xVmapiDectHSet.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xVmapiDectHSet,IFX_VMAPI_OP_DEFAULT)){
     ifx_vmapi_freeObjectList(&xVmapiDectHSet,IFX_VMAPI_DECT_SYSTEM);
     return IFX_FAILURE;
	}	 
	for(i=0;xVmapiLinesCount.ucLineIdList[i] !='\0';i++){

	   xVmapiLineFeatures.ucLineId = xVmapiLinesCount.ucLineIdList[i];
     xVmapiLineFeatures.iid.config_owner = IFX_VOIP;
     if(IFX_VMAPI_SUCCESS != ifx_get_LineCallingFeatures(&xVmapiLineFeatures,IFX_VMAPI_OP_DEFAULT)){
       return IFX_FAILURE;
     }
   	if(xVmapiLineFeatures.ucLineId != IFX_VMAPI_PSTN_LINE){
  		xVoiceLine.ucLineId = xVmapiLinesCount.ucLineIdList[i];
  		xVoiceLine.iid.config_owner = IFX_VOIP;
  		if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,0)){
			 	return IFX_FAILURE;
		 	} 	
       memcpy(pxLineSetList->axLineEntry[i].acLineName,xVoiceLine.acName,IFX_DECT_LAU_MAX_LINE_NAME_LEN);
			 pxLineSetList->axLineEntry[i].acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN-1]='\0';
    	 pxLineSetList->axLineEntry[i].ucCallMode = 
													(xVoiceLine.ucLineMode == 1)?IFX_DECT_LAU_CALL_MODE_MULTIPLE:IFX_DECT_LAU_CALL_MODE_SINGLE;
    	 pxLineSetList->axLineEntry[i].ucCallIntrusion = xVoiceLine.ucIntrusion+0x30; 
     }
     pxLineSetList->axLineEntry[i].ucLineId = xVmapiLineFeatures.ucLineId;
     iNumHs=0;
     pxHStbl = xVmapiDectHSet.pxHandsetTbl;
     for(j=0;j<IFX_DECT_LAU_MAX_ATTACHED_PP;j++){
        if(pxHStbl->xSubsInfo.bIsRegistered ){
          k=0;
          while(pxHStbl->aucVoiceLineIdList[k] != '\0'){
              if(pxHStbl->aucVoiceLineIdList[k] == (48+pxLineSetList->axLineEntry[i].ucLineId)){
                pxLineSetList->axLineEntry[i].xAttachedPP.acAttachedPP[j] = 1;
                iNumHs++;
                break;
              }
					 k+=2;
          }
        }
        __ifx_list_GetNext((void*)&pxHStbl);
				if (!pxHStbl)
					break;
     }
     pxLineSetList->axLineEntry[i].xAttachedPP.cNoOfPP = iNumHs;

		 pxLineSetList->axLineEntry[i].xCLIRInfo.ucCLIRStatus = (xVmapiLineFeatures.bEnableCid == 1)?IFX_DECT_LAU_CLIR_DEACTIVATE:IFX_DECT_LAU_CLIR_ACTIVATE;
    // pxLineSetList->axLineEntry[i].ucCallIntrusion=0x30;//TODO:

     pxLineSetList->axLineEntry[i].xCFInfoU.ucNoOfSec = 0;
     memcpy(pxLineSetList->axLineEntry[i].xCFInfoU.ucCFNum,xVmapiLineFeatures.xCfuAddress.acUserName,
           strlen(xVmapiLineFeatures.xCfuAddress.acUserName));

     pxLineSetList->axLineEntry[i].xCFInfoN.ucNoOfSec = xVmapiLineFeatures.ucCfnaRingCount;
     memcpy(pxLineSetList->axLineEntry[i].xCFInfoN.ucCFNum,xVmapiLineFeatures.xCfnaAddress.acUserName,
           strlen(xVmapiLineFeatures.xCfnaAddress.acUserName));
     pxLineSetList->axLineEntry[i].xCFInfoB.ucNoOfSec = 0;
     memcpy(pxLineSetList->axLineEntry[i].xCFInfoB.ucCFNum,xVmapiLineFeatures.xCfbAddress.acUserName,
                     strlen(xVmapiLineFeatures.xCfbAddress.acUserName));
		 pxLineSetList->axLineEntry[i].xCFInfoU.ucStatus = ((xVmapiLineFeatures.unCallFwdCfg & IFX_VMAPI_CALL_FWD_UNCONDITIONAL)!= 0)?
			                                                 IFX_DECT_LAU_CF_ON:IFX_DECT_LAU_CF_OFF;
     pxLineSetList->axLineEntry[i].xCFInfoN.ucStatus = ((xVmapiLineFeatures.unCallFwdCfg & IFX_VMAPI_CALL_FWD_ON_NO_ANSWER)!=0)?
			                                                   IFX_DECT_LAU_CF_ON:IFX_DECT_LAU_CF_OFF;
     pxLineSetList->axLineEntry[i].xCFInfoB.ucStatus = ((xVmapiLineFeatures.unCallFwdCfg & IFX_VMAPI_CALL_FWD_BUSY)!=0)?
			                                                   IFX_DECT_LAU_CF_ON:IFX_DECT_LAU_CF_OFF;

    pxLineSetList->axLineEntry[i].nEntryId =  xVmapiLineFeatures.ucLineId;
    pxLineSetList->axLineEntry[i].uiEditField = IFX_DECT_LAU_LSE_ATCHPP|IFX_DECT_LAU_LSE_CLIR|
                                                IFX_DECT_LAU_LSE_CFU|IFX_DECT_LAU_LSE_CFB|IFX_DECT_LAU_LSE_CFN|
                                                IFX_DECT_LAU_LSE_ATCHPP_PIN|IFX_DECT_LAU_LSE_CLIR_PIN|
                                                IFX_DECT_LAU_LSE_CFU_PIN|IFX_DECT_LAU_LSE_CFB_PIN|
																								IFX_DECT_LAU_LSE_CFN_PIN|IFX_DECT_LAU_LSE_CALLMODE|
																								IFX_DECT_LAU_LSE_CALLMODE_PIN|IFX_DECT_LAU_LSE_LINENAME|
																								IFX_DECT_LAU_LSE_LINENAME_PIN|IFX_DECT_LAU_LSE_INTR|
																								IFX_DECT_LAU_LSE_INTR_PIN;
    ifx_vmapi_freeObjectList(&xVmapiLineFeatures, IFX_VMAPI_VL_CALLFEAT);
   }
   /* PSTN Line */

    xFXO.xVoiceServPhyIf.ucInterfaceId = 3;
		xFXO.iid.config_owner = IFX_VOIP;
		if(IFX_VMAPI_SUCCESS != ifx_get_FxoPhyInterface(&xFXO,IFX_VMAPI_OP_DEFAULT)){
			return IFX_FAILURE;
		}

   pxLineSetList->axLineEntry[i].ucLineId = IFX_VMAPI_PSTN_LINE;
   memcpy(pxLineSetList->axLineEntry[i].acLineName,xFXO.acName,IFX_DECT_LAU_MAX_LINE_NAME_LEN);
	 pxLineSetList->axLineEntry[i].acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN-1]='\0';
   pxLineSetList->axLineEntry[i].ucCallMode = 
             (xFXO.ucLineMode == 1)?IFX_DECT_LAU_CALL_MODE_MULTIPLE:IFX_DECT_LAU_CALL_MODE_SINGLE;
   pxLineSetList->axLineEntry[i].ucCallIntrusion = xFXO.ucIntrusion+0x30; 
   /* Populate Interface Id List for PSTN Line */
   iNumHs=0;                                                                                                                                                               
   pxHStbl = xVmapiDectHSet.pxHandsetTbl;                                                                                                                                  
   for(j=0;j<IFX_DECT_LAU_MAX_ATTACHED_PP;j++){                                                                                                                            
      if(pxHStbl->xSubsInfo.bIsRegistered ){                                                                                                                               
          k=0;
          while(pxHStbl->aucVoiceLineIdList[k] != '\0'){
           if(pxHStbl->aucVoiceLineIdList[k] == (48+IFX_VMAPI_PSTN_LINE)){                                                                             
              pxLineSetList->axLineEntry[i].xAttachedPP.acAttachedPP[j] = 1;                                                                                               
              iNumHs++;                                                                                                                                                    
              break;                                                                                                                                                       
           }
        k+=2;                                                                                                                                                              
        }                                                                                                                                                                  
      }                                                                                                                                                                    
      __ifx_list_GetNext((void*)&pxHStbl);                                                                                                                                 				if (!pxHStbl)
					break;
   }                                                                                                                                                                       
   pxLineSetList->axLineEntry[i].xAttachedPP.cNoOfPP = iNumHs; 

   memset(&pxLineSetList->axLineEntry[i].xCFInfoU,0,sizeof(pxLineSetList->axLineEntry[i].xCFInfoU));
   memset(&pxLineSetList->axLineEntry[i].xCFInfoB,0,sizeof(pxLineSetList->axLineEntry[i].xCFInfoB));
   memset(&pxLineSetList->axLineEntry[i].xCFInfoN,0,sizeof(pxLineSetList->axLineEntry[i].xCFInfoN));

	 pxLineSetList->axLineEntry[i].xCLIRInfo.ucCLIRStatus = 0;
   pxLineSetList->axLineEntry[i].nEntryId =  IFX_VMAPI_PSTN_LINE;
   pxLineSetList->axLineEntry[i].uiEditField = IFX_DECT_LAU_LSE_ATCHPP|IFX_DECT_LAU_LSE_CLIR|
                                                IFX_DECT_LAU_LSE_CFU|IFX_DECT_LAU_LSE_CFB|
																								IFX_DECT_LAU_LSE_CFN|IFX_DECT_LAU_LSE_CALLMODE|
																								IFX_DECT_LAU_LSE_ATCHPP_PIN|IFX_DECT_LAU_LSE_CLIR_PIN|
                                                IFX_DECT_LAU_LSE_CFU_PIN|IFX_DECT_LAU_LSE_CFB_PIN|
																								IFX_DECT_LAU_LSE_CFN_PIN|IFX_DECT_LAU_LSE_CALLMODE_PIN|
																								IFX_DECT_LAU_LSE_LINENAME|IFX_DECT_LAU_LSE_LINENAME_PIN|
																								IFX_DECT_LAU_LSE_INTR|IFX_DECT_LAU_LSE_INTR_PIN;
   
   pxLineSetList->ucNoOfLines = i+1;
   ifx_vmapi_freeObjectList(&xVmapiLinesCount,IFX_VMAPI_VOICE_SERVICE);
   ifx_vmapi_freeObjectList(&xVmapiDectHSet,IFX_VMAPI_DECT_SYSTEM);
	 return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_CIF_AllIncomingCallListGet
 *  Description     : This internal Api fetches All Incoming Call List entries
 *                    for the specified line.
 *  Input Values    : ucLineId - Line Identifier 
 *  Output Values   : pxAllIncomingCallList - pointer to All Incoming call list structure
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
 IFX_CIF_AllIncomingCallListGet(IN uchar8 ucLineId,OUT x_IFX_DECT_LAU_AllIncomingCallList *pxAllIncomingCallList){

  x_IFX_VMAPI_CallRegister xVmapiCallReg = {{{{""}}}};
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
  x_IFX_VMAPI_CallRegEntry *pxCallRegHead = NULL;
  int32 i=0;
  char8 acLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN]={0};

  if((NULL == pxAllIncomingCallList)||(0 == ucLineId)){
    return IFX_FAILURE;
  }
 if(IFX_SUCCESS != IFX_CIF_GetLineName(ucLineId,acLineName))
    return IFX_FAILURE;
  /*Add Missed Call Entries*/
  xVmapiCallReg.ucLineId=ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_MissCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){

    ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_MISSCALL_REGISTER);
    return IFX_FAILURE;
  }
  pxCallRegEntry = pxCallRegHead = xVmapiCallReg.pxCallRegEntries;
  if(pxCallRegHead != NULL){

    __ifx_list_GetPrev((void*)&pxCallRegEntry);
    pxCallRegHead = pxCallRegEntry;

		if (pxCallRegEntry == NULL)
			return IFX_FAILURE;

    do{
	//	 if(ucLineId == pxCallRegEntry->ucLineId){
      memcpy(pxAllIncomingCallList->axAllIncomingCallList[i].acCallerName,pxCallRegEntry->xAddress.acDisplayName,
             strlen(pxCallRegEntry->xAddress.acDisplayName));
      memcpy(pxAllIncomingCallList->axAllIncomingCallList[i].acCallerNum,pxCallRegEntry->xAddress.acUserName,
             strlen(pxCallRegEntry->xAddress.acUserName));
      IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
													 &pxAllIncomingCallList->axAllIncomingCallList[i].xTimeDate);
		  strcpy(pxAllIncomingCallList->axAllIncomingCallList[i].acLineName,acLineName);
      pxAllIncomingCallList->axAllIncomingCallList[i].ucLineId = pxCallRegEntry->ucLineId;
      pxAllIncomingCallList->axAllIncomingCallList[i].nEntryId = pxCallRegEntry->uiEntryId;
      pxAllIncomingCallList->axAllIncomingCallList[i].ucInternal = 0;
      pxAllIncomingCallList->axAllIncomingCallList[i].bNew = pxCallRegEntry->bStatus;
      pxAllIncomingCallList->axAllIncomingCallList[i].ucNoOfCalls = pxCallRegEntry->ucNoOfCalls;
      i++;
	//	 }	
     __ifx_list_GetPrev((void*)&pxCallRegEntry);
				if (!pxCallRegEntry)
					break;
    }while(pxCallRegEntry != pxCallRegHead);
  }

  ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_MISSCALL_REGISTER);
  memset(&xVmapiCallReg,0,sizeof(x_IFX_VMAPI_CallRegister));

  /*Add Incoming Received Call Entries*/
  xVmapiCallReg.ucLineId=ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_RecvCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){

    ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_RECVCALL_REGISTER);
    return IFX_FAILURE;
  }
  pxCallRegEntry = pxCallRegHead = xVmapiCallReg.pxCallRegEntries;
  if(pxCallRegHead != NULL){

    __ifx_list_GetPrev((void*)&pxCallRegEntry);
   pxCallRegHead = pxCallRegEntry;
		if (pxCallRegEntry == NULL)
			return IFX_FAILURE;
    do{
	//	 if(ucLineId == pxCallRegEntry->ucLineId){
      memcpy(pxAllIncomingCallList->axAllIncomingCallList[i].acCallerName,pxCallRegEntry->xAddress.acDisplayName,
             strlen(pxCallRegEntry->xAddress.acDisplayName));
      memcpy(pxAllIncomingCallList->axAllIncomingCallList[i].acCallerNum,pxCallRegEntry->xAddress.acUserName,
             strlen(pxCallRegEntry->xAddress.acUserName));
      IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
													 &pxAllIncomingCallList->axAllIncomingCallList[i].xTimeDate);
		  strcpy(pxAllIncomingCallList->axAllIncomingCallList[i].acLineName,acLineName);
      pxAllIncomingCallList->axAllIncomingCallList[i].ucLineId = pxCallRegEntry->ucLineId;
      pxAllIncomingCallList->axAllIncomingCallList[i].nEntryId = pxCallRegEntry->uiEntryId;
      pxAllIncomingCallList->axAllIncomingCallList[i].bNew = 0xFF;
      pxAllIncomingCallList->axAllIncomingCallList[i].ucNoOfCalls = 0xFF;
      pxAllIncomingCallList->axAllIncomingCallList[i].ucInternal = 0;

      i++;
	//	 }	
     __ifx_list_GetPrev((void*)&pxCallRegEntry);
				if (!pxCallRegEntry)
					break;
    }while(pxCallRegEntry != pxCallRegHead);
  }
  pxAllIncomingCallList->cNoOfEntries = i;

  ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_RECVCALL_REGISTER);
  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_ContactListGet
 *  Description     : This internal Api fetches the contact list entries. 
 *  Input Values    : 
 *  Output Values   : pxContactList - Contact list
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
IFX_CIF_ContactListGet(OUT x_IFX_DECT_LAU_ContactList *pxDectContacts, 
											 uchar8 ucLineId)
{
  x_IFX_VMAPI_ContactList xVmapiContacts;
	int i=0;
  e_IFX_Return eRet = IFX_FAILURE;
	memset(&xVmapiContacts,0,sizeof(xVmapiContacts));
  
	if(NULL == pxDectContacts || ucLineId == 0){
		printf("<CfgIf_ContactListGet> Invalid IN Params\n");
    return IFX_FAILURE;
  }

	xVmapiContacts.iid.config_owner = IFX_VOIP;
	xVmapiContacts.ucLineId = ucLineId;
	memset(pxDectContacts,0,sizeof(x_IFX_DECT_LAU_ContactList));
	if(IFX_VMAPI_SUCCESS == 
		 ifx_get_ContactList (&xVmapiContacts,IFX_VMAPI_OP_DEFAULT)){

				x_IFX_VMAPI_ContactListEntry *pxTemp=NULL;
        pxTemp = xVmapiContacts.pxContactEntries;
				while(pxTemp != NULL){
          int32 k = 0;
          pxDectContacts->axContactList[i].xNumber.ucNoOfContactNumbers =0;

					strncpy(pxDectContacts->axContactList[i].acLastName,pxTemp->xAddress.acUserLastName,
									sizeof(pxDectContacts->axContactList[i].acLastName)-1);

					strncpy(pxDectContacts->axContactList[i].acFirstName,pxTemp->xAddress.acUserFirstName,
									sizeof(pxDectContacts->axContactList[i].acFirstName)-1);

          if(pxTemp->xAddress.acContactNum[0] != '\0'){
      		  strncpy(pxDectContacts->axContactList[i].xNumber.xNum[k].acNumber,
									pxTemp->xAddress.acContactNum,
									sizeof(pxDectContacts->axContactList[i].xNumber.xNum[k].acNumber)-1);
            pxDectContacts->axContactList[i].xNumber.xNum[k].ctype = pxTemp->xAddress.cContactType;
            k++;  
      		  pxDectContacts->axContactList[i].xNumber.ucNoOfContactNumbers++;
          }

          if(pxTemp->xAddress.acContactNumTwo[0] != '\0'){
      		 strncpy(pxDectContacts->axContactList[i].xNumber.xNum[k].acNumber,
									pxTemp->xAddress.acContactNumTwo,
									sizeof(pxDectContacts->axContactList[i].xNumber.xNum[k].acNumber)-1);
           pxDectContacts->axContactList[i].xNumber.xNum[k].ctype = pxTemp->xAddress.cContactTypeTwo;
      		 pxDectContacts->axContactList[i].xNumber.ucNoOfContactNumbers++;
          }   

          if((pxTemp->xAddress.acContactNum[0] == '\0')&&(pxTemp->xAddress.acContactNumTwo[0] == '\0')){
           pxDectContacts->axContactList[i].xNumber.xNum[0].acNumber[0] = '\0';
           pxDectContacts->axContactList[i].xNumber.xNum[0].ctype = 0;
      		 pxDectContacts->axContactList[i].xNumber.ucNoOfContactNumbers = 1;
          }

      		pxDectContacts->axContactList[i].ucAssocMelody = 0;
      		pxDectContacts->axContactList[i].ucSubType = IFX_DECT_LINE_SUBTYPE_RELATING_TO;
      		pxDectContacts->axContactList[i].ucLineId = ucLineId;
      		pxDectContacts->axContactList[i].nEntryId = pxTemp->uiEntryId;
      		pxDectContacts->axContactList[i].uiEditField = 
					(IFX_DECT_LAU_CON_LIST_NAME | IFX_DECT_LAU_CON_LIST_FIRST_NAME | 
					 IFX_DECT_LAU_CON_LIST_NUMBER | IFX_DECT_LAU_CON_LIST_LINE_ID);

				/*	printf("<CIF_GetContacts> Line Id = %d EntryId = %d F.Name =%s L.Name =%s\n",
					ucLineId,pxTemp->uiEntryId,pxDectContacts->axContactList[i].acFirstName,
					pxDectContacts->axContactList[i].acLastName);*/
					i++;
      		__ifx_list_GetNext((void *)&pxTemp);

				}
				pxDectContacts->unNoOfEntries = i;
    		eRet = IFX_SUCCESS;
		}
		ifx_vmapi_freeObjectList(&xVmapiContacts, IFX_VMAPI_VS_CONTACT_LIST);
		return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_CommonContactListGet
 *  Description     : This internal Api fetches the contact list entries. 
 *  Input Values    : 
 *  Output Values   : pxContactList - Contact list
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
IFX_CIF_CommonContactListGet(OUT x_IFX_DECT_LAU_ContactList *pxDectContacts 
											 )
{
  x_IFX_VMAPI_ContactList xVmapiContacts;
	int i=0;
  e_IFX_Return eRet = IFX_FAILURE;
	memset(&xVmapiContacts,0,sizeof(xVmapiContacts));
  
	if(NULL == pxDectContacts ){
		printf("<CfgIf_CommonContactListGet> Invalid IN Params\n");
    return IFX_FAILURE;
  }

	xVmapiContacts.iid.config_owner = IFX_VOIP;
	memset(pxDectContacts,0,sizeof(x_IFX_DECT_LAU_ContactList));
	if(IFX_VMAPI_SUCCESS == 
		 ifx_get_CommonContactList (&xVmapiContacts,IFX_VMAPI_OP_DEFAULT)){

				x_IFX_VMAPI_ContactListEntry *pxTemp=NULL;
        pxTemp = xVmapiContacts.pxContactEntries;
				while(pxTemp != NULL){
          int32 k = 0;
          pxDectContacts->axContactList[i].xNumber.ucNoOfContactNumbers =0;

					strncpy(pxDectContacts->axContactList[i].acLastName,pxTemp->xAddress.acUserLastName,
									sizeof(pxDectContacts->axContactList[i].acLastName)-1);

					strncpy(pxDectContacts->axContactList[i].acFirstName,pxTemp->xAddress.acUserFirstName,
									sizeof(pxDectContacts->axContactList[i].acFirstName)-1);

          if(pxTemp->xAddress.acContactNum[0] != '\0'){
      		  strncpy(pxDectContacts->axContactList[i].xNumber.xNum[k].acNumber,
									pxTemp->xAddress.acContactNum,
									sizeof(pxDectContacts->axContactList[i].xNumber.xNum[k].acNumber)-1);
            pxDectContacts->axContactList[i].xNumber.xNum[k].ctype = pxTemp->xAddress.cContactType;
            k++;  
      		  pxDectContacts->axContactList[i].xNumber.ucNoOfContactNumbers++;
          }

          if(pxTemp->xAddress.acContactNumTwo[0] != '\0'){
      		 strncpy(pxDectContacts->axContactList[i].xNumber.xNum[k].acNumber,
									pxTemp->xAddress.acContactNumTwo,
									sizeof(pxDectContacts->axContactList[i].xNumber.xNum[k].acNumber)-1);
           pxDectContacts->axContactList[i].xNumber.xNum[k].ctype = pxTemp->xAddress.cContactTypeTwo;
      		 pxDectContacts->axContactList[i].xNumber.ucNoOfContactNumbers++;
          }   

          if((pxTemp->xAddress.acContactNum[0] == '\0')&&(pxTemp->xAddress.acContactNumTwo[0] == '\0')){
           pxDectContacts->axContactList[i].xNumber.xNum[0].acNumber[0] = '\0';
           pxDectContacts->axContactList[i].xNumber.xNum[0].ctype = 0;
      		 pxDectContacts->axContactList[i].xNumber.ucNoOfContactNumbers = 1;
          }

      		pxDectContacts->axContactList[i].ucAssocMelody = 0;
      		pxDectContacts->axContactList[i].ucSubType = IFX_DECT_LINE_SUBTYPE_ALL;
      		pxDectContacts->axContactList[i].ucLineId = pxTemp->ucLineId;
      		pxDectContacts->axContactList[i].nEntryId = pxTemp->uiEntryId;
      		pxDectContacts->axContactList[i].uiEditField = 
					(IFX_DECT_LAU_CON_LIST_NAME | IFX_DECT_LAU_CON_LIST_FIRST_NAME | 
					 IFX_DECT_LAU_CON_LIST_NUMBER | IFX_DECT_LAU_CON_LIST_LINE_ID);

				/*	printf("<CIF_GetContacts> Line Id = %d EntryId = %d F.Name =%s L.Name =%s\n",
					ucLineId,pxTemp->uiEntryId,pxDectContacts->axContactList[i].acFirstName,
					pxDectContacts->axContactList[i].acLastName);*/
					i++;
      		__ifx_list_GetNext((void *)&pxTemp);

				}
				pxDectContacts->unNoOfEntries = i;
    		eRet = IFX_SUCCESS;
		}
		ifx_vmapi_freeObjectList(&xVmapiContacts, IFX_VMAPI_VS_CONTACT_LIST);
		return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_IntNameSet
 *  Description     : This internal Api performs edit/delete entry operation
 *                    on Internal Names List
 *  Input Values    : pxListName - pointer to Internal Names List
 *										ucOp - operation to be done
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
IFX_CIF_IntNameSet(IN x_IFX_DECT_LAU_IntNameList *pxListName,
                   IN uchar8 ucOp){

  x_IFX_VMAPI_DectSystem xVmapiIntList = {{{{""}}}};
  x_IFX_VMAPI_DectHandset *pxInttbl = NULL;
	int32 i = 0,iHsNum=0;
  e_IFX_Return eRet = IFX_FAILURE;

	if(NULL == pxListName){
		return IFX_FAILURE;
	}	
  xVmapiIntList.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xVmapiIntList,IFX_VMAPI_OP_DEFAULT)){

    ifx_vmapi_freeObjectList(&xVmapiIntList,IFX_VMAPI_DECT_SYSTEM); 
		return IFX_FAILURE;
  }
  pxInttbl = xVmapiIntList.pxHandsetTbl;
  for(i=0; i< (pxListName->axIntNameList[0].nEntryId-1);i++){
    __ifx_list_GetNext((void*)&pxInttbl);
		if (pxInttbl == NULL)
			break;
  }
	iHsNum=i+1;
  i = 0;
	if (pxInttbl == NULL)
		return IFX_FAILURE;

  while(pxInttbl->aucVoiceLineIdList[i] != '\0'){
     pxInttbl->aucVoiceLineIdList[i/2] = pxInttbl->aucVoiceLineIdList[i]-48;
     i = i+2;
  }
	pxInttbl->aucVoiceLineIdList[i/2] = '\0';
	switch(ucOp){

		case IFX_DECTAPP_MODIFY:
    {
        if((pxListName->axIntNameList[0].uiEditField & IFX_DECT_LAU_IL_FNAME)){
          strncpy((char8*)pxInttbl->ucEndPtName,(char8*)pxListName->axIntNameList[0].acName,15);
					pxInttbl->ucEndPtName[15]=0;
        }
				if((pxListName->axIntNameList[0].uiEditField & IFX_DECT_LAU_IL_INTERCEPTION)&& (pxListName->axIntNameList[0].ucCallIntercept !=0)){
					pxInttbl->bIntercept = pxListName->axIntNameList[0].ucCallIntercept-0x30;
				}
		}
	  break;

	  case IFX_DECTAPP_DEL:
	  {
        pxInttbl->xSubsInfo.bIsRegistered = 0;
				if (iHsNum < 7 && iHsNum > 0){
					sprintf((char8 *)pxInttbl->ucEndPtName,"Handset%d",iHsNum);
        	pxInttbl->ucEndPtName[8]='\0';
					pxInttbl->bIntercept = 0;
				}
    }
		break;
			
		default:
		   break;
	}		 
  eRet = IFX_SUCCESS;
  pxInttbl->iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,pxInttbl,0)){
    eRet = IFX_FAILURE;
  }
  ifx_vmapi_freeObjectList(&xVmapiIntList,IFX_VMAPI_DECT_SYSTEM); 
  return eRet;
}
/******************************************************************************
 *  Function Name   : IFX_CIF_SystemSet
 *  Description     : This internal Api performs edit operation on System
 *                    Settings list.
 *  Input Values    : pxSysList - pointer to System settings list
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
IFX_CIF_SystemSet(IN x_IFX_DECT_LAU_SystemSettingsList *pxSysList){

   x_IFX_VMAPI_DectSystem xVmapiPinno = {{{{""}}}};
	 e_IFX_Return eRet=IFX_SUCCESS;
   memset(&xVmapiPinno,0,sizeof(xVmapiPinno));

	 if(NULL == pxSysList){
		 return IFX_FAILURE;
	 } 
   xVmapiPinno.iid.config_owner = IFX_VOIP;
   if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xVmapiPinno,0)){
      return IFX_FAILURE;
   }
   if((pxSysList->uiEditField & IFX_DECT_LAU_SSE_NEWPIN)&&(strcmp(pxSysList->acNewPIN,""))){
			strcpy(xVmapiPinno.acAuthCode,pxSysList->acNewPIN);
      printf("Pin1 %s----pinstack----%s\n",xVmapiPinno.acAuthCode,pxSysList->acNewPIN);
   }
   if((pxSysList->uiEditField & IFX_DECT_LAU_SSE_CLKMSTR)&&(pxSysList->cClockMaster != 0)){
     xVmapiPinno.ucClkMaster=(pxSysList->cClockMaster==IFX_DECT_LAU_CLOCK_MASTER_FP)?1:0;
   }

   if((pxSysList->uiEditField & IFX_DECT_LAU_SSE_NEM)&&(pxSysList->cEmissionMode != -1)){
     xVmapiPinno.ucNoEmo=pxSysList->cEmissionMode;
   }
   if((pxSysList->uiEditField & IFX_DECT_LAU_SSE_BASERESET)&&(pxSysList->cBaseReset == IFX_DECT_LAU_BASE_RESET_YES)){//Base Reset
     xVmapiPinno.ucClkMaster = 1;/*Clk Master is FP*/
     strcpy(xVmapiPinno.acAuthCode,"0000");
   }
   if(IFX_SUCCESS != ifx_set_DectInterface(IFX_OP_MOD,&xVmapiPinno,IFX_VMAPI_OP_DEFAULT)){
      eRet=IFX_FAILURE;
   }
   ifx_vmapi_freeObjectList(&xVmapiPinno,IFX_VMAPI_DECT_SYSTEM);
   return eRet;
}
/******************************************************************************
 *  Function Name   : IFX_CIF_LineSet
 *  Description     : This internal Api performs Edit operation on Line Settings
 *                    List.
 *  Input Values    : pxLineSetList - pointer to Line Settings List
 *                    ucOp - operation to be performed
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
IFX_CIF_LineSet(IN x_IFX_DECT_LAU_LineSettingsList *pxLineSetList,IN uchar8 ucOp){

  x_IFX_VMAPI_LineCallingFeatures xVmapiLineFeatures = {{{{0}}}};
  x_IFX_VMAPI_DectSystem xVmapiDectHSet = {{{{0}}}};
  x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{0}}}};
  x_IFX_VMAPI_DectHandset *pxHStbl = NULL;
  x_IFX_VMAPI_FxoPhyIf xFXO = {{{{0}}}}; 
  int32 i = 0,j = 0,k = 0;
  int32 iVoiceLen = 0;
  int32 iIntLen = 0;
  int32 iFxoLen = 0;

	if(NULL == pxLineSetList){
    printf("\n Failure1\n");
		return IFX_FAILURE;
	}

  if(pxLineSetList->axLineEntry[0].nEntryId != IFX_VMAPI_PSTN_LINE){

  xVoiceLine.ucLineId = pxLineSetList->axLineEntry[0].nEntryId;
  xVoiceLine.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_VoiceLine(&xVoiceLine,0)){
    printf("\n Failure2\n");
		return IFX_FAILURE;
	} 	

  xVmapiLineFeatures.ucLineId =pxLineSetList->axLineEntry[0].nEntryId;
  xVmapiLineFeatures.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_LineCallingFeatures(&xVmapiLineFeatures,IFX_VMAPI_OP_DEFAULT)){
     printf("\n Failure3\n");
     return IFX_FAILURE;
  }
  if((pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_CLIR)){
    xVmapiLineFeatures.bEnableCid = (pxLineSetList->axLineEntry[0].xCLIRInfo.ucCLIRStatus == IFX_DECT_LAU_CLIR_ACTIVATE)?0:1;
  }
  if((pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_CFU)){

     if((pxLineSetList->axLineEntry[0].xCFInfoU.ucStatus == IFX_DECT_LAU_CF_ON)
         &&(!strlen((char8 *)pxLineSetList->axLineEntry[0].xCFInfoU.ucCFNum))){
         return IFX_FAILURE;
     }
     xVmapiLineFeatures.unCallFwdCfg = (pxLineSetList->axLineEntry[0].xCFInfoU.ucStatus == IFX_DECT_LAU_CF_ON)?
                                       (xVmapiLineFeatures.unCallFwdCfg | IFX_VMAPI_CALL_FWD_UNCONDITIONAL):
                                       (xVmapiLineFeatures.unCallFwdCfg & ~IFX_VMAPI_CALL_FWD_UNCONDITIONAL);
   
     if(strlen((char8 *)pxLineSetList->axLineEntry[0].xCFInfoU.ucCFNum) != 0){ 
       strcpy(xVmapiLineFeatures.xCfuAddress.acUserName,(char8 *)pxLineSetList->axLineEntry[0].xCFInfoU.ucCFNum);
       strcpy(xVmapiLineFeatures.xCfuAddress.acDisplayName,(char8 *)pxLineSetList->axLineEntry[0].xCFInfoU.ucCFNum);
       xVmapiLineFeatures.xCfuAddress.ucAddrType = IFX_VMAPI_ADDR_TYPE_TEL_NUM;

     }
  }
  if((pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_CFN)){

     if((pxLineSetList->axLineEntry[0].xCFInfoN.ucStatus == IFX_DECT_LAU_CF_ON)
         &&(!strlen((char8 *)pxLineSetList->axLineEntry[0].xCFInfoN.ucCFNum))){
         return IFX_FAILURE;
     }
     xVmapiLineFeatures.unCallFwdCfg = (pxLineSetList->axLineEntry[0].xCFInfoN.ucStatus == IFX_DECT_LAU_CF_ON)?
                                       (xVmapiLineFeatures.unCallFwdCfg | IFX_VMAPI_CALL_FWD_ON_NO_ANSWER):
                                       (xVmapiLineFeatures.unCallFwdCfg & ~IFX_VMAPI_CALL_FWD_ON_NO_ANSWER);
      
     if(strlen((char8 *)pxLineSetList->axLineEntry[0].xCFInfoN.ucCFNum) != 0){
				 {
					int32 iRingTimeOut=0;
					uchar8 ucRingCount = 2; /*Default*/ 
					IFX_MMGR_RingCadenceTimeGet(&iRingTimeOut);
					iRingTimeOut = iRingTimeOut / 1000;  //Convert msec to sec
					if(iRingTimeOut && 
						 ( (pxLineSetList->axLineEntry[0].xCFInfoN.ucNoOfSec/iRingTimeOut) > 0) )	{
						 ucRingCount = pxLineSetList->axLineEntry[0].xCFInfoN.ucNoOfSec/iRingTimeOut; 
					}
        	xVmapiLineFeatures.ucCfnaRingCount=  ucRingCount;
				}
        strcpy(xVmapiLineFeatures.xCfnaAddress.acUserName,(char8 *)pxLineSetList->axLineEntry[0].xCFInfoN.ucCFNum);
        strcpy(xVmapiLineFeatures.xCfnaAddress.acDisplayName,(char8 *)pxLineSetList->axLineEntry[0].xCFInfoN.ucCFNum);
        xVmapiLineFeatures.xCfnaAddress.ucAddrType = IFX_VMAPI_ADDR_TYPE_TEL_NUM;
     }   
  }
  if((pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_CFB)){

    if((pxLineSetList->axLineEntry[0].xCFInfoB.ucStatus == IFX_DECT_LAU_CF_ON)
       &&(!strlen((char8 *)pxLineSetList->axLineEntry[0].xCFInfoB.ucCFNum))){
       return IFX_FAILURE;
    }

    xVmapiLineFeatures.unCallFwdCfg = (pxLineSetList->axLineEntry[0].xCFInfoB.ucStatus == IFX_DECT_LAU_CF_ON)?
                                        (xVmapiLineFeatures.unCallFwdCfg | IFX_VMAPI_CALL_FWD_BUSY):
                                         (xVmapiLineFeatures.unCallFwdCfg & ~IFX_VMAPI_CALL_FWD_BUSY);
    if(strlen((char8 *)pxLineSetList->axLineEntry[0].xCFInfoB.ucCFNum) != 0){

      strcpy(xVmapiLineFeatures.xCfbAddress.acUserName,(char8 *)pxLineSetList->axLineEntry[0].xCFInfoB.ucCFNum);
      strcpy(xVmapiLineFeatures.xCfbAddress.acDisplayName,(char8 *)pxLineSetList->axLineEntry[0].xCFInfoB.ucCFNum);
      xVmapiLineFeatures.xCfbAddress.ucAddrType = IFX_VMAPI_ADDR_TYPE_TEL_NUM;
    }
  }

  if(IFX_VMAPI_SUCCESS != ifx_set_LineCallingFeatures(IFX_OP_MOD,&xVmapiLineFeatures,IFX_VMAPI_OP_DEFAULT)){
     ifx_vmapi_freeObjectList(&xVmapiLineFeatures, IFX_VMAPI_VL_CALLFEAT);
     return IFX_FAILURE;
  }
  }else{//PSTN

    xFXO.xVoiceServPhyIf.ucInterfaceId = 3;                                                                                                                             
    xFXO.iid.config_owner = IFX_VOIP;                                                                                                                                    
    if(IFX_VMAPI_SUCCESS != ifx_get_FxoPhyInterface(&xFXO,IFX_VMAPI_OP_DEFAULT)){
      printf("\n Failure8\n");
      return IFX_FAILURE;
    }                                               
   }
  if((pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_ATCHPP)){
     xVmapiDectHSet.iid.config_owner = IFX_VOIP;
     if(IFX_VMAPI_SUCCESS == ifx_get_DectInterface(&xVmapiDectHSet,IFX_VMAPI_OP_DEFAULT)){
       pxHStbl = xVmapiDectHSet.pxHandsetTbl;
       for(i=0;i<IFX_DECT_LAU_MAX_ATTACHED_PP;i++){
        if(pxHStbl->xSubsInfo.bIsRegistered){
          //printf("\n Get VoiceLineIdList For HS=%s\n",pxHStbl->aucVoiceLineIdList);
          for(j=0;pxHStbl->aucVoiceLineIdList[j] != '\0';j+=2){
              pxHStbl->aucVoiceLineIdList[j/2] = pxHStbl->aucVoiceLineIdList[j]-48;
          }
          pxHStbl->aucVoiceLineIdList[j/2] = '\0';
					j=0;
          while(pxHStbl->aucVoiceLineIdList[j] != '\0'){
            if(pxHStbl->aucVoiceLineIdList[j] == pxLineSetList->axLineEntry[0].nEntryId){
               break;
            }
            j++;
					}
          iVoiceLen = strlen(((char8 *)pxHStbl->aucVoiceLineIdList));
          iIntLen = strlen(((char8 *)xVoiceLine.ucAssocVoiceInterface));
          iFxoLen = strlen((char8 *)xFXO.ucInterfaceIdList);
          /*Attached Handsets for a Line is editted.This implies modification of VoiceLineId list for the corresponding handset.Since there was no 
            entry previously,add the current line to the VoiceLineIdList for the handset and make it the default line.*/
          if(pxHStbl->aucVoiceLineIdList[j] == '\0'){
						if(pxLineSetList->axLineEntry[0].xAttachedPP.acAttachedPP[i]){
              //k=0;
              if(IFX_VMAPI_PSTN_LINE != pxLineSetList->axLineEntry[0].nEntryId){
 
							  if (iIntLen < (2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES)){
                	xVoiceLine.ucAssocVoiceInterface[iIntLen] = i+4;
                	xVoiceLine.ucAssocVoiceInterface[iIntLen+1] = '\0';
								}
                //printf("\n AssocVoiceInterface for VoiceLine=%s\n",xVoiceLine.ucAssocVoiceInterface);
              }else if (iFxoLen < (2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES)){
                xFXO.ucInterfaceIdList[iFxoLen] = i+4;
                xFXO.ucInterfaceIdList[iFxoLen+1] = '\0';
                //printf("\n InterfaceIdList For PSTN=%s\n",xFXO.ucInterfaceIdList);
               } 
              pxHStbl->ucVoiceLineId = pxLineSetList->axLineEntry[0].nEntryId;
							if (iVoiceLen < (2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES)){
              	pxHStbl->aucVoiceLineIdList[iVoiceLen] = pxLineSetList->axLineEntry[0].nEntryId;
              	pxHStbl->aucVoiceLineIdList[iVoiceLen+1] = '\0';
							}
              //printf("\n VoiceLineIdList For HS=%s\n",pxHStbl->aucVoiceLineIdList);
					  }	
				  }else{ 
            /*Case where the handset is already present in the attached handsets lists for the line.Make it the default line for the handset.*/
						if(pxLineSetList->axLineEntry[0].xAttachedPP.acAttachedPP[i]){
              pxHStbl->ucVoiceLineId = pxLineSetList->axLineEntry[0].nEntryId;
            }else{
               /*Case where the handset is detached from the current line.Update Assoc Interfaces for the current line and 
                 VoiceLineId List and default line for the handset.*/
	  					 memmove(&pxHStbl->aucVoiceLineIdList[j],&pxHStbl->aucVoiceLineIdList[j+1],iVoiceLen-j-1);
							 if (iVoiceLen > 0)
               	 pxHStbl->aucVoiceLineIdList[iVoiceLen-1] = '\0';
               if(pxHStbl->ucVoiceLineId == pxLineSetList->axLineEntry[0].nEntryId){//Change default line if current line is default line.
			  				 pxHStbl->ucVoiceLineId = pxHStbl->aucVoiceLineIdList[0];
				  		 }	 
               //printf("\n VoiceLineIdList For HS=%s\n",pxHStbl->aucVoiceLineIdList);
					     k=0;
               if(IFX_VMAPI_PSTN_LINE != pxLineSetList->axLineEntry[0].nEntryId){
                 while(xVoiceLine.ucAssocVoiceInterface[k] != i+4){
                  k++;
			           }
					       memmove(&xVoiceLine.ucAssocVoiceInterface[k],&xVoiceLine.ucAssocVoiceInterface[k+1],iIntLen-k-1);
							 	 if (iIntLen > 0)
                 	 xVoiceLine.ucAssocVoiceInterface[iIntLen-1] = '\0';
                 //printf("\n AssocVoiceInterface for VoiceLine=%s\n",xVoiceLine.ucAssocVoiceInterface);
               }else{//PSTN Line
                 while(xFXO.ucInterfaceIdList[k] != i+4){
                  k++;
			           }
					       memmove(&xFXO.ucInterfaceIdList[k],&xFXO.ucInterfaceIdList[k+1],iFxoLen-k-1);
							 	 if (iFxoLen > 0)
                 	 xFXO.ucInterfaceIdList[iFxoLen-1] = '\0';
                 //printf("\n InterfaceIdList For PSTN=%s\n",xFXO.ucInterfaceIdList);
                }   
						 }	
				   }		
           pxHStbl->iid.config_owner = IFX_VOIP;
           if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,pxHStbl,0)){
             printf("\n Failure9\n");
						 return IFX_FAILURE;
					 }	 
          }
           __ifx_list_GetNext((void*)&pxHStbl);
					if (pxHStbl == NULL)
						break;
		   }         
     }         
     ifx_vmapi_freeObjectList(&xVmapiDectHSet,IFX_VMAPI_DECT_SYSTEM);
	}
  if(IFX_VMAPI_PSTN_LINE != pxLineSetList->axLineEntry[0].nEntryId){
  	if((pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_LINENAME)&&
				(pxLineSetList->axLineEntry[0].acLineName[0] != '\0')){
			memcpy(xVoiceLine.acName,pxLineSetList->axLineEntry[0].acLineName,IFX_DECT_LAU_MAX_LINE_NAME_LEN);
			
			xVoiceLine.acName[IFX_DECT_LAU_MAX_LINE_NAME_LEN-1] = '\0';
		}
  	if(pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_CALLMODE)
			xVoiceLine.ucLineMode = (pxLineSetList->axLineEntry[0].ucCallMode == IFX_DECT_LAU_CALL_MODE_MULTIPLE) ? 1:0;
  	if(pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_INTR)
			xVoiceLine.ucIntrusion = pxLineSetList->axLineEntry[0].ucCallIntrusion-0x30;
    if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,0)){
      printf("\n Failure10\n");
		  return IFX_FAILURE;
	  }
  }
	else{//PSTN Line
  	 if((pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_LINENAME)&&
				(pxLineSetList->axLineEntry[0].acLineName[0] != '\0')){
			memcpy(xFXO.acName,pxLineSetList->axLineEntry[0].acLineName,IFX_DECT_LAU_MAX_LINE_NAME_LEN);
			xFXO.acName[IFX_DECT_LAU_MAX_LINE_NAME_LEN-1]='\0';
		 }
  	if(pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_CALLMODE)
			xFXO.ucLineMode = (pxLineSetList->axLineEntry[0].ucCallMode == IFX_DECT_LAU_CALL_MODE_MULTIPLE) ? 1:0;
  	if(pxLineSetList->axLineEntry[0].uiEditField & IFX_DECT_LAU_LSE_INTR)
			xFXO.ucIntrusion = pxLineSetList->axLineEntry[0].ucCallIntrusion-0x30;
   	 if(IFX_VMAPI_SUCCESS != ifx_set_FxoPhyInterface(IFX_OP_MOD,&xFXO,0)){
       printf("\n Failure11\n");
       return IFX_FAILURE;
   }                            
  }
  return IFX_SUCCESS;
}
#endif
/******************************************************************************
 *  Function Name   : GetMatchingContactEntry
 *  Description     : Finds the matching VMPAI contact entry based on Line and Entry Id
 *  Input Values    : Line Id 
 *                    Entry Id
 *  Output Values   : VMPAI Contact List Entyr
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/

e_IFX_Return 
IFX_CIF_GetMatchingContactEntry(IN uchar8 ucLineId, 
 	 														  IN uint16 nEntryId,
								 								OUT  x_IFX_VMAPI_ContactListEntry *pxMatchingEntry)
{
	e_IFX_Return eRet = IFX_FAILURE;
  x_IFX_VMAPI_ContactList xVmapiContacts;
	if(ucLineId == 0 || nEntryId == 0) {
		printf("<GetMatchingContactEntry> Invalid IN Params\n");
		return eRet;
	}
	memset(&xVmapiContacts,0,sizeof(xVmapiContacts));
	xVmapiContacts.iid.config_owner = IFX_VOIP;
	xVmapiContacts.ucLineId = ucLineId;

	if(IFX_VMAPI_SUCCESS ==
     ifx_get_ContactList (&xVmapiContacts,IFX_VMAPI_OP_DEFAULT)){
			x_IFX_VMAPI_ContactListEntry *pxTemp= xVmapiContacts.pxContactEntries;
			while(pxTemp != NULL){
				if(nEntryId == pxTemp->uiEntryId){
					memcpy(pxMatchingEntry,pxTemp,sizeof(x_IFX_VMAPI_ContactListEntry));
					eRet= IFX_SUCCESS;
					printf("<GetMatchingContactEntry>Match Found\n");
					break;
			}
			__ifx_list_GetNext((void *)&pxTemp);
		} 
	ifx_vmapi_freeObjectList(&xVmapiContacts, IFX_VMAPI_VS_CONTACT_LIST);
	} 
  return eRet;
}

/******************************************************************************
 *  Function Name   : GetMatchingCommonContactEntry
 *  Description     : Finds the matching VMPAI contact entry based on Line and Entry Id
 *  Input Values    : 
 *                    Entry Id
 *  Output Values   : VMPAI Contact List Entyr
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/

e_IFX_Return 
IFX_CIF_GetMatchingCommonContactEntry(
 	 														  IN uint16 nEntryId,
								 								OUT  x_IFX_VMAPI_ContactListEntry *pxMatchingEntry)
{
	e_IFX_Return eRet = IFX_FAILURE;
  x_IFX_VMAPI_ContactList xVmapiContacts;
	if(nEntryId == 0) {
		printf("<GetMatchingContactEntry> Invalid IN Params\n");
		return eRet;
	}
	memset(&xVmapiContacts,0,sizeof(xVmapiContacts));
	xVmapiContacts.iid.config_owner = IFX_VOIP;

	if(IFX_VMAPI_SUCCESS ==
     ifx_get_CommonContactList (&xVmapiContacts,IFX_VMAPI_OP_DEFAULT)){
			x_IFX_VMAPI_ContactListEntry *pxTemp= xVmapiContacts.pxContactEntries;
			while(pxTemp != NULL){
				if(nEntryId == pxTemp->uiEntryId){
					memcpy(pxMatchingEntry,pxTemp,sizeof(x_IFX_VMAPI_ContactListEntry));
					eRet= IFX_SUCCESS;
					printf("<GetMatchingCommonContactEntry>Match Found\n");
					break;
			}
			__ifx_list_GetNext((void *)&pxTemp);
		} 
	ifx_vmapi_freeObjectList(&xVmapiContacts, IFX_VMAPI_VS_CONTACT_LIST);
	} 
  return eRet;
}


/******************************************************************************
 *  Function Name   : IFX_CIF_GetContactListInfoFromVmapiObj
 *  Description     : This API reads VMAPI Contact List structure and fills
											Line Id and Number of entires as out params 
 *  Input Values    : 
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
IFX_CIF_GetContactListInfoFromVmapiObj(IN void *pxNew,
																			 OUT uchar8 *pucLineId,
																			 OUT uchar8 *pucNoOfEntries)
{
	x_IFX_VMAPI_ContactList *pxContactList = (x_IFX_VMAPI_ContactList*)pxNew;
	if(!pxContactList || !pucNoOfEntries || !pucLineId) {
			return IFX_FAILURE;
	}
	*pucLineId = pxContactList->ucLineId;
	*pucNoOfEntries = pxContactList->ucNoOfEntries;
	return IFX_SUCCESS;

}

/******************************************************************************
 *  Function Name   : IFX_CIF_ContactListSet
 *  Description     : This internal Api performs Add/Modify/Delete op on Contact
                      List. 
 *  Input Values    : pxContactList - pointer to Contact list structure
 *                    ucOp - Operation Add/Modify/Delete
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
#ifdef DECT_SUPPORT
e_IFX_Return
IFX_CIF_ContactListSet(IN x_IFX_DECT_LAU_ContactListEntry *pxDectContact,
											 IN uchar8 *pucLineIdList,
                       IN uchar8 ucOp)
{
		x_IFX_VMAPI_ContactListEntry xVmapiContact;
		uint32 uiOperation=IFX_OP_MOD; /*Init to Modify*/

	 if(pxDectContact == NULL && ucOp != IFX_DECTAPP_DEL_ALL) {
			printf("<CfgIf_SetContact> Invalid Input Params\n");
			return IFX_FAILURE;
   }
	 memset(&xVmapiContact,0,sizeof(xVmapiContact));

	 if( ucOp == IFX_DECTAPP_DEL || ucOp == IFX_DECTAPP_MODIFY) {
				printf("<CfgIfSet> Mod/Del Rcvd Line Id = %d EntryId = %d\n",
						pxDectContact->ucLineId,pxDectContact->nEntryId);
				if(IFX_FAILURE == IFX_CIF_GetMatchingContactEntry(pxDectContact->ucLineId,
													pxDectContact->nEntryId,&xVmapiContact)){
           printf("<CfgIf_SetContact>Modify/Del:No matching entry found\n");
					return IFX_FAILURE;
        }
		}
		xVmapiContact.iid.config_owner = IFX_VOIP;
	
		switch(ucOp) {

    case IFX_DECTAPP_DEL:
		{
			printf("<CfgIf_ContactSet> Delete\n");
     	if(ifx_set_ContactListEntry(IFX_OP_DEL,&xVmapiContact,0) != IFX_SUCCESS){
          printf("<CfgIf_SetContact>Delete Failed\n");
				 return IFX_FAILURE;
			}
     }
		 break;

  	case IFX_DECTAPP_DEL_ALL: 
		printf("<CfgIf_ContactSet> Delete the entire List!!!\n");
		{
			int i=0;
			if(pucLineIdList == NULL) {
				printf("<CfgIf_ContactSet> Line List is NULL\n");
				return IFX_FAILURE;
			}

			while(pucLineIdList[i] != '\0'){
					if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_CONTACT_LIST,pucLineIdList[i]) != IFX_VMAPI_SUCCESS)
							return IFX_FAILURE;
			 i++;
		}
			//Delete the common-contactList entries.
			if(IFX_SUCCESS != IFX_CIF_CommonContactListSet(NULL,IFX_DECTAPP_DEL_ALL)){
					printf("<CfgIf_CommonContactListSet>Delete-All Failed\n");
					return IFX_FAILURE;
			}

		}
		break; 

    case IFX_DECTAPP_ADD:
		{
			printf("<CfgIf_ContactSet> Add Operation\n");
			uiOperation = IFX_OP_ADD;
			xVmapiContact.uiEntryId = 0;
			xVmapiContact.ucLineId = pxDectContact->ucLineId;
			/*strncpy(xVmapiContact.xAddress.acDisplayName,pxDectContact->acLastName,
							sizeof(xVmapiContact.xAddress.acDisplayName)-1);*/
		}
    										/*Continue to Modify*/ 
		case IFX_DECTAPP_MODIFY:
		{
			  strncpy(xVmapiContact.xAddress.acUserFirstName,pxDectContact->acFirstName,
							sizeof(xVmapiContact.xAddress.acUserFirstName)-1);
			  strncpy(xVmapiContact.xAddress.acUserLastName,pxDectContact->acLastName,
							sizeof(xVmapiContact.xAddress.acUserLastName)-1);

			  strncpy(xVmapiContact.xAddress.acContactNum,
							pxDectContact->xNumber.xNum[0].acNumber,
							sizeof(xVmapiContact.xAddress.acContactNum)-1);
			  xVmapiContact.xAddress.cContactType = (pxDectContact->xNumber.xNum[0].ctype == 0)?IFX_DECT_LAU_CONTACT_WORK:pxDectContact->xNumber.xNum[0].ctype;
        
        if(pxDectContact->xNumber.ucNoOfContactNumbers > 1){
          if(!((pxDectContact->xNumber.xNum[0].acNumber[0] == '\0')&&(pxDectContact->xNumber.xNum[1].acNumber[0] == '\0'))){ 
			      strncpy(xVmapiContact.xAddress.acContactNumTwo,
							pxDectContact->xNumber.xNum[1].acNumber,
							sizeof(xVmapiContact.xAddress.acContactNumTwo)-1);
			      xVmapiContact.xAddress.cContactTypeTwo = (pxDectContact->xNumber.xNum[1].ctype == 0)?IFX_DECT_LAU_CONTACT_MOBILE:pxDectContact->xNumber.xNum[1].ctype;
          }
        }
			printf("<CfgIf_ContactSet>BeforeSet Line= %d Entry Id= %d \n",xVmapiContact.ucLineId,
							xVmapiContact.uiEntryId);
      
			if(IFX_VMAPI_SUCCESS != ifx_set_ContactListEntry(uiOperation,&xVmapiContact,0)) {
					printf("<CfgIf_ContactSet>Add/Modify Failed\n");
					return IFX_FAILURE;
			}
			if(pxDectContact->nEntryId == 0) { /*It was Add Op*/
						pxDectContact->nEntryId = xVmapiContact.uiEntryId;
			}
		}
     break;

     default:
       printf("\n Invalid Op!!\n");
			 return IFX_FAILURE;
   }
   printf("<CfgIf_ContactSet>Returning Success\n");
  /* Write-the changes to the Flash */
	system ("/etc/rc.d/backup"); 
	return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_CommonContactListSet
 *  Description     : This internal Api performs Add/Modify/Delete op on Contact
                      List. 
 *  Input Values    : pxContactList - pointer to Contact list structure
 *                    ucOp - Operation Add/Modify/Delete
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
IFX_CIF_CommonContactListSet(IN x_IFX_DECT_LAU_ContactListEntry *pxDectContact,
                       IN uchar8 ucOp)
{
		x_IFX_VMAPI_ContactListEntry xVmapiContact;
		uint32 uiOperation=IFX_OP_MOD; /*Init to Modify*/

	 if(pxDectContact == NULL && ucOp != IFX_DECTAPP_DEL_ALL) {
			printf("<CfgIf_SetContact> Invalid Input Params\n");
			return IFX_FAILURE;
   }
	 memset(&xVmapiContact,0,sizeof(xVmapiContact));

	 if( ucOp == IFX_DECTAPP_DEL || ucOp == IFX_DECTAPP_MODIFY) {
				printf("<CfgIfSet> Mod/Del Common-Contact EntryId = %d\n",
						pxDectContact->nEntryId);
				if(IFX_FAILURE == IFX_CIF_GetMatchingCommonContactEntry(
													pxDectContact->nEntryId,&xVmapiContact)){
           printf("<CfgIf_SetContact>Modify/Del:No matching entry found\n");
					return IFX_FAILURE;
        }
		}
		xVmapiContact.iid.config_owner = IFX_VOIP;
	
		switch(ucOp) {

    case IFX_DECTAPP_DEL:
		{
			printf("<CfgIf_ContactSet> Delete\n");
     	if(ifx_set_CommonContactListEntry(IFX_OP_DEL,&xVmapiContact,0) != IFX_SUCCESS){
          printf("<CfgIf_SetContact>Delete Failed\n");
				 return IFX_FAILURE;
			}
     }
		 break;

  	case IFX_DECTAPP_DEL_ALL: 
		{
		if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_COMMON_CONTACT_LIST,0/*No-LineId for commonContactlist*/) != IFX_VMAPI_SUCCESS)
        return IFX_FAILURE;

		}
		break; 

    case IFX_DECTAPP_ADD:
		{
			printf("<CfgIf_ContactSet> Add Operation\n");
			uiOperation = IFX_OP_ADD;
			xVmapiContact.uiEntryId = 0;
			/*strncpy(xVmapiContact.xAddress.acDisplayName,pxDectContact->acLastName,
							sizeof(xVmapiContact.xAddress.acDisplayName)-1);*/
		}
    										/*Continue to Modify*/ 
		case IFX_DECTAPP_MODIFY:
		{
			  strncpy(xVmapiContact.xAddress.acUserFirstName,pxDectContact->acFirstName,
							sizeof(xVmapiContact.xAddress.acUserFirstName)-1);
			  strncpy(xVmapiContact.xAddress.acUserLastName,pxDectContact->acLastName,
							sizeof(xVmapiContact.xAddress.acUserLastName)-1);

			  strncpy(xVmapiContact.xAddress.acContactNum,
							pxDectContact->xNumber.xNum[0].acNumber,
							sizeof(xVmapiContact.xAddress.acContactNum)-1);
			  xVmapiContact.xAddress.cContactType = (pxDectContact->xNumber.xNum[0].ctype == 0)?IFX_DECT_LAU_CONTACT_WORK:pxDectContact->xNumber.xNum[0].ctype;
			  xVmapiContact.ucLineId = pxDectContact->ucLineId;
        
        if(pxDectContact->xNumber.ucNoOfContactNumbers > 1){
          if(!((pxDectContact->xNumber.xNum[0].acNumber[0] == '\0')&&(pxDectContact->xNumber.xNum[1].acNumber[0] == '\0'))){ 
			      strncpy(xVmapiContact.xAddress.acContactNumTwo,
							pxDectContact->xNumber.xNum[1].acNumber,
							sizeof(xVmapiContact.xAddress.acContactNumTwo)-1);
			      xVmapiContact.xAddress.cContactTypeTwo = (pxDectContact->xNumber.xNum[1].ctype == 0)?IFX_DECT_LAU_CONTACT_MOBILE:pxDectContact->xNumber.xNum[1].ctype;
          }
        }
			printf("<CfgIf_CommonContactSet>BeforeSet  Entry Id= %d \n",
							xVmapiContact.uiEntryId);
      
			if(IFX_VMAPI_SUCCESS != ifx_set_CommonContactListEntry(uiOperation,&xVmapiContact,0)) {
					printf("<CfgIf_CommonContactSet>Add/Modify Failed\n");
					return IFX_FAILURE;
			}
			if(pxDectContact->nEntryId == 0) { /*It was Add Op*/
						pxDectContact->nEntryId = xVmapiContact.uiEntryId;
			}
		}
     break;

     default:
       printf("\n Invalid Op!!\n");
			 return IFX_FAILURE;
   }
   printf("<CfgIf_CommonContactSet>Returning Success\n");
  /* Write-the changes to the Flash */
	system ("/etc/rc.d/backup"); 
   return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_CIF_MissedCallListSet
 *  Description     : This internal Api performs edit/delete all operation on Missed
 *                    Call List.
 *  Input Values    : pxMissedCallList - pointer to Missed call list structure
 *                    ucOp - Operation to be performed,here modify/delete list
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return 
  IFX_CIF_MissedCallListSet(IN uchar8 ucLineId, IN x_IFX_DECT_LAU_MissedCallList *pxMissedCallList,
                            IN uchar8 ucOp){

  x_IFX_VMAPI_CallRegister xVmapiCallReg = {{{{""}}}};
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
  //x_IFX_VMAPI_CallRegEntry *pxTempCallRegEntry = NULL;
  e_IFX_Return eRet = IFX_FAILURE;
  int32 i = 0;
  int32 iFlag = 0;
  uchar8 ucIndex = 0;

  memset(&xVmapiCallReg,0,sizeof(xVmapiCallReg));

  if(ucLineId > 0){
    xVmapiCallReg.ucLineId = ucLineId;
  }else{
    return IFX_FAILURE;
  }
  if(NULL != pxMissedCallList) {
	xVmapiCallReg.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_MissCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){

    ifx_vmapi_freeObjectList(&xVmapiCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);
    return IFX_FAILURE;
  }  
}
  switch(ucOp){

    case IFX_DECTAPP_MODIFY:
    {
        if(NULL != pxMissedCallList){
 
          for(i=0;i<pxMissedCallList->cNoOfEntries;i++){

             iFlag = 0; 
             pxCallRegEntry = xVmapiCallReg.pxCallRegEntries;
             while(pxCallRegEntry != NULL){

               if(pxCallRegEntry->uiEntryId == pxMissedCallList->axMissedCallList[i].nEntryId){
                 
                 pxCallRegEntry->bStatus = pxMissedCallList->axMissedCallList[i].bNew;
                 pxCallRegEntry->iid.config_owner = IFX_VOIP;
                 if(vucMissCallReadStatusNtfyFlag == 1){
                   if(IFX_VMAPI_SUCCESS != ifx_set_MissCallRegEntry(IFX_OP_MOD,pxCallRegEntry,IFX_VMAPI_OP_DEFAULT)){
                     break;
		   }
                 }else{
                   if(IFX_VMAPI_SUCCESS != ifx_set_MissCallRegEntry(IFX_OP_MOD,pxCallRegEntry,IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)){
                     break;
		   }
                 }
		 iFlag = 1;
                 eRet = IFX_SUCCESS;
               }
               __ifx_list_GetNext((void*)&pxCallRegEntry);
             }
             if(iFlag == 0){
               eRet = IFX_FAILURE;
               break;
             }
          }
        }    
    }
    break;

    case IFX_DECTAPP_DEL:
    {
        if(NULL == pxMissedCallList){
					if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_MISSCALL_REGISTER,ucLineId) != IFX_VMAPI_SUCCESS)
							eRet = IFX_FAILURE;
					else
							eRet = IFX_SUCCESS;

   }else{
           pxCallRegEntry = xVmapiCallReg.pxCallRegEntries;
           while(pxCallRegEntry != NULL){
             ucIndex++;
             if(pxCallRegEntry->uiEntryId == pxMissedCallList->axMissedCallList[0].nEntryId){
               break;
             }
             __ifx_list_GetNext((void *)&pxCallRegEntry);
           } 
           if(pxCallRegEntry != NULL){
             pxCallRegEntry->ucIndex = ucIndex;
             pxCallRegEntry->iid.config_owner = IFX_VOIP;
             if(IFX_VMAPI_SUCCESS == ifx_set_MissCallRegEntry(IFX_OP_DEL,pxCallRegEntry,IFX_VMAPI_OP_DEFAULT)){ 
               eRet = IFX_SUCCESS;
             }
           }
         }
    }
    break;

    default:
      printf("\n Invalid Op!!\n");
			return IFX_FAILURE;
  }
  ifx_vmapi_freeObjectList(&xVmapiCallReg,IFX_VMAPI_VS_MISSCALL_REGISTER);
  /* Write-the changes to the Flash */
	system ("/etc/rc.d/backup"); 
  return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_OutgoingCallListSet
 *  Description     : This internal Api performs delete all operation on Outgoing
 *                    Call List.
 *  Input Values    : pxOutgoingCallList - pointer to Outgoing call list structure
 *                    ucOp - Operation to be performed,here delete list
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return 
  IFX_CIF_OutgoingCallListSet(IN uchar8 ucLineId, IN x_IFX_DECT_LAU_OutgoingCallList *pxOutgoingCallList,
                              IN uchar8 ucOp){

  x_IFX_VMAPI_CallRegister xVmapiCallReg = {{{{""}}}};
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
  e_IFX_Return eRet = IFX_FAILURE;
  uchar8 ucIndex = 0;
  switch(ucOp){
  
   case IFX_DECTAPP_DEL:
   {
       if(NULL == pxOutgoingCallList){
				 if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_DIALCALL_REGISTER,ucLineId) != IFX_VMAPI_SUCCESS)
						 eRet = IFX_FAILURE;
				else
							eRet = IFX_SUCCESS;
       }else{

  memset(&xVmapiCallReg,0,sizeof(xVmapiCallReg));
  if(ucLineId > 0){
    xVmapiCallReg.ucLineId = ucLineId;
  }else{
    return IFX_FAILURE;
  }
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_DialCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){
    ifx_vmapi_freeObjectList(&xVmapiCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);
    return IFX_FAILURE;
  }
           pxCallRegEntry = xVmapiCallReg.pxCallRegEntries;
           while(pxCallRegEntry != NULL){

             ucIndex++;
             if(pxCallRegEntry->uiEntryId == pxOutgoingCallList->axOutgoingCallList[0].nEntryId){
               break;
             }
             __ifx_list_GetNext((void *)&pxCallRegEntry);
           } 
           if(pxCallRegEntry != NULL){

             pxCallRegEntry->ucIndex = ucIndex;
             pxCallRegEntry->iid.config_owner = IFX_VOIP;
             if(IFX_VMAPI_SUCCESS == ifx_set_DialCallRegEntry(IFX_OP_DEL,pxCallRegEntry,IFX_VMAPI_OP_DEFAULT)){ 
                 eRet = IFX_SUCCESS;  

             }
           }
    				ifx_vmapi_freeObjectList(&xVmapiCallReg,IFX_VMAPI_VS_DIALCALL_REGISTER);
         }
   }
   break;
   
   default:
       printf("\n Invalid Op\n");
			return IFX_FAILURE;
  } 
  
  /* Write-the changes to the Flash */
	system ("/etc/rc.d/backup"); 
return eRet;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_IncomingCallListSet
 *  Description     : This internal Api performs delete all operation on Incoming
 *                    Call List
 *  Input Values    : pxIncomingCallList - pointer to Incoming call list structure
 *                    ucOp - Operation to be performed,here delete list
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return 
  IFX_CIF_IncomingCallListSet(IN uchar8 ucLineId, IN x_IFX_DECT_LAU_IncomingCallList *pxIncomingCallList,uchar8 ucOp){

  x_IFX_VMAPI_CallRegister xVmapiCallReg = {{{{""}}}};
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
  //x_IFX_VMAPI_CallRegEntry *pxTempCallRegEntry = NULL;
  e_IFX_Return eRet = IFX_FAILURE;
  uchar8 ucIndex = 0;

  switch(ucOp){
 
    case IFX_DECTAPP_DEL:
    {
        if(pxIncomingCallList == NULL){
				if ( ifx_delete_All_ListEntries(IFX_VMAPI_VS_RECVCALL_REGISTER,ucLineId) != IFX_VMAPI_SUCCESS)
						eRet=IFX_FAILURE;
				else
						 eRet = IFX_SUCCESS;
				
        }else{
  						memset(&xVmapiCallReg,0,sizeof(xVmapiCallReg));
						  if(ucLineId > 0){
							    xVmapiCallReg.ucLineId = ucLineId;
					  }else{
							    return IFX_FAILURE;
						  }
						  xVmapiCallReg.iid.config_owner = IFX_VOIP;
						  if(IFX_VMAPI_SUCCESS != ifx_get_RecvCallReg(&xVmapiCallReg,IFX_VMAPI_OP_DEFAULT)){
    
						    ifx_vmapi_freeObjectList(&xVmapiCallReg,IFX_VMAPI_VS_RECVCALL_REGISTER);
							    return IFX_FAILURE;
							  }

           pxCallRegEntry = xVmapiCallReg.pxCallRegEntries;
           while(pxCallRegEntry != NULL){

             ucIndex++;
             if(pxCallRegEntry->uiEntryId == pxIncomingCallList->axIncomingCallList[0].nEntryId){
               break;
             }
             __ifx_list_GetNext((void *)&pxCallRegEntry);
           } 
           if(pxCallRegEntry != NULL){
             pxCallRegEntry->ucIndex = ucIndex;
             pxCallRegEntry->iid.config_owner = IFX_VOIP;
             if(IFX_VMAPI_SUCCESS == ifx_set_RecvCallRegEntry(IFX_OP_DEL,pxCallRegEntry,IFX_VMAPI_OP_DEFAULT)){ 
                 eRet = IFX_SUCCESS;  

             }
           }
					ifx_vmapi_freeObjectList(&xVmapiCallReg,IFX_VMAPI_VS_RECVCALL_REGISTER);
         } 
    }
    break;
   
    default:
        printf("\n Invalid Op\n");
				return IFX_FAILURE;
  } 
  /* Write-the changes to the Flash */
	system ("/etc/rc.d/backup"); 
  return eRet;
}
e_IFX_Return IFX_CIF_StoreXram(IN uchar8 *pCont){
		x_IFX_VMAPI_DectXRAM xXram={{{{0}}}};
    xXram.ucByte1 = pCont[0];
    xXram.ucByte2 = pCont[1];
    memcpy(&xXram.ucByte3,&pCont[2],10);

        if(IFX_CIF_StoreValuesFromModem(IFX_VMAPI_XRAM_TEST,&xXram)==IFX_SUCCESS)
					return IFX_SUCCESS;
				else
					return IFX_FAILURE;
}
/******************************************************************************
 *  Function Name   : IFX_CIF_CLIPInt
 *  Description     : This internal Api fetches TerminalId from EndPtId
                      (1-6) for Dect Handset,(7-8) for FXS.
 *  Input Values    : pzCallerNumber--EndPtId 
 *                   
 *  Output Values   : pzModCallerNumber- Modified CallerNumber
 *  Return Value    : None
 ****************************************************************************/
void
  IFX_CIF_CLIPInt(IN char8 *pzCallerNumber,OUT char8 *pzModCallerNumber){
   uint16 i=0;
   x_IFX_VMAPI_DectSystem xVmapiDectSys = {{{{""}}}};
   x_IFX_VMAPI_DectHandset *pxHS = NULL;
   memset(&xVmapiDectSys,0,sizeof(xVmapiDectSys));
   xVmapiDectSys.iid.config_owner = IFX_VOIP;
    if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xVmapiDectSys,IFX_VMAPI_OP_DEFAULT)){
      ifx_vmapi_freeObjectList(&xVmapiDectSys,IFX_VMAPI_DECT_SYSTEM);
    }
    pxHS = xVmapiDectSys.pxHandsetTbl;
    while(pxHS != NULL){
      if(strcmp(pzCallerNumber,(char8 *)pxHS->ucEndPtId) == 0){
        //memset(pzModCallerNumber,0,sizeof(pzModCallerNumber));
        pzModCallerNumber[0] = i+1;
        if(sizeof(pzCallerNumber) > 1)
        pzModCallerNumber[1] = '\0';
    	 ifx_vmapi_freeObjectList(&xVmapiDectSys,IFX_VMAPI_DECT_SYSTEM);
        break;  
       }
       i++;
       __ifx_list_GetNext((void*)&pxHS);
    }
    	ifx_vmapi_freeObjectList(&xVmapiDectSys,IFX_VMAPI_DECT_SYSTEM);
    x_IFX_VMAPI_FxsPhyIf xFXS;
  		memset(&xFXS,0,sizeof(xFXS));
			for(i=1;i<=2;i++){
  			xFXS.xVoiceServPhyIf.ucInterfaceId = i;
  			xFXS.iid.config_owner = IFX_VOIP;
  			if(IFX_VMAPI_SUCCESS != ifx_get_FxsPhyInterface(&xFXS,0))
  				{
  				}
				 
  			if(strcmp((char8 *)xFXS.ucEndPtId,pzCallerNumber) == 0){
        //memset(pzModCallerNumber,0,sizeof(pzModCallerNumber));
        pzModCallerNumber[0] = i+6;
        if(sizeof(pzCallerNumber) > 1)
        pzModCallerNumber[1] = '\0';
    	 ifx_vmapi_freeObjectList(&xFXS,IFX_VMAPI_DECT_SYSTEM);
        break;  
					}
			}

}
/******************************************************************************
 *  Function Name   : IFX_CIF_CNIPGet
 *  Description     : This internal Api fetches Handset Name/Contact List Name 
 *                    to be copied into CNIP.
 *  Input Values    : isInternal-whether the call is Internal/External
 *                    pzCallerNumber-Pointer to Caller Number
 *                   
 *  Output Values   : pzCallerName- Pointer to Caller Name
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 ****************************************************************************/
e_IFX_Return
  IFX_CIF_CNIPGet(IN boolean isInternal,IN uchar8 ucLineId,IN char8 *pzCallerNumber,IN OUT char8 *pzCallerName){
   uint16 i=0;
   /* Special case of Star Dialing */  
   if((isInternal) && (!(strcmp(pzCallerNumber,"*"))))
   {
     strcpy(pzCallerName,"All Handsets");
     return IFX_SUCCESS;
   }  
   if(isInternal){
    x_IFX_VMAPI_DectHandset xVmapiDectHs;
    memset(&xVmapiDectHs,0,sizeof(xVmapiDectHs));
    xVmapiDectHs.xVoiceServPhyIf.ucInterfaceId = atoi(pzCallerNumber)+3;
    if(xVmapiDectHs.xVoiceServPhyIf.ucInterfaceId > 3 && xVmapiDectHs.xVoiceServPhyIf.ucInterfaceId < 10){
      xVmapiDectHs.iid.config_owner = IFX_VOIP;
      if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xVmapiDectHs,0)){
        return IFX_FAILURE;
      }
      //memset(pzCallerName,0,sizeof(pzCallerName));
      memcpy(pzCallerName,xVmapiDectHs.ucEndPtName,strlen((char8 *)xVmapiDectHs.ucEndPtName));
		  pzCallerName[strlen((char8 *)xVmapiDectHs.ucEndPtName)]='\0';
		  }else{
			for(i=1;i<=2;i++){
  			if(i+6 == atoi(pzCallerNumber)){
      		//memset(pzCallerName,0,sizeof(pzCallerName));
					sprintf(pzCallerName,"Phone%d",i);
					break;
					}
			}
		}
   }else{
  /* Contact List Mapping */
  		x_IFX_VMAPI_ContactList xVmapiContacts;
			memset(&xVmapiContacts,0,sizeof(xVmapiContacts));
			xVmapiContacts.iid.config_owner = IFX_VOIP;
			x_IFX_VMAPI_ContactListEntry *pxTemp=NULL;
			if(IFX_VMAPI_SUCCESS == 
		 			ifx_get_CommonContactList (&xVmapiContacts,IFX_VMAPI_OP_DEFAULT)){

        	pxTemp = xVmapiContacts.pxContactEntries;
				   while(pxTemp != NULL){
                 i=0;
                while((pzCallerNumber[i] != '@')&&(pzCallerNumber[i]!='\0')){
                		 i++;
								}
                if((pxTemp->xAddress.acContactNum[i]!='\0')||
										(pxTemp->xAddress.acContactNumTwo[i]!='\0')){
									__ifx_list_GetNext((void *)&pxTemp);
                  continue;
								}
                if((i <= IFX_VMAPI_MAX_TRANS_ADDR_LEN) && 
										((!memcmp(pzCallerNumber,pxTemp->xAddress.acContactNum,i))
										 ||(!memcmp(pzCallerNumber,pxTemp->xAddress.acContactNumTwo,i))))
                  break;
      		  __ifx_list_GetNext((void *)&pxTemp);
           }
		}
			if(pxTemp == NULL){	
					memset(&xVmapiContacts,0,sizeof(xVmapiContacts));
					xVmapiContacts.iid.config_owner = IFX_VOIP;
					xVmapiContacts.ucLineId = ucLineId;

				if(IFX_VMAPI_SUCCESS == 
		 			ifx_get_ContactList (&xVmapiContacts,IFX_VMAPI_OP_DEFAULT)){

        	pxTemp = xVmapiContacts.pxContactEntries;
				   while(pxTemp != NULL){
                 i=0;
                while((pzCallerNumber[i] != '@')&&(pzCallerNumber[i]!='\0')&&i<IFX_VMAPI_MAX_TRANS_ADDR_LEN-1){
                		 i++;
								}
                if((pxTemp->xAddress.acContactNum[i]!='\0')||
										(pxTemp->xAddress.acContactNumTwo[i]!='\0')){
									__ifx_list_GetNext((void *)&pxTemp);
                  continue;
								}
                if(((!memcmp(pzCallerNumber,pxTemp->xAddress.acContactNum,i))
										 ||(!memcmp(pzCallerNumber,pxTemp->xAddress.acContactNumTwo,i))))
                  break;
      		  __ifx_list_GetNext((void *)&pxTemp);
           }
		}
	}
    if(pxTemp != NULL){
      //memset(pzCallerName,0,sizeof(pzCallerName));
			memcpy(pzCallerName,pxTemp->xAddress.acUserLastName,strlen(pxTemp->xAddress.acUserLastName));
			pzCallerName[strlen(pxTemp->xAddress.acUserLastName)]='\0';
		}
		ifx_vmapi_freeObjectList(&xVmapiContacts, IFX_VMAPI_VS_CONTACT_LIST);
   
  }
  /* End Contact List Mapping */
  
  return IFX_SUCCESS;
}
#endif
/******************************************************************************
 *  Function Name   : IFX_CIF_NoOfUnreadGet
 *  Description     : This internal Api fetches number of unread Missed Calls in
 *                    the Missed Call List for the specified line.
 *  Input Values    : ucLineId - Line Identifier
 *  Output Values   : pucNoOfUNread - Number of Unread Entries in the list
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : Unread Entries in Missed Call List are those for which
 *                    read status is set.(bStatus is 1) 
 ****************************************************************************/
e_IFX_Return
  IFX_CIF_NoOfUnreadGet(IN uchar8 ucLineId,OUT uchar8 *pucNoOfUnread){

  x_IFX_VMAPI_MissCallRegister xVmapiMissCall= {{{{""}}}};
  x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;

  if(NULL == pucNoOfUnread){
	  return IFX_FAILURE;
  }	  
  *pucNoOfUnread = 0;
  if(ucLineId > 0){
    xVmapiMissCall.ucLineId=ucLineId; 
  }else{
    return IFX_FAILURE;
  }
  xVmapiMissCall.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_MissCallReg(&xVmapiMissCall,IFX_VMAPI_OP_DEFAULT)){
    ifx_vmapi_freeObjectList(&xVmapiMissCall, IFX_VMAPI_VS_MISSCALL_REGISTER);
    return IFX_FAILURE;
  }
  pxCallRegEntry = xVmapiMissCall.pxCallRegEntries;

  while(pxCallRegEntry != NULL){
  

      if(1 == pxCallRegEntry->bStatus){ 
        ++(*pucNoOfUnread);
      }
    __ifx_list_GetNext((void *)&pxCallRegEntry);
  }
  ifx_vmapi_freeObjectList(&xVmapiMissCall, IFX_VMAPI_VS_MISSCALL_REGISTER);
  return IFX_SUCCESS;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_AssocLineIdsGet
 *  Description     : This internal Api determines the Line Ids for the Lines to
 *                    which given Handset is associated.
 *  Input Values    : ucHandset - Handset Identifier
 *  Output Values   : pucLineIdList - List of Line Identifiers
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
#if defined(DECT_SUPPORT) || defined (CVOIP_SUPPORT)
e_IFX_Return
  IFX_CIF_AssocLineIdsGet(IN uchar8 ucHandset,OUT uchar8 *pucLineIdList){

  uchar8 aucEndPt[5] = "";
  uchar8 j = 0,i=0;
  x_IFX_VMAPI_DectSystem xVmapiDectSys = {{{{""}}}};
  x_IFX_VMAPI_DectHandset *pxHS = NULL;

  if(NULL == pucLineIdList){
	  return IFX_FAILURE;
  }	  
  memset(pucLineIdList,0,IFX_DECTAPP_MAX_LINES);

  memset(&xVmapiDectSys,0,sizeof(x_IFX_VMAPI_DectSystem));
  sprintf((char8 *)aucEndPt,"%d",1003+ucHandset); 
  xVmapiDectSys.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xVmapiDectSys,IFX_VMAPI_OP_DEFAULT)){
    ifx_vmapi_freeObjectList(&xVmapiDectSys,IFX_VMAPI_DECT_SYSTEM);
    return IFX_FAILURE;
  }
  pxHS = xVmapiDectSys.pxHandsetTbl;
  /*while(pxHS != NULL){
     
     if(strcmp(pxHS->ucEndPtId,aucEndPt) == 0){              
           while(pxHS->aucVoiceLineIdList[j] != '\0'){                  
             *pucLineIdList = (pxHS->aucVoiceLineIdList[j])-48;
             pucLineIdList++;
             j += 2; 
           }
       break;  
     }
     __ifx_list_GetNext((void*)&pxHS);
  }*/
  while(pxHS != NULL){
     if(i == ucHandset-1){ 
       while(j < (2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES + 1) 
							&& pxHS->aucVoiceLineIdList[j] != '\0'){                  
         *pucLineIdList = (pxHS->aucVoiceLineIdList[j])-48;
         printf("Assoc Lines=%d ,",*pucLineIdList);
         pucLineIdList++;
         j += 2;
       }
       break;  
     }
     i++;
     __ifx_list_GetNext((void*)&pxHS);
  }
  *pucLineIdList = '\0';
  ifx_vmapi_freeObjectList(&xVmapiDectSys,IFX_VMAPI_DECT_SYSTEM);
  return IFX_SUCCESS;
}
/******************************************************************************
 *  Function Name   : IFX_CIF_AssocLineIdSet
 *  Description     : This internal Api determines the Line Ids for the Lines to
 *                    which given Handset is associated.
 *  Input Values    : ucHandset - Handset Identifier
 *  Output Values   : pucLineIdList - List of Line Identifiers
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
  IFX_CIF_AssocLineIdSet(IN uchar8 ucHandset,IN uchar8 ucLineId){

	x_IFX_VMAPI_DectHandset xDectHs = {0};

  if('\0' == ucLineId){
	  return IFX_FAILURE;
  }	  
  //Get voice line associated with DECT handset 
	xDectHs.xVoiceServPhyIf.ucInterfaceId = ucHandset+3;
  xDectHs.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_DectHandset(&xDectHs,IFX_CIF_GET_FLAGS))
	{
      xDectHs.aucVoiceLineIdList[0] = ucLineId;
	}
  if(IFX_VMAPI_SUCCESS != ifx_set_DectHandset(IFX_OP_MOD,&xDectHs,IFX_VMAPI_OP_DEFAULT)){
  }  
return IFX_SUCCESS;
}
#endif

#ifdef DECT_SUPPORT
/******************************************************************************
 *  Function Name   : IFX_CIF_ModifiedNamePP
 *  Description     : This internal Api determines the PP whose name has been 
 *                    modified by comparing old and new objects.
 *  Input Values    : pxOld - Old Internal Names List Object
 *                    pxNew - New Internal Names List Object
 *  Output Values   : pucHandset - Handset Identifier
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return 
  IFX_CIF_ModifiedNamePP(IN void *pxOld,IN void *pxNew,OUT uchar8 *pucHandset){ 

  x_IFX_VMAPI_DectHandset *pxHSOld = (x_IFX_VMAPI_DectHandset *)pxOld;
  x_IFX_VMAPI_DectHandset *pxHSNew = (x_IFX_VMAPI_DectHandset *)pxNew;

  uchar8 j = 0;
  x_IFX_VMAPI_DectSystem xVmapiDectSys = {{{{""}}}};
  x_IFX_VMAPI_DectHandset *pxHS = NULL;

	if(NULL == pucHandset){
		return IFX_FAILURE;
	}

#if 0
  if(pxHSOld != NULL && pxHSNew != NULL){
    
    if(strcmp(pxHSOld->ucEndPtName,pxHSNew->ucEndPtName) != 0){

      *pucHandset = atoi(pxHSNew->ucEndPtId)-1003; 
    }  
  }
#endif

  xVmapiDectSys.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xVmapiDectSys,IFX_VMAPI_OP_DEFAULT)){
    ifx_vmapi_freeObjectList(&xVmapiDectSys,IFX_VMAPI_DECT_SYSTEM);
    return IFX_FAILURE;
  }
  if(pxHSOld != NULL && pxHSNew != NULL){

  if((strcmp((char8 *)pxHSNew->ucEndPtName,(char8 *)pxHSOld->ucEndPtName))
			||(pxHSOld->bIntercept != pxHSNew->bIntercept)){
  pxHS = xVmapiDectSys.pxHandsetTbl;
  while(pxHS != NULL){
    if(strcmp((char8 *)pxHSNew->ucEndPtName,(char8 *)pxHS->ucEndPtName) == 0){
      *pucHandset = j+1;
      break;  
     }
     j++;
     __ifx_list_GetNext((void*)&pxHS);
  }
  }else if((pxHSOld->xSubsInfo.bIsRegistered == 1)&&(pxHSNew->xSubsInfo.bIsRegistered == 0)){
      /*Handset Unregistered.*/ 
      *pucHandset = 0;  

  }else if((pxHSOld->xSubsInfo.bIsRegistered == 0)&&(pxHSNew->xSubsInfo.bIsRegistered == 1)){
       /*Handset Registered.*/
    j=0; 
    pxHS = xVmapiDectSys.pxHandsetTbl;
    while(pxHS != NULL){
      if(strcmp((char8 *)pxHSNew->ucEndPtName,(char8 *)pxHS->ucEndPtName) == 0){
        *pucHandset = (j+1)+IFX_DECTAPP_MAX_DECT_ENDPTS;
        break;  
      }
      j++;
      __ifx_list_GetNext((void*)&pxHS);
    }  
  }else{
    ifx_vmapi_freeObjectList(&xVmapiDectSys,IFX_VMAPI_DECT_SYSTEM);
    return IFX_FAILURE;
   }  

  ifx_vmapi_freeObjectList(&xVmapiDectSys,IFX_VMAPI_DECT_SYSTEM);
  return IFX_SUCCESS;
  }
  return IFX_FAILURE;
}


/******************************************************************************
 *  Function Name   : IFX_CIF_RegisteredPPsGet
 *  Description     : This internal Api fetches the list of registered handsets
 *  Input Values    : None
 *  Output Values   : pucRegisteredHS - List of Handset Identifiers for 
 *                    Registered HS
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
  IFX_CIF_RegisteredPPsGet(OUT uchar8 *pucRegisteredHS){

  int32 i=0,j = 0;
  x_IFX_VMAPI_DectSystem xVmapiDectHS = {{{{""}}}};
	x_IFX_VMAPI_DectHandset *pxHSTbl = NULL;

	if(NULL == pucRegisteredHS){
		return IFX_FAILURE;
	}	
  xVmapiDectHS.iid.config_owner = IFX_VOIP;
	if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(&xVmapiDectHS,IFX_VMAPI_OP_DEFAULT)){
    ifx_vmapi_freeObjectList(&xVmapiDectHS,IFX_VMAPI_DECT_SYSTEM);
		return IFX_FAILURE;
	}  
	pxHSTbl = xVmapiDectHS.pxHandsetTbl;
	for(i=0;i<IFX_DECT_LAU_MAX_ATTACHED_PP;i++){
		 if(pxHSTbl->xSubsInfo.bIsRegistered){
			 //pucRegisteredHS[j++] = atoi(pxHSTbl->ucEndPtId)-1003;
			 pucRegisteredHS[j++] = i+1;
		 }   
		 __ifx_list_GetNext((void*)&pxHSTbl);
		if (pxHSTbl == NULL)
			break;
	}  
  pucRegisteredHS[j] = '\0'; 	
  ifx_vmapi_freeObjectList(&xVmapiDectHS,IFX_VMAPI_DECT_SYSTEM);
	return IFX_SUCCESS;
} 

/******************************************************************************
 *  Function Name   : IFX_CIF_LineChange
 *  Description     : This internal Api determines the line identifer for the line
 *                    which is newly added/deleted or for which Handset association
 *                    information has changed.It aso determines the list of new 
 *                    handset identifiers in case of line association change.
 *  Input Values    : pxOld - Old Line Settings List object
 *                    pxNew - New line Settings List object
 *  Output Values   : pucAssocHs - List of handset identifiers for the handsets 
 *                    attached to a given line
 *                    pucLineId - Line Identifier
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
IFX_CIF_LineChange(IN void *pxOld,IN void *pxNew,OUT uchar8 *pucLineId){

	x_IFX_VMAPI_VoiceLine *pxLineOld=(x_IFX_VMAPI_VoiceLine *)pxOld;
	x_IFX_VMAPI_VoiceLine *pxLineNew=(x_IFX_VMAPI_VoiceLine *)pxNew;
	uchar8 i=0;
	uchar8 ucHSMap=0;
  uchar8 ucNoNotify1 = 0;
  uchar8 ucNoNotify2 = 0;
  uchar8 ucRegisteredHS[IFX_DECTAPP_MAX_DECT_ENDPTS] = ""; 

	if((NULL == pucLineId)||((NULL == pxOld) && (NULL == pxNew))){
    printf("\n Failure!!\n");
		return IFX_FAILURE;
	}	

  if((pxLineOld != NULL)&&(pxLineNew != NULL)){//Line Assoc Changed

    *pucLineId = pxLineNew->ucLineId;

	  while(i < (2*IFX_VMAPI_MAX_VOICE_INTERFACES+1) 
							&& pxLineOld->ucAssocVoiceInterface[i]!=0){
	 	 if(pxLineOld->ucAssocVoiceInterface[i] >= 4){
		   ucNoNotify1 |= 1<<(pxLineOld->ucAssocVoiceInterface[i]-4);
     }
		 i++;
    }
    i=0;
	  while(i<(2*IFX_VMAPI_MAX_VOICE_INTERFACES+1) && pxLineNew->ucAssocVoiceInterface[i]!=0){
	 	 if(pxLineNew->ucAssocVoiceInterface[i] >= 4){
		   ucNoNotify2 |= 1<<(pxLineNew->ucAssocVoiceInterface[i]-4);
		 }
		 i++;
    }
    printf("\n ucNoNotify1=%x , ucNoNotify2=%x\n",ucNoNotify1,ucNoNotify2);

    /*When the change in AssocVoiceInterface for the Line involves attach/detach of only Phone1/Phone2,no 
      notification needs to be sent to Dect HS.*/
		if(strcmp(pxLineOld->acName,pxLineNew->acName)){
			ucNoNotify2=0;
		}
    else if(pxLineOld->ucLineMode != pxLineNew->ucLineMode){
			ucNoNotify2=0;
		}
    else if(pxLineOld->ucIntrusion != pxLineNew->ucIntrusion){
			ucNoNotify2=0;
		}
    else if((ucNoNotify1 == ucNoNotify2)){
      return IFX_FAILURE;
    } 

    ucHSMap = ucNoNotify1|ucNoNotify2;
    printf("\n ucHSMap=%x\n",ucHSMap);

    if(IFX_FAILURE == IFX_CIF_RegisteredPPsGet(ucRegisteredHS)){
      return IFX_FAILURE;
    }
    for(i=0;i<IFX_DECTAPP_MAX_DECT_ENDPTS && ucRegisteredHS[i] != '\0';i++){
      if((0x01<<(ucRegisteredHS[i]-1))&ucHSMap){
        return IFX_SUCCESS;
      }
    }
  }else{//Line Add or Delete.

    *pucLineId = 0;//All Lines
    return IFX_SUCCESS;
   }
	 return IFX_FAILURE;
}
#endif

/******************************************************************************
 *  Function Name   : IFX_CIF_PSTNLineChange
 *  Description     : This internal Api determines the line identifer and the 
 *                    new association list for the PSTN Line.
 *  Input Values    : pxOld - Old PSTN object
 *                    pxNew - New PSTN object
 *  Output Values   : pucAssocHs - List of handset identifiers for the handsets 
 *                    attached to the PSTN line
 *                    pucLineId - Line Identifier for the PSTN Line
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
#ifdef DECT_SUPPORT
e_IFX_Return
IFX_CIF_PSTNLineChange(IN void *pxOld,IN void *pxNew,OUT uchar8 *pucLineId){

	x_IFX_VMAPI_FxoPhyIf *pxFXOOld=(x_IFX_VMAPI_FxoPhyIf *)pxOld;
	x_IFX_VMAPI_FxoPhyIf *pxFXONew=(x_IFX_VMAPI_FxoPhyIf *)pxNew;
	uchar8 i=0;
	uchar8 ucHSMap=0;
  uchar8 ucNoNotify1 = 0;
  uchar8 ucNoNotify2 = 0;
  uchar8 ucRegisteredHS[IFX_DECTAPP_MAX_DECT_ENDPTS] = ""; 

	if((NULL == pucLineId)||((NULL == pxOld) && (NULL == pxNew))){
		return IFX_FAILURE;
	}	
 
  /*PSTN Line - Association Change*/
  if((pxFXOOld != NULL)&&(pxFXONew != NULL)){

    printf("\n pxFXOOld->ucInterfaceIdList:%s\n",pxFXOOld->ucInterfaceIdList);
    printf("\n pxFXONew->ucInterfaceIdList:%s\n",pxFXONew->ucInterfaceIdList);

    *pucLineId = IFX_VMAPI_PSTN_LINE;
    
	  while(i<(2*IFX_VMAPI_MAX_PHY_ENDPTS) && pxFXOOld->ucInterfaceIdList[i]!=0){
	 	 if(pxFXOOld->ucInterfaceIdList[i]-48 >= 4){
		   ucNoNotify1 |= 1<<(pxFXOOld->ucInterfaceIdList[i]-48-4);
     }
		 i+=2;
    }
    i=0;
	  while(i<(2*IFX_VMAPI_MAX_PHY_ENDPTS) && pxFXONew->ucInterfaceIdList[i]!=0){
	 	 if(pxFXONew->ucInterfaceIdList[i]-48 >= 4){
		   ucNoNotify2 |= 1<<(pxFXONew->ucInterfaceIdList[i]-48-4);
		 }
		 i+=2;
    }
    printf("\n ucNoNotify1=%x , ucNoNotify2=%x\n",ucNoNotify1,ucNoNotify2);

    /*When the change in InterfaceIdList for Fxo involves attach/detach of only Phone1/Phone2,no 
      notification needs to be sent to Dect HS.*/
		if(strcmp(pxFXOOld->acName,pxFXONew->acName)){
			ucNoNotify2=0;
		}
    else if(pxFXOOld->ucLineMode != pxFXONew->ucLineMode){
			ucNoNotify2=0;
		}
    else if(pxFXOOld->ucIntrusion != pxFXONew->ucIntrusion){
			ucNoNotify2=0;
		}
    else if((ucNoNotify1 == ucNoNotify2)){
      return IFX_FAILURE;
    } 

    ucHSMap = ucNoNotify1|ucNoNotify2;
    printf("\n ucHSMap=%x\n",ucHSMap);

    if(IFX_FAILURE == IFX_CIF_RegisteredPPsGet(ucRegisteredHS)){
      return IFX_FAILURE;
    }
    for(i=0;i<IFX_DECTAPP_MAX_DECT_ENDPTS && ucRegisteredHS[i] != '\0';i++){
      if((0x01<<(ucRegisteredHS[i]-1))&ucHSMap){
        return IFX_SUCCESS;
      }
    } 
  }
	return IFX_FAILURE;
}
#endif

/******************************************************************************
 *  Function Name   : IFX_CIF_CallFeatChange
 *  Description     : This internal Api determines the Line Id for which the Line
 *                    Calling features have changed and also the list of handsets
 *                    attached to that line.
 *  Input Values    : pxOld - Old Line Settings List object
 *                    pxNew - New Line Settings List object
 *  Output Values     pucLineId - Line Identifier
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : 
 ****************************************************************************/
e_IFX_Return
IFX_CIF_CallFeatChange(IN void *pxOld,IN void *pxNew,OUT uchar8 *pucLineId){

	x_IFX_VMAPI_LineCallingFeatures  *pxCallFeatOld=(x_IFX_VMAPI_LineCallingFeatures *)pxOld;
	x_IFX_VMAPI_LineCallingFeatures *pxCallFeatNew=(x_IFX_VMAPI_LineCallingFeatures *)pxNew;

  *pucLineId = pxCallFeatOld->ucLineId;

  if((pxCallFeatNew->bEnableCid != pxCallFeatOld->bEnableCid)||
		 (pxCallFeatNew->unCallFwdCfg != pxCallFeatOld->unCallFwdCfg)){
	 return IFX_SUCCESS;
  }
   return IFX_FAILURE;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_SystemChange
 *  Description     : This internal determines if the Clock Master or Pin Code
 *                    changed for the System Settings List.
 *  Input Values    : pxOld - Old System Settings List object
 *                    pxNew - New System Settings List object
 *  Output Values   : None
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : In case of Base Reset,                                                                                  
 *                    one of Clock Master/Pin Code shall change so notification                                                                                    
 *                    will be sent.                                   
 ****************************************************************************/
e_IFX_Return
IFX_CIF_SystemChange(IN void *pxOld,IN void *pxNew){

  x_IFX_VMAPI_DectSystem *pxSysOld = (x_IFX_VMAPI_DectSystem*)pxOld;
  x_IFX_VMAPI_DectSystem *pxSysNew = (x_IFX_VMAPI_DectSystem*)pxNew;

  if(strcmp(pxSysOld->acAuthCode,pxSysNew->acAuthCode) ||
     (pxSysOld->ucClkMaster != pxSysNew->ucClkMaster)){
    return IFX_SUCCESS;
  }       
  return IFX_FAILURE;
}

/******************************************************************************
 *  Function Name   : IFX_CIF_ListObjectGet
 *  Description     : This internal Api populates the list structure from the
 *                    given list object. 
 *  Input Values    : ucListType - List Identifier
 *                    pxObj - pointer to List Object
 *  Output Values   : pxList - pointer to List structure
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : Used during Notification 
 ****************************************************************************/
#ifdef DECT_SUPPORT
e_IFX_Return 
  IFX_CIF_ListObjectGet(IN uchar8 ucListType,IN void *pxObj,OUT void *pxList){

        x_IFX_VMAPI_CallRegister *pxVmapiCallReg = NULL;
	      x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
		    x_IFX_VMAPI_CallRegEntry *pxCallRegHead = NULL;
			  int32 i=0;



  switch(ucListType){

		case IFX_DECT_LAU_MISSED_CALLS: 
    {
        x_IFX_DECT_LAU_MissedCallList *pxMissedCallList = NULL;
        if((NULL == pxObj)||(NULL == pxList)){
  	  return IFX_FAILURE;
        }		 
        pxMissedCallList = (x_IFX_DECT_LAU_MissedCallList *)pxList;	
        pxVmapiCallReg = (x_IFX_VMAPI_CallRegister*)pxObj;
        pxCallRegEntry = pxCallRegHead = pxVmapiCallReg->pxCallRegEntries;
 if (pxCallRegEntry == NULL){
				pxMissedCallList->cNoOfEntries = 0;
				//pxMissedCallList->ucLineId = pxVmapiCallReg->ucLineId;
        pxMissedCallList->axMissedCallList[0].ucLineId = pxVmapiCallReg->ucLineId;
				printf ("IFX_CIF_ListObjectGet Line 1\n");
  	  	return IFX_SUCCESS;
 }
	if(pxCallRegHead != NULL){
          
           __ifx_list_GetPrev((void*)&pxCallRegEntry);
           pxCallRegHead = pxCallRegEntry;
       if(pxCallRegEntry == NULL){ 
				printf ("IFX_CIF_ListObjectGet Line 2\n");
				pxMissedCallList->cNoOfEntries = 0;
        pxMissedCallList->axMissedCallList[0].ucLineId = pxVmapiCallReg->ucLineId;
				//pxMissedCallList->ucLineId = pxVmapiCallReg->ucLineId;
  	  	return IFX_SUCCESS;
   		 }

         do{
           memcpy(pxMissedCallList->axMissedCallList[i].acCallerNum,pxCallRegEntry->xAddress.acUserName,
                strlen(pxCallRegEntry->xAddress.acUserName));
           memcpy(pxMissedCallList->axMissedCallList[i].acCallerName,pxCallRegEntry->xAddress.acDisplayName,
                strlen(pxCallRegEntry->xAddress.acDisplayName));
           IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
												 &pxMissedCallList->axMissedCallList[i].xTimeDate);
           pxMissedCallList->axMissedCallList[i].bNew = pxCallRegEntry->bStatus;
           if(pxCallRegEntry->ucLineId == IFX_VMAPI_PSTN_LINE){
             strcpy(pxMissedCallList->axMissedCallList[i].acLineName,"PSTN Line");
           }else{
             sprintf(pxMissedCallList->axMissedCallList[i].acLineName,"Line%d",pxCallRegEntry->ucLineId);
           }
           pxMissedCallList->axMissedCallList[i].ucLineId = pxCallRegEntry->ucLineId;
           pxMissedCallList->axMissedCallList[i].ucNoOfCalls = pxCallRegEntry->ucNoOfCalls;
           pxMissedCallList->axMissedCallList[i].nEntryId = pxCallRegEntry->uiEntryId;

           i++;
           __ifx_list_GetPrev((void*)&pxCallRegEntry);
					 if (pxCallRegEntry == NULL)
						 break;

         }while(pxCallRegEntry != pxCallRegHead); 

			  } else{
           pxMissedCallList->axMissedCallList[0].ucLineId = pxVmapiCallReg->ucLineId;
                         }
		    pxMissedCallList->cNoOfEntries = pxVmapiCallReg->ucNoOfEntries;
    }
    break;

		case IFX_DECT_LAU_INCOMING_ACCEPT_CALLS:
		{

        x_IFX_DECT_LAU_IncomingCallList *pxIncomingCallList = NULL;

			  if((NULL == pxObj)||(NULL == pxList)){
					 return IFX_FAILURE;
			  }		 

        pxIncomingCallList = (x_IFX_DECT_LAU_IncomingCallList *)pxList;	
        pxVmapiCallReg = (x_IFX_VMAPI_CallRegister*)pxObj;

        pxCallRegEntry = pxCallRegHead = pxVmapiCallReg->pxCallRegEntries;

        if(pxCallRegHead != NULL){
          
           __ifx_list_GetPrev((void*)&pxCallRegEntry);
           pxCallRegHead = pxCallRegEntry;
       if(pxCallRegEntry == NULL){ 
  	  	return IFX_FAILURE;
			 }

         do{

           memcpy(pxIncomingCallList->axIncomingCallList[i].acCallerNum,pxCallRegEntry->xAddress.acUserName,
                strlen(pxCallRegEntry->xAddress.acUserName));
           memcpy(pxIncomingCallList->axIncomingCallList[i].acCallerName,pxCallRegEntry->xAddress.acDisplayName,
                strlen(pxCallRegEntry->xAddress.acDisplayName));
           IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
															&pxIncomingCallList->axIncomingCallList[i].xTimeDate);
           if(pxCallRegEntry->ucLineId == IFX_VMAPI_PSTN_LINE){
             strcpy(pxIncomingCallList->axIncomingCallList[i].acLineName,"PSTN Line");
           }else{
             sprintf(pxIncomingCallList->axIncomingCallList[i].acLineName,"Line%d",pxCallRegEntry->ucLineId);
           }
           pxIncomingCallList->axIncomingCallList[i].ucLineId = pxCallRegEntry->ucLineId;
           pxIncomingCallList->axIncomingCallList[i].nEntryId = pxCallRegEntry->uiEntryId;

					 i++;
           __ifx_list_GetPrev((void*)&pxCallRegEntry);
					 if (pxCallRegEntry == NULL)
						 break;

         }while(pxCallRegEntry != pxCallRegHead); 

	  }else{
           pxIncomingCallList->axIncomingCallList[0].ucLineId = pxVmapiCallReg->ucLineId;
          }
	    pxIncomingCallList->cNoOfEntries = pxVmapiCallReg->ucNoOfEntries;
   }
	 break;

		case IFX_DECT_LAU_OUTGOING_CALLS:
		{

        x_IFX_DECT_LAU_OutgoingCallList *pxOutgoingCallList = NULL;

			  if((NULL == pxObj)||(NULL == pxList)){
					 return IFX_FAILURE;
			  }		 

        pxOutgoingCallList = (x_IFX_DECT_LAU_OutgoingCallList *)pxList;	
        pxVmapiCallReg = (x_IFX_VMAPI_CallRegister*)pxObj;

        pxCallRegEntry = pxCallRegHead = pxVmapiCallReg->pxCallRegEntries;

        if(pxCallRegHead != NULL){
          
           __ifx_list_GetPrev((void*)&pxCallRegEntry);
           pxCallRegHead = pxCallRegEntry;
       if(pxCallRegEntry == NULL){ 
  	  	return IFX_FAILURE;
			 }

         do{

           memcpy(pxOutgoingCallList->axOutgoingCallList[i].acCalledNum,pxCallRegEntry->xAddress.acUserName,
               strlen(pxCallRegEntry->xAddress.acUserName));
           if(!strlen(pxCallRegEntry->xAddress.acDisplayName)){
              memcpy(pxOutgoingCallList->axOutgoingCallList[i].acCalledName,pxCallRegEntry->xAddress.acUserName,
                   strlen(pxCallRegEntry->xAddress.acUserName));
           }else{
             memcpy(pxOutgoingCallList->axOutgoingCallList[i].acCalledName,pxCallRegEntry->xAddress.acDisplayName,
                   strlen(pxCallRegEntry->xAddress.acDisplayName));
            }
           IFX_DECT_GetDateTime(pxCallRegEntry->acCallDate,pxCallRegEntry->acCallTime,
														 &pxOutgoingCallList->axOutgoingCallList[i].xTimeDate);
           if(pxCallRegEntry->ucLineId == IFX_VMAPI_PSTN_LINE){
             strcpy(pxOutgoingCallList->axOutgoingCallList[i].acLineName,"PSTN Line");
           }else{
             sprintf(pxOutgoingCallList->axOutgoingCallList[i].acLineName,"Line%d",pxCallRegEntry->ucLineId);
           }
           pxOutgoingCallList->axOutgoingCallList[i].ucLineId = pxCallRegEntry->ucLineId;
           pxOutgoingCallList->axOutgoingCallList[i].nEntryId = pxCallRegEntry->uiEntryId;

           i++;
           __ifx_list_GetPrev((void*)&pxCallRegEntry);

         }while(pxCallRegEntry != pxCallRegHead);

			  }else{
           pxOutgoingCallList->axOutgoingCallList[0].ucLineId = pxVmapiCallReg->ucLineId;
                          }
 
	        pxOutgoingCallList->cNoOfEntries = pxVmapiCallReg->ucNoOfEntries;
   }
	 break;

   default:
    break;
  } 	 
  return IFX_SUCCESS;
}
#endif


/******************************************************************************
 *  Function Name   : IFX_CIF_FreeVmapiObj
 *  Description     : This internal Api is used to free vmapi list object after
 *                    notification is sent to all registered handsets.
 *  Input Values    : eLAType - List Type
 *                    pxObj - pointer to old List Object
 *  Output Values   : pxList - pointer to new List object
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           : Used after Notification 
 ****************************************************************************/
e_IFX_Return 
IFX_CIF_FreeVmapiObj(IN e_IFX_CMGR_LA_Type eLAType,
                     IN void *pxOld,
                     IN void *pxNew){

  printf("\n FreeVmapiObj Entry.\n");
  switch(eLAType){

    case IFX_CMGR_LA_MISSED_CALLS:

				ifx_vmapi_freeObjectList((x_IFX_VMAPI_CallRegister*)pxOld,IFX_VMAPI_VS_MISSCALL_REGISTER);
				ifx_vmapi_freeObjectList((x_IFX_VMAPI_CallRegister*)pxNew,IFX_VMAPI_VS_MISSCALL_REGISTER);
        printf("\nMissed Call Objects freed.\n");
        break;

    case IFX_CMGR_LA_INCOMING_ACCEPT_CALLS:

				ifx_vmapi_freeObjectList((x_IFX_VMAPI_CallRegister*)pxOld,IFX_VMAPI_VS_RECVCALL_REGISTER);
				ifx_vmapi_freeObjectList((x_IFX_VMAPI_CallRegister*)pxNew,IFX_VMAPI_VS_RECVCALL_REGISTER);
        printf("\nIncoming Call Objects freed.\n");
        break;
  
    case IFX_CMGR_LA_OUTGOING_CALLS:

				ifx_vmapi_freeObjectList((x_IFX_VMAPI_CallRegister*)pxOld,IFX_VMAPI_VS_DIALCALL_REGISTER);
				ifx_vmapi_freeObjectList((x_IFX_VMAPI_CallRegister*)pxNew,IFX_VMAPI_VS_DIALCALL_REGISTER);
        printf("\nOutgoing Call Objects freed.\n");
        break;

    case IFX_CMGR_LA_CONTACTS:
        //Check?
        break;
/*
*/
    case IFX_CMGR_LA_LINE_SETTINGS_ASSOC:
        break;

    case IFX_CMGR_LA_LINE_SETTINGS_CF:
        break;
    case IFX_CMGR_LA_SYSTEM_SETTINGS:
        break;

    default:
        return IFX_FAILURE;


  }
  return IFX_SUCCESS;
}


e_IFX_Return IFX_CIF_AddrBookEntryGet(
	                 IN char8* szAddrIndex, 
									 OUT x_IFX_CMGR_AddressInfo* pxAddr,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_AddressBook xAddrBook = {{{{""}}}};
	uchar8 ucCount = 0;
	e_IFX_Return eRet = IFX_FAILURE;
  xAddrBook.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_AddrBook(&xAddrBook,IFX_CIF_GET_FLAGS))
	{
		x_IFX_VMAPI_AddressBookEntry *pxAddrBook = xAddrBook.pxAddressBook;

		if (pxAddrBook == NULL){
			return IFX_FAILURE;
		}

		while( pxAddrBook != NULL )
		{
			if( strcasecmp(szAddrIndex, pxAddrBook->acDialCode ) == 0 )
			{
				break;
			}
			++ucCount;
		  __ifx_list_GetNext((void**)&pxAddrBook);
		}
		
		if (!pxAddrBook){
			ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);
			return IFX_FAILURE;
		}

		if( ucCount == xAddrBook.ucNoOfAddBookEntries )
			*peReason = IFX_CIF_ELEMENT_NOT_FOUND;
		else
		{
			eRet = IFX_SUCCESS;
			if( IFX_PSTN_NUM == pxAddrBook->eCallType )
			{
				pxAddr->eAddressType = IFX_CMGR_TYPE_FXO;
				strcpy(pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber,
					pxAddrBook->xAddress.acUserName);
			}
			else /* VoIP Number */
			{
				 pxAddr->eAddressType = IFX_CMGR_TYPE_VOIP;

				 //pxAddrBook->xAddress.ucAddrType = 0; //IFX_IP_ADDR;
				 ifx_cif_cpyFromVmapiAddr(&pxAddr->uxAddressInfo.xVoipAddr, 
												 &pxAddrBook->xAddress);
			}
		}
		ifx_vmapi_freeObjectList(&xAddrBook,IFX_VMAPI_VS_ADDRESS_BOOK);
	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_AddrBookEntryModify(
	                 IN  char8* szAddrIndex,
	                 IN x_IFX_CalledAddr* pxAddr,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_AddressBook xAddrBook = {{{{""}}}};
	x_IFX_VMAPI_AddressBookEntry *pxAddrBook;
	uchar8 ucCount = 0;
	e_IFX_Return eRet = IFX_FAILURE;
  xAddrBook.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_AddrBook(&xAddrBook,IFX_CIF_GET_FLAGS) ) 
	{
		pxAddrBook = xAddrBook.pxAddressBook;
		while( ucCount < xAddrBook.ucNoOfAddBookEntries )
		{
			if( strcasecmp(szAddrIndex, pxAddrBook->acDialCode ) == 0 )
				break;

			++ucCount;
			++pxAddrBook;
		}

		if( ucCount != xAddrBook.ucNoOfAddBookEntries )
		{
			ifx_cif_cpyToVmapiAddr(&pxAddrBook->xAddress,pxAddr);
			if( IFX_VMAPI_SUCCESS != ifx_set_AddrEntry(IFX_CIF_SETOPP_FLAG,
																			pxAddrBook,
																			IFX_CIF_MOD_FLAG) )
			{
				*peReason = IFX_CIF_CONFIG_ERROR;
			}
			else
				eRet = IFX_SUCCESS;
		}
		else
		{
			*peReason = IFX_CIF_ELEMENT_NOT_FOUND;
		}

		ifx_vmapi_freeObjectList(&xAddrBook, IFX_VMAPI_VS_ADDRESS_BOOK);
	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_FxoVLIdGet(
	                 IN char8* szEndptId,
	                 OUT uchar8* pucLineId,
	                 OUT e_IFX_ReasonCode* peReason )
{
	return IFX_CIF_EndptDefaultVLGet(szEndptId,pucLineId,peReason);
}

e_IFX_Return IFX_CIF_EndptDefaultVLGet(
	                 IN char8* szEndptId,
	                 OUT uchar8* pucLineId,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_CIF_EndptData* pxEndptData;
	e_IFX_Return eRet ;
	
	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szEndptId,&pxEndptData,peReason)) )
	{
		*pucLineId = pxEndptData->ucDefaultVL;
	}

	return eRet;
}

/*
 * 
 */
e_IFX_Return IFX_CIF_VLStatusGet(
	                 IN uchar8 ucLineId,
									 OUT boolean* pbEnabled,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_VoiceLine xLine = {{{{""}}}};
	x_IFX_VMAPI_VoiceProfile xProfile = {{{{""}}}};
	e_IFX_Return eRet ;
	
	IFX_CIF_VALIDATE_VOICELINE(ucLineId,peReason);
	*pbEnabled = IFX_FALSE;
	xLine.ucLineId = ucLineId;
  xLine.iid.config_owner = IFX_VOIP;
	printf("\n\nLine Id = %d\n", ucLineId);
	if( IFX_VMAPI_SUCCESS == (eRet=ifx_get_VoiceLine(&xLine, IFX_CIF_GET_FLAGS)) )
	{
		/*
		 * FIX: If profile is disabled don't treat line as in disabled state.
		 */
		printf("Line %d Get Voice Line Success\n", ucLineId);
		printf("xLine.ucState=%d , xLine.ucLineStatus=%d , xLine.ucProfileId=%d\n", xLine.ucState,xLine.ucLineStatus,xLine.ucProfileId);
		xProfile.ucProfileId = xLine.ucProfileId;
    xProfile.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS == ifx_get_VoiceProfile(&xProfile,IFX_CIF_GET_FLAGS)
				&& IFX_VMAPI_VP_STATE_ENABLED == xProfile.ucState ) 
		{
		  printf("Line %d Get Voice Profile Success and Profile State Enabled\n", ucLineId);
			if((IFX_VMAPI_VL_STATE_ENABLED == xLine.ucState) && 
											(IFX_VMAPI_VL_STATUS_UP == xLine.ucLineStatus))
			{ 
				printf("Line %d Enabled\n", ucLineId);
				*pbEnabled = IFX_TRUE;
			}
		}
	}

	return eRet;
}

e_IFX_Return IFX_CIF_EndptDefaultFxoLineGet(
	                 IN char8* szEndptId,
	                 OUT char8* pszFxoEndptId,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_CIF_EndptData* pxEndptData = vxConfigInfo.axEndptData;
	uchar8 ucIfId = 0;
	e_IFX_Return eRet = IFX_SUCCESS;
	
	pszFxoEndptId[0] = '\0';
	while(ucIfId < IFX_MAX_ENDPTS )
	{
		if( IFX_EP_FXO == pxEndptData->eType )
		{
			strcpy(pszFxoEndptId,pxEndptData->szEndptId);
			break;
		}
		++ucIfId;
		++pxEndptData;
	}

	if( 0 == strlen(pszFxoEndptId) )
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
		eRet = IFX_FAILURE;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_EndptTypeGet(
	                 IN char8* szEndptId,
	                 OUT e_IFX_EndptType* peEpType,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_CIF_EndptData* pxEndptData;
	e_IFX_Return eRet ;
	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szEndptId,&pxEndptData,peReason)) )
	{
		*peEpType = pxEndptData->eType;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_EndptLinesGet(
	                 IN char8* szEndptId,
	                 IN_OUT uchar8* pucSize,
	                 OUT uchar8* paLines,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_CIF_EndptData* pxEndptData;
	x_IFX_VMAPI_FxsPhyIf xFxsPhyIf = {{{{""}}}};
	uchar8* pucVoiceLineIds = 0;
	uchar8 ucCount = 0;
	e_IFX_Return eRet ;

	if( *pucSize < IFX_MAX_LINES )
	{
		*peReason = IFX_CIF_INSUFFICIENT_ARRAY_SIZE;
		return IFX_FAILURE;
	}

	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szEndptId,&pxEndptData,peReason)) )
	{
		eRet = IFX_FAILURE;
		if( IFX_EP_FXS == pxEndptData->eType )
		{
			/* 
			 * Get FXS endpoint physical interface object and copy voice lines 
			 * assoicated with it into paLines.
			 */
			xFxsPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xFxsPhyIf.iid.config_owner = IFX_VOIP;

			if( IFX_VMAPI_SUCCESS == 
				ifx_get_FxsPhyInterface(&xFxsPhyIf,IFX_CIF_GET_FLAGS) )
			{
				pucVoiceLineIds = xFxsPhyIf.ucVoiceLineIdList;
				eRet = IFX_SUCCESS;
			}
			else
				*peReason = IFX_CIF_CONFIG_ERROR;

		} 
#ifdef DECT_SUPPORT
		else if( IFX_EP_DECT == pxEndptData->eType )
		{
			//Get voice line associated with DECT handset 
			x_IFX_VMAPI_DectHandset xDectHs = {0};
			xDectHs.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xDectHs.iid.config_owner = IFX_VOIP;
				
			if( IFX_VMAPI_SUCCESS == ifx_get_DectHandset(&xDectHs,IFX_CIF_GET_FLAGS))
			{
				pucVoiceLineIds = xDectHs.aucVoiceLineIdList;
				eRet = IFX_SUCCESS;
			}			
		}
#endif

		if( pucVoiceLineIds )
		{
			/* 
			 * 0 is invalid voice line id. Voice line id list ends with invalid 
			 * voice line id.
			 */
			while( ucCount < *pucSize && pucVoiceLineIds[ucCount] != 0)
			{
				*paLines = pucVoiceLineIds[ucCount];
				++ucCount;
			}
		}

	} /* End point data */

	return eRet;
}

e_IFX_Return IFX_CIF_FxoLineEndptListGet(
	                 IN char8* szFxoEndpointId,
	                 IN_OUT uchar8* pucSize,
	                 OUT char8 aszEndpointList[][IFX_MAX_ENDPOINTID_LEN],
	                 OUT e_IFX_ReasonCode* peReason ) 
{
	x_IFX_CIF_EndptData* pxEndptData;
	x_IFX_VMAPI_FxoPhyIf xFxoPhyIf = {{{{""}}}};
	uchar8 ucCount = 0;
	uchar8 ucIndex;
	e_IFX_Return eRet = IFX_FAILURE;

	if( *pucSize < IFX_MAX_ENDPTS || *pucSize >= (2*IFX_VMAPI_MAX_PHY_ENDPTS))
	{
		*peReason = IFX_CIF_INSUFFICIENT_ARRAY_SIZE;
		return eRet;
	}

	if( IFX_SUCCESS == 
		(eRet = IFX_CIF_EndptDataGet(szFxoEndpointId,&pxEndptData,peReason)) )
	{
		eRet = IFX_FAILURE;
		if( pxEndptData->eType != IFX_EP_FXO )
		{
			*peReason = IFX_CIF_INVALID_ENDPOINT;
		} 
		else
		{
			xFxoPhyIf.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
      xFxoPhyIf.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS ==
				ifx_get_FxoPhyInterface(&xFxoPhyIf,IFX_CIF_GET_FLAGS) )
			{
				while(ucCount < *pucSize && xFxoPhyIf.ucInterfaceIdList[ucCount] > 0)
				{
 					  ucIndex  = xFxoPhyIf.ucInterfaceIdList[ucCount]-1;
 					strcpy(aszEndpointList[ucCount],
						vxConfigInfo.axEndptData[ucIndex].szEndptId);
					++ucCount;
				}
				eRet = IFX_SUCCESS;
			}
			/* else
				printf("\n%s: ifx_get_FxoPhyInterface FAILED", __FUNCTION__); */
		}
	}

	*pucSize = ucCount;
	return eRet;
}

/*
 * Get profile list. Compare domain name of szSipUrl and profile domain name.
 * If matches, get voice lines of that profile and compare user name of 
 * szSipUrl with voice line. If matched, return that line's id.
 */
e_IFX_Return IFX_CIF_VLFromUrlGet(
	                 IN x_IFX_CalledAddr* pxAddr,
	                 OUT uchar8* pucVoiceLineId,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_VoiceProfile xProfile = {{{{""}}}};
	x_IFX_VMAPI_ProfileSignaling xProfileSig = {{{{""}}}};
	x_IFX_VMAPI_LineSignaling xLineSig;
	x_IFX_VMAPI_VoiceLine xLine = {{{{""}}}};
	x_IFX_VMAPI_LineSubscription xLineSub;
	uchar8 aucProfileId[IFX_MAX_PROFILES]={0};
	e_IFX_Return eRet = IFX_FAILURE;
	uchar8 ucCnt = 0;
	
	*pucVoiceLineId = 0;
	memset(&xProfile,0,sizeof(x_IFX_VMAPI_VoiceProfile));
	memset(&xProfileSig,0,sizeof(x_IFX_VMAPI_ProfileSignaling));


	if( IFX_SUCCESS != IFX_CIF_ProfileIdListGet(aucProfileId))
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
		return eRet;
	}
#if 0
	/*
	 * Go through each profile in system and check whether it is enabled. 
	 * If enabled check whether domain name matches with pxAddr. If matches
	 * then for each line of that profile, check whether user name matches with
	 * that of pxAddr (if line is active only). If matches return that line
	 * in pucVoiceLineId.
	 */
	for(ucCnt = 0 ; aucProfileId[ucCnt] > 0; ++ucCnt )
	{
		xProfile.ucProfileId = aucProfileId[ucCnt];
		
		if( IFX_VMAPI_SUCCESS == 
				ifx_get_VoiceProfile(&xProfile,IFX_CIF_GET_FLAGS))
		{
			if( IFX_VMAPI_VP_STATE_ENABLED == xProfile.ucState )
			{
				xProfileSig.ucProfileId = xProfile.ucProfileId;

				if( IFX_VMAPI_SUCCESS == 
						ifx_get_ProfileSignaling(&xProfileSig,IFX_CIF_GET_FLAGS))
				{
					/* printf("%s: Profile Domain Name=%s [id=%d] (Received: %s)\n",
													__FUNCTION__,xProfileSig.acUADomain, 
													xProfile.ucProfileId,pxAddr->acCalledAddr); */
					if( strcasecmp(xProfileSig.acUADomain, pxAddr->acCalledAddr ) == 0)
					{
						eRet =  IFX_SUCCESS;
						break;
					}
				}
				else
				{
					printf("%s: ifx_get_ProfileSignaling FAILED :: Profile Id [id=%d]\n",
													__FUNCTION__,xProfile.ucProfileId);
					break;
				}
			}
			else
			{
				printf("%s: Profile Id [id=%d] Is Disabled\n",
												__FUNCTION__, aucProfileId[ucCnt]);
			}
		}
		else
		{
			printf("%s: ifx_get_VoiceProfile FAILED :: Profile Id [id=%d]\n",
											__FUNCTION__, aucProfileId[ucCnt]);
			break;
		}
	}

	if( IFX_SUCCESS == eRet )
	{
		//printf("\n%s: Profile Matched [profile id=%d]\n",__FUNCTION__, xProfile.ucProfileId);
		eRet = IFX_FAILURE;
		/* Profile matched, now search for voice line */
		for(ucCnt = 0; xProfile.aucAssoLineIds[ucCnt] > 0 ; ++ucCnt )
		{

			xLine.ucProfileId = xProfile.ucProfileId;
			xLine.ucLineId = xProfile.aucAssoLineIds[ucCnt];
			
			if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xLine, IFX_CIF_GET_FLAGS))
			{
				/*
				printf("\n%s: User Name : %s (Received User Name=%s)",
												__FUNCTION__, xLine.acDirName, pxAddr->acUserName); */

				if( IFX_VMAPI_VL_STATE_ENABLED == xLine.ucState &&
						strcasecmp(xLine.acDirName, pxAddr->acUserName ) == 0)
				{
					printf("\n%s: User Name Matched  [Line id = %d]\n",
																		__FUNCTION__, xLine.ucLineId);
					*pucVoiceLineId = xLine.ucLineId;
					eRet = IFX_SUCCESS;
					break;
				}
			}
		}

		if( 0 == *pucVoiceLineId )
		{
			printf("\n%s: User Not Found : %s\n",__FUNCTION__, pxAddr->acUserName);
			*peReason = IFX_USER_NOT_FOUND;
		}
	}
	else
	{
		printf("\n%s: NO MATCHING PROFILE FOUND\n",__FUNCTION__); 
		*peReason = 
			(aucProfileId[ucCnt] == 0)?IFX_USER_NOT_FOUND:IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
#else
	*peReason = IFX_USER_NOT_FOUND;
	
	for(ucCnt = 0 ; ucCnt < IFX_MAX_PROFILES && aucProfileId[ucCnt] > 0; ++ucCnt )
	{
		xProfile.ucProfileId = aucProfileId[ucCnt];
		
		printf("Searching user Name in %d profiole For  User name=**%s**\n", 
										xProfile.ucProfileId, pxAddr->acUserName);	
    xProfile.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS == 
				ifx_get_VoiceProfile(&xProfile,IFX_CIF_GET_FLAGS))
		{
			if( IFX_VMAPI_VP_STATE_ENABLED == xProfile.ucState )
			{
				uchar8 ucLineCount = 0;

				printf("First 2 lines of the profile =%d %d\n", xProfile.aucAssoLineIds[0],xProfile.aucAssoLineIds[1]);
				for( ; ucLineCount < (2*IFX_VMAPI_MAX_VOICE_LINES_PER_PROFILE+1) && xProfile.aucAssoLineIds[ucLineCount] > 0 ; ++ucLineCount )
				{
					memset(&xLine,0,sizeof(x_IFX_VMAPI_VoiceLine));

					xLine.ucProfileId = xProfile.ucProfileId;
					xLine.ucLineId = xProfile.aucAssoLineIds[ucLineCount];
          xLine.iid.config_owner = IFX_VOIP;
					
					if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xLine, IFX_CIF_GET_FLAGS))
					{
								 memset(&xLineSub,0,sizeof(xLineSub));
								 memset(&xLineSig,0,sizeof(x_IFX_VMAPI_LineSignaling));
						if( IFX_VMAPI_VL_STATE_ENABLED == xLine.ucState ) {
							xLineSig.ucLineId = xLine.ucLineId;
          					xLineSig.iid.config_owner = IFX_VOIP;
							ifx_get_LineSignaling(&xLineSig,0);
						 printf("Line State=%d  Line User Name=%s \n",
								 xLine.ucState,xLineSig.acSipUserName	); 
							if( strcasecmp(xLineSig.acSipUserName, pxAddr->acUserName ) == 0)
							{
							*pucVoiceLineId = xLine.ucLineId;
							eRet = IFX_SUCCESS;
							ifx_vmapi_freeObjectList(&xLineSig,IFX_VMAPI_VL_SIGNALING);//aarif
							break;
							}
							ifx_vmapi_freeObjectList(&xLineSig,IFX_VMAPI_VL_SIGNALING);//aarif
							xLineSub.ucLineId = xLine.ucLineId;
              				xLineSub.iid.config_owner = IFX_VOIP;
							ifx_get_LineSubscription(&xLineSub,0);
							if( strcasecmp(xLineSub.pxLineEvents->acSubspnUsrName,pxAddr->acUserName ) == 0)
							{
							printf("\n Line Subscribe Name=%s\n",xLineSub.pxLineEvents->acSubspnUsrName);
							*pucVoiceLineId = xLine.ucLineId;
							eRet = IFX_SUCCESS;
							ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);
							break;
							}
							ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);
						}
					}
				}

				if( 0 != *pucVoiceLineId )
					break;
			}
#if 1 
			else
			{
				printf("%s: Profile Id [id=%d] Is Disabled\n",
												__FUNCTION__, aucProfileId[ucCnt]);
			}
#endif
		}
		else
		{
			 printf("%s: ifx_get_VoiceProfile FAILED :: Profile Id [id=%d]\n",
											__FUNCTION__, aucProfileId[ucCnt]); 
			break;
		}
	}
#ifdef DEV_DEBUG
	if( IFX_SUCCESS != eRet )
	{
		printf("\n%s: User Not Found : %s\n",__FUNCTION__, pxAddr->acUserName);
	}
#endif

	return eRet;
#endif
}

e_IFX_Return IFX_CIF_UrlFromVLGet(
	                 IN uchar8 ucVoiceLineId,
	                 OUT x_IFX_CalledAddr* pxAddr,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_VoiceLine xLine = {{{{""}}}};
	x_IFX_VMAPI_LineSignaling xLineSig = {{{{""}}}};
	x_IFX_VMAPI_ProfileSignaling xProfileSig = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;
	
	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);

	xLineSig.ucLineId = xLine.ucLineId = ucVoiceLineId;
  xLineSig.iid.config_owner = xLine.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xLine, IFX_CIF_GET_FLAGS))
	{
		xProfileSig.ucProfileId = xLine.ucProfileId;
    xProfileSig.iid.config_owner = IFX_VOIP;
		
		if( IFX_VMAPI_SUCCESS == ifx_get_LineSignaling(&xLineSig,IFX_CIF_GET_FLAGS))
		{
			strcpy(pxAddr->acDisplayName, xLineSig.acSipDispName);
			ifx_vmapi_freeObjectList(&xLineSig, IFX_VMAPI_VL_SIGNALING);
		}
		if( IFX_VMAPI_SUCCESS == 
				ifx_get_ProfileSignaling(&xProfileSig,IFX_CIF_GET_FLAGS))
		{
			strcpy(pxAddr->acUserName,xLine.acDirName);
			strcpy(pxAddr->acCalledAddr,xProfileSig.acUADomain); 
			eRet =  IFX_SUCCESS;
		}
		else
		{
			*peReason = IFX_CIF_CONFIG_ERROR;
		}
	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_VLModeGet(
	                 IN uchar8 ucVoiceLineId,
	                 OUT boolean* pbMode,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);

	xVoiceLine.ucLineId = ucVoiceLineId;
  xVoiceLine.iid.config_owner = IFX_VOIP;

	if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS) )
	{
		*pbMode = xVoiceLine.ucGatewayMode;
		eRet = IFX_SUCCESS;
	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_VLCallWaitingCheck(
	               IN uchar8 ucVoiceLineId,
	               IN boolean* pbEnable,
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);

	xLineCallingFeature.ucLineId = ucVoiceLineId;
  xLineCallingFeature.iid.config_owner = IFX_VOIP;

	*pbEnable = IFX_FALSE;
	if( IFX_VMAPI_SUCCESS == 
		ifx_get_LineCallingFeatures(&xLineCallingFeature,
																			IFX_CIF_GET_FLAGS)  )
	{
		*pbEnable = xLineCallingFeature.bEnableCallWaiting;
		eRet = IFX_SUCCESS;
	} 
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_VLEndptListGet(
	                 IN uchar8 ucVoiceLineId,
									 IN boolean bGwMode,
	                 IN_OUT uchar8* pucSize,
	                 OUT char8 aszEndpointList[][IFX_MAX_ENDPOINTID_LEN],
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);


	if( *pucSize < IFX_MAX_ENDPTS )
	{
		*peReason = IFX_CIF_INSUFFICIENT_ARRAY_SIZE;
		return eRet;
	}
	(*pucSize) = 0;

	xVoiceLine.ucLineId = ucVoiceLineId;
  xVoiceLine.iid.config_owner = IFX_VOIP;

	if( IFX_VMAPI_SUCCESS == 
			(eRet = ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS)) )
	{
		x_IFX_CIF_EndptData* pxEndptData;
		uchar8 ucCount = 0;
		uchar8 ucIndex;
		
		while(ucCount < (2*IFX_VMAPI_MAX_VOICE_INTERFACES+1) && xVoiceLine.ucAssocVoiceInterface[ucCount] > 0)
		{
			  ucIndex  = xVoiceLine.ucAssocVoiceInterface[ucCount]-1;
			pxEndptData = (vxConfigInfo.axEndptData+ucIndex);

			if( (IFX_TRUE == bGwMode && pxEndptData->eType == IFX_EP_FXO) ||
				  (IFX_FALSE == bGwMode && pxEndptData->eType != IFX_EP_FXO) )
			{
			
				strcpy(aszEndpointList[*pucSize],pxEndptData->szEndptId);
				++(*pucSize);
			}
#if 0
			else
			{
				printf("\n%s: Endpoint [%s] is NOT associated with %d line", 
					__FUNCTION__, pxEndptData->szEndptId, ucVoiceLineId);
			}
#endif	
			++ucCount;
		}

	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_VLCodecInfoGet(
	                 IN uchar8 ucVoiceLineId, 
	                 OUT x_IFX_CodecList* pxCodecParams,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCodecList xLineCodecList = {{{{""}}}} ;
	x_IFX_VMAPI_T38Cfg xT38Cfg = {{{{""}}}};
	x_IFX_VMAPI_Misc xMisc = {{{{""}}}};
	bool bSilSup = IFX_FALSE;
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);
	memset(&xT38Cfg,0,sizeof(x_IFX_VMAPI_T38Cfg));
	memset(pxCodecParams,0,sizeof(x_IFX_CodecList));
	xLineCodecList.ucLineId  = ucVoiceLineId;
  xLineCodecList.iid.config_owner = IFX_VOIP;
  xT38Cfg.iid.config_owner = IFX_VOIP;

	if( IFX_VMAPI_SUCCESS == ifx_get_Misc(&xMisc,IFX_CIF_GET_FLAGS)){
		bSilSup = xMisc.bSilenceSupp;
	}

	if(	IFX_VMAPI_SUCCESS == 
		ifx_get_LineCodecList(&xLineCodecList,IFX_CIF_GET_FLAGS) )
	{
		x_IFX_VMAPI_CodecDesc* pxCodecList = xLineCodecList.pxCodecList;
		uchar8 ucCount = 0;
		//CHECK: Is this check needed?
/*		if( xLineCodecList.uiNumCodecs > IFX_MAX_CODECS )
			xLineCodecList.uiNumCodecs = IFX_MAX_CODECS; 
*/
		while(ucCount < IFX_MAX_CODECS-1 && pxCodecList != NULL )
		{
			//TODO : This is temp FIX for G.723 Codec
			if( pxCodecList->uiCodecId == IFX_VMAPI_CODEC_G723)
			{
					pxCodecParams->axCodec[ucCount].uiCodec = 
					  (( xLineCodecList.uiPrefG723Codec == 0)?
						 							IFX_VMAPI_CODEC_G723_5_3:IFX_VMAPI_CODEC_G723_6_3);
       pxCodecParams->axCodec[ucCount].ucFrameSize= pxCodecList->unCodecSuppFrameLen;
			}else if( pxCodecList->uiCodecId == IFX_VMAPI_CODEC_T38)
			{		/* Added For Fax - Chaitanya*/
					ifx_get_SystemT38(&xT38Cfg,0);
					switch(xT38Cfg.ucT38Conn)
					{
						case IFX_VMAPI_FAX_CONN_UDP:
							pxCodecParams->axCodec[ucCount].uiCodec = IFX_T38_UDP;
						break;
						case IFX_VMAPI_FAX_CONN_TCP:
							pxCodecParams->axCodec[ucCount].uiCodec = IFX_T38_TCP;
						break;
						case IFX_VMAPI_FAX_CONN_UDP_TCP:
							pxCodecParams->axCodec[ucCount].uiCodec = IFX_T38_UDP;
							pxCodecParams->axCodec[++ucCount].uiCodec = IFX_T38_TCP;
						break;
						case IFX_VMAPI_FAX_CONN_TCP_UDP:
							pxCodecParams->axCodec[ucCount].uiCodec = IFX_T38_TCP;
							pxCodecParams->axCodec[++ucCount].uiCodec = IFX_T38_UDP;
						break;
					}
			}
			else
				pxCodecParams->axCodec[ucCount].uiCodec = pxCodecList->uiCodecId;

			//TODO: unCodecSuppFrameLen is bit flag. ? Very Imp
       pxCodecParams->axCodec[ucCount].ucFrameSize= pxCodecList->unCodecSuppFrameLen;
	   printf(" CfgIf framelen %d\n",pxCodecList->unCodecSuppFrameLen);
//			pxCodecParams->axCodec[ucCount].ucFrameSize = 20;			
			pxCodecParams->axCodec[ucCount].ucDynPT = pxCodecList->ucPayloadType;
			pxCodecParams->axCodec[ucCount].bSilenceSupp = bSilSup && pxCodecList->bSilenceSupp;
			++ucCount;
			__ifx_list_GetNext((void **)&pxCodecList);	
		}
		/* Free call codec list */
		ifx_vmapi_freeObjectList(&xLineCodecList, IFX_VMAPI_VL_CODECLIST);
		
		if( (pxCodecParams->unNoOfCodecs = ucCount) )
			eRet = IFX_SUCCESS;
	}
	else
	{
		printf("%s: Vmapi get failed\n", __FUNCTION__);
		*peReason = IFX_CIF_CONFIG_ERROR;
	}
	return eRet;
}

e_IFX_Return IFX_CIF_VLRtpMediaCfgGet(
	                 IN uchar8 ucVoiceLineId, 
	                 OUT x_IFX_RtpParams* pRtpMediaCfg,
	                 OUT e_IFX_ReasonCode* peReason  )

{
	x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;
	
	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId, peReason);

	xVoiceLine.ucLineId = ucVoiceLineId;
  xVoiceLine.iid.config_owner = IFX_VOIP;
	printf("IFX_CIF_VLRtpMediaCfgGet Line=%d\n", ucVoiceLineId);
	if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS) &&
			xVoiceLine.ucProfileId > 0 && xVoiceLine.ucProfileId <= IFX_MAX_PROFILES )
	{
	
		printf("IFX_CIF_VLRtpMediaCfgGet Peofile =%d\n", xVoiceLine.ucProfileId);
		
		x_IFX_CIF_ProfileMediaPorts* pxMediaPorts =
										(axProfileMediaPorts + xVoiceLine.ucProfileId -1)	;
		uint16 unStartRtpPort = pxMediaPorts->unNextRtpPort;

		printf("IFX_CIF_VLRtpMediaCfgGet Max and Min Ports: %d %d\n", 
				pxMediaPorts->unMaxRtpPort, pxMediaPorts->unMinFaxPort);

		pRtpMediaCfg->uiLocalRtpPort = 0;
		printf("RTP start:%d Max:%d\n", unStartRtpPort,pxMediaPorts->unMaxRtpPort);
		do {
			if( IFX_SUCCESS == 
					IFX_CIF_IsPortFree(pxMediaPorts->unNextRtpPort, IFX_TRPROTO_UDP) )
			{
				pRtpMediaCfg->uiLocalRtpPort = pxMediaPorts->unNextRtpPort;
				pRtpMediaCfg->uiLocalRtcpPort = pxMediaPorts->unNextRtpPort+1;
				//Currently only RTP ports are reserved
				IFX_CIF_AllocPort(pRtpMediaCfg->uiLocalRtpPort,IFX_TRPROTO_UDP);
				//IFX_CIF_AllocPort(pRtpMediaCfg->uiLocalRtpPort,IFX_TRPROTO_UDP);
			}
			pxMediaPorts->unNextRtpPort += 2; 
			if( pxMediaPorts->unNextRtpPort  > pxMediaPorts->unMaxRtpPort )
				pxMediaPorts->unNextRtpPort = pxMediaPorts->unMinRtpPort;
				
		} while( unStartRtpPort != pxMediaPorts->unNextRtpPort 
						 && 0 == pRtpMediaCfg->uiLocalRtpPort );
		
		if( pRtpMediaCfg->uiLocalRtpPort )
		{
			pRtpMediaCfg->eSdpMode = IFX_SENDRECV;
			IFX_OS_GetHostIp((char8 *)pRtpMediaCfg->szLocalRtpIpAddr);
			eRet = IFX_SUCCESS;
		}
	}
	else
	{
		printf("IFX_CIF_VLRtpMediaCfgGet failied to get line info\n" );
		*peReason = IFX_CIF_CONFIG_ERROR;
	}
	
	return eRet ;
}

e_IFX_Return IFX_CIF_VLFaxMediaCfgGet(
	                 IN uchar8 ucVoiceLineId,
									 IN uint32 uiFaxTrProto, 
	                 OUT x_IFX_FaxParams* pxFaxParms,
									 OUT boolean* pbSupported,
	                 OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_T38Cfg xT38SysCfg = {{{{""}}}};
	x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
	x_IFX_VMAPI_FaxT38 xT38Prfl = {{{{""}}}};

	memset(pxFaxParms, 0, sizeof(x_IFX_FaxParams));
	*pbSupported	= IFX_FALSE;
	xT38SysCfg.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_SystemT38(&xT38SysCfg, IFX_CIF_GET_FLAGS) )
	{
    if( xT38SysCfg.ucT38Conn > IFX_VMAPI_FAX_CONN_TCP )
			*pbSupported = IFX_TRUE;
		else if( IFX_TRPROTO_UDP == uiFaxTrProto && xT38SysCfg.ucT38Conn == IFX_VMAPI_FAX_CONN_UDP )
			*pbSupported = IFX_TRUE;
		else if(IFX_TRPROTO_TCP == uiFaxTrProto && xT38SysCfg.ucT38Conn == IFX_VMAPI_FAX_CONN_TCP )
			*pbSupported = IFX_TRUE;
		else
			return IFX_SUCCESS ; /* Request protocol not supported */

		xVoiceLine.ucLineId = ucVoiceLineId;
    xVoiceLine.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS))
		{
			xT38Prfl.ucProfileId = xVoiceLine.ucProfileId;
      xT38Prfl.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == 
					ifx_get_ProfileMediaFaxT38(&xT38Prfl ,IFX_CIF_GET_FLAGS) )
			{
				x_IFX_CIF_ProfileMediaPorts *pxMediaPorts = 
								(axProfileMediaPorts+xVoiceLine.ucProfileId -1);
				uint16 unStartFaxPort = pxMediaPorts->unNextFaxPort;
				/* Copy fax params to pxFaxParms */
				pxFaxParms->xFaxCfg.uiTransportProtocol = uiFaxTrProto;
				pxFaxParms->xFaxCfg.ucVersion = 0;
				//xT38Prfl.ucTCFMethodTcp
				//xT38Prfl.ucTCFMethodUdp
				//xT38Prfl.uiHighSpeedPacketRate
				pxFaxParms->xFaxCfg.uiBitOptions = 0;
				if(IFX_TRPROTO_UDP == uiFaxTrProto )
				{
					pxFaxParms->xFaxCfg.unMaxBitRate = xT38Prfl.uiBitRateUdp;
					pxFaxParms->xFaxCfg.ucRateManagement = xT38Prfl.ucTCFMethodUdp;
					pxFaxParms->xFaxCfg.unUDPMaxBufferSize = xT38Prfl.unUDPMaxBufferSize;
					pxFaxParms->xFaxCfg.unUDPMaxDatagramSize = xT38Prfl.unUDPMaxDatagramSize;
					pxFaxParms->xFaxCfg.ucUDPErrCorrection = xT38Prfl.ucUDPErrCorrection;
				}
				else //IFX_TRPROTO_TCP
				{
					pxFaxParms->xFaxCfg.ucRateManagement = xT38Prfl.ucTCFMethodTcp;
					pxFaxParms->xFaxCfg.unMaxBitRate = xT38Prfl.uiBitRateTcp;
				}

				/* Allocate FAX port */
				do {
					if( IFX_SUCCESS ==
							IFX_CIF_IsPortFree(pxMediaPorts->unNextFaxPort, uiFaxTrProto) )
					{
						pxFaxParms->uiLocalFaxPort = pxMediaPorts->unNextFaxPort;
						IFX_CIF_AllocPort(pxFaxParms->uiLocalFaxPort, uiFaxTrProto);
					}
					
					pxMediaPorts->unNextFaxPort += 2;
					if( pxMediaPorts->unNextFaxPort > pxMediaPorts->unMaxFaxPort )
						pxMediaPorts->unNextFaxPort = pxMediaPorts->unMinFaxPort;
						
				} while( unStartFaxPort != pxMediaPorts->unNextFaxPort &&
						0 == pxFaxParms->uiLocalFaxPort );
				
				if( pxFaxParms->uiLocalFaxPort )
				{
					IFX_OS_GetHostIp((char8 *)pxFaxParms->szLocalFaxIpAddr);
					eRet = IFX_SUCCESS;
				}
			}
		}
	}
	
	return eRet ;
}

e_IFX_Return IFX_CIF_ReleasePort(uint16 unPort, e_IFX_TransportType ePortType)
{
	return IFX_CIF_FreePort(unPort, ePortType);
}

e_IFX_Return IFX_CIF_VLCallFwdInfoGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN e_IFX_CallForwardType eCfType,
	                 OUT boolean* pbEnabled,
									 OUT uchar8* pucRingCount,
	                 OUT x_IFX_CalledAddr* pxCfAddr,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);

	xLineCallingFeature.ucLineId = ucVoiceLineId;
  xLineCallingFeature.iid.config_owner = IFX_VOIP;

	*pbEnabled = IFX_FALSE;
	*pucRingCount = 0;

	if( IFX_VMAPI_SUCCESS == ifx_get_LineCallingFeatures(
		&xLineCallingFeature,	IFX_CIF_GET_FLAGS) )
	{
		x_IFX_VMAPI_Address* pxVmapiAddr = 0;
	
		*pbEnabled = (xLineCallingFeature.unCallFwdCfg & eCfType)?IFX_TRUE:IFX_FALSE;

		if((xLineCallingFeature.unCallFwdCfg & IFX_VMAPI_CALL_FWD_VOICE_MAIL) ||  eCfType == IFX_CALL_FWD_VOICE_MAIL)
		{
			uint16 unExpTime;
			printf("$$$<IFX_CIF_VLCallFwdInfoGet> **** Voice-Mail Enabled : \n");
			/* Get VM deposit address */
			eRet =  IFX_CIF_VLVMSubEventGet( ucVoiceLineId,IFX_TRUE, 
																						pxCfAddr,&unExpTime);
			if(eCfType == IFX_CALL_FWD_ON_NO_ANSWER)
			{
				*pucRingCount = xLineCallingFeature.ucCfnaRingCount; 
			}
		}
		else
		{
			if(eCfType == IFX_CALL_FWD_UNCONDITIONAL)
				pxVmapiAddr = &xLineCallingFeature.xCfuAddress;
			else if(eCfType == IFX_CALL_FWD_BUSY)
				pxVmapiAddr = &xLineCallingFeature.xCfbAddress;
			else if(eCfType == IFX_CALL_FWD_ON_NO_ANSWER)
			{
				pxVmapiAddr = &xLineCallingFeature.xCfnaAddress;
				*pucRingCount = xLineCallingFeature.ucCfnaRingCount; 
			}
			else if(eCfType == IFX_CALL_FWD_DND)
				pxVmapiAddr = &xLineCallingFeature.xDndAddress;

			/* If pxVmapiAddr is null, then call forwarded to voice mail */
			if( pxVmapiAddr && *pbEnabled )
			{
				ifx_cif_cpyFromVmapiAddr(pxCfAddr,pxVmapiAddr);
			}
			eRet = IFX_SUCCESS;
		}
	} 
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}
						printf("$$$$ FWD-Mail Port: %d\n",pxCfAddr->unPort);
						printf("$$$$ FWd Protocol: %d\n",pxCfAddr->ucAddrProto);
            printf("$$$$ Address: %s\n",pxCfAddr->acCalledAddr);

	return eRet;
}

e_IFX_Return IFX_CIF_VLDNDStatusGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN boolean* pbEnable, 
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	*pbEnable = IFX_FALSE;
	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);
	xLineCallingFeature.ucLineId = ucVoiceLineId;
  xLineCallingFeature.iid.config_owner = IFX_VOIP;

	if( IFX_VMAPI_SUCCESS == ifx_get_LineCallingFeatures(
			&xLineCallingFeature, IFX_CIF_GET_FLAGS) )
	{
		*pbEnable = xLineCallingFeature.bEnableDnd;
		eRet = IFX_SUCCESS;
	} 
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_VLAnonCallBlkStatusGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN boolean* pbEnable, 
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	*pbEnable = IFX_FALSE;
	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);
	xLineCallingFeature.ucLineId = ucVoiceLineId;
  xLineCallingFeature.iid.config_owner = IFX_VOIP;

	if( IFX_VMAPI_SUCCESS == ifx_get_LineCallingFeatures(
			&xLineCallingFeature, IFX_CIF_GET_FLAGS) )
	{
		*pbEnable = xLineCallingFeature.bEnableAcb;
		eRet = IFX_SUCCESS;
	} 
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_VLCidStatusGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN boolean* pbEnable, 
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	*pbEnable = IFX_FALSE;
	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);
	xLineCallingFeature.ucLineId = ucVoiceLineId;
  xLineCallingFeature.iid.config_owner = IFX_VOIP;

	if( IFX_VMAPI_SUCCESS == ifx_get_LineCallingFeatures(
			&xLineCallingFeature, IFX_CIF_GET_FLAGS) )
	{
		*pbEnable = xLineCallingFeature.bEnableCid;
		eRet = IFX_SUCCESS;
	} 
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_CallRegisterAdd(
	                 IN e_IFX_CallRegisterType eCrType,
	                 IN uchar8 ucLineId,
	                 IN x_IFX_CMGR_AddressInfo* pxAddr,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_CallRegEntry xRegEntry = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE ;

  printf("\nEntry IFX_CIF_CallRegisterAdd.\n");
	if(!pxAddr)
		return eRet;
  if((!strcmp(pxAddr->uxAddressInfo.xVoipAddr.acDisplayName,"\"Anonymous\""))
                            ||(!strcmp(pxAddr->uxAddressInfo.xVoipAddr.acUserName,"anonymous"))){

    printf("\nAnonymous Call\n");
    return IFX_SUCCESS;
    }
	memset(&xRegEntry,0,sizeof(xRegEntry));
  xRegEntry.iid.config_owner = IFX_VOIP;
  xRegEntry.ucLineId = ucLineId;
  /* Contact List Mapping */
  x_IFX_VMAPI_ContactList xVmapiContacts;
	x_IFX_VMAPI_ContactListEntry *pxTemp=NULL;
	memset(&xVmapiContacts,0,sizeof(xVmapiContacts));
	xVmapiContacts.iid.config_owner = IFX_VOIP;
	if(IFX_VMAPI_SUCCESS == 
		 ifx_get_CommonContactList (&xVmapiContacts,IFX_VMAPI_OP_DEFAULT)){

        pxTemp = xVmapiContacts.pxContactEntries;
        if(IFX_CMGR_TYPE_VOIP == pxAddr->eAddressType){
				   while(pxTemp != NULL){
printf("Call Register Add name %s\n",pxTemp->xAddress.acUserFirstName);
printf("Call Register Add Last name %s\n",pxTemp->xAddress.acUserLastName);
printf("Call Register Contact Number  %s\n",pxTemp->xAddress.acContactNum);

             		if((!strcmp(pxTemp->xAddress.acContactNum,pxAddr->uxAddressInfo.xVoipAddr.acUserName))||
									(!strcmp(pxTemp->xAddress.acContactNumTwo,pxAddr->uxAddressInfo.xVoipAddr.acUserName)))       
               		break;
      		  __ifx_list_GetNext((void *)&pxTemp);
           }
        }else if(IFX_CMGR_TYPE_FXO == pxAddr->eAddressType){
				   while(pxTemp != NULL){
             		if((!strcmp(pxTemp->xAddress.acContactNum,pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber))||
									(!strcmp(pxTemp->xAddress.acContactNumTwo,pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber)))       
               		break;
      		  __ifx_list_GetNext((void *)&pxTemp);
           }
				}
  }
	if( pxTemp == NULL ){
	memset(&xVmapiContacts,0,sizeof(xVmapiContacts));
	xVmapiContacts.iid.config_owner = IFX_VOIP;
	xVmapiContacts.ucLineId = ucLineId;
	if( IFX_VMAPI_SUCCESS == 
		 ifx_get_ContactList (&xVmapiContacts,IFX_VMAPI_OP_DEFAULT)){
        pxTemp = xVmapiContacts.pxContactEntries;
        if(IFX_CMGR_TYPE_VOIP == pxAddr->eAddressType){
				   while(pxTemp != NULL){
printf("Call Register Add name %s\n",pxTemp->xAddress.acUserFirstName);
printf("Call Register Add Last name %s\n",pxTemp->xAddress.acUserLastName);
printf("Call Register Contact Number  %s\n",pxTemp->xAddress.acContactNum);

             		if((!strcmp(pxTemp->xAddress.acContactNum,pxAddr->uxAddressInfo.xVoipAddr.acUserName))||
									(!strcmp(pxTemp->xAddress.acContactNumTwo,pxAddr->uxAddressInfo.xVoipAddr.acUserName)))       
               		break;
      		  __ifx_list_GetNext((void *)&pxTemp);
           }
        }else if(IFX_CMGR_TYPE_FXO == pxAddr->eAddressType){
				   while(pxTemp != NULL){
             		if((!strcmp(pxTemp->xAddress.acContactNum,pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber))||
									(!strcmp(pxTemp->xAddress.acContactNumTwo,pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber)))       
               		break;
      		  __ifx_list_GetNext((void *)&pxTemp);
           }
				}
  }
}
  /* End Contact List Mapping */
  printf("\nLine Id:%d\n",ucLineId);
	if(IFX_CMGR_TYPE_VOIP == pxAddr->eAddressType)
	{
    printf("\nAddress Type: VOIP\n");
		xRegEntry.eCallType = IFX_VOIP_NUM;
		ifx_cif_cpyToVmapiAddr(&xRegEntry.xAddress,
										&pxAddr->uxAddressInfo.xVoipAddr);
    if(pxTemp!=NULL)
		  strcpy(xRegEntry.xAddress.acDisplayName,pxTemp->xAddress.acUserLastName);
      
  	//xRegEntry.ucLineId = ucLineId;
		
	}else if (IFX_CMGR_TYPE_FXO == pxAddr->eAddressType)
	{
    printf("\nAddress Type: FXO\n");
		xRegEntry.eCallType = IFX_PSTN_NUM;
    printf("\n Username:%s\n",pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber);
    if(strcmp(pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber,"")){
		  strcpy(xRegEntry.xAddress.acUserName,
							pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber);

		  strcpy(xRegEntry.xAddress.acDisplayName,
							pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber);
			if(pxTemp!=NULL)
      	strcpy(xRegEntry.xAddress.acDisplayName,pxTemp->xAddress.acUserLastName);
    }else{

		  strcpy(xRegEntry.xAddress.acUserName,"0000");

		  strcpy(xRegEntry.xAddress.acDisplayName,"Unknown");
     }
		/*strcpy(xRegEntry.xAddress.acDestAddr,
												pxAddr->uxAddressInfo.xFxoInfo.szPhoneNumber);*/
	}
	else
	{
		/*Error - Its an invalid point*/

    printf("\nError Invalid Input\n");
		return eRet;
	}

	ifx_vmapi_freeObjectList(&xVmapiContacts, IFX_VMAPI_VS_CONTACT_LIST);
	IFX_GetDateTime(xRegEntry.acCallDate, xRegEntry.acCallTime);
	
	if( IFX_CR_DIALED == eCrType )
	{
    printf("UPDATE DIALLED CALL LIST !!!!!!!!\n");
#if 0	 
    if('\0' == xRegEntry.xAddress.acDisplayName[0]){
			strcpy(xRegEntry.xAddress.acDisplayName,xRegEntry.xAddress.acUserName);
		}
#endif	 
		eRet = ( IFX_VMAPI_SUCCESS == ifx_set_DialCallRegEntry(
						 IFX_CIF_OPP_ADD_FLAG, &xRegEntry, IFX_CIF_ADD_FLAG) 
						)?IFX_SUCCESS:IFX_FAILURE;
	}
	else if( IFX_CR_RECEIVED == eCrType )
	{
    printf("UPDATE RECEIVED CALL LIST !!!!!!!!\n");
		eRet = ( IFX_VMAPI_SUCCESS == ifx_set_RecvCallRegEntry(
						 IFX_CIF_OPP_ADD_FLAG, &xRegEntry, IFX_CIF_ADD_FLAG) 
						)?IFX_SUCCESS:IFX_FAILURE;
	}		
	else if( IFX_CR_MISSED == eCrType )
	{
    printf("UPDATE MISSED CALL LIST !!!!!!!!\n");
    viNewMissedCall = 1;
		eRet = ( IFX_VMAPI_SUCCESS == ifx_set_MissCallRegEntry(
						 IFX_CIF_OPP_ADD_FLAG, &xRegEntry, IFX_CIF_ADD_FLAG) 
						)?IFX_SUCCESS:IFX_FAILURE;
	}	
#if 0
	if( IFX_SUCCESS != eRet )
	{
		printf("\n%s : FAILED TO ADD Call Register Entry (Reg Type=%d)",
			__FUNCTION__,eCrType);
	}
#endif

  printf("\neRet=%d\n",eRet);
	return eRet;
}



e_IFX_Return IFX_CIF_CallReturnAddrGet(
	                 IN  char8* szEndptId,
									 OUT x_IFX_CMGR_AddressInfo* pxCallRetAddr,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_CallRegister xVmapiCallReg = {{{{""}}}};
	x_IFX_VMAPI_CallRegEntry xRecvEntry = {{{{""}}}};
	x_IFX_VMAPI_CallRegEntry	xMissEntry = {{{{""}}}};	
	x_IFX_VMAPI_CallRegEntry *pxCallRegEntry = NULL;
	x_IFX_VMAPI_CallRegEntry *pxListHead = NULL;
	boolean bRecvAddr = IFX_FALSE;
	boolean bMissAddr = IFX_FALSE;
	uchar8 ucLineId = 0;
	e_IFX_Return eRet;

	IFX_CIF_EndptDefaultVLGet(szEndptId, &ucLineId, peReason );
	
	memset(pxCallRetAddr, 0, sizeof(x_IFX_CMGR_AddressInfo));
	memset(&xVmapiCallReg,0,sizeof(x_IFX_VMAPI_CallRegister));
  
  xVmapiCallReg.ucLineId=ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_RecvCallReg(
										&xVmapiCallReg,IFX_CIF_GET_FLAGS) )
	{
		pxCallRegEntry =  pxListHead = xVmapiCallReg.pxCallRegEntries;
		if( pxListHead != NULL )
		{	
			do {
				__ifx_list_GetPrev((void**)&pxCallRegEntry);
				if (pxCallRegEntry == NULL)
					break;
				
				if((pxCallRegEntry->eCallType == IFX_PSTN_NUM) || 
					 (pxCallRegEntry->ucLineId == ucLineId)	)
				{
					bRecvAddr = IFX_TRUE;
					memcpy(&xRecvEntry, pxCallRegEntry,sizeof(x_IFX_VMAPI_CallRegEntry) );
					break;
				}
			}while( pxListHead != pxCallRegEntry  );
		}	

		ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_RECVCALL_REGISTER);
	}		

	memset(&xVmapiCallReg,0,sizeof(x_IFX_VMAPI_CallRegister));
  xVmapiCallReg.ucLineId=ucLineId;
  xVmapiCallReg.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_MissCallReg(
										&xVmapiCallReg,IFX_CIF_GET_FLAGS))
	{
		pxCallRegEntry = pxListHead = xVmapiCallReg.pxCallRegEntries;
		
		if( pxListHead != NULL )
		{
			do {
				__ifx_list_GetPrev((void**)&pxCallRegEntry);
				if( pxCallRegEntry != NULL && (pxCallRegEntry->eCallType == IFX_PSTN_NUM || 
					 pxCallRegEntry->ucLineId == ucLineId)	)
				{
					bMissAddr = IFX_TRUE;
					memcpy(&xMissEntry, pxCallRegEntry,sizeof(x_IFX_VMAPI_CallRegEntry) );
					break;
				}
			}while( pxListHead != pxCallRegEntry );
		}

		ifx_vmapi_freeObjectList(&xVmapiCallReg, IFX_VMAPI_VS_MISSCALL_REGISTER);
	}	

	if( !bRecvAddr && !bMissAddr )
	{
		eRet = IFX_FAILURE;
	}
	else
	{
		if( bRecvAddr && bMissAddr )
		{
			char8 acRecvCallTime[2*IFX_VMAPI_MAX_TIME_STR_LEN+1];
			char8 acMissCallTime[2*IFX_VMAPI_MAX_TIME_STR_LEN+1];
			int32 iCmp = 0;
			
			sprintf(acRecvCallTime, "%s %s",
				xRecvEntry.acCallDate, xRecvEntry.acCallTime);
			sprintf(acMissCallTime, "%s %s",
				xMissEntry.acCallDate, xMissEntry.acCallTime);
			if( IFX_FAILURE != 
					(iCmp = IFX_CompareDateTime(acRecvCallTime, acMissCallTime)))
			{
				bRecvAddr = (1 == iCmp)?IFX_TRUE:IFX_FALSE;
			}
		}
		
		pxCallRegEntry = (IFX_TRUE == bRecvAddr)?&xRecvEntry:&xMissEntry;


		if(IFX_VOIP_NUM == pxCallRegEntry->eCallType )
		{
			/* Voip Call */
			pxCallRetAddr->eAddressType = IFX_CMGR_TYPE_VOIP;
			ifx_cif_cpyFromVmapiAddr(&pxCallRetAddr->uxAddressInfo.xVoipAddr,
					&pxCallRegEntry->xAddress);
		}
		else
		{
			/* PSTN call */
			pxCallRetAddr->eAddressType = IFX_CMGR_TYPE_FXO;
			strcpy(pxCallRetAddr->uxAddressInfo.xFxoInfo.szPhoneNumber,
					pxCallRegEntry->xAddress.acUserName);
		}

		eRet = IFX_SUCCESS;
	}

	return eRet;
}

e_IFX_Return IFX_CIF_VLJBCfgGet(
	                 IN uchar8 ucVoiceLineId,
	                 OUT x_IFX_MMGR_JitterBuffer_Conf* pxJB_Conf,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);
	
	xVoiceLine.ucLineId = ucVoiceLineId;
  xVoiceLine.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS) )
	{				
		x_IFX_VMAPI_ProfileMediaRTP xPrfRtpMedia = {{{{""}}}};
		xPrfRtpMedia.ucProfileId = xVoiceLine.ucProfileId;
    xPrfRtpMedia.iid.config_owner = IFX_VOIP;
	
		if( IFX_VMAPI_SUCCESS == 
				ifx_get_ProfileMediaRTP(&xPrfRtpMedia, IFX_CIF_GET_FLAGS) )
		{
			memset(pxJB_Conf,0,sizeof(x_IFX_MMGR_JitterBuffer_Conf));
			if( IFX_JB_FIXED == xPrfRtpMedia.ucJbType)
				pxJB_Conf->ucJBType =  IFX_MMGR_JB_TYPE_FIXED;
			else
				pxJB_Conf->ucJBType =  IFX_MMGR_JB_TYPE_ADAPTIVE;

			pxJB_Conf->ucPacketAdaptation = IFX_MMGR_PACKET_ADAPT_VOICE;
			pxJB_Conf->ucscaling =  xPrfRtpMedia.ucScalingFactor;
			pxJB_Conf->unInitialSize =  xPrfRtpMedia.unInitialSize;
			pxJB_Conf->unMaxSize =  xPrfRtpMedia.unMaxSize ;
			pxJB_Conf->unMinSize = xPrfRtpMedia.unMinSize ;
			eRet = IFX_SUCCESS;
		}
#if 0
		else
		{
				printf("\nifx_get_ProfileMediaRTP Failed (Profile Id = %d",
						xVoiceLine.ucProfileId);
		}
#endif
	}
#if 0
	else
	{
		printf("\nifx_get_VoiceLine Failed (Voice Line Id=%d",ucVoiceLineId);
	}
#endif
	
	if( IFX_SUCCESS != eRet)
		*peReason = IFX_CIF_CONFIG_ERROR;

	return eRet ;
}

//TODO: Where is SID for voice line ??
/* For getting the silence supression configured on the Line*/
e_IFX_Return IFX_CIF_VLSIDCheck(
	                 IN uchar8 ucLineId,
	                 OUT boolean* pbSidStatus,
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_Misc xMisc = {{{{""}}}};

  xMisc.iid.config_owner = IFX_VOIP;

  if( IFX_VMAPI_SUCCESS == ifx_get_Misc(&xMisc,IFX_CIF_GET_FLAGS)){
		*pbSidStatus = xMisc.bSilenceSupp;
	}else{
		*pbSidStatus = IFX_FALSE;
	}

	return IFX_SUCCESS;
}

e_IFX_Return IFX_CIF_VLDigitMethodGet(
	                 IN uchar8 ucVoiceLineId,
	                 OUT e_IFX_DtmfType* peType,
	                 OUT uint16*punDynPayNum, 
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	*peType = IFX_DTMF_NONE;
	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);
	
	xVoiceLine.ucLineId = ucVoiceLineId;
  xVoiceLine.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS) )
	{
		x_IFX_VMAPI_VoiceProfile xProfile = {{{{""}}}};

		xProfile.ucProfileId = xVoiceLine.ucProfileId;
    xProfile.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS == 
				ifx_get_VoiceProfile(&xProfile,IFX_CIF_GET_FLAGS))
		{
			*peType = xProfile.ucDtmfMethod;
			*punDynPayNum = xProfile.ucDtmfPayloadType;
			eRet = IFX_SUCCESS;
		}
		else
		{
			*peReason = IFX_CIF_CONFIG_ERROR;
		}
	}

	return eRet;
}

e_IFX_Return
IFX_CIF_ProfileIdListGet(uchar8 *pucProfileId)
{
	x_IFX_VMAPI_VoiceService xVoiceSrv = {{{{""}}}};
  
  xVoiceSrv.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVoiceSrv,IFX_CIF_GET_FLAGS))
	{
		return IFX_FAILURE;
	}

	memcpy(pucProfileId, xVoiceSrv.ucProfileIdList, IFX_MAX_PROFILES);

	return IFX_SUCCESS ;
}

e_IFX_Return
IFX_CIF_LineIdListGet(uchar8 *pucLineId)
{
	x_IFX_VMAPI_VoiceService xVoiceSrv = {{{{""}}}};
  
  xVoiceSrv.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS != ifx_get_VoiceService(&xVoiceSrv,IFX_CIF_GET_FLAGS))
	{
		return IFX_FAILURE;
	}

	memcpy(pucLineId, xVoiceSrv.ucLineIdList, (2*IFX_VMAPI_MAX_VOICE_LINES+1));
  printf("Line Ids from Line Id list get: %d %d\n",pucLineId[0],pucLineId[1]);
	return IFX_SUCCESS ;
}
e_IFX_Return IFX_CIF_VLVMSubEventGet(
	               IN uchar8 ucVoiceLineId,
	               IN boolean bDepositAddr,
	               OUT x_IFX_CalledAddr* pxAddr,
	               OUT uint16* punSubExpiryTime )
{
	x_IFX_VMAPI_LineSubscription xLineSub = {{{{""}}}};
	x_IFX_VMAPI_EventSubscribe xEventSub = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;
	
	xLineSub.ucLineId = ucVoiceLineId;
  xLineSub.iid.config_owner = IFX_VOIP;
	
	if( IFX_VMAPI_SUCCESS == 
		ifx_get_LineSubscription(&xLineSub,IFX_CIF_GET_FLAGS) )
	{
		x_IFX_VMAPI_LineEvents *pxLineEvent = xLineSub.pxLineEvents;
		uchar8 ucIndex = 0;
		
		while(pxLineEvent != NULL)
		{
			if(pxLineEvent->uiSubspnEvent == IFX_VMAPI_VL_SUBS_EVENT_MWI )
				break;
			__ifx_list_GetNext((void**)&pxLineEvent);
		}
		/* Find Event Subscribe entry for voice mail server */
		if( pxLineEvent )
		{
			do {
				xEventSub.ucIndex = ++ucIndex;
				xEventSub.ucProfileId = 1; //xLineSub.ucProfileId; //TODO
        xEventSub.iid.config_owner = IFX_VOIP;
				if( IFX_VMAPI_SUCCESS == 
					ifx_get_EventSubscribe(&xEventSub,IFX_CIF_GET_FLAGS) )
				{
					if( xEventSub.uiEvent == IFX_VMAPI_VL_SUBS_EVENT_MWI )
					{
						memset(pxAddr,0,sizeof(x_IFX_CalledAddr));
						pxAddr->ucAddrType = IFX_IP_ADDR;
						pxAddr->unPort = xEventSub.unNotifierPort;
						pxAddr->ucAddrProto = xEventSub.ucNotifierProtocol;
						printf("$$$$< IFX_CIF_VLVMSubEventGet> Voice-Mail Port: %d\n",xEventSub.unNotifierPort);
						printf("$$$$< IFX_CIF_VLVMSubEventGet> Voice-Mail Protocol: %d\n",xEventSub.ucNotifierProtocol);
	
					if(IFX_TRUE == bDepositAddr)
							strcpy(pxAddr->acUserName, pxLineEvent->acSubspnUsrName);
						else
							strcpy(pxAddr->acUserName,xLineSub.acMwiRetrieveUsrName);
						if(xEventSub.acNotifierAddr[0] == '\0'){
						  eRet = IFX_FAILURE;
							break;
		        }
						printf("$$$$< IFX_CIF_VLVMSubEventGet> Voice-Mail Address: %s\n",xEventSub.acNotifierAddr);
						strcpy(pxAddr->acCalledAddr,xEventSub.acNotifierAddr);
						*punSubExpiryTime = xEventSub.unSubscriptionTime;
						eRet = IFX_SUCCESS;
						break;
					}
				} 
				else {
					break;		
				}
			} while(1);
		}	//	if( pxLineEvent )

		ifx_vmapi_freeObjectList(&xLineSub,IFX_VMAPI_VL_EVENT_SUBSCR);
	}
#if 0	
	else {
		printf("\n%s: ifx_get_LineSubscription FAILED",__FUNCTION__);
	}
#endif
	return eRet;
}

e_IFX_Return IFX_CIF_UpdateProfilePorts(uchar8 ucProfileId)
{
	x_IFX_VMAPI_ProfileMediaRTP xPrfMediaRtp = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	if( ucProfileId > 0 && ucProfileId <= IFX_MAX_PROFILES ) {

		xPrfMediaRtp.ucProfileId = ucProfileId;
    xPrfMediaRtp.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != 
			ifx_get_ProfileMediaRTP(&xPrfMediaRtp, IFX_CIF_GET_FLAGS) ) {
			eRet = IFX_FAILURE;
		} else {
			--ucProfileId;
		 /*	printf("Rtp Port Range :: %d-%d\n", xPrfMediaRtp.unMinRtpPort,
																								xPrfMediaRtp.unMaxRtpPort);	*/
			axProfileMediaPorts[ucProfileId].unNextRtpPort =  
			axProfileMediaPorts[ucProfileId].unMinRtpPort = xPrfMediaRtp.unMinRtpPort;
			axProfileMediaPorts[ucProfileId].unMaxRtpPort = xPrfMediaRtp.unMaxRtpPort;

			axProfileMediaPorts[ucProfileId].unNextFaxPort = 
			axProfileMediaPorts[ucProfileId].unMinFaxPort = xPrfMediaRtp.unMinFaxPort;
			axProfileMediaPorts[ucProfileId].unMaxFaxPort = xPrfMediaRtp.unMaxFaxPort;
			eRet = IFX_SUCCESS;
		}
	}
	return eRet;
}

e_IFX_Return IFX_CIF_RemoveMediaPorts(
	                   uchar8 ucLineId )
{
	return IFX_FAILURE;
}

#ifdef ENABLE_DBG_THR_PHONE
e_IFX_Return IFX_CIF_DebugSet( boolean bEnableDbg )
{
	x_IFX_VMAPI_SystemDebugSettings xDbg = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;
  
  xDbg.iid.config_owner = IFX_VOIP;
  if( IFX_VMAPI_SUCCESS == ifx_get_DbgSettings(&xDbg,IFX_CIF_GET_FLAGS))
	{
	
		if(  bEnableDbg )
		{	
			xDbg.xAgentsDbg.ucDbgType = xDbg.xSipDbg.ucDbgType = 1;
			xDbg.xAgentsDbg.ucDbgLvl = xDbg.xSipDbg.ucDbgLvl = 4;
		}
		else
		{
			xDbg.xAgentsDbg.ucDbgType = xDbg.xSipDbg.ucDbgType = 0;
			xDbg.xAgentsDbg.ucDbgLvl = xDbg.xSipDbg.ucDbgLvl = 0;
		}
			
		eRet = (IFX_VMAPI_SUCCESS == ifx_set_DbgSettings(IFX_CIF_SETOPP_FLAG, 
						&xDbg, IFX_CIF_MOD_FLAG))? IFX_SUCCESS:IFX_FAILURE;
		IFX_CFG_DebugSetttingsNtfyHdlr(&xDbg, &xDbg);
	}
	return eRet;
}
#endif
/*!
  \brief This function retrieves gaussian value configured for DECT system.   
  \param[out] pucDbgType Debug type
  \param[out] pucDbgLvl Debug level
  \return IFX_SUCCESS or IFX_FAILURE.
*/
e_IFX_Return IFX_CIF_DectDbgGet(OUT uchar8 *pucDbgType, OUT uchar8 *pucDbgLvl)
{
 	x_IFX_VMAPI_SystemDebugSettings xDbg = {{{{""}}}};
	//e_IFX_Return eRet = IFX_FAILURE;

  xDbg.iid.config_owner = IFX_VOIP;
  if( IFX_VMAPI_SUCCESS == ifx_get_DbgSettings(&xDbg,IFX_CIF_GET_FLAGS))
	{
	
			*pucDbgType = xDbg.xAgentsDbg.ucDbgType;
			*pucDbgLvl = xDbg.xAgentsDbg.ucDbgLvl;
	}
    return IFX_SUCCESS;
}
				
#ifdef LTAM
e_IFX_Return IFX_CIF_LineTestResultSet(char8* pszEndpt,
								x_IFX_VMAPI_VoiceServTestResult* pxPhyIntTestRes)
{
  x_IFX_VMAPI_VoiceServPhyIfTest xPhyIntTest = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	//printf("Calling ifx_get_VoicePhyInterface Result\n--------------------\n");
	//if( IFX_VMAPI_SUCCESS == ifx_get_PhyInterfaceTestResult(&xPhyIntTestRes, 0) )
	{	
		//if( IFX_VMAPI_SUCCESS == ifx_set_PhyInterfaceTestResult(IFX_OP_MOD,&xPhyIntTestRes, 0) )
    pxPhyIntTestRes->iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS == ifx_set_PhyInterfaceTestResult(IFX_OP_MOD, pxPhyIntTestRes, 0) )
		{
		  xPhyIntTest.iid.config_owner = IFX_VOIP;
			if( IFX_VMAPI_SUCCESS == ifx_get_PhyInterfaceTest(&xPhyIntTest, 0) )
			{
				xPhyIntTest.ucTestState = IFX_VMAPI_TEST_STATE_SUCCESS; 
				eRet = (IFX_VMAPI_SUCCESS == 
							ifx_set_PhyInterfaceTest(IFX_CIF_SETOPP_FLAG,
																			 &xPhyIntTest, 
																				IFX_CIF_MOD_FLAG))?IFX_SUCCESS:IFX_FAILURE;
			}
		}
	}
	
	return eRet;
}
#endif

#if defined(DECT_SUPPORT)

#ifdef DECT_PART
void LTQ_Init_ParamsFromDectPart(){
	//e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_TransmitPowerParam xTransPower;
	x_IFX_VMAPI_DectBMCParams xBMCParams ;
	x_IFX_VMAPI_DectOscTrimVal xOscParams;
	x_IFX_VMAPI_DectGFSKVal xGfsk;
	uint32 uiFlag = IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ | IFX_VMAPI_DO_NOT_WRITE_TO_DECT_PART; 

	//read the dect config partition
	//system("/etc/rc.d/read_dect_config");

	//TPC Settings...
	memset(&xTransPower, 0 , sizeof(x_IFX_VMAPI_TransmitPowerParam));
  xTransPower.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
      ifx_get_TransPower(&xTransPower,1)){

			if(ifx_set_TransPower(IFX_OP_MOD,&xTransPower,uiFlag) != IFX_VMAPI_SUCCESS){
						printf("$$$$$$$$$$$ Configuring Transpower from dect config failed....!\n");
			}
	}else
						printf("$$$$$$$$$$$$$$$$$$$ Reading Transpower from dect config failed....!\n");
		

	memset(&xBMCParams, 0 , sizeof(x_IFX_VMAPI_DectBMCParams));
	xBMCParams.iid.config_owner = IFX_VOIP;
  if( IFX_VMAPI_SUCCESS ==
      ifx_get_Bmcparam(&xBMCParams,1)){

			if(ifx_set_Bmcparam(IFX_OP_MOD,&xBMCParams,uiFlag) != IFX_VMAPI_SUCCESS){
						printf("$$$$$$$$$$$$$$$$$$$ Configuring BMCParams from dect config failed....!\n");
			}

	}else
			printf("$$$$$$$$$$$$$$$$$$$$$ Reading BMCParams from dect config failed.....!\n");
	
memset(&xOscParams, 0 , sizeof(x_IFX_VMAPI_DectOscTrimVal));
xOscParams.iid.config_owner = IFX_VOIP;
  if( IFX_VMAPI_SUCCESS ==
      ifx_get_Osctrim(&xOscParams,1)) {

			if(ifx_set_Osctrim(IFX_OP_MOD,&xOscParams,uiFlag) != IFX_VMAPI_SUCCESS){
						printf("$$$$$$$$$$$$$$$$$$$$$ Configuring OscParams from dect config failed....!\n");
			}

	}else
			printf("$$$$$$$$$$$$$$$$$$$$ Reading OscParams from dect config failed......!\n");

memset(&xGfsk, 0 , sizeof(x_IFX_VMAPI_DectGFSKVal));
xGfsk.iid.config_owner = IFX_VOIP;	
if( IFX_VMAPI_SUCCESS ==
      ifx_get_Gfsk(&xGfsk, 1)){

			if(ifx_set_Gfsk(IFX_OP_MOD,&xGfsk,uiFlag) != IFX_VMAPI_SUCCESS){
						printf("Configuring xGfsk from dect config failed....!\n");
			}

	}else
		printf("Reading GFSK params from dect config failed....!\n");

}

#endif 

e_IFX_Return IFX_CIF_TPCValGet(OUT x_IFX_DECT_TransmitPowerParam *pxTpcGet)
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_TransmitPowerParam xTransPower = {{{{""}}}};
	 
  xTransPower.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
      ifx_get_TransPower(&xTransPower,IFX_CIF_GET_FLAGS))

	{
		memcpy(pxTpcGet, &xTransPower.ucTuneDigitalRef, 
																sizeof(x_IFX_DECT_TransmitPowerParam));
		eRet = IFX_SUCCESS;
	}


	return eRet;
}
#if 1
e_IFX_Return IFX_CIF_GaussianValGet(OUT uint16 *punGaussianVal)
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_DectGFSKVal xGFSKParams = {{{{""}}}};
	
  xGFSKParams.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_Gfsk(&xGFSKParams,IFX_CIF_GET_FLAGS))
	{
    *punGaussianVal = xGFSKParams.ucDectGFSKHI;
		*punGaussianVal <<= 8;
    *punGaussianVal |= xGFSKParams.ucDectGFSKLOW;
		eRet = IFX_SUCCESS;
	}
	return eRet;
}
#endif	


e_IFX_Return IFX_CIF_BMCRegparamGet(OUT x_IFX_DECT_BMCRegParams *pxBMCParams)
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_DectBMCParams xBMCParams = {{{{""}}}};
	x_IFX_VMAPI_DectCountrySettings xCountrySet = {{{{""}}}};

  xBMCParams.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_Bmcparam(&xBMCParams,IFX_CIF_GET_FLAGS))
	{      
		memcpy(pxBMCParams,&xBMCParams.ucDectRSSIFreeLevel,14);
	
  xCountrySet.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_CtrySet(&xCountrySet,IFX_CIF_GET_FLAGS))
	{
   pxBMCParams->ucGENMUTCTRL0 = xCountrySet.ucFreqTxOffset;
   pxBMCParams->ucGENMUTCTRL1 = xCountrySet.ucFreqRxOffset;
   pxBMCParams->ucEXTMUTCTRL0 = xCountrySet.ucFreqRan;
  eRet = IFX_SUCCESS;
  }
 }	
return eRet;
}

e_IFX_Return IFX_CIF_OscTrimParamGet(OUT x_IFX_DECT_OscTrimVal *pxOscTrimVal)
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_DectOscTrimVal xOscParams = {{{{""}}}};

  xOscParams.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_Osctrim(&xOscParams,IFX_CIF_GET_FLAGS))
	{
		memcpy(pxOscTrimVal, &xOscParams.ucDectOscTrimValHI,
			       sizeof(x_IFX_DECT_OscTrimVal));
		eRet = IFX_SUCCESS;
	}
	return eRet;
}

e_IFX_Return IFX_CIF_RFPIGet(OUT uchar8 *paxRFPI)
{
	e_IFX_Return eRet = IFX_FAILURE;
  static int i=0;
	x_IFX_VMAPI_DectRfpi xRfpi = {{{{""}}}};
  
  xRfpi.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_Rfpi(&xRfpi,IFX_CIF_GET_FLAGS))
	{
    *paxRFPI = xRfpi.ucByte1;
    *(paxRFPI+1) = xRfpi.ucByte2;
    *(paxRFPI+2) = xRfpi.ucByte3;
    *(paxRFPI+3) = xRfpi.ucByte4;
    *(paxRFPI+4) = xRfpi.ucByte5;
  
		eRet = IFX_SUCCESS;
	}
  if((i==0) && (xRfpi.ucByte6 == 0)) {
    char8 acHostMac[10] = {'\0'};
    IFX_OS_GetHostMac("br0",acHostMac);
    printf("MAC Address %02x %02x %02x %02x %02x %02x\n",
         acHostMac[0],acHostMac[1],acHostMac[2],acHostMac[3],acHostMac[4],acHostMac[5]);
		
    *(paxRFPI+2) = xRfpi.ucByte3 = (acHostMac[4]!=0x00)?acHostMac[4]:0x04;
    *(paxRFPI+3) = xRfpi.ucByte4 = (acHostMac[5]!=0x00)?acHostMac[5]:0x32;
    xRfpi.ucByte6 = 1;
    if(IFX_VMAPI_FAIL == ifx_set_Rfpi(IFX_CIF_SETOPP_FLAG,&xRfpi,0)){
      printf("\n <CIF>RFPI Set Failure.\n");
      return IFX_FAILURE;
    } 
		eRet = IFX_SUCCESS;
    i =1;
  }
	return eRet; 
}
#elif defined(CVOIP_SUPPORT)
e_IFX_Return IFX_CIF_TPCValGet(OUT x_IFX_VMAPI_TransmitPowerParam *pxTpc)
{
  pxTpc->iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
      ifx_get_TransPower(pxTpc, IFX_CIF_GET_FLAGS)){
		return IFX_SUCCESS;
	}
	return IFX_FAILURE;
}

e_IFX_Return IFX_CIF_GaussianValGet(OUT x_IFX_VMAPI_DectGFSKVal *pxGfsk)
{
  pxGfsk->iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
      ifx_get_Gfsk(pxGfsk, IFX_CIF_GET_FLAGS)){
		return IFX_SUCCESS;
	}
	return IFX_FAILURE;
}

e_IFX_Return IFX_CIF_BMCRegparamGet(OUT x_IFX_VMAPI_DectBMCParams *pxBMCParams)
{
  pxBMCParams->iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_Bmcparam(pxBMCParams,IFX_CIF_GET_FLAGS)){      
		return IFX_SUCCESS;
	}
	return IFX_FAILURE;
}

e_IFX_Return IFX_CIF_OscTrimParamGet(OUT x_IFX_VMAPI_DectOscTrimVal *pxOscTrimVal)
{
  pxOscTrimVal->iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_Osctrim(pxOscTrimVal,IFX_CIF_GET_FLAGS)){
		return IFX_SUCCESS;
	}
	return IFX_FAILURE;
}

e_IFX_Return IFX_CIF_RFPIGet(OUT x_IFX_VMAPI_DectRfpi *pxRfpi)
{

  pxRfpi->iid.config_owner = IFX_VOIP;
  if( IFX_VMAPI_SUCCESS ==
      ifx_get_Rfpi(pxRfpi,IFX_CIF_GET_FLAGS))
  {
		return IFX_SUCCESS;
	}
return IFX_FAILURE;
}


e_IFX_Return IFX_CIF_CtryParamGet(OUT x_IFX_VMAPI_DectCountrySettings *pxCtryset){
	pxCtryset->iid.config_owner = IFX_VOIP;
if( IFX_VMAPI_SUCCESS ==
      ifx_get_CtrySet(pxCtryset,IFX_CIF_GET_FLAGS))
  {
			return IFX_VMAPI_SUCCESS;
	}
return IFX_FAILURE;
}

e_IFX_Return IFX_CIF_RFMODGet(OUT x_IFX_VMAPI_RFMode *pxRfmode)
{
  pxRfmode->iid.config_owner = IFX_VOIP;
if( IFX_VMAPI_SUCCESS ==
			ifx_get_rfmode(pxRfmode,IFX_CIF_GET_FLAGS))
	{
  	  return IFX_SUCCESS;
  }
  return IFX_FAILURE;
}

e_IFX_Return IFX_CIF_XRAMGet(OUT x_IFX_VMAPI_DectXRAM *pxXram )
{

  pxXram -> iid.config_owner = IFX_VOIP;
  if( IFX_VMAPI_SUCCESS ==
      ifx_get_Xram(pxXram,IFX_CIF_GET_FLAGS))
  {
    return IFX_SUCCESS;
  }
return IFX_FAILURE;
}

#endif // DECT_SUPPORT

#ifdef DECT_SUPPORT

e_IFX_Return IFX_CIF_ToneCadenceGet( IN  e_IFX_MMGR_ToneType eToneType,
											OUT x_IFX_MMGR_Tone *pxTone )
{
	return IFX_FAILURE;
}
#endif
#if defined(DECT_SUPPORT) || defined (CVOIP_SUPPORT)
e_IFX_Return IFX_CIF_DectSubsInfoGet(IN char8* pszEndptId,
											OUT x_IFX_CIF_DectSubsInfo *pxDectSubsInfo)
{
	
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_CIF_EndptData* pxEndptData = 0;
	e_IFX_ReasonCode eReason;
	
	if( IFX_SUCCESS == 
		  IFX_CIF_EndptDataGet(pszEndptId, &pxEndptData, &eReason) && 
			pxEndptData->eType == IFX_EP_DECT ) 
	{
		x_IFX_VMAPI_DectHandset xDectHs = {0};
		
		xDectHs.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
    xDectHs.iid.config_owner = IFX_VOIP;

		if( IFX_VMAPI_SUCCESS == ifx_get_DectHandset(&xDectHs,IFX_CIF_GET_FLAGS) )
		{
			IFX_CIF_copySubsInfoFromVmapi(pxDectSubsInfo, &xDectHs.xSubsInfo);
			eRet = IFX_SUCCESS;
		}
#ifdef DEV_DEBUG
		else
			printf("[CIF] %s: ifx_get_DectHandset Failed\n", __FUNCTION__);
#endif
	}
	return eRet;
}
#ifdef ULE_SUPPORT
e_IFX_Return IFX_CIF_ULEConfigGet(OUT x_IFX_CIF_ULE_Config *pxULEConfig){
		if(IFX_ULE_MAPI_SUCCESS==IFX_ULE_CONFIG(0,2, (uchar8 *)pxULEConfig,0))
			return IFX_SUCCESS;
		else
			return IFX_FAILURE;

}
e_IFX_Return IFX_CIF_UleSubsInfoGet(IN uchar8 ucEndptId,
											OUT x_IFX_CIF_UleSubsInfo *pxDectSubsInfo)
{
	
	e_IFX_Return eRet = IFX_FAILURE;
	
	{
		x_IFX_ULE_MAPI_UleSubsInfo xDectHs = {0};
		
		if(IFX_ULE_MAPI_SUCCESS==IFX_ULE_CONFIG(0,1, (uchar8 *)&xDectHs,ucEndptId))
		{
			IFX_CIF_copyUleInfoFromVmapi(pxDectSubsInfo, &xDectHs);

	//IFX_CIF_ConvertStringToHex(pxDectSubsInfo->Last_SSN,(char8 *)xDectHs.Last_SSN,6);	
	//IFX_CIF_ConvertStringToHex(pxDectSubsInfo->Last_RSN,(char8 *)xDectHs.Last_RSN,6);	
	IFX_CIF_ConvertStringToHex(pxDectSubsInfo->Last_SSN,(char8 *)xDectHs.Last_SSN);	
	IFX_CIF_ConvertStringToHex(pxDectSubsInfo->Last_RSN,(char8 *)xDectHs.Last_RSN);	
 	pxDectSubsInfo->uiULEType=xDectHs.uiULEType;
 	pxDectSubsInfo->uiSDUSize=xDectHs.uiSDUSize;
 	pxDectSubsInfo->ucWindowSize=xDectHs.ucWindowSize;
 pxDectSubsInfo->uiNWKState=xDectHs.uiNWKState;
 pxDectSubsInfo->ucDeviceNo=xDectHs.ucDeviceNo;
 pxDectSubsInfo->unEMC=xDectHs.unEMC;
			eRet = IFX_SUCCESS;
		}
#ifdef DEV_DEBUG
		else
			printf("[CIF] %s: ifx_get_DectHandset Failed\n", __FUNCTION__);
#endif
	}
	return eRet;
}
#endif
#ifdef DECT_REPEATER
#ifdef VOIP_NEWVMAPI
e_IFX_Return IFX_CIF_DECTRepeaterSubsInfoGet(IN uchar8 ucEndptId, OUT x_IFX_CIF_DectSubsInfo *pxDectSubsInfo)
{
	
	e_IFX_Return eRet = IFX_FAILURE;
	int nInstanceNo = 0;
	{
		x_IFX_VMAPI_DectSubsInfo xDectHs = {0};
		for(nInstanceNo = 1; nInstanceNo <= 6; nInstanceNo++){
			if(IFX_VMAPI_SUCCESS == ifx_get_DectRepeaterSubs(&xDectHs,ucEndptId,nInstanceNo))
			{
				memset(&pxDectSubsInfo[nInstanceNo-1],0,sizeof(x_IFX_CIF_DectSubsInfo));
				  IFX_CIF_copySubsInfoFromVmapi(&pxDectSubsInfo[nInstanceNo-1], &xDectHs);
				 eRet = IFX_SUCCESS;	
			}
#ifdef DEV_DEBUG
			else {
				printf("[CIF] %s: ifx_get_DectRepeaterSubs Failed\n", __FUNCTION__);
				eRet = IFX_FAILURE;
			}
#endif
		}
	}
	return eRet;
}
#endif
#endif
#endif
#if defined(DECT_SUPPORT) || defined (CVOIP_SUPPORT)
//Note: If pszRegDateAndTime is NULL, registration date and time are unchaged. 
e_IFX_Return IFX_CIF_DectSubsInfoSet(IN char8* pszEndptId,
											IN x_IFX_CIF_DectSubsInfo *pxDectSubsInfo,
											IN boolean bWidebandCapable,
											IN char8* pszRegDateAndTime )
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_CIF_EndptData* pxEndptData = 0;
	e_IFX_ReasonCode eReason;
  uint32 uiInFlag = IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ;
	
	if( IFX_SUCCESS == 
		  IFX_CIF_EndptDataGet(pszEndptId, &pxEndptData, &eReason) ) 
	{
		x_IFX_VMAPI_DectHandset xDectHs = {0};
	
		xDectHs.xVoiceServPhyIf.ucInterfaceId = pxEndptData->ucInterfaceId;
    xDectHs.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS == ifx_get_DectHandset(&xDectHs,IFX_CIF_GET_FLAGS) )
		{
      printf("\n xDectHs.xSubsInfo.bIsRegistered=%d\n",xDectHs.xSubsInfo.bIsRegistered);
      uiInFlag |= (xDectHs.xSubsInfo.bIsRegistered == pxDectSubsInfo->bIsRegistered)? IFX_CIF_MOD_FLAG: IFX_VMAPI_OP_DEFAULT; 
			IFX_CIF_copySubsInfoToVmapi(&xDectHs.xSubsInfo, pxDectSubsInfo);
      printf("\n pxDectSubsInfo->bIsRegistered=%d\n",pxDectSubsInfo->bIsRegistered);
			xDectHs.bWideBandCapable = bWidebandCapable;
#if 1
		if( pszRegDateAndTime ) //Copy registration date and time
				strcpy(xDectHs.acSubscriptionTime,pszRegDateAndTime);
#endif	
      
			eRet = (IFX_VMAPI_SUCCESS == ifx_set_DectHandset(IFX_CIF_SETOPP_FLAG, 
						&xDectHs, uiInFlag))? IFX_SUCCESS:IFX_FAILURE;
		}
	}
	return eRet;
}
#ifdef ULE_SUPPORT
e_IFX_Return IFX_CIF_ULESubsInfoSet(IN uchar8 ucEndptId,
											IN x_IFX_CIF_UleSubsInfo *pxDectSubsInfo)
{
	e_IFX_Return eRet = IFX_FAILURE;

	{
		x_IFX_ULE_MAPI_UleSubsInfo xDectHs = {0};
	
		if(IFX_ULE_MAPI_SUCCESS==IFX_ULE_CONFIG(0,1, (uchar8 *)&xDectHs,ucEndptId) )
		{
			IFX_CIF_copyUleInfoToVmapi(&xDectHs, pxDectSubsInfo);
	IFX_CIF_ConvertHexToString((char8 *)xDectHs.Last_SSN,pxDectSubsInfo->Last_SSN,6);	
	IFX_CIF_ConvertHexToString((char8 *)xDectHs.Last_RSN,pxDectSubsInfo->Last_RSN,6);	
 xDectHs.uiULEType=pxDectSubsInfo->uiULEType;
 xDectHs.uiSDUSize=pxDectSubsInfo->uiSDUSize;
 xDectHs.ucWindowSize=pxDectSubsInfo->ucWindowSize;
 xDectHs.uiNWKState=pxDectSubsInfo->uiNWKState;
 xDectHs.ucDeviceNo=pxDectSubsInfo->ucDeviceNo;
 xDectHs.unEMC=pxDectSubsInfo->unEMC;
			eRet = (IFX_ULE_MAPI_SUCCESS==IFX_ULE_CONFIG(1,1, (uchar8 *)&xDectHs,ucEndptId))? IFX_SUCCESS:IFX_FAILURE;
		}
	}
	return eRet;
}
#endif
#ifdef DECT_REPEATER
#ifdef VOIP_NEWVMAPI
e_IFX_Return IFX_CIF_DECTRepeaterSubsInfoSet(IN uchar8 ucEndptId, x_IFX_CIF_DectSubsInfo *pxDectSubsInfo)
{
	e_IFX_Return eRet = IFX_FAILURE;
	int nInstanceNo = 0;
	{
		x_IFX_VMAPI_DectSubsInfo xDectHs = {0};
		for(nInstanceNo = 1; nInstanceNo <= 6; nInstanceNo++){
			
			IFX_CIF_copySubsInfoToVmapi(&xDectHs, &pxDectSubsInfo[nInstanceNo-1]);
			
			if(IFX_VMAPI_SUCCESS != ifx_set_DectRepeaterSubs(&xDectHs,ucEndptId,nInstanceNo))
			{
#ifdef DEV_DEBUG
				printf("[CIF] %s: ifx_get_DectRepeaterSubs Failed\n", __FUNCTION__);
				eRet = IFX_FAILURE;
#endif
			}
			else
				eRet = IFX_SUCCESS;
		}
	}
	return eRet;
}
#endif
#endif
e_IFX_Return  IFX_CIF_EndptVLListGet(IN char8 *pszEndptId,
											OUT	uchar8	*pacVLList,
											IN_OUT uchar8	*pucNumVLs )
{
	//Currently not used. Its may be required in future
  return IFX_FAILURE;	
}

e_IFX_Return  IFX_CIF_EndptVLListSet(IN     char8   *pszEndptId,
											OUT	uchar8	*pacVLList,
											IN_OUT uchar8	*pucNumVLs )
{
	//Currently not used. Its may be required in future
  return IFX_FAILURE;
}

e_IFX_Return IFX_CIF_BS_PinSet(IN char8* pszBasePin)
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_DectSystem xDectSystem = {{{{""}}}};
	//memset(&xDectSystem, 0, sizeof(x_IFX_VMAPI_DectSystem));
  xDectSystem.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_DectInterface(&xDectSystem,IFX_CIF_GET_FLAGS))
	{
		strcpy(xDectSystem.acAuthCode, pszBasePin);
		if( IFX_VMAPI_SUCCESS == ifx_set_DectInterface(
											IFX_CIF_SETOPP_FLAG, &xDectSystem, IFX_CIF_MOD_FLAG) )
		{
			eRet = IFX_SUCCESS;
		}
		ifx_vmapi_freeObjectList(&xDectSystem,IFX_VMAPI_DECT_SYSTEM);
	}
	return eRet; 
}

e_IFX_Return IFX_CIF_BS_EncryptionSet(IN uchar8 pszEncryption)
{
  e_IFX_Return eRet = IFX_SUCCESS;
  x_IFX_VMAPI_DectSystem xDectSystem = {{{{""}}}};
  //memset(&xDectSystem, 0, sizeof(x_IFX_VMAPI_DectSystem));
  xDectSystem.iid.config_owner = IFX_VOIP;
  if( IFX_VMAPI_SUCCESS == 
      ifx_get_DectInterface(&xDectSystem,IFX_CIF_GET_FLAGS))
  {
		if(xDectSystem.ucEncrytionEnable != pszEncryption){	
    xDectSystem.ucEncrytionEnable = pszEncryption;
   	 if( IFX_VMAPI_SUCCESS == ifx_set_DectInterface(
    	                  IFX_CIF_SETOPP_FLAG, &xDectSystem, IFX_CIF_MOD_FLAG) )
    	{
      		eRet = IFX_SUCCESS;
    	}
		}
    ifx_vmapi_freeObjectList(&xDectSystem,IFX_VMAPI_DECT_SYSTEM);
  }
  return eRet;  
}

#if 0
e_IFX_Return IFX_CIF_DectEnhancedFeatureGet(x_IFX_DECT_EnhancedStackCfg *pxEnhancedStackCfg)
{
	  e_IFX_Return eRet = IFX_FAILURE;
	  x_IFX_VMAPI_DectSystem xDectSystem = {{{{""}}}};
	  //memset(&xDectSystem, 0, sizeof(x_IFX_VMAPI_DectSystem));
	xDectSystem.iid.config_owner = IFX_VOIP;
	  if( IFX_VMAPI_SUCCESS == 
			  ifx_get_DectInterface(&xDectSystem,IFX_CIF_GET_FLAGS))
	  {
		  if(pxEnhancedStackCfg != NULL)
		{
			pxEnhancedStackCfg->bEarlyEncryption = xDectSystem.ucEarlyEncrytion;		  
			pxEnhancedStackCfg->bReKeying = xDectSystem.ucReKeying;
			pxEnhancedStackCfg->bULESupport = xDectSystem.ucUleSupport;
		  	pxEnhancedStackCfg->bRepeaterSupport = xDectSystem.ucRepeaterSupp;		  
		  	pxEnhancedStackCfg->bJapanDECTSupport = xDectSystem.ucJDECTSupp;
		  	pxEnhancedStackCfg->bUseRealCN = xDectSystem.ucRealCN;
		} 

		  ifx_vmapi_freeObjectList(&xDectSystem,IFX_VMAPI_DECT_SYSTEM);
		  eRet = IFX_SUCCESS;
	  }
	  return eRet; 

}
#endif

e_IFX_Return IFX_CIF_DectBasicParamsGet(OUT char8* pszBasePin,OUT uchar8 *pucBitmap,
	OUT x_IFX_DECT_EnhancedStackCfg *pxEnhancedStackCfg)
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_DectSystem xDectSystem = {{{{""}}}};
	//memset(&xDectSystem, 0, sizeof(x_IFX_VMAPI_DectSystem));
  xDectSystem.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_DectInterface(&xDectSystem,IFX_CIF_GET_FLAGS))
	{
		/*passing null from top to get the remaining params*/
		if(pszBasePin != NULL){
			strcpy(pszBasePin, xDectSystem.acAuthCode);
		}
		*pucBitmap = 0;
		*pucBitmap = (xDectSystem.ucEncrytionEnable)|(xDectSystem.ucNoEmo<<1)|
									(xDectSystem.ucRfEnable<<2);
		if(pxEnhancedStackCfg != NULL)
		{
			pxEnhancedStackCfg->bEarlyEncryption = xDectSystem.ucEarlyEncrytion;		  
			pxEnhancedStackCfg->bReKeying = xDectSystem.ucReKeying;
			pxEnhancedStackCfg->bULESupport = xDectSystem.ucUleSupport;
		  	pxEnhancedStackCfg->bRepeaterSupport = xDectSystem.ucRepeaterSupp;		  
		  	pxEnhancedStackCfg->bJapanDECTSupport = xDectSystem.ucJDECTSupp;
		  	pxEnhancedStackCfg->bUseRealCN = xDectSystem.ucRealCN;
		}
		  
		ifx_vmapi_freeObjectList(&xDectSystem,IFX_VMAPI_DECT_SYSTEM);
		eRet = IFX_SUCCESS;
	}
	return eRet; 
}
#endif
#if defined(DECT_SUPPORT) || defined (CVOIP_SUPPORT)
/*******************************************************************************
* Function Name    : IFX_CIF_BS_NameGet 
* Description      : Get the name of the base 
* Input Values     : None
* Output Values    : Base name
* Return Value     : IFX_SUCCESS/IFX_FAILURE
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CIF_BS_NameGet(OUT char8* pszBaseName)
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_DectSystem xDectSystem = {{{{""}}}};
  xDectSystem.iid.config_owner = IFX_VOIP;
	if( IFX_VMAPI_SUCCESS == 
			ifx_get_DectInterface(&xDectSystem,IFX_CIF_GET_FLAGS))
	{
		strcpy(pszBaseName, xDectSystem.acBaseName);
		ifx_vmapi_freeObjectList(&xDectSystem,IFX_VMAPI_DECT_SYSTEM);
		eRet = IFX_SUCCESS;
	}
	return eRet; 
}

#endif
#ifdef MESSAGE_SUPPORT
e_IFX_Return IFX_CIF_VLDectHandsetListGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN_OUT uchar8* pucSize,
	                 OUT char8 aszHandsetList[IFX_VMAPI_MAX_DECT_ENDPTS],
	                 OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);


	if( *pucSize < IFX_MAX_ENDPTS )
	{
		*peReason = IFX_CIF_INSUFFICIENT_ARRAY_SIZE;
		return eRet;
	}
	(*pucSize) = 0;

	xVoiceLine.ucLineId = ucVoiceLineId;
  xVoiceLine.iid.config_owner = IFX_VOIP;

	if( IFX_VMAPI_SUCCESS == 
			(eRet = ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS)) )
	{
		x_IFX_CIF_EndptData* pxEndptData;
		uchar8 ucCount = 0;
		uchar8 ucIndex;
		
		while( xVoiceLine.ucAssocVoiceInterface[ucCount] > 0)
		{
			 ucIndex  = xVoiceLine.ucAssocVoiceInterface[ucCount]-1;
			pxEndptData = (vxConfigInfo.axEndptData+ucIndex);

			if(xVoiceLine.ucAssocVoiceInterface[ucCount] >IFX_VMAPI_MAX_FXS_ENDPTS + IFX_VMAPI_MAX_FXO_ENDPTS)
			{
				strcpy(aszHandsetList[*pucSize],xVoiceLine.ucAssocVoiceInterface[ucCount]);
				++(*pucSize);
			}
			++ucCount;
		}

	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}


e_IFX_Return IFX_CIF_VLNoOfUnReadMsgGet(
	                 IN uchar8 ucVoiceLineId,
	                 IN_OUT uchar8* pucCount,
	                 OUT e_IFX_ReasonCode* peReason )
{
	e_IFX_Return eRet = IFX_FAILURE;

	IFX_CIF_VALIDATE_VOICELINE(ucVoiceLineId,peReason);

	if( *pucCount < IFX_VMAPI_MAX_MSG_IN_ENTRIES)
	{
		*peReason = IFX_CIF_INSUFFICIENT_ARRAY_SIZE;
		return eRet;
	}
	(*pucCount) = 0;

	if( IFX_VMAPI_SUCCESS == 
			(eRet = ifx_vmapi_getUnReadMsg(ucVoiceLineId,pucCount)) )
	{

	}
	else
	{
		*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;

}

#endif

#ifdef MESSAGE_SUPPORT
/*
 * Handles MESSAGE Support.
 */
/*******************************************************************************
* Function Name    : IFX_CIF_GetAllMsgHdr 
* Description      :
* Input Values     : 
*                  : pxSmsInfo is reference to array of SMS Info structure 
* Output Values    : ucCount - Number of available SMS
* Return Value     : 
* Notes            : Get From,MsgUnread,SMS Header, SMS Handle
										 eMsgBox = IN / OUT
*******************************************************************************/
e_IFX_Return IFX_CIF_GetAllMsgHdrs( IN uchar8 ucLineId,
		                               IN e_IFX_MsgBox eMsgBox,
	                                 OUT x_IFX_CMGR_Msg_Info* pxMsgInfo,
																	 OUT uchar8* pucCount)
{
	if(eMsgBox == IFX_MSG_IN) {
		x_IFX_VMAPI_IN_Message xMsgIn ;
		x_IFX_VMAPI_IN_MessageEntry *pxMsgInEntry = NULL;
		uchar8 ucCount =0;

		printf("<IFX_CIF_GetAllMsgHdrs> Msg In Headers\n");
  	memset(&xMsgIn,0,sizeof(xMsgIn));
		xMsgIn.ucLineId = ucLineId ;
  	xMsgIn.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgInbox(&xMsgIn,IFX_CIF_GET_FLAGS))
		{
			printf("<%s:%d> ERROR :  ifx_get_MsgInbox FAILED\n", 
													__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
		
		pxMsgInEntry = xMsgIn.pxMsgEntries;
  	if((pxMsgInEntry == NULL) || (xMsgIn.ucNoOfEntries == 0))
    	return IFX_FAILURE;

		while(pxMsgInEntry != NULL) {
				printf("<IFX_CIF_GetAllMsgHdrs>Msg is %s\n",pxMsgInEntry->acMsg);
				strcpy((pxMsgInfo+ucCount)->szMsgBody, pxMsgInEntry->acMsg);
				strcpy((pxMsgInfo+ucCount)->acUserName, pxMsgInEntry->acUser);
				(pxMsgInfo+ucCount)->uiMsgHdl = pxMsgInEntry->uiMsgHdl;
				(pxMsgInfo+ucCount)->bMsgUnread = pxMsgInEntry->bReadFlg;
				ucCount++;
				__ifx_list_GetNext((void**)&pxMsgInEntry);
  	}

		*pucCount = ucCount;
		printf("<IFX_CIF_GetAllMsgHdrs>No of MsgEntry is %d\n",*pucCount);
		ifx_vmapi_freeObjectList(&xMsgIn, IFX_VMAPI_MSG_INBOX);
	}
	else if(eMsgBox == IFX_MSG_OUT) {
		x_IFX_VMAPI_OUT_Message xMsgOut ;
		x_IFX_VMAPI_OUT_MessageEntry *pxMsgOutEntry = NULL;
		uchar8 ucCount =0;

		printf("<IFX_CIF_GetAllMsgHdrs> Msg Out Headers\n");
  	memset(&xMsgOut,0,sizeof(xMsgOut));
		xMsgOut.ucLineId = ucLineId ;
  	xMsgOut.iid.config_owner = IFX_VOIP;
		if( IFX_VMAPI_SUCCESS != 
				ifx_get_MsgOutbox(&xMsgOut,IFX_CIF_GET_FLAGS))
		{
			printf("<%s:%d> ERROR :  ifx_get_MsgOutbox FAILED\n", 
											__FUNCTION__, __LINE__);
			return IFX_FAILURE;
		}
		
		pxMsgOutEntry = xMsgOut.pxMsgEntries;
  	if((pxMsgOutEntry == NULL) || (xMsgOut.ucNoOfEntries == 0))
    	return IFX_FAILURE;

		while(pxMsgOutEntry != NULL) {
				printf("<IFX_CIF_GetAllMsgHdrs>Msg is %s\n",pxMsgOutEntry->acMsg);
				strcpy((pxMsgInfo+ucCount)->szMsgBody, pxMsgOutEntry->acMsg);
				strcpy((pxMsgInfo+ucCount)->acUserName, pxMsgOutEntry->acUser);
				(pxMsgInfo+ucCount)->uiMsgHdl = pxMsgOutEntry->uiMsgHdl;
				(pxMsgInfo+ucCount)->bMsgUnread = pxMsgOutEntry->bReadFlg;
				ucCount++;
				__ifx_list_GetNext((void**)&pxMsgOutEntry);
  	}

		*pucCount = ucCount;
		print_message("<IFX_CIF_GetAllMsgHdrs>No of MsgOutEntry is %d\n",*pucCount);
		ifx_vmapi_freeObjectList(&xMsgOut, IFX_VMAPI_MSG_OUTBOX);
	}
	else {
			printf("<%s:%d> ERROR :  Wrong MsgBox FAILED\n", 
										__FUNCTION__, __LINE__);
			*pucCount = 0;
			return IFX_FAILURE;
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CIF_GetMsg
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            :
*******************************************************************************/
e_IFX_Return IFX_CIF_GetMsg( uchar8 ucLineId,
	                   IN uint32 uiMsgHdl,
										 OUT x_IFX_CMGR_Msg_Info* pxMsgInfo)
{
	x_IFX_VMAPI_MessageEntry xMsgEntry;
	memset(&xMsgEntry,0,sizeof(x_IFX_VMAPI_MessageEntry));
	printf("<IFX_CIF_GetMsg> Entry\n");
	if( IFX_VMAPI_FAIL == 
			ifx_vmapi_getMsg(ucLineId,uiMsgHdl,&xMsgEntry))
	{
		printf("<%s:%d> ERROR :  ifx_vmapi_getMsg FAILED\n", 
												__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
		
	strcpy(pxMsgInfo->szMsgBody, xMsgEntry.acMsg);
	strcpy(pxMsgInfo->acUserName, xMsgEntry.acUser);
	pxMsgInfo->uiMsgHdl = xMsgEntry.uiMsgHdl;
	pxMsgInfo->bMsgUnread = xMsgEntry.bReadFlg;

	printf("<IFX_CIF_GetMsg>MsgBody: %s Username: %s MsgHdl: %d ReadFlg: %d\n",
										pxMsgInfo->szMsgBody,pxMsgInfo->acUserName,
										pxMsgInfo->uiMsgHdl,pxMsgInfo->bMsgUnread);
	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CIF_StoreMsg
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            : IN LineId, MsgBox
									   OUT MsgInfo
*******************************************************************************/
e_IFX_Return IFX_CIF_StoreMsg(IN uchar8 ucLineId,
		                         	IN e_IFX_MsgBox eMsgBox,
															IN_OUT x_IFX_CMGR_Msg_Info *pxMsgInfo)
{
	x_IFX_VMAPI_MessageEntry xMsgEntry;

  memset(&xMsgEntry,0,sizeof(xMsgEntry));
	xMsgEntry.ucLineId = ucLineId ;
  xMsgEntry.iid.config_owner = IFX_VOIP;

	strcpy(xMsgEntry.acMsg, pxMsgInfo->szMsgBody);
	strcpy(xMsgEntry.acUser, pxMsgInfo->acUserName);

	printf("Store the Msg : %s\n",pxMsgInfo->szMsgBody);
	printf("Store the UserName : %s\n",pxMsgInfo->acUserName);

	if( IFX_VMAPI_SUCCESS != 
				ifx_vmapi_storeMsg(ucLineId,eMsgBox,&xMsgEntry))
	{
		printf("<%s:%d> ERROR :  ifx_set_storeMsg FAILED\n", 
											__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CIF_DeleteMsg
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            : IN ucLineId
									   OUT MsgHdl
*******************************************************************************/
e_IFX_Return IFX_CIF_DeleteMsg(IN uchar8 ucLineId,
												IN uint32 uiMsgHdl)
{
	if( IFX_VMAPI_SUCCESS != 
			ifx_vmapi_delMsg(ucLineId,uiMsgHdl))
	{
		printf("<%s:%d> ERROR :  ifx_vmapi_delMsg FAILED\n", 
													__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}

	return IFX_SUCCESS;
}

/*******************************************************************************
* Function Name    : IFX_CIF_SetMsgAsRead
* Description      :
* Input Values     : 
*                  : 
* Output Values    : None
* Return Value     : 
* Notes            : IN acFrom, SmsBody
									   OUT SmsHdl
*******************************************************************************/
IFX_CIF_SetMsgAsRead(IN uchar8 ucLineId,
										  IN uint32 uiMsgHdl)
{
	if( IFX_VMAPI_SUCCESS != 
			ifx_vmapi_setMsgAsRead(ucLineId,uiMsgHdl))
	{
		printf("<%s:%d> ERROR : ifx_vmapi_setMsgAsRead FAILED\n", 
															__FUNCTION__, __LINE__);
		return IFX_FAILURE;
	}
	return IFX_SUCCESS;
}

#endif /* MESSAGE_SUPPORT */


//#ifdef DECT_SUPPORT
#if defined(DECT_SUPPORT) || defined (CVOIP_SUPPORT)
e_IFX_Return 
IFX_CIF_StoreValuesFromModem(e_IFX_VMAPI_ObjectId eObj,IN void *buf)
{
  
  printf("\n <CIF>StoreTpValuesFromModem Entry.\n");
uint32 uiNotifyFlag = 0;
#ifdef CVOIP_SUPPORT
	uiNotifyFlag = IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ;
#endif
 
 switch(eObj){
 
 case IFX_VMAPI_TRANS_POWER_TEST:  
  {
    x_IFX_VMAPI_TransmitPowerParam *pxTp = (x_IFX_VMAPI_TransmitPowerParam *)buf;
    //x_IFX_VMAPI_DectBMCParams xBmc = {0};
    pxTp->iid.config_owner = IFX_VOIP;
 if(pxTp->ucTuneDigital != 0){ 
    printf("\n <CIF>Invoking ifx_set_TransPower.\n");
    if(IFX_VMAPI_FAIL == ifx_set_TransPower(IFX_CIF_SETOPP_FLAG,pxTp,uiNotifyFlag)){
      printf("\n <CIF>Failure.\n");
      return IFX_FAILURE;
    }
	}
#if 0
 
  xBmc.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_FAIL == ifx_get_Bmcparam(&xBmc,0)){

    printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
  }

  xBmc.ucDectNTP_TCORR = pxTp->ucTxBias; 
  xBmc.ucDectNTP_ALGO = pxTp->ucSWPowerMode; 

  printf("\n <CIF>Invoking ifx_set_Bmcparam.\n");
  if(IFX_VMAPI_FAIL == ifx_set_Bmcparam(IFX_CIF_SETOPP_FLAG,&xBmc,0)){

    printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
  } 
#endif
  }
  break;

 case IFX_VMAPI_BMC_REG_PARAMS_TEST:
 {
 x_IFX_VMAPI_DectBMCParams *pxBmc = (x_IFX_VMAPI_DectBMCParams *)buf;

  pxBmc->iid.config_owner = IFX_VOIP;

  printf("\n <CIF>Invoking ifx_set_Bmcparam.\n");
  if(IFX_VMAPI_FAIL == ifx_set_Bmcparam(IFX_CIF_SETOPP_FLAG,pxBmc,uiNotifyFlag)){

  printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
  } 
 }
  break;

 case IFX_VMAPI_RF_MODE_TEST:
 {

  x_IFX_VMAPI_RFMode *pxRfmode = (x_IFX_VMAPI_RFMode*)buf;

  pxRfmode->iid.config_owner = IFX_VOIP;

  printf("\n <CIF>Invoking ifx_set_Bmcparam.\n");
  if(IFX_VMAPI_FAIL == ifx_set_rfmode(IFX_CIF_SETOPP_FLAG,pxRfmode,uiNotifyFlag)){

  printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
  } 
 }
 break;
 
 case IFX_VMAPI_OSC_TRIM_TEST:
 {

  x_IFX_VMAPI_DectOscTrimVal *pxOscTrim = (x_IFX_VMAPI_DectOscTrimVal*)buf;

  pxOscTrim->iid.config_owner = IFX_VOIP;

  printf("\n <CIF>Invoking ifx_set_Bmcparam.\n");
  if(IFX_VMAPI_FAIL == ifx_set_Osctrim(IFX_CIF_SETOPP_FLAG,pxOscTrim,uiNotifyFlag)){

  printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
  } 
 }
 break;

 case IFX_VMAPI_GFSK_TEST:
 {

  x_IFX_VMAPI_DectGFSKVal *pxGfsk = (x_IFX_VMAPI_DectGFSKVal*)buf;

  pxGfsk->iid.config_owner = IFX_VOIP;

  printf("\n <CIF>Invoking ifx_set_Gfsk.\n");
  if(IFX_VMAPI_FAIL == ifx_set_Gfsk(IFX_CIF_SETOPP_FLAG,pxGfsk,uiNotifyFlag)){

  printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
  } 
 }
 break;

case IFX_VMAPI_COUNTRY_SETTINGS_TEST:
 {
   x_IFX_VMAPI_DectCountrySettings *pxCtryset = (x_IFX_VMAPI_DectCountrySettings*)buf;

   pxCtryset->iid.config_owner = IFX_VOIP;

   printf("\n <CIF>Invoking ifx_set_CtrySet.\n");
   if(IFX_VMAPI_FAIL == ifx_set_CtrySet(IFX_CIF_SETOPP_FLAG,pxCtryset,uiNotifyFlag)){

   printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
   }
 }
 break;

 case IFX_VMAPI_XRAM_TEST:
 {

  x_IFX_VMAPI_DectXRAM *pxXram = (x_IFX_VMAPI_DectXRAM*)buf;

  pxXram->iid.config_owner = IFX_VOIP;

  printf("\n <CIF>Invoking ifx_set_Xram.\n");
  if(IFX_VMAPI_FAIL == ifx_set_Xram(IFX_CIF_SETOPP_FLAG,pxXram,uiNotifyFlag)){

  printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
  } 
 }
 break;

 case IFX_VMAPI_RFPI_TEST:
 {

  x_IFX_VMAPI_DectRfpi *pxRfpi = (x_IFX_VMAPI_DectRfpi*)buf;

  pxRfpi->iid.config_owner = IFX_VOIP;

  printf("\n <CIF>Invoking ifx_set_Rfpi.\n");
  if(IFX_VMAPI_FAIL == ifx_set_Rfpi(IFX_CIF_SETOPP_FLAG,pxRfpi,uiNotifyFlag)){

  printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
  } 
 }
 break;
 case IFX_VMAPI_DECT_SYSTEM:
 {

	x_IFX_VMAPI_DectSystem *pxDectSystem = (x_IFX_VMAPI_DectSystem *)buf;

  pxDectSystem->iid.config_owner = IFX_VOIP;

  printf("\n <CIF>Invoking ifx_set_DectIntf.\n");
  if(IFX_VMAPI_FAIL == ifx_set_DectInterface(IFX_CIF_SETOPP_FLAG,pxDectSystem,uiNotifyFlag)){

  printf("\n <CIF>Failure.\n");
    return IFX_FAILURE;
  } 
 }
 break;

 default:
   break;
 }//switch ends 
  printf("\n <CIF>Success.\n");
    return IFX_SUCCESS;
  	

}

#endif

/*------------------------- Lcoal Utility functions -------------------------*/

e_IFX_Return IFX_CIF_EndptDataGet(
	                   IN char8* szEndpoint, 
	                   OUT x_IFX_CIF_EndptData** pxEndptData,
										 OUT e_IFX_ReasonCode* peReason)
{
	x_IFX_CIF_EndptData* paxEndptData = vxConfigInfo.axEndptData;
	uchar8 ucIfId = 0;
	
	*pxEndptData = 0;
	while(ucIfId < IFX_MAX_ENDPTS )
	{
		if( strcmp(paxEndptData->szEndptId,szEndpoint) == 0 )
		{
			*pxEndptData = paxEndptData;
			break;
		}
		++ucIfId;
		++paxEndptData;
	}

	if( !(*pxEndptData) )
		*peReason = IFX_CIF_INVALID_ENDPOINT;

	return ((*pxEndptData )?IFX_SUCCESS:IFX_FAILURE);
}

e_IFX_Return IFX_CIF_IsPortFree(uint16 unPort, e_IFX_TransportType ePortType)
{
	uint16 unCount = 0;

	while( unCount < IFX_USED_PORT_ARRAY_SIZE )
	{
		if( vauiUsedPorts[unCount] == unPort )
			break;
		++unCount;
	}
	return (unCount < IFX_USED_PORT_ARRAY_SIZE)?IFX_FAILURE:IFX_SUCCESS;
}

e_IFX_Return IFX_CIF_AllocPort(uint16 unPort, e_IFX_TransportType ePortType)
{
	uint16 unCount = 0;
	while( unCount < IFX_USED_PORT_ARRAY_SIZE )
	{
		if( vauiUsedPorts[unCount] == 0 )
		{
			//printf("%s: Allocated Port=%d\n", __FUNCTION__,unPort);
			vauiUsedPorts[unCount] = unPort;
			break;
		}
		++unCount;
	}

	return (unCount < IFX_USED_PORT_ARRAY_SIZE)?IFX_SUCCESS:IFX_FAILURE;

}

e_IFX_Return IFX_CIF_FreePort(uint16 unRelPort, e_IFX_TransportType ePortType)
{
	uint16 unCount = 0;
	while( unCount < IFX_USED_PORT_ARRAY_SIZE )
	{
		if( vauiUsedPorts[unCount] == unRelPort )
		{
			//printf("%s: Released Port=%d\n", __FUNCTION__,unRelPort);
			vauiUsedPorts[unCount] = 0;
			break;
		}
		++unCount;
	}
	return IFX_SUCCESS;
}

/*SMS01395036 Start: Fix for call forward activate*/
/*****************************************************************************
 *  Function Name   : IFX_CIF_GetCallFrwdDomain
 *  Description     :
 *  Input Values    :
 *  Return Value    :
 *
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CIF_GetCallFrwdDomain (IN uint8 ucVoipLineId,
                                        OUT x_IFX_CMGR_VoipAddr* pxFwdAddr)

{
	x_IFX_VMAPI_VoiceLine xLine = {{{{""}}}};
  x_IFX_VMAPI_ProfileSignaling xProfileSig = {{{{""}}}};
  if( ucVoipLineId <= 0 ||
      ( (ucVoipLineId-1) > IFX_MAX_LINES) ||
      pxFwdAddr == NULL){
    return IFX_FAILURE;
  }

 if(IFX_TEL_NUM !=pxFwdAddr->ucAddrType){
    return IFX_SUCCESS;
 }

  xLine.ucLineId = ucVoipLineId;
  xLine.iid.config_owner = IFX_VOIP;
  if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xLine, IFX_CIF_GET_FLAGS))
  {
   xProfileSig.ucProfileId = xLine.ucProfileId;
   xProfileSig.iid.config_owner = IFX_VOIP;
   if(IFX_VMAPI_SUCCESS == ifx_get_ProfileSignaling(&xProfileSig,0)){
     strcpy(pxFwdAddr->acCalledAddr,xProfileSig.acProxyAddr);
     return IFX_SUCCESS;
   }
  }
  return IFX_FAILURE;
}

#ifdef DECT_SUPPORT
/*****************************************************************************
 *  Function Name   : IFX_CIF_GetLineName
 *  Description     :	This API fetches the LineName corresponding to a given LineId.
 *  Input Values    :	Line Id
 *  Output Values		: Line Name
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return 
IFX_CIF_GetLineName(IN uchar8 ucLineId, OUT char8 *pcLineName)
{
  x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{0}}}};
  x_IFX_VMAPI_FxoPhyIf xFXO = {{{{0}}}};
  if((ucLineId != IFX_VMAPI_PSTN_LINE)&&(ucLineId != 0)){
   memset(&xVoiceLine,0,sizeof(xVoiceLine));
 	 xVoiceLine.ucLineId = ucLineId;
  	xVoiceLine.iid.config_owner = IFX_VOIP;
  	if(IFX_SUCCESS == ifx_get_VoiceLine(&xVoiceLine,0)){
    	memcpy(pcLineName,xVoiceLine.acName,IFX_DECT_LAU_MAX_LINE_NAME_LEN);
			pcLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN-1]='\0';
    	return IFX_SUCCESS;
  	}
	}else if (ucLineId == IFX_VMAPI_PSTN_LINE){
    memset(&xFXO,0,sizeof(xFXO));
    xFXO.xVoiceServPhyIf.ucInterfaceId = 3;
		xFXO.iid.config_owner = IFX_VOIP;
		if(IFX_VMAPI_SUCCESS == ifx_get_FxoPhyInterface(&xFXO,IFX_VMAPI_OP_DEFAULT)){
    	memcpy(pcLineName,xFXO.acName,IFX_DECT_LAU_MAX_LINE_NAME_LEN);
			pcLineName[IFX_DECT_LAU_MAX_LINE_NAME_LEN-1]='\0';
    	return IFX_SUCCESS;
    }          
	}                                     
   return IFX_FAILURE; 
}

/*****************************************************************************
 *  Function Name   : IFX_CIF_IsIntrusionAllowed
 *  Description     :	This API retrives Intrusion Info.
 *  Input Values    :	Line Id
 *  Return Value    : IFX_TRUE
 *										IFX_FALSE - If Intrusion Not allowed.
 *  Notes           :
 ****************************************************************************/
boolean 
IFX_CIF_IsIntrusionAllowed(uchar8 ucLineId){
  x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{0}}}};
	x_IFX_VMAPI_FxoPhyIf xFXO = {{{{0}}}};
	uchar8 ucMode=2;
  if((ucLineId != IFX_VMAPI_PSTN_LINE)&&(ucLineId != 0)){
  	xVoiceLine.ucLineId = ucLineId;
  	xVoiceLine.iid.config_owner = IFX_VOIP;
  	ifx_get_VoiceLine(&xVoiceLine,0);
    ucMode=xVoiceLine.ucIntrusion;
		//ucMode=(ucLineId==1)?1:0;
	}else if(ucLineId == IFX_VMAPI_PSTN_LINE){
    xFXO.xVoiceServPhyIf.ucInterfaceId = 3;
		xFXO.iid.config_owner = IFX_VOIP;
		ifx_get_FxoPhyInterface(&xFXO,IFX_VMAPI_OP_DEFAULT);
    ucMode=xFXO.ucIntrusion;
	}
  if(ucMode == 1)
   return IFX_TRUE;
  else
   return IFX_FALSE; 
}

/*****************************************************************************
 *  Function Name   : IFX_CIF_IsInterceptAllowed
 *  Description     :	This API retrives Intercept Info.
 *  Input Values    :	Hanset Id
 *  Return Value    : IFX_TRUE
 *										IFX_FALSE - If Intercept Not allowed.
 *  Notes           :
 ****************************************************************************/
boolean 
IFX_CIF_IsInterceptAllowed(uchar8 ucHandsetId){
	x_IFX_VMAPI_DectHandset xVmapiDectHs;
  memset(&xVmapiDectHs,0,sizeof(xVmapiDectHs));
  xVmapiDectHs.xVoiceServPhyIf.ucInterfaceId = ucHandsetId+3;
  xVmapiDectHs.iid.config_owner = IFX_VOIP;
  if(IFX_VMAPI_SUCCESS != ifx_get_DectHandset(&xVmapiDectHs,0)){
     return IFX_FALSE;
  }
	return (xVmapiDectHs.bIntercept==1)?IFX_TRUE:IFX_FALSE;
 
}
#endif //DECT_SUPPORT
/*****************************************************************************
 *  Function Name   : IFX_CIF_IsLineTypeMulti
 *  Description     :	This API retrives Line setting attributes and checks if 
											line can have simultaneous multiple calls.
 *  Input Values    :	Line Id
 *  Return Value    : IFX_TRUE
 *										IFX_FALSE - If Line can have only single call
 *  Notes           :
 ****************************************************************************/
boolean 
IFX_CIF_IsLineTypeMulti(IN uchar8 ucLineId)
{
  x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{0}}}};
	x_IFX_VMAPI_FxoPhyIf xFXO = {{{{0}}}};
	uchar8 ucMode=2;
  if((ucLineId != IFX_VMAPI_PSTN_LINE)&&(ucLineId != 0)){
  	xVoiceLine.ucLineId = ucLineId;
  	xVoiceLine.iid.config_owner = IFX_VOIP;
  	ifx_get_VoiceLine(&xVoiceLine,0);
    ucMode=xVoiceLine.ucLineMode;
	}else if(ucLineId == IFX_VMAPI_PSTN_LINE){
    xFXO.xVoiceServPhyIf.ucInterfaceId = 3;
		xFXO.iid.config_owner = IFX_VOIP;
		ifx_get_FxoPhyInterface(&xFXO,IFX_VMAPI_OP_DEFAULT);
    ucMode=xFXO.ucLineMode;
	}
  if(ucMode == 1)
   return IFX_TRUE;
  else
   return IFX_FALSE; 
}
/*****************************************************************************
 *  Function Name   : IFX_CIF_LineAssocSet
 *  Description     :	This API Associates the handset to a given line.
 *  Input Values    :	Line Id,Handset Id
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return
IFX_CIF_LineAssocSet(IN uchar8 ucHandset,IN uchar8 ucLineId)
{
	x_IFX_VMAPI_VoiceLine xVoiceLine = {{{{""}}}};
	xVoiceLine.ucLineId = ucLineId;
  xVoiceLine.iid.config_owner = IFX_VOIP;
  int16 i=0;

	if( IFX_VMAPI_SUCCESS == ifx_get_VoiceLine(&xVoiceLine,IFX_CIF_GET_FLAGS))
	{
			while(xVoiceLine.ucAssocVoiceInterface[i] != '\0')
						i++;
			xVoiceLine.ucAssocVoiceInterface[i] = ucHandset+3;
    	if(IFX_VMAPI_SUCCESS != ifx_set_VoiceLine(IFX_OP_MOD,&xVoiceLine,0)){
		  	return IFX_FAILURE;
	  	}
	}else{
      return IFX_FAILURE;
	}
return IFX_SUCCESS;
}
#ifdef DELAYED_HOTLINE
/*****************************************************************************
 *  Function Name   : IFX_CIF_EndptDhlInfoSet
 *  Description     :	This API set the Delayed Hotline Info
 *  Input Values    :	EndptId, bEnabled, pcDhlNumber
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CIF_EndptDhlInfoSet(
	                 IN char8* szEndptId, 
	                 IN boolean bEnabled,
	                 IN char8* pcDhlNumber,
	                 OUT e_IFX_ReasonCode* peReason  )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	uchar8 ucLineId;
	e_IFX_Return eRet;

	if( IFX_SUCCESS == 
		(eRet=IFX_CIF_EndptDefaultVLGet(szEndptId,
																							&ucLineId,peReason) ) )
	{
		eRet = IFX_FAILURE;
		xLineCallingFeature.ucLineId = ucLineId;
    xLineCallingFeature.iid.config_owner = IFX_VOIP;
		
		if( IFX_VMAPI_SUCCESS == 
			ifx_get_LineCallingFeatures(&xLineCallingFeature,
																	IFX_CIF_GET_FLAGS)  )   
		{
			if( !bEnabled )
			{
				/* Disable */
				xLineCallingFeature.bEnableDhl = IFX_FALSE;
				xLineCallingFeature.acDhlNumber[0] = 0;
			}
			else
			{
				/* Enable */
				xLineCallingFeature.bEnableDhl = IFX_TRUE;
				strcpy(xLineCallingFeature.acDhlNumber,pcDhlNumber);
			}
			
			if( IFX_VMAPI_SUCCESS == 
					ifx_set_LineCallingFeatures(IFX_CIF_SETOPP_FLAG,
																			&xLineCallingFeature,
																			IFX_CIF_MOD_FLAG ) )
			{
				eRet = IFX_SUCCESS;
			}
			
		}

		if( IFX_SUCCESS != eRet )
			*peReason = IFX_CIF_CONFIG_ERROR;
	}

	return eRet;
}

/*****************************************************************************
 *  Function Name   : IFX_CIF_EndptDhlInfoGet
 *  Description     :	This API get the Delayed Hotline Info
 *  Input Values    :	EndptId
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CIF_EndptDhlInfoGet(
	               IN char8* szEndptId,
	               OUT boolean* pbEnable,
	               OUT char8* pcDhlNumber,
	               OUT e_IFX_ReasonCode* peReason )
{
	x_IFX_VMAPI_LineCallingFeatures xLineCallingFeature = {{{{""}}}};
	e_IFX_Return eRet = IFX_FAILURE;
	uchar8 ucLineId = 0;

	if( IFX_SUCCESS == 
		(eRet=IFX_CIF_EndptDefaultVLGet(szEndptId,
																							&ucLineId,peReason) ) ){

		IFX_CIF_VALIDATE_VOICELINE(ucLineId,peReason);

		xLineCallingFeature.ucLineId = ucLineId;
  	xLineCallingFeature.iid.config_owner = IFX_VOIP;

		*pbEnable = IFX_FALSE;
		if( IFX_VMAPI_SUCCESS == 
			ifx_get_LineCallingFeatures(&xLineCallingFeature,
																			IFX_CIF_GET_FLAGS)  ){
			*pbEnable = xLineCallingFeature.bEnableDhl;
			strcpy(pcDhlNumber,xLineCallingFeature.acDhlNumber);
			eRet = IFX_SUCCESS;
		} 
		else{
			*peReason = IFX_CIF_CONFIG_ERROR;
		}
	}

	return eRet;
}
#endif
/*****************************************************************************
 *  Function Name   : IFX_CIF_DialToneLengthSet
 *  Description     :	This API sets the vunDialToneLength
 *  Input Values    :	EndptId
 *  Return Value    : IFX_SUCCESS/IFX_FAILURE
 *  Notes           :
 ****************************************************************************/
e_IFX_Return IFX_CIF_DialToneLengthSet()
{
	e_IFX_Return eRet = IFX_FAILURE;
	x_IFX_VMAPI_Misc xMisc = {{{{""}}}};

  xMisc.iid.config_owner = IFX_VOIP;
  if( IFX_VMAPI_SUCCESS == ifx_get_Misc(&xMisc,IFX_CIF_GET_FLAGS)){
		vunDialToneLength = 1000*xMisc.ucDialToneDuration;
		eRet = IFX_SUCCESS;
	}
	return eRet;
}
#ifdef CVOIP_SUPPORT
e_IFX_Return
IFX_CIF_DectSystemGet(x_IFX_VMAPI_DectSystem *pxDectSystem)
{
	pxDectSystem->iid.config_owner = IFX_VOIP;

  if(IFX_VMAPI_SUCCESS != ifx_get_DectInterface(pxDectSystem,IFX_VMAPI_OP_DEFAULT)){
  	return IFX_FAILURE;
  }

	ifx_vmapi_freeObjectList(pxDectSystem,IFX_VMAPI_DECT_SYSTEM);
  return IFX_SUCCESS;
}
#endif



e_IFX_Return IFX_CIF_GetRtpDscp(uchar8 *pucDscp)
{
	x_IFX_VMAPI_ProfileMediaRTP xrtp;
	
	memset(&xrtp,0,sizeof(xrtp));
	ifx_get_ProfileMediaRTP(&xrtp,0);
	*pucDscp = xrtp.ucRtpDscp;
	return IFX_SUCCESS;
}
