/**************************************************************************
 **   SRC_FILE          :IFX_DP.c
 **   PROJECT           : DECT-VOIP GW
 **   MODULES          :
 **   SRC VERSION       : v0.1
 **   DATE                  :
 **   AUTHOR            : Voip-Gw Team
 **   DESCRIPTION   :
 **   FUNCTIONS        :
 **   COMPILER          : GCC
 **   REFERENCE         : Coding guide lines V2.0
 **   COPYRIGHT         : Copyright © 2004 Infineon Technologies AG
 **                        St. Martin Strasse 53; 81669 München, Germany
 **   DESCLAIMER        : Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are grant.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "IFX_Config.h"
#include "IFX_DialPlanIf.h"
#include "IFX_DialPlan.h"
#define printf(...)
#define IFX_DP_BUF_SIZE 256
/************** Data declerations *************/

/*The size of malloced array of dial plan structures*/
int32 viNumDpRules;
/*The pointer which will be pointing to starting array location */
x_IFX_DP_Rule *vpxDpRule = NULL;
uint16 vunFullInterdigitTimer = IFX_FULL_INTERDIGIT_DURATION;
uint16 vunProgInterdigitTimer = IFX_PROGRESSIVE_INTERDIGIT_DURATION;
/*The Number of digits after which the call 
  would be taken over default interface*/
x_IFX_DP_Rule *pxDEF_IF_Rule = NULL;
/*The Debug library Id*/
uchar8 vucDpModId = 0;
uchar8 gucMindgts,gucMaxdgts;
/*****Action names for debugging****/

const char8 * aszDpActions[]=
{
	[IFX_DP_ANON_CALLBLOCK_ACTV] 			="IFX_DP_ANON_CALLBLOCK_ACTV",
	[IFX_DP_ANON_CALLBLOCK_DEACTV]		="IFX_DP_ANON_CALLBLOCK_DEACTV",
	[IFX_DP_AUTO_REDIAL_ACTV]				="IFX_DP_AUTO_REDIAL_ACTV",
	[IFX_DP_AUTO_REDIAL_DEACTV]			="IFX_DP_AUTO_REDIAL_DEACTV",
	[IFX_DP_DND_ACTV]							="IFX_DP_DND_ACTV",
	[IFX_DP_DND_DEACTV]						="IFX_DP_DND_DEACTV",
	[IFX_DP_CALLWAITING_ACTV]				="IFX_DP_CALLWAITING_ACTV",
	[IFX_DP_CALLWAITING_DEACTV]			="IFX_DP_CALLWAITING_DEACTV",
	[IFX_DP_CALLWAITING_PERCALL_ACTV]	="IFX_DP_CALLWAITING_PERCALL_ACTV",
	[IFX_DP_CALLWAITING_PERCALL_DEACTV]	="IFX_DP_CALLWAITING_PERCALL_DEACTV",
	[IFX_DP_UNC_CFWD_ACTV]					="IFX_DP_UNC_CFWD_ACTV",
	[IFX_DP_UNC_CFWD_DEACTV]				="IFX_DP_UNC_CFWD_DEACTV",
	[IFX_DP_BUSY_CFWD_ACTV]					="IFX_DP_BUSY_CFWD_ACTV",
	[IFX_DP_BUSY_CFWD_DEACTV]				="IFX_DP_BUSY_CFWD_DEACTV",
	[IFX_DP_NOANS_CFWD_ACTV]				="IFX_DP_NOANS_CFWD_ACTV",
	[IFX_DP_NOANS_CFWD_DEACTV]				="IFX_DP_NOANS_CFWD_DEACTV",
	[IFX_DP_CID_BLOCK_ACTV]					="IFX_DP_CID_BLOCK_ACTV",
	[IFX_DP_CID_BLOCK_DEACTV]				="IFX_DP_CID_BLOCK_DEACTV",
	[IFX_DP_CID_BLOCK_PERCALL_ACTV]		="IFX_DP_CID_BLK_PERCALL_ACTV",
	[IFX_DP_CID_BLOCK_PERCALL_DEACTV]	="IFX_DP_CID_BLK_PERCALL_DEACTV",
#ifdef DIAL_PLAN_REMOVE
	[IFX_DP_DEF_OUTBOUND_INTERFACE_PSTN]="IFX_DP_DEF_OTBND_IFACE_PSTN",
	[IFX_DP_DEF_OUTBOUND_INTERFACE_VOIP]="IFX_DP_DEF_OTBND_IFACE_VOIP",
#endif
	[IFX_DP_BLIND_TX]							="IFX_DP_BLIND_TX",
#ifdef DIAL_PLAN_REMOVE
	[IFX_DP_PSTN_HOOKFLASH]					="IFX_DP_PSTN_HOOKFLASH",
#endif
	[IFX_DP_CALL_RETURN]						="IFX_DP_CALL_RETURN",
	[IFX_DP_CALLWAITING_REJECT]			="IFX_DP_CALLWAITING_REJECT",
	[IFX_DP_VOICEMAIL_RETRIVAL]			="IFX_DP_VOICEMAIL_RETRIVAL",
	[IFX_DP_NON_DEFAULT_VL_DIAL]			="IFX_DP_NON_DEFAULT_VL_DIAL",
	[IFX_DP_DISCONNECT_LASTACTV_CALLL]	="IFX_DP_DISCNN_LASTACTV_CALLL",
	[IFX_DP_RESUME_LASTACTV_CALLL]		="IFX_DP_RESUME_LASTACTV_CALLL",
	[IFX_DP_RESUME_NON_LASTACTV_CALLL]	="IFX_DP_RESUME_NON_LA_CALLL",
	[IFX_DP_CONFERENCE]						="IFX_DP_CONFERENCE",
	[IFX_DP_SPEED_DIAL]						="IFX_DP_SPEED_DIAL",
	[IFX_DP_EXTENSION_DIAL]					="IFX_DP_EXTENSION_DIAL",
#ifdef DIAL_PLAN_REMOVE
	[IFX_DP_SERV_SIDE_CFG]					="IFX_DP_SERV_SIDE_CFG",
#endif
	[IFX_DP_TWO_STAGE_PSTN_DIALING]		="IFX_DP_TWO_STAGE_PSTN_DIAL",
	[IFX_DP_LOCAL_PSTN_CALLS]				="IFX_DP_LOCAL_PSTN_CALLS",
#ifdef DIAL_PLAN_REMOVE
	[IFX_DP_LOCAL_VOIP_CALLS]				="IFX_DP_LOCAL_VOIP_CALLS",
	[IFX_DP_STD_PSTN_CALLS]					="IFX_DP_STD_PSTN_CALLS",
	[IFX_DP_STD_VOIP_CALLS]					="IFX_DP_STD_VOIP_CALLS",
	[IFX_DP_ISD_PSTN_CALLS]					="IFX_DP_ISD_PSTN_CALLS",
	[IFX_DP_ISD_VOIP_CALLS]					="IFX_DP_ISD_VOIP_CALLS",
#endif
	[IFX_DP_EMERGENCY_CALLS]				="IFX_DP_EMERGENCY_CALLS",
	[IFX_DP_DIALDEFAULT_DEF_IF]			="IFX_DP_DIALDEFAULT_DEF_IF",
#ifdef DIAL_PLAN_REMOVE
	[IFX_DP_DIRECT_IP_CALLS]				="IFX_DP_DIRECT_IP_CALLS",
#endif
#ifdef ENABLE_DBG_THR_PHONE
	[IFX_DP_ENABLE_DEBUGS]					="IFX_DP_ENABLE_DEBUGS",
#endif
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
#ifdef ENABLE_PIN_CODE_CFG_THR_PHONE
	[IFX_DP_CHANGE_BASE_PIN]				="IFX_DP_CHANGE_BASE_PIN",
#endif
#ifdef DEBUG_COSIC
	[IFX_DP_DEBUG_COSIC]            ="IFX_DP_DEBUG_COSIC",
#endif
#endif //DECT_SUPPORT
#ifdef DELAYED_HOTLINE
	[IFX_DP_DHL_ACTV]							="IFX_DP_DHL_ACTV",
	[IFX_DP_DHL_DEACTV]						="IFX_DP_DHL_DEACTV",
#endif
	[IFX_DP_MAX_DP_ACTIONS]					="IFX_DP_MAX_DP_ACTIONS" 

};

/************** STATIC UTILITY FUNCTIONS *************/

STATIC inline void PrintRule(x_IFX_DP_Rule *dpRule)
{
	char8 szdbg_buff[IFX_DP_BUF_SIZE];

	memset(szdbg_buff,0,IFX_DP_BUF_SIZE);
	sprintf(szdbg_buff,"Prefix:=%s,Min:=%d,Max:=%d",dpRule->szPrefix,dpRule->ucMin,dpRule->ucMax);
	//printf("Prefix:=%s,Min:=%d,Max:=%d",dpRule->szPrefix,dpRule->ucMin,dpRule->ucMax);
	IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, szdbg_buff);
	sprintf(szdbg_buff,"DgtRmv:=%d,Pos:=%d,Act:=%s",dpRule->ucDgtRmv,dpRule->ucPosRmv,dpRule->acAction);
	//printf("DgtRmv:=%d,Pos:=%d,Act:=%s",dpRule->ucDgtRmv,dpRule->ucPosRmv,dpRule->acAction);
	IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR, szdbg_buff);
	return;
}

/*****************************************************************
 * Name: IFX_Match_dgt
 * Input values:Pointers to pointers for the digitpattern and rule string
 * 				 
 * Output Values:It Advances both pointers to point to the next digit in 
 						the prefix/Rule as well as in the Digitpattern. 
 * 				  
 * Return Values:MATCHED/NOT_MATCHED
 * Action: It matches the digit of a rule (May be a single digit 
			 or may be in the format [x-y]) with pattern digit
 ****************************************************************/
STATIC uchar8 IFX_Match_dgt(IN_OUT char8 **ppcdgtstr,
					 				IN_OUT char8 **ppcrule)
{
	char8 upplim=0,lowlim=9;
	/*Check whether valid rule digit*/
	if(IFX_IS_RUL_DIG(**ppcrule))
	{		  
		/*Check whether valid telephone digit*/
		if(IFX_IS_TEL_DIG(**ppcdgtstr))
		{
			/*for the [upperlim-lowerlom] kind of rule digits*/	  
			if(**ppcrule == '[')
			{
				(*ppcrule)++;
	 			lowlim = **ppcrule;		
				(*ppcrule) ++;
	 			if(**ppcrule != '-')
			  		return NOT_MATCHED;		  
				(*ppcrule)++;
	 			upplim = **ppcrule;						  	  
				(*ppcrule)++;
	 			if(**ppcrule != ']')
			  		return NOT_MATCHED;
				//Printf("\n Lowlim = %c Ulim - %c \n",lowlim,upplim);
 				if((**ppcdgtstr <= upplim) && (**ppcdgtstr >= lowlim))
					return MATCHED;
				else 
					return NOT_MATCHED;			
			}
 			else
			/*Else go for exact match*/		  
		   {
				if(**ppcrule == **ppcdgtstr)
					return MATCHED;
		 		else		
					return NOT_MATCHED;			
			}			  
		}
		else 	
			return NOT_MATCHED;
	}
	else 	
		return NOT_MATCHED;
}		  


/*****************************************************************
 * Name: IFX_Match_prefix
 * Input values:	-The Index in the global array of Num Plan Rule structures
 * 				 	-The string to be analyzed.
 						-The Type of matching to be done (PARTIAL/FULL)
 * Output Values: 
 					 
 * 				  
 * Return Values:MATCHED/NOT_MATCHED
 * Action: 	-This function is called only in the NOT_MATCHED_STATE(With type=PARTIAL) Or 
 					for confirmation (in IFX_Dialout or IFX_Find_Perfect_Match with type=FULL)
 				-It loops through the dialstring and prefix present at the specified 
					index in the global array of Numplan rules and calls the IFX_Match_dgt function
				-The PARTIAL/FULL comes in picture if digitstring is over but prefix is not.
					here, if the PARTIAL type is passed, we will return the MATCHED/CONTINUE
					(both are #defined to same value by the way) Since we could be expecting some 
					digits ahed .
					but FULL is passed, we will returm MISMATCH.
				-At some point of time f the dialstring exceeds the Max specified in the rule structure;
					MISMATCH is returned	
 ****************************************************************/

STATIC uchar8 IFX_Match_prefix(IN uchar8 ucIdx,IN char8 *string ,uchar8 type)
{
	char8 * pcdgtstr=string;
	char8 * pcrule=vpxDpRule[ucIdx].szPrefix ;
	
	//printf("\n In function %s \n",__FUNCTION__);
	while(*pcdgtstr)
	{
		//printf("\n Rul = %c String =%c \n",*pcrule,*pcdgtstr);
			  
		/*if prefix is over*/	  
		if(*pcrule == '\0')
		{
			//printf("\n Here 1\n");
			/*Till now, the match is there now check for minimum number of digits*/
			if((strlen(string)<=vpxDpRule[ucIdx].ucMax))
				return MATCHED;
	 		else 
			  return NOT_MATCHED;		  
		}	  
		else
		{		  
		//Printf("\n Rul:%c Dgtstr:%c \n",*pcrule,*pcdgtstr);				 
			if(IFX_Match_dgt(&pcdgtstr,&pcrule)!=MATCHED)
			{	  
				return NOT_MATCHED;
			}
		}		
		pcdgtstr++;pcrule++;
	}
	//Printf("\nWhile broke :- Rul = %c String =%c \n",*pcrule,*pcdgtstr);
	/*When dial string is over but prefix is not*/
	if((*pcrule)&&(type == PARTIAL))
		return MATCHED;
	if((*pcrule)&&(type == FULL))
		return NOT_MATCHED;
	/*The Following condition when prefix and 
	  dialstring both are over and matched!!!*/
	else
	{
	   /*Till now, the match is there now check for minimum number of digits*/
	   //if((strlen(string)>=dpr[ucIdx].Min)&&(strlen(string)<=dpr[ucIdx].Max))
	   if((strlen(string)<=vpxDpRule[ucIdx].ucMax))
	         return MATCHED;
	   else
	        return NOT_MATCHED;
	}	
}


/*****************************************************************
 * Name: IFX_Match_rule
 * Input values:	-The Index in the global array of Num Plan Rule structures
 * 				 	-The string to be analyzed.
 						
 * Output Values: 
 					 
 * 				  
 * Return Values:MATCHED/NOT_MATCHED/CONTINUE
 * Action:
 				-Function called only in PARTIAL_MATCH_STATE with Match_Dgt
				-It Confirms whether Prefix is Matching and digits are
					within MAX and MIN Limits.and returns 
					based on limits,returns	MATCHED/MISMATCHED/CONTINUE
****************************************************************/
STATIC uchar8 IFX_Match_rule(IN int32 ucIdx,IN char8 *string )
{
	char8 * pcdgtstr=string;
	char8 * pcrule=vpxDpRule[ucIdx].szPrefix ;

	while(*pcrule)
	{
			if(IFX_Match_dgt(&pcdgtstr,&pcrule)!=MATCHED)
			{	  
				return NOT_MATCHED;
			}
		pcdgtstr++;pcrule++;
	}
	if(strlen(string)==vpxDpRule[ucIdx].ucMax)
	{
			  //Printf("\n Returning Continue\n");		
			  return MATCHED;
	}
	else if(strlen(string)>vpxDpRule[ucIdx].ucMax)
	{
			  //Printf("\n Returning Not Matched\n");		
			  return NOT_MATCHED;
	}
	else
	{
			  //Printf("\n Returning NOT-MATCHED \n");		
			  return CONTINUE;
	}		  
}

/*****************************************************************
 * Name: IFX_Dialout
 * Input values:	-The Index in the global array of Num Plan Rule structures
 * 				 	-The string to be analyzed.
 						-The pointer to output buffer.
 						
 * Output Values: 
 					 
 * 				  
 * Return Values:SUCCESS/FAILURE
 * Action:-When the dial plan is ready to dial out, This function will be invoked.
 * 			it will give the dailable string as output
****************************************************************/

STATIC e_IFX_Return IFX_Dialout(IN char8 ucIdx1,
					 					IN char8 *input,OUT char8 *output)
{
	char8 * pcptrin = input	;
	char8 * pcptrout = output	;
	char8 acbuff[IFX_DP_BUF_SIZE];

  int32 iCnt=0,len=0;
	uchar8 ucIdx;
	/*Hack for the DEFAULT_INTERFACE rule without prefix, 
	  so ucIdx1 will be -1 so copy input to output*/
	if(ucIdx1 < 0)
		{
		strcpy(output,input);
		/*Remove the last T*/
		len = strlen(output);
		output[len -1]='\0';
		return IFX_SUCCESS;
		}
	/*Else for other rules*/
	ucIdx = ucIdx1;
	//Printf("\n In  %s\n",__FUNCTION__);
	/*Donot touch the individual string , work on buffer*/
	memset(acbuff,0,IFX_DP_BUF_SIZE);
	strcpy(acbuff,input);
	/*Remove last T*/	
	len = strlen(acbuff);
	if (len > 0)
		acbuff[len -1]='\0';
	/*Assign new value to len*/
	len = strlen(acbuff);
	
	/*Confirm once before dialing*/
	if(!((len>=vpxDpRule[ucIdx].ucMin)&&(len<=vpxDpRule[ucIdx].ucMax)&&(MATCHED 
									== IFX_Match_prefix(ucIdx,acbuff,FULL))))
			         return IFX_FAILURE;
	
	if(vpxDpRule[ucIdx].ucDgtRmv == 0)
		{
			/*If no digit is to be removed, copy input to output*/		  
			strcpy(output,input);
			/*Remove the last T*/
			len = strlen(output);
			output[len -1]='\0';
			return IFX_SUCCESS;
		}
	else
		{
			/**Code to remove appropriate number of digits from specified position*/	  
			while(*pcptrin)
			{					  
				if((iCnt >= vpxDpRule[ucIdx].ucPosRmv)&&(iCnt < 
									(vpxDpRule[ucIdx].ucPosRmv+ vpxDpRule[ucIdx].ucDgtRmv)))
				{						  
					pcptrin++ ;	  
					iCnt++;
				}
				else
				{		  
					*pcptrout = *pcptrin;
					iCnt++;	  
					pcptrin++;	  
					pcptrout++;
				}	
			}
		*pcptrout	= '\0';
		len = strlen(output);
		output[len -1]='\0';
		return IFX_SUCCESS;				  
		}		  	
}

/*****************************************************************
 * Name: IFX_Find_perfect_match
 * Input values:	The string to be analyzed. 						
 * Output Values:  					 
 * 				  
 * Return Values:SUCCESS/FAILURE
 * Action:-This function is used to get the perfect match
 * 		-It loops through entire array and returns when match is returned.
 			-It is Invoked only in NO_MATCHED_STATE 	
****************************************************************/

STATIC int32 IFX_Find_perfect_match(char8 *dgtpattern)
{		
	int32 iCnt,len;
	char8 acbuff[IFX_DP_BUF_SIZE];

	//Printf("\n In  %s\n",__FUNCTION__);
	/*Donot touch the individual string , work on buffer*/
	memset(acbuff,0,IFX_DP_BUF_SIZE);
	strcpy(acbuff,dgtpattern);
	/*Remove last T*/	
	len = strlen(acbuff);
	if (len > 0)
		acbuff[len -1]='\0';
	/*Assign new value to len*/
	len = strlen(acbuff);	
	for(iCnt=0;iCnt<viNumDpRules;iCnt++)
	{
		if((len>=vpxDpRule[iCnt].ucMin)&&(len<=vpxDpRule[iCnt].ucMax)&&
							(MATCHED == IFX_Match_prefix(iCnt,acbuff,FULL)))
			return iCnt;	  
	}		  
	return IFX_FAILURE;
}		  
			
/*****************************************************************
 * Name: IFX_Match
 * Input values:	-The string to be analyzed.
						-Dialplan Private data	 
 * Output Values: -The string to be dialed out

 * 				  
 * Return Values:SUCCESS/FAILURE
 * Action:-The function is divided in 5 sections.
 				As specified by demarcations
****************************************************************/
int32 IFX_Match(
					 OUT uchar8 *ucAction,
					 OUT dp_rule* dprule_matched,
					 IN_OUT char8 *dialout_string,
					 IN char8 *dgtpattern,
					 IN x_dp_pvt_data * dpdata
			)
{

	int8 iCnt=0,ucIdx=0;	 
	int8 iRet=0;	 
  int8 ucmatched_rules=0;
	x_IFX_DP_Rule *dpr =vpxDpRule;	

	memset(dprule_matched,0,sizeof(dp_rule));
	*ucAction=MISMATCH;
/***********ERROR CONDITION CHECKS *****************************************/	
	/*Empty dial-string*/
	if(!dgtpattern[0])
	{
	memset(dprule_matched,0,sizeof(dp_rule));
	*ucAction=MISMATCH;
   return IFX_SUCCESS;		
	}		  
	/*No digits dialed, just timeout*/
	if(!strcmp(dgtpattern,"T"))
	{
	memset(dprule_matched,0,sizeof(dp_rule));
	*ucAction=MISMATCH;
   return IFX_SUCCESS;		
	}		  
/****************** LONG TIMEOUT HAPPENED ***************************/
	//Printf("\n In function %s\n",__FUNCTION__);
	//Printf("\n dpdata->ucDpstate = %d\n",dpdata->ucDpstate);
	//Printf("\n dpdata->NumRulesMatchedLast = %d\n",dpdata->NumRulesMatchedLast);
	
	/*String contains Long timeout*/
	if(strchr(dgtpattern,'T') != NULL)
	{
		if(dpdata->ucDpstate == NO_MATCH_STATE)		
		{
			/*No matched state , So Last attempt to find perfect match */
			
			//Printf("\n Here \n");
			iRet = IFX_Find_perfect_match(dgtpattern);
			if(iRet != IFX_FAILURE)
			{
				/*Match found*/	  
				dpdata->ucIndex = iRet;		  
				/*Dialout*/											  
				if(IFX_FAILURE == IFX_Dialout(dpdata->ucIndex,dgtpattern,dialout_string))
				{
					memset(dprule_matched,0,sizeof(dp_rule));
					*ucAction=MISMATCH;
		      	return IFX_SUCCESS;			  
				}
	 			else
			  	{			  
      			memcpy(dprule_matched,&(dpr[dpdata->ucIndex]),sizeof(dp_rule));
					*ucAction=DIALOUT;
	   			return IFX_SUCCESS;
				}
			}
			/*If The DEFAULT_INTERFACE rule is configured*/
			else if(pxDEF_IF_Rule)
			{
				if((pxDEF_IF_Rule->ucMin <= (strlen(dgtpattern)-1)) && 
				(gucMindgts <= (strlen(dgtpattern)-1)) &&
				(pxDEF_IF_Rule->ucMax >= (strlen(dgtpattern)-1)) &&
				                (gucMaxdgts >= (strlen(dgtpattern)-1)))
				{
					/*And adequate number of digits are being dialed*/	  
					IFX_Dialout(-1,dgtpattern,dialout_string);
					memcpy(dprule_matched,pxDEF_IF_Rule,sizeof(dp_rule));
         		*ucAction=DIALOUT;
					return IFX_SUCCESS;
				}
			}			 
			else
			{
				memset(dprule_matched,0,sizeof(dp_rule));
		   	*ucAction=MISMATCH;
	      	return IFX_SUCCESS;		 				  
			}	  
			memset(dprule_matched,0,sizeof(dp_rule));
		   *ucAction=MISMATCH;
	      return IFX_SUCCESS;		 				  
		}
			  
		if(dpdata->ucDpstate == PARTIAL_MATCH_STATE)				
		{
			/*partial matched state , String should contain S and not T */
		   /*So Something wrong!!*/
			
			//Printf("\n Minor err In  %s\n",__FUNCTION__);
			//Printf("\n But dialing out\n");
				  
			/*But Dialout*/				
			 	if(IFX_FAILURE == IFX_Dialout(dpdata->ucIndex,dgtpattern,dialout_string))
			 	{
					memset(dprule_matched,0,sizeof(dp_rule));
					*ucAction=MISMATCH;
		      	return IFX_SUCCESS;			  
				}
				else
				{		  
      		memcpy(dprule_matched,&(dpr[dpdata->ucIndex]),sizeof(dp_rule));
				*ucAction=DIALOUT;
	   		return IFX_SUCCESS;	
				}	
		}		  
	}		  
/*******************SHORT TIMEOUT HAS HAPPENED*************************************/	
	/*String contains Short timeout*/
	if(strchr(dgtpattern,'S') != NULL)
	{
		/*But No matched state*/	  
		if(dpdata->ucDpstate == NO_MATCH_STATE)
		{
		   /*So Something wrong!!*/
			//Printf("\n Minor err In  %s\n",__FUNCTION__);
			//Printf("\n returning MISMATCH\n");
			memset(dprule_matched,0,sizeof(dp_rule));
			*ucAction=MISMATCH;
			return IFX_SUCCESS;
		}
		/**Partial matched state so*/		
		if(dpdata->ucDpstate == PARTIAL_MATCH_STATE)				  
		{
			/*Dialout Royally*/			  
			if(IFX_FAILURE == IFX_Dialout(dpdata->ucIndex,dgtpattern,dialout_string))
			{
					memset(dprule_matched,0,sizeof(dp_rule));
					*ucAction=MISMATCH;
		      	return IFX_SUCCESS;			  
			}
			else
			{  			  
			memcpy(dprule_matched,&(dpr[dpdata->ucIndex]),sizeof(dp_rule));
      	*ucAction=DIALOUT;
	   	return IFX_SUCCESS;	
			}	
		}		  
	}		  
/******************NO TIMEOUT HAS HAPPENED ******************************/			  
	if(dpdata->ucDpstate == NO_MATCH_STATE)
	{		  
		//Printf("\n No timeout\n");
	
		/*Match the incoming string with each rule in dpr*/
		for(iCnt=0;iCnt<viNumDpRules;iCnt++)
		{
		  if(IFX_Match_prefix(iCnt,dgtpattern,PARTIAL)==MATCHED)
		  {
			 ucmatched_rules++;	
			 ucIdx = iCnt;
			 dpdata->ucIndex = ucIdx;
		  }	  	 
		}	  
		
		//Printf("\n Matched rules=%d\n",ucmatched_rules);
		//Printf("\n %s \n",dpr[dpdata->ucIndex].acAction);
		
		/*Only one rule matches*/
		if(ucmatched_rules == 1)
		{
			/*Change the state to PARTIAL_MATCH_STATE*/
			dpdata->ucIndex = ucIdx;	  
			dpdata->NumRulesMatchedLast=ucmatched_rules;
			dpdata->ucDpstate = PARTIAL_MATCH_STATE;
			//Printf("\n Changiing state to partial matched state  %s\n",__FUNCTION__);
			/*donot return */ 	  
		}
		else if(ucmatched_rules == 0 )
		{
			/*Change the state to NO_MATCH_STATE*/
			dpdata->NumRulesMatchedLast=ucmatched_rules;
	      dpdata->ucDpstate = NO_MATCH_STATE;		
			/*Continue with long timer*/ 	  
			memset(dprule_matched,0,sizeof(dp_rule));
      	*ucAction=ST_LARGE_TIM;
	   	return IFX_SUCCESS;		
		}		  
		else if(ucmatched_rules > 1)
		{
			/*If multiple rules match, start large timer*/	  
			memset(dprule_matched,0,sizeof(dp_rule));
         *ucAction=ST_LARGE_TIM;
			return IFX_SUCCESS;
						
		}		  		
	}	
	/*If the state is partial match state*/
	if (dpdata->ucDpstate == PARTIAL_MATCH_STATE)
	{
		iRet = IFX_Match_rule(dpdata->ucIndex,dgtpattern);
		if(iRet==CONTINUE)
		{
		/*Continue with short timer*/
		memset(dprule_matched,0,sizeof(dp_rule));
      *ucAction=ST_SMALL_TIM;
	   return IFX_SUCCESS;		
		}
 		else if(iRet == MATCHED)	
		{
		/*Dialout*/		  
		 	if(IFX_FAILURE == IFX_Dialout(dpdata->ucIndex,dgtpattern,dialout_string))
		 	{
					memset(dprule_matched,0,sizeof(dp_rule));
					*ucAction=MISMATCH;
		      	return IFX_SUCCESS;			  
		  	}
			else			
			{
			memcpy(dprule_matched,&(dpr[dpdata->ucIndex]),sizeof(dp_rule));
      	*ucAction=DIALOUT;
	   	return IFX_SUCCESS;	
			}	
		}
 		else		
		{
		/*More digits than Max.or the prefix mismatches*/		  
		/*Move back to no match state*/		  
	      dpdata->ucDpstate = NO_MATCH_STATE;		
			memset(dprule_matched,0,sizeof(dp_rule));
      	*ucAction=ST_LARGE_TIM;
	   	return IFX_SUCCESS;		
		}	
	}
	else 
	{
			//Printf("\n Major err In  %s\n",__FUNCTION__);
			/*Major err , come and fix*/	  
			return IFX_FAILURE ;	  
	}		  		
/****************FUNCTION END*************************/	
}

/************** EXPOSED FUNCTIONS  *************/

/*************************************************
 * Name: IFX_DP_MAtch
 * Input values:-The String to be parsed,
 * 				 -A flag indicating the dialing is finished or not
 * Output Values:-The String to be dialed out,
 * 				  -The Action to be done. 
 * 				  -The Relavant string to be dialed
 * Return Values:SUCCESS/FAIL
 * Action: The wrper over IFX_Match and Invokes the function 
 				digit by digit.
 ************************************************/
e_IFX_Return  IFX_DP_Match(
					IN char8 *szDigitPattern,
					IN boolean bFinished,
					OUT uchar8 *pucAction,
					OUT char8 *szDialOutString,
					OUT x_IFX_DP_Rule *pxDpRuleMatched,
					OUT uint16* pucInterdigitTimer																								  
					)
{
	uchar8 ucAction = MISMATCH,iCnt;
	char8 dgtstr[IFX_DP_BUF_SIZE];	
	char8 szbuff[IFX_DP_BUF_SIZE];
	
	x_dp_pvt_data dpdata;
	memset(szbuff,0,IFX_DP_BUF_SIZE);  
	memset(&dpdata,0,sizeof(x_dp_pvt_data));
	strcpy(szDialOutString,"");
	IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,__FILE__);
	IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
                 "Input String",szDigitPattern);
	for(iCnt = 1;iCnt <= strlen(szDigitPattern);iCnt++)
	{
	      memset(dgtstr,0,IFX_DP_BUF_SIZE);  
	      strncpy(dgtstr,szDigitPattern,iCnt);
				dgtstr[iCnt]=0;
	      if(IFX_Match(&ucAction,pxDpRuleMatched,szDialOutString,dgtstr,&dpdata)==IFX_FAILURE)
			 {
					IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Numbering plan Fail"); 
			  		return IFX_FAILURE;
			 }
			dpdata.ucTim = ucAction;			
	}
   if(bFinished)
	{
	      memset(dgtstr,0,IFX_DP_BUF_SIZE);  
	      strcpy(dgtstr,szDigitPattern);
	      if(dpdata.ucTim == ST_SMALL_TIM)
				strcat(dgtstr,"S");
			else
				strcat(dgtstr,"T");
	      if(IFX_Match(&ucAction,pxDpRuleMatched,szDialOutString,dgtstr,&dpdata)==IFX_FAILURE)
		   {
				IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Numbering plan Fail"); 
			  return IFX_FAILURE;
			}
			if((ucAction == DIALOUT )&&(pxDpRuleMatched->eAction == IFX_DP_NON_DEFAULT_VL_DIAL))			
	 		{
					/*Hack for the Non default voice line rule*/
					strcpy(szbuff,szDialOutString);
					szDialOutString[0] = szDigitPattern[2] - '0';
					strcpy(&szDialOutString[1],szbuff);
			
	 		}
	}
	if(pucAction)	
		*pucAction = ucAction;
	
	if(pucInterdigitTimer)	
	{
	if(ucAction == ST_SMALL_TIM)	  
	  	*pucInterdigitTimer = vunProgInterdigitTimer;
	else  
		*pucInterdigitTimer = vunFullInterdigitTimer;
	}else{
		return IFX_FAILURE;
	}

	IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Num plan outputs:-");	
	switch(ucAction)
	{
		case ST_SMALL_TIM:
			IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
               				  "Action:","IFX_DP_ST_SMALL_TIM");
			IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
         	    "Timeout(msec)",*pucInterdigitTimer);
			break;
		case ST_LARGE_TIM: 
			IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
               				  "Action:","IFX_DP_ST_LARGE_TIM");
			IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
         	    "Timeout(msec)",*pucInterdigitTimer);
			break;
		case DIALOUT:
			IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
               				  "Action:","DIALOUT");
			IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
         		        "Output String",szDialOutString);
			IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
         		        "Sub Action:-",pxDpRuleMatched->acAction);
			break;
		case MISMATCH:
			IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_STRING_INFO,
               				  "Action:","IFX_DP_MISMATCH");
			break;
	}
		  
	return IFX_SUCCESS;
}

/********************************************************************
 * Name: IFX_DP_PopulateDialPlan
 * Input values:-
 * Output Values:-
 * Return Values:SUCCESS/FAIL
 * Action:This function Re-Populates the Internal global array of 
 				Numbering plan rules. 
******************************************************************* */
e_IFX_Return IFX_DP_DialPlanPopulate(IN x_IFX_DP_Rule * paxDpRules,
					                              IN uchar8 ucNumDpRules,
															IN uint16 unShortInterDigitTimer,
															IN uint16 unLongInterDigitTimer,		
															IN uchar8 ucDbgId
															)
{
	int32 iCnt,Idx;
	
	/***** ASSIGN VALUE TO DEBUG ID *****/
	vucDpModId = ucDbgId;
	/****Update the Interdigit timers*****/
	vunProgInterdigitTimer=unShortInterDigitTimer;
	vunFullInterdigitTimer=unLongInterDigitTimer;			  

	IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
         	    "Progressive Timeout(msec)",vunProgInterdigitTimer);
	IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH, IFX_DBG_ATA_INT_INFO,
         	    "Full Timeout(msec)",vunFullInterdigitTimer);

	IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_FUNC_ENTRY_INFO,
              __FUNCTION__ ,__FILE__);

	/*Check for the wrong inputs*/
	if((!paxDpRules) || (!ucNumDpRules))
	{
		IFX_DBGA(vucDpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                             "Null pointers in function parameters");	
		return IFX_FAILURE;
	}
	/*Free the Memory if allocated previously*/
	if(vpxDpRule)
		free(vpxDpRule);
	pxDEF_IF_Rule = NULL;	
	
	/*do malloc*/	
	vpxDpRule = (x_IFX_DP_Rule*)malloc(ucNumDpRules*sizeof(x_IFX_DP_Rule));
	if(!vpxDpRule)
	{
		IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
                             "Malloc Fail");	
		return IFX_FAILURE;
	}

	/*Memset the memory to zero*/
	memset(vpxDpRule,0,ucNumDpRules*sizeof(x_IFX_DP_Rule));
	Idx = 0 ;	

	/*Populate the Numbering plan rules*/
	for(iCnt = 0;iCnt < ucNumDpRules;iCnt ++)
	{
		/*Identify the NO PREFIX line rule*/
		if(paxDpRules[iCnt].eAction == IFX_DP_DIALDEFAULT_DEF_IF)
		{
			/*Put it to End of the array and DONOT INCREAMENT THE RULE COUNT ***/	  
			memcpy(&vpxDpRule[ucNumDpRules -1],&paxDpRules[iCnt],sizeof(x_IFX_DP_Rule));	
			/*Populate the verbal description of action*/
			strcpy(vpxDpRule[ucNumDpRules -1].acAction,
								 IFX_DP_GetAction(vpxDpRule[ucNumDpRules -1].eAction));
			/*ASSIGN THE RULE POINTER*/
			pxDEF_IF_Rule = &vpxDpRule[ucNumDpRules -1];	
			PrintRule(pxDEF_IF_Rule);	
		}
		else
		{
			memcpy(&vpxDpRule[Idx],&paxDpRules[iCnt],sizeof(x_IFX_DP_Rule));
			/*Populate the verbal description of action*/
			strcpy(vpxDpRule[Idx].acAction,IFX_DP_GetAction(vpxDpRule[Idx].eAction));
			PrintRule(&vpxDpRule[Idx]);	
			Idx ++ ;
		}
	}
# if 0
	if(!pxDEF_IF_Rule)	
	{	
		/*Initialize the default object*/
		memset(xDEF_IF_Rule,0,sizeof(x_IFX_DP_Rule));
		xDEF_IF_Rule.ucMin = 5;
		xDEF_IF_Rule.eAction = IFX_DP_DIALDEFAULT_DEF_IF;
		pxDEF_IF_Rule = &xDEF_IF_Rule;
	}	
# endif
	viNumDpRules = Idx;

	IFX_DBGA(vucDpModId,IFX_DBG_LVL_HIGH,IFX_DBG_ATA_INT_INFO,
             "Number of rules:-",viNumDpRules);

	return IFX_SUCCESS;
}

e_IFX_Return 
IFX_DP_RulePrefixGet(IN e_IFX_DP_Action eAction,
                     OUT char8 *pszPrefix){

  x_IFX_DP_Rule *pxdialrule =vpxDpRule;
  char8 *tmpPrefix = NULL;
  char8 i;

  if(IFX_DP_MAX_DP_ACTIONS == eAction){
   return IFX_FAILURE;
  }

  //while(pxdialrule != NULL){
	for (i=0; i<viNumDpRules; i++){
    if(pxdialrule->eAction == eAction){ 

      memcpy(pszPrefix,&pxdialrule->szPrefix[0],strlen(pxdialrule->szPrefix));                                                         
			pszPrefix[strlen(pxdialrule->szPrefix)]=0;
      tmpPrefix = strchr(pszPrefix,'[');
      if(tmpPrefix != NULL)
       *tmpPrefix = '\0';

      if(eAction == IFX_DP_LOCAL_PSTN_CALLS){
       if(pxdialrule->ucDgtRmv == 0)
        pszPrefix[0] = '\0';    
       else{
        memmove(&pszPrefix[0],&pxdialrule->szPrefix[pxdialrule->ucPosRmv],pxdialrule->ucDgtRmv);                                                         
        pszPrefix[pxdialrule->ucDgtRmv] = '\0'; 
       } 
      }
      printf("\n Actual Prefix=%s\n",pxdialrule->szPrefix); 
      printf("\n Prefix=%s\n",pszPrefix); 
      printf("\n pxdialrule->ucPosRmv=%d\n",pxdialrule->ucPosRmv); 
      printf("\n pxdialrule->ucDgtRmv=%d\n",pxdialrule->ucDgtRmv); 
      return IFX_SUCCESS;
    }
    pxdialrule++;       
  }                                          
  return IFX_FAILURE;
}
