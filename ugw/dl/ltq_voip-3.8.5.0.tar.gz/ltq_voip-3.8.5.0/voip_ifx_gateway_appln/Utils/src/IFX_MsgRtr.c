/***********************************************************************
*   SRC_FILE           : IFX_MsgRtr.c
*   PROJECT            : Voip Gateway Subsystem
*   MODULES            : Gateway Application
*   SRC VERSION        : V1.0
*   DATE               : 21/05/2007
*   AUTHOR             : Gw Appln Team
*   DESCRIPTION        :
*   FUNCTIONS          :
*   COMPILER           : mips(el)-linux-gcc
*   REFERENCE          :
*   COPYRIGHT          :Copyright © 2004
*                       Infineon Technologies AG
*                       St. Martin Strasse 53; 81669 München, Germany
*   DESCLAIMER         :Any use of this Software is subject to the conclusion
*                       of a respective License Agreement.
*                       Without such a License Agreement no rights to the
*                       Software are granted.
*   Version Control Section
*   $Author$ 
*   $Date$
*   $Revisions$
*   $Log$       Revision history
***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/ioctl.h>
#include <errno.h>
#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "IFX_Config.h"
#include "IFX_MediaMgrIf.h"
#include "IFX_MsgRtrIf.h"
#include "IFX_MsgRtr.h"

#ifdef CVOIP_SUPPORT
#define CVOIP_ONBOARD
#ifdef CVOIP_ONBOARD
#define DECT_DRV_SSC_HW_RESET 0x01
extern int32 viCVoipFd;
#endif
#endif
#define printf(...)

//#ifdef __PIN_CODE__
#if 0
extern uchar8 vszPinCode[5];
#endif


/* static declarations */
STATIC int32 IFX_MSGRTR_Main();

STATIC void
IFX_MSGRTR_InvokeCallBack(
                            IN  fd_set  *pxReadFdSet, 
                            IN  fd_set  *pxWriteFdSet, 
                            IN  fd_set  *pxExcFdSet,
                            OUT int32   *piNumFds);

STATIC e_IFX_Return
IFX_MSGRTR_GetEndptCbInfoIndex(char8 *acEndptId, int32 *piIndex);

/* extern declarations */
EXTERN int32 IFX_OS_CreateFifo(IN uchar8 * pucName);
EXTERN e_IFX_Return IFX_CFG_AgentInit();
/* 
   EXTERN e_IFX_Return
IFX_MMGR_DeviceEventsGet(uint32 uiFd, x_IFX_MMGR_DeviceEvents *pxDevEvtInfo,
                        int32 *iNumEndpts); */

/* static global variables */
STATIC fd_set                       vx_IFX_ReadFdSet, vx_IFX_WriteFdSet, 
                                    vx_IFX_ExcFdSet;
STATIC x_IFX_MSGRTR_CallBackInfo    vxCallBackInfo;

char8** vppcArgv = 0;
/***************************************************************************
* Function Name    : Application Main
* Description      : This function is an entry point into ATA Voip software.
* Input Values     : argc - Argument Count
*                  : argv - list of Arguments
* Output Values    : None
* Return Value     : void
* Notes            :
***************************************************************************/
int app_main()
{
  memset(&vxCallBackInfo, 0, sizeof(vxCallBackInfo));
  char8 acCommand[128]="";
  memset(*vppcArgv,0,strlen(*vppcArgv));

  strcpy(*vppcArgv, "GwApp");
  sprintf(acCommand,"echo %d > /var/run/ifxsip.pid",getpid());
  system(acCommand);
	printf("<AppMain> Invoking MsgRtrMain\n");
	IFX_MSGRTR_Main();
	return 0;
}

/***************************************************************************
* Function Name    : get_wan
* Description      : This function reads interface file and return interface name
* Input Values     : Inerface file name
* Output Values    : Inerface name
* Return Value     : IFX_SUCCESS/IFX_FAILURE
***************************************************************************/
static int32 get_wan(char8 *sFile, char8 *sWanVal)
{
	FILE *pFile;
	pFile = fopen(sFile, "r");

	if(NULL != pFile){
		fgets(sWanVal, 32, pFile);
		fclose(pFile);
		return IFX_SUCCESS;
	}

	return IFX_FAILURE;
}

/***************************************************************************
* Function Name    : restart_handler
* Description      : This function checks if GwApp is restarted after crash
* Input Values     : None
* Return Value     : void
***************************************************************************/
static void restart_handler()
{
	char8 acInterface[32];
	int32 nRet = IFX_FAILURE;

	if(access("/var/run/ifxsip.pid",F_OK) != 0){
		printf("GwApp is started first time\n");
		return;
	}

	system("killall Rtp 2> /dev/null");
	system("killall Fax 2> /dev/null");

	memset(acInterface, 0, 32);
	nRet = get_wan("/tmp/voip_def_wan", acInterface);

	if (nRet == IFX_FAILURE)
		nRet = get_wan("/tmp/voip_def_lan", acInterface);

	if (nRet == IFX_FAILURE)
		strcpy(acInterface, "br-lan");

	setenv("WAN",acInterface, 1);
	return;
}

#define NO_RECOVERY 1
/*************************************************************************** 
* Function Name    : main
* Description      : This function is an entry point into ATA Voip software.
* Input Values     : argc - Argument Count
*                  : argv - list of Arguments 
* Output Values    : None
* Return Value     : void
* Notes            :
***************************************************************************/
int main(int32	argc, char8 **argv)
{
#ifdef NO_RECOVERY
	char8 acCommand[128]="";

	memset(&vxCallBackInfo, 0, sizeof(vxCallBackInfo));
	vppcArgv = argv;
	memset(*vppcArgv,0,strlen(*vppcArgv));

	restart_handler();

	strcpy(*vppcArgv, "GwApp");
	sprintf(acCommand,"echo %d > /var/run/ifxsip.pid",getpid());
	system(acCommand);

	IFX_MSGRTR_Main();
#else
  uint16 pid =0;
  int32 iStatus = 0;

  vppcArgv = argv;
  memset(*vppcArgv,0,strlen(*vppcArgv));
  strcpy(*vppcArgv, "Monitor");
  
	printf("<Main> Invoking App Main\n");
  pid = fork();
  if(pid == 0){
 	app_main();
  }

  else{
    wait(&iStatus);
  	if(iStatus & 0xFF){
      system("/etc/rc.d/rc.restart_voip.sh");
  	}
  }
#endif
  return 0;
}

/***************************************************************************
* Function Name    : IFX_MSGRTR_Main
* Description      : This function is an entry point into Message Router.
* Input Values     : argc - Argument Count
*                  : argv - list of Arguments
* Output Values    : None
* Return Value     : IFX_SUCCESS, IFX_FAILURE
* Notes            :
***************************************************************************/
int IFX_MSGRTR_Main()
{

	/* Powering on the CVoIP so that CV can igone first CS low*/
#ifdef CVOIP_SUPPORT
#ifdef CVOIP_ONBOARD
/*
	if ( 0 > ioctl(viCVoipFd, DECT_DRV_SSC_HW_RESET, 0))
		printf("DECT_DRV_SSC_HW_RESET Reset failed\n");
	else
		printf("DECT_DRV_SSC_HW_RESET Reset passed\n");
*/
#else
	system("echo 0 > /sys/class/leds/ledc_8/brightness");
#endif
#endif
	/* 
	 * Initialise the configuration agent. This agent takes care of the complete
	 * system initialisation, which includes agents, Call Manager, Media Manager 
	 * Debug Library, Timer Interface and VMAPI
	 */
	if (IFX_CFG_AgentInit() != IFX_SUCCESS)
	{
			printf(" Configuration Agent initialisation failed\n");
			return IFX_FAILURE;
			//system("reboot");
	}
  printf("\n CFG Agent Init Success!!!!!\n");

	/* Powering on the CVoIP so that CV can igone first CS low*/
#ifdef CVOIP_SUPPORT
#ifdef CVOIP_ONBOARD
	if ( 0 > ioctl(viCVoipFd, DECT_DRV_SSC_HW_RESET, 1))
		printf("DECT_DRV_SSC_HW_RESET Reset failed\n");
	else
		printf("DECT_DRV_SSC_HW_RESET Reset passed\n");
#else
  system("echo 1 > /sys/class/leds/ledc_8/brightness");
#endif
#endif
	/*
	 * By now, it is presumed that the complete system is initialised and 
	 * that the fd_set's are populated by the agents. Now is the time to block
	 * on select system call
	 */

	while(1)
	{			
		fd_set  xTempReadFdSet, xTempWriteFdSet, xTempExcFdSet;
		int32	iNumFds;

		memcpy(&xTempReadFdSet,	&vx_IFX_ReadFdSet,	sizeof(fd_set));
		memcpy(&xTempWriteFdSet,&vx_IFX_WriteFdSet, sizeof(fd_set));
		memcpy(&xTempExcFdSet,	&vx_IFX_ExcFdSet,	sizeof(fd_set));

		iNumFds = select(FD_SETSIZE, &xTempReadFdSet, &xTempWriteFdSet,	
					&xTempExcFdSet, NULL);
		if (iNumFds <= 0)
		{	
			if (errno == EINTR)
						continue;
			/* something wrong has happened, exit from this place */
			printf(" select failed :: EXITING APPLICATION\n" );
			exit(-1);
		}

		/* search for the fd and invoke the call back function */
		IFX_MSGRTR_InvokeCallBack(&xTempReadFdSet, &xTempWriteFdSet,
					&xTempExcFdSet, &iNumFds);
 		if (iNumFds > 0)
		{
			/* the remaining fd's belong to SIP...hand it over to SIP */
      // printf("DECT FD unblocked %d\n",iNumFds);
       if(vxCallBackInfo.pfnDectFdCallback != NULL){
			    vxCallBackInfo.pfnDectFdCallback(&xTempReadFdSet, &xTempWriteFdSet,
					                              		&xTempExcFdSet, &iNumFds);
       }
		}                                               
		if (iNumFds > 0)
		{
			/* the remaining fd's belong to SIP...hand it over to SIP */
			vxCallBackInfo.pfnSipFdCallback(&xTempReadFdSet, &xTempWriteFdSet,
							&xTempExcFdSet, &iNumFds);
		}

#if 0
		if( iNumFds != 0 )
			printf("\n !!!!! SOME FDs WERE NOT USED !!!!!\n");
#endif
	}

	return IFX_SUCCESS;
}
 

/***************************************************************************
* Function Name    : IFX_MSGRTR_InvokeCallBack
* Description      : Invokes the callback function registered by the agents
* Input Values     : pxReadFdSet	- pointer to read fd set	 
*                  : pxWriteFdSet	- pointer to write fd set
*					 pxExcFdSet		- pointer to exception fd set
*					 piNumFds		- Number of fd's that have unblocked
* Output Values    : None
* Return Value     : void
* Notes            :
***************************************************************************/           
STATIC void
IFX_MSGRTR_InvokeCallBack(
                            IN  fd_set  *pxReadFdSet, 
                            IN  fd_set  *pxWriteFdSet, 
                            IN  fd_set  *pxExcFdSet,
                            OUT int32   *piNumFds)
{
    int i;
    
	if (*piNumFds <= 0)
	{
		return;
	}
	//printf(" Ready  FDs :: %d\n",*piNumFds);
	for (i=0; i < IFX_MAX_FDS; i++)
	{
			if (vxCallBackInfo.xFdCbInfo[i].pfnFdCallback != NULL)
			{
					x_IFX_MSGRTR_FdInfo   *pxFdInfo = &vxCallBackInfo.xFdCbInfo[i].xFdInfo;
					uchar8                  bFlag = 0;

					switch(pxFdInfo->eFdSetType)
					{
					case IFX_MSGRTR_READ_TYPE:
							bFlag = FD_ISSET(pxFdInfo->uiFd, pxReadFdSet);
							break;
					case IFX_MSGRTR_WRITE_TYPE:
							bFlag = FD_ISSET(pxFdInfo->uiFd, pxWriteFdSet);
							break;
					case IFX_MSGRTR_EXCEPTION_TYPE:
							bFlag = FD_ISSET(pxFdInfo->uiFd, pxExcFdSet);
							break;
					}
					
					if (bFlag)
					{
							/* invoke the call back function with this fd */
							vxCallBackInfo.xFdCbInfo[i].pfnFdCallback(pxFdInfo->uiFd);

							/* decrement one from number of FD's set */
							(*piNumFds)--;
							
							if (*piNumFds == 0)
							{
									break;
							}
					}
			}
	}
    
    return;
}


/***************************************************************************
* Function Name    : IFX_MSGRTR_RegisterFdCallBack
* Description      : Api provided to the agents to register callback function
*						for events arriving on file descriptors.
* Input Values     : paxFdInfo - pointer to array of x_IFX_MSGRTR_FdInfo 
*					 ucNumFds  - array size of paxFdInfo
*					 pfnFdCallback - pointer to FdCallback function
* Output Values    : None
* Return Value     : IFX_SUCCESS, IFX_FAILURE
* Notes            :
***************************************************************************/
PUBLIC e_IFX_Return 
IFX_MSGRTR_FdCallBackRegister(  
                                IN x_IFX_MSGRTR_FdInfo          *paxFdInfo,
                                IN uchar8                       ucNumFds,
                                IN pfn_IFX_MSGRTR_FdCallback    pfnFdCallback)
{
    uchar8  i, j;
    
    for(i=0; i < ucNumFds; i++)
    {
        j=0;
        
        while((j < IFX_MAX_FDS) && (vxCallBackInfo.xFdCbInfo[j].pfnFdCallback != NULL))
		{
			j++;
		}

        if (j == IFX_MAX_FDS)
        {
            /* encountered some serious problem */
            return IFX_FAILURE;
        }

		//printf("\nFD to be added :: %d\n",paxFdInfo[i].uiFd);
        /* add the fd to the appropriate fd_set based on the type */
        switch(paxFdInfo[i].eFdSetType)
        {
        case IFX_MSGRTR_READ_TYPE:
            FD_SET(paxFdInfo[i].uiFd, &vx_IFX_ReadFdSet);
            break;
        case IFX_MSGRTR_WRITE_TYPE:
            FD_SET(paxFdInfo[i].uiFd, &vx_IFX_WriteFdSet);
            break;
        case IFX_MSGRTR_EXCEPTION_TYPE:
            FD_SET(paxFdInfo[i].uiFd, &vx_IFX_ExcFdSet);
            break;
        }
        
        /* store the information */
        vxCallBackInfo.xFdCbInfo[j].pfnFdCallback = pfnFdCallback;
        vxCallBackInfo.xFdCbInfo[j].xFdInfo.uiFd = paxFdInfo[i].uiFd;
        vxCallBackInfo.xFdCbInfo[j].xFdInfo.eFdSetType = paxFdInfo[i].eFdSetType;
    }
    
    return IFX_SUCCESS;
}

/***************************************************************************
* Function Name    : IFX_MSGRTR_UnRegisterFd
* Description      : This function is used to unregister the fd
* Input Values     : pxFdInfo - Info of Fd that needs to be unregistered
* Output Values    : None
* Return Value     : IFX_SUCCESS
* Notes            :
***************************************************************************/
PUBLIC e_IFX_Return
IFX_MSGRTR_FdUnregister(
                        IN x_IFX_MSGRTR_FdInfo   *pxFdInfo)
{
	int32 j;

	/* remove this fd from the appropriate fd_set */
	switch (pxFdInfo->eFdSetType)
	{
	case IFX_MSGRTR_READ_TYPE:
		FD_CLR(pxFdInfo->uiFd, &vx_IFX_ReadFdSet);
		//printf("Removed from Read List\n");
		break;
	case IFX_MSGRTR_WRITE_TYPE:
		FD_CLR(pxFdInfo->uiFd, &vx_IFX_WriteFdSet);
		//printf("Removed from Write List\n");
		break;
	case IFX_MSGRTR_EXCEPTION_TYPE:
		FD_CLR(pxFdInfo->uiFd, &vx_IFX_ExcFdSet);
		//printf("Removed from EXCPT List\n");
		break;
	default:
		/* erroneous case */
		return IFX_SUCCESS;
	}

    for (j=0; j < IFX_MAX_FDS; j++)
    {
        if (vxCallBackInfo.xFdCbInfo[j].pfnFdCallback != NULL)
        {
          	//printf("Function set to NULL %d\n",pxFdInfo->uiFd);
            /* compare the fd's */
            if (vxCallBackInfo.xFdCbInfo[j].xFdInfo.uiFd == pxFdInfo->uiFd)
            {
                vxCallBackInfo.xFdCbInfo[j].pfnFdCallback	= NULL;
                vxCallBackInfo.xFdCbInfo[j].xFdInfo.uiFd	= 0;
                break;
            }
        }
    }

    return IFX_SUCCESS;
}


/***************************************************************************
* Function Name    : IFX_MSGRTR_RegisterEventCallBack
* Description      : Api provided to the agents to register callback function
*						for events arriving from TAPI devices.
* Input Values     : pszEndptId - pointer to endpoint array
*					 ucNumEndpts - Number of Endpoints in the above array
*					 pfnEventCallback - pointer to event callback function
* Output Values    : None
* Return Value     : IFX_SUCCESS, IFX_FAILURE
* Notes            :
***************************************************************************/
PUBLIC e_IFX_Return 
IFX_MSGRTR_EventCallBackRegister( 
        IN char8                        aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
        IN uchar8                       ucNumEndpts,
        IN pfn_IFX_MSGRTR_EventCallback pfnEventCallback)
{
    uchar8  i, j;

    /* allocate a structure for storing endpoint id and the corresponding call back */
    for (i=0; i < ucNumEndpts; i++)
    {
        j=0;

        while((j < IFX_MAX_ENDPTS) 
								&& (vxCallBackInfo.xEndptCbInfo[j].pfnEventCallback != NULL))
				{
					j++;
				}

        if (j == IFX_MAX_ENDPTS)
        {
            /* we have encountered some major problem here */
            return IFX_FAILURE;
        }

        /* store the information */
        vxCallBackInfo.xEndptCbInfo[j].pfnEventCallback = pfnEventCallback;
        strcpy(vxCallBackInfo.xEndptCbInfo[j].acEndptId, aszEndptId[i]);
    }

    return IFX_SUCCESS;        
}



/***************************************************************************
* Function Name    : IFX_MSGRTR_EventCallBackUnregister
* Description      : Api to unregister event callback function
* Input Values     : pszEndptId - pointer to endpoint id
* Output Values    : None
* Return Value     : IFX_SUCCESS
* Notes            :
***************************************************************************/
PUBLIC e_IFX_Return
IFX_MSGRTR_EventCallBackUnregister(
                            IN char8    aszEndptId[][IFX_MAX_ENDPOINTID_LEN],
                            IN uchar8   ucNumEndpts)
{
    uchar8  i, j;
    
    /* 
     * search for the EndptCallback structure that contains the Endptid, which 
     * needs to be unregistered
     */
    for (j=0; j < ucNumEndpts; j++)
    {
        for (i=0; i < IFX_MAX_ENDPTS; i++)
        {
            if (vxCallBackInfo.xEndptCbInfo[i].pfnEventCallback != NULL)
            {
                /* compare the endpoints id's */
                if (strcmp(vxCallBackInfo.xEndptCbInfo[i].acEndptId, aszEndptId[j]) == 0)
                {
                    /* clear the information */
                    vxCallBackInfo.xEndptCbInfo[i].pfnEventCallback = NULL;
                    break;
                }
            }
        }
    }

    return IFX_SUCCESS;
}




/***************************************************************************
* Function Name    : IFX_MSGRTR_RegisterSipFdCallBack
* Description      : Api provided to the agents to register callback function
*						for events arriving on file descriptors.
* Input Values     : paxFdInfo - pointer to x_IFX_MSGRTR_FdInfo 
*					 pfnFdCallback - pointer to FdCallback function
* Output Values    : None
* Return Value     : IFX_SUCCESS
* Notes            :
***************************************************************************/
PUBLIC e_IFX_Return 
IFX_MSGRTR_SipFdCallBackRegister(  
                                IN x_IFX_MSGRTR_FdInfo          *pxFdInfo,
                                IN pfn_IFX_MSGRTR_SipFdCallback pfnCallBack )
{
    /* add the fd to the appropriate fd_set based on the type */
    switch(pxFdInfo->eFdSetType)
    {
    case IFX_MSGRTR_READ_TYPE:
        FD_SET(pxFdInfo->uiFd, &vx_IFX_ReadFdSet);
        break;
    case IFX_MSGRTR_WRITE_TYPE:
        FD_SET(pxFdInfo->uiFd, &vx_IFX_WriteFdSet);
        break;
    case IFX_MSGRTR_EXCEPTION_TYPE:
        FD_SET(pxFdInfo->uiFd, &vx_IFX_ExcFdSet);
        break;
    }
		
		printf("\nSIP FD to be added :: %d\n",pxFdInfo->uiFd);
   
    /* store the SIP Fd Callback function */
    vxCallBackInfo.pfnSipFdCallback = pfnCallBack;

	return IFX_SUCCESS;

}
/***************************************************************************
* Function Name    : IFX_MSGRTR_RegisterDectFdCallBack
* Description      : Api provided to the agents to register callback function
*						for events arriving on file descriptors.
* Input Values     : paxFdInfo - pointer to x_IFX_MSGRTR_FdInfo 
*					 pfnFdCallback - pointer to FdCallback function
* Output Values    : None
* Return Value     : IFX_SUCCESS
* Notes            :
***************************************************************************/
PUBLIC e_IFX_Return 
IFX_MSGRTR_DectFdCallBackRegister(  
                                IN x_IFX_MSGRTR_FdInfo          *pxFdInfo,
                                IN pfn_IFX_MSGRTR_SipFdCallback pfnCallBack )
{
    /* add the fd to the appropriate fd_set based on the type */
    switch(pxFdInfo->eFdSetType)
    {
    case IFX_MSGRTR_READ_TYPE:
        FD_SET(pxFdInfo->uiFd, &vx_IFX_ReadFdSet);
        printf("Added to Read list\n");
        break;
    case IFX_MSGRTR_WRITE_TYPE:
        FD_SET(pxFdInfo->uiFd, &vx_IFX_WriteFdSet);
        printf("Added to Write list\n");
        break;
    case IFX_MSGRTR_EXCEPTION_TYPE:
        FD_SET(pxFdInfo->uiFd, &vx_IFX_ExcFdSet);
        printf("Added to Excep list\n");
        break;
    }
		
    printf("\nDECT FD to be added :: %d\n",pxFdInfo->uiFd);
   
    /* store the SIP Fd Callback function */
    vxCallBackInfo.pfnDectFdCallback = pfnCallBack;

	return IFX_SUCCESS;

}
//TODO: This is very important to aline with CM define IFX_CFG_AGENT_ENDPT_ID
#define IFX_CFG_AGENT_ID "-4" 

/***************************************************************************
* Function Name    : IFX_MSGRTR_HandleTapiEvents
* Description      : Routes events from TAPI to corresponding endpoints
* Input Values     : uiFd - file descriptor on which event is reported
* Output Values    : None
* Return Value     : IFX_SUCCESS, IFX_FAILURE
* Notes            :
***************************************************************************/
e_IFX_Return
IFX_MSGRTR_HandleTapiEvents(IN int32   iFd)
{
	x_IFX_MMGR_DeviceEvents		xDevEvtInfo[IFX_MMGR_MAX_FXS_CHANNELS +
																				IFX_MMGR_MAX_FXO_CHANNELS];
	int32						iNumEndpts, i, iIndex;

    /* call Media Manager API to obtain the events */
	/* TODO Change this value to some defines */
	iNumEndpts = IFX_MMGR_MAX_FXS_CHANNELS+IFX_MMGR_MAX_FXO_CHANNELS;
	if (IFX_MMGR_DeviceEventsGet(iFd, &xDevEvtInfo[0],
										&iNumEndpts) != (e_IFX_MMGR_Return) IFX_SUCCESS)	
	{
		/* is this failure really critical */
		return IFX_FAILURE;
	}

	if (iNumEndpts == 0)
	{
		/* this should not happen..a bug in MMGR */
		return IFX_FAILURE;
	}

	for (i=0; i < iNumEndpts; i++)
	{
		/* find the callback function for these endpoints and invoke them */
	 if(	xDevEvtInfo[i].uiEvents == 0 || IFX_MSGRTR_GetEndptCbInfoIndex(
				xDevEvtInfo[i].szEndPtId, &iIndex) != IFX_SUCCESS)
		{
			/* 
			 * Maybe there are no evnets or this endpoint forgot to register callback
			 * with MSGRTR. Ignore this event 
			 */
			//printf("Getting the cb info failed for channel %d\n",i);
#ifdef LTAM
			printf("Got event for %s: %d\n", 
											xDevEvtInfo[i].szEndPtId, xDevEvtInfo[i].uiEvents);
			/* If event related to line test, then route message to CFG agent */
		if( !(xDevEvtInfo[i].uiEvents & IFX_MMGR_EVENT_GR909_RESULT) ||
					IFX_SUCCESS != 
					IFX_MSGRTR_GetEndptCbInfoIndex(IFX_CFG_AGENT_ID, &iIndex) )
			{
				continue;
			}
#else
			continue;
#endif
		} 
		if (iIndex >= IFX_MAX_ENDPTS)
			return IFX_FAILURE;
		/* invoke the endpoint callback function */
		vxCallBackInfo.xEndptCbInfo[iIndex].pfnEventCallback(&xDevEvtInfo[i]);
		
	}
    
	return IFX_SUCCESS;
}


/***************************************************************************
* Function Name    : IFX_MSGRTR_GetEndptCbInfoIndex
* Description      : Gets the EndptCbInfoIndex by searching on endpoint id
* Input Values     : acEndptId - Endpoint Id
*					 piIndex   - pointer to the EndptCbInfoIndex
* Output Values    : None
* Return Value     : IFX_SUCCESS, IFX_FAILURE
* Notes            :
***************************************************************************/
STATIC e_IFX_Return
IFX_MSGRTR_GetEndptCbInfoIndex(char8 *acEndptId, int32 *piIndex)
{
	
	for(*piIndex=0; *piIndex < IFX_MAX_ENDPTS; (*piIndex)++)
	{
		if(vxCallBackInfo.xEndptCbInfo[*piIndex].pfnEventCallback != NULL)
		{
			/* compare the endpoint id's */
			if( !strcmp(vxCallBackInfo.xEndptCbInfo[*piIndex].acEndptId, acEndptId))
			{
				return IFX_SUCCESS;
			}
		}
	}
	
	return IFX_FAILURE;
}














                                  
