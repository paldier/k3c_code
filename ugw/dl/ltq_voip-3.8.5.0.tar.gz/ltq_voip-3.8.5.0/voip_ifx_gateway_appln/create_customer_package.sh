#!/bin/sh

if [ ! -n "$1" ] ; then
   echo "Usage : create_customer_pkg.sh SOURCE_PATH"
   exit 0
fi

if [ "$1" = "-h" ]; then
	echo "SOURCE"
	exit 0;
fi;

#Irrespective any package these sources have to be deleted


#Copy the above libraries

mkdir -p lib

if [ "$2" = "SOURCE" ]; then
mkdir -p lib
else
	#default Customer CD PKG
	find voip_ifx_sip \( -name stack_h -prune \) -o \( -type d ! -name voip_ifx_sip -print \) |xargs rm -rf

	#Copy the required binaries
	cp -f $1/lib/libsipua.a lib/
	cp -f $1/lib/libsdp.a lib/

fi;

rm -f create_customer_package.sh
rm -f voip_ifx_gateway_appln/create_customer_package.sh

