/**************************************************************************
 **   FILE NAME       : ifx_rtp_common.h
 **   PROJECT         : RTP/RTCP
 **   MODULES         : Common module for RTP/RTCP
 **   SRC VERSION     : V0.1
 **   DATE            : 15-08-2004
 **   AUTHOR          : Bharthraj
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER         : MIPS 4KC cross compiler
 **   REFERENCE        : 
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_RTP_COMMON_H__
#define __IFX_RTP_COMMON_H__

/* Project Specific Include Files */
#include "ifx_common_defs.h"
#include "ifx_ipc.h"
#define IFX_RTP_TRUE       1
#define IFX_RTP_FALSE      0

#define IFX_RTP_PKT  0
#define IFX_RTCP_PKT  1

#define IFX_RTP_RX_FIFO_PERM   0777
#define IFX_RTP_MAX_BUFF_SIZE  4000

#define IFX_RTP_MAX_CHANNELS 2

#define IFX_MAX_CODECS       17

#endif /* __IFX_RTP_COMMON_H__ */
