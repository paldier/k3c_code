/*****************************************************************************
  **   FILE NAME        : ifx_rtp_encode.h
  **   PROJECT          : Inca IP Phone
  **   MODULES          : RTP
  **   SRC VERSION      :
  **   DATE             : 10-02-2004
  **   AUTHOR           : Hari
  **   DESCRIPTION      : RTP Encoder Module in Kernel Mode
  **   FUNCTIONS        : IFX_RTP_EncodePacket
  **   COMPILER         : MIPS 4KC cross compiler
  **   REFERENCE        :
  **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
  **                     St. Martin Strasse 53; 81669 M�nchen, Germany
  **                     Any use of this Software is subject to the conclusion
  **                     of a respective License Agreement.Without such a
  **                     License Agreement no rights to the Software are granted.
  **  Version Control Section  **
  **   $Author$
  **   $Date$
  **   $Revisions$
  **   $Log$       Revision history
  *****************************************************************************/
#ifndef __IFX_RTP_ENCODE_H__
#define __IFX_RTP_ENCODE_H__

#define IFX_RTP_MAX_CHANNELS 2

typedef struct
{
   uint16 unSeqNo;
   uint32 uiSsrc;
   uint8 ucCC;
   uint32 auiCSRC[IFX_RTP_MAX_CONNS];
} x_IFX_RTP_EncoderInfo;

typedef struct
{
   uint16 unPayloadType;   /* Voice IANA Payload Type */
   uint32 uiTimeStamp;     /* RTP TimeStamp */
   uint16 unLength;        /* Length of Header + Payload */
   char8 *pacDataBuffer;  /* Header + Payload */
   uchar8 ucSID;            /* Voice + SID packet indicator */
} x_IFX_RTP_VoiceData;

typedef struct
{
   uint16 unPayloadType;   /* Dynamic IANA DTMF Payload Type */
   uint32 uiTimeStamp;     /* RTP TimeStamp */
   uchar8 ucDTMFDigit;      /* DTMF Digit */
   uint16 unDuration;       /* Total Duration of tone till now */
   char8 ucEnd;             /* Tone End Indicator */ 
   uchar8 ucVolume;         /* Volume in dB */
   uint16 unLength;        /* Length of Header + Payload , 4 DWORDs */
   char8 *pacDataBuffer;  /* Event Header + Payload */
} x_IFX_RTP_EventData;

#define IFX_RTP_DATA_TYPE_VOICE 0
#define IFX_RTP_DATA_TYPE_EVENT 1

EXTERN uchar8 IFX_RTP_EncoderInit( IN uchar8 ucChannelNumber,
   IN x_IFX_RTP_EncoderInfo *pEncInfo );

EXTERN uchar8 IFX_RTP_EncodePacket( IN uchar8 ucChannelNumber,
   IN uchar8 ucDataType, /* Voice = 0 or Event = 1*/
                     IN_OUT void *pvRtpData ); /* x_IFX_RTP_VoiceData or
                                                * x_IFX_RTP_EventData
                                                */

#endif /* __IFX_RTP_ENCODE_H__ */
