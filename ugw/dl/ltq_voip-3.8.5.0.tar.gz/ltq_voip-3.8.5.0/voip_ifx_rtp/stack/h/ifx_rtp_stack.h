/**************************************************************************
 **   FILE NAME       : ifx_rtp_stack.h
 **   PROJECT         : RTP/RTCP
 **   MODULES         : RTP/RTCP Stack definitions
 **   SRC VERSION     : V1.0
 **   DATE            : 15-08-2004
 **   AUTHOR          : Bharathraj
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER         : MIPS 4KC cross compiler
 **   REFERENCE        :
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_RTP_STACK_H__
#define __IFX_RTP_STACK_H__

/* Constants */
#define IFX_RTP_MAX_INACTIVE_INTERVALS  5
#define IFX_RTP_SENT_COUNT              2
/* RTCP Tx Interval defines */

#define IFX_RTCP_BW_FRAC                (6.25)
#define IFX_RTCP_COMPENSATION           (2.71828 - 1.5)
#define IFX_RTCP_MIN_TIME               (5.0)
#define IFX_RTCP_SENDER_BW_FRACTION     (0.25)
#define IFX_RTCP_RCVR_BW_FRACTION       (1 - IFX_RTCP_SENDER_BW_FRACTION)
#define IFX_RTP_DEFAULT_RTCP_BW         (5.0)
#define IFX_RTP_SEQ_NUM_ROC_THRESHOLD   50000
/* For local use only */
#define IFX_RTP_DEFAULT_APS             (100.0)
#define IFX_RTP_SESS_SELF               (1)


#define IFX_RTP_MAX_USE_RANGE    ((float64)300000.0)
#define IFX_RTP_SENDER_INFO_SIZE (6)
#define IFX_RTP_RXER_INFO_SIZE      (1)

#define IFX_RTCP_NO_BYE 0
//#define IFX_RTCP_BYE 1
#define IFX_RTP_INTERNAL_PORT 55555
#define IFX_RTP_INTERNAL_IP "127.0.0.1"
#define IFX_RTCP_MAX_MTU 1500
typedef struct
{
   uint8 ucCodecType;
   float32 fBandwidth;
} x_IFX_RTP_SessBw;

typedef struct
{
   uchar8 ucSessId;
   uint16 unReportType;
} x_IFX_RTP_RtcpReportInfo;

typedef enum
{
  IFX_RTP_REM_SESS,
  IFX_RTP_THREAD_SHUT,
  IFX_RTP_RSTRT_RTCP_TIMER,
  IFX_RTP_EMRGCY_RSTRT_RTCP_TIMER,
  IFX_RTP_ADD_SOCK_FD
} e_IFX_RTP_INT_MSG_TYPE;

typedef struct
{
  e_IFX_RTP_INT_MSG_TYPE eIntMsgType;
  uint32 uiSessPtr;
  uint32 uiConnPtr;
} x_IFX_RTP_INT_MSG;

/* Internal RTCP info - Used to indicate interval timer expiry */
typedef struct
{
   void * pxTimerInfo;
	/*
	 *     * Other useful Timer Info to be defined here
	*      */
}x_IFX_RTCP_TimerMsg;

/* Public Functions */

EXTERN char8 IFX_RTP_ProcessUpstreamRtpPkt(IN x_IFX_RTP_Session *pxSess,
                                           IN x_IFX_RTP_ConnInfo *pxConn,
                                           IN char8 *pcBuffer,
                                           IN uint16 unBuffLen );

EXTERN char8 IFX_RTP_ProcessDownstreamRtpPkt(IN x_IFX_RTP_Session *pxSess,
                                 IN x_IFX_RTP_ConnInfo *pxConn,
                                 IN char8 *pcBuffer,IN uint16 *punBuffLen,
                                 IN x_IFX_RTP_PacketSourceInfo *pxRemoteAddr );

EXTERN char8 IFX_RTP_ProcessDownstreamRtcpPkt(IN x_IFX_RTP_Session *pxSess,
                                 IN x_IFX_RTP_ConnInfo *pxConn,
                                 IN char8 *pcBuffer, IN uint16 unBuffLen,
                                 IN x_IFX_RTP_PacketSourceInfo *pxRemoteAddr );

EXTERN char8 IFX_RTP_RtcpStartSession(IN x_IFX_RTP_Session *pxSess);

/*
EXTERN char8 IFX_RTP_RtcpStopSession(IN x_IFX_RTP_Session *pxSess,
                                 IN x_IFX_RTP_ConnInfo *pxConn,
                                 IN uint8 ucFlag );
*/

EXTERN char8 IFX_RTP_ProcessRtcpInfo(IN void *pTimerCallBkParam );

EXTERN char8 IFX_RTP_SendRtcpReport(IN x_IFX_RTP_Session *pxSess,
                                 IN x_IFX_RTP_ConnInfo *pxConn,
                                 IN uint8 ucPktType,
                                 IN void* vpUserPlugInData);

EXTERN PUBLIC int8 IFX_RTP_TransmitPkt( IN x_IFX_RTP_Session *pxSess,
                                 IN x_IFX_RTP_ConnInfo *pxConn,
                                 IN uint8 ucPktType,
                                 IN char8 *pcPkt,
                                 IN uint16 unPktSize);
#if defined(ATA) || defined(AMAZON)
EXTERN char8 IFX_RTP_CsrcConfig(IN x_IFX_RTP_Session *pxSess,
                                IN x_IFX_RTP_ConnInfo *pxConn,
                                IN uint8 ucCC );
#endif
#endif /* __IFX_RTP_STACK_H__ */
