/**************************************************************************
 **   FILE NAME       : ifx_rtp_db.c
 **   PROJECT         : RTP/RTCP
 **   MODULES         : RTP/RTCP Database module
 **   SRC VERSION     : V0.1
 **   DATE            : 15-08-2004
 **   AUTHOR          : Bharathraj
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc,monta-vista linux
 **   REFERENCE       : Coding guide lines for VSS ,
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#include "ifx_rtp_pkt.h"
#include "ifx_rtp_api.h"
#include "ifx_rtp_memiface.h"
#include "ifx_rtp_oslayer.h"
#include "ifx_rtp_db.h"
#include "ifx_rtp_stack.h"
#include "ifx_rtp_parser.h"
#include "ifx_rtp_timeriface.h"
#include "ifx_debug.h"
#include "ifx_list.h"

x_IFX_RTP_Session *vpxRtpSessHeadPtr;
x_IFX_RTP_ConnInfo *vpxRtpConnHeadPtr;

extern IFX_RTP_fd_set v_RdSelectFd;
extern x_IFX_RTP_SyncCallBks vxSyncCallBks;
extern int32 viStackMode;
/******************************************************************
*  Function Name                :  IFX_RTP_DB_SetSdes
*  Description                  :  This function saves SDES items from
*                                  each chunk to the corresponding
*                                  connection in the  Database
*  Input Values                 :  ucSessId, ucConnId, pcRxPkt
*                               :  ucSessId = Session Id
*                               :  ucConnId = Connection Id
*                               :  pcRxPkt = Received Sdes Pkt
*  Output Values                :  none
*  Return Value                 :  IFX_RTP_SUCCESS \ IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8 IFX_RTP_DB_SetRxSdes(IN x_IFX_RTP_Session *pxSess,
                                  IN x_IFX_RTP_ConnInfo *pxConn,
                                  IN char8 *pcRxPkt)
{
  x_IFX_RTP_ConnList *pxConnList;
  x_IFX_RTP_ConnInfo *pxTempConn=NULL;
  uint32 *puiPkt    = (uint32 *) pcRxPkt,
         *puiPktEnd = (uint32 *) pcRxPkt + 1 +
	               IFX_RTP_Ntohs(((x_IFX_RTCP_Header *)pcRxPkt)->unLen),uiRxSsrc;
  int16 nIndex;

  if ( ((x_IFX_RTCP_Header *)puiPkt)->ucPktType != IFX_RTCP_SDES_PKT)
  {
    return IFX_RTP_FAIL;
  }

  if (IFX_RTP_Ntohs(((x_IFX_RTCP_Header *)puiPkt)->unLen) == 0 )
  {
    /* This is a valid but useless SDES packet */
    return IFX_RTP_SUCCESS;
  }

  /* Point to the first chunk - SSRC */
  puiPkt = (uint32 *) pcRxPkt + 1;

  /* Handle each SSRC/CSRC entry */
  for( nIndex = 0;
       (puiPkt < puiPktEnd) &&
       (nIndex < ((x_IFX_RTCP_Header *) pcRxPkt)->ucCount);
       nIndex++ )
  {
    uiRxSsrc = IFX_RTP_Ntohl( *(uint32 *)puiPkt );
    IFX_RTP_DB_AddToMemberList( pxSess, uiRxSsrc);

    pxConnList = pxSess->pxConnListHeadPtr;
    while(pxConnList != NULL)
    {
      pxTempConn = pxConnList->pxConn;

      if( pxTempConn->uiRxSsrc == uiRxSsrc )
      {
        break;
      }
      __ifx_list_GetNext((void*)(&pxConnList)); 
    }

    if( pxConnList == NULL )
    {
      puiPkt += 1 + (IFX_RTCP_GET_SDES_Size((char8*) (puiPkt + 1)) >> 2);
    }
    else
    {
      /* Point to the first chunk - data */
      puiPkt++;
      while( (puiPkt < puiPktEnd) &&
             (*(uint8 *) puiPkt != IFX_RTCP_SDES_ITEM_END) )
      {
        /* Store each SDES item in data base */
        switch( *( uint8 * ) puiPkt )
        {
          case IFX_RTCP_SDES_ITEM_CNAME:
            strncpy( (pxTempConn->xRxSrcDesc.acCanName),
                     ((char8 *) puiPkt + 2),*((uint8 *) puiPkt + 1) );
            IFX_DBGA( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
                      "<DB> Canonical Name %s and sessid =",
                      pxTempConn->xRxSrcDesc.acCanName,pxSess );
            break;
          case IFX_RTCP_SDES_ITEM_NAME:
            strncpy( (pxTempConn->xRxSrcDesc.acName),
                     ((char8 *) puiPkt + 2),*((uint8 *) puiPkt + 1) );
             IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
                      "<DB> Name ",pxTempConn->xRxSrcDesc.acName );
             break;
          case IFX_RTCP_SDES_ITEM_EMAIL:
            strncpy( (pxTempConn->xRxSrcDesc.acEmail),
                     ((char8 *) puiPkt + 2 ),*((uint8 *) puiPkt + 1) );
            IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
                     "<DB> Email ",pxTempConn->xRxSrcDesc.acEmail );
            break;
          case IFX_RTCP_SDES_ITEM_PHONE:
            strncpy( (pxTempConn->xRxSrcDesc.acPhone),
                     ((char8 *) puiPkt + 2),*((uint8 *) puiPkt + 1) );
            IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
                     "<DB> Phone ",pxTempConn->xRxSrcDesc.acPhone );
            break;
          case IFX_RTCP_SDES_ITEM_LOC:
            strncpy( (pxTempConn->xRxSrcDesc.acLoc),
                     ((char8 *) puiPkt + 2),*((uint8 *) puiPkt + 1) );
            IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
                     "<DB> Location", pxTempConn->xRxSrcDesc.acLoc );
            break;
          case IFX_RTCP_SDES_ITEM_TOOL:
            strncpy( (pxTempConn->xRxSrcDesc.acAppTool),
                     ((char8 *) puiPkt + 2),*((uint8 *) puiPkt + 1) );
            IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
                     "<DB> application tool",
                     pxTempConn->xRxSrcDesc.acAppTool );
            break;
          case IFX_RTCP_SDES_ITEM_NOTE:
            strncpy( (pxTempConn->xRxSrcDesc.acNote),
                     ((char8 *) puiPkt + 2),*((uint8 *) puiPkt + 1) );
            IFX_DBGA(vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
                     "<DB> Note", pxTempConn->xRxSrcDesc.acNote );
            break;
          case IFX_RTCP_SDES_ITEM_PRIV:
            pxTempConn->xRxSrcDesc.xPriv.ucPrefixLength =
              *(uint8 *) ((uint8 *)puiPkt + 2);
            memcpy( pxTempConn->xRxSrcDesc.xPriv.acPrefixString,
                   ((uint8 *)puiPkt + 3),
                   pxTempConn->xRxSrcDesc.xPriv.ucPrefixLength);
            memset( pxTempConn->xRxSrcDesc.xPriv.acPrefixString +
                    pxTempConn->xRxSrcDesc.xPriv.ucPrefixLength, 0, 1 );
            memcpy( pxTempConn->xRxSrcDesc.xPriv.acPriv,
                    ((uint8 *)puiPkt + 3 +
                     pxTempConn->xRxSrcDesc.xPriv.ucPrefixLength),
                     *(uint8 *)((uint8 *)puiPkt + 1) -
                     pxTempConn->xRxSrcDesc.xPriv.ucPrefixLength);
            memset( pxTempConn->xRxSrcDesc.xPriv.acPriv +
                    *(uint8 *)((uint8 *)puiPkt + 1) -
                    pxTempConn->xRxSrcDesc.xPriv.ucPrefixLength, 0, 1 );
            IFX_DBGA( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
                      "<DB> Priv ", pxTempConn->xRxSrcDesc.xPriv.acPriv );
            break;
          default:
            IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                      "<DB> SDES RX ERROR....." );
            break;
        }
         /* Go to Next Item */
        puiPkt = (uint32 *) ((uint32)puiPkt + (2 + *(uint8 *)((uint8 *)puiPkt + 1)));
      }
      if(puiPkt > puiPktEnd)
      {
        return IFX_RTP_FAIL;
      }
    }
  }

  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name                :  IFX_RTP_DB_SetSdesItem
*  Description                  :  This function sets SDES items for
*                                  the session owner in the  Database
*  Input Values                 :  ucSessId, uiConnId, pxSdesItem
*                               :  ucSessId = Session Id
*                               :  ucConnId = Connection Id
*  Output Values                :  none
*  Return Value                 :  void
*  Notes                        :
*********************************************************************/
PUBLIC void IFX_RTP_DB_SetSdesItem(IN x_IFX_RTP_Session *pxSess,
                                   IN e_IFX_RTCP_SDES_Item eSdesItem,
                                   IN char8 *pcSdesItemValue)
{
  switch (eSdesItem)
  {
    case IFX_RTCP_SDES_ITEM_CNAME:
      strcpy(pxSess->xTxSrcDesc.acCanName,pcSdesItemValue);
      break;
    case IFX_RTCP_SDES_ITEM_NAME:
      strcpy(pxSess->xTxSrcDesc.acName,pcSdesItemValue);
      break;
    case IFX_RTCP_SDES_ITEM_LOC:
      strcpy(pxSess->xTxSrcDesc.acLoc,pcSdesItemValue);
      break;
    case IFX_RTCP_SDES_ITEM_PHONE:
      strcpy(pxSess->xTxSrcDesc.acPhone,pcSdesItemValue);
      break;
    case IFX_RTCP_SDES_ITEM_EMAIL:
      strcpy(pxSess->xTxSrcDesc.acEmail,pcSdesItemValue);
      break;
    case IFX_RTCP_SDES_ITEM_TOOL:
      strcpy(pxSess->xTxSrcDesc.acAppTool,pcSdesItemValue);
      break;
    case IFX_RTCP_SDES_ITEM_NOTE:
      strcpy(pxSess->xTxSrcDesc.acNote,pcSdesItemValue);
      break;
    case IFX_RTCP_SDES_ITEM_PRIV:
      pxSess->xTxSrcDesc.xPriv = *((x_IFX_RTCP_SDES_PRIV_Item *)pcSdesItemValue);
      break;
    default:
     IFX_DBGC(vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "<DB> INVALID SDES ITEM TYPE...");
  }
  return;
}

/******************************************************************
*  Function Name                :  IFX_RTP_DB_GetSdesItem
*  Description                  :  This function gets SDES items of
*                                  the session owner from the Database
*  Input Values                 :  pxSdesChunk = SDES information
*                               :  eSdesItem = Exact SDES iem name
*                               :  pxSdesItem = Storage location
*  Output Values                :  none
*  Return Value                 :  void
*  Notes                        :
*********************************************************************/
PUBLIC void IFX_RTP_DB_GetSdesItem(IN x_IFX_RTCP_SdesItems *pxSdesSrc,
                                   IN e_IFX_RTCP_SDES_Item eSdesItem,
                                   OUT x_IFX_RTCP_SdesItems *pxSdesDst)
{
  switch (eSdesItem)
  {
    case IFX_RTCP_SDES_ITEM_CNAME:
      strcpy(pxSdesDst->acCanName,pxSdesSrc->acCanName);
      break;
    case IFX_RTCP_SDES_ITEM_NAME:
      strcpy(pxSdesDst->acName,pxSdesSrc->acName);
      break;
    case IFX_RTCP_SDES_ITEM_LOC:
      strcpy(pxSdesDst->acLoc,pxSdesSrc->acLoc);
      break;
    case IFX_RTCP_SDES_ITEM_PHONE:
      strcpy(pxSdesDst->acPhone,pxSdesSrc->acPhone);
      break;
    case IFX_RTCP_SDES_ITEM_EMAIL:
      strcpy(pxSdesDst->acEmail,pxSdesSrc->acEmail);
      break;
    case IFX_RTCP_SDES_ITEM_TOOL:
      strcpy(pxSdesDst->acAppTool,pxSdesSrc->acAppTool);
      break;
    case IFX_RTCP_SDES_ITEM_NOTE:
      strcpy(pxSdesDst->acNote,pxSdesSrc->acNote);
      break;
    case IFX_RTCP_SDES_ITEM_PRIV:
      pxSdesDst->xPriv = pxSdesSrc->xPriv;
      break;
    default:
      IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
                "<DB> INVALID SDES ITEM TYPE...");
      break;
  }
}

/******************************************************************
*  Function Name                : IFX_RTP_DB_AddToMemberList
*  Description                  : This functions adds the SSRC
*                                 to the Member List
*  Input Values                 :  ucSessId
*                               :  ucSessId = Session Id
*                               :  uiSsrc = Ssrc of the Member
*  Output Values                :  none
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8 IFX_RTP_DB_AddToMemberList(IN x_IFX_RTP_Session *pxSess,
                                        IN uint32 uiSsrc )
{
  uint8 ucIdx, ucInsIdx = IFX_RTP_MAX_MEMBERS; 
  long32 lnSecs, lnUsecs;

  IFX_RTP_GetTimeOfDay( &lnSecs,&lnUsecs );
  for( ucIdx = 0; ucIdx < IFX_RTP_MAX_MEMBERS; ucIdx++ )
  {
    /* if member is already exists in a list */
    if(pxSess->xMemberList.auiMembers[ucIdx] == uiSsrc )
    {
      pxSess->xMemberList.adiLastPktTime[ucIdx] =
        ( double64 ) ( lnSecs + lnUsecs / 1000000.0 );
      return IFX_RTP_SUCCESS;
    }

    /* to check whether list is not exhausted */
    if(pxSess->xMemberList.auiMembers[ucIdx] == 0 )
    {
       if(ucInsIdx > IFX_RTP_MAX_MEMBERS )
       {
         ucInsIdx = ucIdx;
       }
    }
  }
  /* update list */
  if(ucInsIdx < IFX_RTP_MAX_MEMBERS )
  {
    pxSess->xMemberList.auiMembers[ucInsIdx] = uiSsrc;
    pxSess->xMemberList.adiLastPktTime[ucIdx] =
      ( double64 ) ( lnSecs + lnUsecs / 1000000.0 );
    pxSess->ucMembers++;
    IFX_DBGA( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
              "<DB> AddToMembers ucMembers = ",
              pxSess->ucMembers );
  }

  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
            "<DB> Added Ssrc to Member List",uiSsrc );

  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name                : IFX_RTP_DB_AddToSenderList
*  Description                  : This functions adds the SSRC
*                                 to the Sender List
*  Input Values                 :  ucSessId
*                               :  ucSessId = Session Id
*                               :  uiSsrc = Ssrc of the Sender
*  Output Values                :  none
*  Return Value                 :  void
*  Notes                        :
*********************************************************************/
PUBLIC char8 IFX_RTP_DB_AddToSenderList(IN x_IFX_RTP_Session *pxSess,
                                        IN uint32 uiSsrc )
{
  uint8 ucIdx, ucInsIdx = IFX_RTP_MAX_MEMBERS;
  long32 lnSecs, lnUsecs;

  IFX_RTP_GetTimeOfDay( &lnSecs,&lnUsecs );
  for( ucIdx = 0; ucIdx < IFX_RTP_MAX_MEMBERS; ucIdx++ )
  {
    /* if sender is already exists in a sender list */
    if(pxSess->xSenderList.auiSenders[ucIdx] == uiSsrc )
    {
      pxSess->xSenderList.adiLastRtpPktTime[ucIdx] =
        ( double64 ) ( lnSecs + lnUsecs / 1000000.0 );
       return IFX_RTP_SUCCESS;
    }

    /* to check whether sender list is not exhausted */
    if(pxSess->xSenderList.auiSenders[ucIdx] == 0 )
    {
      if( ucInsIdx > IFX_RTP_MAX_MEMBERS )
      {
        ucInsIdx = ucIdx;
      }
    }
  }

  /* update list */
  if( ucInsIdx < IFX_RTP_MAX_MEMBERS )
  {
    pxSess->xSenderList.auiSenders[ucInsIdx] = uiSsrc;
    pxSess->xSenderList.adiLastRtpPktTime[ucIdx] =
      ( double64 ) ( lnSecs + lnUsecs / 1000000.0 );
    pxSess->ucSenders++;
    IFX_DBGA( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
              "<Stack> ucSenders = ",
              pxSess->ucSenders );
  }

  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
            "<DB> Added Ssrc to Sender List", uiSsrc );
  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name                : IFX_RTP_DB_DeleteFromMemberList
*  Description                  : This functions deletes the SSRC
*                                 from the Member List
*  Input Values                 :  ucSessId
*                               :  ucSessId = Session Id
*                               :  uiSsrc = Ssrc of the Member
*  Output Values                :  none
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8 IFX_RTP_DB_DeleteFromMemberList(IN x_IFX_RTP_Session *pxSess,
                                             IN uint32 uiSsrc )
{
  uint8 ucIdx = 0;

  for( ucIdx = 0; ucIdx < IFX_RTP_MAX_MEMBERS; ucIdx++ )
  {
    /* update list */
    if( pxSess->xMemberList.auiMembers[ucIdx] == uiSsrc )
    {
      pxSess->xMemberList.auiMembers[ucIdx] = 0;
      pxSess->ucMembers--;
	  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
                "<DB> DeleteFromMembers ucMembers = ",
                pxSess->ucMembers );
      break;
    }
  }
  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_RTP_STR_PRINT,
            "<DB> Removed SSRC  From Member List",uiSsrc );
  return IFX_RTP_SUCCESS;
}

/******************************************************************
*  Function Name                : IFX_RTP_DeleteFromSenderList
*  Description                  : This functions deletes the SSRC
*                                 from the Sender List
*  Input Values                 :  ucSessId
*                               :  ucSessId = Session Id
*                               :  uiSsrc = Ssrc of the Sender
*  Output Values                :  none
*  Return Value                 :  IFX_RTP_SUCCESS/IFX_RTP_FAIL
*  Notes                        :
*********************************************************************/
PUBLIC char8 IFX_RTP_DB_DeleteFromSenderList(IN x_IFX_RTP_Session *pxSess,
                                             IN uint32 uiSsrc )
{
  uint8 ucIdx = 0;

  for( ucIdx = 0; ucIdx < IFX_RTP_MAX_MEMBERS; ucIdx++ )
  {
    /* update list */
    if( pxSess->xSenderList.auiSenders[ucIdx] == uiSsrc )
    {
       pxSess->xSenderList.auiSenders[ucIdx] = 0;
       pxSess->ucSenders--;
       break;
    }
  }
  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_RTP_STR_PRINT,
            "<DB> Removed SSRC From Sender List",uiSsrc );
  return IFX_RTP_SUCCESS;
}

/************************************************************************
* Function Name  : IFX_RTP_CreateSessNode
* Description    : This function will create Rtp Session
* Input Values   : UserData
* Output Values  : address of subsciption node
* Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAIL
* Notes          :
* *************************************************************************/
PUBLIC uint32 IFX_RTP_CreateSessNode()
{
  int32 uiErrorCode;
  x_IFX_RTP_Session *pxRtpSess = NULL;
  x_IFX_RTP_ConnInfo *pxRtpConn = NULL;
  
  /* Add to Session List*/
  __ifx_list_add_front((void *)&vpxRtpSessHeadPtr,
                       (void *)&pxRtpSess,
                       sizeof(x_IFX_RTP_Session),&uiErrorCode);

  if( uiErrorCode < 0)
  {
    IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Create RTP Session Failure" );
    return IFX_RTP_FAIL;
  }

  /* Add to Conn List*/
  __ifx_list_add_front((void *)&vpxRtpConnHeadPtr,
                       (void *)&pxRtpConn,
                       sizeof(x_IFX_RTP_ConnInfo),&uiErrorCode);

  if( uiErrorCode < 0)
  {
    IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Create RTP Conn Failure" );
    return IFX_RTP_FAIL;
  }

  /* Add Connection to Session */
  if( IFX_RTP_AddConnToSess(pxRtpSess,pxRtpConn) < 0 )
  {
    IFX_DBGC( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Add Connection to Session Failure" );
    return IFX_RTP_FAIL;
  }

  /* Set the session owner */
  pxRtpConn->uiSessOwner = (uint32) pxRtpSess;

  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
            "Session Created Success" );
  return (uint32)pxRtpSess;
}
/************************************************************************
* Function Name  : IFX_RTP_AddConnToSess
* Description    : This function will add connection to session list
* Input Values   : Session ptr and Conn Ptr
* Output Values  : Conn list Ptr
* Return Value   : IFX_SIP_SUCCESS,IFX_SIP_FAIL
* Notes          :
* *************************************************************************/
PUBLIC int32 IFX_RTP_AddConnToSess(
                            IN x_IFX_RTP_Session *pxRtpSessPtr,
                            IN x_IFX_RTP_ConnInfo *pxRtpConnPtr)
{
  int32 uiErrorCode=0;
  x_IFX_RTP_ConnList *pxConnNode=NULL; 
  x_IFX_RTP_ConnList *pxConnList = pxRtpSessPtr->pxConnListHeadPtr;

  /* Check if connection already owned by session */
  while( pxConnList != NULL )
  {
    if( pxConnList->pxConn == pxRtpConnPtr )
    {
      return IFX_RTP_SUCCESS;
    }
    __ifx_list_GetNext((void *) &pxConnList); 
  }

  /* Add connection to the session connection list*/
  __ifx_list_add_front((void *) &(pxRtpSessPtr->pxConnListHeadPtr),
                       (void *) &pxConnNode,
                       sizeof(x_IFX_RTP_ConnList),&uiErrorCode);

  if( uiErrorCode < 0 )
  {
    IFX_DBGA( vcRtpModId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,
              "Added Connection to Session Failure" );
    return IFX_RTP_FAIL;
  }

  pxConnNode->pxConn = pxRtpConnPtr;
  pxRtpSessPtr->ucNoConns++;
  pxRtpConnPtr->ucOwnerCount++; 
  IFX_RTP_DB_AddToMemberList(pxRtpSessPtr, pxRtpConnPtr->uiRxSsrc);
  if( pxRtpConnPtr->ucConnMode == IFX_RTP_MODE_SEND_RECV )
  {
    IFX_RTP_DB_AddToSenderList(pxRtpSessPtr, pxRtpConnPtr->uiRxSsrc);
  }
  pxRtpSessPtr->auiCsrcList[0] = pxRtpSessPtr->uiTxSSRC;
  if( pxRtpSessPtr->ucNoConns > 1 && pxRtpSessPtr->ucNoConns <= IFX_RTP_MAX_CSRC)
  {
    pxRtpSessPtr->auiCsrcList[pxRtpSessPtr->ucNoConns-1] = pxRtpConnPtr->uiRxSsrc;
  }

  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Add Connection to Session Success" );

  return IFX_RTP_SUCCESS;
}
/************************************************************************
* Function Name  : IFX_RTP_RemoveConnFromSess
* Description    : This function will remove the connection from the session
* Input Values   : Session ptr and Conn Ptr
* Output Values  :
* Return Value   : IFX_RTP_SUCCESS,IFX_RTP_FAIL
* Notes          :
* *************************************************************************/
PUBLIC uint32 IFX_RTP_RemoveConnFromSess(
                            IN x_IFX_RTP_Session *pxRtpSessPtr,
                            IN x_IFX_RTP_ConnInfo *pxRtpConnPtr)
{
  x_IFX_RTP_ConnList *pxConnList = pxRtpSessPtr->pxConnListHeadPtr;
  uint16 i;

  while( pxConnList != NULL )
  {
    if( pxConnList->pxConn == pxRtpConnPtr )
    {            
      pxRtpSessPtr->ucNoConns--;
      pxRtpConnPtr->ucOwnerCount--;

      IFX_RTP_DB_DeleteFromMemberList(pxRtpSessPtr, pxRtpConnPtr->uiRxSsrc);
      IFX_RTP_DB_DeleteFromSenderList(pxRtpSessPtr, pxRtpConnPtr->uiRxSsrc);

      for( i=1; i < pxRtpSessPtr->ucNoConns && pxRtpSessPtr->ucNoConns < IFX_RTP_MAX_CSRC; i++)
      {
        if( pxRtpSessPtr->auiCsrcList[i] == pxRtpConnPtr->uiRxSsrc)
        {
          while( i <= pxRtpSessPtr->ucNoConns )
          {
            pxRtpSessPtr->auiCsrcList[i] = pxRtpSessPtr->auiCsrcList[i+1];
            i++;
          }
          break;
        }
      }
           /* If connection originated from this session, close related Fds */
      if(pxRtpConnPtr->uiSessOwner == (uint32) pxRtpSessPtr)  
      {
        if(viStackMode == IFX_RTP_SYNC_MODE)
        {
          if(vxSyncCallBks.pfnRemoveFDFromSelect != NULL)
          {
            vxSyncCallBks.pfnRemoveFDFromSelect(
              pxRtpConnPtr->pvUserData,
              pxRtpConnPtr->iRtpFd,
              pxRtpConnPtr->iRtcpFd,
              0);
          }
          if(pxRtpConnPtr->iRtcpFd)
          {
            IFX_RTP_Close(pxRtpConnPtr->iRtcpFd);
          }
          if(pxRtpConnPtr->iRtpFd)
          {
            IFX_RTP_Close(pxRtpConnPtr->iRtpFd);
          }
        }
        else 
        {
          if(pxRtpConnPtr->iRtpFd)
          {
            IFX_RTP_CloseSocket(pxRtpConnPtr->iRtpFd, &v_RdSelectFd);
          }
          if(pxRtpConnPtr->iRtcpFd)
          {
            IFX_RTP_CloseSocket(pxRtpConnPtr->iRtcpFd, &v_RdSelectFd);
          }
        }
      } 
                              
      /* Remove Connection is removed from all sessions */
      if( pxRtpConnPtr->ucOwnerCount == 0 )
      {
        /* remove from Connection node list*/
        __ifx_list_del((void *) &(vpxRtpConnHeadPtr), (void *) pxRtpConnPtr);
      }
      /* Remove connection reference from session connection list*/
      __ifx_list_del((void *) &(pxRtpSessPtr->pxConnListHeadPtr),
                     (void *) pxConnList);

      IFX_DBGA( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
                "Remove Connection from Session Success" );

      return IFX_RTP_SUCCESS;
    }
    __ifx_list_GetNext((void *) &pxConnList);
  }
  return IFX_RTP_FAIL;
}

/************************************************************************
* Function Name  : IFX_RTP_RemoveSess
* Description    : This function will remove the session
* Input Values   : Session ptr
* Output Values  :
* Return Value   : IFX_RTP_SUCCESS,IFX_RTP_FAIL
* Notes          : All connection associated are also removed
* *************************************************************************/
PUBLIC uint32 IFX_RTP_RemoveSess(IN x_IFX_RTP_Session *pxRtpSessPtr)
{
  x_IFX_RTP_Session *pxSessNode = vpxRtpSessHeadPtr;
  x_IFX_RTP_ConnList *pxConnList=NULL;
  //int32 iRtpFd=0, iRtcpFd=0;

  while( pxSessNode != NULL )
  {
    if( pxSessNode == pxRtpSessPtr )
    {
      /* Remove all conections associated with the session from the list*/
      pxConnList = pxSessNode->pxConnListHeadPtr;
      /*if(pxConnList != NULL)
      {
        iRtpFd = pxConnList->pxConn->iRtpFd;
        iRtcpFd = pxConnList->pxConn->iRtcpFd;
      }*/
      while( pxConnList != NULL )
      {
        #ifndef __IMSENV__
          if( pxRtpSessPtr->ucIsRtcpEnable && pxRtpSessPtr->ucIsRtpEnable)
          {
            IFX_RTP_SendRtcpReport(pxRtpSessPtr,pxConnList->pxConn,IFX_RTCP_SR|
                                   IFX_RTCP_RR|IFX_RTCP_SDES|IFX_RTCP_BYE,NULL);
          }
        #endif
        /* remove Connection From Session connection list*/
        IFX_RTP_RemoveConnFromSess(pxSessNode, pxConnList->pxConn);
        if( pxSessNode->ucNoConns == 0 )
        {
          break;
        }
        __ifx_list_GetNext((void *) &pxConnList);
      }
      
      /* Remove Session node from session node list*/
      __ifx_list_del((void *) &(vpxRtpSessHeadPtr),
                     (void *) pxRtpSessPtr);

      break;
    }
    __ifx_list_GetNext((void *) &pxSessNode);
  }
  IFX_DBGA( vcRtpModId,IFX_DBG_LVL_NORMAL,IFX_DBG_STR,
            "Remove Session Success" );
  return IFX_RTP_SUCCESS;
}
