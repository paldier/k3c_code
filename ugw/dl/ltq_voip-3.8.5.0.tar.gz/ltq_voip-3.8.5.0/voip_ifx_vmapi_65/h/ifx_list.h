/*****************************************************************************
 **   FILE NAME       : ifx_List.h
 **   PROJECT         : INCA IP and ATA
 **   MODULES         : List Module
 **   SRC VERSION     : V0.1
 **   DATE            : 12-08-2005
 **   AUTHOR          : Radvajesh
 **   DESCRIPTION     : This file contains all the data declarations that are
 **                     shared across the modules
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS
 **   COPYRIGHT       : Infineon Technologies AG 2003 - 2005

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
 *****************************************************************************/
#ifndef __IFX_LIST_H__
#define __IFX_LIST_H__

#ifdef MEM_DBG
#define IFX_OS_Calloc(iNum,iSize) IFX_OS_CallocDbg(iNum,iSize,__FILE__,__LINE__)

#define IFX_OS_Malloc(iSize)  IFX_OS_CallocDbg(1,iSize,__FILE__,__LINE__)

#define IFX_OS_Free(pcFree)  (IFX_OS_FreeDbg(pcFree,__FILE__,__LINE__))

#else
#include<stdlib.h>
#endif
typedef int int32;
/* list data structure */
typedef struct x_ifx_list
{ 
   struct x_ifx_list *pxNext;
   struct x_ifx_list *pxPrev;
}x_ifx_list;


#ifdef __LINUX__
/* Initlize the header */
static inline void __ifx_list_init(
                x_ifx_list *pxHeadptr)
{
    (pxHeadptr)->pxNext = NULL; 
    (pxHeadptr)->pxPrev = NULL;
}
/* Insert a new entry between 2 nodes*/
static inline void __ifx_list_add(
                        x_ifx_list *pxNewNode,
                        x_ifx_list *pxPrevNode,
                        x_ifx_list  *pxNextNode)
{
   pxNewNode->pxPrev = pxPrevNode;
   pxNewNode->pxNext = pxPrevNode->pxNext;
   pxPrevNode->pxNext = pxNewNode;
   if ( pxNextNode != NULL)
   pxNextNode->pxPrev = pxNewNode;
}

/* Create and add an entry */
static inline void __ifx_list_createNadd(
                        void **ppxHeadptr,
                        void **ppxNewNode,
                        void *pxPrevNode,
                        void  *pxNextNode,
                        int32 iSize,
                        int32 *puiErrorCode)
{
    *puiErrorCode = -1;
#ifndef MEM_DBG
    *ppxNewNode = calloc(1,sizeof(x_ifx_list) + iSize);
#else
    *ppxNewNode = IFX_OS_Malloc(sizeof(x_ifx_list) + iSize);
#endif
    if (*ppxNewNode == NULL){
      *puiErrorCode = -1;
    }
    else{
      if(*ppxHeadptr == NULL){
       *ppxHeadptr =(x_ifx_list *)*ppxNewNode;
       __ifx_list_init(*ppxHeadptr);
//ASK:Make Circular
      ((x_ifx_list*)*ppxHeadptr)->pxPrev = *ppxHeadptr; 
       *ppxHeadptr += sizeof(x_ifx_list);
      }
      else{
        x_ifx_list *pxPrevPtr = (x_ifx_list *)((char*)pxPrevNode-sizeof(x_ifx_list));
        x_ifx_list *pxHeadptr = (x_ifx_list *)(*((char**)ppxHeadptr)-sizeof(x_ifx_list));
        x_ifx_list *pxNextPtr=NULL;
        if(pxNextNode != NULL){
          pxNextPtr = (x_ifx_list *)((char*)pxNextNode-sizeof(x_ifx_list));
        }
        __ifx_list_add((x_ifx_list *)*ppxNewNode,pxPrevPtr,pxNextPtr);
       pxHeadptr->pxPrev = *ppxNewNode;
      }
     *ppxNewNode += sizeof(x_ifx_list);
     *puiErrorCode = 0;
  }
}
/* Insert the node at the front */
static inline void __ifx_list_add_first(
                void **ppxHeadptr,
                void **ppxNodeptr,
                int32 iSize,
                int32 *puiErrorCode)
{ 
  *puiErrorCode = -1;
#ifndef MEM_DBG
  *ppxNodeptr = calloc(1,sizeof(x_ifx_list) + iSize);
#else
  *ppxNodeptr = IFX_OS_Malloc(sizeof(x_ifx_list) + iSize); 
#endif
  if (*ppxNodeptr == NULL)
  {
    *puiErrorCode = -1;
  }
  else
  {
      x_ifx_list *pxHeadptr = (x_ifx_list *)(*((char**)ppxHeadptr)-sizeof(x_ifx_list));
			((x_ifx_list*)*ppxNodeptr)->pxPrev = (pxHeadptr)->pxPrev;
			((x_ifx_list*)*ppxNodeptr)->pxNext = pxHeadptr;
			(pxHeadptr)->pxPrev = *ppxNodeptr;
			*ppxNodeptr = (*(char**)ppxNodeptr)+sizeof(x_ifx_list);
			*ppxHeadptr = *ppxNodeptr;
			*puiErrorCode = 0;
  }
}


/* Insert the node at the front */
static inline void __ifx_list_add_front(
                void **ppxHeadptr,
                void **ppxNodeptr,
                int32 iSize,
                int32 *puiErrorCode)
{ 
  *puiErrorCode = -1;
#ifndef MEM_DBG
  *ppxNodeptr = calloc(1,sizeof(x_ifx_list) + iSize);
#else
  *ppxNodeptr = IFX_OS_Malloc(sizeof(x_ifx_list) + iSize); 
#endif
  if (*ppxNodeptr == NULL)
  {
    *puiErrorCode = -1;
  }
  else
  {
    if ( *ppxHeadptr == NULL)
    {
       *ppxHeadptr =(x_ifx_list *)*ppxNodeptr;
       __ifx_list_init(*ppxHeadptr);
       *ppxHeadptr = (*((char**)ppxHeadptr)) + sizeof(x_ifx_list);
    }
    else
    {
       x_ifx_list *pxHeadptr = (x_ifx_list *)((*((char**)ppxHeadptr))-sizeof(x_ifx_list));
       __ifx_list_add((x_ifx_list *)*ppxNodeptr,pxHeadptr,(pxHeadptr)->pxNext);
     }
     *ppxNodeptr = (*((char**)ppxNodeptr)) + sizeof(x_ifx_list);
     *puiErrorCode = 0;
  }
}
/* Insert the node at the end */
static inline void __ifx_list_add_to_tail(
                void **ppxHeadptr,
                void **ppxNodeptr,
                int32 iSize,
                int32 *puiErrorCode)
{ 
  *puiErrorCode = -1;
#ifndef MEM_DBG
  *ppxNodeptr = calloc(1,sizeof(x_ifx_list) + iSize);
#else
  *ppxNodeptr = IFX_OS_Malloc(sizeof(x_ifx_list) + iSize); 
#endif
  if (*ppxNodeptr == NULL)
  {
    *puiErrorCode = -1;
  }
  else
  {
    if ( *ppxHeadptr == NULL)
    {
       *ppxHeadptr =(x_ifx_list *)*ppxNodeptr;
       __ifx_list_init(*ppxHeadptr);
       /* Making it circular*/
       ((x_ifx_list *)*ppxHeadptr)->pxPrev = *ppxHeadptr;
       *ppxHeadptr = (*((char**)ppxHeadptr)) + sizeof(x_ifx_list);
    }
    else
    {
       x_ifx_list *pxHeadptr = (x_ifx_list *)(*((char**)ppxHeadptr)-sizeof(x_ifx_list));
       __ifx_list_add((x_ifx_list *)*ppxNodeptr,pxHeadptr->pxPrev,(pxHeadptr->pxPrev)->pxNext);
       pxHeadptr->pxPrev = *ppxNodeptr;
     }
     *ppxNodeptr = (*((char**)ppxNodeptr)) + sizeof(x_ifx_list);
     *puiErrorCode = 0;
  }
}
/* Get Next node */
static inline void __ifx_list_GetNext(void **ppxNodeptr)
{
   x_ifx_list *pxNode = (x_ifx_list *)(*((char**)ppxNodeptr) - sizeof(x_ifx_list));
   pxNode = pxNode->pxNext;
   if ( pxNode != NULL)
   {
     *ppxNodeptr = ((char *)pxNode + sizeof(x_ifx_list));
   }
   else
   {
      *ppxNodeptr = NULL;
   }
}

/* Get Prev node */
static inline void __ifx_list_GetPrev(void **ppxNodeptr)
{
   x_ifx_list *pxNode = (x_ifx_list *)(*((char**)ppxNodeptr) - sizeof(x_ifx_list));
   pxNode = pxNode->pxPrev;
   if ( pxNode != NULL)
   {
     *ppxNodeptr = ((char *)pxNode + sizeof(x_ifx_list));
   }
   else
   {
      *ppxNodeptr = NULL;
   }
}


/* Delete Node */
static inline void  __ifx_list_del(void **ppxHeadptr,void *pxNodeptr)
{
  x_ifx_list *pxNode = (x_ifx_list *)((char*)pxNodeptr - sizeof(x_ifx_list));
  x_ifx_list *pxTemp1 = (x_ifx_list *)(*((char**)ppxHeadptr) - sizeof(x_ifx_list));
  x_ifx_list *pxTemp2 = NULL;
  if (*ppxHeadptr == pxNodeptr)
  {
    if ( pxNode->pxNext == NULL)
    {
       *ppxHeadptr = NULL;  
    }
    else
    {    
       *ppxHeadptr = ((char *)(pxNode->pxNext))+ sizeof(x_ifx_list);
       pxTemp2 = (x_ifx_list *)(*((char**)ppxHeadptr) - sizeof(x_ifx_list));
       pxTemp2->pxPrev = pxTemp1->pxPrev;
    }
  }else {
  if (pxNode->pxNext != NULL)
  {
    (pxNode->pxNext)->pxPrev = pxNode->pxPrev;
  }
  else{
    pxTemp1->pxPrev = pxNode->pxPrev;
  }
  
  if (pxNode->pxPrev != NULL)
  {
    (pxNode->pxPrev)->pxNext = pxNode->pxNext;
}  }
#ifndef MEM_DBG  
  free(pxNode);
#else
  IFX_OS_Free(pxNode);
#endif
}
static inline void  __ifx_list_move_front_updateTail(void **ppxHeadptr,void *pxNodeptr)
{
  x_ifx_list *pxNode = (x_ifx_list *)((char*)pxNodeptr - sizeof(x_ifx_list));
  x_ifx_list *pxFirstNode = (x_ifx_list *)(*((char**)ppxHeadptr) - sizeof(x_ifx_list));
  if (*ppxHeadptr == pxNodeptr)
  {
     pxNode->pxPrev = pxNode;
     return;
  }
  else
  {
     if(pxNode->pxNext != NULL){
       (pxNode->pxNext)->pxPrev = pxFirstNode;
       pxFirstNode->pxNext = pxNode->pxNext;
     }
     pxNode->pxPrev =pxFirstNode->pxPrev;
     pxFirstNode->pxPrev = pxNode;
     *ppxHeadptr = ((char *)(pxNode))+ sizeof(x_ifx_list);
  }
}
static inline void __ifx_list_del_tail(void **ppxHeadptr)
{
  x_ifx_list *pxFirstNode = (x_ifx_list *)(*((char**)ppxHeadptr) - sizeof(x_ifx_list));
  __ifx_list_del(ppxHeadptr,((char *)(pxFirstNode->pxPrev))+ sizeof(x_ifx_list));      
}       


 
#endif
#ifdef __IMSENV__
/* Initlize the header */
void __ifx_list_init(
                x_ifx_list *pxHeadptr);

/* Insert a new entry between 2 nodes*/
void __ifx_list_add(
                    x_ifx_list *pxNewNode,
                    x_ifx_list *pxPrevNode,
                    x_ifx_list  *pxNextNode);


/* Insert the node at the front */
void __ifx_list_add_front(
                void **ppxHeadptr,
                void **ppxNodeptr,
                int32 iSize,
                int32 *puiErrorCode);

/* Get Next node */
void __ifx_list_GetNext(void **ppxNodeptr);


/* Get Prev node */
 void __ifx_list_GetPrev(void **ppxNodeptr);



/* Delete Node */
void  __ifx_list_del(void **ppxHeadptr,void *pxNodeptr);

/* Move front and update tail*/
void __ifx_list_move_front_updateTail(void **ppxHeadptr,void *pxNodeptr);

/*Delete tail*/
void __ifx_list_del_tail(void **ppxHeadptr);

void __ifx_list_add_to_tail(void **ppxHeadptr,
                            void **ppxNodeptr,
                            int32 iSize,
                            int32 *puiErrorCode);
 
#endif
#endif /* __IFX_LIST_H__*/
