/**************************************************************************
 **   FILE NAME       : ifx_vmapi_api.h
 **   PROJECT         : Voice Management API
 **   MODULES         : Voice Management APIs
 **   SRC VERSION     : V0.1
 **   DATE            : 05-09-2006
 **   AUTHOR          : Prashant,Pallav
 **   DESCRIPTION     : This file contains the Voice Management API function
 **                      prototype declarations.
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/

#ifndef __IFX_VMAPI_API_H__
#define __IFX_VMAPI_API_H__

#ifdef DECT_SUPPORT
#define DECT_REPEATER 
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*! \file ifx_vmapi_api.h
    \brief File containing the Function Prototypes of VMAPI APIs.
*/

/** \ingroup MAPI_VOICE
        \defgroup MAPI_VOICE_METHODS Methods
    	\brief This section describes the MAPI Voice Methods.  The
		MAPI Voice Methods implement functions to operate on MAPI 
		Voice Objects. Typically, for each MAPI Voice Object, two
		methods, viz., a GET and a SET method are implemented. Most 
		of the methods use the Profile Identifier and a Line Identifier
		as the primary keys for accessing the objects. However, there
		are also some objects that do not fall under the Profile and 
		Line hierarchy and appropriate keys are used.
*/
/* @{ */
#define IFX_VMAPI_CM_INIT() IFX_CM_Init()
#define IFX_VMAPI_CM_SHUT()	IFX_CM_Shut()
#define IFX_VMAPI_CM_MGMT_INIT(ucModuleId) IFX_CM_MgtInit(ucModuleId)
#define IFX_VMAPI_CM_MGMT_SHUT() IFX_CM_MgtShut()

/*! 
    \brief This method is used for setting the attributes to the VoiceService object.
	\param[in] 	uiOperation Operation Type
    \param[in] pxVoiceService Pointer to the object structure
    \param[in] uiInFlag Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_VoiceService(IN uint32 uiOperation,
                    IN x_IFX_VMAPI_VoiceService *pxVoiceService,
                    IN uint32 uiInFlag);

/*! 
    \brief This method is used for getting the attributes of the VoiceService object.     
    \param[in,out] pxVoiceService Pointer to the object structure
    \param[in] uiInFlag Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_VoiceService(IN_OUT x_IFX_VMAPI_VoiceService *pxVoiceService,
				                   IN uint32 uiInFlag);


/*! 
    \brief This method is used for getting the attributes of the VoiceCodecCaps object.
    \param[in,out] pxVoiceCodecCaps Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_VoiceCodecCaps(
                    IN_OUT x_IFX_VMAPI_VoiceCodecCapabilities *pxVoiceCodecCaps,
                    IN uint32 uiFlags);


/*! 
    \brief This method is used for getting the attributes of the VoiceCapabilities object.
    \param[in,out] pxVoiceCap Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_VoiceCaps(IN_OUT x_IFX_VMAPI_VoiceCapabilities *pxVoiceCap,
                        IN uint32 uiFlags);


/*! 
    \brief This method is used for getting the attributes of the VoiceSipCaps object.
    \param[in,out] pxVoiceSipCaps Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_VoiceSipCaps(
                    IN_OUT x_IFX_VMAPI_VoiceSipCapabilities *pxVoiceSipCaps,
                    IN uint32 uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the T38 information object.							 
    \param[in,out]  pxT38 Pointer to the T38 object structure.
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_SystemT38(IN_OUT x_IFX_VMAPI_T38Cfg *pxT38, 
               						 IN uint32 uiFlags);


/*! 
    \brief       This method is used for setting the attributes to the T38 information object.
    \param[in] 	uiOperation Operation Type 
    \param[in] 	pxT38 Pointer to the object structure
    \param[in] 	uiFlags Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_SystemT38(IN uint32  uiOperation,
					IN x_IFX_VMAPI_T38Cfg *pxT38, 
                    IN uint32 uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Call Block object.
    \param[in,out]  pxCallBlk Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_CallBlock (IN_OUT  x_IFX_VMAPI_CallBlock  *pxCallBlk,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Call Block object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxCallBlk Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_CallBlock(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_CallBlock *pxCallBlk,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Call Block Entry object.
    \param[in,out]   pxCallBlkEntry Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/					  
int32 ifx_get_CallBlockEntry (IN_OUT  x_IFX_VMAPI_CallBlockEntry  *pxCallBlkEntry,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Call Block Entry object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxCallBlkEntry Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_CallBlockEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_CallBlockEntry *pxCallBlkEntry,
                      IN uint32  uiFlags);


/*! 
    \brief This method is used for getting the attributes of the ProfileEventSubsTable object.
    \param[in,out] pxProfileEventSubsTable Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_ProfileEventSubsTable(
              IN_OUT x_IFX_VMAPI_ProfileEventSubsTable *pxProfileEventSubsTable,
              IN uint32 uiFlags);


/*! 
    \brief This method is used for getting the attributes of all the entries of ProfileEventSubsTable object.
    \param[out] puiNumEntries Number of object structures
    \param[out] ppxProfileEventSubsTable Pointer to the list of object structures
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_all_ProfileEventSubsTable(
              OUT uint32 *puiNumEntries,
               OUT x_IFX_VMAPI_ProfileEventSubsTable **ppxProfileEventSubsTable, 
              IN  uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the ProfileEventSubsTable object.
    \param[in] uiOperation Operation Type 
    \param[in] pxProfileEventSubsTable Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_ProfileEventSubsTable(
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_ProfileEventSubsTable *pxProfileEventSubsTable, 
              IN uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of the ProfileRspMapTable object.
    \param[in,out] pxProfileRsp Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_ProfileRspMapTable(
              IN_OUT x_IFX_VMAPI_ProfileRspMapTable *pxProfileRsp,
              IN uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of all the entries of ProfileRspMapTable object.
    \param[out] puiNumEntries Number of object structures
    \param[out] ppxProfileRspMapTable Pointer to the list of object structures
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_all_ProfileRspMapTable(
              OUT uint32 *puiNumEntries, 
              OUT x_IFX_VMAPI_ProfileRspMapTable **ppxProfileRspMapTable,
               IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the ProfileRspMapTable object.
    \param[in] uiOperation Operation Type 
    \param[in] pxProfileRspMapTable Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_ProfileRspMapTable(
              IN uint32 uiOperation, 
              IN x_IFX_VMAPI_ProfileRspMapTable *pxProfileRspMapTable,
              IN uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of the ProfileServiceProviderInfo object.
    \param[in,out] pxServProviderInfo Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_ProfileServiceProviderInfo(
              IN_OUT x_IFX_VMAPI_ProfileServiceProviderInfo *pxServProviderInfo,
              IN uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of all the entries of ProfileServiceProviderInfo object.
    \param[out] puiNumEntries Number of object structures
    \param[out] ppxServiceProviderInfo Pointer to the list of object structures
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_all_ProfileServiceProviderInfo(
              OUT uint32 *puiNumEntries, 
              OUT x_IFX_VMAPI_ProfileServiceProviderInfo **ppxServiceProviderInfo,
               IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the ProfileServiceProviderInfo object.
    \param[in] uiOperation Operation Type 
    \param[in] pxServProviderInfo Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_ProfileServiceProviderInfo(
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_ProfileServiceProviderInfo *pxServProviderInfo, 
              IN uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of the ProfileSignaling object.
    \param[in,out] pxProfileSignaling Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_ProfileSignaling(
                      IN_OUT x_IFX_VMAPI_ProfileSignaling *pxProfileSignaling,
                      IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the ProfileSignaling object.
    \param[in] uiOperation Operation Type 
    \param[in] pxProfileSignaling Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_ProfileSignaling(
                      IN uint32 uiOperation,
                      IN x_IFX_VMAPI_ProfileSignaling *pxProfileSignaling,
                      IN uint32 uiFlags);

#ifdef IIP
/*! 
    \brief This method is used for getting the attributes of the ProfileMediaSecurity object.
    \param[in,out] pxProfileMediaSecurity Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_ProfileMediaSecurity(
              IN_OUT x_IFX_VMAPI_ProfileMediaSecurity *pxProfileMediaSecurity,
              IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the ProfileMediaSecurity object.
    \param[in] uiOperation Operation Type 
    \param[in] pxProfileMediaSecurity Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_ProfileMediaSecurity(
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_ProfileMediaSecurity *pxProfileMediaSecurity, 
              IN uint32 uiFlags);
#endif

/*! 
    \brief This method is used for getting the attributes of the ProfileMediaRTP object.
    \param[in,out] pxProfileMediaRTP Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_ProfileMediaRTP (
                    IN_OUT x_IFX_VMAPI_ProfileMediaRTP *pxProfileMediaRTP,
                    IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the ProfileMediaRTP object.
    \param[in] uiOperation Operation Type 
    \param[in] pxProfileMediaRTP Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_ProfileMediaRTP(
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_ProfileMediaRTP *pxProfileMediaRTP,
              IN uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of the ProfileMediaRTCP object.
    \param[in,out] pxProfileMediaRTCP Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_ProfileMediaRTCP (
                    IN_OUT x_IFX_VMAPI_ProfileMediaRTCP *pxProfileMediaRTCP ,
                    IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the ProfileMediaRTCP object.
    \param[in] uiOperation Operation Type 
    \param[in] pxProfileMediaRTCP Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_ProfileMediaRTCP(
              IN uint32 uiOperation,
              IN x_IFX_VMAPI_ProfileMediaRTCP *pxProfileMediaRTCP,
              IN uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of the VoiceProfile object.
    \param[in,out] pxVoiceProfile Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_VoiceProfile(IN_OUT x_IFX_VMAPI_VoiceProfile *pxVoiceProfile,
                           IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the VoiceProfile object.
    \param[in] uiOperation Operation Type 
    \param[in] pxVoiceProfile Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_VoiceProfile(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_VoiceProfile *pxVoiceProfile,
                            IN uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of all the VoiceProfile objects.
    \param[out] puiNumEntries Number of object structures
    \param[out] ppxVoiceProfile Pointer to the list of object structures
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_getall_VoiceProfile(
              OUT uint32 *puiNumEntries,
               OUT x_IFX_VMAPI_ProfileEventSubsTable **ppxVoiceProfile, 
              IN  uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of the VoiceServPhyIf object.
    \param[in,out] pxVoiceIf Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_VoicePhyInterface(IN_OUT x_IFX_VMAPI_VoiceServPhyIf *pxVoiceIf,
                                 IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the VoiceServPhyIf object.
    \param[in] uiOperation Operation Type 
    \param[in] pxVoiceIf Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_VoicePhyInterface(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_VoiceServPhyIf *pxVoiceIf,
                            IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Voice Line under a
    	           particular  Profile.
    \param[in,out]  pxVoiceLine Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_VoiceLine (IN_OUT x_IFX_VMAPI_VoiceLine  *pxVoiceLine,
                   IN uint32 uiFlags);


/*! 
    \brief       This method is used for setting the attributes to the Voice Line object that
                 comprises of associated physical interface, line, call status ringer
                 and volume information under a particular profile and line.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxVoiceLine Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_VoiceLine ( IN uint32 uiOperation,
                    IN  x_IFX_VMAPI_VoiceLine  *pxVoiceLine,
                    IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Line signaling object
                 that comprises of SIP user, display name and authentication 
                 information under a particular profile and line.
    \param[in,out]  pxLineSignaling Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_LineSignaling (IN_OUT  x_IFX_VMAPI_LineSignaling  *pxLineSignaling,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Line signaling object
                 that comprises of SIP user, display name and authentication 
                 information under a particular profile and line.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxLineSignaling Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineSignaling(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_LineSignaling *pxLineSignaling,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Line calling features
								 object that comprises calling features information like Call
								 forwarding, DND etc under a particular profile and line.
    \param[in,out]  pxLineCallingFeatures Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_LineCallingFeatures(
                IN_OUT x_IFX_VMAPI_LineCallingFeatures *pxLineCallingFeatures,
                IN uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Line calling features object that
                comprises calling features information like Call forwarding DND etc., under a
                particular profile and line.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxLineCallingFeatures Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineCallingFeatures(IN  uint32 uiOperation,
                       IN x_IFX_VMAPI_LineCallingFeatures  *pxLineCallingFeatures,
                       IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting information about a session that
                comprises related statistics such as session duration,
                destination address used for establishing session, etc, under
                a particular profile and line.
    \param[in,out]  pxLineVoiceSession Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_LineVoiceSession(IN_OUT  x_IFX_VMAPI_LineSession  *pxLineVoiceSession,
                          IN uint32  uiFlags);


/*! 
    \brief       This method is used for setting information about a session that
                comprises of related statistics such as session duration,
                destination address used for establishing session, etc, under
                a particular profile and line.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxLineVoiceSession Pointer to the list of object structures
    \param[in]  uiFlags Input Flag 
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineVoiceSession ( IN  uint32  uiOperation,
                           IN  x_IFX_VMAPI_LineSession  *pxLineVoiceSession,
                           IN  uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Line Voice Media object
								 that comprises media information like echo cancellation, transmit,
								 receive gain and session information under a particular profile
								 and line.
    \param[in,out]  pxLineVoiceProcessing Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_LineVoiceProcessing(
                IN_OUT  x_IFX_VMAPI_LineVoiceProcessing  *pxLineVoiceProcessing,
                IN uint32  uiFlags);


/*! 
    \brief       This method is used for setting the attributes to the Line Voice Media object
								 that comprises media information like echo cancellation, transmit,
								 receive gain and session information under a particular profile
								 and line.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxLineVoiceProcessing Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineVoiceProcessing ( IN  uint32  uiOperation,
                              IN  x_IFX_VMAPI_LineVoiceProcessing  *pxLineVoiceProcessing,
                              IN  uint32  uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Line Codec object
                that comprises information like echo transmit codec, receive
                codec, etc..., under a particular profile and line.
    \param[in,out]  pxLineVoiceCodec Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_LineVoiceCodec(IN_OUT  x_IFX_VMAPI_LineCodec  *pxLineVoiceCodec,
                       IN uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Line Codec object
                that comprises information like echo transmit codec, receive
                codec, etc., under a particular profile and line.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxLineVoiceCodec Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineVoiceCodec ( IN  uint32  uiOperation,
                         IN  x_IFX_VMAPI_LineCodec  *pxLineVoiceCodec,
                         IN  uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Codec List object that
                 comprises of list of Codec settings under a particular profile and line.
    \param[in,out]  pxCodecList Pointer to the list of object structures
    \param[in]      uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_LineCodecList(IN_OUT x_IFX_VMAPI_LineCodecList  *pxCodecList,
                          IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Codec List object that
                 comprises of list of Codec settings under all  profiles and
								 lines.
    \param[in,out]  pxCodecList Pointer to the object structure
    \param[in]      uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/						  
int32 ifx_get_LineCodecList_All(IN_OUT x_IFX_VMAPI_LineCodecList *pxCodecList,
                            IN uint32 uiInFlag);

/*!  
    \brief      This method is used for setting the attributes to the Codec List object that
                comprises of list of Codec settings under a particular profile and
								line.
    \param[in] uiOperation Operation Type 
    \param[in] pxCodecList Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return    IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineCodecList( IN uint32  uiOperation,
                       IN  x_IFX_VMAPI_LineCodecList  *pxCodecList,
                       IN uint32 uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Codec List object that
                 comprises of list of Codec settings under a particular profile and
								 line.
    \param[in,out]  pxCodecDesc Pointer to the object structure
    \param[in]      uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_CodecDesc(IN_OUT x_IFX_VMAPI_CodecDesc  *pxCodecDesc,
                          IN uint32 uiFlags);


/*!  
    \brief      This method is used for setting the attributes to the Codec List object that
                comprises of list of Codec settings under a particular profile and
								line.
    \param[in] uiOperation Operation Type 
    \param[in] pxCodecDesc Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return    IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_CodecDesc( IN uint32  uiOperation,
                       IN  x_IFX_VMAPI_CodecDesc  *pxCodecDesc,
                       IN uint32 uiFlags);

#if 0 

/*! 
    \brief      This method is used for getting the attributes of the Line Call Register
								table that holds the of call information for all lines.
    \param[out]  numEntries Number of object entries								
    \param[in,out]  pxVoiceSystem Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_all_LineCallRegister( OUT  uint32 *numEntries,
							  IN_OUT x_IFX_VMAPI_VoiceSystem *pxVoiceSystem, 
                              IN uint32 uiFlags);


/*!  
    \brief     This method is used for setting the attributes to the Line Call Register 
				for a particular line.
    \param[in] uiOperation Operation Type 
    \param[in] pxVoiceSystem Pointer to the object structure
    \param[in] uiFlags Input Flag
    \return    IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineCallRegister( IN uint32  uiOperation,
						IN x_IFX_VMAPI_VoiceSystem *pxVoiceSystem, 
                        IN uint32 uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Line Address Book that
                contains address entries for a particular line.
	\param[out]  numEntries Number of object entries
    \param[in,out]  pxVoiceSystem Pointer to the list of object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_all_LineAddressBook( OUT  uint32 *numEntries,
							IN_OUT x_IFX_VMAPI_VoiceSystem *pxVoiceSystem, 
                            IN uint32 uiFlags);


/*! 
    \brief       This method is used for setting the attributes of the Line Address Book that
                contains address entries for a particular line.
    \param[in] uiOperation Operation Type 
    \param[in] pxVoiceSystem Pointer to the object structure
    \param[in] uiFlags Input Flag
    \return    IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineAddressBook( IN uint32  uiOperation,
						 IN x_IFX_VMAPI_VoiceSystem *pxVoiceSystem, 
                         IN uint32 uiFlags);

#endif


/*! 

    \brief       This method is used for getting the attributes of the statistics object
				 associated with a line.
    \param[in,out]  pxLineStats Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_LineStats(IN_OUT  x_IFX_VMAPI_LineStats  *pxLineStats,
                  IN uint32  uiFlags);

/*! 

    \brief       This method is used for setting the attributes to the statistics object
				 associated with a line.
    \param[in] uiOperation Operation Type 
    \param[in,out]  pxLineStats Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineStats(IN uint32  uiOperation,
				  IN_OUT  x_IFX_VMAPI_LineStats  *pxLineStats,
                  IN uint32  uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Fax T38 information object.
    \param[in,out]  pxFax Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_ProfileMediaFaxT38(IN_OUT x_IFX_VMAPI_FaxT38 *pxFax, 
               						 IN uint32 uiFlags);


/*! 
    \brief       This method is used for setting the attributes to the Fax T38 information object.
    \param[in] 	uiOperation Operation Type 
    \param[in] 	pxFax Pointer to the object structure
    \param[in] 	uiFlags Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_ProfileMediaFaxT38(IN uint32  uiOperation,
						  IN x_IFX_VMAPI_FaxT38 *pxFax, 
                          IN uint32 uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Numbering Plan object.   	        
    \param[in,out]  pxNumPlan Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_NumPlan (IN_OUT x_IFX_VMAPI_NumPlan  *pxNumPlan,
                   IN uint32 uiFlags);


/*! 
    \brief       This method is used for setting the attributes to the Numbering Plan object. 
    \param[in]   uiOperation Operation Type 
    \param[in]   pxNumPlan Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_NumPlan ( IN uint32 uiOperation,
                  IN  x_IFX_VMAPI_NumPlan  *pxNumPlan,
                  IN uint32 uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Address Book object.   	        
    \param[in,out]  pxAddrBook Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_AddrBook (IN_OUT x_IFX_VMAPI_AddressBook  *pxAddrBook,
                   IN uint32 uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Address Book object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxAddrBook Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_AddrBook ( IN uint32 uiOperation,
                  IN  x_IFX_VMAPI_AddressBook  *pxAddrBook,
                  IN uint32 uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Call Register.    	        
    \param[in,out]  pxDialCallReg Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_DialCallReg (IN_OUT x_IFX_VMAPI_DialCallRegister  *pxDialCallReg,
                   IN uint32 uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Call Register object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxDialCallReg Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_DialCallReg ( IN uint32 uiOperation,
                  IN  x_IFX_VMAPI_DialCallRegister  *pxDialCallReg,
                  IN uint32 uiFlags);
/*! 
    \brief       This method is used for getting the attributes of the Missed Call Register Entry object.
    \param[in,out]  pxMissCallRegEtr Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_MissCallRegEntry (IN_OUT  x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Missed Call Register Entry object.            
    \param[in]   uiOperation Operation Type 
    \param[in]   pxMissCallRegEtr Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_MissCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Missed Call Register object.
    \param[in,out]  pxMissCallReg Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_MissCallReg (IN_OUT x_IFX_VMAPI_MissCallRegister  *pxMissCallReg,
                   IN uint32 uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Missed Call Register object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxMissCallReg Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_MissCallReg ( IN uint32 uiOperation,
                  IN  x_IFX_VMAPI_MissCallRegister  *pxMissCallReg,
                  IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Received Call Register Entry object.
    \param[in,out]  pxRecvCallRegEtr Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_RecvCallRegEntry (IN_OUT  x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Received Call Register Entry object.            
    \param[in]   uiOperation Operation Type 
    \param[in]   pxRecvCallRegEtr Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_RecvCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,
                      IN uint32  uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Received Call Register object.   	        
    \param[in,out]  pxRecvCallReg Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_RecvCallReg (IN_OUT x_IFX_VMAPI_RecvCallRegister  *pxRecvCallReg,
                   IN uint32 uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Received Call Register object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxRecvCallReg Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_RecvCallReg ( IN uint32 uiOperation,
                  IN  x_IFX_VMAPI_RecvCallRegister  *pxRecvCallReg,
                  IN uint32 uiFlags);



/*! 
    \brief       This method is used for getting the attributes of the Line Subscription object.
    \param[in,out]  pxLineSubscr Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_LineSubscription (IN_OUT  x_IFX_VMAPI_LineSubscription  *pxLineSubscr,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Line Subscription object.            
    \param[in]   uiOperation Operation Type 
    \param[in]   pxLineSubscr Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineSubscription(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_LineSubscription  *pxLineSubscr,
                      IN uint32  uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Line Subscription object.            
    \param[in,out]   pxLineEvents Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_LineEvents (IN_OUT  x_IFX_VMAPI_LineEvents  *pxLineEvents,
                       IN   uint32  uiFlags);


/*! 
    \brief       This method is used for setting the attributes to the Line Subscription object.            
    \param[in]   uiOperation Operation Type 
    \param[in]   pxLineEvents Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_LineEvents(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_LineEvents  *pxLineEvents,
                      IN uint32  uiFlags);




/*! 
    \brief       This method is used for getting the attributes of the Auth Config object.
    \param[in,out]  pxAuthCfg Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_AuthCfg (IN_OUT  x_IFX_VMAPI_SipAuthCfg  *pxAuthCfg,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Auth Config object.            
    \param[in]   uiOperation Operation Type 
    \param[in]   pxAuthCfg Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_AuthCfg(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_SipAuthCfg  *pxAuthCfg,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Address Book Entry object.
    \param[in,out]  pxAddrEntry Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_AddrEntry (IN_OUT  x_IFX_VMAPI_AddressBookEntry  *pxAddrEntry,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Address Book Entry object.            
    \param[in]   uiOperation Operation Type 
    \param[in]   pxAddrEntry Pointer to the list of object structures
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_AddrEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_AddressBookEntry  *pxAddrEntry,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Event Subscribe object.
    \param[in,out]  pxEventSub Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_EventSubscribe (IN_OUT  x_IFX_VMAPI_EventSubscribe  *pxEventSub,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Event Subscribe object.            
    \param[in]   uiOperation Operation Type 
    \param[in]   pxEventSub Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_EventSubscribe(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_EventSubscribe  *pxEventSub,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Dialled Call Register Entry object.
    \param[in,out]  pxDialCallRegEtr Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_DialCallRegEntry (IN_OUT  x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Dialled Call Register Entry object.            
    \param[in]   uiOperation Operation Type 
    \param[in]   pxDialCallRegEtr Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_DialCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Numbering Plan Rule object.
    \param[in,out]  pxNumRule Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_NumPlanRule (IN_OUT  x_IFX_VMAPI_NumPlanRule  *pxNumRule,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Numbering Rule object.            
    \param[in]   uiOperation Operation Type 
    \param[in]   pxNumRule Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_NumPlanRule(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_NumPlanRule  *pxNumRule,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Miscellaneous information object.								 
    \param[in,out]  pxMisc Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_Misc(IN_OUT x_IFX_VMAPI_Misc *pxMisc, 
               						 IN uint32 uiFlags);


/*! 
    \brief      This method is used for setting the attributes to the Miscellaneous information	object.						
    \param[in] 	uiOperation Operation Type 
    \param[in] 	pxMisc Pointer to the object structure
    \param[in] 	uiFlags Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_Misc(IN uint32  uiOperation,
					IN x_IFX_VMAPI_Misc *pxMisc, 
                    IN uint32 uiFlags);


/*! 
    \brief This method is used for getting the attributes of the  FXO Physical Interface object.
    \param[in,out] pxFxoPhyIf Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_FxoPhyInterface(IN x_IFX_VMAPI_FxoPhyIf *pxFxoPhyIf, 
                    IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the FXO Physical Interface object.
    \param[in] uiOperation Operation Type 
    \param[in] pxFxoPhyIf Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_set_FxoPhyInterface(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_FxoPhyIf *pxFxoPhyIf,
                            IN uint32 uiFlags);

/*! 
    \brief This method is used for getting the attributes of the FXS Physical Interface object.
    \param[in,out] pxFxsIf Pointer to the object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_get_FxsPhyInterface(IN_OUT x_IFX_VMAPI_FxsPhyIf *pxFxsIf,
                                 IN uint32 uiFlags);

/*! 
    \brief This method is used for setting the attributes to the FXS Physical Interface object.
    \param[in] uiOperation Operation Type 
    \param[in] pxFxsIf Pointer to object structure
    \param[in] uiFlags Input Flag
    \result IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_set_FxsPhyInterface(IN uint32 uiOperation,
                            IN x_IFX_VMAPI_FxsPhyIf *pxFxsIf,
                            IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Debug setting object.								 
    \param[in,out]  pxDbgSet Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_DbgSettings(IN_OUT x_IFX_VMAPI_SystemDebugSettings *pxDbgSet, 
               						 IN uint32 uiFlags);


/*! 
    \brief      This method is used for setting the attributes to the Debug Settings object.						
    \param[in] 	uiOperation Operation Type 
    \param[in] 	pxDbgSet Pointer to the object structure
    \param[in] 	uiFlags Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_DbgSettings(IN uint32  uiOperation,
				IN x_IFX_VMAPI_SystemDebugSettings *pxDbgSet, 
                IN uint32 uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the Version Info object.
    \param[in,out]  pxVer Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_Version(IN_OUT x_IFX_VMAPI_SystemVersionRegister *pxVer, 
               						 IN uint32 uiFlags);


/*! 
    \brief       This method is used for getting the attributes of the DECT Interface object.
    \param[in,out]  pxDectInf Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_DectInterface(IN_OUT x_IFX_VMAPI_DectSystem *pxDectInf,
               			  IN uint32 uiFlags);


/*! 
    \brief       This method is used for setting the attributes to the DECT Interface object.
    \param[in] 	uiOperation Operation Type 
    \param[in] 	pxDectInf Pointer to the object structure
    \param[in] 	uiFlags Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_DectInterface(IN uint32 uiOperation,
                      IN x_IFX_VMAPI_DectSystem *pxDectInf, 
                      IN uint32 uiFlags);
int32
ifx_set_DectInterfaceToModem(IN x_IFX_VMAPI_DectSystem *pxDectInf);

/*! 
    \brief       This method is used for getting the attributes of the DECT Handset object.
    \param[in,out]  pxDectHand Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_DectHandset(IN_OUT x_IFX_VMAPI_DectHandset *pxDectHand,
               			  IN uint32 uiFlags);

/*! 
    \brief       This method is used for setting the attributes to theDECT Interface information.
    \param[in] 	uiOperation Operation Type 
    \param[in] 	pxDectHand Pointer to the object structure
    \param[in] 	uiFlags Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_DectHandset(IN uint32 uiOperation,
                    IN x_IFX_VMAPI_DectHandset *pxDectHand, 
                    IN uint32 uiFlags);

#ifdef LTAM
/*! 
    \brief       This method is used for getting the attributes of the Physical Interface Test object.
    \param[in,out]  pxPhyIntTest Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_PhyInterfaceTest(IN_OUT x_IFX_VMAPI_VoiceServPhyIfTest *pxPhyIntTest,
               			  IN uint32 uiFlags);

/*! 
    \brief       This method is used for setting the attributes to thePhysical Interface Test object.
    \param[in] 	uiOperation Operation Type 
    \param[in] 	pxPhyIntTest Pointer to the object structure
    \param[in] 	uiFlags Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_PhyInterfaceTest(IN uint32 uiOperation,
											IN x_IFX_VMAPI_VoiceServPhyIfTest *pxPhyIntTest, 
                      IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the Physical InterfaceTest Result object.
    \param[in,out]  pxPhyIntTestRes Pointer to the object structure
    \param[in]   uiFlags Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_PhyInterfaceTestResult(IN_OUT x_IFX_VMAPI_VoiceServTestResult *pxPhyIntTestRes,
               			  IN uint32 uiFlags);

/*! 
    \brief       This method is used for setting the attributes to the Physical Interface Test Result object.
    \param[in] 	uiOperation Operation Type 
    \param[in] 	pxPhyIntTestRes Pointer to the object structure
    \param[in] 	uiFlags Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_PhyInterfaceTestResult(IN uint32 uiOperation,
											IN x_IFX_VMAPI_VoiceServTestResult *pxPhyIntTestRes, 
                      IN uint32 uiFlags);
#endif /* LTAM */ 

#ifdef MESSAGE_SUPPORT

/*! 
    \brief       This method is used for getting the attributes of the message inbox object.
    \param[in,out]  pxMsgIn Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_MsgInbox (IN_OUT x_IFX_VMAPI_IN_Message  *pxMsgIn,
                        IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the message inbox object.
    \param[in] 	 uiOperation Operation Type 
    \param[in] 	 pxMsgIn Pointer to the object structure
    \param[in] 	 uiFlags Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_MsgInbox(IN uint32 uiOperation,
								 IN x_IFX_VMAPI_IN_Message *pxMsgIn, 
                 IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the attributes of the message outbox object.
    \param[in,out]  pxMsgOut Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_MsgOutbox (IN_OUT x_IFX_VMAPI_OUT_Message  *pxMsgOut,
                        IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the message outbox object.
    \param[in] 	 uiOperation Operation Type 
    \param[in] 	 pxMsgOut Pointer to the object structure
    \param[in] 	 uiFlags Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_MsgOutbox(IN uint32 uiOperation,
								 IN x_IFX_VMAPI_OUT_Message *pxMsgOut, 
                 IN uint32 uiFlags);

#endif
//#ifdef DECT_SUPPORT

/*! 
    \brief       This method is used for getting the attributes of the Transmit Power object.
    \param[in,out]  pxTransPower Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 
ifx_get_TransPower(IN_OUT x_IFX_VMAPI_TransmitPowerParam *pxTransPower,
                           IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the Transmit Power object.
    \param[in] 	 uiOperation Operation Type 
    \param[in] 	 pxTransPower Pointer to the object structure
    \param[in] 	 uiInFlag Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_TransPower (IN uint32 uiOperation,
                         IN x_IFX_VMAPI_TransmitPowerParam *pxTransPower,
                         IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the Transmit Power object at the modem.
    \param[in] 	 ucStartStopTest Modem read or write operation 
    \param[in] 	 pxTransParam Pointer to the object structure
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/						 
int32
ifx_set_TransPowerToModem(IN uchar8 ucStartStopTest,
                        IN x_IFX_VMAPI_TransmitPowerParam *pxTransParam);


/*! 
    \brief       This method is used for getting the attributes of the RF Mode object.
    \param[in,out]  pxRfmode Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 
ifx_get_rfmode(IN_OUT x_IFX_VMAPI_RFMode *pxRfmode,
                           IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the RF Mode object.
    \param[in] 	 uiOperation Operation Type 
    \param[in] 	 pxRfmode Pointer to the object structure
    \param[in] 	 uiInFlag Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_rfmode(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_RFMode *pxRfmode,
                         IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the RF Mode object at the modem.
    \param[in] 	 ucStartStopTest Modem read or write operation
    \param[in] 	 pxRfmode Pointer to the object structure
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_rfmodeToModem(IN uchar8 ucStartStopTest,
							IN x_IFX_VMAPI_RFMode *pxRfmode);




/*! 
    \brief       This method is used for getting the attributes of the RFPI object.
    \param[in,out]  pxRfpi Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 
ifx_get_Rfpi(IN_OUT x_IFX_VMAPI_DectRfpi  *pxRfpi,
                           IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the RFPI object.
    \param[in] 	 uiOperation Operation Type 
    \param[in] 	 pxRfpi Pointer to the object structure
    \param[in] 	 uiInFlag Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_Rfpi(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_DectRfpi  *pxRfpi,
                         IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the RFPI object at the modem.
    \param[in] 	 ucStartStopTest Modem read or write operation
    \param[in] 	 pxRfpi Pointer to the object structure
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_RfpiToModem(IN uchar8 ucStartStopTest,
                    IN x_IFX_VMAPI_DectRfpi *pxRfpi);




/*! 
    \brief       This method is used for getting the attributes of the DECT Country object.
    \param[in,out]  pxCtryset Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 
ifx_get_CtrySet(IN_OUT x_IFX_VMAPI_DectCountrySettings  *pxCtryset,
                           IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the DECT Country object.
    \param[in] 	 uiOperation Operation Type 
    \param[in] 	 pxCtryset Pointer to the object structure
    \param[in] 	 uiInFlag Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_CtrySet(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_DectCountrySettings  *pxCtryset,
                         IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the DECT Country object at the modem.
    \param[in] 	 ucStartStopTest Modem read or write operation
    \param[in] 	 pxCtryset Pointer to the object structure
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_set_CtrySetToModem(IN uchar8 ucStartStopTest,
                             IN x_IFX_VMAPI_DectCountrySettings *pxCtryset);

/*! 
    \brief       This method is used for getting the attributes of the BMC object.
    \param[in,out]  pxBmcparam Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 
ifx_get_Bmcparam(IN_OUT x_IFX_VMAPI_DectBMCParams  *pxBmcparam,
                           IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the BMC object.
    \param[in] 	 uiOperation Operation Type 
    \param[in] 	 pxBmcparam Pointer to the object structure
    \param[in] 	 uiInFlag Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_Bmcparam(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_DectBMCParams  *pxBmcparam,
                         IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the BMC object at the modem.
    \param[in] 	 ucStartStopTest Modem read or write operation
    \param[in] 	 pxBmcparam Pointer to the object structure
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 
ifx_set_BmcparamToModem(IN uchar8 ucStartStopTest,
                        IN x_IFX_VMAPI_DectBMCParams *pxBmcparam);




/*! 
    \brief       This method is used for getting the attributes of the Oscillator Trim object.
    \param[in,out]  pxOsctrim Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_Osctrim(IN_OUT x_IFX_VMAPI_DectOscTrimVal  *pxOsctrim,
                           IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the Oscillator Trim object.
    \param[in]   uiOperation Operation Type
    \param[in]   pxOsctrim Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_Osctrim(IN uint32 uiOperation,
                         IN x_IFX_VMAPI_DectOscTrimVal  *pxOsctrim,
                         IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the Oscillator Trim object at the modem.
    \param[in]   ucStartStopTest Modem read or write operation
    \param[in]   pxOsctrim Pointer to the object structure
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_OsctrimToModem(IN uchar8 ucStartStopTest,
                      IN x_IFX_VMAPI_DectOscTrimVal *pxOsctrim);


/*! 
    \brief       This method is used for getting the attributes of the GFSK object.
    \param[in,out]  pxGfsk Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_Gfsk(IN_OUT x_IFX_VMAPI_DectGFSKVal  *pxGfsk,
                           IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the GFSK.
    \param[in]   uiOperation Operation Type
    \param[in]   pxGfsk Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_Gfsk(IN uint32 uiOperation,
                   IN x_IFX_VMAPI_DectGFSKVal  *pxGfsk,
                   IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the GFSK object at the modem.
    \param[in]   ucStartStopTest Modem read or write operation
    \param[in]   pxGfsk Pointer to the object structure
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_GfskToModem(IN uchar8 ucStartStopTest,
                      IN x_IFX_VMAPI_DectGFSKVal *pxGfsk);


/*! 
    \brief       This method is used for getting the attributes of the XRAM object.
    \param[in,out]  pxXram Pointer to the object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 
ifx_get_Xram(OUT x_IFX_VMAPI_DectXRAM *pxXram,
                           IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the XRAM object.
    \param[in]   uiOperation Operation Type
    \param[in]   pxXram Pointer to the Xram object structure
    \param[in]   uiInFlag Input Flag
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_Xram(IN uint32 uiOperation,
                   IN x_IFX_VMAPI_DectXRAM *pxXram,
                   IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes of the XRAM object at the modem.
    \param[in] 	 ucStartStopTest Modem read or write operation
    \param[in] 	 pxXram Pointer to the object structure
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_XramToModem(IN uchar8 ucStartStopTest,
            IN x_IFX_VMAPI_DectXRAM *pxXram);



/*! 
    \brief      This method is used for setting the Diagnostics mode.
    \param[in] 	uiOperation Operation Type 
    \param[in] 	ucStartStopTest Enable or disable diagnostic mode
    \param[in] 	uiInFlag Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_DectDiagnostics (IN uint32 uiOperation,
                           IN uchar8 ucStartStopTest,
						   IN uint32 uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the TBR06 Test object.
    \param[in] 	uiOperation Operation Type 
    \param[in] 	ucStartStopTest Start or Stop Test
    \param[in] 	uiInFlag Input Flag
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_Tbr6Test (IN uint32 uiOperation,
                  IN uchar8 ucStartStopTest,
				  IN uint32 uiInFlag);
//#endif

/*! 
    \brief       This function is used initialize the debug for MAPI Voice.
    \param[in] 	cDbgType Debug Type 
    \param[in] 	cDbgLvl Debug Level
    \param[out] pcRet Pointer to Debug handle
    \return    	None
*/
EXTERN void IFX_VMAPI_DbgInit(
             IN char8 cDbgType,
             IN char8 cDbgLvl,
             OUT char8 *pcRet);

/*! 
    \brief       This function is used set the debug type and level for MAPI Voice.
    \param[in] 	ucType Debug Type 
    \param[in] 	ucLevel Debug Level
    \return    	IFX_SUCCESS or IFX_FAILURE
*/
int32 
IFX_VMAPI_SetDebug(uchar8 ucType , uchar8 ucLevel);

/*! 
    \brief       This function is used to free an object list.
    \param[in] 	pxVoid Pointer to the object list 
    \param[in] 	ucObjType Type of the object
    \return    	None
*/
void
ifx_vmapi_freeObjectList(IN void *pxVoid,IN uchar8 ucObjType);

/* Notification related  */

/*! 
    \brief       This function is used notify changes as and when they occur .
    \param[in] 	ucInfoType Info type
    \param[in] 	ucSize Size of info
    \return    	IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
char8 IFX_VMAPI_IntimateOnChange(IN uchar8 ucInfoType[],IN uchar8 ucSize);

/*! 
    \brief       This method is used for getting the attributes of the Contact List.
    \param[in,out] 	 pxContactList Pointer to the object structure
    \param[in] 	 uiInFlag Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_get_ContactList (IN_OUT  x_IFX_VMAPI_ContactList  *pxContactList,
                       IN   uint32  uiInFlag);

/*! 
    \brief       This method is used for setting the attributes to the Contact List.
    \param[in] 	uiOperation Operation Type 
	\param[in] 	 pxContactList Pointer to the object structure
    \param[in] 	 uiInFlag Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_set_ContactList(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactList *pxContactList,
                      IN uint32  uiInFlag);


/*! 
    \brief       This method is used for setting the attributes to the Contact List Entry.
	\param[in] 	uiOperation Operation Type 
    \param[in] 	 pxContactListEtr Pointer to the object structure
    \param[in] 	 uiInFlag Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/					  
int32 ifx_set_ContactListEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactListEntry *pxContactListEtr,
                      IN uint32  uiInFlag);
					  
/*! 
    \brief       This method is used for getting the attributes of the Contact List Entry.
    \param[in,out] 	 pxContactListEtr Pointer to the object structure
    \param[in] 	 uiInFlag Input Flag
    \return    	 IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/		
int32 ifx_get_ContactListEntry (IN_OUT x_IFX_VMAPI_ContactListEntry  *pxContactListEtr,
                       IN   uint32  uiInFlag);


/*! 
    \brief       This method is used for getting the values of Missed Call Register Entry.
    \param[in,out]  pxMissCallRegEtr Pointer to the object structure
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_PstnMissCallRegEntry (IN_OUT  x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the values of Missed Call Register Entry.
    \param[in]   uiOperation Operation Type
    \param[in]   pxMissCallRegEtr Pointer to the object structure
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_PstnMissCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the values of Missed Call Register object.
    \param[in,out]  pxMissCallReg Pointer to the object structure
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_PstnMissCallReg (IN_OUT x_IFX_VMAPI_MissCallRegister  *pxMissCallReg,
                   IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the values of Missed Call Register object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxMissCallReg Pointer to the object structure
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_PstnMissCallReg ( IN uint32 uiOperation,
                  IN  x_IFX_VMAPI_MissCallRegister  *pxMissCallReg,
                  IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the values of dialed Call Register Entry.
    \param[in,out]  pxDialCallRegEtr Pointer to the object structure
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_PstnDialCallRegEntry (IN_OUT  x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the values of dialed Call Register Entry.                 
    \param[in]   uiOperation Operation Type 
    \param[in]   pxDialCallRegEtr Pointer to the list of object structures
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_PstnDialCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,
                      IN uint32  uiFlags);

/*! 
    \brief       This method is used for getting the values of dialed Call Register object.          
    \param[in,out]  pxDialCallReg Pointer to the object structure
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_PstnDialCallReg (IN_OUT x_IFX_VMAPI_DialCallRegister  *pxDialCallReg,
                   IN uint32 uiFlags);

/*! 
    \brief       This method is used for setting the values of dialed Call Register object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxDialCallReg Pointer to the list of object structures
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_PstnDialCallReg ( IN uint32 uiOperation,
                  IN  x_IFX_VMAPI_DialCallRegister  *pxDialCallReg,
                  IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the values of received Call Register Entry. 
    \param[in,out]  pxRecvCallRegEtr Pointer to the object structure
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_PstnRecvCallRegEntry (IN_OUT  x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,
                       IN   uint32  uiFlags);

/*! 
    \brief       This method is used for setting the values of received Call Register Entry.               
    \param[in]   uiOperation Operation Type 
    \param[in]   pxRecvCallRegEtr Pointer to the list of object structures
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_PstnRecvCallRegEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,
                      IN uint32  uiFlags);


/*! 
    \brief       This method is used for getting the values of received Call Register object.      
    \param[in,out]  pxRecvCallReg Pointer to the object structure
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_get_PstnRecvCallReg (IN_OUT x_IFX_VMAPI_RecvCallRegister  *pxRecvCallReg,
                   IN uint32 uiFlags);

/*! 
    \brief       This method is used for setting the values of received Call Register object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxRecvCallReg Pointer to the list of object structures
    \param[in]   uiFlags Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32
ifx_set_PstnRecvCallReg ( IN uint32 uiOperation,
                  IN  x_IFX_VMAPI_RecvCallRegister  *pxRecvCallReg,
                  IN uint32 uiFlags);

/*! 
    \brief       This method is used for getting the values of Contact list object.            
    \param[in,out]  pxContactList Pointer to the object structure
    \param[in]   uiInFlag Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/


int32 ifx_get_PstnContactList (IN_OUT  x_IFX_VMAPI_ContactList  *pxContactList,
                       IN   uint32  uiInFlag);

/*! 
    \brief       This method is used for setting the values of Contact list object. 
    \param[in]   uiOperation Operation Type 
    \param[in]   pxContactList Pointer to the list of object structures
    \param[in]   uiInFlag Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_set_PstnContactList(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactList *pxContactList,
                      IN uint32  uiInFlag);

/*! 
    \brief       This method is used for setting the values of Contact List Entry object.                
    \param[in]   uiOperation Operation Type 
    \param[in]   pxContactListEtr Pointer to the list of object structures
    \param[in]   uiInFlag Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_set_PstnContactListEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactListEntry *pxContactListEtr,
                      IN uint32  uiInFlag);

/*! 
    \brief       This method is used for getting the values of Contact List Entry object.
    \param[in,out]  pxContactListEtr Pointer to the object structure
    \param[in]   uiInFlag Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_get_PstnContactListEntry (IN_OUT x_IFX_VMAPI_ContactListEntry  *pxContactListEtr,
                       IN   uint32  uiInFlag);



/*! 
    \brief       This method is used for getting the values of the common Contact list object.
    \param[in,out]  pxContactList Pointer to the object structure
    \param[in]   uiInFlag Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/


int32 ifx_get_CommonContactList (IN_OUT  x_IFX_VMAPI_ContactList  *pxContactList,
                       IN   uint32  uiInFlag);

/*! 
    \brief       This method is used for setting the values of the common Contact list object.
    \param[in]   uiOperation Operation Type 
    \param[in]   pxContactList Pointer to the list of object structures
    \param[in]   uiInFlag Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_set_CommonContactList(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactList *pxContactList,
                      IN uint32  uiInFlag);

/*! 
    \brief       This method is used for setting the values of the common Contact list entry object.                
    \param[in]   uiOperation Operation Type 
    \param[in]   pxContactListEtr Pointer to the list of object structures
    \param[in]   uiInFlag Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_set_CommonContactListEntry(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_ContactListEntry *pxContactListEtr,
                      IN uint32  uiInFlag);

/*! 
    \brief       This method is used for getting the values of the common Contact list entry object. 
    \param[in,out]  pxContactListEtr Pointer to the object structure
    \param[in]   uiInFlag Input flags
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/

int32 ifx_get_CommonContactListEntry (IN_OUT x_IFX_VMAPI_ContactListEntry  *pxContactListEtr,
                       IN   uint32  uiInFlag);

/*! 
    \brief       This method is used for getting all the entries of a list (e.g Call Registers within a line).
    \param[in]  uiObjectId Object identifier
    \param[in]   pucLineId Line Identifier.
    \return      IFX_VMAPI_SUCCESS or IFX_VMAPI_FAILURE
*/
int32 ifx_delete_All_ListEntries(IN uint32 uiObjectId,IN uchar8 pucLineId);

int32 LTQ_set_SensorList(IN uint32  uiOperation,
                      IN  /*x_LTQ_VMAPI_SensorList*/ void *pxSensorList,
                      IN uint32 uiObjectType,
                      IN uint32  uiInFlag);

int32 LTQ_get_SensorList (IN_OUT  /*x_LTQ_SensorList*/void  *pxSensorList,
												IN uint32 uiObjType,
                        IN   uint32  uiInFlag);

int32 LTQ_get_SensorEntry (IN_OUT /*x_LTQ_VMAPI_SensorList_Entry*/void  *pxSensorListEtr, 
                       IN uint32 uiSensorType,
                       IN   uint32  uiInFlag);

int32 LTQ_set_SensorEntry(IN uint32  uiOperation,
                      IN  /*x_LTQ_VMAPI_SensorList_Entry*/void *pxSensorListEtr,
                      IN  uint32 uiSensorType,
                      IN uint32  uiInFlag);

int32 LTQ_set_SensorAlaramList(IN uint32  uiOperation,
                      IN  /*x_LTQ_SensorAlaram_List*/void *pxAlaramEtr,
				              IN uint32 uiSensorType,
                      IN uint32  uiInFlag);

int32 LTQ_get_SensorAlaramList (IN_OUT  /*x_LTQ_VMAPI_SensorAlaram_List*/void  *pxSensorAlaramList,
                       IN uint32 uiSensorListType,
                       IN   uint32  uiInFlag);

int32 LTQ_set_SensorAlaramEntry(IN uint32  uiOperation,
                      IN  /*x_LTQ_SensorAlaram_Entry*/ void *pxAlaramEtr,
	    			          IN uint32 uiSensorType,
                      IN uint32  uiInFlag);

int32 LTQ_get_ContactList (IN_OUT  /*x_IFX_VMAPI_ContactList*/ void  *pxContactList,
											 IN uint32 uiListType,
                       IN uint32 uiObjectId,
                       IN uint32  uiInFlag);

int32 LTQ_set_ContactList(IN uint32  uiOperation,
                      IN_OUT  void /*x_IFX_VMAPI_ContactList*/ *vpxContactList,
                      IN uint32 uiListType,
                      IN uint32 uiObjectId,
                      IN uint32  uiInFlag);

int32 LTQ_get_ContactListEntry (IN_OUT x_IFX_VMAPI_ContactListEntry *pxContactListEtr,
                       IN  uint32 uiObjectType,
                       IN uint32 uiObjectId,
                       IN   uint32  uiInFlag);
int32 LTQ_set_ContactListEntry (IN uint32  uiOperation,
											 IN_OUT /*x_IFX_VMAPI_ContactListEntry*/ void *pxContactListEtr,
                       IN  uint32 uiObjectType,
                       IN uint32 uiObjectId,
                       IN   uint32  uiInFlag);

int32 LTQ_get_CallRegister (IN_OUT  x_IFX_VMAPI_CallRegister *pxCallReg,
                      IN uint32 uiListType,
                      IN uint32 uiObjectId,
                      IN uint32 uiInFlag);
int32 LTQ_set_CallRegister(IN uint32  uiOperation,
                      IN  x_IFX_VMAPI_CallRegister *pxCallReg,
                      IN uint32  uiListType,
                      IN uint32 uiObjectId,
                      IN uint32 uiInFlag);

int32 LTQ_set_CallRegisterEntry (IN uint32  uiOperation,
											IN_OUT  IN  x_IFX_VMAPI_CallRegEntry *pxCallRegEtr ,
                      IN uint32 uiListType,
                      IN uint32 uiObjectId,
                      IN uint32  uiInFlag);

int32_t IFX_VMAPI_UpdateFwSuppCodec(uint32 uiFwSuppCodec);

#ifdef CVOIP_SUPPORT
	int32 LTQ_CVoIP_ParamRequest(uint32 uiObject);
	int32 LTQ_Request_XramToModem(IN char8*);

#endif
#ifdef ULE_SUPPORT
typedef enum
{
  IFX_ULE_MAPI_FAIL,
  IFX_ULE_MAPI_SUCCESS
}e_IFX_UMAPI_Return;

e_IFX_UMAPI_Return IFX_ULE_CONFIG(uchar8 bset ,uint32 unObjCode, uchar8 *pucBuff, uint32 uiInstanceId);

int32_t
ifx_set_UleSubsInfo(x_IFX_ULE_MAPI_UleSubsInfo *
                   pxUleSubsInfo, IN uint32 uiInstanceId);
int32_t
ifx_set_UleConfig(x_IFX_ULE_MAPI_SystemConfig *
                   pxUleSysConfig, IN uint32 uiInstanceId);
#endif
#ifdef __cplusplus
}
#endif
#ifdef DECT_REPEATER
int ifx_get_DectRepeaterSubs(x_IFX_VMAPI_DectSubsInfo * pxDectRep,IN uchar8 ucEndptId, uint32 uiInstanceId);
int ifx_set_DectRepeaterSubs(x_IFX_VMAPI_DectSubsInfo * pxDectRep, IN uchar8 ucEndptId ,uint32 uiInstanceId);
int ifx_get_DectRepeater(x_IFX_VMAPI_DectRepeater * pxRepeater, uint32 uiInFlag);
int32 ifx_set_DectRepeater(IN uint32 uiOperation,IN x_IFX_VMAPI_DectRepeater * pxDecRep,
                IN uint32 uiInFlag);

#endif

#endif
/* @} */
