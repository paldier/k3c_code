
#ifndef __IFX_VMAPI_COMMON_H__
#define __IFX_VMAPI_COMMON_H__

#include "ifx_common_defs.h"
//#include "ifx_api_util.h"
//#include "ifx_common.h" 
#include "ifx_list.h"


/*! \def IFX_OP_ADD
    \brief Macro that defines the Addition type of operation used in SET API.
*/
#define IFX_OP_ADD              1   /*!<  Addition type of operation used in SET API. */

/*! \def IFX_OP_DEL
    \brief Macro that defines the Deletion type of operation used in SET API.
*/
#define IFX_OP_DEL              2   /*!<  Deletion type of operation used in SET API. */

/*! \def IFX_OP_MOD
    \brief Macro that defines the Modification type of operation used in SET API.
*/
#define IFX_OP_MOD              3   /*!<  Modification type of operation used in SET API. */

#ifndef MAX_FILELINE_LEN
/*!\def MAX_FILELINE_LEN
   \brief This macro denotes maximum file line length
*/
#define MAX_FILELINE_LEN                332
#endif

/*!\def MAX_FILENAME_LEN
   \brief This macro denotes maximum file data length
*/
#define MAX_FILENAME_LEN                256


/*! \def IFX_SUCCESS
    \brief Macro that defines the Success Return Code.
*/
#define IFX_SUCCESS             0   /*!<  Success Return Code. */

/*! \def IFX_FAIL
    \brief Macro that defines the Failure Return Code.
*/
#define IFX_FAIL                -1  /*!<  Failure Return Code. */

/*! \def IFX_FAILURE
    \brief Macro that defines the Failure Return Code.
*/
#define IFX_FAILURE             IFX_FAIL    /*!<  Failure Return Code. */



#ifdef HOST_SUPPORT
#define SYSTEM_CONF_FILE "/tmp/rc.conf"                   // "/flash/rc.conf"
#else
#define SYSTEM_CONF_FILE FILE_RC_CONF                   // "/flash/rc.conf"
#endif

#define DECT_RC_CONF_FILE "/flash/dect_rc.conf"
#define DECT_RC_CHKPOINT_FILE "/tmp/dect_rc.conf_tmp"
#define DECT_RC_CHKPOINT_FILE2 "/tmp/dect_rc.conf_tmp1"
//#define DECT_PART 1
#define IFX_VMAPI_DO_NOT_WRITE_TO_DECT_PART   0x01<<18

#define IFX_MAX_CODEC_NAME_LEN	24

#define IFX_MAX_TSP_ADDR						128
#define IFX_MAX_USR_PASSWD					16
#define IFX_MAX_DOMAIN_NAME					128
#define IFX_MAX_IFACE_DESCR_LEN			12
//#define IFX_MAX_USR_NAME						128
#define IFX_MAX_BUFF_LEN						1024

#define IFX_MAX_PROFILES             1
#define IFX_VP_NAME_LEN						32
#define IFX_MAX_VOICE_LINES_PER_PROFILE		3
#define IFX_MAX_PSTN_LINES_PER_PROFILE		1
#define IFX_VP_MAX_SESSIONS								2
#define IFX_MAX_SESSIONS_PER_LINE					3
#define IFX_MAX_LINES											10
//#define IFX_MAX_LINES			(((IFX_MAX_PROFILES) * (IFX_MAX_VOICE_LINES_PER_PROFILE)) +(IFX_MAX_PSTN_LINES_PER_PROFILE)

#define IFX_VMAPI_MAX_LINE_EVENTS         2
#define IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ   0x01<<16
#define IFX_VMAPI_SEND_NOTIFY_FORCEFULLY_TO_THIS_OBJ   0x01<<17


#define IFX_TIME_STR_SIZE      32
#define IFX_MAX_TONE_NAME						16
#define IFX_MAX_TONES											16
#define IFX_PLAN_MAX_PREFIX_LEN						22

#define IFX_MAX_DIAL_CODE_SIZE  42 
#define IFX_FA_NSX_MAX_SIZE     8
#define IFX_MAX_VERSION_STRING  48
#define IFX_MAX_DIGIT_MAP_LEN				12
#define IFX_MAX_RSP_MAP_TXT					32
#define IFX_MAX_RSPMAP_ELMNTS							1
#define IFX_MAX_PHONE_NO						16
#define IFX_MAX_CNAME								128
#define IFX_MAX_VOICE_INTERFACES					10
#define IFX_MAX_RINGS											12
#define IFX_MAX_IP_ADDRESS_LEN			16
#define IFX_MAX_CALLBLOCK_LIST      10
#define IFX_MAX_SUBSCR_ELMNTS							2
#define IFX_MAX_NUM_PLAN_RULES						50	
#define IFX_MAX_CR_ENTRIES             10
#define IFX_SUBS_EVENT_MWI 				2

/* Definitions related to Jitter Buffer */
#define IFX_JB_FIXED 1
#define IFX_JB_ADAPTIVE 2

//typedef int                 bool;


EXTERN uchar8 ucVMAPIModuleId;

//EXTERN char8 vcCmModId;

#endif
