/********************************************************************************

    Copyright (c) 2014
	LANTIQ DEUTSCHLAND GMBH
    Lilienthalstrasse 15, 85579 Neubiberg, Germany
    For licensing information, see the file 'LICENSE' in the root folder of
    this software module.

********************************************************************************/

#ifndef _VOIPPROFILE_H
#define _VOIPPROFILE_H

#ifdef DECT_SUPPORT
#define DECT_REPEATER
#endif 

//required definition
#ifndef bool
//#define bool char
#endif
typedef int int32;
#define IFX_MAX_RINGS	12
#define IFX_MAX_TONE_NAME  16
#define IFX_MAX_TONES    16
#define IFX_MAX_CNAME 	128
#define IFX_MAX_PHONE_NO 16
#define IFX_MAX_RSPMAP_ELMNTS 1
#define IFX_MAX_RSP_MAP_TXT   32
#define IFX_MAX_DIGIT_MAP_LEN  12
#define IFX_PLAN_MAX_PREFIX_LEN 22
#define IFX_VP_NAME_LEN      32
#define IFX_IDLIST_MAX_LEN 	 20

#include "ifx_vmapi_common.h" 
#include "ifx_vmapi.h"
#include "ugw_structs.h"
#include "string.h"

//Object name
#define VOICE_SERVICE 		  	   	 "Device.Services.VoiceService.1"
#define VOICE_SERVICE_CAPAB      		 "Device.Services.VoiceService.1.Capabilities."
#define VOICE_SERVICE_CODEC_CAPAB		 "Device.Services.VoiceService.1.Capabilities.Codec."
#define VOICE_SERVICE_PHYIF			 "Device.Services.VoiceService.1.PhyInterface."
#define VOICE_SERVICE_VOICE_PROFILE 		 "Device.Services.VoiceService.1.VoiceProfile.1."
#define VOICE_PROFILE_SERVICEPROVIDERINFO	 "Device.Services.VoiceService.1.VoiceProfile.1.ServiceProviderInfo"
#define VOICE_LINE				 "Device.Services.VoiceService.1.VoiceProfile.1.Line."
#define PROFILE_EVENTSUBSCRIBE 		 	 "Device.Services.VoiceService.1.VoiceProfile.1.SIP.EventSubscribe."
#define PROFILE_SIP 					"Device.Services.VoiceService.1.VoiceProfile.1.SIP"
#define DIAL_CALLREG					".X_VENDOR_COM_DialCallRegister."
#define MISS_CALLREG				".X_VENDOR_COM_MissCallRegister."
#define RCV_CALLREG					".X_VENDOR_COM_RecvCallRegister."
#define DIAL_CALLREG_ENTRY			 ".X_VENDOR_COM_DialCallRegister.X_VENDOR_COM_DialCallRegEntry."
#define MISS_CALLREG_ENTRY                       ".X_VENDOR_COM_MissCallRegister.X_VENDOR_COM_MissCallRegEntry."
#define RCV_CALLREG_ENTRY                        ".X_VENDOR_COM_RecvCallRegister.X_VENDOR_COM_RecvCallRegEntry."
#define PSTNLINE						"Device.Services.VoiceService.1.X_VENDOR_COM_FxoPhyIf.1"
#define ADDRESS					 "X_VENDOR_COM_Address"	
#define ADDRESS_ENTRY				"Device.Services.VoiceService.1.X_VENDOR_COM_AddressBook.X_VENDOR_COM_AddressBookEntry."	
#define ADDRESS_BOOK				"Device.Services.VoiceService.1.X_VENDOR_COM_AddressBook." 
#define SENSOR_ALARM				"Device.Services.VoiceService.1.X_VENDOR_COM_SensorAlaramList."
#define SENSOR_READ					"Device.Services.VoiceService.1.X_VENDOR_COM_PowerSensorReadList."
#define SENSOR_ALARM_ENTRY			"Device.Services.VoiceService.1.X_VENDOR_COM_SensorAlaramList.X_VENDOR_COM_SensorAlaramEntry."
#define POWER_SENSOR_READ_ENTRY		"Device.Services.VoiceService.1.X_VENDOR_COM_PowerSensorReadList.X_VENDOR_COM_PowerSensorReadEntry."
#define SENSOR_LIST						"Device.Services.VoiceService.1.X_VENDOR_COM_SensorList."
#define POWER_SENSOR_LIST							"Device.Services.VoiceService.1.X_VENDOR_COM_PowerSensorList."
#define SENSOR_ENTRIES				"Device.Services.VoiceService.1.X_VENDOR_COM_SensorList.X_VENDOR_COM_SensorEntries."
#define POWER_SENSOR_ENTRIES		"Device.Services.VoiceService.1.X_VENDOR_COM_PowerSensorList.X_VENDOR_COM_PowerSensorEntries."
#define DECT_INTERFACE				 "Device.Services.VoiceService.1.X_VENDOR_COM_DectSystem."
#define CALL_BLK_ENTRY 				"Device.Services.VoiceService.1.X_VENDOR_COM_CallBlock.X_VENDOR_COM_CallBlockEntry."
#define CALL_BLOCK					"Device.Services.VoiceService.1.X_VENDOR_COM_CallBlock."
#define FXO_INTERFACE				"Device.Services.VoiceService.1.X_VENDOR_COM_FxoPhyIf"
#define DECT_RFPI				"Device.Services.VoiceService.1.X_VENDOR_COM_DectRfpi"
#define DECT_BMC				"Device.Services.VoiceService.1.X_VENDOR_COM_DectBMCParams"
#define DECT_TRANSPOWER 			"Device.Services.VoiceService.1.X_VENDOR_COM_TransmitPowerParam"
#define DEF_DIALCALLREGENTRY_PATH		"Device.Services.VoiceService.VoiceProfile.Line.X_VENDOR_COM_DialCallRegister.X_VENDOR_COM_DialCallRegEntry"
#define DEF_PSTNDIALCALLREGENTRY_PATH "Device.Services.VoiceService.X_VENDOR_COM_FxoPhyIf.X_VENDOR_COM_DialCallRegister.X_VENDOR_COM_DialCallRegEntry"
#define DEF_MISSCALLREGENTRY_PATH               "Device.Services.VoiceService.VoiceProfile.Line.X_VENDOR_COM_MissCallRegister.X_VENDOR_COM_MissCallRegEntry"
#define DEF_PSTNMISSCALLREGENTRY_PATH "Device.Services.VoiceService.X_VENDOR_COM_FxoPhyIf.X_VENDOR_COM_MissCallRegister.X_VENDOR_COM_MissCallRegEntry"
#define DEF_RCVCALLREGENTRY_PATH               "Device.Services.VoiceService.VoiceProfile.Line.X_VENDOR_COM_RecvCallRegister.X_VENDOR_COM_RecvCallRegEntry"
#define DEF_PSTNRCVCALLREGENTRY_PATH "Device.Services.VoiceService.X_VENDOR_COM_FxoPhyIf.X_VENDOR_COM_RecvCallRegister.X_VENDOR_COM_RecvCallRegEntry"
#define CONTACT_LIST				".X_VENDOR_COM_ContactList."
#define CONTACT_LIST_ENTRY 		       ".X_VENDOR_COM_ContactList.X_VENDOR_COM_ContactListEntry."
#define CONTACT_ADDRESS 		       "X_VENDOR_COM_ContactAddress"
#define DEF_CONTACTLISTENTRY_PATH	       "Device.Services.VoiceService.VoiceProfile.Line.X_VENDOR_COM_ContactList.X_VENDOR_COM_ContactListEntry"
#define DEF_PSTNCONTACTLISTENTRY_PATH              "Device.Services.VoiceService.X_VENDOR_COM_FxoPhyIf.X_VENDOR_COM_ContactList.X_VENDOR_COM_ContactListEntry"

#define COMMON_CONTACT_LIST			".X_VENDOR_COM_CommonContactList."
#define COMMON_CONTACT_LIST_ENTRY		".X_VENDOR_COM_CommonContactList.X_VENDOR_COM_CommonContactListEntry."
#define DEF_COMMON_CONTACTLISTENTRY_PATH	"Device.Services.VoiceService.VoiceProfile.Line.X_VENDOR_COM_CommonContactList.X_VENDOR_COM_CommonContactListEntry"
#define DEF_PSTNCOMMON_CONTACTLISTENTRY_PATH       "Device.Services.VoiceService.X_VENDOR_COM_FxoPhyIf.X_VENDOR_COM_CommonContactList.X_VENDOR_COM_CommonContactListEntry"
#define INMESSAGE_LIST 				".X_VENDOR_COM_INMessage."
#define INMESSAGE_ENTRY 			".X_VENDOR_COM_INMessage.X_VENDOR_COM_INMessageEntry."
#define OUTMESSAGE_LIST 			".X_VENDOR_COM_OUTMessage."
#define OUTMESSAGE_ENTRY		        ".X_VENDOR_COM_OUTMessage.X_VENDOR_COM_OUTMessageEntry."	

#define DECT_RFMODE				"Device.Services.VoiceService.1.X_VENDOR_COM_RFMode"
#define DECT_GFSK				"Device.Services.VoiceService.1.X_VENDOR_COM_DectGFSKVal"
#define DECT_OCS_TRIM				"Device.Services.VoiceService.1.X_VENDOR_COM_DectOscTrimVal"
#define DECT_CNTRY_SETT				"Device.Services.VoiceService.1.X_VENDOR_COM_DectCountrySettings"
#define DECT_XRAM				"Device.Services.VoiceService.1.X_VENDOR_COM_DectXRAM"
#define PHY_IF_TEST				"Device.Services.VoiceService.1.X_VENDOR_COM_VoiceServPhyIfTest"
#define VOICESERVICE_FXS			"Device.Services.VoiceService.1.X_VENDOR_COM_FxsPhyIf."
#define CALLINGFEATURE 				".CallingFeatures"
#define VOICE_PROCESSING 			".VoiceProcessing"
#define VOICESERVICE_TESTRESULT 		"Device.Services.VoiceService.1.X_VENDOR_COM_VoiceServTestResult"
#define LINE_EVENT_SUSCRIBE 			".SIP.EventSubscribe."
#define LINE_SUBSCRIPTION				".SIP"
#define LINE_SESSION				".Session."
#define LINE_STATS				".Stats"
#define CODEC_LIST				".Codec.List."
#define CODEC					".Codec"
#define DOT 					"."
#define VOICESEEVICE_MISCELLANEOUS 		"Device.Services.VoiceService.1.X_VENDOR_COM_Miscellaneous"
#define DECT_HANDSET 				"Device.Services.VoiceService.1.X_VENDOR_COM_DectSystem.X_VENDOR_COM_DectHandset."
#define DECT_REPEATER_PATH 				"Device.Services.VoiceService.1.X_VENDOR_COM_Dect_Repeater."
#define PROFILE_MEDIA_RTP			"Device.Services.VoiceService.1.VoiceProfile.1.RTP"
#define PROFILE_MEDIA_RTCP			"Device.Services.VoiceService.1.VoiceProfile.1.RTP.RTCP"
#define NUMBER_PLAN					"Device.Services.VoiceService.1.VoiceProfile.1.NumberingPlan"
#define NUMBER_PLAN_RULE			"Device.Services.VoiceService.1.VoiceProfile.1.NumberingPlan.PrefixInfo."
#define FAX_T38						"Device.Services.VoiceService.1.VoiceProfile.1.FaxT38."
#define COM_T38						"Device.Services.VoiceService.1.X_VENDOR_COM_T38configuration"
#define SYSTEM_VERSION				"Device.Services.VoiceService.1.X_VENDOR_COM_SystemVersionRegister"
#define FXO_INTERFACE				"Device.Services.VoiceService.1.X_VENDOR_COM_FxoPhyIf"
#define FXS_INTERFACE						"Device.Services.VoiceService.1.X_VENDOR_COM_FxsPhyIf."
#define DEBUG_SETTINGS					"Device.Services.VoiceService.1.X_VENDOR_COM_SystemDebugSettings"
#define VOICESERVICE_TEST_RESULT		"Device.Services.VoiceService.1.X_VENDOR_COM_VoiceServTestResult"
#define VOICESERVICE_ULE_SUBS_INFO      "Device.Services.VoiceService.1.X_VENDOR_COM_UleDevice."
#define VOICESERVICE_ULE_SYSTEM_CONFIG  "Device.Services.VoiceService.1.X_VENDOR_COM_UleSystem"

#ifndef offsetof
#define offsetof(type, member) ((long) &((type *) 0)->member)
#endif

#define IFX_VMAPI_PARAM_TYPE_CHAR         1   /*!< parameter is char */
#define IFX_VMAPI_PARAM_TYPE_UCHAR        2   /*!< parameter is unsigned char */
#define IFX_VMAPI_PARAM_TYPE_SHORT_INT    3    /*!< parameter is short int */
#define IFX_VMAPI_PARAM_TYPE_USHORT_INT   4   /*!< parameter is unsigned short int */
#define IFX_VMAPI_PARAM_TYPE_INT          5   /*!< parameter is int */
#define IFX_VMAPI_PARAM_TYPE_UINT         6   /*!< parameter is unsigned int */
#define IFX_VMAPI_PARAM_TYPE_LONG         7   /*!< parameter is long */
#define IFX_VMAPI_PARAM_TYPE_ULONG        8   /*!< parameter is unsigned long */
#define IFX_VMAPI_PARAM_TYPE_FLOAT        9   /*!< parameter is float */
#define IFX_VMAPI_PARAM_TYPE_DOUBLE       10  /*!< parameter is double */
#define IFX_VMAPI_PARAM_TYPE_STR          11  /*!< parameter is string */
#define IFX_VMAPI_PARAM_TYPE_OBJ          12  /*!< parameter is an object */
#define IFX_VMAPI_PARAM_TYPE_OBJ_LIST     13  /*!< parameter is an object */

#define HEX_BASE_VAL					  16   /*!< Base vale for hex data type */

#define IFX_TR104_TRUE 1
#define IFX_TR104_FALSE 0

#define MAX_CODEC 21
#define MAX_STRING_LENGTH 256

#define VOIP_GET 	7
#define VOIP_SET 	8
#define TEMP_LEN 	10
#define PSTN_LINE 	4

#define LINE_EVENT_MESSAGE_SUMMARY 					 "Message-Summary"
#define LINE_EVENT_DIALOG							 "Dialog"
#define IFX_STRING_TRUE 							 "true"
#define IFX_STRING_FALSE							 "false"
#define IFX_STRING_DISABLED							 "Disabled"
#define IFX_STRING_ENABLED							 "Enabled"
#define IFX_STRING_QUIESCENT						 "Quiescent"
#define IFX_STRING_EVENT_MWI						 "MWI"
#define IFX_STRING_EVENT_DIALOG						 "DIALOG"
#define IFX_STRING_SIP_INBOUNDAUTH_NONE				 "None"
#define IFX_STRING_SIP_INBOUNDAUTH_DIGEST			 "Digest"
#define IFX_STRING_DISABLE							 "Disable"
#define IFX_STRING_AUTO								 "Auto"
#define OSCTRIM_P10_OFF						"IFX_VMAPI_DECT_OSCTRIM_P10_OFF"
#define OSCTRIM_P10_ON                                         "IFX_VMAPI_DECT_OSCTRIM_P10_ON"
#define IFX_STRING_LOCAL							"Local"
#define IFX_STRING_NETWORK							"Network"

/*!
  \brief int32_t
*/
typedef int                int32_t;

/*!<macro to check if error returned by a function ,return UGW_FAILURE*/
#define CHECK_FOR_ERROR(sError) \
      if (nRetVal != IFX_VMAPI_SUCCESS) ({ \
        IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,sError);\
        goto END; \
        })

/*!<macro to check if Object Ptr returned  is NULL,return UGW_FAILURE*/
#define CHECK_FOR_NULL(sVal , sError) ({ \
      if (sVal == NULL) { \
       	 IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_ERROR,IFX_DBG_STR,sError);\
                nRetVal = IFX_VMAPI_FAIL; \
        goto END; \
        } \
        })


typedef struct {
		char8 sName[MAX_LEN_PARAM_NAME];
		uint32 unValue;
} x_IFX_NAME_VALUE;


typedef struct {
			char8 acParamName[MAX_LEN_PARAM_NAME];
			uint8 uiType;
			uint32 unOffset;
}x_IFX_Param;

extern x_IFX_NAME_VALUE axoutbndifacenv[4];

extern x_IFX_NAME_VALUE axtfreqoffsetnv[3];
extern x_IFX_NAME_VALUE axtfreqrangenv[3];
extern x_IFX_NAME_VALUE axtransmitpowernv[9];
extern x_IFX_NAME_VALUE axswpowermodenv[3];
extern x_IFX_NAME_VALUE axdtmfmethodnv[3];
extern x_IFX_NAME_VALUE axtransportnv[5];
extern x_IFX_NAME_VALUE axlinestatusnv[8];
extern x_IFX_NAME_VALUE axcallstatusnv [7];
extern x_IFX_NAME_VALUE axcallingfeatnv[6];
#ifdef IIP
extern x_IFX_NAME_VALUE axmediasecnv[6];
#endif
extern x_IFX_NAME_VALUE axcodecnv[21];
extern x_IFX_Param x_IFX_VMAPI_VoiceService_param[7];
extern x_IFX_Param x_IFX_VMAPI_CodecDesc_param [8];
extern x_IFX_Param x_IFX_VMAPI_VoiceCodecCapabilities_param [3];
extern x_IFX_Param x_IFX_VMAPI_VoiceCapabilities_param[1];
extern x_IFX_Param x_IFX_VMAPI_VoiceServPhyIf_param[5];
extern x_IFX_Param x_IFX_VMAPI_FxoPhyIf_param [17];
extern x_IFX_Param x_IFX_VMAPI_FxsPhyIf_param [12];
extern x_IFX_Param x_IFX_VMAPI_DectHandset_param [24];
extern x_IFX_Param x_IFX_VMAPI_DectCodecDesc_param [3];
#ifdef DECT_REPEATER
extern x_IFX_Param x_IFX_VMAPI_DectSystem_param [17];
#else
extern x_IFX_Param x_IFX_VMAPI_DectSystem_param [11];
#endif
extern x_IFX_Param x_IFX_VMAPI_CallBlockEntry_param [1];
extern x_IFX_Param x_IFX_VMAPI_CallBlock_param [2];
extern x_IFX_Param x_IFX_VMAPI_AddressBookEntry_param [11];
extern x_IFX_Param x_IFX_VMAPI_AddressBook_param [1];
extern x_IFX_Param x_IFX_VMAPI_ToneInfo_param [];
extern x_IFX_Param x_IFX_VMAPI_ToneTable_param [];
extern x_IFX_Param x_IFX_VMAPI_Misc_param [10];
extern x_IFX_Param x_IFX_VMAPI_T38Cfg_param [9];
extern x_IFX_Param x_IFX_VMAPI_GR909_param [5];
extern x_IFX_Param x_IFX_VMAPI_SystemVersionRegister_param [10];
extern x_IFX_Param x_IFX_VMAPI_DbgType_param [2];
extern x_IFX_Param x_IFX_VMAPI_SystemDebugSettings_param [14];
extern x_IFX_Param x_IFX_VMAPI_VoiceServPhyIfTest_param [5];
extern x_IFX_Param x_IFX_VMAPI_VoiceServTestResult_param [25];
extern x_IFX_Param x_IFX_VMAPI_TransmitPowerParam_param [23];
extern x_IFX_Param x_IFX_VMAPI_DectRfpi_param [6];
extern x_IFX_Param x_IFX_VMAPI_DectXRAM_param [10];
extern x_IFX_Param x_IFX_VMAPI_DectBMCParams_param [16];
extern x_IFX_Param x_IFX_VMAPI_DectOscTrimVal_param [3];
extern x_IFX_Param x_IFX_VMAPI_DectGFSKVal_param [2];
extern x_IFX_Param x_IFX_VMAPI_DectCountrySettings_param [6];
extern x_IFX_Param x_IFX_VMAPI_RFMode_param [3];
#ifdef DECT_SENSORS_SUPPORT
extern x_IFX_Param x_LTQ_SensorAlaram_List_param [2];
extern x_IFX_Param x_LTQ_SensorAlaram_Entry_param [5];
extern x_IFX_Param x_LTQ_SensorList_param [4];
extern x_IFX_Param x_LTQ_SensorList_Entry_param [7];
extern x_IFX_Param x_LTQ_PowerSensorList_param [2];
extern x_IFX_Param x_LTQ_PowerSensorEntry_param [6];
extern x_IFX_Param x_LTQ_PowerSensor_ReadList_param [2];
extern x_IFX_Param x_LTQ_PowerSensor_ReadEntry_param [7];
#endif
extern x_IFX_Param x_IFX_VMAPI_ProfileStunConfig_param [6];
extern x_IFX_Param x_IFX_VMAPI_VoiceProfile_param [25];
extern x_IFX_Param x_IFX_VMAPI_EventSubscribe_param [6];
extern x_IFX_Param x_IFX_VMAPI_ProfileEventSubsTable_param [3];
extern x_IFX_Param x_IFX_VMAPI_RspMap_param [3];
extern x_IFX_Param x_IFX_VMAPI_ProfileRspMapTable_param [3];
extern x_IFX_Param x_IFX_VMAPI_ProfileServiceProviderInfo_param [5];
extern x_IFX_Param x_IFX_VMAPI_ProfileSignaling_param [51];
extern x_IFX_Param x_IFX_VMAPI_ProfileMediaRTP_param [13];
extern x_IFX_Param x_IFX_VMAPI_ProfileMediaRTCP_param [4];
#ifdef IIP
extern x_IFX_Param x_IFX_VMAPI_ProfileMediaSecurity_param [15];
#endif
extern x_IFX_Param x_IFX_VMAPI_NumPlan_param [5];
extern x_IFX_Param x_IFX_VMAPI_NumPlanRule_param [12];
extern x_IFX_Param x_IFX_VMAPI_FaxT38_param [10];
extern x_IFX_Param x_IFX_VMAPI_VoiceLine_param [14];
extern x_IFX_Param x_IFX_VMAPI_LineSignaling_param [4];
extern x_IFX_Param x_IFX_VMAPI_SipAuthCfg_param [2];
extern x_IFX_Param x_IFX_VMAPI_LineSubscription_param [3];
extern x_IFX_Param x_IFX_VMAPI_LineEvents_param [6];
extern x_IFX_Param x_IFX_VMAPI_LineCallingFeatures_param [48];
extern x_IFX_Param x_IFX_VMAPI_LineVoiceProcessing_param [7] ;
extern x_IFX_Param x_IFX_VMAPI_LineCodec_param [7];
extern x_IFX_Param x_IFX_VMAPI_LineSession_param [7];
extern x_IFX_Param x_IFX_VMAPI_LineStats_param [29];
#ifdef DECT_REPEATER
extern x_IFX_Param x_IFX_VMAPI_DectSubsInfo_param [8];
extern x_IFX_Param x_IFX_VMAPI_DectRepeater_param [4];
#endif
#ifdef MESSAGE_SUPPORT
/***********************************************************/
/***************MESSAGE object **************************/

extern x_IFX_Param x_IFX_VMAPI_Message_param [2];

extern x_IFX_Param x_IFX_VMAPI_MessageEntry_param [6];
#endif /* MESSAGE_SUPPORT */
extern x_IFX_Param x_IFX_VMAPI_ContactList_param [2];
extern x_IFX_Param x_IFX_VMAPI_ContactListEntry_param [9];
extern x_IFX_Param x_IFX_VMAPI_CallRegister_param [3];
extern x_IFX_Param x_IFX_VMAPI_CallRegEntry_param [14];
#ifdef ULE_SUPPORT
extern  x_IFX_Param x_IFX_ULE_MAPI_UleSubsInfo_param [16];
extern x_IFX_Param x_IFX_ULE_MAPI_SystemConfig_param [15];
#endif

int
ifx_ParseCallBlockList (uchar8 * ucSrc, uchar8 * ucDestList,
                              uchar8 * iLength);
int
ifx_ParseCallBlockListDevice (char8 * ucSrc, char8 * ucDestList,
                              uchar8 * iLength);
int fill_struct_param(ObjList *pxTmpObj,void *pVoipStruct,x_IFX_Param param_detail[],int iSize);
int ifx_get_EventSubscribe (IN_OUT x_IFX_VMAPI_EventSubscribe  *pxEventSub,uint32  uiInFlag);

int32 ifx_get_VoiceCodecCapsEntry(
                    OUT x_IFX_VMAPI_CodecDesc *pxVCCapsEntry,
                    IN uint32 uiInFlag);
int ifx_get_NumPlanRule(x_IFX_VMAPI_NumPlanRule *pxNumRule,uint32  uiInFlag);

int ifx_get_CodecDesc(x_IFX_VMAPI_CodecDesc *pxCodecDesc,uint32  uiInFlag);
int ifx_get_LineEvents(x_IFX_VMAPI_LineEvents  *pxLineEvents,uint32  uiInFlag);
int ifx_get_DialCallRegEntry (x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,uint32  uiInFlag);
int ifx_get_PstnDialCallRegEntry (x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,uint32  uiInFlag);
int ifx_get_MissCallRegEntry (x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,uint32  uiInFlag);
int ifx_get_PstnMissCallRegEntry (x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,uint32  uiInFlag);
int ifx_get_RecvCallRegEntry (x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,uint32  uiInFlag);
int ifx_get_PstnRecvCallRegEntry (x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,uint32  uiInFlag);
int ifx_get_ContactListEntry(x_IFX_VMAPI_ContactListEntry *pxContactListEtr,uint32  uiInFlag);
int ifx_get_PstnContactListEntry(x_IFX_VMAPI_ContactListEntry *pxContactListEtr,uint32  uiInFlag);
int ifx_get_CommonContactListEntry(x_IFX_VMAPI_ContactListEntry *pxContactListEtr,uint32  uiInFlag);

/* API to get Host IP and DNS servers list */
typedef enum {
	IFX_IP_ADDRESS_V4,
	IFX_IP_ADDRESS_V6
} e_IFX_IP_ADDRESS_TYPE;

typedef struct {
	char8 sIPAddress[MAX_LEN_PARAM_NAME];
	e_IFX_IP_ADDRESS_TYPE eType;
} x_IFX_IP_ADDRESS;

/*! \brief  Get List of DNS server for Default WAN interface.
   \param[out] puiCount is  Number of DNS servers returned
   \param[out] pxDNS Array of DNS servers of puiCount number.
   Caller must free the buffer.
   \return 0 if OK / -1 on ERROR
*/
int32_t ifx_get_DNSIP(OUT uint32_t *puiCount, OUT x_IFX_IP_ADDRESS **pxDNS);

/*! \brief  Get IPv4 and IPv6 addresses for Default WAN interface.
   \param[out] pcHostIPv4 is IPv4 address of the Default WAN
   \param[out] pcHostIPv6 is IPv6 address of the Default WAN
   \return 0 if OK / -1 on ERROR
*/
int32_t ifx_get_HostIP(OUT char8 *pcHostIPv4, OUT char8 *pcHostIPv6);

/*Api to set Auth config*/
int ifx_get_AuthCfg(x_IFX_VMAPI_SipAuthCfg *pxAuthCfg,uint32  uiInFlag);

/*Api to update the value in object list*/
int32_t UpdateParamValueInDB(ObjList *pxTmpObj,void *pVoipStruct,x_IFX_Param acOffsetStruct[],int nSize);

void
ifx_vmapi_freeObjectList(void *pxVoid,IN uchar8 ucObjType);
int
IFX_SipUri_GetHostName(IN char8* pcString,OUT char8* pcHostName);

void IFX_VMAPI_DbgInit(
             IN char8 cDbgType,
             IN char8 cDbgLvl,
             OUT char8 *pcRet);


PUBLIC char8 IFX_VMAPI_SendNotifyForRegObject(IN uchar8 ucInfoType,
                                           IN void *pvOldObj , IN void *pvNewObj);

#endif //#ifndef _VOIPPROFILE_H
