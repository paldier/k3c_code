/**************************************************************************
 **   FILE NAME       : ifx_vmapi_port.h
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Voice Management API 
 **   SRC VERSION     : V0.1
 **   DATE            : 20-06-2006
 **   AUTHOR          : Prashant
 **   DESCRIPTION     : This file defines the portable elements of the implementation.
 **   FUNCTIONS       :
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_VMAPI_PORT_H__
#define __IFX_VMAPI_PORT_H__

/*! \file ifx_vmapi_port.h
    \brief This file contains the portable elements of the VMAPI. This file
		has to be changed when the VMAPI is ported to different platforms.
*/

#ifdef __cplusplus
extern  "C" {
#endif

#include "ifx_common_defs.h"

/** \defgroup VMAPI_TYPES_MACROS VMAPI TYPES and Other Macros
Given below are the data types used by VMAPI */

/** \addtogroup VMAPI_TYPES_MACROS */
/* @{ */
/** Macro used to represent an API */
#define PUBLIC
/** extern */
#define EXTERN  extern
/** static */
#define STATIC  static
/** const */
#define CONST    const

#define PRINT printf

/** Macro used to represent an in parameter of a function */
#define IN
/** Macro used to represent an out parameter of a function */
#define OUT
/** Macro used to represent an in-out parameter of a function */
#define IN_OUT

/** void */
typedef void            VOID;
/* @} */

#define IFX_VMAPI_SUCCESS 0
#define IFX_VMAPI_FAILURE -1

/** \defgroup VMAPI_FUNC_MAP Porting Maps
These macros map to the library/system calls imported */

/** \addtogroup VMAPI_FUNC_MAP */
/* @{ */
#if defined(__LINUX__)
#include <stdlib.h>
/**************************************/
/*! Ascii-to-* conversion macros */
#define IFX_VMAPI_ATOI(ascii_str)     atoi(ascii_str)
#define IFX_VMAPI_ATOF(ascii_str)     atof(ascii_str)
#define IFX_VMAPI_ATOL(ascii_str)     atol(ascii_str)

/*! String functions */
#define IFX_VMAPI_STRCPY(dst,src)     strcpy((char8*)dst,(CONST char8*)src)
#define IFX_VMAPI_STRNCPY(dst,src,n)  strncpy((char8*)dst,(CONST char8*)(src),(n))
#define IFX_VMAPI_STRCAT(dst,src)     strcat((char8*)(dst),(CONST char8*)(src))
#define IFX_VMAPI_STRCMP(dst,src)     strcmp((CONST char8*)(dst),(CONST char8*)(src))
#define IFX_VMAPI_STRSTR(dst,src)     strstr((CONST char8*)dst,(CONST char8*)src)
#define IFX_VMAPI_SPRINTF  sprintf
#if 0
#define IFX_VMAPI_STRCPY(dst,src)     strcpy(dst,src)
#define IFX_VMAPI_STRNCPY(dst,src,n)  strncpy(dst,src,(n))
#define IFX_VMAPI_STRCAT(dst,src)     strcat(dst,src)
#define IFX_VMAPI_STRCMP(dst,src)     strcmp(dst,src)
#define IFX_VMAPI_STRSTR(dst,src)     strstr(dst,src)
#endif

#ifndef offsetof
/*! Used by VMAPI for internal operations - 
		gives the offset of a memeber in structure */
#define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)
#endif

/*! Memory Functions */
#define IFX_VMAPI_MALLOC(s)  malloc(s)
#define IFX_VMAPI_FREE(s)  free(s)

/*! lock macros */
#define IFX_VMAPI_LOCK(uiLock)
#define IFX_VMAPI_UNLOCK(uiLock)

/**************************************/
/*! Debug related */
#if defined (VMAPI_DBG_ENABLE)
#include <assert.h>
//#define VDBG(s) //IFX_DBG_Log s
//#define VDBG(s) IFX_DBGA(s)
#define VDBG(ucModuleId,ucDbgLvl,unMsgId,...) \
{ \
				   IFX_DBG_Log(ucModuleId,ucDbgLvl,unMsgId,__VA_ARGS__); \
}

#define VDBG1(ucModuleId,ucDbgLvl,func,unMsgId,...) \
{ \
				   IFX_DBG_Log(ucModuleId,ucDbgLvl,unMsgId,__VA_ARGS__); \
}

//#define VDBG(s) IFX_VMAPI_DBG s
#define IFX_VMAPI_PRINT_NAMEVAL(pxNVList, unNo) \
												IFX_VMAPI_Print_NameVal(pxNVList, unNo)
#define IFX_VMAPI_ASSERT(a)  assert(a)

VOID IFX_VMAPI_DbgInit(
             IN char8 cDbgType,
             IN char8 cDbgLvl,
             OUT char8 *pcRet);
VOID IFX_VMAPI_DbgLvlSet(char8 cDbgType, char8 cDbgLvl);

#else
#define VDBG(s)
#define IFX_VMAPI_PRINT_NAMEVAL(pxNVList, unNo)
#define IFX_VMAPI_ASSERT(a)
#endif /* VMAPI_DBG_ENABLE */

#define IFX_VMAPI_SYSTEM_CMD(s)  system(s)

/**************************************/
#endif /* __LINUX__ */
/* @} */

/*************************************************************************/
#ifdef __cplusplus
}
#endif

#endif /* __IFX_VMAPI_PORT_H__ */
