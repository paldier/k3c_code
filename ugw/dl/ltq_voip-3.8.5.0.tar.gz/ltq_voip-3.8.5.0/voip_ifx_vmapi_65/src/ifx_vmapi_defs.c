/********************************************************************************

    Copyright (c) 2014
	LANTIQ DEUTSCHLAND GMBH
    Lilienthalstrasse 15, 85579 Neubiberg, Germany
    For licensing information, see the file 'LICENSE' in the root folder of
    this software module.

********************************************************************************/

#include "ifx_vmapi_genapi.h"
x_IFX_NAME_VALUE axoutbndifacenv[]={
						{"IFX_PSTN_NUM",0},
						{"IFX_VOIP_NUM",1},
						{"IFX_EXTN_NUM",2},
						{"IFX_DIRECT_IPNUM",3}
};

x_IFX_NAME_VALUE axtfreqoffsetnv[]={
                                                {"FREQ_OFF_EU",FREQ_OFF_EU},
                                                {"FREQ_OFF_LATIN",FREQ_OFF_LATIN},
                                                {"FREQ_OFF_US",FREQ_OFF_US}
};
x_IFX_NAME_VALUE axtfreqrangenv[]={
                                                {"FREQ_RANGE_EU",FREQ_RANGE_EU},
                                                {"FREQ_RANGE_LATIN",FREQ_RANGE_LATIN},
                                                {"FREQ_RANGE_US",FREQ_RANGE_US}
};


x_IFX_NAME_VALUE axtransmitpowernv[]={
                                                {"IFX_VMAPI_MCEI_FULLPOWERMODE",IFX_VMAPI_MCEI_FULLPOWERMODE},
                                                {"IFX_VMAPI_MCEI_FIVEDB",IFX_VMAPI_MCEI_FIVEDB},
                                                {"IFX_VMAPI_MCEI_TENDB",IFX_VMAPI_MCEI_TENDB},
						{"IFX_VMAPI_MCEI_FIFTEENDB",IFX_VMAPI_MCEI_FIFTEENDB},
						{"IFX_VMAPI_MCEI_TWENTYDB",IFX_VMAPI_MCEI_TWENTYDB},
						{"IFX_VMAPI_MCEI_TWENTYFIVEDB",IFX_VMAPI_MCEI_TWENTYFIVEDB},
						{"IFX_VMAPI_MCEI_THIRTYDB",IFX_VMAPI_MCEI_THIRTYDB},
						{"IFX_VMAPI_MCEI_MIN_POWERMODE",IFX_VMAPI_MCEI_MIN_POWERMODE},
						{"IFX_VMAPI_MCEI_USERMODE",IFX_VMAPI_MCEI_USERMODE}
};


x_IFX_NAME_VALUE axswpowermodenv[]={
                                                {"IFX_VMAPI_SW_POWERMODE_CONTANT",IFX_VMAPI_SW_POWERMODE_CONTANT},
                                                {"IFX_VMAPI_SW_POWERMODE_ADAPTIVE",IFX_VMAPI_SW_POWERMODE_ADAPTIVE},
                                                {"IFX_VMAPI_SW_POWERMODE_USER",IFX_VMAPI_SW_POWERMODE_USER}
};

x_IFX_NAME_VALUE axdtmfmethodnv[]={
						{"InBand",IFX_VMAPI_VP_DTMF_MTHD_INBAND},
						{"RFC2833",IFX_VMAPI_VP_DTMF_MTHD_RFC2833},
						{"SIPInfo",IFX_VMAPI_VP_DTMF_MTHD_INFO}
};


x_IFX_NAME_VALUE axtransportnv[] ={
						{"AUTO",IFX_VMAPI_SIG_TRANSPORT_AUTO},
						{"UDP",IFX_VMAPI_SIG_TRANSPORT_UDP},
						{"TCP",IFX_VMAPI_SIG_TRANSPORT_TCP},
						{"TLS",IFX_VMAPI_SIG_TRANSPORT_TLS},
						{"SCTP",IFX_VMAPI_SIG_TRANSPORT_SCTP}
};

x_IFX_NAME_VALUE axlinestatusnv[] ={
						{"Up",IFX_VMAPI_VL_STATUS_UP},
						{"Initializing",IFX_VMAPI_VL_STATUS_INITIALISING},
						{"Registering",IFX_VMAPI_VL_STATUS_REGISTERING},
						{"Unregistering",IFX_VMAPI_VL_STATUS_UNREGISTERING},
						{"Error",IFX_VMAPI_VL_STATUS_ERROR},
						{"Testing",IFX_VMAPI_VL_STATUS_TESTING},
						{"Quiescent",IFX_VMAPI_VL_STATUS_QUIESCENT},
						{"Disabled",IFX_VMAPI_VL_STATUS_DISABLED}

};

x_IFX_NAME_VALUE axcallstatusnv [] ={
                                                {"Idle",IFX_VMAPI_CALL_STATUS_IDLE},
                                                {"Calling",IFX_VMAPI_CALL_STATUS_CALLING},
                                                {"Ringing",IFX_VMAPI_CALL_STATUS_RINGING},
                                                {"Connecting",IFX_VMAPI_CALL_STATUS_CONNECTING},
                                                {"Incall",IFX_VMAPI_CALL_STATUS_INCALL},
                                                {"Hold",IFX_VMAPI_CALL_STATUS_HOLD},
                                                {"Disconnecting",IFX_VMAPI_CALL_STATUS_DISCONNECTING}
};


x_IFX_NAME_VALUE axcallingfeatnv[] ={
						{"Disabled",IFX_VMAPI_CALL_STATUS_DISABLED},
						{"Idle",IFX_VMAPI_CALL_STATUS_IDLE},
						{"SecondaryRinging",IFX_VMAPI_CALL_STATUS_RINGING},
						{"SecondaryConnecting",IFX_VMAPI_CALL_STATUS_SEC_CONNECTING},
						{"SecondaryConnected",IFX_VMAPI_CALL_STATUS_SEC_CONNECTED},
						{"InConferenceCall",IFX_VMAPI_CALL_STATUS_IN_CONF}
};
#ifdef IIP
x_IFX_NAME_VALUE axmediasecnv[] ={
						{"Null",IFX_VMAPI_SRTP_KEYING_MTHD_NONE},
						{"Properitery",IFX_VMAPI_SRTP_KEYING_MTHD_PROPRIETARY},
						{"Static",IFX_VMAPI_SRTP_KEYING_MTHD_STATIC},
						{"SDP",IFX_VMAPI_SRTP_KEYING_MTHD_SDP},
						{"IKE",IFX_VMAPI_SRTP_KEYING_MTHD_IKE},
						{"MIKEY",IFX_VMAPI_SRTP_KEYING_MTHD_MIKEY}
};
#endif
x_IFX_NAME_VALUE axcodecnv[] ={
						{"G.711ALaw",IFX_VMAPI_CODEC_G711_ALAW},
						{"G.711MuLaw",IFX_VMAPI_CODEC_G711_ULAW},
						{"IFX_VMAPI_CODEC_G729_8",IFX_VMAPI_CODEC_G729_8},
						{"IFX_VMAPI_CODEC_G729_E",IFX_VMAPI_CODEC_G729_E},
						{"IFX_VMAPI_CODEC_G723",IFX_VMAPI_CODEC_G723},
						{"IFX_VMAPI_CODEC_G723_5_3",IFX_VMAPI_CODEC_G723_5_3},
						{"IFX_VMAPI_CODEC_G723_6_3",IFX_VMAPI_CODEC_G723_6_3},
						{"IFX_VMAPI_CODEC_G728",IFX_VMAPI_CODEC_G728},
						{"IFX_VMAPI_CODEC_LINEAR_256",IFX_VMAPI_CODEC_LINEAR_256},
						{"IFX_VMAPI_CODEC_LINEAR_16",IFX_VMAPI_CODEC_LINEAR_16},
						{"IFX_VMAPI_CODEC_LINEAR_8",IFX_VMAPI_CODEC_LINEAR_8},
						{"IFX_VMAPI_CODEC_G726_16",IFX_VMAPI_CODEC_G726_16},
						{"IFX_VMAPI_CODEC_G726_24",IFX_VMAPI_CODEC_G726_24},
						{"IFX_VMAPI_CODEC_G726_32",IFX_VMAPI_CODEC_G726_32},
						{"IFX_VMAPI_CODEC_G726_40",IFX_VMAPI_CODEC_G726_40},
						{"IFX_VMAPI_CODEC_G722_64",IFX_VMAPI_CODEC_G722_64},
						{"IFX_VMAPI_CODEC_G722_64_2",IFX_VMAPI_CODEC_G722_64_2},
						{"IFX_VMAPI_CODEC_ILBC",IFX_VMAPI_CODEC_ILBC},
						{"IFX_VMAPI_CODEC_T38",IFX_VMAPI_CODEC_T38},
						{"IFX_VMAPI_CODEC_T38_UDP",IFX_VMAPI_CODEC_T38_UDP},
						{"IFX_VMAPI_CODEC_T38_TCP",IFX_VMAPI_CODEC_T38_TCP}
};

x_IFX_Param x_IFX_VMAPI_VoiceService_param []= {
						{"VoiceProfileNumberOfEntries",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
							offsetof(x_IFX_VMAPI_VoiceService,uiNumProfiles)},
                                                {"X_VENDOR_COM_CountrySet",IFX_VMAPI_PARAM_TYPE_UINT,
                                                        offsetof(x_IFX_VMAPI_VoiceService,uiCountrySet)},
                                                {"X_VENDOR_COM_PhyNumOfEntries",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                        offsetof(x_IFX_VMAPI_VoiceService,uiPhyNumOfEntries)},
                                                {"X_VENDOR_COM_ProfileIdList",IFX_VMAPI_PARAM_TYPE_STR,
                                                        offsetof(x_IFX_VMAPI_VoiceService,ucProfileIdList)},
                                                {"X_VENDOR_COM_LineIdList",IFX_VMAPI_PARAM_TYPE_STR,
                                                        offsetof(x_IFX_VMAPI_VoiceService,ucLineIdList)},
                                                {"X_VENDOR_COM_DeviceList",IFX_VMAPI_PARAM_TYPE_STR,
                                                        offsetof(x_IFX_VMAPI_VoiceService,acDeviceList)},
                                                {"X_VENDOR_COM_StartFlag",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_VoiceService,ucStartFlag)}
					};

x_IFX_Param x_IFX_VMAPI_CodecDesc_param []= {
						{"EntryID",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_CodecDesc,uiCodecId)},
						{"Codec",IFX_VMAPI_PARAM_TYPE_STR,offsetof(x_IFX_VMAPI_CodecDesc,acCodecName)},
						{"BitRate",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_CodecDesc,uiBitRate)},
						{"PacketizationPeriod",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
							offsetof(x_IFX_VMAPI_CodecDesc,unCodecSuppFrameLen)},
						{"SilenceSuppression",IFX_VMAPI_PARAM_TYPE_CHAR,
							offsetof(x_IFX_VMAPI_CodecDesc,bSilenceSupp)},
						{"X_VENDOR_COM_PayloadType",IFX_VMAPI_PARAM_TYPE_UCHAR,offsetof(x_IFX_VMAPI_CodecDesc,ucPayloadType)},
						{"Enable",IFX_VMAPI_PARAM_TYPE_UCHAR,offsetof(x_IFX_VMAPI_CodecDesc,bEnable)},
					{"Priority",IFX_VMAPI_PARAM_TYPE_UCHAR,offsetof(x_IFX_VMAPI_CodecDesc,ucPriority)}
};





x_IFX_Param x_IFX_VMAPI_VoiceCodecCapabilities_param [] = {
						{"FwSuppCodecs",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_VoiceCodecCapabilities,uiFwSuppCodec)},
						{ "NumCodecs",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_VoiceCodecCapabilities,uiNumCodecs)},
						{"CodCapEntry",IFX_VMAPI_PARAM_TYPE_OBJ_LIST,offsetof(x_IFX_VMAPI_VoiceCodecCapabilities,pxCodecList)}
};

x_IFX_Param x_IFX_VMAPI_VoiceCapabilities_param[] = {
						{"SuppCountries",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_VoiceCapabilities ,uiSuppCountries )}	
};

x_IFX_Param x_IFX_VMAPI_VoiceServPhyIf_param[] = {
						{"PhyPort",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_VoiceServPhyIf,ucPhyPortNum)},
					    {"X_VENDOR_COM_PortType",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_VoiceServPhyIf,ucPortType)},
						{"X_VENDOR_COM_Status",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_VoiceServPhyIf,ucStatus)},
						{"InterfaceID",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_VoiceServPhyIf,ucInterfaceId)},
						{"Description",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_VoiceServPhyIf,acIfDesc)}
};
x_IFX_Param x_IFX_VMAPI_FxoPhyIf_param [] = {
						{"X_VENDOR_COM_EnableEchoCancel",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,bEnableEchoCancel)},
						{"X_VENDOR_COM_EndPtId",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,ucEndPtId)},
						{"X_VENDOR_COM_VoiceLineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,ucVoiceLineId)},
						{"X_VENDOR_COM_PhyPortNum",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxoPhyIf, xVoiceServPhyIf.ucPhyPortNum)},
                                                {"X_VENDOR_COM_PortType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_FxoPhyIf, xVoiceServPhyIf.ucPortType)},
                                                {"X_VENDOR_COM_Status",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_FxoPhyIf, xVoiceServPhyIf.ucStatus)},
                                                {"X_VENDOR_COM_InterfaceId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_FxoPhyIf, xVoiceServPhyIf.ucInterfaceId)},
                                                {"X_VENDOR_COM_Description",IFX_VMAPI_PARAM_TYPE_STR,
                                                        offsetof(x_IFX_VMAPI_FxoPhyIf, xVoiceServPhyIf.acIfDesc)},
						{"X_VENDOR_COM_InterfaceIdList",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,ucInterfaceIdList)},
						{"X_VENDOR_COM_SmsScNumber",IFX_VMAPI_PARAM_TYPE_STR,
                                                        offsetof(x_IFX_VMAPI_FxoPhyIf,uacSmsScNumber)},
						{"X_VENDOR_COM_GatewayMode",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_FxoPhyIf,ucGatewayMode)},
						{"X_VENDOR_COM_CallFwdNoAnswer",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,uacCallFwdNoAnswer)},
						{"X_VENDOR_COM_ChannelString",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,acChannelString)},
						{"X_VENDOR_COM_State",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,ucState)},
						{"X_VENDOR_COM_Name",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,acName)},
						{"X_VENDOR_COM_LineMode",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,ucLineMode)},
					        {"X_VENDOR_COM_Intrusion",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxoPhyIf,ucIntrusion)}

};

x_IFX_Param x_IFX_VMAPI_FxsPhyIf_param [] = {
						{"X_VENDOR_COM_EnableEchoCancel",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxsPhyIf,bEnableEchoCancel)},
						{"X_VENDOR_COM_EndPtId",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_FxsPhyIf,ucEndPtId)},
						{"X_VENDOR_COM_VoiceLineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxsPhyIf,ucVoiceLineId)},
						{"X_VENDOR_COM_ChannelString",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_FxsPhyIf,acChannelString)},
                                                {"X_VENDOR_COM_PhyPortNum",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_FxsPhyIf, xVoiceServPhyIf.ucPhyPortNum)},
                                                {"X_VENDOR_COM_PortType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_FxsPhyIf, xVoiceServPhyIf.ucPortType)},
                                                {"X_VENDOR_COM_Status",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_FxsPhyIf, xVoiceServPhyIf.ucStatus)},
                                                {"X_VENDOR_COM_InterfaceId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_FxsPhyIf, xVoiceServPhyIf.ucInterfaceId)},
                                                {"X_VENDOR_COM_Description",IFX_VMAPI_PARAM_TYPE_STR,
                                                        offsetof(x_IFX_VMAPI_FxsPhyIf, xVoiceServPhyIf.acIfDesc)},
						{"X_VENDOR_COM_SmsCapable",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxsPhyIf,bSmsCapable)},
						{"X_VENDOR_COM_WideBandCapable",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_FxsPhyIf,bWideBandCapable)},
						{"X_VENDOR_COM_VoiceLineIdList",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_FxsPhyIf,ucVoiceLineIdList)}
};
x_IFX_Param x_IFX_VMAPI_DectHandset_param [] = {
						{"X_VENDOR_COM_Status",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,acStatus)},
						{"X_VENDOR_COM_IPEI",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,acIPEI)},
						{"X_VENDOR_COM_SubscriptionTime",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,acSubscriptionTime)},
						{"X_VENDOR_COM_ChannelString",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,acChannelString)},
						{"X_VENDOR_COM_SmsCapable",IFX_VMAPI_PARAM_TYPE_CHAR,
								offsetof(x_IFX_VMAPI_DectHandset,bSmsCapable)},
						{"X_VENDOR_COM_WideBandCapable",IFX_VMAPI_PARAM_TYPE_CHAR,
								offsetof(x_IFX_VMAPI_DectHandset,bWideBandCapable)},
                                                {"X_VENDOR_COM_IsRegistered",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectHandset,xSubsInfo.bIsRegistered)},
                                                {"X_VENDOR_COM_IPUI",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,xSubsInfo.aucIPUI)},
                                                {"X_VENDOR_COM_TPUI",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,xSubsInfo.aucTPUI)},
                                        	{"X_VENDOR_COM_AuthKey",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,xSubsInfo.aucAuthKey)},
                                                {"X_VENDOR_COM_CipherKey",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,xSubsInfo.aucCipherKey)},
                                                {"X_VENDOR_COM_ServiceClass",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectHandset,xSubsInfo.ucServiceClass)},
                                                {"X_VENDOR_COM_ModelId",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectHandset,xSubsInfo.ucModelId)},
                                                {"X_VENDOR_COM_TermCapab",IFX_VMAPI_PARAM_TYPE_UINT,
								offsetof(x_IFX_VMAPI_DectHandset,xSubsInfo.uiTermCapab)},
                                                {"X_VENDOR_COM_PhyPortNum",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_DectHandset,xVoiceServPhyIf.ucPhyPortNum)},
                                                {"X_VENDOR_COM_PortType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_DectHandset,xVoiceServPhyIf.ucPortType)},
                                                {"X_VENDOR_COM_Status",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_DectHandset,xVoiceServPhyIf.ucStatus)},
                                                {"X_VENDOR_COM_InterfaceId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_DectHandset,xVoiceServPhyIf.ucInterfaceId)},
                                                {"X_VENDOR_COM_Description",IFX_VMAPI_PARAM_TYPE_STR,
                                                        offsetof(x_IFX_VMAPI_DectHandset,xVoiceServPhyIf.acIfDesc)},
						{"X_VENDOR_COM_EndPtId",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,ucEndPtId)},
						{"X_VENDOR_COM_EndPtName",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,ucEndPtName)},
						{"X_VENDOR_COM_Intercept",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectHandset,bIntercept)},
						{"X_VENDOR_COM_VoiceLineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectHandset,ucVoiceLineId)},
						{"X_VENDOR_COM_VoiceLineIdList",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectHandset,aucVoiceLineIdList)}

};
#ifdef DECT_REPEATER
x_IFX_Param x_IFX_VMAPI_DectSubsInfo_param [] = {
                                                {"X_VENDOR_COM_IsRegistered",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                offsetof(x_IFX_VMAPI_DectSubsInfo,bIsRegistered)},
                                                {"X_VENDOR_COM_IPUI",IFX_VMAPI_PARAM_TYPE_STR,
                                                                offsetof(x_IFX_VMAPI_DectSubsInfo,aucIPUI)},
                                                {"X_VENDOR_COM_TPUI",IFX_VMAPI_PARAM_TYPE_STR,
                                                                offsetof(x_IFX_VMAPI_DectSubsInfo,aucTPUI)},
                                                {"X_VENDOR_COM_AuthKey",IFX_VMAPI_PARAM_TYPE_STR,
                                                                offsetof(x_IFX_VMAPI_DectSubsInfo,aucAuthKey)},
                                                {"X_VENDOR_COM_CipherKey",IFX_VMAPI_PARAM_TYPE_STR,
                                                                offsetof(x_IFX_VMAPI_DectSubsInfo,aucCipherKey)},
                                                {"X_VENDOR_COM_ServiceClass",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                offsetof(x_IFX_VMAPI_DectSubsInfo,ucServiceClass)},
                                                {"X_VENDOR_COM_ModelId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                offsetof(x_IFX_VMAPI_DectSubsInfo,ucModelId)},
                                                {"X_VENDOR_COM_TermCapab",IFX_VMAPI_PARAM_TYPE_UINT,
                                                                offsetof(x_IFX_VMAPI_DectSubsInfo,uiTermCapab)}
};
x_IFX_Param x_IFX_VMAPI_DectRepeater_param [] = {
                        {"X_VENDOR_COM_IPEI",IFX_VMAPI_PARAM_TYPE_STR,
                                offsetof(x_IFX_VMAPI_DectRepeater,acIPEI)},
                        {"X_VENDOR_COM_SubscriptionTime",IFX_VMAPI_PARAM_TYPE_STR,
                                offsetof(x_IFX_VMAPI_DectRepeater,acSubscriptionTime)},
                        {"X_VENDOR_COM_EndPtId",IFX_VMAPI_PARAM_TYPE_STR,
                                offsetof(x_IFX_VMAPI_DectRepeater,ucEndPtId)},
                        {"X_VENDOR_COM_EndPtName",IFX_VMAPI_PARAM_TYPE_STR,
                                offsetof(x_IFX_VMAPI_DectRepeater,ucEndPtName)}
};
#endif
x_IFX_Param x_IFX_VMAPI_DectCodecDesc_param [] = {
						   {"X_VENDOR_COM_CodecId",IFX_VMAPI_PARAM_TYPE_UINT,
								offsetof(x_IFX_VMAPI_DectCodecDesc,uiCodecId)},
						   {"X_VENDOR_COM_CodecName",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectCodecDesc,acCodecName)},
						   {"X_VENDOR_COM_CodecSuppFrameLen",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
								offsetof(x_IFX_VMAPI_DectCodecDesc,unCodecSuppFrameLen)}
};


x_IFX_Param x_IFX_VMAPI_DectSystem_param [] = {
						{"X_VENDOR_COM_NumberOfHandsets",IFX_VMAPI_PARAM_TYPE_UINT,
							        offsetof(x_IFX_VMAPI_DectSystem,uiNumberOfHandsets)},
						{"X_VENDOR_COM_WaitingSubscription",IFX_VMAPI_PARAM_TYPE_CHAR,
								offsetof(x_IFX_VMAPI_DectSystem,bWaitingSubscription)},
						{"X_VENDOR_COM_AuthCode",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectSystem,acAuthCode)},
						{"X_VENDOR_COM_DeviceString",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectSystem,acDeviceString)},
						{"X_VENDOR_COM_EncrytionEnable",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucEncrytionEnable)},
						{"X_VENDOR_COM_DnaEnable",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucDnaEnable)},
						{"X_VENDOR_COM_ClkMaster",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucClkMaster)},
						{"X_VENDOR_COM_NoEmo",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucNoEmo)},
					        {"X_VENDOR_COM_RfEnable",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucRfEnable)},
					        {"X_VENDOR_COM_BaseName",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_DectSystem,acBaseName)},
						{"X_VENDOR_COM_DectNumCodecs",IFX_VMAPI_PARAM_TYPE_UINT,
								offsetof(x_IFX_VMAPI_DectSystem,uiDectNumCodecs)}
#ifdef DECT_REPEATER
						,
						{"X_VENDOR_COM_EARLY_ENCRYPTION",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucEarlyEncrytion)},
						{"X_VENDOR_COM_CYCLIC_REKEYING",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucReKeying)},
						{"X_VENDOR_COM_ULE",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucUleSupport)},
						{"X_VENDOR_COM_REPEATER",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucRepeaterSupp)},
						{"X_VENDOR_COM_JDECT",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucJDECTSupp)},
						{"X_VENDOR_COM_REAL_CARRIER_NUMBER",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_DectSystem,ucRealCN)}
#endif
};


/*******************************************************************/
/********************** Call Block **************************/

x_IFX_Param x_IFX_VMAPI_CallBlockEntry_param [] = {
					    {"X_VENDOR_COM_CallBlockNum",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_CallBlockEntry,acCallBlockNum)}
};

x_IFX_Param x_IFX_VMAPI_CallBlock_param [] ={
						{"X_VENDOR_COM_CallBar",IFX_VMAPI_PARAM_TYPE_CHAR,
								offsetof(x_IFX_VMAPI_CallBlock,bCallBar)},
						{"X_VENDOR_COM_NumCallBlockEntries",IFX_VMAPI_PARAM_TYPE_UINT,
								offsetof(x_IFX_VMAPI_CallBlock,uiNumCallBlockEntries)}
};

/*******************************************************************/
/********************** Address Book Entry**************************/

x_IFX_Param x_IFX_VMAPI_AddressBookEntry_param [] = {
						{"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_AddressBookEntry,ucLineId)},
						{"X_VENDOR_COM_DialCode",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_AddressBookEntry,acDialCode)},
						{"X_VENDOR_COM_CallType",IFX_VMAPI_PARAM_TYPE_UINT,
							offsetof(x_IFX_VMAPI_AddressBookEntry,eCallType)},
						{"X_VENDOR_COM_EntryId",IFX_VMAPI_PARAM_TYPE_UINT,
							offsetof(x_IFX_VMAPI_AddressBookEntry,uiEntryId)},
						{"X_VENDOR_COM_Index",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_AddressBookEntry,ucIndex)},
                                                {"X_VENDOR_COM_AddrType",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_AddressBookEntry,xAddress.ucAddrType)},
                                                {"X_VENDOR_COM_DisplayName",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_AddressBookEntry,xAddress.acDisplayName)},
                                                 {"X_VENDOR_COM_UserName",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_AddressBookEntry,xAddress.acUserName)},
                                                 {"X_VENDOR_COM_DestAddr",IFX_VMAPI_PARAM_TYPE_STR,
							offsetof(x_IFX_VMAPI_AddressBookEntry,xAddress.acDestAddr)},
                                                 {"X_VENDOR_COM_Port",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
							offsetof(x_IFX_VMAPI_AddressBookEntry,xAddress.unPort)},
                                                 {"X_VENDOR_COM_AddrProto",IFX_VMAPI_PARAM_TYPE_UCHAR,
							offsetof(x_IFX_VMAPI_AddressBookEntry,xAddress.ucAddrProto)}

};

x_IFX_Param x_IFX_VMAPI_AddressBook_param [] = {
						{"X_VENDOR_COM_NoOfAddBookEntries",IFX_VMAPI_PARAM_TYPE_UINT,
								offsetof(x_IFX_VMAPI_AddressBook,ucNoOfAddBookEntries)}
};


/***********************************************************/
/***************Tone related object****************/

x_IFX_Param x_IFX_VMAPI_ToneInfo_param [] = {
						{"ToneID",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_ToneInfo,uiToneId)},
						{"Function",IFX_VMAPI_PARAM_TYPE_STR,offsetof(x_IFX_VMAPI_ToneInfo,acToneName)},
						{"ToneEnable",IFX_VMAPI_PARAM_TYPE_UCHAR,offsetof(x_IFX_VMAPI_ToneInfo,bEnableTone)},
						{"ToneOn",IFX_VMAPI_PARAM_TYPE_UCHAR,offsetof(x_IFX_VMAPI_ToneInfo,bOn)},
						{"Frequency1",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unF1)},
						{"Frequency2",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unF2)},
						{"Frequency3",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unF3)},
						{"Frequency4",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unF4)},
						{"ModulationFrequency",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unModFreq)},
						{"Power1",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unG1)},
						{"Power2",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unG2)},
						{"Power3",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unG3)},
						{"Power4",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unG4)},
						{"ModulationPower",IFX_VMAPI_PARAM_TYPE_USHORT_INT,offsetof(x_IFX_VMAPI_ToneInfo,unModGain)},
						{"Duration",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_ToneInfo,uiDuration)}
};

x_IFX_Param x_IFX_VMAPI_ToneTable_param [] = {
						{"PatternNumberOfEntries	",IFX_VMAPI_PARAM_TYPE_UCHAR,offsetof(x_IFX_VMAPI_ToneTable,ucNoOfTones)},
						{" ",IFX_VMAPI_PARAM_TYPE_OBJ_LIST,offsetof(x_IFX_VMAPI_ToneTable,axToneInfo)}
};



/***********************************************************/
/***************Miscellaneous Information *********************/
x_IFX_Param x_IFX_VMAPI_Misc_param [] = {
					 	{"X_VENDOR_COM_AcceptUnSolNotify",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_Misc,bAcceptUnSolNotify)},
						{"X_VENDOR_COM_EnableUDPRedir",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_Misc,bEnableUDPRedir)},
						{"X_VENDOR_COM_SmsScNumber",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_Misc,uacSmsScNumber)},
						{"X_VENDOR_COM_RestoreFactorySettings",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_Misc,bRestoreFactorySettings)},
						{"X_VENDOR_COM_defaultFaxIface",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_Misc,defaultFaxIface)},
						{"X_VENDOR_COM_defaultOutbndIface",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_Misc,defaultOutbndIface)},
						{"X_VENDOR_COM_DialToneDuration",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_Misc,ucDialToneDuration)},
						{"X_VENDOR_COM_SilenceSupp",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_Misc,bSilenceSupp)},
						{"X_VENDOR_COM_SessExpires",IFX_VMAPI_PARAM_TYPE_UINT,
								offsetof(x_IFX_VMAPI_Misc,uiSessExpires)},
						{"X_VENDOR_COM_FxoEnable",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_Misc,ucFxoEnable)}

};

///use correct name and #define

/***********************************************************/
/*************** T.38 *********************/
x_IFX_Param x_IFX_VMAPI_T38Cfg_param [] = {
						{"X_VENDOR_COM_OldAsn1",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_T38Cfg,ucOldAsn1)},
						{"X_VENDOR_COM_NsxSize",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_T38Cfg,ucNsxSize)},
						{"X_VENDOR_COM_NsxInfoField",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_T38Cfg,ucNsxInfoField)},
						{"X_VENDOR_COM_DataWaitTime",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_T38Cfg,ucDataWaitTime)},
						{"X_VENDOR_COM_UdpHighRateErrRecPkts",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
								offsetof(x_IFX_VMAPI_T38Cfg,unUdpHRErrRecPkts)},
						{"X_VENDOR_COM_UdpLowRateErrRecPkts",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
								offsetof(x_IFX_VMAPI_T38Cfg,unUdpLRErrRecPkts)},
						{"X_VENDOR_COM_UdpPriorFecPkts",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
								offsetof(x_IFX_VMAPI_T38Cfg,unUdpPriorFecPkts)},
						{"X_VENDOR_COM_FrameLength",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
								offsetof(x_IFX_VMAPI_T38Cfg,unFrameLength)},
						{"X_VENDOR_COM_T38Connection",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_T38Cfg,ucT38Conn)}
};

/***********************************************************/
/*************** GR909 Test *********************///Structure not found
x_IFX_Param x_IFX_VMAPI_GR909_param [] = {
						{" ",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_GR909,uiHighResist)},
						{"",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_GR909,uiHighResist)},
						{"",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_GR909,uiHighResist)},
						{"",IFX_VMAPI_PARAM_TYPE_UINT,offsetof(x_IFX_VMAPI_GR909,uiHighResist)},
						{"",IFX_VMAPI_PARAM_TYPE_UCHAR,offsetof(x_IFX_VMAPI_GR909,uiHighResist)},

};


/***********************************************************/
/*************** Version Information *********************/

x_IFX_Param x_IFX_VMAPI_SystemVersionRegister_param [] = {
							  {"X_VENDOR_COM_FirmwareVersion",IFX_VMAPI_PARAM_TYPE_STR,
								offsetof(x_IFX_VMAPI_SystemVersionRegister,acFirmwareVer)},
#ifdef IIP
							  {"X_VENDOR_COM_HapiVersion",IFX_VMAPI_PARAM_TYPE_STR,
									offsetof(x_IFX_VMAPI_SystemVersionRegister,acHapiVer)},
							  {"X_VENDOR_COM_JBVersion",IFX_VMAPI_PARAM_TYPE_STR,
									offsetof(x_IFX_VMAPI_SystemVersionRegister,acJBVer)},
						          {"X_VENDOR_COM_ChipVersion",IFX_VMAPI_PARAM_TYPE_STR,
									offsetof(x_IFX_VMAPI_SystemVersionRegister,acChipVer)},
#endif /*IIP*/
							  {"X_VENDOR_COM_DriverVersion",IFX_VMAPI_PARAM_TYPE_STR,
									offsetof(x_IFX_VMAPI_SystemVersionRegister,acDrvVer)},
							  {"X_VENDOR_COM_VoipApplicationVersion",IFX_VMAPI_PARAM_TYPE_STR,
									offsetof(x_IFX_VMAPI_SystemVersionRegister,acAppVer)},
							  {"X_VENDOR_COM_RTPVersion",IFX_VMAPI_PARAM_TYPE_STR,
									offsetof(x_IFX_VMAPI_SystemVersionRegister,acRtpVer)},
							  {"X_VENDOR_COM_CMVersion",IFX_VMAPI_PARAM_TYPE_STR,
									offsetof(x_IFX_VMAPI_SystemVersionRegister,acCmVer)},
							  {"X_VENDOR_COM_SIPVersion",IFX_VMAPI_PARAM_TYPE_STR,
									offsetof(x_IFX_VMAPI_SystemVersionRegister,acSipVer)},
#ifndef IIP
							  {"X_VENDOR_COM_FaxVersion",IFX_VMAPI_PARAM_TYPE_STR,
									offsetof(x_IFX_VMAPI_SystemVersionRegister,acFaxVer)}
#endif /* ATA */
};

/***********************************************************/
/*************** Debug Information *********************/
x_IFX_Param x_IFX_VMAPI_DbgType_param [] = {
						{"X_VENDOR_COM_DbgLvl",IFX_VMAPI_PARAM_TYPE_UCHAR,offsetof(x_IFX_VMAPI_DbgType,ucDbgLvl)},
						{"X_VENDOR_COM_DbgType",IFX_VMAPI_PARAM_TYPE_UCHAR,offsetof(x_IFX_VMAPI_DbgType,ucDbgType)}
};

x_IFX_Param x_IFX_VMAPI_SystemDebugSettings_param [] = {
						       	      {"X_VENDOR_COM_CallManagerDebugLevel",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_SystemDebugSettings,xCmDbg.ucDbgLvl)},
							      {"X_VENDOR_COM_CallManagerDebugType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                offsetof(x_IFX_VMAPI_SystemDebugSettings,xCmDbg.ucDbgType)},
							      {"X_VENDOR_COM_MediaManagerDebugLevel",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_SystemDebugSettings,xMmDbg.ucDbgLvl)},
							      {"X_VENDOR_COM_MediaManagerDebugType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                offsetof(x_IFX_VMAPI_SystemDebugSettings,xMmDbg.ucDbgType)},
							      {"X_VENDOR_COM_AgentsDebugLevel",IFX_VMAPI_PARAM_TYPE_UCHAR,
								offsetof(x_IFX_VMAPI_SystemDebugSettings,xAgentsDbg.ucDbgLvl)},
							      {"X_VENDOR_COM_AgentsDebugType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                offsetof(x_IFX_VMAPI_SystemDebugSettings,xAgentsDbg.ucDbgType)},
							      {"X_VENDOR_COM_RtpDebugLevel",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_SystemDebugSettings,xRtpDbg.ucDbgLvl)},
							      {"X_VENDOR_COM_RtpDebugType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_SystemDebugSettings,xRtpDbg.ucDbgType)},
							      {"X_VENDOR_COM_CMDebugType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_SystemDebugSettings,xVmapiDbg.ucDbgType)},
							      {"X_VENDOR_COM_CMDebugLevel",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_SystemDebugSettings,xVmapiDbg.ucDbgLvl)},
							      {"X_VENDOR_COM_SIPDebugLevel",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_SystemDebugSettings,xSipDbg.ucDbgLvl)},
							      {"X_VENDOR_COM_SIPDebugType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_SystemDebugSettings,xSipDbg.ucDbgType)},
#ifndef IIP
							      {"X_VENDOR_COM_FaxDebugLevel",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_SystemDebugSettings,xFaxDbg.ucDbgLvl)},
							      {"X_VENDOR_COM_FaxDebugType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_SystemDebugSettings,xFaxDbg.ucDbgType)}

#endif /*ATA*/

};
/*******************************************************************/
/**********************   PhysicalInterfaceTest ********************/

x_IFX_Param x_IFX_VMAPI_VoiceServPhyIfTest_param [] = {
                                                        {"X_VENDOR_COM_PhyPortNum",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceServPhyIfTest,ucPhyPortNum)},
                                                        {"X_VENDOR_COM_PortType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceServPhyIfTest,ucPortType)},
                                                        {"X_VENDOR_COM_InterfaceId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceServPhyIfTest,ucInterfaceId)},
                                                        {"X_VENDOR_COM_TestType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceServPhyIfTest,ucTestType)},
                                                        {"X_VENDOR_COM_TestState",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceServPhyIfTest,ucTestState)}


};

x_IFX_Param x_IFX_VMAPI_VoiceServTestResult_param [] = {
                                                        {"X_VENDOR_COM_PortType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceServTestResult,ucPortType)},
                                                        {"X_VENDOR_COM_InterfaceId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceServTestResult,ucInterfaceId)},
                                                        {"X_VENDOR_COM_TestType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                            offsetof(x_IFX_VMAPI_VoiceServTestResult,ucTestType)},
                                                        {"X_VENDOR_COM_FEMFResult",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909FEMFVoltResult.ucResult)},
                                                        {"X_VENDOR_COM_FEMFACringwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909FEMFVoltResult.facr2g)},
                                                        {"X_VENDOR_COM_FEMFACtipwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909FEMFVoltResult.fact2g)},
                                                        {"X_VENDOR_COM_FEMFACtipwiretoringwire",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909FEMFVoltResult.fact2r)},
                                                        {"X_VENDOR_COM_FEMFDCringwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909FEMFVoltResult.fdcr2g)},
                                                        {"X_VENDOR_COM_FEMFDCtipwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909FEMFVoltResult.fdct2g)},
                                                        {"X_VENDOR_COM_FEMFDCtipwiretoringwire",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909FEMFVoltResult.fdct2r)},

                                                        {"X_VENDOR_COM_HPTResult",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909HPTVoltResult.ucResult)},
                                                        {"X_VENDOR_COM_HPTACringwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909HPTVoltResult.facr2g)},
                                                        {"X_VENDOR_COM_HPTACtipwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909HPTVoltResult.fact2g)},
                                                        {"X_VENDOR_COM_HPTACtipwiretoringwire",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909HPTVoltResult.fact2r)},
                                                        {"X_VENDOR_COM_HPTDCringwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909HPTVoltResult.fdcr2g)},
                                                        {"X_VENDOR_COM_HPTDCtipwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909HPTVoltResult.fdct2g)},
                                                        {"X_VENDOR_COM_HPTDCtipwiretoringwire",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909HPTVoltResult.fdct2r)},

                                                        {"X_VENDOR_COM_RFTResult",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                            offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909RFTResult.ucResult)},
                                                        {"X_VENDOR_COM_RFTRingwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                              offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909RFTResult.fr2g)},
                                                        {"X_VENDOR_COM_RFTTipwiretoground",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909RFTResult.ft2g)},
                                                        {"X_VENDOR_COM_RFTTipwiretoringwire",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909RFTResult.ft2r)},
                                                        
							{"X_VENDOR_COM_RIResult",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909RIResult.ucResult)},
                                                        {"X_VENDOR_COM_RITvalue",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909RIResult.fRit)},
                                                        
							{"X_VENDOR_COM_ROHResult",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909ROHResult.ucResult)},
                                                        {"X_VENDOR_COM_ROHTipwiretoringwireresistance",IFX_VMAPI_PARAM_TYPE_FLOAT,
                                                        offsetof(x_IFX_VMAPI_VoiceServTestResult,xGr909ROHResult.ft2rl)}
};
/***********************************************************/
/***************Power Measurement related object****************/

x_IFX_Param x_IFX_VMAPI_TransmitPowerParam_param [] = {
                                                        {"X_VENDOR_COM_TuneDigitalRef",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTuneDigitalRef)},
                                                        {"X_VENDOR_COM_PABiasRef",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucPABiasRef)},
                                                        {"X_VENDOR_COM_PowerOffset0",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucPowerOffset0)},
                                                        {"X_VENDOR_COM_PowerOffset1",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucPowerOffset1)},
                                                        {"X_VENDOR_COM_X_VENDOR_COM_PowerOffset2",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucPowerOffset2)},
                                                        {"X_VENDOR_COM_PowerOffset3",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucPowerOffset3)},
                                                        {"X_VENDOR_COM_PowerOffset4",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucPowerOffset4)},
                                                        {"X_VENDOR_COM_TD1",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTD1)},
                                                        {"X_VENDOR_COM_TD2",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTD2)},
                                                        {"X_VENDOR_COM_TD3",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTD3)},
                                                        {"X_VENDOR_COM_PA1",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucPA1)},
                                                        {"X_VENDOR_COM_PA2",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucPA2)},
                                                        {"X_VENDOR_COM_PA3",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucPA3)},
                                                        {"X_VENDOR_COM_SWPowerMode",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucSWPowerMode)},
                                                        {"X_VENDOR_COM_TXPOW_0",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTXPOW_0)},
                                                        {"X_VENDOR_COM_TXPOW_1",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTXPOW_1)},
                                                        {"X_VENDOR_COM_TXPOW_2",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTXPOW_2)},
                                                        {"X_VENDOR_COM_TXPOW_3",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTXPOW_3)},
                                                        {"X_VENDOR_COM_TXPOW_4",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTXPOW_4)},
                                                        {"X_VENDOR_COM_TXPOW_5",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTXPOW_5)},
                                                        {"X_VENDOR_COM_DBPOW",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucDBPOW)},
                                                        {"X_VENDOR_COM_TuneDigital",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTuneDigital)},
                                                        {"X_VENDOR_COM_TxBias",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_TransmitPowerParam,ucTxBias)}
};
 
x_IFX_Param x_IFX_VMAPI_DectRfpi_param [] = {
						{"X_VENDOR_COM_Byte1",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectRfpi,ucByte1)},
                                                {"X_VENDOR_COM_Byte2",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectRfpi,ucByte2)},
                                                {"X_VENDOR_COM_Byte3",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectRfpi,ucByte3)},
                                                {"X_VENDOR_COM_Byte4",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectRfpi,ucByte4)},
                                                {"X_VENDOR_COM_Byte5",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectRfpi,ucByte5)},
                                                {"X_VENDOR_COM_Byte6",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectRfpi,ucByte6)}

};

x_IFX_Param x_IFX_VMAPI_DectXRAM_param [] = {
                                                {"X_VENDOR_COM_Byte1",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucByte1)},
                                                {"X_VENDOR_COM_Byte2",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucByte2)},
                                                {"X_VENDOR_COM_Byte3",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucByte3)},
                                                {"X_VENDOR_COM_Byte4",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucByte4)},
                                                {"X_VENDOR_COM_Byte5",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucByte5)},
                                                {"X_VENDOR_COM_Byte6",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucByte6)},
                                                {"X_VENDOR_COM_Byte7",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucByte7)},
                                                {"X_VENDOR_COM_Byte8",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucByte8)},
                                                {"X_VENDOR_COM_Byte9",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucByte9)},
                                                {"X_VENDOR_COM_Type",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectXRAM,ucType)}

};

x_IFX_Param x_IFX_VMAPI_DectBMCParams_param [] = {
                                                    {"X_VENDOR_COM_DectRSSIFreeLevel",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectRSSIFreeLevel)},
                                                    {"X_VENDOR_COM_DectRSSIBusyLevel",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectRSSIBusyLevel)},
                                                    {"X_VENDOR_COM_DectBearerChgLim",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectBearerChgLim)},
                                                    {"X_VENDOR_COM_DectDefaultAntenna",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectDefaultAntenna)},
                                                    {"X_VENDOR_COM_DectWOPNSF",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectWOPNSF)},
                                                    {"X_VENDOR_COM_DectWWSF",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectWWSF)},
                                                    {"X_VENDOR_COM_DectCNTUPCtrlReg",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectCNTUPCtrlReg)},
                                                    {"X_VENDOR_COM_DectDelayReg",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectDelayReg)},
                                                    {"X_VENDOR_COM_DectHandOverEvalper",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectHandOverEvalper)},
                                                    {"X_VENDOR_COM_DectSYNCMCtrlReg",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectSYNCMCtrlReg)},
                                                    {"X_VENDOR_COM_DectReserved_0",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectReserved_0)},
                                                    {"X_VENDOR_COM_DectReserved_1",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectReserved_1)},
                                                    {"X_VENDOR_COM_DectReserved_2",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectReserved_2)},
                                                    {"X_VENDOR_COM_DectReserved_3",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectReserved_3)},
                                                    {"X_VENDOR_COM_DectReserved_4",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectReserved_4)},
                                                    {"X_VENDOR_COM_DectReserved_5",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectBMCParams,ucDectReserved_5)}
};

x_IFX_Param x_IFX_VMAPI_DectOscTrimVal_param [] = {
                                                    {"X_VENDOR_COM_OSCTrimByteHighValue",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectOscTrimVal,ucDectOscTrimValHI)},
                                                    {"X_VENDOR_COM_OSCTrimByteLowValue",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectOscTrimVal,ucDectOscTrimValLOW)},
                                                    {"X_VENDOR_COM_P10Status",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectOscTrimVal,ucDectP10Status)}

};

x_IFX_Param x_IFX_VMAPI_DectGFSKVal_param [] = {
                                                    {"X_VENDOR_COM_GFSKByteHighValue",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectGFSKVal,ucDectGFSKHI)},
                                                    {"X_VENDOR_COM_GFSKByteLowValue",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                         offsetof(x_IFX_VMAPI_DectGFSKVal,ucDectGFSKLOW)}

};

x_IFX_Param x_IFX_VMAPI_DectCountrySettings_param [] = {
                                                         {"X_VENDOR_COM_FrequencyTxoffset",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_DectCountrySettings,ucFreqTxOffset)},
                                                         {"X_VENDOR_COM_FrequencyRxoffset",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_DectCountrySettings,ucFreqRxOffset)},
                                                         {"X_VENDOR_COM_FrequencyRange",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_DectCountrySettings,ucFreqRan)},
                                                         {"X_VENDOR_COM_Eci",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_DectCountrySettings,ucEci)},
                                                         {"X_VENDOR_COM_ChmaskHigh",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_DectCountrySettings,ucChmaskHigh)},
                                                         {"X_VENDOR_COM_ChmaskLow",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_DectCountrySettings,ucChmaskLow)}
};

x_IFX_Param x_IFX_VMAPI_RFMode_param [] = {
                                              {"X_VENDOR_COM_TxTestMode",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                   offsetof(x_IFX_VMAPI_RFMode,ucTxtestmode)},
                                              {"X_VENDOR_COM_Channel",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                   offsetof(x_IFX_VMAPI_RFMode,ucChannel)},
                                              {"X_VENDOR_COM_Slot",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                   offsetof(x_IFX_VMAPI_RFMode,ucSlot)}
};

/***********************************************************/
/***************Sensor related object****************/
#ifdef DECT_SENSORS_SUPPORT
x_IFX_Param x_LTQ_SensorAlaram_List_param [] = {
                                                 {"X_VENDOR_COM_SensorId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                      offsetof(x_LTQ_SensorAlaram_List,uiSensorId)},
                                                 {"X_VENDOR_COM_NoOfEntries",IFX_VMAPI_PARAM_TYPE_UINT,
                                                      offsetof(x_LTQ_SensorAlaram_List,ucNoOfEntries)}
};

x_IFX_Param x_LTQ_SensorAlaram_Entry_param [] = {
                                                 {"X_VENDOR_COM_EntryId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                      offsetof(x_LTQ_SensorAlaram_Entry,uiEntryId)},
                                                 {"X_VENDOR_COM_SensorId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                      offsetof(x_LTQ_SensorAlaram_Entry,uiSensorId)},
                                                 {"X_VENDOR_COM_Index",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                      offsetof(x_LTQ_SensorAlaram_Entry,ucIndex)},
                                                 {"X_VENDOR_COM_Message",IFX_VMAPI_PARAM_TYPE_STR,
                                                      offsetof(x_LTQ_SensorAlaram_Entry,xAlaram.acMessage)},
                                                 {"X_VENDOR_COM_AlaramTime",IFX_VMAPI_PARAM_TYPE_STR,
                                                      offsetof(x_LTQ_SensorAlaram_Entry,xAlaram.acAlaramTime)}
};

x_IFX_Param x_LTQ_SensorList_param [] = {
                                          {"X_VENDOR_COM_NoOfEntries",IFX_VMAPI_PARAM_TYPE_UINT,
                                             offsetof(x_LTQ_SensorList,ucNoOfEntries)},
                                          {"X_VENDOR_COM_PresetNum",IFX_VMAPI_PARAM_TYPE_STR,
                                             offsetof(x_LTQ_SensorList,ucPresetNum)},
                                          {"X_VENDOR_COM_AllPowerOn",IFX_VMAPI_PARAM_TYPE_CHAR,
                                             offsetof(x_LTQ_SensorList,bAllPowerOn)},
                                          {"X_VENDOR_COM_ToneAlaram",IFX_VMAPI_PARAM_TYPE_CHAR,
                                             offsetof(x_LTQ_SensorList,bToneAlaram)}
};
x_IFX_Param x_LTQ_SensorList_Entry_param [] =  {
                                              {"X_VENDOR_COM_EntryId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                offsetof(x_LTQ_SensorList_Entry,uiEntryId)},
                                              {"X_VENDOR_COM_Index",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                offsetof(x_LTQ_SensorList_Entry,ucIndex)},
                                              {"X_VENDOR_COM_BatteryLevel",IFX_VMAPI_PARAM_TYPE_UINT,
                                                offsetof(x_LTQ_SensorList_Entry,uiBatteryLevel)},
                                              {"X_VENDOR_COM_SensorName",IFX_VMAPI_PARAM_TYPE_STR,
                                                offsetof(x_LTQ_SensorList_Entry,xSensorInfo.acSensorName)},
                                              {"X_VENDOR_COM_Registrationstatus",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                offsetof(x_LTQ_SensorList_Entry,xSensorInfo.bRegStatus)},
                                              {"X_VENDOR_COM_Powerstatus",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                offsetof(x_LTQ_SensorList_Entry,xSensorInfo.bPowerStatus)},
                                              {"X_VENDOR_COM_ReadInterval",IFX_VMAPI_PARAM_TYPE_UINT,
                                                offsetof(x_LTQ_SensorList_Entry,xSensorInfo.uiInterval)}
};
 
x_IFX_Param x_LTQ_PowerSensorList_param [] = {
                                          {"X_VENDOR_COM_AllPowerOn",IFX_VMAPI_PARAM_TYPE_CHAR,
                                             offsetof(x_LTQ_PowerSensorList,bAllPowerOn)},
                                          {"X_VENDOR_COM_NoOfEntries",IFX_VMAPI_PARAM_TYPE_UINT,
                                             offsetof(x_LTQ_PowerSensorList,ucNoOfEntries)}
};

x_IFX_Param x_LTQ_PowerSensorEntry_param [] = {
                                                 {"X_VENDOR_COM_EntryId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                      offsetof(x_LTQ_PowerSensorEntry,uiEntryId)},
                                                 {"X_VENDOR_COM_Index",IFX_VMAPI_PARAM_TYPE_UINT,
                                                      offsetof(x_LTQ_PowerSensorEntry,ucIndex)},
                                                 {"X_VENDOR_COM_SensorName",IFX_VMAPI_PARAM_TYPE_STR,
                                                      offsetof(x_LTQ_PowerSensorEntry,xSensorInfo.acSensorName)},
                                                 {"X_VENDOR_COM_Registrationstatus",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                      offsetof(x_LTQ_PowerSensorEntry,xSensorInfo.bRegStatus)},
                                                 {"X_VENDOR_COM_Powerstatus",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                      offsetof(x_LTQ_PowerSensorEntry,xSensorInfo.bPowerStatus)},
                                                 {"X_VENDOR_COM_ReadInterval",IFX_VMAPI_PARAM_TYPE_UINT,
                                                      offsetof(x_LTQ_PowerSensorEntry,xSensorInfo.uiInterval)}
};

x_IFX_Param x_LTQ_PowerSensor_ReadList_param [] = {
                                                    {"X_VENDOR_COM_SensorId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadList,uiSensorId)},
                                                    {"X_VENDOR_COM_NoOfEntries",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadList,ucNoOfEntries)}
};
/*
x_IFX_Param x_LTQ_PowerSensor_Read_param [] = {
                                                    {"MeasureTime",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,acMeasureTime)},
                                                    {"Readparam1",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,uiParam1)},
                                                    {"Readparam2",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,uiParam2)},
                                                    {"Readparam3",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,uiParam3)}
};
*/
x_IFX_Param x_LTQ_PowerSensor_ReadEntry_param [] = {
                                                    {"X_VENDOR_COM_EntryId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,uiEntryId)},
                                                    {"X_VENDOR_COM_SensorId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,uiSensorId)},
                                                    {"X_VENDOR_COM_Index",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,ucIndex)},
                                                    {"X_VENDOR_COM_MeasureTime",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,xPowerRead.acMeasureTime)},
                                                    {"X_VENDOR_COM_Readparam1",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,xPowerRead.uiParam1)},
                                                    {"X_VENDOR_COM_Readparam2",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,xPowerRead.uiParam2)},
                                                    {"X_VENDOR_COM_Readparam3",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_LTQ_PowerSensor_ReadEntry,xPowerRead.uiParam3)}
};
#endif
/***********************************************************/
/***************Profile related object****************/


x_IFX_Param x_IFX_VMAPI_ProfileStunConfig_param [] = {
							{"Server",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_ProfileStunConfig,acStunServer)},
							{"Port",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                                 offsetof(x_IFX_VMAPI_ProfileStunConfig,unStunPort)},	
							{"Usr",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_ProfileStunConfig,acStunUserName)},
							{"Passwd",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_ProfileStunConfig,acStunPassword)},
							{"KeepAlive",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                                 offsetof(x_IFX_VMAPI_ProfileStunConfig,unNatKeepAliveTime)},
							{"NatType",IFX_VMAPI_PARAM_TYPE_INT,
                                                                 offsetof(x_IFX_VMAPI_ProfileStunConfig,iNatType)}
};
//Note : Profileid is missing

x_IFX_Param x_IFX_VMAPI_VoiceProfile_param [] = {
                                                        {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,ucProfileId)},
                                                        {"Name",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,acProfileName)},
                                                        {"X_VENDOR_COM_Country",IFX_VMAPI_PARAM_TYPE_UINT,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,uiAssocCountry)},
                                                        {"Enable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,ucState)},
                                                        {"Reset",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,bReset)},
                                                        {"NumberOfLines",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,ucNoOfLines)},
                                                        {"X_VENDOR_COM_LinesState",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,aucLines)},
                                                        {"X_VENDOR_COM_AssoLineIds",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,aucAssoLineIds)},
                                                        {"X_VENDOR_COM_DtmfPayloadType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,ucDtmfPayloadType)},
                                                        {"DTMFMethod",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,ucDtmfMethod)},
                                                        {"DTMFMethodG711",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,ucG711DtmfMethod)},
                                                        {"DigitMapEnable",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,bEnableDigitMap)},
                                                        {"X_VENDOR_COM_DigitMap",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,acDigitMap)},
                                                        {"STUNEnable",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,bEnableStun)},                                            
							                            {"STUNServer",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,xStunConfig.acStunServer)},
                                                        {"X_VENDOR_COM_StunPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,xStunConfig.unStunPort)},
                                                        {"X_VENDOR_COM_StunUserName",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,xStunConfig.acStunUserName)},
                                                        {"X_VENDOR_COM_StunPassword",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,xStunConfig.acStunPassword)},
                                                        {"X_VENDOR_COM_NatKeepAliveTime",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_VoiceProfile,xStunConfig.unNatKeepAliveTime)},
                                                        {"X_VENDOR_COM_NatType",IFX_VMAPI_PARAM_TYPE_INT,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,xStunConfig.iNatType)},
                                                        {"NonVoiceBandwidthReservedUpstream",IFX_VMAPI_PARAM_TYPE_UINT,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,uiDataResUpBandwidth)},
                                                        {"NonVoiceBandwidthReservedDownstream",IFX_VMAPI_PARAM_TYPE_UINT,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,uiDataResDownBandwidth)},
                                                        {"PSTNFailOver",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,bPstnFailOver)},
                                                        {"FaxPassThrough",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,bFaxPassThru)},
                                                        {"ModemPassThrough",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_VoiceProfile,bModemPassThru)}
};


/***********************************************************/
/******************Event Notification related Objects*******/
//Note:some fields are not available
x_IFX_Param x_IFX_VMAPI_EventSubscribe_param [] = {
												        {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                offsetof(x_IFX_VMAPI_EventSubscribe,ucProfileId)},
                                                        {"Event",IFX_VMAPI_PARAM_TYPE_UINT,
                                                                 offsetof(x_IFX_VMAPI_EventSubscribe,uiEvent)},
                                                        {"Notifier",IFX_VMAPI_PARAM_TYPE_STR,
                                                                 offsetof(x_IFX_VMAPI_EventSubscribe,acNotifierAddr)},
                                                        {"NotifierPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                                 offsetof(x_IFX_VMAPI_EventSubscribe,unNotifierPort)},
                                                        {"NotifierTransport",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_EventSubscribe,ucNotifierProtocol)},
                                                        {"ExpireTime",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                                 offsetof(x_IFX_VMAPI_EventSubscribe,unSubscriptionTime)}
};

//Note:some fields are not available
x_IFX_Param x_IFX_VMAPI_ProfileEventSubsTable_param [] = {
                                                        {"",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                 offsetof(x_IFX_VMAPI_ProfileEventSubsTable,ucProfileId)},
                                                        {"NoOfSubscr",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                               offsetof(x_IFX_VMAPI_ProfileEventSubsTable,ucNoOfSubscrElements)},
                                                        {"EventSubscribe",IFX_VMAPI_PARAM_TYPE_OBJ_LIST,
                                                               offsetof(x_IFX_VMAPI_ProfileEventSubsTable,pxEventSubscribe)}


};

/***********************************************************/
/******************Response Map Objects*********************/
//Note:struct not found
x_IFX_Param x_IFX_VMAPI_RspMap_param [] = {
                                                {"SIPResponseNumber",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                            offsetof(x_IFX_VMAPI_RspMap,unSipRspCode)},
                                                {"TextMessage",IFX_VMAPI_PARAM_TYPE_STR,
                                                            offsetof(x_IFX_VMAPI_RspMap,acMsg)},
                                                {"Tone",IFX_VMAPI_PARAM_TYPE_UINT,
                                                            offsetof(x_IFX_VMAPI_RspMap,uiTone)}
};

x_IFX_Param x_IFX_VMAPI_ProfileRspMapTable_param [] = {
                                                		{"",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                            		offsetof(x_IFX_VMAPI_ProfileRspMapTable,ucProfileId)},
                                                                {"",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                                  offsetof(x_IFX_VMAPI_ProfileRspMapTable,ucNoOfRspMapElements)},
                                                                {"SIPResponseNumber",IFX_VMAPI_PARAM_TYPE_OBJ_LIST,
                                                                   offsetof(x_IFX_VMAPI_ProfileRspMapTable,axRspMap)}


};

/***********************************************************/
/******************Service Provider related object**********/

x_IFX_Param x_IFX_VMAPI_ProfileServiceProviderInfo_param [] = {
                                                              {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileServiceProviderInfo,ucProfileId)},
                                                              {"Name",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileServiceProviderInfo,acName)},
                                                              {"URL",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileServiceProviderInfo,acUrl)},
                                                              {"ContactPhoneNumber",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileServiceProviderInfo,acPhone)},
                                                              {"EmailAddress",IFX_VMAPI_PARAM_TYPE_STR,
                                                             	offsetof(x_IFX_VMAPI_ProfileServiceProviderInfo,acEmail)}


};
x_IFX_Param x_IFX_VMAPI_ProfileSignaling_param [] = {
							{"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucProfileId)},
							{"X_VENDOR_COM_EnableProxy",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,bEnableProxy)},
                                                        {"X_VENDOR_COM_EnableRegistrar",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,bEnableRegistrar)},
                                                        {"ProxyServer",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,acProxyAddr)},
                                                        {"ProxyServerPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                             	offsetof(x_IFX_VMAPI_ProfileSignaling,unProxyPort)},
                                                        {"ProxyServerTransport",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucProxyProtocol)},
                                                        {"RegistrarServer",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,acRegistrarAddr)},
                                                        {"RegistrarServerPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unRegistrarPort)},
                                                        {"RegistrarServerTransport",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucRegistrarProtocol)},
                                                        {"X_VENDOR_COM_BackupRegAddr",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,acBackupRegAddr)},
                                                        {"X_VENDOR_COM_BackupRegPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unBackupRegPort)},
                                                        {"X_VENDOR_COM_BackupRegProtocol",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucBackupRegProtocol)},
                                                        {"RegistrationPeriod",IFX_VMAPI_PARAM_TYPE_UINT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,uiRegExpirationTime)},
                                                        {"RegisterRetryInterval",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unRegRetryTime)},
                                                        {"RegRetryAttempts",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucRegRetryAttempts)},
                                                        {"UserAgentDomain",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,acUADomain)},
                                                        {"X_VENDOR_COM_DnsQueryTimeOut",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unDnsQueryTimeOut)},
                                                        {"UserAgentPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unUAPort)},
                                                        {"UserAgentTransport",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucUAProtocol)},
                                                        {"OutboundProxy",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,acOutboundProxyAddr)},
                                                        {"OutboundProxyPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unOutboundProxyPort)},
                                                        {"X_VENDOR_COM_WellKnownSource",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,bWellKnownSource)},
                                                        {"Organization",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,acOrg)},
                                                        {"TimerT1",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unT1)},
                                                        {"TimerT2",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unT2)},
                                                        {"TimerT4",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unT4)},
                                                        {"TimerA",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTa)},
                                                        {"TimerB",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTb)},
                                                        {"TimerC",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTc)},
                                                        {"TimerD",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTd)},
                                                        {"TimerE",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTe)},
                                                        {"TimerF",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTf)},
                                                        {"TimerG",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTg)},
                                                        {"TimerH",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTh)},
                                                        {"TimerI",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTi)},
                                                        {"TimerJ",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTj)},
														{"TimerK",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unTk)},
                                                        {"InviteExpires",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unInvExpires)},
                                                        {"ReInviteExpires",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unReInvExpires)},
                                                        {"RegisterExpires",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unRegExpires)},
                                                        {"RegistersMinExpires",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,unRegMinExpires)},
                                                        {"InboundAuth",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucInboundAuth)},
                                                        {"InboundAuthUsername",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,acInbAuthUserName)},
                                                        {"InboundAuthPassword",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,acInbAuthPassword)},
                                                        {"X_VENDOR_COM_CohMethod",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucCohMethod)},
                                                        {"X_VENDOR_COM_UseCompactHdrs",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,bUseCompactHdrs)},
                                                        {"X_VENDOR_COM_UserAgentHdr",IFX_VMAPI_PARAM_TYPE_STR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,acUserAgentHdr)},
                                                        {"UseCodecPriorityInSDPResponse",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,bAnnounceMethod)},
                                                        {"DSCPMark",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucSipDscp)},
                                                        {"VLANIDMark",IFX_VMAPI_PARAM_TYPE_INT,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,iSipVlanId)},
                                                        {"EthernetPriorityMark",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileSignaling,ucSipEthPriority)}

};
x_IFX_Param x_IFX_VMAPI_ProfileMediaRTP_param [] = {
												  {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileMediaRTP,ucProfileId)},
                                                  {"LocalPortMin",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,unMinRtpPort)},
                                                  {"LocalPortMax",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,unMaxRtpPort)},
                                                  {"DSCPMark",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,ucRtpDscp)},
                                                  {"VLANIDMark",IFX_VMAPI_PARAM_TYPE_INT,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,iRtpVlanId)},
                                                  {"EthernetPriorityMark",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,ucRtpEthPriority)},
                                                  {"X_VENDOR_COM_JitterBufferType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,ucJbType)},
                                                  {"X_VENDOR_COM_MinFaxPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,unMinFaxPort)},
                                                  {"X_VENDOR_COM_MaxFaxPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,unMaxFaxPort)},
                                                  {"X_VENDOR_COM_ScalingFactor",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,ucScalingFactor)},
                                                  {"X_VENDOR_COM_InitialSize",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,unInitialSize)},
                                                  {"X_VENDOR_COM_MaxSize",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,unMaxSize)},
                                                  {"X_VENDOR_COM_MinSize",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTP,unMinSize)}
};
x_IFX_Param x_IFX_VMAPI_ProfileMediaRTCP_param [] = {
													    {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                              offsetof(x_IFX_VMAPI_ProfileMediaRTCP,ucProfileId)},
                                                        {"Enable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTCP,bEnableRtcp)},
                                                        {"TxRepeatInterval",IFX_VMAPI_PARAM_TYPE_UINT,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTCP,uiRtcpInterval)},
                                                        {"LocalCName",IFX_VMAPI_PARAM_TYPE_STR,
                                                        offsetof(x_IFX_VMAPI_ProfileMediaRTCP,acCName)}
};
#ifdef IIP
x_IFX_Param x_IFX_VMAPI_ProfileMediaSecurity_param [] = {
													   {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                             offsetof(x_IFX_VMAPI_ProfileMediaSecurity,ucProfileId)},
                                                       {"Enable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,bEnableSrtp)},
                                                       {"KeyingMethods",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,ucSrtpKeyingMethod)},
                                                       {"X_VENDOR_COM_X_VENDOR_COM_SrtpEncription",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,ucSrtpEnc)},
                                                       {"X_VENDOR_COM_SRTPAuthentication",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,ucSrtpAuth)},
                                                       {"X_VENDOR_COM_SRTPMasterKey",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,acSrtpMasterKey)},
                                                       {"X_VENDOR_COM_SRTPMasterSalt",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,acSrtpMasterSalt)},
                                                       {"X_VENDOR_COM_EnableSrtpMkiInd",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,bEnableSrtpMkiInd)},
                                                       {"X_VENDOR_COM_SRTPMkiLen",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,unSrtpMkiLen)},
                                                       {"X_VENDOR_COM_SRTCPEncription",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,ucSrtcpEnc)},
                                                       {"X_VENDOR_COM_SRTCPAuthentication",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,ucSrtcpAuth)},
                                                       {"X_VENDOR_COM_SRTCPMasterKey",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,acSrtcpMasterKey)},
                                                       {"X_VENDOR_COM_SRTCPMasterSalt",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,acSrtcpMasterSalt)},
                                                       {"X_VENDOR_COM_SRTCPMasterSalt",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,bEnableSrtcpMkiInd)},
                                                       {"X_VENDOR_COM_SRTCPMkiLen",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_ProfileMediaSecurity,unSrtcpMkiLen)}



};
#endif
x_IFX_Param x_IFX_VMAPI_NumPlan_param [] = {
                                               {"MinimumNumberOfDigits",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlan,ucNumPlanMinDigits)},
                                               {"MaximumNumberOfDigits",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlan,ucNumPlanMaxDigits)},
                                               {"InterDigitTimerStd",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlan,ucInterdigTimerStd)},
                                               {"InterDigitTimerOpen",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlan,ucInterdigTimerProg)},
                                               {"PrefixInfoNumberOfEntries",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_NumPlan,ucNoOfNumPlanRules)}
};

x_IFX_Param x_IFX_VMAPI_NumPlanRule_param [] = {
                                               {"FacilityAction",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,uiMainAct)},
                                               {"PrefixRange",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,acPrefix)},
                                               {"PrefixMinNumberOfDigits",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,ucMinDigits4Prefix)},
                                               {"PrefixMaxNumberOfDigits",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,ucMaxDigits4Prefix)},
                                               {"NumberOfDigitsToRemove",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,ucNoOfDigits2bRem)},
                                               {"PosOfDigitsToRemove",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,ucPosDigits2bRem)},
                                               {"X_VENDOR_COM_DigitsToInstert",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,cDigits2bIns)},
											   {"X_VENDOR_COM_PosOfDigitsToInstert",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,ucPosDigits2bIns)},
                                               {"X_VENDOR_COM_DigitsToRep",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,cDigits2bRep)},
                                               {"X_VENDOR_COM_PosOfDigitsToRep",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,ucPosDigits2bRep)},
                                               {"PrefixRange",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,uiDialTone)},
                                               {"FacilityActionArgument",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_NumPlanRule,acFacilityArg)}
};
x_IFX_Param x_IFX_VMAPI_FaxT38_param [] = {
											   {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                        offsetof(x_IFX_VMAPI_FaxT38,ucProfileId)},
                                               {"Enable",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_FaxT38,bEnableFax)},
											   {"X_VENDOR_COM_BitRateTcp",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_FaxT38,uiBitRateTcp)},
                                               {"BitRate",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_FaxT38,uiBitRateUdp)},
                                               {"HighSpeedPacketRate",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_FaxT38,uiHighSpeedPacketRate)},
                                               {"X_VENDOR_COM_TCFMethodTcp",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_FaxT38,ucTCFMethodTcp)},
                                               {"TCFMethod",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_FaxT38,ucTCFMethodUdp)},
                                               {"HighSpeedRedundancy",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_FaxT38,unUDPMaxBufferSize)},
                                               {"LowSpeedRedundancy",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_FaxT38,unUDPMaxDatagramSize)},
											   {"X_VENDOR_COM_UDPErrCorrection",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_FaxT38,ucUDPErrCorrection)},
};
x_IFX_Param x_IFX_VMAPI_VoiceLine_param [] = {
											   {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucProfileId)},
                                               {"DirectoryNumber",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,acDirName)},
                                               {"X_VENDOR_COM_Name",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,acName)},
                                               {"Enable",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucState)},
                                               {"Status",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucLineStatus)},
                                               {"CallState",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucCallStatus)},
                                               {"X_VENDOR_COM_GatewayMode",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucGatewayMode)},
                                               {"X_VENDOR_COM_LineMode",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucLineMode)},
                                               {"X_VENDOR_COM_Intrusion",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucIntrusion)},
#ifdef IIP
                                               {"RingMuteStatus",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,bEnableRingMute)},
                                               {"RingVolumeStatus",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucRingVolume)},
                                               {"X_VENDOR_COM_RoomType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucRoomType)},
                                               {"X_VENDOR_COM_VoiceVol",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucVoiceVol)},
#endif
                                               {"PhyReferenceList",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_VoiceLine,ucAssocVoiceInterface)}
};

x_IFX_Param x_IFX_VMAPI_LineSignaling_param [] = {
						    {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineSignaling,ucProfileId)},
					 	    {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineSignaling,ucLineId)},
						    {"X_VENDOR_COM_SipUserName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineSignaling,acSipUserName)},
                                                   {"X_VENDOR_COM_SipDispName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineSignaling,acSipDispName)}
};

x_IFX_Param x_IFX_VMAPI_SipAuthCfg_param [] = {
                                                   {"AuthUserName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_SipAuthCfg,acSipAuthUsrName)},
                                                   {"AuthPassword",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_SipAuthCfg,acSipAuthPasswd)}
};

x_IFX_Param x_IFX_VMAPI_LineSubscription_param [] = {
                                                   {"X_VENDOR_COM_MwiRetrieveUsrName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineSubscription,acMwiRetrieveUsrName)},
                                                   {"SIPEventSubscribeNumberOfElements",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineSubscription,ucNoOfLineEvents)},
                                                   {"",IFX_VMAPI_PARAM_TYPE_OBJ_LIST,
                                                       offsetof(x_IFX_VMAPI_LineSubscription,pxLineEvents)},
};
x_IFX_Param x_IFX_VMAPI_LineEvents_param [] = {
												   {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineEvents,ucProfileId)},
									               {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineEvents,ucLineId)},
                                                   {"Event",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineEvents,uiSubspnEvent)},
                                                   {"X_VENDOR_COM_SubspnState",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineEvents,ucSubspnState)},
                                                   {"AuthUserName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineEvents,acSubspnUsrName)},
                                                   {"AuthPassword",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineEvents,acSubspnPasswd)}
};

x_IFX_Param x_IFX_VMAPI_LineCallingFeatures_param [] = {
												   {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,ucProfileId)},
									               {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,ucLineId)},
                                                   {"CallerIDEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableCid)},
                                                   {"CallerIDNameEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableCidName)}, 
												   {"CallerIDName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,acCidName)},                                                   		    
												   {"CallWaitingEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableCallWaiting)},
												   {"CallWaitingStatus",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,ucCallWaitStatus)},
												   {"MaxSessions",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,ucMaxConfSessions)},
												   {"ConferenceCallingStatus",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,ucConfCallStatus)},
												   {"ConferenceCallingSessionCount",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,ucConfCallSessionCount)},  
													   
												   {"CallForwardUnconditionalEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,unCallFwdCfg)},
						                           {"CallForwardUnconditionalNumber",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfuAddress.acUserName)},
									               {"X_VENDOR_COM_CfuAddrType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfuAddress.ucAddrType)},
													{"X_VENDOR_COM_CfuDisplayName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfuAddress.acDisplayName)}, 
													{"X_VENDOR_COM_CfuDestAddr",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfuAddress.acDestAddr)},
													{"X_VENDOR_COM_CfuPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfuAddress.unPort)},
													{"X_VENDOR_COM_CfuAddrProto",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfuAddress.ucAddrProto)},
													   
												   {"CallForwardOnBusyNumber",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfbAddress.acUserName)},
									               {"X_VENDOR_COM_CfbAddrType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfbAddress.ucAddrType)},
													{"X_VENDOR_COM_CfbDisplayName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfbAddress.acDisplayName)}, 
													{"X_VENDOR_COM_CfbDestAddr",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfbAddress.acDestAddr)},
													{"X_VENDOR_COM_CfbPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfbAddress.unPort)},
													{"X_VENDOR_COM_CfbAddrProto",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfbAddress.ucAddrProto)},
													   
												   {"CallForwardOnNoAnswerNumber",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfnaAddress.acUserName)},
									               {"X_VENDOR_COM_CfnaAddrType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfnaAddress.ucAddrType)},
													{"X_VENDOR_COM_CfnaDisplayName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfnaAddress.acDisplayName)}, 
													{"X_VENDOR_COM_CfnaDestAddr",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfnaAddress.acDestAddr)},
													{"X_VENDOR_COM_CfnaPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfnaAddress.unPort)},
													{"X_VENDOR_COM_CfnaAddrProto",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xCfnaAddress.ucAddrProto)},
													
												   {"CallForwardOnNoAnswerRingCount",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,ucCfnaRingCount)},

												   {"X_VENDOR_COM_DndUserName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xDndAddress.acUserName)},
									               {"X_VENDOR_COM_DndAddrType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xDndAddress.ucAddrType)},
													{"X_VENDOR_COM_DndDisplayName",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xDndAddress.acDisplayName)}, 
													{"X_VENDOR_COM_DndDestAddr",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xDndAddress.acDestAddr)},
													{"X_VENDOR_COM_DndPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xDndAddress.unPort)},
													{"X_VENDOR_COM_DndAddrProto",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,xDndAddress.ucAddrProto)},
													   
												   {"CallTransferEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableCallTransfer)},
												   {"MWIEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableMwiIndication)},
												   {"MessageWaiting",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bIsMsgWaiting)},
												   {"AnonymousCallBlockEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableAcb)}, 
												   {"DoNotDisturbEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableDnd)},
												   {"CallReturnEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableCallRet)},
												   {"RepeatDialEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableRepeatDial)},
                                                   {"X_VENDOR_COM_FwdStatus",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bFwdStatus)},
#ifdef IIP
                                                   {"X_VENDOR_COM_ExtnDialFlag",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bExtnDialFlag)},
                                                   {"X_VENDOR_COM_PrefixDigit",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,unPrefixDigit)},
#endif
#ifdef DELAYED_HOTLINE
						                           {"X_VENDOR_COM_EnableDhl",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,bEnableDhl)},
                                                   {"X_VENDOR_COM_DhlNumber",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineCallingFeatures,acDhlNumber)}
#endif
};

x_IFX_Param x_IFX_VMAPI_LineVoiceProcessing_param [] = {
											           {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                          offsetof(x_IFX_VMAPI_LineVoiceProcessing,ucProfileId)},
									                   {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                          offsetof(x_IFX_VMAPI_LineVoiceProcessing,ucLineId)},
#ifndef IIP
                                                       {"EchoCancellationEnable",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineVoiceProcessing,bEnableEchoCancel)},
                                                       {"TransmitGain",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineVoiceProcessing,ucTxGain)},
                                                       {"ReceiveGain",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineVoiceProcessing,ucRxGain)},
                                                       {"EchoCancellationInUse",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineVoiceProcessing,bEchoCancelInUse)},
                                                       {"EchoCancellationTail",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineVoiceProcessing,ucEchoCancelTail)}
#endif
};
x_IFX_Param x_IFX_VMAPI_LineCodec_param [] = {
                                                       {"TransmitCodec",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineCodec,uiTxCodec)},
                                                       {"ReceiveCodec",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineCodec,uiRxCodec)},
                                                       {"TransmitBitRate",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_LineCodec,unTxBitRate)},
                                                       {"ReceiveBitRate",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_LineCodec,unRxBitRate)},
                                                       {"TransmitSilenceSuppression",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCodec,bTxSilenceSupp)},
                                                       {"ReceiveSilenceSuppression",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCodec,bRxSilenceSupp)},
                                                       {"TransmitPacketizationPeriod",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineCodec,unFrameLen)}

};
x_IFX_Param x_IFX_VMAPI_LineSession_param [] = {
													   {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineSession,ucProfileId)},
									                   {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineSession,ucLineId)},
                                                       {"SessionStartTime",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineSession,acSessStartTime)},
                                                       {"SessionDuration",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineSession,uiSessDuration)},
                                                       {"FarEndIPAddress",IFX_VMAPI_PARAM_TYPE_STR,
                                                       offsetof(x_IFX_VMAPI_LineSession,acDestAddress)},
                                                       {"FarEndUDPPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_LineSession,unDestPort)},
                                                       {"LocalUDPPort",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                       offsetof(x_IFX_VMAPI_LineSession,unLocalPort)}


};
x_IFX_Param x_IFX_VMAPI_LineStats_param [] = {
													   {"X_VENDOR_COM_ProfileId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineStats,ucProfileId)},
									                   {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                       offsetof(x_IFX_VMAPI_LineStats,ucLineId)},
                                                       {"ResetStatistics",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                       offsetof(x_IFX_VMAPI_LineStats,bResetStatistics)},
                                                       {"PacketsSent",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulPktsSent)},
                                                       {"PacketsReceived",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulPktsRcvd)},
                                                       {"BytesSent",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulBytesSent)},
                                                       {"BytesReceived",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulBytesRcvd)},
                                                       {"PacketsLost",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulPktsLost)},
                                                       {"ReceivePacketLossRate",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulRecvPktLossRate)},
                                                       {"FarEndPacketLossRate",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulFarEndPktLossRate)},
                                                       {"ReceiveInterarrivalJitter",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulRecvInterarrivalJitter)},
                                                       {"FarEndInterarrivalJitter",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulFarEndInterarrivalJitter)},
                                                       {"RoundTripDelay",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulRoundTripDelay)},
                                                       {"AverageReceiveInterarrivalJitter",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulAvgRecvInterarrivalJitter)},
                                                       {"AverageFarEndInterarrivalJitter",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulAvgFarEndInterarrivalJitter)},
                                                       {"AverageRoundTripDelay",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulAvgRoundTripDelay)},
                                                       {"Overruns",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulOverrun)},
                                                       {"Underruns",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulUnderrun)},
                                                       {"IncomingCallsReceived",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulIncomingCallsRcvd)},
                                                       {"IncomingCallsAnswered",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulIncomingCallsAns)},
                                                       {"IncomingCallsConnected",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulIncomingCallsConn)},
                                                       {"IncomingCallsFailed",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulIncomingCallsFail)},
                                                       {"OutgoingCallsAttempted",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulOutgoingCallsAttempt)},
                                                       {"OutgoingCallsAnswered",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulOutgoingCallsAns)},
                                                       {"OutgoingCallsConnected",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulOutgoingCallsConn)},
                                                       {"OutgoingCallsFailed",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulOutgoingCallsFail)},
                                                       {"CallsDropped",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulCallsDrop)},
                                                       {"TotalCallTime",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulTotalCallTime)},
                                                       {"ServerDownTime",IFX_VMAPI_PARAM_TYPE_UINT,
                                                       offsetof(x_IFX_VMAPI_LineStats,ulServerDownTime)}
};

#ifdef MESSAGE_SUPPORT
/***********************************************************/
/***************MESSAGE object **************************/

x_IFX_Param x_IFX_VMAPI_Message_param [] = {
                                              {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                  offsetof(x_IFX_VMAPI_Message,ucLineId)},
                                              {"X_VENDOR_COM_NoOfEntries",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                  offsetof(x_IFX_VMAPI_Message,ucNoOfEntries)}

};


x_IFX_Param x_IFX_VMAPI_MessageEntry_param [] = {
                                                   {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                          offsetof( x_IFX_VMAPI_MessageEntry,ucLineId)},
                                                   {"X_VENDOR_COM_Index",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                          offsetof( x_IFX_VMAPI_MessageEntry,ucIndex)},
                                                   {"X_VENDOR_COM_MsgHdl",IFX_VMAPI_PARAM_TYPE_UINT,
                                                          offsetof( x_IFX_VMAPI_MessageEntry,uiMsgHdl)},
                                                   {"X_VENDOR_COM_MessageBody",IFX_VMAPI_PARAM_TYPE_STR,
                                                          offsetof( x_IFX_VMAPI_MessageEntry,acMsg)},
                                                   {"X_VENDOR_COM_User",IFX_VMAPI_PARAM_TYPE_STR,
                                                          offsetof( x_IFX_VMAPI_MessageEntry,acUser)},
                                                   {"X_VENDOR_COM_ReadFlg",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                          offsetof( x_IFX_VMAPI_MessageEntry,bReadFlg)}
};
#endif /* MESSAGE_SUPPORT */

/******************************** Contact-List related object *********************/

x_IFX_Param x_IFX_VMAPI_ContactList_param [] = {
                                                 {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_VMAPI_ContactList,ucLineId)},
                                                 {"X_VENDOR_COM_NoOfEntries",IFX_VMAPI_PARAM_TYPE_UINT,
                                                   offsetof(x_IFX_VMAPI_ContactList,ucNoOfEntries)}

};

x_IFX_Param x_IFX_VMAPI_ContactListEntry_param [] = {
                                                     {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                           offsetof(x_IFX_VMAPI_ContactListEntry,ucLineId)},
                                                     {"X_VENDOR_COM_EntryId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                           offsetof(x_IFX_VMAPI_ContactListEntry,uiEntryId)},
                                                     {"X_VENDOR_COM_Index",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                           offsetof(x_IFX_VMAPI_ContactListEntry,ucIndex)},
                                                     {"X_VENDOR_COM_UserFirstName",IFX_VMAPI_PARAM_TYPE_STR,
                                                           offsetof(x_IFX_VMAPI_ContactListEntry,xAddress.acUserFirstName)},
                                                     {"X_VENDOR_COM_UserLastName",IFX_VMAPI_PARAM_TYPE_STR,
                                                           offsetof(x_IFX_VMAPI_ContactListEntry,xAddress.acUserLastName)},
                                                     {"X_VENDOR_COM_ContactNum",IFX_VMAPI_PARAM_TYPE_STR,
                                                           offsetof(x_IFX_VMAPI_ContactListEntry,xAddress.acContactNum)},
                                                     {"X_VENDOR_COM_ContactType",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                           offsetof(x_IFX_VMAPI_ContactListEntry,xAddress.cContactType)},
                                                     {"X_VENDOR_COM_ContactNumTwo",IFX_VMAPI_PARAM_TYPE_STR,
                                                           offsetof(x_IFX_VMAPI_ContactListEntry,xAddress.acContactNumTwo)},
                                                     {"X_VENDOR_COM_ContactTypeTwo",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                           offsetof(x_IFX_VMAPI_ContactListEntry,xAddress.cContactTypeTwo)}
};

/********************   Call Register *************************/
x_IFX_Param x_IFX_VMAPI_CallRegister_param [] = {
                                                 {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_VMAPI_CallRegister,ucLineId)},
                                                 {"X_VENDOR_COM_NoOfEntries",IFX_VMAPI_PARAM_TYPE_UINT,
                                                   offsetof(x_IFX_VMAPI_CallRegister,ucNoOfEntries)},
                                                 {"X_VENDOR_COM_Index",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                   offsetof(x_IFX_VMAPI_CallRegister,ucIndex)}				
};

x_IFX_Param x_IFX_VMAPI_CallRegEntry_param [] = {
                                                 {"X_VENDOR_COM_LineId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,ucLineId)},
                                                 {"X_VENDOR_COM_Index",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                   offsetof(x_IFX_VMAPI_CallRegEntry,ucIndex)},
                                                 {"X_VENDOR_COM_CallTime",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,acCallTime)},
                                                 {"X_VENDOR_COM_CallDate",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,acCallDate)},
                                                 {"X_VENDOR_COM_CallType",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,eCallType)},
                                                 {"X_VENDOR_COM_Status",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,bStatus)},
                                                 {"X_VENDOR_COM_NoOfCalls",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,ucNoOfCalls)},
                                                 {"X_VENDOR_COM_EntryId",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,uiEntryId)},
                                                 {"X_VENDOR_COM_AddrType",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,xAddress.ucAddrType)},
                                                 {"X_VENDOR_COM_DisplayName",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,xAddress.acDisplayName)},
                                                 {"X_VENDOR_COM_UserName",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,xAddress.acUserName)},
                                                 {"X_VENDOR_COM_DestAddr",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,xAddress.acDestAddr)},
                                                 {"X_VENDOR_COM_Port",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,xAddress.unPort)},
                                                 {"X_VENDOR_COM_AddrProto",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_VMAPI_CallRegEntry,xAddress.ucAddrProto)}
};

#ifdef ULE_SUPPORT
x_IFX_Param x_IFX_ULE_MAPI_UleSubsInfo_param [] = {
                                                 {"X_VENDOR_COM_IsRegistered",IFX_VMAPI_PARAM_TYPE_CHAR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,bIsRegistered)},
                                                 {"X_VENDOR_COM_IPUI",IFX_VMAPI_PARAM_TYPE_STR,
                                                   offsetof(x_IFX_ULE_MAPI_UleSubsInfo,aucIPUI)},
                                                 {"X_VENDOR_COM_TPUI",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,aucTPUI)},
                                                 {"X_VENDOR_COM_AuthKey",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,aucAuthKey)},
                                                 {"X_VENDOR_COM_CipherKey",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,aucCipherKey)},
                                                 {"X_VENDOR_COM_ServiceClass",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,ucServiceClass)},
                                                 {"X_VENDOR_COM_ModelId",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,ucModelId)},
                                                 {"X_VENDOR_COM_TermCapab",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,uiTermCapab)},
                                                 {"X_VENDOR_COM_Last_SSN",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,Last_SSN)},
                                                 {"X_VENDOR_COM_Last_RSN",IFX_VMAPI_PARAM_TYPE_STR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,Last_RSN)},
                                                 {"X_VENDOR_COM_ULEType",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,uiULEType)},
                                                 {"X_VENDOR_COM_SDUSize",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,uiSDUSize)},
                                                 {"X_VENDOR_COM_WindowSize",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,ucWindowSize)},
                                                 {"X_VENDOR_COM_NWKState",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,uiNWKState)},
                                                 {"X_VENDOR_COM_DeviceNo",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,ucDeviceNo)},
                                                 {"X_VENDOR_COM_EMC",IFX_VMAPI_PARAM_TYPE_USHORT_INT,
                                                    offsetof(x_IFX_ULE_MAPI_UleSubsInfo,unEMC)}
};

x_IFX_Param x_IFX_ULE_MAPI_SystemConfig_param [] = {
                                                 {"X_VENDOR_COM_SensorPageCycle",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,uiSensorPageCycle)},
                                                 {"X_VENDOR_COM_Start_MFN_Sensor",IFX_VMAPI_PARAM_TYPE_UINT,
                                                   offsetof(x_IFX_ULE_MAPI_SystemConfig,uiStart_MFN_Sensor)},
                                                 {"X_VENDOR_COM_Start_FCN_Sensor",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,ucStart_FCN_Sensor)},
                                                 {"X_VENDOR_COM_ActiveChnlSensor",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,ucActiveChnlSensor)},
                                                 {"X_VENDOR_COM_SlowActuatorPageCycle",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,uiSlowActuatorPageCycle)},
                                                 {"X_VENDOR_COM_Start_MFN_SlowAct",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,uiStart_MFN_SlowAct)},
                                                 {"X_VENDOR_COM_Start_FCN_SlowAct",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,ucStart_FCN_SlowAct)},
                                                 {"X_VENDOR_COM_ActiveChnlSlowAct",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,ucActiveChnlSlowAct)},
                                                 {"X_VENDOR_COM_FastActuatorPageCycle",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,uiFastActuatorPageCycle)},
                                                 {"X_VENDOR_COM_Start_MFN_FastAct",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,uiStart_MFN_FastAct)},
                                                 {"X_VENDOR_COM_Start_FCN_FastAct",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,ucStart_FCN_FastAct)},
                                                 {"X_VENDOR_COM_ActiveChnlFastAct",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,ucActiveChnlFastAct)},
                                                 {"X_VENDOR_COM_StayAliveCycle",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,uiStayAliveCycle)},
                                                 {"X_VENDOR_COM_SDUSize",IFX_VMAPI_PARAM_TYPE_UINT,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,uiSDUSize)},
                                                 {"X_VENDOR_COM_WindowSize",IFX_VMAPI_PARAM_TYPE_UCHAR,
                                                    offsetof(x_IFX_ULE_MAPI_SystemConfig,ucWindowSize)}
};

#endif
#if 0
int
ifx_ParseCallBlockList (uchar8 * ucSrc, uchar8 * ucDestList,
                              uchar8 * iLength);
int
ifx_ParseCallBlockListDevice (char8 * ucSrc, char8 * ucDestList,
                              uchar8 * iLength);
int fill_struct_param(ObjList *pxTmpObj,void *pVoipStruct,x_IFX_Param param_detail[],int iSize);
int ifx_get_EventSubscribe (IN_OUT x_IFX_VMAPI_EventSubscribe  *pxEventSub,uint32  uiInFlag);

int32 ifx_get_VoiceCodecCapsEntry(
                    OUT x_IFX_VMAPI_CodecDesc *pxVCCapsEntry,
                    IN uint32 uiInFlag);
int ifx_get_NumPlanRule(x_IFX_VMAPI_NumPlanRule *pxNumRule,uint32  uiInFlag);

int ifx_get_CodecDesc(x_IFX_VMAPI_CodecDesc *pxCodecDesc,uint32  uiInFlag);
int ifx_get_LineEvents(x_IFX_VMAPI_LineEvents  *pxLineEvents,uint32  uiInFlag);
int ifx_get_DialCallRegEntry (x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,uint32  uiInFlag);
int ifx_get_PstnDialCallRegEntry (x_IFX_VMAPI_DialCallRegEntry  *pxDialCallRegEtr,uint32  uiInFlag);
int ifx_get_MissCallRegEntry (x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,uint32  uiInFlag);
int ifx_get_PstnMissCallRegEntry (x_IFX_VMAPI_MissCallRegEntry  *pxMissCallRegEtr,uint32  uiInFlag);
int ifx_get_RecvCallRegEntry (x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,uint32  uiInFlag);
int ifx_get_PstnRecvCallRegEntry (x_IFX_VMAPI_RecvCallRegEntry  *pxRecvCallRegEtr,uint32  uiInFlag);
int ifx_get_ContactListEntry(x_IFX_VMAPI_ContactListEntry *pxContactListEtr,uint32  uiInFlag);
int ifx_get_PstnContactListEntry(x_IFX_VMAPI_ContactListEntry *pxContactListEtr,uint32  uiInFlag);
int ifx_get_CommonContactListEntry(x_IFX_VMAPI_ContactListEntry *pxContactListEtr,uint32  uiInFlag);

/* API to get Host IP and DNS servers list */
typedef enum {
	IFX_IP_ADDRESS_V4,
	IFX_IP_ADDRESS_V6
} e_IFX_IP_ADDRESS_TYPE;

typedef struct {
	char8 sIPAddress[MAX_LEN_PARAM_NAME];
	e_IFX_IP_ADDRESS_TYPE eType;
} x_IFX_IP_ADDRESS;

/*! \brief  Get List of DNS server for Default WAN interface.
   \param[out] puiCount is  Number of DNS servers returned
   \param[out] pxDNS Array of DNS servers of puiCount number.
   Caller must free the buffer.
   \return 0 if OK / -1 on ERROR
*/
int32_t ifx_get_DNSIP(OUT uint32_t *puiCount, OUT x_IFX_IP_ADDRESS **pxDNS);

/*! \brief  Get IPv4 and IPv6 addresses for Default WAN interface.
   \param[out] pcHostIPv4 is IPv4 address of the Default WAN
   \param[out] pcHostIPv6 is IPv6 address of the Default WAN
   \return 0 if OK / -1 on ERROR
*/
int32_t ifx_get_HostIP(OUT char8 *pcHostIPv4, OUT char8 *pcHostIPv6);

/*Api to set Auth config*/
int ifx_get_AuthCfg(x_IFX_VMAPI_SipAuthCfg *pxAuthCfg,uint32  uiInFlag);

/*Api to update the value in object list*/
int32_t UpdateParamValueInDB(ObjList *pxTmpObj,void *pVoipStruct,x_IFX_Param acOffsetStruct[],int nSize);

void
ifx_vmapi_freeObjectList(void *pxVoid,IN uchar8 ucObjType);
int
IFX_SipUri_GetHostName(IN char8* pcString,OUT char8* pcHostName);

void IFX_VMAPI_DbgInit(
             IN char8 cDbgType,
             IN char8 cDbgLvl,
             OUT char8 *pcRet);


PUBLIC char8 IFX_VMAPI_SendNotifyForRegObject(IN uchar8 ucInfoType,
                                           IN void *pvOldObj , IN void *pvNewObj);

#endif
