/*  *****************************************************************************
    Copyright (c) 2014
	LANTIQ DEUTSCHLAND GMBH
		Lilienthalstrasse 15, 85579 Neubiberg, Germany
	For licensing information, see the file 'LICENSE' in the Device.Services.folder of
					        this software module.

********************************************************************************/
/*  *****************************************************************************
 *         File Name    : voice_profile.c                                       *
 *         Description  : voice profile                                         *
 *                                                                              *
 *  *****************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <sys/file.h>
#include "ifx_vmapi_genapi.h"
#include "stdlib.h"
#include "cal.h"
#include "VoiceService_control.h"
#include "ugw_structs.h"
#include "ifx_sip_errors.h"
#include "ifx_sipuri_func.h"
#include "ifx_vmapi_api.h"
#include "ifx_vmapi_port.h"
#include "ifx_list.h"
#include "ifx_debug.h"
#define printf(...)

#ifndef LOG_LEVEL
uint16_t LOGLEVEL = SYS_LOG_DEBUG + 1;
#else
uint16_t LOGLEVEL = LOG_LEVEL + 1;
#endif

#ifndef LOG_TYPE
uint16_t LOGTYPE = SYS_LOG_TYPE_FILE;
#else
uint16_t LOGTYPE = LOG_TYPE;
#endif
/******************************************************************************
*  Function Name  : ifx_getval_fromname
*  Description    : Get api to get value corresponds to a string
*  Input Values   : pcname - Input string 
*					pxnv - input data structure which stores name value pair
*					nSize - size of data structure
*  Output Values  : 
*  Return Value   : Value
*  Notes          : 
******************************************************************************/
int32_t ifx_getval_fromname(char *pcname, x_IFX_NAME_VALUE * pxnv,
			    int32_t nSize)
{
	int32_t nParamVal = IFX_VMAPI_SUCCESS, nIndex = 0;
	x_IFX_NAME_VALUE *pxtmp = pxnv;

	for (nIndex = 0; nIndex < nSize; nIndex++) {

		if (strcasecmp(pxtmp->sName, pcname) == 0) {
			nParamVal = pxtmp->unValue;

			break;
		}
		pxtmp++;
	}

	return nParamVal;
}

static int32_t cal_getValueWrapper(INOUT MsgHeader * pxMsg);
static int32_t cal_setValueWrapper(INOUT MsgHeader * pxMsg);

pthread_mutex_t global_vmapi_mutex = PTHREAD_MUTEX_INITIALIZER;

static int32_t cal_getValueWrapper(INOUT MsgHeader * pxMsg)
{
	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	pthread_mutex_lock(&global_vmapi_mutex);
	nRetVal = cal_getValue(pxMsg);
	pthread_mutex_unlock(&global_vmapi_mutex);

	return nRetVal;
}

static int32_t cal_setValueWrapper(INOUT MsgHeader * pxMsg)
{
	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	pthread_mutex_lock(&global_vmapi_mutex);
	nRetVal = cal_setValue(pxMsg);
	pthread_mutex_unlock(&global_vmapi_mutex);

	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_getstring_fromval
*  Description    : Get api to get string from value
*  Input Values   : nInVal - Input string 
*					pxnv - input data structure which stores name value pair
*					nSize - size of data structure
*  Output Values  : sTempstr - string
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t
ifx_getstring_fromval(int32_t nInVal, x_IFX_NAME_VALUE * pxnv, int32_t nSize,
		      char *sTempstr)
{
	int32_t nRetVal = IFX_VMAPI_SUCCESS, nIndex = 0;
	x_IFX_NAME_VALUE *pxtmp = pxnv;

	CHECK_FOR_NULL(sTempstr, "String is NULL");

	for (nIndex = 0; nIndex < nSize; nIndex++) {
		if (pxtmp->unValue == nInVal) {
			strcpy(sTempstr, pxtmp->sName);
			break;
		}
		pxtmp++;
	}
      END:
	return nRetVal;
}


/******************************************************************************
*  Function Name  : HandleVoiceLineCodecDes
*  Description    : Api to handle Voice Line codec params for 
*					which data type differs in DB and internal data
*					structure.
*  Input Values   : pxTmpObj - DB object list			
*  Output Values  : pxLineCodec - Codec data structure to be filled
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t HandleVoiceLineCodec(ObjList * pxTmpObj,
			     x_IFX_VMAPI_LineCodec * pxLineCodec)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleVoiceLineCodec function.");
	ParamList *pxParam = NULL;
	int32_t nValue = -1, nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	CHECK_FOR_NULL(pxTmpObj, "Error :  Line Codec Object is NULL");
	CHECK_FOR_NULL(pxLineCodec,
		       "Error :  Line Codec struct Object is NULL");

	nSize = sizeof(axcodecnv) / sizeof(x_IFX_NAME_VALUE);

	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		switch (pxParam->unParamId) {
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CODEC_TRANSMITCODEC:
			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axcodecnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error :  Getting TxCodec Failed\n");
				goto END;
			}
			pxLineCodec->uiTxCodec = nValue;
			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CODEC_RECEIVECODEC:
			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axcodecnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error :  Getting RxCodec Failed\n");
				goto END;
			}
			pxLineCodec->uiRxCodec = nValue;
			break;

		}
	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleVoiceLineCodec function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleVoiceLineEvent
*  Description    : Api to handle Voice Line Event params for 
*					which data type differs in DB and internal data
*					structure.
*  Input Values   : pxTmpObj - DB object list	
*					nOperation - GET/SET operation		
*  Output Values  : pxVoiceLine - Line Events data structure to be filled
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t HandleVoiceLineEvent(ObjList * pxTmpObj,
			     x_IFX_VMAPI_LineEvents * pxVoiceLine,
			     int32_t nOperation)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleVoiceLineEvent function.");
	ParamList *pxParam = NULL;
	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	if (NULL == pxTmpObj || NULL == pxVoiceLine) {
		nRetVal = IFX_VMAPI_FAIL;
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Error :  Line Event Object is NULL\n");
		goto END;
	}
	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		if (pxParam->unParamId ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SIP_EVENTSUBSCRIBE_EVENT)
		{
			if (nOperation == VOIP_GET) {
				if (!strncmp
				    (pxParam->sParamValue,
				     LINE_EVENT_MESSAGE_SUMMARY,
				     strlen(LINE_EVENT_MESSAGE_SUMMARY)))
					pxVoiceLine->uiSubspnEvent =
					    IFX_VMAPI_VL_SUBS_EVENT_MWI;
				else if (!strncmp
					 (pxParam->sParamValue,
					  LINE_EVENT_DIALOG,
					  strlen(LINE_EVENT_DIALOG)))
					pxVoiceLine->uiSubspnEvent =
					    IFX_VMAPI_VL_SUBS_EVENT_DIALOG;
			} else if (nOperation == VOIP_SET) {
				if (pxVoiceLine->uiSubspnEvent ==
				    IFX_VMAPI_VL_SUBS_EVENT_MWI)
					strncpy(pxParam->sParamValue,
						LINE_EVENT_MESSAGE_SUMMARY,
						strlen
						(LINE_EVENT_MESSAGE_SUMMARY));
				else if (pxVoiceLine->uiSubspnEvent ==
					 IFX_VMAPI_VL_SUBS_EVENT_DIALOG)
					strncpy(pxParam->sParamValue,
						LINE_EVENT_DIALOG,
						strlen(LINE_EVENT_DIALOG));

			}
			break;
		}
	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleVoiceLineEvent function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleVoiceLineCallingFeature
*  Description    : Api to handle Voice Line calling feature params for 
*					which data type differs in DB and internal data
*					structure.
*  Input Values   : pxTmpObj - DB object list	
*					nOperation - GET/SET operation		
*  Output Values  : pxLineCallingFeatures - Line Calling feature data 
*					structure to be filled
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t HandleVoiceLineCallingFeature(ObjList * pxTmpObj,
				      x_IFX_VMAPI_LineCallingFeatures *
				      pxLineCallingFeatures,
				      int32_t nOperation)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleVoiceLineCallingFeature.");
	ParamList *pxParam = NULL;
	int32_t nValue = 0, nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	char strVal[MAX_LEN_PARAM_VALUE];

	if (NULL == pxTmpObj || NULL == pxLineCallingFeatures) {
		nRetVal = IFX_VMAPI_FAIL;
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Error :  Line calling Object is NULL\n");
		goto END;
	}
	nSize = sizeof(axcallingfeatnv) / sizeof(x_IFX_NAME_VALUE);
	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		strncpy(strVal, "", MAX_LEN_PARAM_VALUE);
		switch (pxParam->unParamId) {
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES_CALLWAITINGSTATUS:
			if (nOperation == VOIP_GET)
			{
				pxLineCallingFeatures->ucCallWaitStatus =
				    ifx_getval_fromname(pxParam->sParamValue,
							axcallingfeatnv,
							nSize);
			} else if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxLineCallingFeatures->
						      ucCallWaitStatus,
						      axcallingfeatnv, nSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,
					sizeof(strVal));

			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES_CONFERENCECALLINGSTATUS:
			if (nOperation == VOIP_GET)
			{
				pxLineCallingFeatures->ucConfCallStatus =
				    ifx_getval_fromname(pxParam->sParamValue,
							axcallingfeatnv,
							nSize);
			} else if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxLineCallingFeatures->
						      ucCallWaitStatus,
						      axcallingfeatnv, nSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,
					sizeof(strVal));
			}

			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES_X_VENDOR_COM_CALLFWRDVOICEMAIL:
			if (nOperation == VOIP_GET)
			{
				if ((!strncmp
				     (pxParam->sParamValue, IFX_STRING_TRUE,
				      strlen(IFX_STRING_TRUE)))
				    || atoi(pxParam->sParamValue) ==
				    IFX_TR104_TRUE)
					pxLineCallingFeatures->unCallFwdCfg |=
					    IFX_VMAPI_CALL_FWD_VOICE_MAIL;
				else if ((!strncmp
					  (pxParam->sParamValue,
					   IFX_STRING_FALSE,
					   strlen(IFX_STRING_FALSE)))
					 || atoi(pxParam->sParamValue) ==
					 IFX_TR104_FALSE)
					pxLineCallingFeatures->unCallFwdCfg &=
					    ~IFX_VMAPI_CALL_FWD_VOICE_MAIL;
			} else if (nOperation == VOIP_SET) {
				nValue =
				    (pxLineCallingFeatures->
				     unCallFwdCfg &
				     IFX_VMAPI_CALL_FWD_VOICE_MAIL) ? 1 : 0;
				snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%d", nValue);
			}

			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES_CALLFORWARDUNCONDITIONALENABLE:
			if (nOperation == VOIP_GET)
			{
				if ((!strncmp
				     (pxParam->sParamValue, IFX_STRING_TRUE,
				      strlen(IFX_STRING_TRUE)))
				    || atoi(pxParam->sParamValue) ==
				    IFX_TR104_TRUE)
					pxLineCallingFeatures->unCallFwdCfg |=
					    IFX_VMAPI_CALL_FWD_UNCONDITIONAL;
				else if ((!strncmp
					  (pxParam->sParamValue,
					   IFX_STRING_FALSE,
					   strlen(IFX_STRING_FALSE)))
					 || atoi(pxParam->sParamValue) ==
					 IFX_TR104_FALSE)
					pxLineCallingFeatures->unCallFwdCfg &=
					    ~IFX_VMAPI_CALL_FWD_UNCONDITIONAL;
			} else if (nOperation == VOIP_SET) {
				nValue =
				    (pxLineCallingFeatures->
				     unCallFwdCfg &
				     IFX_VMAPI_CALL_FWD_UNCONDITIONAL) ? 1 :
				    0;
				snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%d", nValue);
			}

			break;
/*
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES_CALLFORWARDUNCONDITIONALNUMBER:
	       		pxLineCallingFeatures->xCfuAddress.ucAddrType = IFX_VMAPI_ADDR_TYPE_TEL_NUM;
              		break;
*/

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES_CALLFORWARDONBUSYENABLE:
			if (nOperation == VOIP_GET)
			{
				if ((!strncmp
				     (pxParam->sParamValue, IFX_STRING_TRUE,
				      strlen(IFX_STRING_TRUE)))
				    || atoi(pxParam->sParamValue) ==
				    IFX_TR104_TRUE)
					pxLineCallingFeatures->unCallFwdCfg |=
					    IFX_VMAPI_CALL_FWD_BUSY;
				else if ((!strncasecmp
					  (pxParam->sParamValue,
					   IFX_STRING_FALSE,
					   strlen(IFX_STRING_FALSE)))
					 || atoi(pxParam->sParamValue) ==
					 IFX_TR104_FALSE)
					pxLineCallingFeatures->unCallFwdCfg &=
					    ~IFX_VMAPI_CALL_FWD_BUSY;
			} else if (nOperation == VOIP_SET) {
				nValue =
				    (pxLineCallingFeatures->
				     unCallFwdCfg & IFX_VMAPI_CALL_FWD_BUSY) ?
				    1 : 0;
				snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%d", nValue);
			}

			break;
/*
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES_CALLFORWARDONBUSYNUMBER:
	     		pxLineCallingFeatures->xCfbAddress.ucAddrType = IFX_VMAPI_ADDR_TYPE_TEL_NUM;
             		break;
*/
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES_CALLFORWARDONNOANSWERENABLE:
			if (nOperation == VOIP_GET)
			{

				if ((!strncmp
				     (pxParam->sParamValue, IFX_STRING_FALSE,
				      strlen(IFX_STRING_FALSE)))
				    || atoi(pxParam->sParamValue) ==
				    IFX_TR104_TRUE)
					pxLineCallingFeatures->unCallFwdCfg |=
					    IFX_VMAPI_CALL_FWD_ON_NO_ANSWER;
				else if ((!strncasecmp
					  (pxParam->sParamValue,
					   IFX_STRING_FALSE,
					   strlen(IFX_STRING_FALSE)))
					 || atoi(pxParam->sParamValue) ==
					 IFX_TR104_FALSE)
					pxLineCallingFeatures->unCallFwdCfg &=
					    ~IFX_VMAPI_CALL_FWD_ON_NO_ANSWER;
			} else if (nOperation == VOIP_SET) {
				nValue =
				    (pxLineCallingFeatures->
				     unCallFwdCfg &
				     IFX_VMAPI_CALL_FWD_ON_NO_ANSWER) ? 1 : 0;
				snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%d", nValue);
			}

			break;
			/* 
			   case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES_CALLFORWARDONNOANSWERNUMBER:
			   pxLineCallingFeatures->xCfnaAddress.ucAddrType = IFX_VMAPI_ADDR_TYPE_TEL_NUM;
			 */
		}
	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleVoiceLineCallingFeature function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleVoiceLineParam
*  Description    : Api to handle Voice Line params for 
*					which data type differs in DB and internal data
*					structure.
*  Input Values   : pxTmpObj - DB object list	
*					nOperation - GET/SET operation		
*  Output Values  : pxVoiceLine - Voice Line feature data 
*					structure to be filled
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t HandleVoiceLineParam(ObjList * pxTmpObj,
			     x_IFX_VMAPI_VoiceLine * pxVoiceLine,
			     int32_t nOperation)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleVoiceLineParam function.");
	ParamList *pxParam = NULL;
	int32_t nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	char strVal[MAX_LEN_PARAM_VALUE];

	if (NULL == pxTmpObj || NULL == pxVoiceLine) {
		nRetVal = IFX_VMAPI_FAIL;
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Error :  Line Object is NULL\n");
		goto END;
	}

	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		switch (pxParam->unParamId) {

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_ENABLE:
			if (nOperation == VOIP_GET) {
				if (!strncmp
				    (pxParam->sParamValue,
				     IFX_STRING_DISABLED,
				     strlen(IFX_STRING_DISABLED)))
					pxVoiceLine->ucState =
					    IFX_VMAPI_VL_STATE_DISABLED;
				else if (!strncmp
					 (pxParam->sParamValue,
					  IFX_STRING_QUIESCENT,
					  strlen(IFX_STRING_QUIESCENT)))
					pxVoiceLine->ucState =
					    IFX_VMAPI_VL_STATE_QUIESCENT;
				else if (!strncmp
					 (pxParam->sParamValue,
					  IFX_STRING_ENABLED,
					  strlen(IFX_STRING_ENABLED)))
					pxVoiceLine->ucState =
					    IFX_VMAPI_VL_STATE_ENABLED;
			} else if (nOperation == VOIP_SET) {
				if (pxVoiceLine->ucState ==
				    IFX_VMAPI_VL_STATE_DISABLED)
					strncpy(pxParam->sParamValue,
						IFX_STRING_DISABLED,
						strlen(IFX_STRING_DISABLED));
				else if (pxVoiceLine->ucState ==
					 IFX_VMAPI_VL_STATE_QUIESCENT)
					strncpy(pxParam->sParamValue,
						IFX_STRING_QUIESCENT,
						strlen(IFX_STRING_QUIESCENT));
				else if (pxVoiceLine->ucState ==
					 IFX_VMAPI_VL_STATE_ENABLED)
					strncpy(pxParam->sParamValue,
						IFX_STRING_ENABLED,
						strlen(IFX_STRING_ENABLED));

			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_STATUS:

			nSize =
			    sizeof(axlinestatusnv) / sizeof(x_IFX_NAME_VALUE);
			if (nOperation == VOIP_GET) {
				pxVoiceLine->ucLineStatus =
				    ifx_getval_fromname(pxParam->sParamValue,
							axlinestatusnv,
							nSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxVoiceLine->
						      ucLineStatus,
						      axlinestatusnv, nSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,MAX_LEN_PARAM_VALUE);
			}
			break;
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLSTATE:
			nSize =
			    sizeof(axcallstatusnv) / sizeof(x_IFX_NAME_VALUE);
			if (nOperation == VOIP_GET) {
				pxVoiceLine->ucCallStatus =
				    ifx_getval_fromname(pxParam->sParamValue,
							axcallstatusnv,
							nSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxVoiceLine->
						      ucCallStatus,
						      axcallstatusnv, nSize,
						      strVal);
				strcpy(pxParam->sParamValue, strVal);
			}
			break;
		}
	}

      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleVoiceLineParam function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleProfileMediaSec
*  Description    : Api to handle profile media security params for 
*					which data type differs in DB and internal data
*					structure.
*  Input Values   : pxTmpObj - DB object list			
*  Output Values  : pxProfileMediaSec -  profile media security data 
*					structure to be filled
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
#ifdef IIP
int32_t HandleProfileMediaSec(ObjList * pxTmpObj,
			      x_IFX_VMAPI_ProfileMediaSecurity *
			      pxProfileMediaSec)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleProfileMediaSec function.");
	ParamList *pxParam = NULL;
	int32_t nValue = -1, nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;

	if (NULL == pxTmpObj || NULL == pxProfileMediaSec) {
		nRetVal = IFX_VMAPI_FAIL;
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Error :  Voice profile media security object is NULL\n");
		goto END;
	}
	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		if (pxParam->unParamId ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_RTP_SRTP_KEYINGMETHODS)
		{
			nSize =
			    sizeof(axmediasecnv) / sizeof(x_IFX_NAME_VALUE);
			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axmediasecnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error :  Getting Call status Failed\n");
				goto END;
			}
			pxProfileMediaSec->ucSrtpKeyingMethod = nValue;
			break;
		}
	}

      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleProfileMediaSec function.");
	return nRetVal;
}
#endif

/******************************************************************************
*  Function Name  : HandleProfileMediaSec
*  Description    : Api to handle profile media security params for 
*					which data type differs in DB and internal data
*					structure.
*  Input Values   : pxTmpObj - DB object list			
*  Output Values  : pxProfileMediaSec -  profile media security data 
*					structure to be filled
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t HandleVoiceProEventSus(ObjList * pxTmpObj,
			       x_IFX_VMAPI_EventSubscribe *
			       pxVoiceProfileEventSubs)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleVoiceProEventSus function.");
	ParamList *pxParam = NULL;
	int32_t nValue = -1, nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;

	if (NULL == pxTmpObj || NULL == pxVoiceProfileEventSubs) {
		nRetVal = IFX_VMAPI_FAIL;
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Error :  Voice profile event subscribe object is NULL\n");
		goto END;
	}

	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		switch (pxParam->unParamId) {
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_EVENTSUBSCRIBE_EVENT:
			if (!strncmp
			    (pxParam->sParamValue, IFX_STRING_EVENT_MWI,
			     strlen(IFX_STRING_EVENT_MWI)))
				pxVoiceProfileEventSubs->uiEvent =
				    IFX_VMAPI_VL_SUBS_EVENT_MWI;
			if (!strncmp
			    (pxParam->sParamValue, IFX_STRING_EVENT_DIALOG,
			     strlen(IFX_STRING_EVENT_DIALOG)))
				pxVoiceProfileEventSubs->uiEvent =
				    IFX_VMAPI_VL_SUBS_EVENT_DIALOG;
			break;
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_EVENTSUBSCRIBE_NOTIFIERTRANSPORT:
			nSize =
			    sizeof(axtransportnv) / sizeof(x_IFX_NAME_VALUE);
			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axtransportnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error :  Getting Notifier transport Failed\n");
				goto END;
			}
			pxVoiceProfileEventSubs->ucNotifierProtocol = nValue;
			break;
		}
	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleVoiceProEventSus function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleVoiceProSigSpclParams
*  Description    : Api to handle profile signalling params for 
*					which data type differs in DB and internal data
*					structure.
*  Input Values   : pxTmpObj - DB object list			
*  Output Values  : pxVoiceProfileSignaling -  profile signalling data 
*					structure to be filled
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t HandleVoiceProSigSpclParams(ObjList * pxTmpObj,
				    x_IFX_VMAPI_ProfileSignaling *
				    pxVoiceProfileSignaling)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleVoiceProSigSpclParams function.");
	ParamList *pxParam = NULL;
	int32_t nValue = -1, nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;

	if (NULL == pxTmpObj || NULL == pxVoiceProfileSignaling) {
		nRetVal = IFX_VMAPI_FAIL;
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Error :  Voice profile signalling object is NULL\n");
		goto END;
	}

	if (strlen(pxVoiceProfileSignaling->acProxyAddr) != 0)
		pxVoiceProfileSignaling->bEnableProxy = IFX_TR104_TRUE;
	else {
		pxVoiceProfileSignaling->bEnableProxy = IFX_TR104_FALSE;
		memset(pxVoiceProfileSignaling->acProxyAddr, 0,
		       sizeof(pxVoiceProfileSignaling->acProxyAddr));
	}
	if (strlen(pxVoiceProfileSignaling->acRegistrarAddr) != 0) {
		pxVoiceProfileSignaling->bEnableRegistrar = IFX_TR104_TRUE;
	} else {
		pxVoiceProfileSignaling->bEnableRegistrar = IFX_TR104_FALSE;
		memset(pxVoiceProfileSignaling->acRegistrarAddr, 0,
		       sizeof(pxVoiceProfileSignaling->acRegistrarAddr));
	}

	nSize = sizeof(axtransportnv) / sizeof(x_IFX_NAME_VALUE);

	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		switch (pxParam->unParamId) {
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_PROXYSERVERTRANSPORT:

			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axtransportnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error : Getting Proxy server transport Failed\n");
				goto END;
			}

			pxVoiceProfileSignaling->ucProxyProtocol = nValue;
			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_REGISTRARSERVERTRANSPORT:

			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axtransportnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error : Getting Register server transport Failed\n");
				goto END;
			}
			pxVoiceProfileSignaling->ucRegistrarProtocol = nValue;
			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_USERAGENTTRANSPORT:

			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axtransportnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error : Getting user agent transport Failed\n");
				goto END;
			}
			pxVoiceProfileSignaling->ucUAProtocol = nValue;
			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_X_VENDOR_COM_BACKUPREGPROTOCOL:

			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axtransportnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error : Getting Backup server transport Failed\n");
				goto END;
			}
			pxVoiceProfileSignaling->ucBackupRegProtocol = nValue;
			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_INBOUNDAUTH:

			if (!strncmp
			    (pxParam->sParamValue,
			     IFX_STRING_SIP_INBOUNDAUTH_NONE,
			     strlen(IFX_STRING_SIP_INBOUNDAUTH_NONE)))
				pxVoiceProfileSignaling->ucInboundAuth =
				    IFX_VMAPI_AUTH_METHOD_NONE;
			else if (!strncmp
				 (pxParam->sParamValue,
				  IFX_STRING_SIP_INBOUNDAUTH_DIGEST,
				  strlen(IFX_STRING_SIP_INBOUNDAUTH_DIGEST)))
				pxVoiceProfileSignaling->ucInboundAuth =
				    IFX_VMAPI_AUTH_METHOD_DIGEST;

			break;
		}
	}

      END:

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleVoiceProSigSpclParams function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleVoiceProSpclParams
*  Description    : Api to handle Voice profile params for 
*					which data type differs in DB and internal data
*					structure.
*  Input Values   : pxTmpObj - DB object list			
*  Output Values  : pxVoiceProfile - Voice  profile  data 
*					structure to be filled
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t HandleVoiceProSpclParams(ObjList * pxTmpObj,
				 x_IFX_VMAPI_VoiceProfile * pxVoiceProfile)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleVoiceProSpclParams function.");
	ParamList *pxParam = NULL;
	int32_t nValue = -1, nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;

	if (NULL == pxTmpObj || NULL == pxVoiceProfile) {
		nRetVal = IFX_VMAPI_FAIL;
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR, IFX_DBG_STR,
			 "Error :  Voice profile object is NULL\n");
		goto END;
	}
	nSize = sizeof(axdtmfmethodnv) / sizeof(x_IFX_NAME_VALUE);
	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		switch (pxParam->unParamId) {
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_ENABLE:
			if (!strncmp
			    (pxParam->sParamValue, IFX_STRING_DISABLED,
			     strlen(IFX_STRING_DISABLED)))
				pxVoiceProfile->ucState =
				    IFX_VMAPI_VP_STATE_DISABLED;
			else if (!strncmp
				 (pxParam->sParamValue, IFX_STRING_ENABLED,
				  strlen(IFX_STRING_ENABLED)))
				pxVoiceProfile->ucState =
				    IFX_VMAPI_VP_STATE_ENABLED;
			else if (!strncmp
				 (pxParam->sParamValue, IFX_STRING_QUIESCENT,
				  strlen(IFX_STRING_QUIESCENT)))
				pxVoiceProfile->ucState =
				    IFX_VMAPI_VP_STATE_QUIESCENT;
			break;
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_DTMFMETHOD:
			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axdtmfmethodnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error : Getting voice profile dtmf method Failed\n");
				goto END;
			}
			pxVoiceProfile->ucDtmfMethod = nValue;
			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_DTMFMETHODG711:
			nValue =
			    ifx_getval_fromname(pxParam->sParamValue,
						axdtmfmethodnv, nSize);
			if (nValue == -1) {
				nRetVal = IFX_VMAPI_FAIL;
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_ERROR,
					 IFX_DBG_STR,
					 "Error : Getting voice profile dtmf method711 method Failed\n");
				goto END;
			}
			pxVoiceProfile->ucG711DtmfMethod = nValue;
			break;

		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_FAXPASSTHROUGH:
			if (!strncmp
			    (pxParam->sParamValue, IFX_STRING_AUTO,
			     strlen(IFX_STRING_AUTO)))
				pxVoiceProfile->bFaxPassThru = IFX_TR104_TRUE;
			else if (!strncmp
				 (pxParam->sParamValue, IFX_STRING_DISABLE,
				  strlen(IFX_STRING_DISABLE)))
				pxVoiceProfile->bFaxPassThru =
				    IFX_TR104_FALSE;
			break;
		case DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_MODEMPASSTHROUGH:
			if (!strncmp
			    (pxParam->sParamValue, IFX_STRING_AUTO,
			     strlen(IFX_STRING_AUTO)))
				pxVoiceProfile->bModemPassThru =
				    IFX_TR104_TRUE;
			else if (!strncmp
				 (pxParam->sParamValue, IFX_STRING_DISABLE,
				  strlen(IFX_STRING_DISABLE)))
				pxVoiceProfile->bModemPassThru =
				    IFX_TR104_FALSE;

		}
	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleVoiceProSpclParams function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_VoiceSevice
*  Description    : Get api to get VoiceService object.
*  Input Values   :  pxVoiceService - Pointer to VoiceService object
*                    uiInFlag - Input flags
*  Output Values  : pxVoiceService - pointer to VoiceService object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_VoiceService(x_IFX_VMAPI_VoiceService * pxVoiceService,
			 uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_VoiceService function");

	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32_t nIndex = 0, nRetVal = IFX_VMAPI_SUCCESS;
	
	uchar8 pucProfileIdList[IFX_IDLIST_MAX_LEN][IFX_IDLIST_MAX_LEN];
	uchar8 pucLineIdList[IFX_IDLIST_MAX_LEN][IFX_IDLIST_MAX_LEN];
	char8 pucDeviceList[IFX_IDLIST_MAX_LEN][IFX_IDLIST_MAX_LEN];

	uchar8 ucNoOfProfiles;
	uchar8 ucNoOfLines;
	uchar8 ucDevice = 0;
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, VOICE_SERVICE);

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_LEAFNODE, OWN_SERVD, 1);
	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Voice Service failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Value for Voice Service Success!!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) ==
            DEVICE_SERVICES_VOICESERVICE) {
			//getting teh number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_VoiceService_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    fill_struct_param(pxTmpObj, pxVoiceService,
					      x_IFX_VMAPI_VoiceService_param,
					      nSize);
			CHECK_FOR_ERROR
			    ("Dump object data into struct for Voice Service failed");
			break;
		}
	}

	memset(pucProfileIdList, 0, sizeof(pucProfileIdList));
	memset(pucLineIdList, 0, sizeof(pucLineIdList));
	memset(pucDeviceList, 0, sizeof(pucDeviceList));
	/* Parse the ProfileId list */
	ifx_ParseCallBlockList(pxVoiceService->ucProfileIdList,
			       &pucProfileIdList[0][0], &ucNoOfProfiles);

	memset(pxVoiceService->ucProfileIdList, 0,
	       sizeof(pxVoiceService->ucProfileIdList));
	for (nIndex = 0; nIndex < ucNoOfProfiles; nIndex++) {
		pxVoiceService->ucProfileIdList[nIndex] =
		    atoi((char8 *) pucProfileIdList[nIndex]);
	}
	/* Parse the LineId list */
	ifx_ParseCallBlockList(pxVoiceService->ucLineIdList,
			       &pucLineIdList[0][0], &ucNoOfLines);
	memset(pxVoiceService->ucLineIdList, 0,
	       sizeof(pxVoiceService->ucLineIdList));
	for (nIndex = 0; nIndex < ucNoOfLines; nIndex++) {
		pxVoiceService->ucLineIdList[nIndex] =
		    atoi((char8 *) pucLineIdList[nIndex]);
	}

	/* Parse the DeviceId list */
	ifx_ParseCallBlockListDevice(&pxVoiceService->acDeviceList[0][0],
				     &pucDeviceList[0][0], &ucDevice);
	memset(pxVoiceService->acDeviceList, 0,
	       sizeof(pxVoiceService->acDeviceList));
	for (nIndex = 0; nIndex < ucDevice; nIndex++) {
		strcpy(pxVoiceService->acDeviceList[nIndex],
		       (pucDeviceList[nIndex]));
	}
    END:
	HELP_DELETE_MSG(&xObjHdr);

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_VoiceService function");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_VoiceCaps
*  Description    : Get api to get VoiceCapabilities object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxVoiceCaps - Pointer to VoiceCapabilities object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_VoiceCaps(x_IFX_VMAPI_VoiceCapabilities * pxVoiceCaps,
		      uint32 uiInFlag)
{
#if 0
	char sObjname[MAX_LEN_OBJNAME];
	int nSize;

	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	INIT_LIST_HEAD(&xObjHdr.xObjList.xOlist);

	xObjHdr.unMainOper = MOPT_GET;
	xObjHdr.unOwner = OWN_SERVD;
	strcpy(sObjname, "Device.Services.VoiceService.Capabilities");
	hlp_addObjList(&xObjHdr.xObjList, sObjname, NULL, NULL, NO_ARG_VALUE);
	cal_getValueWrapper(capi_getValue(&xObjHdr) xObjHdr,
		     capi_getValue(&xObjHdr) pxRespCode);
	//   hlp_printObjList(&xObjHdr);
	list_for_each_entry(pxTmpObj, &(xObjHdr.xObjList.xOlist), xOlist) {
		if (!strcmp(pxTmpObj->sObjName, sObjname)) {
			return 0;
		}
	}

#endif				//no member to fill
	return 0;

}

/******************************************************************************
*  Function Name  : ifx_get_VoiceSipCaps
*  Description    : Get api to get VoiceSipCapabilities object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxVoiceSipCaps - Pointer to VoiceSipCapabilities object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_VoiceSipCaps(x_IFX_VMAPI_VoiceSipCapabilities * pxVoiceSipCaps,
			 IN uint32 uiInFlag)
{
//no variable to fill.all are constants
	return 0;
}

/******************************************************************************
*  Function Name  : ifx_get_VoiceCodecCaps
*  Description    : Get api to get VoiceCodecCapabilities object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxVoiceCodecCaps - Pointer to VoiceCodecCapabilities object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t ifx_get_VoiceCodecCaps(
			       IN x_IFX_VMAPI_VoiceCodecCapabilities *
			       pxVoiceCodecCaps, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_VoiceCodecCaps function.");

	char sObjname[MAX_LEN_OBJNAME];
	int32_t uiErr = 0, nRetVal = IFX_VMAPI_SUCCESS;
	char *strTemp;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strncpy(sObjname, VOICE_SERVICE_CAPAB, sizeof(VOICE_SERVICE_CAPAB));
	ParamList *pxParam;
	

	x_IFX_VMAPI_CodecDesc *pxLocalCodecDesc = NULL;
	x_IFX_VMAPI_CodecDesc sTempCodecDesc;
	memset(&sTempCodecDesc, 0, sizeof(x_IFX_VMAPI_CodecDesc));

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Getting the Value */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for voice codec capabilties failed");

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get value of voice codec capabilties success!!!!");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_CAPABILITIES) {
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR, "Dumping capabilities.");

			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_CAPABILITIES_X_VENDOR_COM_FWSUPPCODEC)
				{
					pxVoiceCodecCaps->uiFwSuppCodec =
					    atoi(pxParam->sParamValue);
					break;
				}
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_CAPABILITIES_X_VENDOR_COM_NUMCODECS)
				{
					pxVoiceCodecCaps->uiNumCodecs =
					    atoi(pxParam->sParamValue);
					break;
				}
			}
		}
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_CAPABILITIES_CODECS) {
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Dumping codec capabilities.");
			pxLocalCodecDesc = NULL;
			memset(&sTempCodecDesc, 0,
			       sizeof(x_IFX_VMAPI_CodecDesc));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempCodecDesc.ucIndex = atoi(strTemp);
			//      sTempCodecDesc.ucLineId = pxVoiceCodecCaps->ucLineId;
			ifx_get_VoiceCodecCapsEntry(&sTempCodecDesc, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxVoiceCodecCaps->
					       pxCodecList,
					       (void *)&pxLocalCodecDesc,
					       sizeof(x_IFX_VMAPI_CodecDesc),
					       &uiErr);
			/* Copy the content in the new location */
			CHECK_FOR_NULL(pxLocalCodecDesc,
				       "Codec entry get failed");
			memcpy(pxLocalCodecDesc, &sTempCodecDesc,
			       sizeof(x_IFX_VMAPI_CodecDesc));
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Dumping codec entries success.");

#endif
		}
	}
   END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_VoiceCodecCaps function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_VoiceCodecCapsEntry
*  Description    : Get api to get VoiceCodecCapabilities object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxVoiceCodecCaps - Pointer to VoiceCodecCapabilities object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t ifx_get_VoiceCodecCapsEntry(OUT x_IFX_VMAPI_CodecDesc * pxVCCapsEntry,
				    IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_VoiceCodecCapsEntry function.");

	char sObjname[MAX_LEN_OBJNAME];
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32_t nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;

	/*Creating the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",VOICE_SERVICE_CODEC_CAPAB,pxVCCapsEntry->ucIndex);

	/*Creating the message header */
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	/*gETTING THE oBJECT */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	//nRetVal = capi_getValue(&xObjHdr);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for codec entry capability failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Value for Codec entry capability success !!!! \n");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_CAPABILITIES_CODECS) {
			nSize =
			    sizeof(x_IFX_VMAPI_CodecDesc_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    fill_struct_param(pxTmpObj, pxVCCapsEntry,
					      x_IFX_VMAPI_CodecDesc_param,
					      nSize);
			CHECK_FOR_ERROR
			    ("Dumping codec entry capability failed");
			break;

		}
	}
END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_VoiceCodecCapsEntry function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_VoicePhyInterface
*  Description    : Get api to get VoiceServPhyIf object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxVoiceServPhyIf - Pointer to the VoiceServPhyIf object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t ifx_get_VoicePhyInterface(x_IFX_VMAPI_VoiceServPhyIf * pxVoiceIf,
				  IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_VoicePhyInterface function.");

	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	/*Create Object name */
	 memset(sObjname, 0, sizeof(MAX_LEN_OBJNAME));
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",VOICE_SERVICE_PHYIF,pxVoiceIf->ucInterfaceId);

	/*Create Message header */
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/*Get the Phy if object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Phyif object value */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR
	    ("Get Value for VoiceService Physical Interface failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Value for VoiceService Physical Interface Success !!!! \n");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		//getting teh number of parameters
		nSize =
		    sizeof(x_IFX_VMAPI_VoiceServPhyIf_param) /
		    sizeof(x_IFX_Param);
		nRetVal =
		    fill_struct_param(pxTmpObj, pxVoiceIf,
				      x_IFX_VMAPI_VoiceServPhyIf_param,
				      nSize);
		CHECK_FOR_ERROR("Dumping VoiceSevice PhyIf failed");
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Dumping Value for VoiceService Physical Interface Success.");
		break;

	}
END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_VoicePhyInterface function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_VoiceProfile
*  Description    : Get api to get VoiceProfile object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxVoiceProfile - pointer to VoiceProfile object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_VoiceProfile(x_IFX_VMAPI_VoiceProfile * pxVoiceProfile,
			 uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_VoiceProfile function.");

	int nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj = NULL;
	int32_t nIndex = 0;
	uchar8 pucAssocLineId[IFX_IDLIST_MAX_LEN][IFX_IDLIST_MAX_LEN] =
	    { {0} };
	uchar8 ucNoOfAssoLines;
	/*Create message header */
	MsgHeader xObjHdr;
	

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_LEAFNODE, OWN_SERVD, 1);
	/*Get Voice Profile Object */
	HELP_OBJECT_GET(xObjHdr.pObjType, VOICE_SERVICE_VOICE_PROFILE,
			xObjHdr.unSubOper);

	/*Getting VoiceProfile object value */
	nRetVal = cal_getValueWrapper(&xObjHdr);

	CHECK_FOR_ERROR("Getting Voice Profile object val failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get value for Voice Profile Success !!!! \n");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE) {

			//getting teh number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_VoiceProfile_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    fill_struct_param(pxTmpObj, pxVoiceProfile,
					      x_IFX_VMAPI_VoiceProfile_param,
					      nSize);

			CHECK_FOR_ERROR
			    ("Dumping Voice Profile object val failed");

			/*Handling special params where the pram type is string in tr-104
			   but internaly we storing as different type */
			nRetVal =
			    HandleVoiceProSpclParams(pxTmpObj,
						     pxVoiceProfile);
			CHECK_FOR_ERROR
			    ("Handling Voice Profile object val failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Dumping value for Voice Profile Success.");

			ifx_ParseCallBlockList(pxVoiceProfile->aucAssoLineIds,
					       &pucAssocLineId[0][0],
					       &ucNoOfAssoLines);

			memset(pxVoiceProfile->aucAssoLineIds, 0,
			       sizeof(pxVoiceProfile->aucAssoLineIds));

			for (nIndex = 0; nIndex < ucNoOfAssoLines; nIndex++) {

				pxVoiceProfile->aucAssoLineIds[nIndex] =
				    atoi((char8 *) pucAssocLineId[nIndex]);
			}

			break;
		}

	}
END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_VoiceProfile function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_ProfileServiceProviderInfo
*  Description    : Get api to get ProfileServiceProviderInfo object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxServProviderInfo - pointer to ProfileServiceProviderInfo 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t
ifx_get_ProfileServiceProviderInfo(x_IFX_VMAPI_ProfileServiceProviderInfo *
				   pxServProviderInfo, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_ProfileServiceProviderInfo function.");

	int32_t nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	
	/*CREATE mESSAGE HEADER */
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/*Get Service provider object */
	HELP_OBJECT_GET(xObjHdr.pObjType, VOICE_PROFILE_SERVICEPROVIDERINFO,
			xObjHdr.unSubOper);

	/*Get Service provider object Value */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for Service provider object failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get value for Service provider object Success!!!! \n");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SERVICEPROVIDERINFO)
		{
			//getting teh number of parameters
			nSize =
			    sizeof
			    (x_IFX_VMAPI_ProfileServiceProviderInfo_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    fill_struct_param(pxTmpObj, pxServProviderInfo,
					      x_IFX_VMAPI_ProfileServiceProviderInfo_param,
					      nSize);
			CHECK_FOR_ERROR
			    ("Dump value for Service provider object failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Dump value for Service provider object Success.");

			break;
		}

	}
END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ProfileServiceProviderInfo function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_ProfileSignaling
*  Description    : Get api to get ProfileSignaling object.
*  Input Values   :
*                   uiInFlag - Input flags
*  Output Values  : pxProfileSignaling - pointer to ProfileSignaling object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_ProfileSignaling(x_IFX_VMAPI_ProfileSignaling *
			     pxProfileSignaling, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_ProfileServiceProviderInfo function.");
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, PROFILE_SIP, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Profile signalling failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {

		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP) {

			//getting teh number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_ProfileSignaling_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxProfileSignaling,
					  x_IFX_VMAPI_ProfileSignaling_param,
					  nSize);

			/*Handling special params where the pram type is string in tr-104
			   but internaly we storing as different type */
			HandleVoiceProSigSpclParams(pxTmpObj,
						    pxProfileSignaling);

			break;
		}
	}

    END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ProfileServiceProviderInfo function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_ProfileEventSubsTable
*  Description    : Get api to get ProfileEventSubsTable object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxProfileEventSubsTable - pointer to ProfileEventSubsTable 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_ProfileEventSubsTable(x_IFX_VMAPI_ProfileEventSubsTable *
				  pxProfileEventSubsTable, uint32 uiFlags)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_ProfileEventSubsTable function.");
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	ParamList *pxParam;
	char *strTemp;
	int32 uiErr;
	x_IFX_VMAPI_EventSubscribe *pxLocalEventSubscribe;
	x_IFX_VMAPI_EventSubscribe sTempEventSubscribe;
	
	int32_t nRetVal = UGW_SUCCESS;
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, PROFILE_SIP, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR
	    ("Get value for Profile event subscription table failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP) {
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_SIPEVENTSUBSCRIBENUMBEROFELEMENTS)
				{
					pxProfileEventSubsTable->
					    ucNoOfSubscrElements =
					    atoi(pxParam->sParamValue);
					break;
				}
			}

		}
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_EVENTSUBSCRIBE)
		{

			pxLocalEventSubscribe = NULL;
			memset(&sTempEventSubscribe, 0,
			       sizeof(x_IFX_VMAPI_EventSubscribe));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempEventSubscribe.ucIndex = atoi(strTemp);
			ifx_get_EventSubscribe(&sTempEventSubscribe, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)
					       &pxProfileEventSubsTable->
					       pxEventSubscribe,
					       (void *)&pxLocalEventSubscribe,
					       sizeof
					       (x_IFX_VMAPI_EventSubscribe),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalEventSubscribe != NULL)
				memcpy(pxLocalEventSubscribe,
				       &sTempEventSubscribe,
				       sizeof(x_IFX_VMAPI_EventSubscribe));
#endif
		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ProfileEventSubsTable function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_EventSubscribe
*  Description    : Get api to get EventSubscribe object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxEventSub - pointer to EventSubscribe object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_EventSubscribe(IN_OUT x_IFX_VMAPI_EventSubscribe * pxEventSub,
			   uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_EventSubscribe function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = UGW_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	memset(&xObjHdr, 0, sizeof(MsgHeader));
    
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",PROFILE_EVENTSUBSCRIBE,pxEventSub->ucIndex,".");

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value profile event subscribe failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_SIP_EVENTSUBSCRIBE) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_EventSubscribe_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxEventSub,
					  x_IFX_VMAPI_EventSubscribe_param,
					  nSize);
			HandleVoiceProEventSus(pxTmpObj, pxEventSub);
			break;

		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_EventSubscribe function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_ProfileMediaRTP
*  Description    : Get api to get ProfileMediaRTP object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxProfileMediaRTP - Pointert to ProfileMediaRTP object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_ProfileMediaRTP(x_IFX_VMAPI_ProfileMediaRTP * pxProfileMediaRTP,
			    uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_ProfileMediaRTP function.");
	//For getting the Older object
	int nSize, nRetVal = UGW_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, PROFILE_MEDIA_RTP,
			xObjHdr.unSubOper);
	

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for RTP failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_RTP) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_ProfileMediaRTP_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxProfileMediaRTP,
					  x_IFX_VMAPI_ProfileMediaRTP_param,
					  nSize);
			break;

		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ProfileMediaRTP function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_ProfileMediaRTCP
*  Description    : Get api to get ProfileMediaRTCP object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxProfileMediaRTP - Pointert to ProfileMediaRTCP object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_ProfileMediaRTCP(x_IFX_VMAPI_ProfileMediaRTCP *
			     pxProfileMediaRTCP, uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ProfileMediaRTCP function.");
	int nSize, nRetVal = UGW_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, PROFILE_MEDIA_RTCP,
			xObjHdr.unSubOper);
	

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for RTCP failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_RTP_RTCP) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_ProfileMediaRTCP_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxProfileMediaRTCP,
					  x_IFX_VMAPI_ProfileMediaRTCP_param,
					  nSize);
			break;
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ProfileMediaRTCP function.");
	return nRetVal;
}

#ifdef IIP
/******************************************************************************
*  Function Name  : ifx_get_ProfileMediaSecurity
*  Description    : Get api to get ProfileMediaSecurity object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxProfileMediaSecurity - Pointer to ProfileMediaSecurity
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_ProfileMediaSecurity(x_IFX_VMAPI_ProfileMediaSecurity *
				 pxProfileMediaSecurity, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_ProfileMediaSecurity function.");
	int nSize, nRetVal = UGW_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType,
			"Device.Services.VoiceService.1.VoiceProfile.1.RTP.SRTP",
			xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_RTP_SRTP) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_ProfileMediaSecurity_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxProfileMediaSecurity,
					  x_IFX_VMAPI_ProfileMediaSecurity_param,
					  nSize);
			HandleProfileMediaSec(pxTmpObj,
					      pxProfileMediaSecurity);
			break;
		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ProfileMediaSecurity function.");
	return nRetVal;
}
#endif

/******************************************************************************
*  Function Name  : ifx_get_NumPlan
*  Description    : Get api to get Numbering Plan object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxNumPlan - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_NumPlan(x_IFX_VMAPI_NumPlan * pxNumPlan, uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_NumPlan function.");
	int nSize, nRetVal = UGW_SUCCESS;
	char sObjname[MAX_LEN_OBJNAME];
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	char *strTemp;
	int32 uiErr;
	

	x_IFX_VMAPI_NumPlanRule *pxLocalNumPlanRule;
	x_IFX_VMAPI_NumPlanRule sTempNumPlanRule;

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	strncpy(sObjname, NUMBER_PLAN, sizeof(NUMBER_PLAN));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Number plan failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_NUMBERINGPLAN) {
			nSize =
			    sizeof(x_IFX_VMAPI_NumPlan_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxNumPlan,
					  x_IFX_VMAPI_NumPlan_param, nSize);

		}
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_NUMBERINGPLAN_PREFIXINFO)
		{
			pxLocalNumPlanRule = NULL;
			memset(&sTempNumPlanRule, 0,
			       sizeof(x_IFX_VMAPI_NumPlanRule));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempNumPlanRule.ucIndex = atoi(strTemp);
			ifx_get_NumPlanRule(&sTempNumPlanRule, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxNumPlan->
					       pxNumPlanRules,
					       (void *)&pxLocalNumPlanRule,
					       sizeof
					       (x_IFX_VMAPI_NumPlanRule),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalNumPlanRule != NULL)
				memcpy(pxLocalNumPlanRule, &sTempNumPlanRule,
				       sizeof(x_IFX_VMAPI_NumPlanRule));
#endif
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_NumPlan function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_NumPlanRule
*  Description    : Get api to get NumPlanRule object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxNumRule - pointer to NumPlanRule 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_NumPlanRule(x_IFX_VMAPI_NumPlanRule * pxNumRule, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_NumPlanRule function.");
	//For getting the Older object
	char sObjname[MAX_LEN_OBJNAME];
	int nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname, 0,MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",NUMBER_PLAN_RULE,pxNumRule->ucIndex);


	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for Number plan rule failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		//getting the number of parameters
		nSize =
		    sizeof(x_IFX_VMAPI_NumPlanRule_param) /
		    sizeof(x_IFX_Param);
		fill_struct_param(pxTmpObj, pxNumRule,
				  x_IFX_VMAPI_NumPlanRule_param, nSize);

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_NumPlanRule function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_ProfileMediaFax
*  Description    : Get api to get Fax T38 object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxFax - pointer to Fax object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_ProfileMediaFaxT38(IN x_IFX_VMAPI_FaxT38 * pxFax, uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ProfileMediaFaxT38 function.");

	//For getting the Older object
	char sObjname[MAX_LEN_OBJNAME];
	int nSize = 0, nRetVal = UGW_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	ParamList *pxParam;
	

	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strncpy(sObjname, FAX_T38, sizeof(FAX_T38));

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Faxt38 failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_FAXT38) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_FaxT38_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxFax,
					  x_IFX_VMAPI_FaxT38_param, nSize);

			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_FAXT38_TCFMETHOD)
				{
					if (!strncasecmp
					    (pxParam->sParamValue,
					     IFX_STRING_LOCAL,
					     sizeof(IFX_STRING_LOCAL)))
						pxFax->ucTCFMethodUdp =
						    IFX_VMAPI_FAX_RATE_MGMT_TCF_LCL;
					else if (!strncasecmp
						 (pxParam->sParamValue,
						  IFX_STRING_NETWORK,
						  sizeof(IFX_STRING_NETWORK)))
						pxFax->ucTCFMethodUdp =
						    IFX_VMAPI_FAX_RATE_MGMT_TCF_TRANS;
					break;
				}
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_FAXT38_X_VENDOR_COM_TCFMETHODTCP)
				{
					if (!strncasecmp
					    (pxParam->sParamValue,
					     IFX_STRING_LOCAL,
					     sizeof(IFX_STRING_LOCAL)))
						pxFax->ucTCFMethodTcp =
						    IFX_VMAPI_FAX_RATE_MGMT_TCF_LCL;
					else if (!strncasecmp
						 (pxParam->sParamValue,
						  IFX_STRING_NETWORK,
						  sizeof(IFX_STRING_NETWORK)))
						pxFax->ucTCFMethodTcp =
						    IFX_VMAPI_FAX_RATE_MGMT_TCF_TRANS;
					break;
				}
			}

		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ProfileMediaFaxT38 function.");
	return nRetVal;
}

int32_t ifx_get_HostIP(OUT char8 *pcHostIPv4, OUT char8 *pcHostIPv6)
{
	char sObjname[MAX_LEN_OBJNAME];
	int nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj = NULL;
	ParamList *pxParam = NULL;
	MsgHeader xObjHdr;
	int32_t found = 0, done = 0, status = 0;
	char8 *pcHostIP = NULL;
	
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_HostIP function!!!! \n");

	/* fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, "Device.PPP.Interface.");

again:
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("cal_get failed for given object");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Host IP Success !!!! \n");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (strlen(pxTmpObj->sObjName) - strlen(sObjname) < 4) {
			status = 0;
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if ((strcmp(pxParam->sParamName, "Status") == 0) && (strcasecmp(pxParam->sParamValue, "Up") == 0)){
					status = 1;
				}
				if ((status == 1) && (((strcmp(pxParam->sParamName, "X_LANTIQ_COM_DefaultGateway") == 0) && (strcasecmp(pxParam->sParamValue, "true") == 0)) 
				|| ((done == 2) && ((strcmp(pxParam->sParamName, "Name") == 0) && (strcasecmp(pxParam->sParamValue, "br-lan") == 0))))){
					found = 1;
					break;
				}
			}
		}
		if (found == 0) continue;

		if (strstr(pxTmpObj->sObjName, "IPv4Address") !=  NULL)
			pcHostIP = pcHostIPv4;
		else if (strstr(pxTmpObj->sObjName, "IPv6Address") !=  NULL)
			pcHostIP = pcHostIPv6;

		if (pcHostIP != NULL) {
			found++;
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (strcmp(pxParam->sParamName, "IPAddress") == 0) {
					if (status == 0)
						strcpy(pcHostIP,"0.0.0.0");
					else
						strcpy(pcHostIP,pxParam->sParamValue);
					break;
				}
			}
		}

		/* If all three objects, Interface, IPv4Address, and IPv6Address are traversed break*/
		if (found == 3) break;;
	}
		
	HELP_DELETE_MSG(&xObjHdr);

END:
	/* If all WANs are down, check for br-lan*/
	if (found == 0 && done < 2) {
		memset(sObjname, 0, MAX_LEN_OBJNAME);
		strcpy(sObjname, "Device.IP.Interface.");
		done++;
		goto again;
	}

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_HostIP function!!!! \n");
	return nRetVal;
}

int32_t ifx_get_DNSIP(OUT uint32_t *puiCount, OUT x_IFX_IP_ADDRESS **pxDNS)
{
	char sObjname[MAX_LEN_OBJNAME];
	int nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj = NULL;
	ParamList *pxParam = NULL;
	MsgHeader xObjHdr;
	int32_t found = 0;
	char sIfObj[MAX_LEN_OBJNAME] = {0};
	char sDefIfObj[MAX_LEN_OBJNAME] = {0};
	x_IFX_IP_ADDRESS xTempAddress;
	
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_DNSIP function!!!! \n");

	/* fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, "Device.IP.Interface.");

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for Interface failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (strlen(pxTmpObj->sObjName) - strlen(sObjname) < 4) {
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if ((strcmp(pxParam->sParamName, "X_LANTIQ_COM_DefaultGateway") == 0) && (strcasecmp(pxParam->sParamValue, "true") == 0)){
					strncpy(sDefIfObj, pxTmpObj->sObjName, MAX_LEN_OBJNAME);
					break;
				}
			}
		}
	}
	HELP_DELETE_MSG(&xObjHdr);

	/* fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, "Device.DNS.Relay.Forwarding.");

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for DNS IP failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for DNS IP Success !!!! \n");

	*puiCount = 0;
	*pxDNS = NULL;

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		found = 0;
		memset(&xTempAddress, 0, sizeof(xTempAddress));
		memset(sIfObj, 0, MAX_LEN_OBJNAME);
		FOR_EACH_PARAM(pxTmpObj, pxParam) {
			if ((strstr(pxParam->sParamName, "DNSServer") !=  NULL) && (strlen(pxParam->sParamValue) > 0) && (strcmp(pxParam->sParamValue, "0.0.0.0") != 0) ) {
				strncpy(xTempAddress.sIPAddress, pxParam->sParamValue, MAX_LEN_PARAM_VALUE);
				xTempAddress.eType = IFX_IP_ADDRESS_V4;
				found = 1;
			}
			if (found == 1 && (strstr(pxParam->sParamName, "Type") !=  NULL) ) {
				if (strstr(pxParam->sParamName, "v6") != NULL)
					xTempAddress.eType = IFX_IP_ADDRESS_V6;
			}
			if (found == 1 && (strstr(pxParam->sParamName, "Interface") !=  NULL) ) {
				strncpy(sIfObj, pxParam->sParamValue, MAX_LEN_PARAM_VALUE);
			}
		}

		if (strncmp(sDefIfObj, sIfObj, strlen(sDefIfObj)) == 0) {
			(*puiCount)++;
			*pxDNS = (x_IFX_IP_ADDRESS *) realloc((void *) *pxDNS, sizeof(x_IFX_IP_ADDRESS) * *puiCount);
			if (*pxDNS != NULL)
				memcpy((*pxDNS + *puiCount - 1), &xTempAddress, sizeof(x_IFX_IP_ADDRESS));
		}

	}
		
	HELP_DELETE_MSG(&xObjHdr);

END:
	if (*puiCount == 0) {
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 		"DNS Server not configured, returning 8.8.8.8 \n");
		(*puiCount)++;
		*pxDNS = (x_IFX_IP_ADDRESS *) realloc((void *) *pxDNS, sizeof(x_IFX_IP_ADDRESS) * *puiCount);
		if (*pxDNS != NULL) {
			(*pxDNS + *puiCount - 1)->eType = IFX_IP_ADDRESS_V4;
			strcpy((*pxDNS + *puiCount - 1)->sIPAddress, "8.8.8.8");
		}
	}

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_DNSIP function!!!! \n");
	return IFX_VMAPI_SUCCESS;
}
/******************************************************************************
*  Function Name  : ifx_get_VoiceLine
*  Description    : Get api to get VoiceLine object.
*  Input Values   :  pxVoiceLine - Pointer to VoiceLine object
*                    uiInFlag - Input flags
*  Output Values  : pxVoiceLine - pointer to ProfileSignaling object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t ifx_get_VoiceLine(x_IFX_VMAPI_VoiceLine * pxVoiceLine,
			  uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_VoiceLine function.");

	//For getting the Older objecti
	char sObjname[MAX_LEN_OBJNAME];
	int nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nIndex = 0;
	uchar8 pucPhyendptsList[IFX_IDLIST_MAX_LEN][IFX_IDLIST_MAX_LEN];
	uchar8 ucNoOfPhyendpts;

//      fill the instance number and create the object name
	memset(sObjname, 0, MAX_LEN_OBJNAME);

	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxVoiceLine->ucLineId,".");

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET,SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for Line failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Line Success !!!!");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_VoiceLine_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    fill_struct_param(pxTmpObj, pxVoiceLine,
					      x_IFX_VMAPI_VoiceLine_param,
					      nSize);
			CHECK_FOR_ERROR
			    ("Dumping line params value to sruct failed");

			nRetVal =
			    HandleVoiceLineParam(pxTmpObj, pxVoiceLine,
						 VOIP_GET);
			CHECK_FOR_ERROR("Handling line params value failed");

			ifx_ParseCallBlockList(pxVoiceLine->
					       ucAssocVoiceInterface,
					       &pucPhyendptsList[0][0],
					       &ucNoOfPhyendpts);

			memset(pxVoiceLine->ucAssocVoiceInterface, 0,
			       sizeof(pxVoiceLine->ucAssocVoiceInterface));
			for (nIndex = 0; nIndex < ucNoOfPhyendpts; nIndex++) {
//Ifndef DECT_SUPPORT
#if !defined(DECT_SUPPORT) && !defined(CVOIP_SUPPORT)
				if (nIndex > 1)
					break;
#endif
				pxVoiceLine->ucAssocVoiceInterface[nIndex] =
				    atoi((char8 *) pucPhyendptsList[nIndex]);

			}
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Dumping Line params to struct is Success.");

			break;

		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_VoiceLine function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_LineSubscription
*  Description    : Get api to get Line Subscription object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineSub - pointer to Line Subscription object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_LineSubscription(x_IFX_VMAPI_LineSubscription * pxLineSub,
			     uint32 uiInFlag)
{
    IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Enter ifx_get_LineSubscription function.");
	char sObjname[MAX_LEN_OBJNAME];

	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	char *strTemp;
	int32 uiErr;
	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	ParamList *pxParam;
	

	x_IFX_VMAPI_LineEvents *pxLocalLineEvents;
	x_IFX_VMAPI_LineEvents sTempLineEvents;

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxLineSub->ucLineId,LINE_SUBSCRIPTION);


	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for Line SIP failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {

		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SIP) {
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SIP_SIPEVENTSUBSCRIBENUMBEROFELEMENTS)
				{
					pxLineSub->ucNoOfLineEvents =
					    atoi(pxParam->sParamValue);
				}
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SIP_X_VENDOR_COM_MWIRETRIEVEUSRNAME)
				{

					strncpy(pxLineSub->
					       acMwiRetrieveUsrName,
					       pxParam->sParamValue,32);
					break;
				}
			}

		}
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SIP_EVENTSUBSCRIBE)
		{

			pxLocalLineEvents = NULL;
			memset(&sTempLineEvents, 0,
			       sizeof(x_IFX_VMAPI_LineEvents));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempLineEvents.ucIndex = atoi(strTemp);
			sTempLineEvents.ucLineId = pxLineSub->ucLineId;
			ifx_get_LineEvents(&sTempLineEvents, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxLineSub->
					       pxLineEvents,
					       (void *)&pxLocalLineEvents,
					       sizeof(x_IFX_VMAPI_LineEvents),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalLineEvents != NULL)
				memcpy(pxLocalLineEvents, &sTempLineEvents,
				       sizeof(x_IFX_VMAPI_LineEvents));
#endif
		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_LineSubscription function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_LineEvents
*  Description    : Get api to get Line Subscription object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineEvents - pointer to Line Subscription object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_LineEvents(x_IFX_VMAPI_LineEvents * pxLineEvents, uint32 uiInFlag)
{
    IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Enter ifx_get_LineEvents function.");
	char sObjname[MAX_LEN_OBJNAME];
	//char tempstr[10];
	int nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	memset(sObjname, 0, MAX_LEN_OBJNAME);
    
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d%s",VOICE_LINE,pxLineEvents->ucLineId,LINE_EVENT_SUSCRIBE,
						pxLineEvents->ucIndex,DOT);


	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for Line events failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SIP_EVENTSUBSCRIBE) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_LineEvents_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxLineEvents,
					  x_IFX_VMAPI_LineEvents_param,
					  nSize);
			HandleVoiceLineEvent(pxTmpObj, pxLineEvents,
					     VOIP_GET);
			break;

		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_LineEvents function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_LineCallingFeatures
*  Description    : Get api to get LineCallingFeatures object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineCallingFeatures - pointer to LineCallingFeatures 
*                    object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_LineCallingFeatures(x_IFX_VMAPI_LineCallingFeatures *
				pxLineCallingFeatures, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineCallingFeatures function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;

	//For getting the Older object
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	memset(sObjname, 0, MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxLineCallingFeatures->ucLineId,
                        CALLINGFEATURE);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for Line Calling Feature  failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_LineCallingFeatures_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxLineCallingFeatures,
					  x_IFX_VMAPI_LineCallingFeatures_param,
					  nSize);

			HandleVoiceLineCallingFeature(pxTmpObj,
						      pxLineCallingFeatures,
						      VOIP_GET);

			break;

		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_LineCallingFeatures function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_LineVoiceProcessing
*  Description    : Get api to get ProfileSignaling object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineVoiceProcessing - pointer to LineVoiceProcessing
*                    object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_LineVoiceProcessing(x_IFX_VMAPI_LineVoiceProcessing *
				pxLineVoiceProcessing, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineVoiceProcessing function.");
	char sObjname[MAX_LEN_OBJNAME];
	//char tempstr[10];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;

	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	memset(sObjname, 0, MAX_LEN_OBJNAME);

    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxLineVoiceProcessing->ucLineId,
                        VOICE_PROCESSING);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for Line Voice processing  failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_VOICEPROCESSING) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_LineVoiceProcessing_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxLineVoiceProcessing,
					  x_IFX_VMAPI_LineVoiceProcessing_param,
					  nSize);
			break;
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exitifx_get_LineVoiceProcessing function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_LineVoiceCodec
*  Description    : Get api to get LineVoiceCodec object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineVoiceCodec - pointer to LineVoiceCodec object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_LineVoiceCodec(x_IFX_VMAPI_LineCodec * pxLineVoiceCodec,
			   uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineVoiceCodec function.");
	char sObjname[MAX_LEN_OBJNAME];
	//char tempstr[10];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	

	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	memset(sObjname, 0, MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxLineVoiceCodec->ucLineId,
                        CODEC);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for Line Voice Codec  failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CODEC) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_LineCodec_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxLineVoiceCodec,
					  x_IFX_VMAPI_LineCodec_param, nSize);
			HandleVoiceLineCodec(pxTmpObj, pxLineVoiceCodec);
			break;

		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_LineVoiceCodec function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_add_CodecToList
*  Description    : Add codec to the list
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCodecList - pointer to LineCodecList objects.
*                   uiInFlag - Input flags
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_add_CodecToList(x_IFX_VMAPI_CodecDesc *pxTemp,x_IFX_VMAPI_LineCodecList * pxCodecList)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Enter ifx_add_CodecToList function.");
	 x_IFX_VMAPI_CodecDesc *pxCurr,*pxPrev;
	 x_IFX_VMAPI_CodecDesc *pxLocal;
         int32 uiErr;

	pxPrev=NULL;
	pxCurr= pxCodecList->pxCodecList;
	if(pxCurr==NULL){
__ifx_list_add_to_tail((void *)&pxCodecList->pxCodecList,
                     (void *)&pxLocal,
	                   sizeof(x_IFX_VMAPI_CodecDesc),&uiErr);
	  /* Copy the content in the new location */
			if(pxLocal != NULL)
		  memcpy(pxLocal,pxTemp,sizeof(x_IFX_VMAPI_CodecDesc));
	}
	else{
	  while(pxCurr != NULL)
	  {
		  if(pxCurr->ucPriority > pxTemp->ucPriority)
		  {
				if(pxPrev == NULL){
			    /* Allocates a memory of x_IFX_VMAPI_CodecDesc type and add to the linked list */
    __ifx_list_add_first((void *)&pxCodecList->pxCodecList,
	                       (void *)&pxLocal,
	                     sizeof(x_IFX_VMAPI_CodecDesc),&uiErr);
			    /* Copy the content in the new location */
			if(pxLocal != NULL)
			    memcpy(pxLocal,pxTemp,sizeof(x_IFX_VMAPI_CodecDesc));
				}
	      else{
			    /* Allocates a memory of x_IFX_VMAPI_CodecDesc type and add to the linked list */
    __ifx_list_add_front((void *)&pxPrev,
	                       (void *)&pxLocal,
	                     sizeof(x_IFX_VMAPI_CodecDesc),&uiErr);
			    /* Copy the content in the new location */
			    if(pxLocal != NULL)
					memcpy(pxLocal,pxTemp,sizeof(x_IFX_VMAPI_CodecDesc));
				}
				break;
		  }
		  else{
		    pxPrev = pxCurr;				
			  __ifx_list_GetNext((void *)&pxCurr);
	if(pxCurr==NULL){
      __ifx_list_add_to_tail((void *)&pxCodecList->pxCodecList,
                           (void *)&pxLocal,
	                         sizeof(x_IFX_VMAPI_CodecDesc),&uiErr);
	        /* Copy the content in the new location */
			    if(pxLocal != NULL)
	        memcpy(pxLocal,pxTemp,sizeof(x_IFX_VMAPI_CodecDesc));
	      }
		  }
	  }
	}

IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
                 "Exit ifx_add_CodecToList function.");
return IFX_VMAPI_SUCCESS; 
}

/******************************************************************************
*  Function Name  : ifx_get_LineCodecList
*  Description    : Get api to get LineCodecList objects for a given profile.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCodecList - pointer to LineCodecList objects. 
*                   uiInFlag - Input flags
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_LineCodecList(x_IFX_VMAPI_LineCodecList * pxCodecList,
			  uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineCodecList function.");
	char sObjname[MAX_LEN_OBJNAME];
	char *strTemp;
	int nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	ParamList *pxParam;
	MsgHeader xObjHdr;
	memset(sObjname, 0, MAX_LEN_OBJNAME);

    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxCodecList->ucLineId,
                        CODEC);
	

	x_IFX_VMAPI_CodecDesc sTempCodecDesc;

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Line Codec  list failed");
	//HELP_PRINT_MSG(&xObjHdr);
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CODEC) {

			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				/*if(pxParam->unParamId == )
				   {
				   pxCodecList->uiNumCodecs = atoi(pxParam->sParamValue);
				   break;
				   } */
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CODEC_X_VENDOR_COM_PREFG723CODEC)
				{
					pxCodecList->uiPrefG723Codec =
					    atoi(pxParam->sParamValue);
					break;
				}
			}
		}
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CODEC_LIST)
		{

			memset(&sTempCodecDesc, 0,
			       sizeof(x_IFX_VMAPI_CodecDesc));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempCodecDesc.ucIndex = atoi(strTemp);
			sTempCodecDesc.ucLineId = pxCodecList->ucLineId;
			ifx_get_CodecDesc(&sTempCodecDesc, 0);
			if(sTempCodecDesc.bEnable == IFX_TRUE)
			{
				ifx_add_CodecToList(&sTempCodecDesc,pxCodecList);		
			}
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_LineCodecList function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_CodecDesc
*  Description    : Get api to get CodecDesc objects for a given profile.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCodecList - pointer to CodecDesc objects. 
*                   uiInFlag - Input flags
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_CodecDesc(x_IFX_VMAPI_CodecDesc * pxCodecDesc, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_CodecDesc function.");
	char sObjname[MAX_LEN_OBJNAME];
	//char tempstr[10];
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	

	memset(sObjname, 0, MAX_LEN_OBJNAME);

    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d%s",VOICE_LINE,pxCodecDesc->ucLineId,
                        CODEC_LIST,pxCodecDesc->ucIndex,DOT);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Codec Description failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		// if(!strcmp(pxTmpObj->sObjName,sObjname))
		{

			nSize =
			    sizeof(x_IFX_VMAPI_CodecDesc_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxCodecDesc,
					  x_IFX_VMAPI_CodecDesc_param, nSize);

			break;

		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_CodecDesc function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_LineStats
*  Description    : Get api to get Line Statistics object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineStats - pointer to VoiceProfile object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_LineStats(x_IFX_VMAPI_LineStats * pxLineStats, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineStats function.");
	char sObjname[MAX_LEN_OBJNAME];
	//char tempstr[10];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;

	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	memset(sObjname, 0, MAX_LEN_OBJNAME);
    
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxLineStats->ucLineId,
                        LINE_STATS);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for LineStats failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_STATS) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_LineStats_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxLineStats,
					  x_IFX_VMAPI_LineStats_param, nSize);
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_LineStats function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_LineVoiceSession
*  Description    : Get api to get LineVoiceSession object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineVoiceSession - pointer to LineVoiceSession object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_LineVoiceSession(x_IFX_VMAPI_LineSession * pxLineVoiceSession,
			     uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineVoiceSession function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;

	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	xObjHdr.unMainOper = MOPT_GET;
	xObjHdr.unOwner = OWN_SERVD;
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d",VOICE_LINE,pxLineVoiceSession->ucLineId,
                       LINE_SESSION,1);

	

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Line Voice Session failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SESSION) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_LineSession_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxLineVoiceSession,
					  x_IFX_VMAPI_LineSession_param,
					  nSize);
			break;
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_LineVoiceSession function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_LineSignaling
*  Description    : Get api to get LineSignaling object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxLineSignaling - pointer to LineSignaling object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_LineSignaling(x_IFX_VMAPI_LineSignaling * pxLineSignaling,
			  uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineSignaling function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32 uiErr;
	int nRetVal = IFX_VMAPI_SUCCESS;
	int32_t nSize = 0;

	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32_t ucLineID = pxLineSignaling->ucLineId;	

	memset(sObjname, 0, MAX_LEN_OBJNAME);

    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxLineSignaling->ucLineId,
                       LINE_SUBSCRIPTION);


	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Line Signalling failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SIP) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_LineSignaling_param) /
			    sizeof(x_IFX_Param);
			//Dump Sip info
			fill_struct_param(pxTmpObj, pxLineSignaling,
					  x_IFX_VMAPI_LineSignaling_param,
					  nSize);
			pxLineSignaling->ucNoOfSipAuthCfg = 1;

			//Dump AuthConfig
			x_IFX_VMAPI_SipAuthCfg *pxLocalpxAuthCfg = NULL;
			x_IFX_VMAPI_SipAuthCfg sTempAuthCfg;
			memset(&sTempAuthCfg, 0,
			       sizeof(x_IFX_VMAPI_SipAuthCfg));
			sTempAuthCfg.ucLineId = ucLineID;

			ifx_get_AuthCfg(&sTempAuthCfg, 0);

#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxLineSignaling->
					       pxAuthCfg,
					       (void *)&pxLocalpxAuthCfg,
					       sizeof(x_IFX_VMAPI_SipAuthCfg),
					       &uiErr);

			/* Copy the content in the new location */
			if (pxLocalpxAuthCfg != NULL)
				memcpy(pxLocalpxAuthCfg, &sTempAuthCfg,
				       sizeof(x_IFX_VMAPI_SipAuthCfg));

#endif

		}
		//it was set to null in the existing get function so set to null for now
		//pxLineSignaling->pxAuthCfg = NULL;

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_LineSignaling function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_AuthCfg
*  Description    : Get api to get AuthCfg object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxAuthCfg - pointer to Line Subscription object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_AuthCfg(x_IFX_VMAPI_SipAuthCfg * pxAuthCfg, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_AuthCfg function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	char8 *pcSipUri = "";
	ParamList *pxParam;

	ObjList *pxTmpObj;
	MsgHeader xObjHdr;

    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxAuthCfg->ucLineId,
                       LINE_SUBSCRIPTION);
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Auth Cfg failed");
	
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SIP) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_SipAuthCfg_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxAuthCfg,
					  x_IFX_VMAPI_SipAuthCfg_param,
					  nSize);
			//parsing and getting the host name from URI
			list_for_each_entry(pxParam,
					    &(pxTmpObj->xParamList.xPlist),
					    xPlist) {
				if (0 == strcmp(pxParam->sParamName, "URI")) {
					pcSipUri = pxParam->sParamValue;
					if (strncmp(pcSipUri, "sip:", 4) == 0) {
						pcSipUri += 4;
					} else
					    if (strncmp(pcSipUri, "sips:", 5)
						== 0) {
						pcSipUri += 5;

					}
					//IFX_SipUri_GetHostName(pcSipUri, acHostName);	//Facing crash
					//strcpy(pxAuthCfg->acRealm,
					 //      acHostName);
					break;

				}
			}
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_AuthCfg function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_ParseCallBlockList
*  Description    : Parses comma separated list
*  Input Values   : ucSrc - comma separated list
*  Output Values  : ucDestList - output list
*					iLength - Number of element in the list
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int
ifx_ParseCallBlockList(uchar8 * ucSrc, uchar8 * ucDestList, uchar8 * iLength)
{

	int32 nIndex = 0, i = 0, j = 0;
	while (ucSrc[nIndex] != '\0')
	{
		if (ucSrc[nIndex] != ',')
		{
			*(ucDestList + (i * 20) + j) = ucSrc[nIndex];

			j++;
		}

		else
		{
			*(ucDestList + (i * 20) + j) = '\0';
			i++;
			j = 0;
		}
		nIndex++;
	}
	*iLength = i + 1;

	return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_ParseCallBlockListDevice
*  Description    : Parses comma separated device list
*  Input Values   : ucSrc - comma separated list
*  Output Values  : ucDestList - output list
*					iLength - Number of element in the list
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int
ifx_ParseCallBlockListDevice(char8 * ucSrc, char8 * ucDestList,
			     uchar8 * iLength)
{
	int32 nIndex = 0, i = 0, j = 0;
	while (ucSrc[nIndex] != '\0')
	{
		if (ucSrc[nIndex] != ',')
		{
			*(ucDestList + (i * 20) + j) = ucSrc[nIndex];
			j++;
		}

		else
		{
			*(ucDestList + (i * 20) + j) = '\0';
			i++;
			j = 0;
		}
		nIndex++;
	}
	*iLength = i + 1;
	return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : HandleFxoPhyInterface
*  Description    : get/set api to handle voiceline params for which data type 
*					differs in DB and internal data structure
*					 
*  Input Values   : pxTmpObj - DB object list
*					nOperation -GET/SET operation			
*  Output Values  : pxFxoPhyIf - Fxo structure
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int HandleFxoPhyInterface(ObjList * pxTmpObj,
			  x_IFX_VMAPI_FxoPhyIf * pxFxoPhyIf,
			  int32_t nOperation)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleFxoPhyInterface function.");
	ParamList *pxParam;
	uchar8 pucFxoendptsList[IFX_IDLIST_MAX_LEN][IFX_IDLIST_MAX_LEN] =
	    { {0} };
	uchar8 ucNoOfFxoendpts;
	char8 acAssInte[2*IFX_VMAPI_MAX_PHY_ENDPTS] = { '\0' };
	int32_t nIndex = 0, nTempIndex = 0;
	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxTmpObj, "Error : Fxo DB Object is NULL");
	CHECK_FOR_NULL(pxFxoPhyIf, "Error : Fxo struct is null");

	FOR_EACH_PARAM(pxTmpObj, pxParam) {
		switch (pxParam->unParamId) {
		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_STATE:
			if (nOperation == VOIP_GET)
			{
				if (!strncmp
				    (pxParam->sParamValue, IFX_STRING_ENABLED,
				     strlen(IFX_STRING_ENABLED)))
					pxFxoPhyIf->ucState =
					    IFX_VMAPI_PSTN_LINE_STATE_ENABLED;
				else if (!strncmp
					 (pxParam->sParamValue,
					  IFX_STRING_DISABLED,
					  strlen(IFX_STRING_DISABLED)))
					pxFxoPhyIf->ucState =
					    IFX_VMAPI_PSTN_LINE_STATE_DISABLED;
			} else if (nOperation == VOIP_SET) {
				if (pxFxoPhyIf->ucState ==
				    IFX_VMAPI_PSTN_LINE_STATE_ENABLED)
					strncpy(pxParam->sParamValue,
						IFX_STRING_ENABLED,
						strlen(IFX_STRING_ENABLED));
				else if (pxFxoPhyIf->ucState ==
					 IFX_VMAPI_PSTN_LINE_STATE_DISABLED)
					strncpy(pxParam->sParamValue,
						IFX_STRING_DISABLED,
						strlen(IFX_STRING_DISABLED));
			}
			break;
		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_INTERFACEIDLIST:
			if (nOperation ==
			    VOIP_GET) {
				memset(&pucFxoendptsList, 0,
				       sizeof(pucFxoendptsList));
				ifx_ParseCallBlockList(pxFxoPhyIf->
						       ucInterfaceIdList,
						       &pucFxoendptsList[0]
						       [0], &ucNoOfFxoendpts);

				memset(pxFxoPhyIf->ucInterfaceIdList, 0,
				       sizeof(pxFxoPhyIf->ucInterfaceIdList));
				for (nIndex = 0; nIndex < ucNoOfFxoendpts;
				     nIndex++) {
//#ifndef DECT_SUPPORT
#if !defined(DECT_SUPPORT) && !defined(CVOIP_SUPPORT)
					if (nIndex > 1)
						break;
#endif
					pxFxoPhyIf->
					    ucInterfaceIdList[nIndex] =
					    atoi((char8 *)
						 pucFxoendptsList[nIndex]);

				}
			} else if (nOperation == VOIP_SET) {
				/* Creating comma separated List */
				while (pxFxoPhyIf->
				       ucInterfaceIdList[nIndex] != 0) {

					snprintf(&acAssInte[nTempIndex],sizeof(acAssInte), "%d%s",
						pxFxoPhyIf->ucInterfaceIdList[nIndex],",");

					nTempIndex = strlen(acAssInte);
					nIndex++;
				}
				strncpy(pxParam->sParamValue, acAssInte,
					sizeof(pxFxoPhyIf->
					       ucInterfaceIdList));

			}
			break;
		}
	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleFxoPhyInterface function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_FxoPhyInterface
*  Description    : Get api to get FXO object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxFxoPhyIf - pointer to FXO object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_FxoPhyInterface(x_IFX_VMAPI_FxoPhyIf * pxFxoPhyIf,
			    uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_FxoPhyInterface function.");
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, FXO_INTERFACE, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Fxo interface failed");

	// HELP_PRINT_MSG(&xObjHdr);
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_VOICESERVPHYIF))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_FxoPhyIf_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxFxoPhyIf,
					  x_IFX_VMAPI_FxoPhyIf_param, nSize);
			if (GET_OBJ_OID(pxTmpObj) ==
			    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF)
				HandleFxoPhyInterface(pxTmpObj, pxFxoPhyIf,
						      VOIP_GET);

			pxFxoPhyIf->xVoiceServPhyIf.ucPortType =
			    IFX_VMAPI_VOICE_PORT_TYPE_FXO;
		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_FxoPhyInterface function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_FxsPhyIf
*  Description    : Get api to get FXS object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxFxsPhyIf - pointer to FXS object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_FxsPhyInterface(x_IFX_VMAPI_FxsPhyIf * pxFxsPhyIf,
			    uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_FxsPhyInterface function.");
	int nSize;
	// ParamList *pxParam;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	char sObjname[MAX_LEN_OBJNAME];
	int32 nIndex = 0, nRetVal = IFX_VMAPI_SUCCESS;
	uchar8 pucFxsendptsList[IFX_IDLIST_MAX_LEN][IFX_IDLIST_MAX_LEN];
	uchar8 ucNoOfFxsendpts;
	
	memset(sObjname,0, MAX_LEN_OBJNAME);

    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",FXS_INTERFACE,pxFxsPhyIf->xVoiceServPhyIf.ucInterfaceId);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Fxs interface failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXSPHYIF)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXSPHYIF_X_VENDOR_COM_VOICESERVPHYIF))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_FxsPhyIf_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxFxsPhyIf,
					  x_IFX_VMAPI_FxsPhyIf_param, nSize);
			//Setting port type FXS
			pxFxsPhyIf->xVoiceServPhyIf.ucPortType =
			    IFX_VMAPI_VOICE_PORT_TYPE_FXS;

		}
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXSPHYIF) {
			//parsing the voiceline ID List
			memset(&pucFxsendptsList, 0,
			       sizeof(pucFxsendptsList));
			ifx_ParseCallBlockList(pxFxsPhyIf->ucVoiceLineIdList,
					       &pucFxsendptsList[0][0],
					       &ucNoOfFxsendpts);

			memset(pxFxsPhyIf->ucVoiceLineIdList, 0,
			       sizeof(pxFxsPhyIf->ucVoiceLineIdList));
			for (nIndex = 0; nIndex < ucNoOfFxsendpts; nIndex++) {
				pxFxsPhyIf->ucVoiceLineIdList[nIndex] =
				    atoi((char8 *) pucFxsendptsList[nIndex]);
			}

		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_FxsPhyInterface function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleDectHandsetParam
*  Description    : get/set api to handle Dect Handset for which data type 
*					differs in DB and internal data structure
*					 
*  Input Values   : pxTmpObj - DB object list
*					nOperation -GET/SET operation			
*  Output Values  : pxDectHand - DectHandset data
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int HandleDectHandsetParam(ObjList * pxTmpObj,
			   x_IFX_VMAPI_DectHandset * pxDectHand,
			   int32_t nOperation)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleDectHandsetParam function.");
	ParamList *pxParam;
	uchar8 pucDectLineIdList[20][20];
	uchar8 ucNoOfDectLineId;
	int32_t nIndex = 0, nTempIndex = 0, nRetVal = IFX_VMAPI_SUCCESS;
	char8 acAssInte[2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES + 1] = { '\0' };

	CHECK_FOR_NULL(pxTmpObj, "Error :  DectHandset Object is NULL");
	CHECK_FOR_NULL(pxDectHand,
		       "Error :  DectHandset struct Object is NULL");

	FOR_EACH_PARAM(pxTmpObj, pxParam) {
		if (pxParam->unParamId ==
		    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET_X_VENDOR_COM_VOICELINEIDLIST)
		{
			if (nOperation == VOIP_GET) {
				memset(&pucDectLineIdList, 0,
				       sizeof(pucDectLineIdList));
				ifx_ParseCallBlockList(pxDectHand->
						       aucVoiceLineIdList,
						       &pucDectLineIdList[0]
						       [0],
						       &ucNoOfDectLineId);

				memset(pxDectHand->aucVoiceLineIdList, 0,
				       sizeof(pxDectHand->
					      aucVoiceLineIdList));
				for (nIndex = 0; nIndex < ucNoOfDectLineId;
				     nIndex++) {
					pxDectHand->
					    aucVoiceLineIdList[nIndex] =
					    atoi((char8 *)
						 pucDectLineIdList[nIndex]);

				}
			} else if (nOperation == VOIP_SET) {
				/*Creating the comma separed list for associated interface */
				while (pxDectHand->
				       aucVoiceLineIdList[nIndex] != 0) {
					snprintf(&acAssInte[nTempIndex],sizeof(acAssInte),"%d%s",
						pxDectHand->aucVoiceLineIdList[nIndex],",");
					//strcat(acAssInte, ",");
					nTempIndex = strlen(acAssInte);
					nIndex++;
				}
		        strncpy(pxParam->sParamValue,
                        acAssInte,
                        sizeof(pxDectHand->
                               aucVoiceLineIdList));
			}

			break;
		}
	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleDectHandsetParam function.");
	return nRetVal;
}


#ifdef DECT_REPEATER
/******************************************************************************
*  Function Name  : ifx_set_DectRepeater
*  Description    : Set api to set Repeater Object.
q
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDectInf - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_DectRepeater(IN uint32 uiOperation,
			    IN x_IFX_VMAPI_DectRepeater * pxDecRep,
			    IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_DectRepeater function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	int32_t nInstanceNo = 0;
	
	x_IFX_VMAPI_DectRepeater xOldDectRepeater;
	memset(&xOldDectRepeater, 0,sizeof(x_IFX_VMAPI_DectRepeater));

	CHECK_FOR_NULL(pxDecRep,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
    memset(&sObjname, 0, MAX_LEN_OBJNAME);
	nInstanceNo = atoi((char*)pxDecRep->ucEndPtId) - 8;
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",DECT_REPEATER_PATH,nInstanceNo);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect Repeater  failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect Repeater success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECT_REPEATER) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_DectRepeater_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxDecRep,
						x_IFX_VMAPI_DectRepeater_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Dect Repeater param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Dect Repeater in object list Success !!!!");


			/*Getting the old object */
			strncpy((char*)xOldDectRepeater.ucEndPtId,(char*)pxDecRep->ucEndPtId,sizeof(pxDecRep->ucEndPtId));
			nRetVal = ifx_get_DectRepeater(&xOldDectRepeater, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing DectSystem Object failed");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR("Wrting Repeater Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Wrting Line Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_DECT_REPEATER,
				     (void *)&xOldDectRepeater,
				     (void *)pxDecRep);
				CHECK_FOR_ERROR
				    ("Sending Notification for Dect Repeater object change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for Dect Repeater change Success!!!! \n");

			}
			break;
		}
	}

END:
    if(xOldDectRepeater.pxSubsInfo != NULL){
        ifx_vmapi_freeObjectList(&xOldDectRepeater,IFX_VMAPI_DECT_REPEATER);
    }
    if(pxDecRep->pxSubsInfo != NULL){
	/*TODO: Facing crash issue here*/
        //ifx_vmapi_freeObjectList(pxDecRep,IFX_VMAPI_DECT_REPEATER);
    }

	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_DectRepeater function.");

	return nRetVal;

}
/******************************************************************************
*  Function Name  : ifx_get_DectRepeater
*  Description    : Get api to get Dect Repeater  object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxNumPlan - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_DectRepeater(x_IFX_VMAPI_DectRepeater * pxRepeater, uint32 uiInFlag)
{

    IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Enter ifx_get_DectRepeater function.");
    int nSize, nRetVal = UGW_SUCCESS;
    char sObjname[MAX_LEN_OBJNAME];
    ObjList *pxTmpObj;
    MsgHeader xObjHdr;
    char *strTemp;
    int32 uiErr;
	int32 nInstanceNo = 0;


    x_IFX_VMAPI_DectSubsInfo *pxLocalRepeaterSusInfo;
    x_IFX_VMAPI_DectSubsInfo sTempRepeaterSusInfo;

    memset(&xObjHdr, 0, sizeof(MsgHeader));
    memset(&sObjname, 0, MAX_LEN_OBJNAME);
	nInstanceNo = atoi((char*)pxRepeater->ucEndPtId) - 8;
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",DECT_REPEATER_PATH,nInstanceNo);
	
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
    HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
    nRetVal = cal_getValueWrapper(&xObjHdr);
    CHECK_FOR_ERROR("Get Value for Dect Repeater failed");
    FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECT_REPEATER) {
            nSize =
                sizeof(x_IFX_VMAPI_DectRepeater_param) /
                sizeof(x_IFX_Param);
            fill_struct_param(pxTmpObj, pxRepeater,
                      x_IFX_VMAPI_DectRepeater_param, nSize);

        }
        if (GET_OBJ_OID(pxTmpObj) ==
            DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECT_REPEATER_X_VENDOR_COM_DECTSUBSINFO)
        {
            pxLocalRepeaterSusInfo = NULL;
            memset(&sTempRepeaterSusInfo, 0,
                   sizeof(x_IFX_VMAPI_DectSubsInfo));
            strTemp = strrchr(pxTmpObj->sObjName, '.'); //get the last occurence of '.'
            strTemp++;
			ifx_get_DectRepeaterSubs(&sTempRepeaterSusInfo,nInstanceNo,atoi(strTemp));
#ifdef __LINUX__
            __ifx_list_add_to_tail((void *)&pxRepeater->
                           pxSubsInfo,
                           (void *)&pxLocalRepeaterSusInfo,
                           sizeof
                           (x_IFX_VMAPI_DectSubsInfo),
                           &uiErr);
            /* Copy the content in the new location */
            if (pxLocalRepeaterSusInfo != NULL)
                memcpy(pxLocalRepeaterSusInfo, &sTempRepeaterSusInfo,
                       sizeof(x_IFX_VMAPI_DectSubsInfo));
#endif
        }

    }

      END:
    HELP_DELETE_MSG(&xObjHdr);
    IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Exit ifx_get_DectRepeater function.");
    return nRetVal;
}


int ifx_set_DectRepeaterSubs(x_IFX_VMAPI_DectSubsInfo * pxDectRep, IN uchar8 ucEndptId, uint32 uiInstanceId)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_DectRepeaterSubs function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxDectRep,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
        memset(sObjname,0,MAX_LEN_OBJNAME);
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d","Device.Services.VoiceService.1.X_VENDOR_COM_Dect_Repeater.",
		ucEndptId,".X_VENDOR_COM_DectSubsInfo.", uiInstanceId);


	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET,SOPT_OBJVALUE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect SubsInfo failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect SubsInfo success !!!! \n");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
	        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECT_REPEATER_X_VENDOR_COM_DECTSUBSINFO) {
                        nSize =
                            sizeof(x_IFX_VMAPI_DectSubsInfo_param) /
                            sizeof(x_IFX_Param);

                        nRetVal =
                            UpdateParamValueInDB(pxTmpObj,
                                                 pxDectRep,
                                                 x_IFX_VMAPI_DectSubsInfo_param,
                                                 nSize);
						
                        CHECK_FOR_ERROR
                            ("Updating the calling feature param value in Object list failed");

			}
			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;
	
			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Dect Rfpi Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Dect SusbInfo Object to DB Success !!!!");
			break;
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_DectRepeaterSubs function.");

	return nRetVal;

}
int ifx_get_DectRepeaterSubs(x_IFX_VMAPI_DectSubsInfo * pxDectRep, IN uchar8 ucEndptId ,uint32 uiInstanceId)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_DectRepeaterSubs function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d","Device.Services.VoiceService.1.X_VENDOR_COM_Dect_Repeater.", 
			ucEndptId,".X_VENDOR_COM_DectSubsInfo.",uiInstanceId);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect Repeater failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECT_REPEATER_X_VENDOR_COM_DECTSUBSINFO))
		{
                        nSize =
                            sizeof(x_IFX_VMAPI_DectSubsInfo_param) /
                            sizeof(x_IFX_Param);


                        fill_struct_param(pxTmpObj,pxDectRep,
                                          x_IFX_VMAPI_DectSubsInfo_param,
                                          nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_DectRepeaterSubs function.");
	return nRetVal;
}
#endif




int ifx_get_DectHandset(x_IFX_VMAPI_DectHandset * pxDectHand, uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_DectHandset function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",DECT_HANDSET,(pxDectHand->xVoiceServPhyIf.ucInterfaceId - 3));

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect Handset failed");

	//HELP_PRINT_MSG(&xObjHdr);

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET_X_VENDOR_COM_DECTSUBSINFO)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET_X_VENDOR_COM_VOICESERVPHYIF))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_DectHandset_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxDectHand,
					  x_IFX_VMAPI_DectHandset_param,
					  nSize);
			pxDectHand->xVoiceServPhyIf.ucPortType =
			    IFX_VMAPI_VOICE_PORT_TYPE_DECT;

		}
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET)
		{
			/*HandleDectHandsetParam(pxTmpObj, pxDectHand,
					       VOIP_GET);*/
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_DectHandset function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleDectCodecDes
*  Description    : get/set api to handle Dect codec for which data type 
*					differs in DB and internal data structure			 
*  Input Values   : pxTmpObj - DB object list			
*  Output Values  : pCodecDesc - DectHandset codec description
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int HandleDectCodecDes(ObjList * pxTmpObj,
		       x_IFX_VMAPI_DectCodecDesc * pCodecDesc)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleDectCodecDes function.");
	ParamList *pxParam = NULL;
	int iTemp;
	FOR_EACH_PARAM(pxTmpObj, pxParam) {
		switch (pxParam->unParamId) {
		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTCODECDESC_X_VENDOR_COM_CODECSUPPFRAMELEN:
			iTemp =
			    atoi(pxParam->sParamValue);
			if (iTemp == 5)
				pCodecDesc->unCodecSuppFrameLen =
				    IFX_VMAPI_CODEC_FRAME_LEN_5;
			else if (iTemp == 10)
				pCodecDesc->unCodecSuppFrameLen =
				    IFX_VMAPI_CODEC_FRAME_LEN_10;
			else if (iTemp == 20)
				pCodecDesc->unCodecSuppFrameLen =
				    IFX_VMAPI_CODEC_FRAME_LEN_20;
			else if (iTemp == 30)
				pCodecDesc->unCodecSuppFrameLen =
				    IFX_VMAPI_CODEC_FRAME_LEN_30;
			else if (iTemp == 40)
				pCodecDesc->unCodecSuppFrameLen =
				    IFX_VMAPI_CODEC_FRAME_LEN_40;
			else if (iTemp == 50)
				pCodecDesc->unCodecSuppFrameLen =
				    IFX_VMAPI_CODEC_FRAME_LEN_50;
			else if (iTemp == 60)
				pCodecDesc->unCodecSuppFrameLen =
				    IFX_VMAPI_CODEC_FRAME_LEN_60;
			break;
		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTCODECDESC_X_VENDOR_COM_CODECID:
			 pCodecDesc->uiCodecId = atoi(pxParam->sParamValue);
			break;
		
		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTCODECDESC_X_VENDOR_COM_CODECNAME:
			strncpy(pCodecDesc->acCodecName,
			       pxParam->sParamValue,32);

		}
	}

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleDectCodecDes function.");
	return IFX_VMAPI_SUCCESS;

}

/******************************************************************************
*  Function Name  : ifx_get_DectInterface
*  Description    : Get api to get VoiceProfile object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxDectInf - pointer to Dect Interface object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_DectInterface(IN_OUT x_IFX_VMAPI_DectSystem * pxDectInf,
			    IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Entering Function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	char *strTemp;
	

	x_IFX_VMAPI_DectHandset *pxLocalHandSet;
	x_IFX_VMAPI_DectHandset sTempDectHandset;

	x_IFX_VMAPI_DectCodecDesc sTempDectCodecDesc;
	x_IFX_VMAPI_CodecDesc *pxLocalCodec;
	int32 uiErr;
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, DECT_INTERFACE, sizeof(DECT_INTERFACE));
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect Interface failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM)) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_DectSystem_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxDectInf,
					  x_IFX_VMAPI_DectSystem_param,
					  nSize);
		}
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET)
		{
			pxLocalHandSet = NULL;
			memset(&sTempDectHandset, 0,
			       sizeof(x_IFX_VMAPI_DectHandset));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			int var = atoi(strTemp);
			sTempDectHandset.xVoiceServPhyIf.ucInterfaceId =
			    var + 3;
			ifx_get_DectHandset(&sTempDectHandset, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxDectInf->
					       pxHandsetTbl,
					       (void *)&pxLocalHandSet,
					       sizeof
					       (x_IFX_VMAPI_DectHandset),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalHandSet != NULL)
				memcpy(pxLocalHandSet, &sTempDectHandset,
				       sizeof(x_IFX_VMAPI_DectHandset));
#endif
		}
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTCODECDESC)
		{
			pxLocalCodec = NULL;
			memset(&sTempDectCodecDesc, 0,
			       sizeof(x_IFX_VMAPI_DectCodecDesc));

			//fill the structure

			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_DectCodecDesc_param) /
			    sizeof(x_IFX_Param);
			//fill_struct_param(pxTmpObj,&sTempDectCodecDesc,x_IFX_VMAPI_DectCodecDesc_param,nSize);

			HandleDectCodecDes(pxTmpObj, &sTempDectCodecDesc);

			__ifx_list_add_to_tail((void *)&pxDectInf->
					       pxCodecList,
					       (void *)&pxLocalCodec,
					       sizeof
					       (x_IFX_VMAPI_DectCodecDesc),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalCodec != NULL)
				memcpy(pxLocalCodec, &sTempDectCodecDesc,
				       sizeof(x_IFX_VMAPI_DectCodecDesc));
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_DectInterface function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_CallBlockEntry
*  Description    : Get api to get Call Block object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCallBlk - pointer to Call Block 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_CallBlockEntry(x_IFX_VMAPI_CallBlockEntry * pxCallBlkEntry,
			   uint32 uiFlags)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_CallBlockEntry function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",CALL_BLK_ENTRY,pxCallBlkEntry->ucIndex);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Call Block entry failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_CALLBLOCK_X_VENDOR_COM_CALLBLOCKENTRY))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_CallBlockEntry_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxCallBlkEntry,
					  x_IFX_VMAPI_CallBlockEntry_param,
					  nSize);

		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_CallBlockEntry function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_CallBlock
*  Description    : Get api to get Call Block object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxCallBlk - pointer to Call Block 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_CallBlock(x_IFX_VMAPI_CallBlock * pxCallBlk, uint32 uiFlags)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_CallBlock function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 uiErr;
	

	x_IFX_VMAPI_CallBlockEntry *pxLocalCallBlkEntry;
	x_IFX_VMAPI_CallBlockEntry sTempCallBlockEntry;
	char *strTemp;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, CALL_BLOCK, sizeof(CALL_BLOCK));

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for C failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_CALLBLOCK)) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_CallBlock_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxCallBlk,
					  x_IFX_VMAPI_CallBlock_param, nSize);

		}
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_CALLBLOCK_X_VENDOR_COM_CALLBLOCKENTRY))
		{
			pxLocalCallBlkEntry = NULL;
			memset(&sTempCallBlockEntry, 0,
			       sizeof(x_IFX_VMAPI_CallBlockEntry));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempCallBlockEntry.ucIndex = atoi(strTemp);
			ifx_get_CallBlockEntry(&sTempCallBlockEntry, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxCallBlk->
					       pxCallBlockList,
					       (void *)&pxLocalCallBlkEntry,
					       sizeof
					       (x_IFX_VMAPI_CallBlockEntry),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalCallBlkEntry != NULL)
				memcpy(pxLocalCallBlkEntry,
				       &sTempCallBlockEntry,
				       sizeof(x_IFX_VMAPI_CallBlockEntry));
#endif
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_CallBlock function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : HandleMiscParam
*  Description    : get/set api to handle Miscellaneous params for which data type 
*					differs in DB and internal data structure			 
*  Input Values   : pxTmpObj - DB object list	
*					nOperation  - GET/SET operation		
*  Output Values  : pxMisc - Miscellaneous
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int HandleMiscParam(ObjList * pxTmpObj, x_IFX_VMAPI_Misc * pxMisc,
		    int32_t nOperation)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleMiscParam function.");
	ParamList *pxParam = NULL;
	char strVal[MAX_LEN_PARAM_VALUE];
	int32_t nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxTmpObj, "Error :  Miscellaneous Object is NULL");
	CHECK_FOR_NULL(pxMisc,
		       "Error :  Miscellaneous struct Object is NULL");

	FOR_EACH_PARAM(pxTmpObj, pxParam) {
		if (pxParam->unParamId ==
		    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_MISCELLANEOUS_X_VENDOR_COM_DEFAULTOUTBNDIFACE)
		{
			nSize =
			    sizeof(axoutbndifacenv) /
			    sizeof(x_IFX_NAME_VALUE);
			if (nOperation == VOIP_GET) {
				pxMisc->defaultOutbndIface =
				    ifx_getval_fromname(pxParam->sParamValue,
							axoutbndifacenv,
							nSize);
			} else if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxMisc->
						      defaultOutbndIface,
						      axoutbndifacenv, nSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,
					sizeof(strVal));
			}
		}
	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleMiscParam function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_AddrEntry
*  Description    : Get api to get AddrEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxAddrEntry - pointer to Addr Book object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 ifx_get_AddrEntry(x_IFX_VMAPI_AddressBookEntry * pxAddrEntry,
			uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_AddrEntry function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",ADDRESS_ENTRY,pxAddrEntry->ucIndex);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Address entry  failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ADDRESSBOOK_X_VENDOR_COM_ADDRESSBOOKENTRY))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_AddressBookEntry_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxAddrEntry,
					  x_IFX_VMAPI_AddressBookEntry_param,
					  nSize);
		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_AddrEntry function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_AddrBook
*  Description    : Get api to get Address Book object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxAddrBook - pointer to AddrBook object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_AddrBook(x_IFX_VMAPI_AddressBook * pxAddrBook, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_AddrBook function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 uiErr;
	

	x_IFX_VMAPI_AddressBookEntry *pxLocalAddressBookEntry;
	x_IFX_VMAPI_AddressBookEntry sAddressBookEntry;
	char *strTemp;

	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, ADDRESS_BOOK, sizeof(ADDRESS_BOOK));

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Address Book failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ADDRESSBOOK)) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_AddressBook_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxAddrBook,
					  x_IFX_VMAPI_AddressBook_param,
					  nSize);

		}
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ADDRESSBOOK_X_VENDOR_COM_ADDRESSBOOKENTRY))
		{
			pxLocalAddressBookEntry = NULL;
			memset(&sAddressBookEntry, 0,
			       sizeof(x_IFX_VMAPI_AddressBookEntry));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sAddressBookEntry.ucIndex = atoi(strTemp);
			ifx_get_AddrEntry(&sAddressBookEntry, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxAddrBook->
					       pxAddressBook,
					       (void *)
					       &pxLocalAddressBookEntry,
					       sizeof
					       (x_IFX_VMAPI_AddressBookEntry),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalAddressBookEntry != NULL)
				memcpy(pxLocalAddressBookEntry,
				       &sAddressBookEntry,
				       sizeof(x_IFX_VMAPI_AddressBookEntry));
#endif
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_AddrBook function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_Misc
*  Description    : Get api to get Miscellaneous object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMisc - pointer to Miscellaneous object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_Misc(x_IFX_VMAPI_Misc * pxMisc, uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Enter ifx_get_Misc function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, VOICESEEVICE_MISCELLANEOUS,
		sizeof(VOICESEEVICE_MISCELLANEOUS));
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Misc failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_MISCELLANEOUS))
		{

			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_Misc_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxMisc,
					  x_IFX_VMAPI_Misc_param, nSize);
			/*Not requured after TR-104 Fix*/
			/*HandleMiscParam(pxTmpObj, pxMisc, VOIP_GET);*/

		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_Misc function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_SystemT38
*  Description    : Get api to get Voice System T38 object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxSystemT38 - pointer to T38 object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/

int ifx_get_SystemT38(x_IFX_VMAPI_T38Cfg * pxSystemT38, uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_SystemT38 function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, COM_T38, sizeof(COM_T38));
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for SystemT38 failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_T38CONFIGURATION))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_T38Cfg_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxSystemT38,
					  x_IFX_VMAPI_T38Cfg_param, nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_SystemT38 function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_Version
*  Description    : Get api to get Version object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxVer - pointer to Version object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_Version(x_IFX_VMAPI_SystemVersionRegister * pxVer,
		    uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_Version function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, SYSTEM_VERSION, sizeof(SYSTEM_VERSION));
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Version failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_SYSTEMVERSIONREGISTER))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_SystemVersionRegister_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxVer,
					  x_IFX_VMAPI_SystemVersionRegister_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_Version function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_DbgSettings
*  Description    : Get api to get Debug Type object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxDbgSet - pointer to Debug Type object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_DbgSettings(x_IFX_VMAPI_SystemDebugSettings * pxDbgSet,
			uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_DbgSettings function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, DEBUG_SETTINGS, sizeof(DEBUG_SETTINGS));
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Debug settings failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_SYSTEMDEBUGSETTINGS))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_SystemDebugSettings_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxDbgSet,
					  x_IFX_VMAPI_SystemDebugSettings_param,
					  nSize);

		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_DbgSettings function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_PhyInterfaceTestResult
*  Description    : Get api to get Physical Interface Test Result object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxPhyIntTestRes - pointer to the object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_PhyInterfaceTest(x_IFX_VMAPI_VoiceServPhyIfTest * pxPhyIntTest,
			     uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_PhyInterfaceTest function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strcpy(sObjname, PHY_IF_TEST);
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Phy interface test failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVPHYIFTEST))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_VoiceServPhyIfTest_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxPhyIntTest,
					  x_IFX_VMAPI_VoiceServPhyIfTest_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_PhyInterfaceTest function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_PhyInterfaceTestResult
*  Description    : Get api to get Physical Interface Test Result object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxPhyIntTestRes - pointer to the object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_PhyInterfaceTestResult(x_IFX_VMAPI_VoiceServTestResult *
				   pxPhyIntTestRes, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_PhyInterfaceTestResult function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, VOICESERVICE_TEST_RESULT,
		sizeof(VOICESERVICE_TEST_RESULT));
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR
	    ("Get Val for Physical Interface test result failed\n");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909FEMFVOLTRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909HPTVOLTRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909RFTRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909RIRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909ROHRESULT))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_VoiceServTestResult_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxPhyIntTestRes,
					  x_IFX_VMAPI_VoiceServTestResult_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_PhyInterfaceTestResult function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleTransPower
*  Description    : get/set api to handle Dect codec for which data type 
*					differs in DB and internal data structure			 
*  Input Values   : pxTmpObj - DB object list	
*					nOperation - GET/SET operation		
*  Output Values  : pxTransPower - Dect Transmit power 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int HandleTransPower(ObjList * pxTmpObj,
		     x_IFX_VMAPI_TransmitPowerParam * pxTransPower,
		     int32_t nOperation)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleTransPower  function.");

	ParamList *pxParam = NULL;
	char strVal[MAX_LEN_PARAM_VALUE];
	int32_t nSize = 0, nTransmitPowSize = 0, nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxTmpObj, "Input DB object is NULL");
	CHECK_FOR_NULL(pxTransPower, "Input struct object is NULL");

	nTransmitPowSize =
	    sizeof(axtransmitpowernv) / sizeof(x_IFX_NAME_VALUE);

	FOR_EACH_PARAM(pxTmpObj, pxParam) {
		strcpy(strVal, "");
		switch (pxParam->unParamId) {
		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_SWPOWERMODE:
			nSize =
			    sizeof(axswpowermodenv) /
			    sizeof(x_IFX_NAME_VALUE);
			if (nOperation == VOIP_GET) {
				pxTransPower->ucSWPowerMode =
				    ifx_getval_fromname(pxParam->sParamValue,
							axswpowermodenv,
							nSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxTransPower->
						      ucSWPowerMode,
						      axswpowermodenv, nSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,sizeof(strVal));
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_TXPOW_0:
			if (nOperation == VOIP_GET)
			{
				pxTransPower->ucTXPOW_0 =
				    ifx_getval_fromname(pxParam->sParamValue,
							axtransmitpowernv,
							nTransmitPowSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxTransPower->ucTXPOW_0,
						      axtransmitpowernv,
						      nTransmitPowSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,sizeof(strVal));
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_TXPOW_1:
			if (nOperation == VOIP_GET)
			{
				pxTransPower->ucTXPOW_1 =
				    ifx_getval_fromname(pxParam->sParamValue,
							axtransmitpowernv,
							nTransmitPowSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxTransPower->ucTXPOW_1,
						      axtransmitpowernv,
						      nTransmitPowSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,sizeof(strVal));
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_TXPOW_2:
			if (nOperation == VOIP_GET)
			{
				pxTransPower->ucTXPOW_2 =
				    ifx_getval_fromname(pxParam->sParamValue,
							axtransmitpowernv,
							nTransmitPowSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxTransPower->ucTXPOW_2,
						      axtransmitpowernv,
						      nTransmitPowSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,sizeof(strVal));
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_TXPOW_3:
			if (nOperation == VOIP_GET)
			{
				pxTransPower->ucTXPOW_3 =
				    ifx_getval_fromname(pxParam->sParamValue,
							axtransmitpowernv,
							nTransmitPowSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxTransPower->ucTXPOW_3,
						      axtransmitpowernv,
						      nTransmitPowSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,sizeof(strVal));
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_TXPOW_4:
			if (nOperation == VOIP_GET)
			{
				pxTransPower->ucTXPOW_4 =
				    ifx_getval_fromname(pxParam->sParamValue,
							axtransmitpowernv,
							nTransmitPowSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxTransPower->ucTXPOW_4,
						      axtransmitpowernv,
						      nTransmitPowSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,sizeof(strVal));
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_TXPOW_5:
			if (nOperation == VOIP_GET)
			{
				pxTransPower->ucTXPOW_5 =
				    ifx_getval_fromname(pxParam->sParamValue,
							axtransmitpowernv,
							nTransmitPowSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxTransPower->ucTXPOW_5,
						      axtransmitpowernv,
						      nTransmitPowSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,sizeof(strVal));
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_DBPOW:
			if (nOperation == VOIP_GET)
			{
				pxTransPower->ucDBPOW =
				    ifx_getval_fromname(pxParam->sParamValue,
							axtransmitpowernv,
							nTransmitPowSize);
			}
			if (nOperation == VOIP_SET) {
				ifx_getstring_fromval(pxTransPower->ucDBPOW,
						      axtransmitpowernv,
						      nTransmitPowSize,
						      strVal);
				strncpy(pxParam->sParamValue, strVal,sizeof(strVal));
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_TUNEDIGITAL:
			if (nOperation == VOIP_GET)
			{
				pxTransPower->ucTuneDigital = strtol(pxParam->sParamValue, NULL, 16);
			}
			if (nOperation == VOIP_SET) {
				snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%s%0x","0x", pxTransPower->ucTuneDigital);
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM_X_VENDOR_COM_TXBIAS:
			if (nOperation == VOIP_GET)
			{
				pxTransPower->ucTxBias = strtol(pxParam->sParamValue, NULL, 16);
			}
			if (nOperation == VOIP_SET) {
				snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%s%0x","0x", pxTransPower->ucTxBias);
			}
			break;

		}
	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleTransPower  function.");

	return nRetVal;

}

int ifx_get_TransPower(x_IFX_VMAPI_TransmitPowerParam * pxTransPower,
		       uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_TransPower function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_TRANSPOWER);
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Transmit power failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_TransmitPowerParam_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxTransPower,
					  x_IFX_VMAPI_TransmitPowerParam_param,
					  nSize);
			HandleTransPower(pxTmpObj, pxTransPower, VOIP_GET);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_TransPower function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_TransPower
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_Rfpi(x_IFX_VMAPI_DectRfpi * pxRfpi, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_Rfpi function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, DECT_RFPI, sizeof(DECT_RFPI));
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for RFPI failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTRFPI)) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_DectRfpi_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxRfpi,
					  x_IFX_VMAPI_DectRfpi_param, nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_Rfpi function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_Xram
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_Xram(x_IFX_VMAPI_DectXRAM * pxXram, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_Xram function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, DECT_XRAM, sizeof(DECT_XRAM));
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Xram failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTXRAM)) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_DectXRAM_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxXram,
					  x_IFX_VMAPI_DectXRAM_param, nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_Xram function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_TransPower
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_Bmcparam(x_IFX_VMAPI_DectBMCParams * pxBmcparam, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_Bmcparam function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_BMC);
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Bmcparam failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTBMCPARAMS))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_DectBMCParams_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxBmcparam,
					  x_IFX_VMAPI_DectBMCParams_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_Bmcparam function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_Osctrim
*  Description    : Get api to get Voice System Osc trim object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxOsctrim - pointer to Osc trim object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_Osctrim(x_IFX_VMAPI_DectOscTrimVal * pxOsctrim, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_Osctrim function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ParamList *pxParam;
	ObjList *pxTmpObj;
	
	MsgHeader xObjHdr;

	memset(sObjname,0,MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_OCS_TRIM);
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Osctrim failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTOSCTRIMVAL))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_DectOscTrimVal_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxOsctrim,
					  x_IFX_VMAPI_DectOscTrimVal_param,
					  nSize);
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTOSCTRIMVAL_X_VENDOR_COM_P10STATUS)
				{
					if (!
					    (strcmp
					     (pxParam->sParamValue,
					      "IFX_VMAPI_DECT_OSCTRIM_P10_ON")))
						pxOsctrim->ucDectP10Status =
						    IFX_VMAPI_DECT_OSCTRIM_P10_ON;
					else if (!
						 (strcmp
						  (pxParam->sParamValue,
						   "IFX_VMAPI_DECT_OSCTRIM_P10_OFF")))
						pxOsctrim->ucDectP10Status =
						    IFX_VMAPI_DECT_OSCTRIM_P10_OFF;
				}
			}
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_Osctrim function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_Gfsk
*  Description    : Get api to get Voice System Osc trim object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxOsctrim - pointer to Osc trim object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_Gfsk(x_IFX_VMAPI_DectGFSKVal * pxGfsk, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_Gfsk function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_GFSK);
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for GFSK failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTGFSKVAL)) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_DectGFSKVal_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxGfsk,
					  x_IFX_VMAPI_DectGFSKVal_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_Gfsk function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : HandleCtrySetParam
*  Description    : get/set api to handle Dect codec for which data type 
*					differs in DB and internal data structure			 
*  Input Values   : pxTmpObj - DB object list			
*  Output Values  : pCodecDesc - DectHandset codec description
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int HandleCtrySetParam(ObjList * pxTmpObj,
		       x_IFX_VMAPI_DectCountrySettings * pxCtryset,
		       int32_t nOperation)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter HandleCtrySetParam  function.");

	ParamList *pxParam = NULL;
	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxTmpObj, "Input DB object is NULL");
	CHECK_FOR_NULL(pxCtryset, "Input struct object is NULL");

	FOR_EACH_PARAM(pxTmpObj, pxParam) {
		switch (pxParam->unParamId) {
		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTCOUNTRYSETTINGS_X_VENDOR_COM_FREQUENCYTXOFFSET:
			if (nOperation == VOIP_GET) {
				pxCtryset->ucFreqTxOffset = strtol(pxParam->sParamValue, NULL,HEX_BASE_VAL);
			}
			if (nOperation == VOIP_SET) {
				snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%s%0x","0x",pxCtryset->ucFreqTxOffset);
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTCOUNTRYSETTINGS_X_VENDOR_COM_FREQUENCYRXOFFSET:
			if (nOperation == VOIP_GET) {
				pxCtryset->ucFreqRxOffset = strtol(pxParam->sParamValue, NULL, HEX_BASE_VAL);
			}
			if (nOperation == VOIP_SET) {
				snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%s%0x","0x",pxCtryset->ucFreqRxOffset);
			}
			break;

		case DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTCOUNTRYSETTINGS_X_VENDOR_COM_FREQUENCYRANGE:
			if (nOperation == VOIP_GET) {
				pxCtryset->ucFreqRan = strtol(pxParam->sParamValue, NULL, HEX_BASE_VAL);
			}
			if (nOperation == VOIP_SET) {
				snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%s%0x","0x",pxCtryset->ucFreqRan);
			}
			break;
		}

	}
      END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit HandleCtrySetParam  function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_CtrySet
*  Description    : Get api to get Voice System Transmit Power object.
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxTransPower - pointer to Transmit Power object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_CtrySet(x_IFX_VMAPI_DectCountrySettings * pxCtryset,
		    uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_CtrySet function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_CNTRY_SETT);
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Country settings failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTCOUNTRYSETTINGS))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_DectCountrySettings_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxCtryset,
					  x_IFX_VMAPI_DectCountrySettings_param,
					  nSize);
			HandleCtrySetParam(pxTmpObj, pxCtryset, VOIP_GET);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_CtrySet function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_rfmode
*  Description    : Get api to get Voice System RF Mode object
*  Input Values   :  uiInFlag - Input flags
*  Output Values  : pxRfmode - pointer to RF mode object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_rfmode(x_IFX_VMAPI_RFMode * pxRfmode, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_rfmode function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	strncpy(sObjname, DECT_RFMODE, sizeof(DECT_RFMODE));
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for rfmode failed");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_RFMODE)) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_RFMode_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxRfmode,
					  x_IFX_VMAPI_RFMode_param, nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_rfmode function.");
	return nRetVal;
}

#ifdef DECT_SENSORS_SUPPORT
/******************************************************************************
*  Function Name  : ifx_get_SensorAlaramList
*  Description    : Get api to get Senor List.
*  Input Values   : uiInFlag - Input flags, uiObjType - Sensor type (motion/smoke)
*  Output Values  : pxSensorAlaramList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int LTQ_get_SensorAlaramList(void *pvSensorReadList, uint32 uiSensorListType,
			     uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter LTQ_get_SensorAlaramList function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	char *strTemp;
	

	x_LTQ_SensorAlaram_Entry *pxLocalSensorAlarm;
	x_LTQ_SensorAlaram_Entry sTempSensorAlarm;

	x_LTQ_VMAPI_PowerSensor_ReadEntry sTempPowerSensorRead;
	x_LTQ_VMAPI_PowerSensor_ReadEntry *pxLocalPowerSensorRead;
	int32 uiErr;

	switch (uiSensorListType) {

	case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_LIST:
	case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_LIST:
		memset(sObjname,0,MAX_LEN_OBJNAME);
		strncpy(sObjname, SENSOR_ALARM, sizeof(SENSOR_ALARM));
		memset(&xObjHdr, 0, sizeof(MsgHeader));

		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);

		/* to query particular parameter for given object */
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Sensor Alarm List failed");

		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
			if ((GET_OBJ_OID(pxTmpObj) ==
			     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_SENSORALARAMLIST))
			{
				//getting the number of parameters
				nSize =
				    sizeof(x_LTQ_SensorAlaram_List_param) /
				    sizeof(x_IFX_Param);
				fill_struct_param(pxTmpObj, pvSensorReadList,
						  x_LTQ_SensorAlaram_List_param,
						  nSize);
			}
			if (GET_OBJ_OID(pxTmpObj) ==
			    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_SENSORALARAMLIST_X_VENDOR_COM_SENSORALARAMENTRY)
			{

				pxLocalSensorAlarm = NULL;
				memset(&sTempSensorAlarm, 0,
				       sizeof(x_LTQ_SensorAlaram_Entry));
				strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
				strTemp++;
				sTempSensorAlarm.ucIndex = atoi(strTemp);
				uiSensorListType =
				    IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY;
				LTQ_get_SensorAlaramEntry(&sTempSensorAlarm,
							  uiSensorListType,
							  0);
#ifdef __LINUX__
				__ifx_list_add_to_tail((void *)
						       &((x_LTQ_SensorAlaram_List *) pvSensorReadList)->pxAlaramEntries, (void *)&pxLocalSensorAlarm, sizeof(x_LTQ_SensorAlaram_Entry), &uiErr);
				/* Copy the content in the new location */
				if (pxLocalSensorAlarm != NULL)
					memcpy(pxLocalSensorAlarm,
					       &sTempSensorAlarm,
					       sizeof
					       (x_LTQ_SensorAlaram_Entry));
#endif

			}
		}
		break;

	case IFX_VMAPI_VS_POWER_SENSOR_READ_LIST:
		memset(sObjname,0,MAX_LEN_OBJNAME);
		strncpy(sObjname, SENSOR_READ, sizeof(SENSOR_READ));
		memset(&xObjHdr, 0, sizeof(MsgHeader));

		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);

		/* to query particular parameter for given object */
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Sensor Alarm List failed");

		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
			if ((GET_OBJ_OID(pxTmpObj) ==
			     DEVICE_SERVICES_VOICESERVICE_POWERSENSORREADLIST))
			{
				//getting the number of parameters
				nSize =
				    sizeof(x_LTQ_PowerSensor_ReadList_param) /
				    sizeof(x_IFX_Param);
				fill_struct_param(pxTmpObj, pvSensorReadList,
						  x_LTQ_PowerSensor_ReadList_param,
						  nSize);
			}
			if (GET_OBJ_OID(pxTmpObj) ==
			    DEVICE_SERVICES_VOICESERVICE_POWERSENSORREADLIST_POWERSENSORREADENTRY)
			{

				pxLocalPowerSensorRead = NULL;
				memset(&sTempPowerSensorRead, 0,
				       sizeof(x_LTQ_PowerSensor_ReadEntry));
				strcpy(strTemp, "");
				strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
				strTemp++;
				sTempPowerSensorRead.ucIndex = atoi(strTemp);
				uiSensorListType =
				    IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY;
				LTQ_get_SensorAlaramEntry
				    (&sTempPowerSensorRead, uiSensorListType,
				     0);
#ifdef __LINUX__
				__ifx_list_add_to_tail((void *)
						       &((x_LTQ_PowerSensor_ReadList *) pvSensorReadList)->pxPowEntries, (void *)&pxLocalPowerSensorRead, sizeof(x_LTQ_PowerSensor_ReadEntry), &uiErr);
				/* Copy the content in the new location */
				if (pxLocalPowerSensorRead != NULL)
					memcpy(pxLocalPowerSensorRead,
					       &sTempPowerSensorRead,
					       sizeof
					       (x_LTQ_PowerSensor_ReadEntry));
#endif
			}
		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit LTQ_get_SensorAlaramList function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : LTQ_get_SensorAlaramEntry
*  Description    : Get api to get Sensor Alaram List Entry.
*  Input Values   : uiInFlag - Input flags
*       uiSensorType - Sensor Type      
*  Output Values  : pxSensorAlaramEtr - pointer to Sensor Alaram List object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32 LTQ_get_SensorAlaramEntry(void *pvSensorRead, uint32 uiSensorReadType,
				uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter LTQ_get_SensorAlaramEntry function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	switch (uiSensorReadType) {

	case IFX_VMAPI_VS_SMOKE_SENSOR_ALARAM_ENTRY:
	case IFX_VMAPI_VS_MOTION_SENSOR_ALARAM_ENTRY:
		memset(sObjname,0,MAX_LEN_OBJNAME);
	    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",SENSOR_ALARM_ENTRY,((x_LTQ_SensorAlaram_Entry *) pvSensorRead)->ucIndex);


		memset(&xObjHdr, 0, sizeof(MsgHeader));

		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);

		/* to query particular parameter for given object */
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Sensor Alarm Entry failed");
		{
			FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
				if ((GET_OBJ_OID(pxTmpObj) ==
				     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_SENSORALARAMLIST_X_VENDOR_COM_SENSORALARAMENTRY)
				    || (GET_OBJ_OID(pxTmpObj) ==
					DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_SENSORALARAMLIST_X_VENDOR_COM_SENSORALARAMENTRY_X_VENDOR_COM_ALARAM))
				{
					//getting the number of parameters
					nSize =
					    sizeof
					    (x_LTQ_SensorAlaram_Entry_param) /
					    sizeof(x_IFX_Param);
					fill_struct_param(pxTmpObj,
							  pvSensorRead,
							  x_LTQ_SensorAlaram_Entry_param,
							  nSize);
				}

			}
		}
		break;

	case IFX_VMAPI_VS_POWER_SENSOR_READ_ENTRY:
		 memset(sObjname,0,MAX_LEN_OBJNAME);
    	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",POWER_SENSOR_READ_ENTRY,
						((x_LTQ_VMAPI_PowerSensor_ReadEntry *) pvSensorRead)->ucIndex);

		memset(&xObjHdr, 0, sizeof(MsgHeader));

		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);

		/* to query particular parameter for given object */
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Sensor Alarm Entry failed");
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
			if ((GET_OBJ_OID(pxTmpObj) ==
			     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_POWERSENSORREADLIST_X_VENDOR_COM_POWERSENSORREADENTRY)
			    || (GET_OBJ_OID(pxTmpObj) ==
				DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_POWERSENSORREADLIST_X_VENDOR_COM_POWERSENSORREADENTRY_X_VENDOR_COM_POWERREAD))
			{
				//getting the number of parameters
				nSize =
				    sizeof(x_LTQ_PowerSensor_ReadEntry_param)
				    / sizeof(x_IFX_Param);
				fill_struct_param(pxTmpObj, pvSensorRead,
						  x_LTQ_PowerSensor_ReadEntry_param,
						  nSize);
			}

		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit LTQ_get_SensorAlaramEntry function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_SensorList
*  Description    : Get api to get Senor List.
*  Input Values   : uiInFlag - Input flags, uiObjType - Sensor type (motion/smoke)
*  Output Values  : pxContactList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int LTQ_get_SensorList(void *pvSensorList, uint32 uiSensorListType,
		       uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter LTQ_get_SensorList function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	char *strTemp;
	

	x_LTQ_SensorList_Entry *pxLocalSensorListEntry;
	x_LTQ_SensorList_Entry sTempSensorListEntry;

	x_LTQ_PowerSensorEntry sTempPowerSensorEntry;
	x_LTQ_PowerSensorEntry *pxLocalPowerSensorEntry;
	int32 uiErr;

	switch (uiSensorListType) {

	case IFX_VMAPI_VS_SMOKE_SENSOR_LIST:
	case IFX_VMAPI_VS_MOTION_SENSOR_LIST:
		memset(sObjname,0,MAX_LEN_OBJNAME);
		strncpy(sObjname, SENSOR_LIST, sizeof(SENSOR_LIST));
		memset(&xObjHdr, 0, sizeof(MsgHeader));

		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);

		/* to query particular parameter for given object */
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Sensor List failed");
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
			if ((GET_OBJ_OID(pxTmpObj) ==
			     DEVICE_SERVICES_VOICESERVICE_SENSORLIST)) {
				//getting the number of parameters
				nSize =
				    sizeof(x_LTQ_SensorList_param) /
				    sizeof(x_IFX_Param);
				fill_struct_param(pxTmpObj, pvSensorList,
						  x_LTQ_SensorList_param,
						  nSize);
			}
			if (GET_OBJ_OID(pxTmpObj) ==
			    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_SENSORLIST_X_VENDOR_COM_SENSORENTRIES)
			{

				pxLocalSensorListEntry = NULL;
				memset(&sTempSensorListEntry, 0,
				       sizeof(x_LTQ_SensorList_Entry));
				strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
				strTemp++;
				sTempSensorListEntry.ucIndex = atoi(strTemp);
				uiSensorListType =
				    IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY;
				LTQ_get_SensorEntry(&sTempSensorListEntry,
						    uiSensorListType, 0);
#ifdef __LINUX__
				__ifx_list_add_to_tail((void *)
						       &((x_LTQ_SensorList *)
							 pvSensorList)->
						       pxSensorEntries,
						       (void *)
						       &pxLocalSensorListEntry,
						       sizeof
						       (x_LTQ_SensorList_Entry),
						       &uiErr);
				/* Copy the content in the new location */
				if (pxLocalSensorListEntry != NULL)
					memcpy(pxLocalSensorListEntry,
					       &sTempSensorListEntry,
					       sizeof
					       (x_LTQ_SensorList_Entry));
#endif
			}

		}

		break;

	case IFX_VMAPI_VS_POWER_SENSOR_LIST:
		memset(sObjname,0,MAX_LEN_OBJNAME);
		strncpy(sObjname, POWER_SENSOR_LIST,
			sizeof(POWER_SENSOR_LIST));
		memset(&xObjHdr, 0, sizeof(MsgHeader));

		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);

		/* to query particular parameter for given object */
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Sensor List failed");

		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
			if ((GET_OBJ_OID(pxTmpObj) ==
			     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_POWERSENSORLIST))
			{
				//getting the number of parameters
				nSize =
				    sizeof(x_LTQ_PowerSensorList_param) /
				    sizeof(x_IFX_Param);
				fill_struct_param(pxTmpObj, pvSensorList,
						  x_LTQ_PowerSensorList_param,
						  nSize);
			}
			if (GET_OBJ_OID(pxTmpObj) ==
			    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_POWERSENSORLIST_X_VENDOR_COM_POWERSENSORENTRIES)
			{

				pxLocalPowerSensorEntry = NULL;
				memset(&sTempPowerSensorEntry, 0,
				       sizeof(x_LTQ_PowerSensorEntry));
				strcpy(strTemp, "");
				strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
				strTemp++;
				sTempPowerSensorEntry.ucIndex = atoi(strTemp);
				uiSensorListType =
				    IFX_VMAPI_VS_POWER_SENSOR_ENTRY;
				LTQ_get_SensorEntry(&sTempPowerSensorEntry,
						    uiSensorListType, 0);
#ifdef __LINUX__
				__ifx_list_add_to_tail((void *)
						       &((x_LTQ_PowerSensorList *) pvSensorList)->pxSensorEntries, (void *)&pxLocalPowerSensorEntry, sizeof(x_LTQ_PowerSensorEntry), &uiErr);
				/* Copy the content in the new location */
				if (pxLocalPowerSensorEntry != NULL)
					memcpy(pxLocalPowerSensorEntry,
					       &sTempPowerSensorEntry,
					       sizeof
					       (x_LTQ_PowerSensorEntry));
#endif
			}
		}
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit LTQ_get_SensorList function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : LTQ_get_SensorListEntry
*  Description    : Get api to get SensorListEntry object.
*  Input Values   : uiInFlag - Input flags
*		    uiSensorType - Sensor Type			
*  Output Values  : pxSensorListEtr - pointer to ContactListEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int LTQ_get_SensorEntry(void *pvSensorEtr, uint32 uiSensorType,
			uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter LTQ_get_SensorEntry function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	switch (uiSensorType) {

	case IFX_VMAPI_VS_SMOKE_SENSOR_ENTRY:
	case IFX_VMAPI_VS_MOTION_SENSOR_ENTRY:
		memset(sObjname,0,MAX_LEN_OBJNAME);
	    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",SENSOR_ENTRIES,
                        ((x_LTQ_SensorList_Entry *) pvSensorEtr)->ucIndex);


		memset(&xObjHdr, 0, sizeof(MsgHeader));

		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);

		/* to query particular parameter for given object */
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Sensor List entries failed");
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
			if ((GET_OBJ_OID(pxTmpObj) ==
			     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_SENSORLIST_X_VENDOR_COM_SENSORENTRIES)
			    || (GET_OBJ_OID(pxTmpObj) ==
				DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_SENSORLIST_X_VENDOR_COM_SENSORENTRIES_X_VENDOR_COM_SENSORINFO))
			{
				//getting the number of parameters
				nSize =
				    sizeof(x_LTQ_SensorList_Entry_param) /
				    sizeof(x_IFX_Param);
				fill_struct_param(pxTmpObj, pvSensorEtr,
						  x_LTQ_SensorList_Entry_param,
						  nSize);
			}

		}

		break;

	case IFX_VMAPI_VS_POWER_SENSOR_ENTRY:
		memset(sObjname,0,MAX_LEN_OBJNAME);
    	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",POWER_SENSOR_ENTRIES,
                        ((x_LTQ_PowerSensorEntry *) pvSensorEtr)->ucIndex);
		memset(&xObjHdr, 0, sizeof(MsgHeader));

		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);

		/* to query particular parameter for given object */
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR
		    ("Get Value power for Sensor List entries failed");
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
			if ((GET_OBJ_OID(pxTmpObj) ==
			     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_POWERSENSORLIST_X_VENDOR_COM_POWERSENSORENTRIES)
			    || (GET_OBJ_OID(pxTmpObj) ==
				DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_POWERSENSORLIST_X_VENDOR_COM_POWERSENSORENTRIES_X_VENDOR_COM_SENSORINFO))
			{
				//getting the number of parameters
				nSize =
				    sizeof(x_LTQ_PowerSensorEntry_param) /
				    sizeof(x_IFX_Param);
				fill_struct_param(pxTmpObj, pvSensorEtr,
						  x_LTQ_PowerSensorEntry_param,
						  nSize);
			}

		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit LTQ_get_SensorEntry function.");
	return nRetVal;
}
#endif

/******************************************************************************
*  Function Name  : ifx_get_DialCallReg
*  Description    : Get api to get Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxDialCallReg - pointer to Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int ifx_get_DialCallReg(x_IFX_VMAPI_DialCallRegister * pxDialCallReg,
			uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_DialCallReg function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 uiErr;
	uchar8 ucTempLineId;

	/*storing the line id a varibale*/	
	ucTempLineId = pxDialCallReg->ucLineId;	
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	x_IFX_VMAPI_DialCallRegEntry *pxLocalDialCallRegEntry;
	x_IFX_VMAPI_DialCallRegEntry sTempDialCallRegEntry;
	char *strTemp;
	if (pxDialCallReg->ucLineId == PSTN_LINE) {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,DIAL_CALLREG);


	} else {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxDialCallReg->ucLineId,DIAL_CALLREG);

	}
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for DialCall Register failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_DIALCALLREGISTER)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_DIALCALLREGISTER)
		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_CallRegister_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxDialCallReg,
					  x_IFX_VMAPI_CallRegister_param,
					  nSize);
			
			pxDialCallReg->ucLineId = ucTempLineId;

		}
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_DIALCALLREGISTER_X_VENDOR_COM_DIALCALLREGENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_DIALCALLREGISTER_X_VENDOR_COM_DIALCALLREGENTRY)
		    ) {
			pxLocalDialCallRegEntry = NULL;
			memset(&sTempDialCallRegEntry, 0,
			       sizeof(x_IFX_VMAPI_DialCallRegEntry));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempDialCallRegEntry.ucIndex = atoi(strTemp);
			sTempDialCallRegEntry.ucLineId =
			    pxDialCallReg->ucLineId;
			ifx_get_DialCallRegEntry(&sTempDialCallRegEntry, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxDialCallReg->
					       pxCallRegEntries,
					       (void *)
					       &pxLocalDialCallRegEntry,
					       sizeof
					       (x_IFX_VMAPI_DialCallRegEntry),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalDialCallRegEntry != NULL)
				memcpy(pxLocalDialCallRegEntry,
				       &sTempDialCallRegEntry,
				       sizeof(x_IFX_VMAPI_DialCallRegEntry));
#endif
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_DialCallReg function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_DialCallRegEntry
*  Description    : Get api to get CallRegEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxDialCallRegEtr - pointer to CallRegEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_DialCallRegEntry(x_IFX_VMAPI_DialCallRegEntry * pxDialCallRegEtr,
			     uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_DialCallRegEntry function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	if (pxDialCallRegEtr->ucLineId == PSTN_LINE) {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s%d",PSTNLINE,DIAL_CALLREG_ENTRY,pxDialCallRegEtr->ucIndex);


	} else {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d",VOICE_LINE,pxDialCallRegEtr->ucLineId,DIAL_CALLREG_ENTRY,
						pxDialCallRegEtr->ucIndex);

	}

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dial Call reg entry failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_DIALCALLREGISTER_X_VENDOR_COM_DIALCALLREGENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_DIALCALLREGISTER_X_VENDOR_COM_DIALCALLREGENTRY)
		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_CallRegEntry_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxDialCallRegEtr,
					  x_IFX_VMAPI_CallRegEntry_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_DialCallReg function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_MissCallReg
*  Description    : Get api to get Missed Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMissCallReg - pointer to Missed Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_MissCallReg(x_IFX_VMAPI_MissCallRegister * pxMissCallReg,
			uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_MissCallReg function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 uiErr;
    uchar8 ucTempLineId;	
	
	ucTempLineId = pxMissCallReg->ucLineId;
	memset(sObjname,0,MAX_LEN_OBJNAME);
	x_IFX_VMAPI_MissCallRegEntry *pxLocalMissCallRegEntry;
	x_IFX_VMAPI_MissCallRegEntry sTempMissCallRegEntry;
	char *strTemp;

	if (pxMissCallReg->ucLineId == PSTN_LINE) {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,MISS_CALLREG);


	} else {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxMissCallReg->ucLineId,MISS_CALLREG);

	}
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for MissCallreg failed");
	
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_MISSCALLREGISTER)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_MISSCALLREGISTER)
		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_CallRegister_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxMissCallReg,
					  x_IFX_VMAPI_CallRegister_param,
					  nSize);
			pxMissCallReg->ucLineId = ucTempLineId;
		}
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_MISSCALLREGISTER_X_VENDOR_COM_MISSCALLREGENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_MISSCALLREGISTER_X_VENDOR_COM_MISSCALLREGENTRY)
		    ) {
			pxLocalMissCallRegEntry = NULL;
			memset(&sTempMissCallRegEntry, 0,
			       sizeof(x_IFX_VMAPI_MissCallRegEntry));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempMissCallRegEntry.ucIndex = atoi(strTemp);
			sTempMissCallRegEntry.ucLineId =
			    pxMissCallReg->ucLineId;
			ifx_get_MissCallRegEntry(&sTempMissCallRegEntry, 0);
#ifdef __LINUX__

			__ifx_list_add_to_tail((void *)&pxMissCallReg->
					       pxCallRegEntries,
					       (void *)
					       &pxLocalMissCallRegEntry,
					       sizeof
					       (x_IFX_VMAPI_MissCallRegEntry),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalMissCallRegEntry != NULL)
				memcpy(pxLocalMissCallRegEntry,
				       &sTempMissCallRegEntry,
				       sizeof(x_IFX_VMAPI_MissCallRegEntry));
#endif
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_MissCallReg function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_MissCallRegEntry
*  Description    : Get api to get MissCallRegEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMissCallRegEtr - pointer to MissCallRegEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_MissCallRegEntry(x_IFX_VMAPI_MissCallRegEntry * pxMissCallRegEtr,
			     uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_MissCallRegEntry function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	if (pxMissCallRegEtr->ucLineId == PSTN_LINE) {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s%d",PSTNLINE,MISS_CALLREG_ENTRY,pxMissCallRegEtr->ucIndex);
	} else {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d",VOICE_LINE,pxMissCallRegEtr->ucLineId,
												MISS_CALLREG_ENTRY,pxMissCallRegEtr->ucIndex);
	}

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val failed for Misscall register entry");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_MISSCALLREGISTER_X_VENDOR_COM_MISSCALLREGENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_MISSCALLREGISTER_X_VENDOR_COM_MISSCALLREGENTRY)
		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_CallRegEntry_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxMissCallRegEtr,
					  x_IFX_VMAPI_CallRegEntry_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_MissCallRegEntry function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_RecvCallReg
*  Description    : Get api to get Recieved Call Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxRecvCallReg - pointer to Received Call Register object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_RecvCallReg(x_IFX_VMAPI_RecvCallRegister * pxRecvCallReg,
			uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_RecvCallReg function");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 uiErr;
	uchar8 ucTempLineId;	
	
	ucTempLineId = pxRecvCallReg->ucLineId;
	memset(sObjname,0,MAX_LEN_OBJNAME);
	x_IFX_VMAPI_RecvCallRegEntry *pxLocalRecvCallRegEntry;
	x_IFX_VMAPI_RecvCallRegEntry sTempRecvCallRegEntry;
	char *strTemp;

	if (pxRecvCallReg->ucLineId == PSTN_LINE) {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,RCV_CALLREG);


	} else {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxRecvCallReg->ucLineId,RCV_CALLREG);

	}
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Receive callregister failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_RECVCALLREGISTER)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_RECVCALLREGISTER)
		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_CallRegister_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxRecvCallReg,
					  x_IFX_VMAPI_CallRegister_param,
					  nSize);
			/*Reseting the line id again as it is getting reset by the 
			 the default value of DB which is not used or set while adding Line
			*/
			 pxRecvCallReg->ucLineId = ucTempLineId;

		}
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_RECVCALLREGISTER_X_VENDOR_COM_RECVCALLREGENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_RECVCALLREGISTER_X_VENDOR_COM_RECVCALLREGENTRY)
		    ) {

			pxLocalRecvCallRegEntry = NULL;
			memset(&sTempRecvCallRegEntry, 0,
			       sizeof(x_IFX_VMAPI_RecvCallRegEntry));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempRecvCallRegEntry.ucIndex = atoi(strTemp);

			sTempRecvCallRegEntry.ucLineId =
			    pxRecvCallReg->ucLineId;
			ifx_get_RecvCallRegEntry(&sTempRecvCallRegEntry, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxRecvCallReg->
					       pxCallRegEntries,
					       (void *)
					       &pxLocalRecvCallRegEntry,
					       sizeof
					       (x_IFX_VMAPI_RecvCallRegEntry),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalRecvCallRegEntry != NULL)
				memcpy(pxLocalRecvCallRegEntry,
				       &sTempRecvCallRegEntry,
				       sizeof(x_IFX_VMAPI_RecvCallRegEntry));
#endif
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_MissCallRegEntry function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_RecvCallRegEntry
*  Description    : Get api to get RecvCallRegEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxRecvCallRegEtr - pointer to RecvCallRegEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_RecvCallRegEntry(x_IFX_VMAPI_RecvCallRegEntry * pxRecvCallRegEtr,
			     uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_RecvCallRegEntry function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	if (pxRecvCallRegEtr->ucLineId == PSTN_LINE) {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s%d",PSTNLINE,RCV_CALLREG_ENTRY,pxRecvCallRegEtr->ucIndex);

	} else {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d",VOICE_LINE,pxRecvCallRegEtr->ucLineId,
								RCV_CALLREG_ENTRY,pxRecvCallRegEtr->ucIndex);
	}
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val failed for receive callregister");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_RECVCALLREGISTER_X_VENDOR_COM_RECVCALLREGENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_RECVCALLREGISTER_X_VENDOR_COM_RECVCALLREGENTRY)

		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_CallRegEntry_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxRecvCallRegEtr,
					  x_IFX_VMAPI_CallRegEntry_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_RecvCallRegEntry function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_ContactList
*  Description    : Get api to get Contact list Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_ContactList(x_IFX_VMAPI_ContactList * pxContactList,
			uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_ContactList function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 uiErr;
	uchar8 ucTempLineId;

	ucTempLineId = pxContactList->ucLineId;

	x_IFX_VMAPI_ContactListEntry *pxLocalContactListEntry;
	x_IFX_VMAPI_ContactListEntry sTempContactListEntry;
	char *strTemp;
	
	memset(sObjname,0,MAX_LEN_OBJNAME);
	if (pxContactList->ucLineId == PSTN_LINE) {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,CONTACT_LIST);

	} else {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxContactList->ucLineId,CONTACT_LIST);


	}

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */

	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val failed for contact list falied");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_CONTACTLIST)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_CONTACTLIST)
		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_ContactList_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxContactList,
					  x_IFX_VMAPI_ContactList_param,
					  nSize);
			pxContactList->ucLineId = ucTempLineId;
		}
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_CONTACTLIST_X_VENDOR_COM_CONTACTLISTENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_CONTACTLIST_X_VENDOR_COM_CONTACTLISTENTRY)
		    ) {
			pxLocalContactListEntry = NULL;
			memset(&sTempContactListEntry, 0,
			       sizeof(x_IFX_VMAPI_ContactListEntry));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempContactListEntry.ucIndex = atoi(strTemp);
			sTempContactListEntry.ucLineId =
			    pxContactList->ucLineId;
			ifx_get_ContactListEntry(&sTempContactListEntry, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxContactList->
					       pxContactEntries,
					       (void *)
					       &pxLocalContactListEntry,
					       sizeof
					       (x_IFX_VMAPI_ContactListEntry),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalContactListEntry != NULL)
				memcpy(pxLocalContactListEntry,
				       &sTempContactListEntry,
				       sizeof(x_IFX_VMAPI_ContactListEntry));
#endif
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ContactList function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_ContactListEntry
*  Description    : Get api to get ContactListEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactListEtr - pointer to ContactListEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_ContactListEntry(x_IFX_VMAPI_ContactListEntry * pxContactListEtr,
			     uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_ContactListEntry function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	if (pxContactListEtr->ucLineId == PSTN_LINE) {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s%d",PSTNLINE,CONTACT_LIST_ENTRY,pxContactListEtr->ucIndex);

	} else {
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d",VOICE_LINE,pxContactListEtr->ucLineId,
									CONTACT_LIST_ENTRY,pxContactListEtr->ucIndex);
	}

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for contactlist failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_CONTACTLIST_X_VENDOR_COM_CONTACTLISTENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_CONTACTLIST_X_VENDOR_COM_CONTACTLISTENTRY)
		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_ContactListEntry_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxContactListEtr,
					  x_IFX_VMAPI_ContactListEntry_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_ContactListEntry function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_CommonContactList
*  Description    : Get api to get Contact list Register object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactList - pointer to ContactList object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_CommonContactList(x_IFX_VMAPI_ContactList * pxContactList,
			      uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_CommonContactList function.");

	return IFX_VMAPI_SUCCESS;

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 uiErr;
	//char tempstr[10];
	

	x_IFX_VMAPI_ContactListEntry *pxLocalContactListEntry;
	x_IFX_VMAPI_ContactListEntry sTempContactListEntry;
	char *strTemp;

	if (pxContactList->ucLineId == PSTN_LINE) {
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,COMMON_CONTACT_LIST);


	} else {
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxContactList->ucLineId,COMMON_CONTACT_LIST);

	}

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("get Value for common contact list failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_CONTACTLIST)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_COMMONCONTACTLIST)
		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_ContactList_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxContactList,
					  x_IFX_VMAPI_ContactList_param,
					  nSize);

		}
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_CONTACTLIST_X_VENDOR_COM_CONTACTLISTENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_COMMONCONTACTLIST_X_VENDOR_COM_COMMONCONTACTLISTENTRY)
		    ) {
			pxLocalContactListEntry = NULL;
			memset(&sTempContactListEntry, 0,
			       sizeof(x_IFX_VMAPI_ContactListEntry));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempContactListEntry.ucIndex = atoi(strTemp);
			sTempContactListEntry.ucLineId =
			    pxContactList->ucLineId;
			ifx_get_CommonContactListEntry(&sTempContactListEntry,
						       0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxContactList->
					       pxContactEntries,
					       (void *)
					       &pxLocalContactListEntry,
					       sizeof
					       (x_IFX_VMAPI_ContactListEntry),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalContactListEntry != NULL)
				memcpy(pxLocalContactListEntry,
				       &sTempContactListEntry,
				       sizeof(x_IFX_VMAPI_ContactListEntry));
#endif
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_CommonContactList function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_CommonContactListEntry
*  Description    : Get api to get CommonContactListEntry object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxContactListEtr - pointer to ContactListEntry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_CommonContactListEntry(x_IFX_VMAPI_ContactListEntry *
				   pxContactListEtr, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_CommonContactListEntry function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	

	if (pxContactListEtr->ucLineId == PSTN_LINE) {
		snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s%d",PSTNLINE,COMMON_CONTACT_LIST_ENTRY,pxContactListEtr->ucIndex);



	} else {
		snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d",VOICE_LINE,pxContactListEtr->ucLineId,
								COMMON_CONTACT_LIST_ENTRY,pxContactListEtr->ucIndex);

	}

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for common contactlist failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_X_VENDOR_COM_CONTACTLIST_X_VENDOR_COM_CONTACTLISTENTRY)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF_X_VENDOR_COM_COMMONCONTACTLIST_X_VENDOR_COM_COMMONCONTACTLISTENTRY)

		    ) {
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_ContactListEntry_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxContactListEtr,
					  x_IFX_VMAPI_ContactListEntry_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_CommonContactList function.");
	return nRetVal;

}

#ifdef MESSAGE_SUPPORT
/******************************************************************************
*  Function Name  : ifx_get_MsgInbox
*  Description    : Api to get Message Inbox object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMsgIn- pointer to Message Inbox object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_MsgInbox(x_IFX_VMAPI_IN_Message * pxMsgIn, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_MsgInbox function.");
	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ParamList *pxParam;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 uiErr;
	char tempstr[TEMP_LEN];

	x_IFX_VMAPI_IN_MessageEntry *pxLocalINMessageEntry;
	x_IFX_VMAPI_IN_MessageEntry sTempINMessageEntry;
	char *strTemp;
	
	memset(sObjname, 0 ,MAX_LEN_OBJNAME);
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxMsgIn->ucLineId,INMESSAGE_LIST);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for MsgInbox failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_INMESSAGE))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_Message_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxMsgIn,
					  x_IFX_VMAPI_Message_param, nSize);

		}

		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_INMESSAGE_INMESSAGEENTRY))
		{
			pxLocalINMessageEntry = NULL;
			memset(&sTempINMessageEntry, 0,
			       sizeof(x_IFX_VMAPI_MessageEntry));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempINMessageEntry.ucIndex = atoi(strTemp);
			sTempINMessageEntry.ucLineId = pxMsgIn->ucLineId;
			ifx_get_MsgInboxEntry(&sTempINMessageEntry, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxMsgIn->pxMsgEntries,
					       (void *)&pxLocalINMessageEntry,
					       sizeof
					       (x_IFX_VMAPI_MessageEntry),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalINMessageEntry != NULL)
				memcpy(pxLocalINMessageEntry,
				       &sTempINMessageEntry,
				       sizeof(x_IFX_VMAPI_MessageEntry));
#endif
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_MsgInbox function.");
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_get_MsgInboxEntry
*  Description    : Api to get Message Inbox object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMsgIn- pointer to Message Inbox object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_MsgInboxEntry(x_IFX_VMAPI_IN_MessageEntry * pxMsgInEntry,
			  uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_MsgInboxEntry function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetval = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	
	memset(sObjname,0, MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d",VOICE_LINE,pxMsgInEntry->ucLineId,
					INMESSAGE_ENTRY,pxMsgInEntry->ucIndex);
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for MsgInboxEntry failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_INMESSAGE_INMESSAGEENTRY)
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_MessageEntry_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxMsgInEntry,
					  x_IFX_VMAPI_MessageEntry_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_MsgInboxEntry function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_MsgOutbox
*  Description    : Api to get Message Outbox object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMsgOut- pointer to Message Inbox object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_MsgOutbox(x_IFX_VMAPI_OUT_Message * pxMsgOut, uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_MsgOutbox function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ParamList *pxParam;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 uiErr;

	x_IFX_VMAPI_MessageEntry *pxLocalOUTMessageEntry;
	x_IFX_VMAPI_MessageEntry sTempOUTMessageEntry;
	char *strTemp;

	memset(sObjname,0, MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxMsgOut->ucLineId,OUTMESSAGE_LIST);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for MsgOutbox failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_OUTMESSAGE))
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_Message_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxMsgOut,
					  x_IFX_VMAPI_Message_param, nSize);

		}
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_OUTMESSAGE_OUTMESSAGEENTRY))
		{
			pxLocalOUTMessageEntry = NULL;
			memset(&sTempOUTMessageEntry, 0,
			       sizeof(x_IFX_VMAPI_MessageEntry));
			strTemp = strrchr(pxTmpObj->sObjName, '.');	//get the last occurence of '.'
			strTemp++;
			sTempOUTMessageEntry.ucIndex = atoi(strTemp);
			sTempOUTMessageEntry.ucLineId = pxMsgOut->ucLineId;
			ifx_get_MsgInboxEntry(&sTempOUTMessageEntry, 0);
#ifdef __LINUX__
			__ifx_list_add_to_tail((void *)&pxMsgOut->
					       pxMsgEntries,
					       (void *)
					       &pxLocalOUTMessageEntry,
					       sizeof
					       (x_IFX_VMAPI_MessageEntry),
					       &uiErr);
			/* Copy the content in the new location */
			if (pxLocalOUTMessageEntry != NULL)
				memcpy(pxLocalOUTMessageEntry,
				       &sTempOUTMessageEntry,
				       sizeof(x_IFX_VMAPI_MessageEntry));

#endif
		}

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_MsgOutbox function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_get_MsgOUTboxEntry
*  Description    : Api to get Message Outbox entry  object.
*  Input Values   : uiInFlag - Input flags
*  Output Values  : pxMsgOut- pointer to Message Inbox object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int ifx_get_MsgOUTboxEntry(x_IFX_VMAPI_OUT_MessageEntry * pxMsgOutEntry,
			   uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_MsgOUTboxEntry function.");

	char sObjname[MAX_LEN_OBJNAME];
	int nSize, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;

	memset(sObjname, 0,MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d",VOICE_LINE, pxMsgOutEntry->ucLineId
							,OUTMESSAGE_ENTRY,pxMsgOutEntry->ucIndex);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val for MsgOutbox failed");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_OUTMESSAGE_OUTMESSAGEENTRY)
		{
			//getting the number of parameters
			nSize =
			    sizeof(x_IFX_VMAPI_MessageEntry_param) /
			    sizeof(x_IFX_Param);
			fill_struct_param(pxTmpObj, pxMsgOutEntry,
					  x_IFX_VMAPI_MessageEntry_param,
					  nSize);
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_MsgInbox function.");
	return nRetVal;
}
#endif

/******************************************************************************
*  Function Name  : fill_struct_param
*  Description    : Api to dump DB object into data structure
*  Input Values   : pxTmpObj - DB object list
*		    param_detail - global structure strores offset
*		    nSize - size of  global structure
*  Output Values  : pVoipStruct - out data structure
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int fill_struct_param(ObjList * pxTmpObj, void *pVoipStruct,
		      x_IFX_Param param_detail[], int nSize)
{

	int nFlag;
	int nIndex, nRetVal = IFX_VMAPI_SUCCESS;
	ParamList *pxParam = NULL;

	CHECK_FOR_NULL(pxTmpObj, "DB object list is NULL");
	CHECK_FOR_NULL(pVoipStruct, "data structure to be filled  is NULL");
	CHECK_FOR_NULL(param_detail, "Global offset structure is NULL");

	//traverse each param of the objlist
	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		nFlag = 0;
		for (nIndex = 0; nIndex < nSize; nIndex++)	//scan the list to get the required param offset and type info
		{
			if (0 ==
			    strncmp(pxParam->sParamName,
				    param_detail[nIndex].acParamName,
				    sizeof(pxParam->sParamName))) {
				//if name matches get the type and offset to save the value
				switch (param_detail[nIndex].uiType) {
				case IFX_VMAPI_PARAM_TYPE_CHAR:
					*((char *)(pVoipStruct +
						   param_detail[nIndex].
						   unOffset)) =
					    atoi(pxParam->sParamValue);
					nFlag = 1;
					break;
                case IFX_VMAPI_PARAM_TYPE_UCHAR:
                    *((unsigned char *)(pVoipStruct +
                           param_detail[nIndex].
                           unOffset)) =
                        atoi(pxParam->sParamValue);
                    nFlag = 1;
                    break;

				case IFX_VMAPI_PARAM_TYPE_SHORT_INT:
				case IFX_VMAPI_PARAM_TYPE_USHORT_INT:
					*((unsigned short *)(pVoipStruct +
							     param_detail
							     [nIndex].
							     unOffset)) =
					    atoi(pxParam->sParamValue);
					nFlag = 1;
					break;

				case IFX_VMAPI_PARAM_TYPE_INT:
				case IFX_VMAPI_PARAM_TYPE_UINT:
					*((int *)(pVoipStruct +
						  param_detail[nIndex].
						  unOffset)) =
					    atoi(pxParam->sParamValue);
					nFlag = 1;
					break;

				case IFX_VMAPI_PARAM_TYPE_ULONG:
				case IFX_VMAPI_PARAM_TYPE_LONG:
					*((long *)(pVoipStruct +
						   param_detail[nIndex].
						   unOffset)) =
					    atol(pxParam->sParamValue);
					nFlag = 1;
					break;
				case IFX_VMAPI_PARAM_TYPE_FLOAT:
					*((float *)(pVoipStruct +
						    param_detail[nIndex].
						    unOffset)) =
					    atof(pxParam->sParamValue);
					nFlag = 1;
					break;
				case IFX_VMAPI_PARAM_TYPE_STR:
					strcpy(((char *)pVoipStruct +
						param_detail[nIndex].
						unOffset),
					       pxParam->sParamValue);
					nFlag = 1;
					break;

				}

			}
			//if the param is found and processed ,break the loop and check the next param
			if (nFlag == 1)
				break;
		}
	}
      END:
	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_LineCallingFeatures
*  Description    : Set api to set Line Calling features, like call waiting,
*                   DND, etc...
*  Input Values   : uiOperation - Gives Operation to be performed
*                   pxLineCallingFeatures- Pointer to the
*                       x_IFX_VMAPI_LineCallingFeatures object to be set
*                   uiInFlag - Input flags
*  Output Values  : None
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32
ifx_set_LineCallingFeatures(IN uint32 uiOperation,
			    IN x_IFX_VMAPI_LineCallingFeatures *
			    pxLineCallingFeatures, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineCallingFeatures function.");
	char sObjname[MAX_LEN_OBJNAME];
//	char tempstr[TEMP_LEN];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxLineCallingFeatures,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);

    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxLineCallingFeatures->ucLineId,CALLINGFEATURE);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_LEAFNODE, OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for line calling Feature Failed failed");
	
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Line calling Feature success !!!! \n");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_CALLINGFEATURES) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_LineCallingFeatures_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj,
						 pxLineCallingFeatures,
						 x_IFX_VMAPI_LineCallingFeatures_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the calling feature param value in Object list failed");

			nRetVal =
			    HandleVoiceLineCallingFeature(pxTmpObj,
							  pxLineCallingFeatures,
							  VOIP_SET);

			CHECK_FOR_ERROR
			    ("Handling the Line param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for line callingfeature in object list Success.");

			/*Getting the old object */
			x_IFX_VMAPI_LineCallingFeatures
			    xOldLineCallingFeature;
			memset(&xOldLineCallingFeature, 0,
			       sizeof(x_IFX_VMAPI_LineCallingFeatures));
			xOldLineCallingFeature.ucLineId =
			    pxLineCallingFeatures->ucLineId;
			nRetVal =
			    ifx_get_LineCallingFeatures
			    (&xOldLineCallingFeature, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Line Calling Onject failed");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Wrting Line Callingfeature Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Wrting Line Object to DB Success !!!!.");

			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_VL_CALLFEAT,
				     (void *)&xOldLineCallingFeature,
				     (void *)pxLineCallingFeatures);
				CHECK_FOR_ERROR
				    ("Sending Notification for linecalling  object change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for line calling object change Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_LineCallingFeatures function.");

	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_set_PhyInterfaceTestResult
*  Description    : Set api to set Physical Interface Test Result object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxPhyIntTestRes - Pointer to the Physical Interface Test
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_PhyInterfaceTestResult(IN uint32 uiOperation,
				     IN x_IFX_VMAPI_VoiceServTestResult *
				     pxPhyIntTestRes, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_PhyInterfaceTestResult function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxPhyIntTestRes,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, VOICESERVICE_TESTRESULT);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_LEAFNODE */ SOPT_OBJVALUE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for line calling Feature Failed failed");
	
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Line calling Feature success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {

		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909FEMFVOLTRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909HPTVOLTRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909RFTRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909RIRESULT)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVTESTRESULT_X_VENDOR_COM_GR909ROHRESULT))
		{
			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_VoiceServTestResult_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxPhyIntTestRes,
						 x_IFX_VMAPI_VoiceServTestResult_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the VoiceService Test Result param value in Object list failed");

			CHECK_FOR_ERROR
			    ("Handling the Line param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for VoiceService Test Result in object list Success.");

		}
	}
	/*wrintg to DB */
	xObjHdr.unMainOper = MOPT_SET;
	xObjHdr.unSubOper = SOPT_OBJVALUE;
	xObjHdr.unOwner = OWN_SERVD;

	cal_setValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR
	    ("Writing VoiceService Test Result Object to DB Failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Writing VoiceService Test Result Success !!!! \n");

	//Notification not required

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_PhyInterfaceTestResult function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : IFX_VMAPI_SetDebug
*  Description    : Initialize VMAPI.
*  Input Values   :
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 IFX_VMAPI_SetDebug(uchar8 ucType, uchar8 ucLevel)
{
	IFX_DBG_Set("VMAPI", ucVMAPIModuleId, ucType, ucLevel);

	return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_set_VoiceLine
*  Description    : Set api to set VoiceLine object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxVoiceLine - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32_t ifx_set_VoiceLine(IN uint32 uiOperation,
			  IN x_IFX_VMAPI_VoiceLine * pxVoiceLine,
			  IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_VoiceLine function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;
	char8 acAssInte[2*IFX_VMAPI_MAX_VOICE_INTERFACES+1] = { '\0' };

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nIndex = 0, nTempIndex = 0, nRetVal = IFX_VMAPI_SUCCESS;
	CHECK_FOR_NULL(pxVoiceLine,
		       "Error : Input name value object is NULL!!!!");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);

    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",VOICE_LINE,pxVoiceLine->ucLineId);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for line failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Line success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_VoiceLine_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxVoiceLine,
						 x_IFX_VMAPI_VoiceLine_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Line param value in Object list failed");

			nRetVal =
			    HandleVoiceLineParam(pxTmpObj, pxVoiceLine,
						 /*VOIP_SET */ 8);
			CHECK_FOR_ERROR
			    ("Handling the Line param value in Object list failed");

			nIndex = 0;
			/*Creating teh comma separed list for associated interface */
			while (pxVoiceLine->ucAssocVoiceInterface[nIndex] !=
			       0) {
				snprintf(&acAssInte[nTempIndex],sizeof(acAssInte), "%d%s",
					pxVoiceLine->ucAssocVoiceInterface[nIndex],",");

				//strcat(acAssInte, ",");
				nTempIndex = strlen(acAssInte);
				nIndex++;
			}
			ParamList *pxParam = NULL;
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if ((strcmp
				     (pxParam->sParamName,
				      "PhyReferenceList") == 0)) {
					strncpy(pxParam->sParamValue,
						acAssInte,
						sizeof(pxVoiceLine->
						       ucAssocVoiceInterface));
				}
			}

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for line in object list Success.");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Line object list to DB !!!!");

			/*Getting the old object */
			x_IFX_VMAPI_VoiceLine xOldVoiceLine;
			memset(&xOldVoiceLine, 0,
			       sizeof(x_IFX_VMAPI_VoiceLine));
			xOldVoiceLine.ucLineId = pxVoiceLine->ucLineId;
			nRetVal = ifx_get_VoiceLine(&xOldVoiceLine, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Line Onject failed");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

		      //HELP_PRINT_MSG(&xObjHdr);       
			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR("Wrting Line Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Wrting Line Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_VL_SIGNALING,
				     (void *)&xOldVoiceLine,
				     (void *)pxVoiceLine);
				CHECK_FOR_ERROR
				    ("Sending Notification for line object change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for line object change Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_VoiceLine function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_LineEvents
*  Description    : Set api to set LineEvents object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxLineEvents - Pointer to the object to be set
*  Output Values  : pxLineEvents - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_LineEvents(IN uint32 uiOperation,
			 IN x_IFX_VMAPI_LineEvents * pxLineEvents,
			 IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineEvents function.");
	char sObjname[MAX_LEN_OBJNAME];
	//char tempstr[TEMP_LEN];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxLineEvents,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s%d%s",VOICE_LINE,pxLineEvents->ucLineId,
					LINE_EVENT_SUSCRIBE,pxLineEvents->ucIndex,DOT);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for line event failed");

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Line event success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_VOICEPROFILE_LINE_SIP_EVENTSUBSCRIBE) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_LineEvents_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxLineEvents,
						 x_IFX_VMAPI_LineEvents_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Line event param value in Object list failed");

			nRetVal =
			    HandleVoiceLineEvent(pxTmpObj, pxLineEvents,
						 VOIP_SET);
			CHECK_FOR_ERROR
			    ("Handling the Line even param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for line in object list event Success.");

			/*Getting the old object */
			x_IFX_VMAPI_LineEvents xOldLineEvent;
			memset(&xOldLineEvent, 0,
			       sizeof(x_IFX_VMAPI_LineEvents));
			xOldLineEvent.ucLineId = pxLineEvents->ucLineId;
			xOldLineEvent.ucIndex = pxLineEvents->ucIndex;
			nRetVal = ifx_get_LineEvents(&xOldLineEvent, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Line Object failed");

			/*writing to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			//HELP_PRINT_MSG(&xObjHdr);     
			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Line even Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Line event Object to DB Success !!!!.");

			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_MAX_OBJ,
				     (void *)&xOldLineEvent,
				     (void *)pxLineEvents);
				CHECK_FOR_ERROR
				    ("Sending Notification for line even object change failed");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notification sent for line even object change Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_LineEvents function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_Misc
*  Description    : Set api to get Misc object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMisc - Pointer to the object to be set
*  Output Values  : pxMisc - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_Misc(IN uint32 uiOperation,
		   IN x_IFX_VMAPI_Misc * pxMisc, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_LineEvents function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxMisc,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, VOICESEEVICE_MISCELLANEOUS);

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Miscellaneous object failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Miscellaneous success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_MISCELLANEOUS) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_Misc_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxMisc,
						 x_IFX_VMAPI_Misc_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Miscellaneous param values in Object list failed");

			nRetVal = HandleMiscParam(pxTmpObj, pxMisc, VOIP_SET);
			CHECK_FOR_ERROR
			    ("Handling the Miscellaneous param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Miscellaneous in object list event Success.");

			/*Getting the old object */
			x_IFX_VMAPI_Misc xOldMisc;
			memset(&xOldMisc, 0, sizeof(x_IFX_VMAPI_Misc));

			nRetVal = ifx_get_Misc(&xOldMisc, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Miscellaneous Object failed");

			/*writing to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			//HELP_PRINT_MSG(&xObjHdr);     
			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Miscellaneous Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Miscellaneous Object to DB Success !!!!");

			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				/*sending the notification */
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_VS_MISC, (void *)&xOldMisc,
				     (void *)pxMisc);
				CHECK_FOR_ERROR
				    ("Sending Notification for Miscellaneous object change failed");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notification sent for Miscellaneous object change Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_Misc function.");

	return nRetVal;

}

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
/******************************************************************************
*  Function Name  : ifx_set_DectHandset
*  Description    : Set api to set DectHandset object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDectHand - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_DectHandset(IN uint32 uiOperation,
			  IN x_IFX_VMAPI_DectHandset * pxDectHand,
			  IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_DectHandset function.");
	char sObjname[MAX_LEN_OBJNAME];
	//char tempstr[TEMP_LEN];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxDectHand,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
    snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",DECT_HANDSET,pxDectHand->xVoiceServPhyIf.ucInterfaceId - 3);
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE /*SOPT_LEAFNODE */ ,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect Handset failed");
	//        HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect Handset success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {

		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET_X_VENDOR_COM_DECTSUBSINFO)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET_X_VENDOR_COM_VOICESERVPHYIF))
		{

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_DectHandset_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxDectHand,
						 x_IFX_VMAPI_DectHandset_param,
						 nSize);
			//HELP_PRINT_MSG(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Updating the dect handset param value in Object list failed");

			if (GET_OBJ_OID(pxTmpObj) ==
			    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM_X_VENDOR_COM_DECTHANDSET)
			{
			/*	HandleDectHandsetParam(pxTmpObj, pxDectHand,
						       VOIP_SET);*/
			}
			CHECK_FOR_ERROR
			    ("Handling the dect handset param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for DectHandset in object list Success.");

		}
	}

	/*Getting the old object */
	x_IFX_VMAPI_DectHandset xOldDectHandset;
	memset(&xOldDectHandset, 0, sizeof(x_IFX_VMAPI_DectHandset));
	xOldDectHandset.xVoiceServPhyIf.ucInterfaceId =
	    pxDectHand->xVoiceServPhyIf.ucInterfaceId;
	nRetVal = ifx_get_DectHandset(&xOldDectHandset, 0);
	CHECK_FOR_ERROR("Getting Existing DectHandset Onject failed");

	/*wrintg to DB */
	xObjHdr.unMainOper = MOPT_SET;
	xObjHdr.unSubOper = SOPT_OBJVALUE;
	xObjHdr.unOwner = OWN_SERVD;

	//HELP_PRINT_MSG(&xObjHdr);     
	cal_setValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Writing DEctHandset Object to DB Failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Writing Line Object to DB Success !!!!");

	//Notification
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
		nRetVal =
		    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_PHY_IFACE_DECT,
						     (void *)&xOldDectHandset,
						     (void *)pxDectHand);
		CHECK_FOR_ERROR
		    ("Sending Notification for DectHandset object change failes");
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Notification sent for DectHandset object change Success!!!!");

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_DectHandset function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_DectInterface
*  Description    : Set api to set VoiceProfile object.
q
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDectInf - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_DectInterface(IN uint32 uiOperation,
			    IN x_IFX_VMAPI_DectSystem * pxDectInf,
			    IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_DectInterface function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	x_IFX_VMAPI_DectSystem xOldDectSystem;
       
    memset(&xOldDectSystem, 0,
                   sizeof(x_IFX_VMAPI_DectSystem));


	CHECK_FOR_NULL(pxDectInf,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_INTERFACE);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect System  failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect System success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTSYSTEM) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_DectHandset_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxDectInf,
						 x_IFX_VMAPI_DectHandset_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the DectSystem param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for DectSystem in object list Success !!!!");


			/*Getting the old object */
			x_IFX_VMAPI_DectSystem xOldDectSystem;
			memset(&xOldDectSystem, 0,
			       sizeof(x_IFX_VMAPI_DectSystem));
			nRetVal = ifx_get_DectInterface(&xOldDectSystem, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing DectSystem Object failed");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR("Wrting Line Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Wrting Line Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_DECT_SYSTEM,
				     (void *)&xOldDectSystem,
				     (void *)pxDectInf);
				CHECK_FOR_ERROR
				    ("Sending Notification for DectSystem object change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for DectSystem change Success!!!! \n");

			}
			break;
		}
	}

END:
    if(xOldDectSystem.pxHandsetTbl != NULL || xOldDectSystem.pxCodecList != NULL){
        ifx_vmapi_freeObjectList(&xOldDectSystem,IFX_VMAPI_DECT_SYSTEM);
    }
    if(pxDectInf->pxHandsetTbl != NULL || pxDectInf->pxCodecList != NULL){
        ifx_vmapi_freeObjectList(pxDectInf,IFX_VMAPI_DECT_SYSTEM);
    }

	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_DectInterface function.");

	return nRetVal;

}
#endif

/******************************************************************************
*  Function Name  : ifx_set_FxoPhyInterface
*  Description    : Set api to get FxoPhyInterface object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxFxoPhyIf - Pointer to the object to be set
*  Output Values  : pxFxoPhyIf - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_FxoPhyInterface(IN uint32 uiOperation,
			      IN x_IFX_VMAPI_FxoPhyIf * pxFxoPhyIf,
			      IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_FxoPhyInterface function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxFxoPhyIf,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, FXO_INTERFACE);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Fxo failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Fxo success !!!! \n");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXOPHYIF) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_FxoPhyIf_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxFxoPhyIf,
						 x_IFX_VMAPI_FxoPhyIf_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Fxo param values in Object list failed");

			HandleFxoPhyInterface(pxTmpObj, pxFxoPhyIf, VOIP_SET);
			CHECK_FOR_ERROR
			    ("Handling the Fxo param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Fxo in object list Success.");


			/*Getting the old object */
			x_IFX_VMAPI_FxoPhyIf xOldFxoInterface;
			memset(&xOldFxoInterface, 0,
			       sizeof(x_IFX_VMAPI_FxoPhyIf));
			nRetVal =
			    ifx_get_FxoPhyInterface(&xOldFxoInterface, 0);
			CHECK_FOR_ERROR("Getting Existing Fxo Object failed");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR("Wrting Fxo Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Wrting Fxo  Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_PHY_IFACE_FXO,
				     (void *)&xOldFxoInterface,
				     (void *)pxFxoPhyIf);
				CHECK_FOR_ERROR
				    ("Sending Notification for DectSystem object change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for DectSystem change Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_FxoPhyInterface function.");

	return nRetVal;

}

#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
/******************************************************************************
*  Function Name  : ifx_set_Rfpi
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_Rfpi(IN uint32 uiOperation,
		   IN x_IFX_VMAPI_DectRfpi * pxRfpi, IN uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_Rfpi function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxRfpi,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_RFPI);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect Rfpi failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect Rfpi success !!!! \n");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTRFPI) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_DectRfpi_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxRfpi,
						 x_IFX_VMAPI_DectRfpi_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Rfpi param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Rfpi in object list Success.");

			/*Getting the old object */
			x_IFX_VMAPI_DectRfpi xOldRfpi;
			memset(&xOldRfpi, 0, sizeof(x_IFX_VMAPI_DectRfpi));
			nRetVal = ifx_get_Rfpi(&xOldRfpi, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Dect Rfpi Object failed");


			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Dect Rfpi Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Dect Rfpi Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_RFPI_TEST, (void *)&xOldRfpi,
				     (void *)pxRfpi);
				CHECK_FOR_ERROR
				    ("Sending Notification for Dect Rfpi object change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for Dect Rfpi change Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_Rfpi function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_Bmcparam
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_Bmcparam(IN uint32 uiOperation,
		       IN x_IFX_VMAPI_DectBMCParams * pxBmcparam,
		       IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_Bmcparam function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxBmcparam,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_BMC);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect BMC  failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect BMC success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTBMCPARAMS) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_DectBMCParams_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxBmcparam,
						 x_IFX_VMAPI_DectBMCParams_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the BMC param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for BMC  in object list Success.");

			/*Getting the old object */
			x_IFX_VMAPI_DectBMCParams xOldDectBmcParam;
			memset(&xOldDectBmcParam, 0,
			       sizeof(x_IFX_VMAPI_DectBMCParams));
			nRetVal = ifx_get_Bmcparam(&xOldDectBmcParam, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Dect BMC Object failed");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;
			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Dect BMC Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Dect BMC Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				/*sending teh notification */
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_BMC_REG_PARAMS_TEST,
				     (void *)&xOldDectBmcParam,
				     (void *)pxBmcparam);
				CHECK_FOR_ERROR
				    ("Sending Notification for Dect BMC object change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for Dect BMC change Success");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_Bmcparam function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_TransPower
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_TransPower(IN uint32 uiOperation,
			 IN x_IFX_VMAPI_TransmitPowerParam * pxTransPower,
			 IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_TransPower function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxTransPower,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_TRANSPOWER);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect TransPower  failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect TransPower success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_TRANSMITPOWERPARAM) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_TransmitPowerParam_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxTransPower,
						 x_IFX_VMAPI_TransmitPowerParam_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the TransPower param values in Object list failed");

			nRetVal =
			    HandleTransPower(pxTmpObj, pxTransPower,
					     VOIP_SET);
			CHECK_FOR_ERROR
			    ("Handling the TransPower param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for TransPower  in object list Success.");

			/*Getting the old object */
			x_IFX_VMAPI_TransmitPowerParam xOldTransPower;
			memset(&xOldTransPower, 0,
			       sizeof(x_IFX_VMAPI_TransmitPowerParam));
			nRetVal = ifx_get_TransPower(&xOldTransPower, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Dect TransPower Object failed");


			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Dect TransPower Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Dect TransPower Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_TRANS_POWER_TEST,
				     (void *)&xOldTransPower,
				     (void *)pxTransPower);
				CHECK_FOR_ERROR
				    ("Sending Notification for Dect TransPowerobject change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for Dect TransPowerchange Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_TransPower function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_rfmode
*  Description    : Set api to set Voice System RF Mode object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxRfmode - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_rfmode(IN uint32 uiOperation,
		     IN x_IFX_VMAPI_RFMode * pxRfmode, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_rfmode function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxRfmode,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_RFMODE);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect RfMode  failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect RfMode success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_RFMODE) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_RFMode_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxRfmode,
						 x_IFX_VMAPI_RFMode_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the RfMode param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for RfMode  in object list Success");

			/*Getting the old object */
			x_IFX_VMAPI_RFMode xOldRfMode;
			memset(&xOldRfMode, 0, sizeof(x_IFX_VMAPI_RFMode));
			nRetVal = ifx_get_rfmode(&xOldRfMode, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Dect RfMode  Object failed");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Dect RfMode Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Dect RfMode Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_RF_MODE_TEST,
				     (void *)&xOldRfMode, (void *)pxRfmode);
				CHECK_FOR_ERROR
				    ("Sending Notification for Dect RfMode  change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for Dect RfMode Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_rfmode function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_Gfsk
*  Description    : Set api to set Voice System Osc trim object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxOsctrim - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_Gfsk(IN uint32 uiOperation,
		   IN x_IFX_VMAPI_DectGFSKVal * pxGfsk, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_Gfsk function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxGfsk,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_GFSK);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect Gfsk  failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect Gfsk success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTGFSKVAL) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_DectGFSKVal_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxGfsk,
						 x_IFX_VMAPI_DectGFSKVal_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Gfsk param values in Object list failed");

			CHECK_FOR_ERROR
			    ("Handling the Gfsk param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Gfsk in object list Success.");

			/*Getting the old object */
			x_IFX_VMAPI_DectGFSKVal xOldGfsk;
			memset(&xOldGfsk, 0, sizeof(x_IFX_VMAPI_DectGFSKVal));
			nRetVal = ifx_get_Gfsk(&xOldGfsk, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Dect Gfsk  Object failed");


			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Dect Gfsk Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Dect Gfsk Object to DB Success !!!!.");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_GFSK_TEST, (void *)&xOldGfsk,
				     (void *)pxGfsk);
				CHECK_FOR_ERROR
				    ("Sending Notification for Dect Gfsk  change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for Dect Gfsk Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_Gfsk function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_Osctrim
*  Description    : Set api to set Voice System Osc trim object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxOsctrim - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_Osctrim(IN uint32 uiOperation,
		      IN x_IFX_VMAPI_DectOscTrimVal * pxOsctrim,
		      IN uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_Osctrim function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	ParamList *pxParam = NULL;	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxOsctrim,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_OCS_TRIM);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect Ocstrim failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect Ocstrim success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTOSCTRIMVAL) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_DectOscTrimVal_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxOsctrim,
						 x_IFX_VMAPI_DectOscTrimVal_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the ocstrim param values in Object list failed");

			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (pxParam->unParamId ==
				    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTOSCTRIMVAL_X_VENDOR_COM_P10STATUS)
				{
					if (pxOsctrim->ucDectP10Status ==
					    IFX_VMAPI_DECT_OSCTRIM_P10_ON)
						strcpy(pxParam->sParamValue,
						       OSCTRIM_P10_ON);
					else if (pxOsctrim->ucDectP10Status ==
						 IFX_VMAPI_DECT_OSCTRIM_P10_OFF)
						strcpy(pxParam->sParamValue,
						       OSCTRIM_P10_OFF);
				}
			}

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for ocstrim in object list Success.");

			/*Getting the old object */
			x_IFX_VMAPI_DectOscTrimVal xOldOcstrim;
			memset(&xOldOcstrim, 0,
			       sizeof(x_IFX_VMAPI_DectOscTrimVal));
			nRetVal = ifx_get_Osctrim(&xOldOcstrim, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Dect ocstrim  Object failed");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Dect ocstrim Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Dect ocstrim Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_OSC_TRIM_TEST,
				     (void *)&xOldOcstrim, (void *)pxOsctrim);
				CHECK_FOR_ERROR
				    ("Sending Notification for Dect Ocstrim change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for Dect Ocstrim Success.");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_rfmode function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_CtrySet
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_CtrySet(IN uint32 uiOperation,
		      IN x_IFX_VMAPI_DectCountrySettings * pxCtryset,
		      IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_CtrySet function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxCtryset,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_CNTRY_SETT);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect CountrySettings  failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect CountrySettings success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTCOUNTRYSETTINGS) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_DectCountrySettings_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxCtryset,
						 x_IFX_VMAPI_DectCountrySettings_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the CountrySettings param values in Object list failed");

			nRetVal =
			    HandleCtrySetParam(pxTmpObj, pxCtryset, VOIP_SET);
			CHECK_FOR_ERROR
			    ("Handling the CountrySettings param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for CountrySettings in object list Success.");

			/*Getting the old object */
			x_IFX_VMAPI_DectCountrySettings xOldCntrySet;
			memset(&xOldCntrySet, 0,
			       sizeof(x_IFX_VMAPI_DectCountrySettings));
			nRetVal = ifx_get_CtrySet(&xOldCntrySet, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Dect CountrySettings Object failed");


			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Dect CountrySettings Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Dect CountrySettings Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_COUNTRY_SETTINGS_TEST,
				     (void *)&xOldCntrySet,
				     (void *)pxCtryset);
				CHECK_FOR_ERROR
				    ("Sending Notification for Dect CountrySettings change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for Dect CountrySettings Success");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_CtrySet function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_Xram
*  Description    : Set api to set Voice System Transmit Power object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                   uiInFlag - Input flags
*                   pxTransPower - Pointer to the object to be set
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_Xram(IN uint32 uiOperation,
		   IN x_IFX_VMAPI_DectXRAM * pxXram, IN uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_Xram function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxXram,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, DECT_XRAM);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Dect Xram  failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Dect Xram success !!!! \n");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_DECTXRAM) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_DectXRAM_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxXram,
						 x_IFX_VMAPI_DectXRAM_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Xram param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Xram  in object list Success");

			/*Getting the old object */
			x_IFX_VMAPI_DectXRAM xOldXram;
			memset(&xOldXram, 0, sizeof(x_IFX_VMAPI_DectXRAM));
			nRetVal = ifx_get_Xram(&xOldXram, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing Dect Xram  Object failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Xram object list to DB");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			/*DB would have updated with the new values,
					so Updating with the new Type value to avoid overrting with old value*/
			ParamList *pxParam = NULL;
			FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
            	if(!strncmp(pxTmpObj->sObjName, sObjname,MAX_LEN_OBJNAME)){
					FOR_EACH_PARAM(pxTmpObj, pxParam) {
						if(strncmp(GET_PARAM_NAME(pxParam),"X_VENDOR_COM_Type",MAX_LEN_PARAM_NAME) == 0){
							snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%d",xOldXram.ucType);
							break;
                    	}
                	}
            	}
			}
			
			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing Dect Xram Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing Dect Xram Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_XRAM_TEST, (void *)&xOldXram,
				     (void *)pxXram);
				CHECK_FOR_ERROR
				    ("Sending Notification for Dect Xram change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for Dect Xram Success");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_Xram  function.");

	return nRetVal;

}
#endif

int32 get_MaxContactListEntryIndex(char *sObjname,int nEntryType)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter get_MaxContactListEntryIndex function.");

	int nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj;
	MsgHeader xObjHdr;
	int32 nCount = 0;
	int32 nNumberOfEnties = 0;
	char *strTemp;
	ParamList *pxParam = NULL;
	int32 nLen = strlen(sObjname);
	
	memset(&xObjHdr, 0, sizeof(MsgHeader));

	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	/* to query particular parameter for given object */

	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Val failed for contact list falied");

    if(nLen > 0 && sObjname[nLen-1] == '.'){
                 sObjname[nLen-1] = '\0';
     }

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
            if(!strncmp(pxTmpObj->sObjName, sObjname,MAX_LEN_OBJNAME)){
                 FOR_EACH_PARAM(pxTmpObj, pxParam) {
                    if(strncmp(GET_PARAM_NAME(pxParam),"X_VENDOR_COM_NoOfEntries",MAX_LEN_PARAM_NAME) == 0){
						nNumberOfEnties = atoi(pxParam->sParamValue);

            		}
				}
			}
	switch(nEntryType){
		case 1:
			if(strstr(pxTmpObj->sObjName,"X_VENDOR_COM_ContactListEntry")){
					nCount++;
					if(nCount == nNumberOfEnties){
				         /* strip the last . in object name to get the instance number*/
				        int32_t nLen = strlen(pxTmpObj->sObjName);
        				if(nLen > 0 && pxTmpObj->sObjName[nLen-1] == '.')
            					pxTmpObj->sObjName[nLen-1] = '\0';
        				strTemp = strrchr (pxTmpObj->sObjName, '.'); //get the last occurence of '.'
        				strTemp++;
        				nRetVal = atoi(strTemp);

					}
									
				}
		break;

		case 2:
			if(strstr(pxTmpObj->sObjName,"CallRegEntry")){
                nCount++;
                if(nCount == nNumberOfEnties){
                         /* strip the last . in object name to get the instance number*/
                        int32_t nLen = strlen(pxTmpObj->sObjName);
                        if(nLen > 0 && pxTmpObj->sObjName[nLen-1] == '.')
                                pxTmpObj->sObjName[nLen-1] = '\0';
                        strTemp = strrchr (pxTmpObj->sObjName, '.'); //get the last occurence of '.'
                        strTemp++;
                        nRetVal = atoi(strTemp);
                }

        	}
			break;
		}
		if(nRetVal != 0)
			goto END;
	
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit get_MaxContactListEntryIndex function.");
	return nRetVal;
}
/******************************************************************************
*  Function Name  : ifx_set_ContactListEntry
*  Description    : Set api to get ContactListEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactListEtr - Pointer to the object to be set
*  Output Values  : pxContactListEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_ContactListEntry(IN uint32 uiOperation,
			       IN x_IFX_VMAPI_ContactListEntry *
			       pxContactListEtr, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_ContactListEntry function.");
	char sObjname[MAX_LEN_OBJNAME] = { 0 };
	char sTempObjname[MAX_LEN_OBJNAME] = { 0 };
	char tempstr[TEMP_LEN] = { 0 };
	int32_t nSize = 0;
	char sName[MAX_LEN_OBJNAME] = { 0 };

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	memset(sObjname,0, MAX_LEN_OBJNAME);
	x_IFX_VMAPI_ContactList xOldContactList;
	x_IFX_VMAPI_ContactList xNewContactList;
	x_IFX_VMAPI_ContactListEntry xOldContactListEntry;

	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	CHECK_FOR_NULL(pxContactListEtr,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
	if (pxContactListEtr->ucLineId == PSTN_LINE) {
		snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,CONTACT_LIST_ENTRY);
	} else {
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxContactListEtr->ucLineId,CONTACT_LIST_ENTRY);
	}
	strncpy(sTempObjname, sObjname, sizeof(sObjname));
	strncat(sTempObjname,CONTACT_ADDRESS,sizeof(CONTACT_ADDRESS));

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	memset(&xOldContactList, 0, sizeof(x_IFX_VMAPI_ContactList));
	memset(&xOldContactListEntry, 0,
	       sizeof(x_IFX_VMAPI_ContactListEntry));

	/*Getting the old call register for Notification */
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {

		memset(&xOldContactList, 0, sizeof(x_IFX_VMAPI_ContactList));

		xOldContactList.ucLineId = pxContactListEtr->ucLineId;
		nRetVal = ifx_get_ContactList(&xOldContactList, 0);

	}

	switch (uiOperation) {
	case IFX_OP_DEL:
		memset(tempstr,0,TEMP_LEN);
		snprintf(tempstr,TEMP_LEN,"%d", pxContactListEtr->ucIndex);
		strncat(sObjname,tempstr,sizeof(tempstr));

		HELP_CREATE_MSG(&xObjHdr, MOPT_SET, SOPT_OBJVALUE, OWN_SERVD,
				1);
		HELP_OBJECT_SET(xObjHdr.pObjType, sObjname, 100, OBJOPT_DEL,
				xObjHdr.unSubOper);
		nRetVal = cal_setValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Deletion of ContactList entry failed");
		break;

	case IFX_OP_MOD:
		memset(tempstr,0,TEMP_LEN);
        snprintf(tempstr,TEMP_LEN,"%d",pxContactListEtr->ucIndex);
        strncat(sObjname,tempstr,sizeof(tempstr));


		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		/*Get the Object from DB */
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Contact List Entry failed");
		CHECK_FOR_NULL(xObjHdr.pObjType, "output object null");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Get Value for Contact List Entry success !!!!");
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {


			nSize =
			    sizeof(x_IFX_VMAPI_ContactListEntry_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxContactListEtr,
						 x_IFX_VMAPI_ContactListEntry_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Contact List Entry param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Contact List Entry in object list Success.");
		}
		xObjHdr.unMainOper = MOPT_SET;
		xObjHdr.unSubOper = SOPT_OBJVALUE;
		xObjHdr.unOwner = OWN_SERVD;

		nRetVal = cal_setValueWrapper(&xObjHdr);

		CHECK_FOR_ERROR
		    ("Writing Contact List entry Object to DB Failed");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Writing Contact List Object to DB Success !!!!");
		break;
	case IFX_OP_ADD:
		HELP_CREATE_MSG(&xObjHdr, MOPT_GET,
				SOPT_OBJVALUE | SOPT_DEFVAL, OWN_SERVD, 1);
		if (pxContactListEtr->ucLineId == PSTN_LINE) {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_PSTNCONTACTLISTENTRY_PATH,
					xObjHdr.unSubOper);
		} else {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_CONTACTLISTENTRY_PATH,
					xObjHdr.unSubOper);
		}
		/*Get the Object from DB */
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Contact List Entry failed");
		CHECK_FOR_NULL(xObjHdr.pObjType, "output object null");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Get Value for Contact List Entry success !!!!");
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {

			/*Update the object name in case of ADD operation */
			if ((strcmp
			     (pxTmpObj->sObjName,
			      DEF_CONTACTLISTENTRY_PATH) == 0)
			    ||
			    (strcmp
			     (pxTmpObj->sObjName,
			      DEF_PSTNCONTACTLISTENTRY_PATH) == 0)) {
				strncpy(pxTmpObj->sObjName, sObjname,
					sizeof(sObjname));
			}
			nSize =
			    sizeof(x_IFX_VMAPI_ContactListEntry_param) /
			    sizeof(x_IFX_Param);
				/*Getting the max instance number existing in DB
				to set new index*/
				snprintf(sName,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxContactListEtr->ucLineId,CONTACT_LIST);	
				int32 nIndex = get_MaxContactListEntryIndex(sName,1);
				
				pxContactListEtr->ucLineId = xOldContactList.ucLineId; 
				pxContactListEtr->uiEntryId = nIndex + 1;
				pxContactListEtr->ucIndex = nIndex + 1; 
			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxContactListEtr,
						 x_IFX_VMAPI_ContactListEntry_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Contact List Entry param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Contact List Entry in object list Success");
			pxTmpObj->unObjOper = OBJOPT_ADD;
		}
		/*wrintg to DB */
		xObjHdr.unSubOper = SOPT_OBJVALUE;
		pxTmpObj->unObjOper = OBJOPT_ADD;
		xObjHdr.unOwner = OWN_SERVD;

		nRetVal = cal_setValueWrapper(&xObjHdr);

		CHECK_FOR_ERROR
		    ("Writing Contact List entry Object to DB Failed");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Writing Contact List Object to DB Success !!!!");

		break;
	}

	/*Notification */
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
		/*Getting the old call register for Notification */
		memset(&xNewContactList, 0, sizeof(x_IFX_VMAPI_ContactList));
		xNewContactList.ucLineId = pxContactListEtr->ucLineId;
		nRetVal = ifx_get_ContactList(&xNewContactList, 0);
		CHECK_FOR_ERROR("Getting New MissCall register failed");

		/*sending teh notification */
		nRetVal =
		    IFX_VMAPI_SendNotifyForRegObject
		    (IFX_VMAPI_VS_CONTACT_LIST, (void *)&xOldContactList,
		     (void *)&xNewContactList);
		CHECK_FOR_ERROR
		    ("Sending Notification for  MissCall Register object change failes");
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Notifiaction sent for  MissCall Register  object change Success");
	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_ContactListEntry function.");

	return nRetVal;

}
/******************************************************************************
*  Function Name  : ifx_del_FirstEntry
*  Description    : Deletes the fist entry of given object.
*  Input Values   : nInstanceNo - Instance number to be deleted
*                   sObjname - Name of the object to be deleted
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32_t ifx_del_FirstEntry(int nInstanceNo, char * sObjname)
{
	
	char sName[MAX_LEN_OBJNAME] = { 0 };
	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	MsgHeader xObjHdr;

	memset(sName,0, MAX_LEN_OBJNAME);
	snprintf(sName,MAX_LEN_OBJNAME,"%s%d",sObjname,nInstanceNo);
	HELP_CREATE_MSG(&xObjHdr, MOPT_SET, SOPT_OBJVALUE, OWN_SERVD,1);
	HELP_OBJECT_SET(xObjHdr.pObjType,sName, 100, OBJOPT_DEL,
												xObjHdr.unSubOper);
	nRetVal = cal_setValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Deletion of Fist instance failed failed");

END:
	HELP_DELETE_MSG(&xObjHdr);
    return nRetVal;

}
/******************************************************************************
*  Function Name  : ifx_set_MissCallRegEntry
*  Description    : Set api to get MissCallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxMissCallRegEtr - Pointer to the object to be set
*  Output Values  : pxMissCallRegEtr - pointer to Misscall register entry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_MissCallRegEntry(IN uint32 uiOperation,
			       IN x_IFX_VMAPI_MissCallRegEntry *
			       pxMissCallRegEtr, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_MissCallRegEntry function.");
	char sObjname[MAX_LEN_OBJNAME];
	char tempstr[10];
	char sName[MAX_LEN_OBJNAME] = { 0 };
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	
	ParamList *pxParam = NULL;

	memset(sObjname,0, MAX_LEN_OBJNAME);
	x_IFX_VMAPI_MissCallRegister xOldCallReg;
	x_IFX_VMAPI_MissCallRegister xNewCallReg;

	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	int nInstanceNo = 0;
	CHECK_FOR_NULL(pxMissCallRegEtr,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
	if (pxMissCallRegEtr->ucLineId == PSTN_LINE) {
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,MISS_CALLREG_ENTRY);

	} else {
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxMissCallRegEtr->ucLineId,MISS_CALLREG_ENTRY);

	}
	
	 memset(&xObjHdr, 0, sizeof(MsgHeader));
	/*Getting the old call register for Notification */
	memset(&xOldCallReg, 0, sizeof(x_IFX_VMAPI_MissCallRegister));
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {

		xOldCallReg.ucLineId = pxMissCallRegEtr->ucLineId;
		nRetVal = ifx_get_MissCallReg(&xOldCallReg, 0);

	}

	if (uiOperation == IFX_OP_DEL) {

        memset(tempstr,0,TEMP_LEN);
        snprintf(tempstr,TEMP_LEN,"%d", pxMissCallRegEtr->uiEntryId);
        strncat(sObjname,tempstr,sizeof(tempstr));

		HELP_CREATE_MSG(&xObjHdr, MOPT_SET, SOPT_OBJVALUE, OWN_SERVD,
				1);
		HELP_OBJECT_SET(xObjHdr.pObjType, sObjname, 100, OBJOPT_DEL,
				xObjHdr.unSubOper);
		nRetVal = cal_setValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Deletion of Missed call register failed");
		goto END;

	} else if (uiOperation == IFX_OP_ADD) {
		
		if(xOldCallReg.ucNoOfEntries >= IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE){
			if(xOldCallReg.pxCallRegEntries != NULL)
				nInstanceNo = xOldCallReg.pxCallRegEntries->uiEntryId;
			nRetVal = ifx_del_FirstEntry(nInstanceNo,sObjname);
			CHECK_FOR_ERROR("Deletion fo First Entry Failed");
		}		
		HELP_CREATE_MSG(&xObjHdr, MOPT_GET,
				SOPT_OBJVALUE | SOPT_DEFVAL, OWN_SERVD, 1);
		if (pxMissCallRegEtr->ucLineId == PSTN_LINE) {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_PSTNMISSCALLREGENTRY_PATH,
					xObjHdr.unSubOper);
		} else {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_MISSCALLREGENTRY_PATH,
					xObjHdr.unSubOper);
		}
		/*Get the Object from DB */
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR
		    ("Get Value for Misscall Register default failed");
		CHECK_FOR_NULL(xObjHdr.pObjType, "output object null");
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Get Value for Misscall Register default success !!!! \n");
		/*update the modified value in Objectlist */
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
			if ((strcmp
			     (pxTmpObj->sObjName,
			      DEF_MISSCALLREGENTRY_PATH) == 0)
			    ||
			    (strcmp
			     (pxTmpObj->sObjName,
			      DEF_PSTNMISSCALLREGENTRY_PATH) == 0)) {
				strncpy(pxTmpObj->sObjName, sObjname,
					sizeof(sObjname));
			}
			nSize =
			    sizeof(x_IFX_VMAPI_CallRegEntry_param) /
			    sizeof(x_IFX_Param);

                /*Getting the max instance number existing in DB
                to set new index*/
                snprintf(sName,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxMissCallRegEtr->ucLineId,MISS_CALLREG);
                int32 nIndex = get_MaxContactListEntryIndex(sName,2);
				pxMissCallRegEtr->uiEntryId = nIndex + 1;
                pxMissCallRegEtr->ucIndex = nIndex + 1;

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxMissCallRegEtr,
						 x_IFX_VMAPI_CallRegEntry_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the MissCall Register param value in Object list failed");

            /*Fix for issue recvcall is not getting registered from soft phone
            as display name is containing quotes which json format error while display
            so removing the "" from display name.*/
            FOR_EACH_PARAM(pxTmpObj, pxParam) {
                    if(strncmp(GET_PARAM_NAME(pxParam),"X_VENDOR_COM_DisplayName",MAX_LEN_PARAM_NAME) == 0){
                        char *sTempVal;
                        sTempVal = GET_PARAM_VALUE(pxParam);
                        if(sTempVal[0] == '\"'){
                            (sTempVal)++;
                        }
                        if(sTempVal[strlen(sTempVal)-1] == '\"'){
                            sTempVal[strlen(sTempVal)-1] = '\0';
                        }
                        strncpy(pxParam->sParamValue,sTempVal,MAX_LEN_PARAM_VALUE);
                    }
            }


			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for MissCall Register in object list Success !!!!");
			pxTmpObj->unObjOper = OBJOPT_ADD;
		}

		
		//HELP_PRINT_MSG(&xObjHdr);
		/*wrintg to DB */
		xObjHdr.unSubOper = SOPT_OBJVALUE;
		pxTmpObj->unObjOper = OBJOPT_ADD;
		xObjHdr.unOwner = OWN_SERVD;

		nRetVal = cal_setValueWrapper(&xObjHdr);

		CHECK_FOR_ERROR
		    ("Writing Miss callregister entry Object to DB Failed");
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Writing Miss callregister entry Object to DB Success !!!!");
	}
	//Notification
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
		/*Getting the old call register for Notification */
		memset(&xNewCallReg, 0, sizeof(x_IFX_VMAPI_MissCallRegister));
		xNewCallReg.ucLineId = pxMissCallRegEtr->ucLineId;
		nRetVal = ifx_get_MissCallReg(&xNewCallReg, 0);
		CHECK_FOR_ERROR("Getting New MissCall register failed");
		/*sending the notification */
		nRetVal =
		    IFX_VMAPI_SendNotifyForRegObject
		    (IFX_VMAPI_VS_MISSCALL_REGISTER, (void *)&xOldCallReg,
		     (void *)&xNewCallReg);
		CHECK_FOR_ERROR
		    ("Sending Notification for  MissCall Register object change failes");
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Notifiaction sent for  MissCall Register  object change Success");
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_MissCallRegEntry function.");

	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_set_DialCallRegEntry
*  Description    : Set api to get CallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxDialCallRegEtr - Pointer to the object to be set
*  Output Values  : pxDialCallRegEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_DialCallRegEntry(IN uint32 uiOperation,
			       IN x_IFX_VMAPI_DialCallRegEntry *
			       pxDialCallRegEtr, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_DialCallRegEntry function.");
	
	char sObjname[MAX_LEN_OBJNAME];
	char tempstr[10];
	int32_t nSize = 0;
	char sName[MAX_LEN_OBJNAME] = { 0 };

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	x_IFX_VMAPI_DialCallRegister xOldCallReg;		
	int nInstanceNo = 0;
	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	CHECK_FOR_NULL(pxDialCallRegEtr,
		       "Error : Input name value object is NULL");
	memset(sObjname,0, MAX_LEN_OBJNAME);
	/*fill the instance number and create the object name */
	if (pxDialCallRegEtr->ucLineId == PSTN_LINE) {
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,DIAL_CALLREG_ENTRY);

	} else {
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxDialCallRegEtr->ucLineId,DIAL_CALLREG_ENTRY);

	}

	memset(&xObjHdr, 0, sizeof(MsgHeader));

	if (uiOperation == IFX_OP_DEL) {
        memset(tempstr,0,TEMP_LEN);
        snprintf(tempstr,TEMP_LEN,"%d",pxDialCallRegEtr->uiEntryId);
        strncat(sObjname,tempstr,sizeof(tempstr));


		HELP_CREATE_MSG(&xObjHdr, MOPT_SET, SOPT_OBJVALUE, OWN_SERVD,
				1);
		HELP_OBJECT_SET(xObjHdr.pObjType, sObjname, 100, OBJOPT_DEL,
				xObjHdr.unSubOper);
		nRetVal = cal_setValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Deletion of dialed call register failed");
		goto END;

	} else if (uiOperation == IFX_OP_ADD) {

		/*if the call register entry is greater than 5,delete the first entry
			then add the new entry*/
		memset(&xOldCallReg,0,sizeof(xOldCallReg));
		xOldCallReg.ucLineId = pxDialCallRegEtr->ucLineId;
		ifx_get_DialCallReg(&xOldCallReg, 0);
        if(xOldCallReg.ucNoOfEntries >= IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE){
            if(xOldCallReg.pxCallRegEntries != NULL)
                nInstanceNo = xOldCallReg.pxCallRegEntries->uiEntryId;
            nRetVal = ifx_del_FirstEntry(nInstanceNo,sObjname);
            ifx_vmapi_freeObjectList(&xOldCallReg,
									IFX_VMAPI_VS_DIALCALL_REGISTER);
            CHECK_FOR_ERROR("Deletion fo First Entry Failed");
        }
		
		HELP_CREATE_MSG(&xObjHdr, MOPT_GET,
				SOPT_OBJVALUE | SOPT_DEFVAL, OWN_SERVD, 1);
		if (pxDialCallRegEtr->ucLineId == PSTN_LINE) {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_PSTNDIALCALLREGENTRY_PATH,
					xObjHdr.unSubOper);
		} else {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_DIALCALLREGENTRY_PATH,
					xObjHdr.unSubOper);
		}

		/*Get the Object from DB */
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR
		    ("Get Value for Dialcall Register default failed");
		CHECK_FOR_NULL(xObjHdr.pObjType, "output object null");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Get Value for Dialcall Register default success !!!");
		/*update the modified value in Objectlist */
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {

			if ((strcmp
			     (pxTmpObj->sObjName,
			      DEF_DIALCALLREGENTRY_PATH) == 0)
			    ||
			    (strcmp
			     (pxTmpObj->sObjName,
			      DEF_PSTNDIALCALLREGENTRY_PATH) == 0)) {
				strncpy(pxTmpObj->sObjName, sObjname,
					sizeof(sObjname));
				pxTmpObj->unObjOper = OBJOPT_ADD;
			}
			nSize =
			    sizeof(x_IFX_VMAPI_CallRegEntry_param) /
			    sizeof(x_IFX_Param);


                /*Getting the max instance number existing in DB
                to set new index*/
                snprintf(sName,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxDialCallRegEtr->ucLineId,DIAL_CALLREG);
                int32 nIndex = get_MaxContactListEntryIndex(sName,2);
				pxDialCallRegEtr->uiEntryId = nIndex + 1;
                pxDialCallRegEtr->ucIndex = nIndex + 1;

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxDialCallRegEtr,
						 x_IFX_VMAPI_CallRegEntry_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the DialCall Register param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for DialCall Register in object list Success");
			pxTmpObj->unObjOper = OBJOPT_ADD;
		}

		/*wrintg to DB */
		xObjHdr.unSubOper = SOPT_OBJVALUE;
		// pxTmpObj->unObjOper = OBJOPT_ADD;
		xObjHdr.unOwner = OWN_SERVD;

		nRetVal = cal_setValueWrapper(&xObjHdr);

		CHECK_FOR_ERROR
		    ("Wrting DialCall Register entry Object to DB Failed");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Wrting DialCall Register Object to DB Success !!!!.");
	}
	//Notification not required as this object is not registered
#if 0
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {

		/*sending teh notification */
		nRetVal =
		    IFX_VMAPI_SendNotifyForRegObject
		    (IFX_VMAPI_VS_DIALCALL_REGISTER_ENTRY, NULL,
		     (void *)pxDialCallRegEtr);
		CHECK_FOR_ERROR
		    ("Sending Notification for  DialCall Register object change failes");
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Notifiaction sent for  DialCall Register  object change Success!!!! \n");

	}
#endif
      END:

	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_DialCallRegEntry function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_RecvCallRegEntry
*  Description    : Set api to get RecvCallRegEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxRecvCallRegEtr - Pointer to the object to be set
*  Output Values  : pxRecvCallRegEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_RecvCallRegEntry(IN uint32 uiOperation,
			       IN x_IFX_VMAPI_RecvCallRegEntry *
			       pxRecvCallRegEtr, IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_RecvCallRegEntry function.");
	char sObjname[MAX_LEN_OBJNAME] = { 0 };
	char tempstr[TEMP_LEN];
	int32_t nSize = 0;
	char sName[MAX_LEN_OBJNAME] = { 0 };

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	x_IFX_VMAPI_RecvCallRegister xOldCallReg;	
	int nInstanceNo = 0;
	ParamList *pxParam = NULL;

	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	CHECK_FOR_NULL(pxRecvCallRegEtr,
		       "Error : Input name value object is NULL");
	memset(sObjname,0, MAX_LEN_OBJNAME);
	/*fill the instance number and create the object name */
	if (pxRecvCallRegEtr->ucLineId == PSTN_LINE) {
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,RCV_CALLREG_ENTRY);

	} else {
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxRecvCallRegEtr->ucLineId,RCV_CALLREG_ENTRY);

	}

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	/*Performing delete operation */
	if (uiOperation == IFX_OP_DEL) {
        memset(tempstr,0,TEMP_LEN);
        snprintf(tempstr,TEMP_LEN,"%d",pxRecvCallRegEtr->uiEntryId);
        strncat(sObjname,tempstr,sizeof(tempstr));
		HELP_CREATE_MSG(&xObjHdr, MOPT_SET, SOPT_OBJVALUE, OWN_SERVD,
				1);
		HELP_OBJECT_SET(xObjHdr.pObjType, sObjname, 100, OBJOPT_DEL,
				xObjHdr.unSubOper);
		nRetVal = cal_setValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Deletion of  Recv call register failed");
		goto END;

	}
	/*Performing ADD operation */
	else if (uiOperation == IFX_OP_ADD) {

		/*if the call register entry is greater than 5,delete the first entry
			then add the new entry*/
        memset(&xOldCallReg,0,sizeof(xOldCallReg));
		xOldCallReg.ucLineId = pxRecvCallRegEtr->ucLineId; 
        ifx_get_RecvCallReg(&xOldCallReg, 0);
        if(xOldCallReg.ucNoOfEntries >= IFX_VMAPI_MAX_CALL_REG_ENTRIES_PER_LINE){
            if(xOldCallReg.pxCallRegEntries != NULL)
                nInstanceNo = xOldCallReg.pxCallRegEntries->uiEntryId;
            nRetVal = ifx_del_FirstEntry(nInstanceNo,sObjname);
            ifx_vmapi_freeObjectList(&xOldCallReg,
                                    IFX_VMAPI_VS_RECVCALL_REGISTER);
            CHECK_FOR_ERROR("Deletion fo First Entry Failed");
        }

		HELP_CREATE_MSG(&xObjHdr, MOPT_GET,
				SOPT_OBJVALUE | SOPT_DEFVAL, OWN_SERVD, 1);
		if (pxRecvCallRegEtr->ucLineId == PSTN_LINE) {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_PSTNRCVCALLREGENTRY_PATH,
					xObjHdr.unSubOper);
		} else {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_RCVCALLREGENTRY_PATH,
					xObjHdr.unSubOper);
		}

		/*Get the Object from DB */
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR
		    ("Get Value for Rcvcall Register default failed");
		CHECK_FOR_NULL(xObjHdr.pObjType, "output object null");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Get Value for Rcvcall Register default success !!!!");
		/*update the modified value in Objectlist */
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {

			if ((strcmp
			     (pxTmpObj->sObjName,
			      DEF_RCVCALLREGENTRY_PATH) == 0)
			    ||
			    (strcmp
			     (pxTmpObj->sObjName,
			      DEF_PSTNRCVCALLREGENTRY_PATH) == 0)) {
				strncpy(pxTmpObj->sObjName, sObjname,
					sizeof(sObjname));
				pxTmpObj->unObjOper = OBJOPT_ADD;
			}
			nSize =
			    sizeof(x_IFX_VMAPI_CallRegEntry_param) /
			    sizeof(x_IFX_Param);

                /*Getting the max instance number existing in DB
                to set new index*/
                snprintf(sName,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxRecvCallRegEtr->ucLineId,RCV_CALLREG);
                int32 nIndex = get_MaxContactListEntryIndex(sName,2);
				pxRecvCallRegEtr->uiEntryId = nIndex + 1;
                pxRecvCallRegEtr->ucIndex = nIndex + 1;

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxRecvCallRegEtr,
						 x_IFX_VMAPI_CallRegEntry_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the RcvCall Register param value in Object list failed");

            /*Fix for issue recvcall is not getting registered from soft phone
            as display name is containing quotes which json format error while display
            so removing the "" from display name.*/
		    FOR_EACH_PARAM(pxTmpObj, pxParam) {
					if(strncmp(GET_PARAM_NAME(pxParam),"X_VENDOR_COM_DisplayName",MAX_LEN_PARAM_NAME) == 0){
						char *sTempVal;
						sTempVal = GET_PARAM_VALUE(pxParam);
						if(sTempVal[0] == '\"'){
							(sTempVal)++;
						}	
						if(sTempVal[strlen(sTempVal)-1] == '\"'){
							sTempVal[strlen(sTempVal)-1] = '\0';
						}
						strncpy(pxParam->sParamValue,sTempVal,MAX_LEN_PARAM_VALUE);
					}
			}	
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for RcvCall Register in object list Success.");
		}

		//HELP_PRINT_MSG(&xObjHdr);

		/*wrintg to DB */
		xObjHdr.unSubOper = SOPT_OBJVALUE;
		xObjHdr.unOwner = OWN_SERVD;

		nRetVal = cal_setValueWrapper(&xObjHdr);

		CHECK_FOR_ERROR("Wrting RcvCall Object to DB Failed");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Wrting RcvCall Register Object to DB Success !!!!");
	}
	END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_RecvCallRegEntry function.");

	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_set_Addrentry
*  Description    : Set api to get Addrentry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxAddrEntry - Pointer to the object to be set
*  Output Values  : pxAddrEntry - pointer to Addrentry object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_AddrEntry(IN uint32 uiOperation,
			IN x_IFX_VMAPI_AddressBookEntry * pxAddrEntry,
			IN uint32 uiInFlag)
{
	printf("\n***ifx_set_AddrEntry is NOt Used**\n");
	return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_set_PhyInterfaceTest
*  Description    : Set api to set GR909 Test config parameters.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxPhyIntTest - Pointer to the Physical Interface Test
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_PhyInterfaceTest(IN uint32 uiOperation,
			       IN x_IFX_VMAPI_VoiceServPhyIfTest *
			       pxPhyIntTest, IN uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_PhyInterfaceTest function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxPhyIntTest,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, PHY_IF_TEST);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for PhyIfTest  failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for PhyIfTest  success !!!! \n");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_VOICESERVPHYIFTEST) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_VoiceServPhyIfTest_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxPhyIntTest,
						 x_IFX_VMAPI_VoiceServPhyIfTest_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the PhyIfTest values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for PhyIfTest in object list Success");

			/*Getting the old object */
			x_IFX_VMAPI_VoiceServPhyIfTest xOldPhyIfTest;
			memset(&xOldPhyIfTest, 0,
			       sizeof(x_IFX_VMAPI_VoiceServPhyIfTest));
			nRetVal = ifx_get_PhyInterfaceTest(&xOldPhyIfTest, 0);
			CHECK_FOR_ERROR
			    ("Getting Existing phyIfTest Object failed");

			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing PhyIfTest Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing PhyIfTest Object to DB Success !!!!");
			//Notification
			if (!
			    (uiInFlag &
			     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
				nRetVal =
				    IFX_VMAPI_SendNotifyForRegObject
				    (IFX_VMAPI_PHY_INT_TEST,
				     (void *)&xOldPhyIfTest,
				     (void *)pxPhyIntTest);
				CHECK_FOR_ERROR
				    ("Sending Notification for PhyIfTest change failes");
				IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
					 IFX_DBG_STR,
					 "Notifiaction sent for PhyIfTest Success");

			}
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_PhyInterfaceTest function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_FxsPhyInterface
*  Description    : Set api to get FxsPhyInterface object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxFxsPhyIf - Pointer to the object to be set
*  Output Values  : pxFxsPhyIf - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_FxsPhyInterface(IN uint32 uiOperation,
			      IN x_IFX_VMAPI_FxsPhyIf * pxFxsPhyIf,
			      IN uint32 uiInFlag)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_FxsPhyInterface function.");
	char sObjname[MAX_LEN_OBJNAME];
	char8 acAssInte[2*IFX_VMAPI_MAX_VOICE_PROFILES * IFX_VMAPI_MAX_VOICE_LINES+1] = { '\0' };
	int32_t nSize = 0, nIndex = 0, nTempIndex = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	x_IFX_VMAPI_FxsPhyIf xOldFxs;
	memset(&xOldFxs, 0, sizeof(x_IFX_VMAPI_FxsPhyIf));

	CHECK_FOR_NULL(pxFxsPhyIf,
		       "Error : Input name value object is NULL.");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	strcpy(sObjname, VOICESERVICE_FXS);

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for Fxs  failed");
	//      HELP_PRINT_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for Fxs  success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if ((GET_OBJ_OID(pxTmpObj) ==
		     DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXSPHYIF)
		    || (GET_OBJ_OID(pxTmpObj) ==
			DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXSPHYIF_X_VENDOR_COM_VOICESERVPHYIF))
		{
			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_VMAPI_FxsPhyIf_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxFxsPhyIf,
						 x_IFX_VMAPI_FxsPhyIf_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Fxs values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Fxs in object list Success");

		}
		/*Creating Comma separated List */
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_FXSPHYIF) {
			while (pxFxsPhyIf->ucVoiceLineIdList[nIndex] != 0) {

				snprintf(&acAssInte[nTempIndex],sizeof(acAssInte), "%d%s",
					pxFxsPhyIf->ucVoiceLineIdList[nIndex],",");
				nTempIndex = strlen(acAssInte);
				nIndex++;
			}
			ParamList *pxParam = NULL;
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if ((strcmp
				     (pxParam->sParamName,
				      "X_VENDOR_COM_VoiceLineIdList") == 0)) {
					strncpy(pxParam->sParamValue,
						acAssInte,
						sizeof(pxFxsPhyIf->
						       ucVoiceLineIdList));
					break;

				}
			}

		}
	}

	/*Get Existing Object */
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
		/*Getting the old object */
		nRetVal = ifx_get_FxsPhyInterface(&xOldFxs, 0);
		CHECK_FOR_ERROR("Getting Existing Fxs Object failed");
	}

	/*wrintg to DB */
	xObjHdr.unMainOper = MOPT_SET;
	xObjHdr.unSubOper = SOPT_OBJVALUE;
	xObjHdr.unOwner = OWN_SERVD;

	cal_setValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Writing Fxs Object to DB Failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Writing Fxs Object to DB Success !!!!");
	//Notification
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {

		/*sending teh notification */
		nRetVal =
		    IFX_VMAPI_SendNotifyForRegObject(IFX_VMAPI_PHY_IFACE_FXS,
						     (void *)&xOldFxs,
						     (void *)pxFxsPhyIf);
		CHECK_FOR_ERROR("Sending Notification for Fxs change failes");
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Notifiaction sent for Fxs Success");

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_FxsPhyInterface function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : ifx_set_CommonContactListEntry
*  Description    : Set api to get ContactListEntry object.
*  Input Values   : uiOperation - Gives Operation to be performed
*                    uiInFlag - Input flags
*                    pxContactListEtr - Pointer to the object to be set
*  Output Values  : pxContactListEtr - pointer to NumPlan object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 ifx_set_CommonContactListEntry(IN uint32 uiOperation,
				     IN x_IFX_VMAPI_ContactListEntry *
				     pxContactListEtr, IN uint32 uiInFlag)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_ContactListEntry function.");
	char sObjname[MAX_LEN_OBJNAME];
	char tempstr[10];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	x_IFX_VMAPI_ContactList xOldContactList;
	x_IFX_VMAPI_ContactList xNewContactList;
	x_IFX_VMAPI_ContactListEntry xOldContactListEntry;

	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	CHECK_FOR_NULL(pxContactListEtr,
		       "Error : Input name value object is NULL");
	memset(sObjname,0, MAX_LEN_OBJNAME);
	/*fill the instance number and create the object name */
	if (pxContactListEtr->ucLineId == PSTN_LINE) {
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%s",PSTNLINE,COMMON_CONTACT_LIST_ENTRY);

	} else {
        snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d%s",VOICE_LINE,pxContactListEtr->ucLineId,COMMON_CONTACT_LIST_ENTRY);

	}
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	memset(&xOldContactList, 0, sizeof(x_IFX_VMAPI_ContactList));
	memset(&xOldContactListEntry, 0,
	       sizeof(x_IFX_VMAPI_ContactListEntry));

	/*Getting the old call register for Notification */
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {

		memset(&xOldContactList, 0, sizeof(x_IFX_VMAPI_ContactList));

		xOldContactList.ucLineId = pxContactListEtr->ucLineId;
		nRetVal = ifx_get_CommonContactList(&xOldContactList, 0);

	}

	switch (uiOperation) {
	case IFX_OP_DEL:
        memset(tempstr,0,TEMP_LEN);
        snprintf(tempstr,TEMP_LEN,"%d",pxContactListEtr->ucIndex);
        strncat(sObjname,tempstr,sizeof(tempstr));

		HELP_CREATE_MSG(&xObjHdr, MOPT_SET, SOPT_OBJVALUE, OWN_SERVD,
				1);
		HELP_OBJECT_SET(xObjHdr.pObjType, sObjname, 100, OBJOPT_DEL,
				xObjHdr.unSubOper);
		nRetVal = cal_setValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Deletion of ContactList entry failed");
		break;

	case IFX_OP_MOD:
        memset(tempstr,0,TEMP_LEN);
        snprintf(tempstr,TEMP_LEN,"%d",pxContactListEtr->ucIndex);
        strncat(sObjname,tempstr,sizeof(tempstr));


		HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD,
				1);
		HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
				xObjHdr.unSubOper);
		/*Get the Object from DB */
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Contact List Entry failed");
		CHECK_FOR_NULL(xObjHdr.pObjType, "output object null");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Get Value for Contact List Entry success !!!!");
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {

			nSize =
			    sizeof(x_IFX_VMAPI_ContactListEntry_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxContactListEtr,
						 x_IFX_VMAPI_ContactListEntry_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Contact List Entry param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Contact List Entry in object list Success");
		}
		xObjHdr.unMainOper = MOPT_SET;
		xObjHdr.unSubOper = SOPT_OBJVALUE;
		xObjHdr.unOwner = OWN_SERVD;

		nRetVal = cal_setValueWrapper(&xObjHdr);

		CHECK_FOR_ERROR
		    ("Writing Contact List entry Object to DB Failed");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Writing Contact List Object to DB Success !!!!");
		break;
	case IFX_OP_ADD:
		HELP_CREATE_MSG(&xObjHdr, MOPT_GET,
				SOPT_OBJVALUE | SOPT_DEFVAL, OWN_SERVD, 1);
		if (pxContactListEtr->ucLineId == PSTN_LINE) {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_PSTNCOMMON_CONTACTLISTENTRY_PATH,
					xObjHdr.unSubOper);
		} else {
			HELP_OBJECT_GET(xObjHdr.pObjType,
					DEF_COMMON_CONTACTLISTENTRY_PATH,
					xObjHdr.unSubOper);
		}
		/*Get the Object from DB */
		nRetVal = cal_getValueWrapper(&xObjHdr);
		CHECK_FOR_ERROR("Get Value for Contact List Entry failed");
		CHECK_FOR_NULL(xObjHdr.pObjType, "output object null");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Get Value for Contact List Entry success !!!!");
		FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {

			/*Update the object name in case of ADD operation */
			if ((strcmp
			     (pxTmpObj->sObjName,
			      DEF_COMMON_CONTACTLISTENTRY_PATH) == 0)
			    ||
			    (strcmp
			     (pxTmpObj->sObjName,
			      DEF_PSTNCOMMON_CONTACTLISTENTRY_PATH) == 0)) {
				strncpy(pxTmpObj->sObjName, sObjname,
					sizeof(sObjname));
			}
/*
                    	else
                    	{
                        	strncpy(pxTmpObj->sObjName,sTempObjname,sizeof(sTempObjname));
			}
*/
			nSize =
			    sizeof(x_IFX_VMAPI_ContactListEntry_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxContactListEtr,
						 x_IFX_VMAPI_ContactListEntry_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the Contact List Entry param value in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for Contact List Entry in object list Success.");
			pxTmpObj->unObjOper = OBJOPT_ADD;
		}
		/*wrintg to DB */
		xObjHdr.unSubOper = SOPT_OBJVALUE;
		pxTmpObj->unObjOper = OBJOPT_ADD;
		xObjHdr.unOwner = OWN_SERVD;

		nRetVal = cal_setValueWrapper(&xObjHdr);

		CHECK_FOR_ERROR
		    ("Writing Contact List entry Object to DB Failed");

		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Writing Contact List Object to DB Success !!!!");

		break;
	}

	/*Notification */
	if (!(uiInFlag & IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)) {
		/*Getting the old call register for Notification */
		memset(&xNewContactList, 0, sizeof(x_IFX_VMAPI_ContactList));
		xNewContactList.ucLineId = pxContactListEtr->ucLineId;
		nRetVal = ifx_get_CommonContactList(&xNewContactList, 0);
		CHECK_FOR_ERROR("Getting New MissCall register failed");

		/*sending teh notification */
		nRetVal =
		    IFX_VMAPI_SendNotifyForRegObject
		    (IFX_VMAPI_VS_COMMON_CONTACT_LIST,
		     (void *)&xOldContactList, (void *)&xNewContactList);
		CHECK_FOR_ERROR
		    ("Sending Notification for  MissCall Register object change failes");
		IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			 "Notifiaction sent for  MissCall Register  object change Success.");

	}

      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_CommonContactListEntry function.");

	return nRetVal;

}

/******************************************************************************
*  Function Name  : IFX_VMAPI_Init
*  Description    : Initialize VMAPI.
*  Input Values   :
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32 IFX_VMAPI_Init()
{
	char8 cErr;
	x_IFX_VMAPI_SystemDebugSettings xDbgSet;
	if (ifx_get_DbgSettings(&xDbgSet, 0) != IFX_VMAPI_SUCCESS) {
		return IFX_VMAPI_FAIL;
	} else {
		IFX_VMAPI_DbgInit(xDbgSet.xVmapiDbg.ucDbgType,
						xDbgSet.xVmapiDbg.ucDbgLvl,&cErr);
	}

	return IFX_VMAPI_SUCCESS;
}

/******************************************************************************
*  Function Name  : ifx_delete_All_ListEntries
*  Description    : To Delte All Entries in a List
*  Input Values   :  uiObjectId - Object ID
*                     pucLineId- LineId
*                     pcDelParent-Parent Delete flag
*  Output Values  :
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/

int32 ifx_delete_All_ListEntries(IN uint32 puiObjectId, IN uchar8 pucLine)
{

	int32 iCount = 0;
	switch (puiObjectId) {
	case IFX_VMAPI_VS_MISSCALL_REGISTER:
		{
			x_IFX_VMAPI_MissCallRegister xMissCallReg;
			x_IFX_VMAPI_MissCallRegEntry *xMissCallEntry;
			//delete the entry's if they any.....
			memset(&xMissCallReg, 0, sizeof(xMissCallReg));
			xMissCallReg.iid.config_owner = IFX_VOIP;
			xMissCallReg.ucLineId = pucLine;
			if (ifx_get_MissCallReg(&xMissCallReg, 0) !=
			    IFX_VMAPI_SUCCESS)
				return IFX_VMAPI_FAIL;
			if (xMissCallReg.ucNoOfEntries > 0) {
				xMissCallEntry =
				    xMissCallReg.pxCallRegEntries;
				while (xMissCallEntry != NULL
				       && iCount <
				       xMissCallReg.ucNoOfEntries) {
				//	xMissCallEntry->ucIndex = 1;
					xMissCallEntry->iid.config_owner =
					    IFX_WEB;
					if (ifx_set_MissCallRegEntry
					    (IFX_OP_DEL, xMissCallEntry,
					     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)
					    != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xMissCallReg,
						     IFX_VMAPI_VS_MISSCALL_REGISTER);
						return IFX_VMAPI_FAIL;
					}
					iCount++;
					__ifx_list_GetNext((void *)
							   &xMissCallEntry);
				}
				if (xMissCallEntry != NULL) {
					xMissCallEntry->ucIndex = 1;
					xMissCallEntry->iid.config_owner =
					    IFX_WEB;
					if (ifx_set_MissCallRegEntry
					    (IFX_OP_DEL, xMissCallEntry,
					     0) != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xMissCallReg,
						     IFX_VMAPI_VS_MISSCALL_REGISTER);
						return IFX_VMAPI_FAIL;
					}
				}
				ifx_vmapi_freeObjectList(&xMissCallReg,
							 IFX_VMAPI_VS_MISSCALL_REGISTER);
			}
		}
		break;
	case IFX_VMAPI_VS_DIALCALL_REGISTER:
		{
			x_IFX_VMAPI_DialCallRegister xDialCallReg;
			x_IFX_VMAPI_DialCallRegEntry *xDialCallEntry;
			//delete the entry's if they any.....
			memset(&xDialCallReg, 0, sizeof(xDialCallReg));
			xDialCallReg.iid.config_owner = IFX_VOIP;
			xDialCallReg.ucLineId = pucLine;
			if (ifx_get_DialCallReg(&xDialCallReg, 0) !=
			    IFX_VMAPI_SUCCESS)
				return IFX_VMAPI_FAIL;
			if (xDialCallReg.ucNoOfEntries > 0) {
				xDialCallEntry =
				    xDialCallReg.pxCallRegEntries;
				while (xDialCallEntry != NULL
				       && iCount <
				       xDialCallReg.ucNoOfEntries) {
					//xDialCallEntry->ucIndex = 1;
					xDialCallEntry->iid.config_owner =
					    IFX_VOIP;
					if (ifx_set_DialCallRegEntry
					    (IFX_OP_DEL, xDialCallEntry,
					     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)
					    != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xDialCallReg,
						     IFX_VMAPI_VS_DIALCALL_REGISTER);
						return IFX_VMAPI_FAIL;
					}
					iCount++;
					__ifx_list_GetNext((void *)
							   &xDialCallEntry);
				}
				if (xDialCallEntry != NULL) {
					xDialCallEntry->ucIndex = 1;
					xDialCallEntry->iid.config_owner =
					    IFX_VOIP;
					if (ifx_set_DialCallRegEntry
					    (IFX_OP_DEL, xDialCallEntry,
					     0) != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xDialCallReg,
						     IFX_VMAPI_VS_DIALCALL_REGISTER);
						return IFX_VMAPI_FAIL;
					}
				}
				ifx_vmapi_freeObjectList(&xDialCallReg,
							 IFX_VMAPI_VS_DIALCALL_REGISTER);
			}

		}
		break;
	case IFX_VMAPI_VS_RECVCALL_REGISTER:
		{
			x_IFX_VMAPI_RecvCallRegister xRecvCallReg;
			x_IFX_VMAPI_RecvCallRegEntry *xRecvCallEntry;
//delete the entry's if they any.....
			memset(&xRecvCallReg, 0, sizeof(xRecvCallReg));
			xRecvCallReg.iid.config_owner = IFX_VOIP;
			xRecvCallReg.ucLineId = pucLine;
			if (ifx_get_RecvCallReg(&xRecvCallReg, 0) !=
			    IFX_VMAPI_SUCCESS)
				return IFX_VMAPI_FAIL;
			if (xRecvCallReg.ucNoOfEntries > 0) {
				xRecvCallEntry =
				    xRecvCallReg.pxCallRegEntries;
				while (xRecvCallEntry != NULL
				       && iCount <
				       xRecvCallReg.ucNoOfEntries) {
					//xRecvCallEntry->ucIndex = 1;
					xRecvCallEntry->iid.config_owner =
					    IFX_VOIP;
					if (ifx_set_RecvCallRegEntry
					    (IFX_OP_DEL, xRecvCallEntry,
					     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)
					    != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xRecvCallReg,
						     IFX_VMAPI_VS_RECVCALL_REGISTER);
						return IFX_VMAPI_FAIL;
					}
					iCount++;
					__ifx_list_GetNext((void *)
							   &xRecvCallEntry);
				}
				if (xRecvCallEntry != NULL) {
					xRecvCallEntry->ucIndex = 1;
					xRecvCallEntry->iid.config_owner =
					    IFX_VOIP;
					if (ifx_set_RecvCallRegEntry
					    (IFX_OP_DEL, xRecvCallEntry,
					     0) != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xRecvCallReg,
						     IFX_VMAPI_VS_RECVCALL_REGISTER);
						return IFX_VMAPI_FAIL;
					}
				}
				ifx_vmapi_freeObjectList(&xRecvCallReg,
							 IFX_VMAPI_VS_RECVCALL_REGISTER);
			}

		}
		break;
	case IFX_VMAPI_VS_CONTACT_LIST:
		{
			x_IFX_VMAPI_ContactList xContactList;
			x_IFX_VMAPI_ContactListEntry *xContactListEntry;
//delete the entry's if they any.....
			memset(&xContactList, 0, sizeof(xContactList));
			xContactList.iid.config_owner = IFX_VOIP;
			xContactList.ucLineId = pucLine;
			if (ifx_get_ContactList(&xContactList, 0) !=
			    IFX_VMAPI_SUCCESS)
				return IFX_VMAPI_FAIL;
			if (xContactList.ucNoOfEntries > 0) {
				xContactListEntry =
				    xContactList.pxContactEntries;
				while (xContactListEntry != NULL
				       && iCount <
				       xContactList.ucNoOfEntries) {
					xContactListEntry->iid.config_owner =
					    IFX_VOIP;
				//	xContactListEntry->ucIndex = 1;
					if (ifx_set_ContactListEntry
					    (IFX_OP_DEL, xContactListEntry,
					     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)
					    != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xContactList,
						     IFX_VMAPI_VS_CONTACT_LIST);
						return IFX_VMAPI_FAIL;
					}
					__ifx_list_GetNext((void *)
							   &xContactListEntry);
					iCount++;
				}
				if (xContactListEntry != NULL) {
					xContactListEntry->iid.config_owner =
					    IFX_VOIP;
					xContactListEntry->ucIndex = 1;
					if (ifx_set_ContactListEntry
					    (IFX_OP_DEL, xContactListEntry,
					     0) != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xContactList,
						     IFX_VMAPI_VS_CONTACT_LIST);
						return IFX_VMAPI_FAIL;
					}
				}
				ifx_vmapi_freeObjectList(&xContactList,
							 IFX_VMAPI_VS_CONTACT_LIST);
			}
		}
		break;

	case IFX_VMAPI_VS_COMMON_CONTACT_LIST:
		{
			x_IFX_VMAPI_ContactList xContactList;
			x_IFX_VMAPI_ContactListEntry *xContactListEntry;
//delete the entry's if they any.....
			memset(&xContactList, 0, sizeof(xContactList));
			xContactList.iid.config_owner = IFX_VOIP;
			xContactList.ucLineId = pucLine;
			if (ifx_get_CommonContactList(&xContactList, 0) !=
			    IFX_VMAPI_SUCCESS)
				return IFX_VMAPI_FAIL;
			if (xContactList.ucNoOfEntries > 0) {
				xContactListEntry =
				    xContactList.pxContactEntries;
				while (xContactListEntry != NULL
				       && iCount <
				       xContactList.ucNoOfEntries - 1) {
					xContactListEntry->iid.config_owner =
					    IFX_VOIP;
					xContactListEntry->ucIndex = 1;
					if (ifx_set_CommonContactListEntry
					    (IFX_OP_DEL, xContactListEntry,
					     IFX_VMAPI_DONT_SEND_NOTIFY_TO_THIS_OBJ)
					    != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xContactList,
						     IFX_VMAPI_VS_CONTACT_LIST);
						return IFX_VMAPI_FAIL;
					}
					__ifx_list_GetNext((void *)
							   &xContactListEntry);
					iCount++;
				}
				if (xContactListEntry != NULL) {
					xContactListEntry->iid.config_owner =
					    IFX_VOIP;
					xContactListEntry->ucIndex = 1;
					if (ifx_set_CommonContactListEntry
					    (IFX_OP_DEL, xContactListEntry,
					     0) != IFX_VMAPI_SUCCESS) {
						ifx_vmapi_freeObjectList
						    (&xContactList,
						     IFX_VMAPI_VS_CONTACT_LIST);
						return IFX_VMAPI_FAIL;
					}
				}

				ifx_vmapi_freeObjectList(&xContactList,
							 IFX_VMAPI_VS_CONTACT_LIST);
			}
		}
		break;
	default:
		return IFX_VMAPI_FAIL;
	}

	return IFX_VMAPI_SUCCESS;
}

/******************************************************************
*  Function Name:  ifx_vmapi_freeObjectList
*  Description  :
*  Input Values :
*  Return Value :
*  Notes        :
*********************************************************************/
void ifx_vmapi_freeObjectList(void *pxVoid, IN uchar8 ucObjType)
{
	/* Check for valid object */
	if (ucObjType >= IFX_VMAPI_MAX_OBJ) {
		return;
	}
	switch (ucObjType) {

		/* Voice Codec Capabs */
	case IFX_VMAPI_CODEC_CAPABS:
		{
/*
                                x_IFX_VMAPI_VoiceCodecCapabilities *pxVoiceCodecCaps =
                       (x_IFX_VMAPI_VoiceCodecCapabilities*) pxVoid;

        while(pxVoiceCodecCaps->pxCodecList != NULL){
          __ifx_list_del((void**)&pxVoiceCodecCaps->pxCodecList,
                    (void *)pxVoiceCodecCaps->pxCodecList);
        }
*/
		}
		break;

		/* Voice System Address Book */
	case IFX_VMAPI_VS_ADDRESS_BOOK:
		{
			x_IFX_VMAPI_AddressBook *pxAddrBook =
			    (x_IFX_VMAPI_AddressBook *) pxVoid;

			while (pxAddrBook->pxAddressBook != NULL) {
				__ifx_list_del((void **)&pxAddrBook->
					       pxAddressBook,
					       (void *)pxAddrBook->
					       pxAddressBook);
			}
		}
		break;
		/* Call Block Entry */
	case IFX_VMAPI_VS_CALL_BLOCK:
		{
			x_IFX_VMAPI_CallBlock *pxCallBlock =
			    (x_IFX_VMAPI_CallBlock *) pxVoid;

			while (pxCallBlock->pxCallBlockList != NULL) {
				__ifx_list_del((void **)&pxCallBlock->
					       pxCallBlockList,
					       (void *)pxCallBlock->
					       pxCallBlockList);
			}
		}
		break;
		/* Numbering Plan */
	case IFX_VMAPI_VS_NUM_PLAN:
		{
			x_IFX_VMAPI_NumPlan *pxNumPlan =
			    (x_IFX_VMAPI_NumPlan *) pxVoid;

			while (pxNumPlan->pxNumPlanRules != NULL) {
				__ifx_list_del((void **)&pxNumPlan->
					       pxNumPlanRules,
					       (void *)pxNumPlan->
					       pxNumPlanRules);
			}
		}
		break;
	case IFX_VMAPI_VS_DIALCALL_REGISTER:
	case IFX_VMAPI_VS_MISSCALL_REGISTER:
	case IFX_VMAPI_VS_RECVCALL_REGISTER:
	case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
	case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
	case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
		{
			x_IFX_VMAPI_DialCallRegister *pxDialCall =
			    (x_IFX_VMAPI_DialCallRegister *) pxVoid;
			while (pxDialCall->pxCallRegEntries != NULL) {
				__ifx_list_del((void **)&pxDialCall->
					       pxCallRegEntries,
					       (void *)pxDialCall->
					       pxCallRegEntries);
			}
		}
		break;
		/* Voice Profile related */
	case IFX_VMAPI_VP_EVENT_SUBSCR:
		{
			printf
			    ("Trying to free the IFX_VMAPI_VP_EVENT_SUBSCR....\n");
			x_IFX_VMAPI_ProfileEventSubsTable *pxEveSubsTbl =
			    (x_IFX_VMAPI_ProfileEventSubsTable *) pxVoid;

			while (pxEveSubsTbl->pxEventSubscribe != NULL) {
				__ifx_list_del((void **)&pxEveSubsTbl->
					       pxEventSubscribe,
					       (void *)pxEveSubsTbl->
					       pxEventSubscribe);
			}
		}
		break;
		/* Voice Line related */
	case IFX_VMAPI_VL_SIGNALING:
		{
			x_IFX_VMAPI_LineSignaling *pxLineSig =
			    (x_IFX_VMAPI_LineSignaling *) pxVoid;

			while (pxLineSig->pxAuthCfg != NULL) {
				__ifx_list_del((void **)&pxLineSig->pxAuthCfg,
					       (void *)pxLineSig->pxAuthCfg);

			}
		}
		break;

	case IFX_VMAPI_VL_EVENT_SUBSCR:
		{
			x_IFX_VMAPI_LineSubscription *pxLineSubs =
			    (x_IFX_VMAPI_LineSubscription *) pxVoid;

			while (pxLineSubs->pxLineEvents != NULL) {
				__ifx_list_del((void **)&pxLineSubs->
					       pxLineEvents,
					       (void *)pxLineSubs->
					       pxLineEvents);
			}
		}
		break;
	case IFX_VMAPI_VL_CODECLIST:
		{
			x_IFX_VMAPI_LineCodecList *pxLineCodec =
			    (x_IFX_VMAPI_LineCodecList *) pxVoid;

			while (pxLineCodec->pxCodecList != NULL) {
				__ifx_list_del((void **)&pxLineCodec->
					       pxCodecList,
					       (void *)pxLineCodec->
					       pxCodecList);
			}
		}
		break;
		/* Physical Interface related */
//#ifdef DECT_SUPPORT
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
	case IFX_VMAPI_DECT_SYSTEM:
		{
			x_IFX_VMAPI_DectSystem *pxDect =
			    (x_IFX_VMAPI_DectSystem *) pxVoid;

			while (pxDect->pxHandsetTbl != NULL) {
				__ifx_list_del((void **)&pxDect->pxHandsetTbl,
					       (void *)pxDect->pxHandsetTbl);
			}
			while (pxDect->pxCodecList != NULL) {
				__ifx_list_del((void **)&pxDect->pxCodecList,
					       (void *)pxDect->pxCodecList);
			}
		}
#ifdef DECT_REPEATER
    case IFX_VMAPI_DECT_REPEATER:
        {
            x_IFX_VMAPI_DectRepeater *pxDectRepeater =
                (x_IFX_VMAPI_DectRepeater *) pxVoid;

            while (pxDectRepeater->pxSubsInfo != NULL) {
                __ifx_list_del((void **)&pxDectRepeater->pxSubsInfo,
                           (void *)pxDectRepeater->pxSubsInfo);
            }
        }
#endif
#endif				//DECT_SUPPORT
#ifdef MESSAGE_SUPPORT
		/* Message Inbox */
	case IFX_VMAPI_MSG_INBOX:
		{
			x_IFX_VMAPI_IN_Message *pxMsgIn =
			    (x_IFX_VMAPI_IN_Message *) pxVoid;

			while (pxMsgIn->pxMsgEntries != NULL) {
				__ifx_list_del((void **)&pxMsgIn->
					       pxMsgEntries,
					       (void *)pxMsgIn->pxMsgEntries);
			}
		}
		break;
		/* Message Outbox */
	case IFX_VMAPI_MSG_OUTBOX:
		{
			x_IFX_VMAPI_OUT_Message *pxMsgOut =
			    (x_IFX_VMAPI_OUT_Message *) pxVoid;

			while (pxMsgOut->pxMsgEntries != NULL) {
				__ifx_list_del((void **)&pxMsgOut->
					       pxMsgEntries,
					       (void *)pxMsgOut->
					       pxMsgEntries);
			}
		}
		break;
#endif				/* MESSAGE_SUPPORT */
	case IFX_VMAPI_VS_CONTACT_LIST:
	case IFX_VMAPI_VS_PSTN_CONTACT_LIST:
		{
			x_IFX_VMAPI_ContactList *pxContactList =
			    (x_IFX_VMAPI_ContactList *) pxVoid;

			while (pxContactList->pxContactEntries != NULL) {
				__ifx_list_del((void **)&pxContactList->
					       pxContactEntries,
					       (void *)pxContactList->
					       pxContactEntries);
			}
		}
		break;

		break;
	default:
		/* Not a valid object */
		return;
	}

}

/*!  \brief  This API is used to fill objectlist params value
	from data structure 
  \param[in] pxTmpObj Pointer to the object data sent
  \param[out] pLineCodec Pointer to the struct data to be filled
  \return
*/
int32_t UpdateParamValueInDB(ObjList * pxTmpObj, void *pVoipStruct,
			     x_IFX_Param acOffsetStruct[], int nSize)
{
	int32_t nFlag = 0;
	int32_t nIndex = 0, nRetVal = IFX_VMAPI_SUCCESS;
	ParamList *pxParam = NULL;

	CHECK_FOR_NULL(pxTmpObj, "Object list is null");
	CHECK_FOR_NULL(pVoipStruct, "Object list is null");

	/*traverse each param of the objlist and fill the corresponding param val */
	list_for_each_entry(pxParam, &(pxTmpObj->xParamList.xPlist), xPlist) {
		nFlag = 0;
		for (nIndex = 0; nIndex < nSize; nIndex++)	//scan the list to get the required param offset and type info
		{
			if (0 ==
			    strncmp(pxParam->sParamName,
				    acOffsetStruct[nIndex].acParamName,
				    sizeof(pxParam->sParamName))) {
				//if name matches get the type and offset to save the value
				switch (acOffsetStruct[nIndex].uiType) {
				case IFX_VMAPI_PARAM_TYPE_OBJ_LIST:
					nFlag = 1;
					break;

				case IFX_VMAPI_PARAM_TYPE_CHAR:
					snprintf(pxParam->sParamValue,sizeof(pxParam->sParamValue), "%d",
						*((char *)(pVoipStruct +
							   acOffsetStruct
							   [nIndex].
							   unOffset)));
					nFlag = 1;
					break;
                case IFX_VMAPI_PARAM_TYPE_UCHAR:
                    snprintf(pxParam->sParamValue,sizeof(pxParam->sParamValue), "%u",
                        *((unsigned char *)(pVoipStruct +
                               acOffsetStruct
                               [nIndex].
                               unOffset)));
                    nFlag = 1;
                    break;

				case IFX_VMAPI_PARAM_TYPE_SHORT_INT:
				case IFX_VMAPI_PARAM_TYPE_USHORT_INT:
					snprintf(pxParam->sParamValue,sizeof(pxParam->sParamValue), "%d",
						*((short *)(pVoipStruct +
							    acOffsetStruct
							    [nIndex].
							    unOffset)));
					nFlag = 1;
					break;

				case IFX_VMAPI_PARAM_TYPE_INT:
				case IFX_VMAPI_PARAM_TYPE_UINT:
					snprintf(pxParam->sParamValue,sizeof(pxParam->sParamValue), "%d",
						*((int *)(pVoipStruct +
							  acOffsetStruct
							  [nIndex].
							  unOffset)));
					nFlag = 1;
					break;

				case IFX_VMAPI_PARAM_TYPE_ULONG:
				case IFX_VMAPI_PARAM_TYPE_LONG:
					snprintf(pxParam->sParamValue,sizeof(pxParam->sParamValue), "%ld",
						*((long *)(pVoipStruct +
							   acOffsetStruct
							   [nIndex].
							   unOffset)));
					nFlag = 1;
					break;
				case IFX_VMAPI_PARAM_TYPE_FLOAT:
					snprintf(pxParam->sParamValue,sizeof(pxParam->sParamValue), "%f",
						*((float *)(pVoipStruct +
							    acOffsetStruct
							    [nIndex].
							    unOffset)));
					nFlag = 1;
					break;
				case IFX_VMAPI_PARAM_TYPE_STR:
					strncpy(pxParam->sParamValue,
					       ((char *)pVoipStruct +
						acOffsetStruct[nIndex].
						unOffset),sizeof(pxParam->sParamValue));
					nFlag = 1;
					break;

				}

			}
			//if the param is found and processed ,break the loop and check the next param
			if (nFlag == 1) {
				break;
			}
		}
	}
      END:

	return nRetVal;

}



#ifdef ULE_SUPPORT

/******************************************************************************
*  Function Name  : ifx_get_UleSubsInfo
*  Description    : Get api to get UleSubsInfo object.
*  Input Values   : uiInstanceId - instance to get
*  Output Values  : pxUleSubsInfo - pointer to UleSubsInfo 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t
ifx_get_UleSubsInfo(x_IFX_ULE_MAPI_UleSubsInfo *
				   pxUleSubsInfo, IN uint32 uiInstanceId)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_UleSubsInfo function.");

	int32_t nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	char sObjname[MAX_LEN_OBJNAME];	
	/*CREATE mESSAGE HEADER */
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	memset(sObjname, 0,MAX_LEN_OBJNAME);
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);
	
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",VOICESERVICE_ULE_SUBS_INFO,(uiInstanceId + 1));
	/*Get UleSubsInfo object */
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname,
			xObjHdr.unSubOper);
	/*Get UleSubsInfo object Value */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for UleSubsInfo object failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get value for UleSusInfo Success!!!!");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE)
		{
			//getting teh number of parameters
			nSize =
			    sizeof
			    (x_IFX_ULE_MAPI_UleSubsInfo_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    fill_struct_param(pxTmpObj, pxUleSubsInfo,
					      x_IFX_ULE_MAPI_UleSubsInfo_param,
					      nSize);
			CHECK_FOR_ERROR
			    ("Dump value for UleSubsInfo object failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Dump value for UleSubsInfo object Success.");

			break;
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_UleSubsInfo function");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_set_UleSubsInfo
*  Description    : Set api to set UleSubsInfo object.
*  Input Values   : uiInstanceId - instance to get
*  Output Values  : pxUleSubsInfo - pointer to UleSubsInfo
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32_t
ifx_set_UleSubsInfo(x_IFX_ULE_MAPI_UleSubsInfo *
                   pxUleSubsInfo, IN uint32 uiInstanceId)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_UleSubsInfo function.");
	char sObjname[MAX_LEN_OBJNAME];
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxUleSubsInfo,
		       "Error : Input name value object is NULL");

	/*fill the instance number and create the object name */
	memset(sObjname, 0, MAX_LEN_OBJNAME);
	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",VOICESERVICE_ULE_SUBS_INFO,(uiInstanceId + 1));
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, /*SOPT_OBJVALUE */ SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for UleSubsInfo failed");
	
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for UleSubsInfo success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE) {

			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_ULE_MAPI_UleSubsInfo_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxUleSubsInfo,
						 x_IFX_ULE_MAPI_UleSubsInfo_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the UleSubsInfo param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for UleSubsInfo in object list Success.");


			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;

			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing UleSubsInfo Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing UleSubsInfo Object to DB Success !!!!");
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_UleSubsInfo function.");

	return nRetVal;


}


/******************************************************************************
*  Function Name  : ifx_get_UleConfig
*  Description    : Get api to get UleSystemConfig object.
*  Input Values   : uiInstanceId - instance to get
*  Output Values  : pxUleSubsInfo - pointer to UleSystemConfig 
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          : 
******************************************************************************/
int32_t
ifx_get_UleConfig(x_IFX_ULE_MAPI_SystemConfig *
				   pxUleSysConfig, IN uint32 uiInstanceId)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_get_UleConfig function.");

	int32_t nSize = 0, nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	char sObjname[MAX_LEN_OBJNAME];
	/*CREATE mESSAGE HEADER */
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	snprintf(sObjname,MAX_LEN_OBJNAME,"%s",VOICESERVICE_ULE_SYSTEM_CONFIG);
	/*Get UleSubsInfo object */
	HELP_OBJECT_GET(xObjHdr.pObjType,VOICESERVICE_ULE_SYSTEM_CONFIG,
			xObjHdr.unSubOper);

	/*Get UleSubsInfo object Value */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for UleSystemConfig object failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get value for UleSystemConfig Success!!!!");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
		    DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULESYSTEM)
		{
			//getting teh number of parameters
			nSize =
			    sizeof
					(x_IFX_ULE_MAPI_SystemConfig_param) /
			    sizeof(x_IFX_Param);
			nRetVal =
			    fill_struct_param(pxTmpObj,pxUleSysConfig,
					      x_IFX_ULE_MAPI_SystemConfig_param,
					      nSize);
			CHECK_FOR_ERROR
			    ("Dump value for UleSysConfig object failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Dump value for UleSysConfig object Success.");

			break;
		}

	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_get_UleConfig function.");
	return nRetVal;
}

/******************************************************************************
*  Function Name  : ifx_set_UleConfig
*  Description    : Set api to set UleSystemConfig object.
*  Input Values   : uiInstanceId - instance to set
*  Output Values  : pxUleSubsInfo - pointer to UleSystemConfig
*                   object
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32_t
ifx_set_UleConfig(x_IFX_ULE_MAPI_SystemConfig *
                   pxUleSysConfig, IN uint32 uiInstanceId)
{

	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Enter ifx_set_UleConfig function.");
	int32_t nSize = 0;

	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	

	int32_t nRetVal = IFX_VMAPI_SUCCESS;

	CHECK_FOR_NULL(pxUleSysConfig,
		       "Error : Input name value object is NULL");

	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_LEAFNODE,
			OWN_SERVD, 1);
	HELP_OBJECT_GET(xObjHdr.pObjType, VOICESERVICE_ULE_SYSTEM_CONFIG, xObjHdr.unSubOper);

	/*Get the Object from DB */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get Value for UleSysConfig  failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Get Val for UleSysConfig success !!!!");
	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) == DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULESYSTEM) {
			/*update the modified value in Objectlist */
			nSize =
			    sizeof(x_IFX_ULE_MAPI_SystemConfig_param) /
			    sizeof(x_IFX_Param);

			nRetVal =
			    UpdateParamValueInDB(pxTmpObj, pxUleSysConfig,
						 x_IFX_ULE_MAPI_SystemConfig_param,
						 nSize);
			CHECK_FOR_ERROR
			    ("Updating the UleSysConfig param values in Object list failed");

			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Updating value for UleSysConfig in object list Success");


			/*wrintg to DB */
			xObjHdr.unMainOper = MOPT_SET;
			xObjHdr.unSubOper = SOPT_OBJVALUE;
			xObjHdr.unOwner = OWN_SERVD;
			cal_setValueWrapper(&xObjHdr);
			CHECK_FOR_ERROR
			    ("Writing UleSysconfig Object to DB Failed");
			IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
				 IFX_DBG_STR,
				 "Writing UleSysConfig Object to DB Success !!!!");
			break;
		}
	}
      END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
		 "Exit ifx_set_UleConfig function.");

	return nRetVal;
}
/******************************************************************************
*  Function Name  : ifx_set_UleReceivedBuff
*  Description    : Get api to get Received buffer for Ule device.
*  Input Values   : uiInstanceId - instance to get
*  Output Values  : char *acReceivedBuff
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32_t
ifx_set_UleReceivedBuff(char acReceivedBuff[3][MAX_LEN_PARAM_VALUE], IN uint32 uiInstanceId)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Enter ifx_set_UleReceivedBuff function.");
	
	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	char sObjname[MAX_LEN_OBJNAME] = {'\0'};
	ParamList *pxParam;
   
	/*CREATE mESSAGE HEADER */
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",VOICESERVICE_ULE_SUBS_INFO,uiInstanceId);
	/*Get UleDevice info object */
	HELP_OBJECT_GET(xObjHdr.pObjType,sObjname,
									xObjHdr.unSubOper);

	/*Get UleSubsInfo object Value */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for UleDevice failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
						"Get value for UleDevice Success!!!!");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
				DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE)
		{
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (pxParam->unParamId ==
						DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE_X_VENDOR_COM_RECEIVEDMESSAGE1)
				{
					strncpy(pxParam->sParamValue,acReceivedBuff[0],MAX_LEN_PARAM_VALUE);

				}
				if (pxParam->unParamId ==
						DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE_X_VENDOR_COM_RECEIVEDMESSAGE2)
				{
					strncpy(pxParam->sParamValue,acReceivedBuff[1],MAX_LEN_PARAM_VALUE);
				}
				if (pxParam->unParamId ==
						DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE_X_VENDOR_COM_RECEIVEDMESSAGE3)
				{
					strncpy(pxParam->sParamValue,acReceivedBuff[2],MAX_LEN_PARAM_VALUE);
				}
			}	
		}
	}
            /*wrintg to DB */
	xObjHdr.unMainOper = MOPT_SET;
	xObjHdr.unSubOper = SOPT_OBJVALUE;
	xObjHdr.unOwner = OWN_SERVD;
	cal_setValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR
    	("Writing UleDevice Buffer to DB Failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
    									IFX_DBG_STR,
										"Writing Ule Device Buffer to DB Success !!!!");


END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Exit ifx_set_UleReceivedBuff function.");

	return nRetVal;
}
/******************************************************************************
*  Function Name  : ifx_get_UleReceivedBuff
*  Description    : Get api to get Received buffer for Ule device.
*  Input Values   : uiInstanceId - instance to get
*  Output Values  : char *acReceivedBuff 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                   IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32_t
ifx_get_UleReceivedBuff(char acReceivedBuff[3][MAX_LEN_PARAM_VALUE], IN uint32 uiInstanceId)
{
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Enter ifx_get_UleReceivedBuff function.");
	
	int32_t nRetVal = IFX_VMAPI_SUCCESS;
	ObjList *pxTmpObj = NULL;
	MsgHeader xObjHdr;
	char sObjname[MAX_LEN_OBJNAME] = {'\0'};
	ParamList *pxParam;
   
	/*CREATE mESSAGE HEADER */
	memset(&xObjHdr, 0, sizeof(MsgHeader));
	HELP_CREATE_MSG(&xObjHdr, MOPT_GET, SOPT_OBJVALUE, OWN_SERVD, 1);

	snprintf(sObjname,MAX_LEN_OBJNAME,"%s%d",VOICESERVICE_ULE_SUBS_INFO,uiInstanceId);
	/*Get UleDevice info object */
	HELP_OBJECT_GET(xObjHdr.pObjType,sObjname,
									xObjHdr.unSubOper);

	/*Get UleSubsInfo object Value */
	nRetVal = cal_getValueWrapper(&xObjHdr);
	CHECK_FOR_ERROR("Get value for UleDevice failed");
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
						"Get value for UleDevice Success!!!!");

	FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
		if (GET_OBJ_OID(pxTmpObj) ==
				DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE)
		{
			FOR_EACH_PARAM(pxTmpObj, pxParam) {
				if (pxParam->unParamId ==
						DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE_X_VENDOR_COM_RECEIVEDMESSAGE1)
				{
					strncpy(acReceivedBuff[0],pxParam->sParamValue,MAX_LEN_PARAM_VALUE);
				}
				if (pxParam->unParamId ==
						DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE_X_VENDOR_COM_RECEIVEDMESSAGE2)
				{
					strncpy(acReceivedBuff[1],pxParam->sParamValue,MAX_LEN_PARAM_VALUE);
				}
				if (pxParam->unParamId ==
						DEVICE_SERVICES_VOICESERVICE_X_VENDOR_COM_ULEDEVICE_X_VENDOR_COM_RECEIVEDMESSAGE3)
				{
					strncpy(acReceivedBuff[2],pxParam->sParamValue,MAX_LEN_PARAM_VALUE);
				}
			}	
		}
	}

END:
	HELP_DELETE_MSG(&xObjHdr);
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
			"Exit ifx_get_UleReceivedBuff function.");

	return nRetVal;

}
/******************************************************************************
*  Function Name  : IFX_ULE_CONFIG
*  Description    : Api to get and set Ule config
*  Input Values   : bset - 1 - set Request
						   0 - get Request
				  : unObjCode - Object code
				  : uiInstanceId - instance to set
*  Output Values  : pucBuff - pointer to UleSystemConfig
*                   object
*  Return Value   : IFX_ULE_MAPI_SUCCESS, on success
*                   IFX_ULE_MAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
e_IFX_UMAPI_Return IFX_ULE_CONFIG(uchar8 bset ,uint32 unObjCode, uchar8 *pucBuff, uint32 uiInstanceId)
{
	if(pucBuff == NULL){
		return IFX_ULE_MAPI_FAIL;
	}
	switch(unObjCode){
			case 1:
				if(bset)
					ifx_set_UleSubsInfo((x_IFX_ULE_MAPI_UleSubsInfo*)pucBuff,uiInstanceId);
				else if(!bset)
					ifx_get_UleSubsInfo((x_IFX_ULE_MAPI_UleSubsInfo*)pucBuff,uiInstanceId);	
				break;
			case 2:
                if(bset)
                    ifx_set_UleConfig((x_IFX_ULE_MAPI_SystemConfig*)pucBuff,uiInstanceId);
                else if(!bset)
                    ifx_get_UleConfig((x_IFX_ULE_MAPI_SystemConfig*)pucBuff,uiInstanceId);

				break;
			default:
			printf("\nunObjCode %d not found",unObjCode);
		}

		return IFX_ULE_MAPI_SUCCESS;
}
#endif
/******************************************************************************
*  Function Name  : IFX_VMAPI_UpdateFwSuppCodec
*  Description    : Set Firmware supported codec in DB
*  Input Values   : uiFwSuppCodec - Fw supported codec
*  Output Values  : 
*  Return Value   : IFX_VMAPI_SUCCESS, on success
*                    IFX_VMAPI_FAIL, on failure.
*  Notes          :
******************************************************************************/
int32_t IFX_VMAPI_UpdateFwSuppCodec(uint32 uiFwSuppCodec)
{
    IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Enter IFX_VMAPI_UpdateFwSuppCodec function.");

    char sObjname[MAX_LEN_OBJNAME];
    int32_t nRetVal = IFX_VMAPI_SUCCESS;
    ObjList *pxTmpObj;
    MsgHeader xObjHdr;
    memset(sObjname, 0, MAX_LEN_OBJNAME);
    strncpy(sObjname, VOICE_SERVICE_CAPAB, sizeof(VOICE_SERVICE_CAPAB));
    ParamList *pxParam;

    memset(&xObjHdr, 0, sizeof(MsgHeader));
    HELP_CREATE_MSG(&xObjHdr, MOPT_GET,SOPT_LEAFNODE, OWN_SERVD, 1);
    HELP_OBJECT_GET(xObjHdr.pObjType, sObjname, xObjHdr.unSubOper);

    /*Getting the Value */
    nRetVal = cal_getValueWrapper(&xObjHdr);
    CHECK_FOR_ERROR("Get Value for voice codec capabilties failed");

    IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Get value of voice codec capabilties success!!!!");
    FOR_EACH_OBJ(xObjHdr.pObjType, pxTmpObj) {
        if (GET_OBJ_OID(pxTmpObj) ==
            DEVICE_SERVICES_VOICESERVICE_CAPABILITIES) {
            IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH,
                 IFX_DBG_STR, "Dumping capabilities.");

            FOR_EACH_PARAM(pxTmpObj, pxParam) {
                if (pxParam->unParamId ==
                    DEVICE_SERVICES_VOICESERVICE_CAPABILITIES_X_VENDOR_COM_FWSUPPCODEC)
                {
                	snprintf(pxParam->sParamValue,MAX_LEN_PARAM_VALUE,"%u",uiFwSuppCodec);
                    break;
                }
            }
        }
	}
	    /*wrintg to DB */
    xObjHdr.unMainOper = MOPT_SET;
    xObjHdr.unSubOper = SOPT_OBJVALUE;
    xObjHdr.unOwner = OWN_SERVD;

    nRetVal = cal_setValueWrapper(&xObjHdr);
    CHECK_FOR_ERROR
        ("Writing Fw supported codec to DB failed.");
    IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Writing Fw supported codec Success !!!! \n");

END:
	IFX_DBGA(ucVMAPIModuleId, IFX_DBG_LVL_HIGH, IFX_DBG_STR,
         "Exit IFX_VMAPI_UpdateFwSuppCodec function.");
    return nRetVal;

		
}
