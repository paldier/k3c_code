/**************************************************************************
 **   FILE NAME       : ifx_vmapi_intimate.c
 **   PROJECT         : Voice Management API
 **   MODULES         : Common module for Applications requiring cpeId
 **   SRC VERSION     : V0.1
 **   DATE            : 23-04-2007
 **   AUTHOR          : 
 **   DESCRIPTION     : This file defines the mechanism for maintaining
 **											the cpeId for the use of applications reequired
 **											to call the VMAPI ifx_get* and ifx_set* APIs.
 **   FUNCTIONS       : IFX_VMAPI_Get_CpeId
 **											
 **   COMPILER        : MIPS 4KC cross compiler
 **   REFERENCE       :
 **   COPYRIGHT       : Copyright © 2006 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 München, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/

#include <unistd.h>
#include "ifx_vmapi_cpeid.h"
extern int32 IFX_OS_OpenFifo(uchar8 *, int32);

uint32 uiOutF = 0;
uint32 uiInF = 0;
char8 acBuf[IFX_MAX_BUFF_LEN] = {0};
char8 acString[MAX_FILELINE_LEN] = {0};
int32 iRet=0;
char8 NVPair[50]={0};
uint32 uiBitMapVal =0;
 
/*****************************************************************************
*  Function Name        :   IFX_VMAPI_GetBitMap
*  Description          :   This Function Get the BitMap value from rc.conf
*  Input Values         :   BitMap pattern  
*  Output Values        :   BitMap pattern value
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
uint32 IFX_VMAPI_GetBitMap(uchar8 uiPat , uint32 *uiBitMap)
{
	iRet = IFX_VMAPI_SUCCESS;
 	
	if(uiPat ==1)
    strcpy((char8*)acString, "BitMap1");
	else if(uiPat ==2)
    strcpy((char8*)acString, "BitMap2");
	else 
    strcpy((char8*)acString, "BitMap3");
#if 0	
  if ((iRet = ifx_GetObjData(SYSTEM_CONF_FILE, "Map_Info", 
         acString, uiInF, &uiOutF, acBuf)) != IFX_VMAPI_SUCCESS)  {
       IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		     	"GET Data failed BitMap\n");
        return iRet;   
  }
#endif
  *uiBitMap = atoi(acBuf); 
	return iRet;
}
/*****************************************************************************
*  Function Name        :   IFX_VMAPI_SetBitMap
*  Description          :   This Function Sets the BitMap value in rc.conf
*  Input Values         :   BitMap pattern, BitMap value 
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
uchar8 IFX_VMAPI_SetBitMap(uchar8 uiPat, uint32 uiBitMap)
{
	iRet = IFX_VMAPI_SUCCESS;
	
	if(uiPat == 1)
    strcpy((char8*)acString, "BitMap1");
	else if(uiPat == 2)
    strcpy((char8*)acString, "BitMap2");
	else
    strcpy((char8*)acString, "BitMap3");
	
	sprintf(NVPair,"%s=\"%d\"\n",acString,uiBitMap);
#if 0
    if ((iRet = ifx_SetObjData(SYSTEM_CONF_FILE, "Map_Info", 
           IFX_F_MODIFY, 1, (char8*)NVPair)) != IFX_VMAPI_SUCCESS)  {
         IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		       	"SET Data failed BitMap\n");
           return iRet;   
    }
#endif
		return iRet;
}

/*****************************************************************************
*  Function Name        :   IFX_VMAPI_IntimateOnChange
*  Description          :   This Function registors an Object for the required
*                           infotype  .
*  Input Values         :   Infotype 
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
PUBLIC char8 IFX_VMAPI_IntimateOnChange(IN uchar8 ucInfoType[],IN uchar8 ucSize)
{
  uint32 uiTemp=0;
	int32 i=0,uiBitMap3=0;
    IFX_VMAPI_GetBitMap(1,&uiBitMapVal);
    uiBitMap1 = uiBitMapVal;
    IFX_VMAPI_GetBitMap(2,&uiBitMapVal);
    uiBitMap2 = uiBitMapVal;
    IFX_VMAPI_GetBitMap(3,&uiBitMapVal);
    uiBitMap3 = uiBitMapVal;
  /*check the info type*/
for(i = 0; i< ucSize ; i++){
 if(ucInfoType[i] < 31)
  { 
    uiTemp =(1u << (ucInfoType[i]));      
    uiBitMap1 |= uiTemp; 
  }
  else if(ucInfoType[i] >= 31 && ucInfoType[i] < 61)
  {
    uiTemp =(1u << (ucInfoType[i]-31));      
    uiBitMap2 |= uiTemp; 
  }else{
    uiTemp =(1u << (ucInfoType[i]-61));      
    uiBitMap3 |= uiTemp; 

	}
}
    if(IFX_VMAPI_SetBitMap(1,uiBitMap1) != IFX_VMAPI_SUCCESS)
		{
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		       	"SET BitMap1 failed \n");
		}
    if(IFX_VMAPI_SetBitMap(2,uiBitMap2) != IFX_VMAPI_SUCCESS)
		{
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		       	"SET BitMap2 failed \n");
		}
    if(IFX_VMAPI_SetBitMap(3,uiBitMap3) != IFX_VMAPI_SUCCESS)
		{
      IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		       	"SET BitMap3 failed \n");
		}
 return IFX_VMAPI_SUCCESS;
}


/*****************************************************************************
*  Function Name        :   IFX_VMAPI_IsProcessRegistered
*  Description          :   This Function checks whether the Object is registered
*                           or not .
*  Input Values         :   Infotype 
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
PUBLIC char8 IFX_VMAPI_IsObjectRegistered(IN uchar8 ucInfoType)
{
  int32 iTemp=0;
  uint32 uiBitMap=0;
  
  
	if(ucInfoType < 31)
  { 
    iTemp =(1u << ucInfoType);
    IFX_VMAPI_GetBitMap(1,&uiBitMapVal);
    uiBitMap = uiBitMapVal;
  }
  else if(ucInfoType >= 31 && ucInfoType < 61)
  {
    iTemp =(1u << (ucInfoType-31));      
    IFX_VMAPI_GetBitMap(2,&uiBitMapVal);
    uiBitMap = uiBitMapVal;
  }else {
    iTemp =(1u << (ucInfoType-61));      
    IFX_VMAPI_GetBitMap(3,&uiBitMapVal);
    uiBitMap = uiBitMapVal;
	}
  if(uiBitMap & iTemp)
  {
    IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		     	"Object is Registered \n");
		return IFX_VMAPI_SUCCESS;
	}
	return IFX_VMAPI_FAIL;
}
/*****************************************************************************
*  Function Name        :   IFX_VMAPI_SendMsgToRegProcess
*  Description          :   This Function send message for the registered Object
*  Input Values         :   Infotype ,pvOldObj ,pvNewObj
*  Output Values        :
*  Return Value         :   IFX_VMAPI_SUCCESS - On Success
*                           IFX_VMAPI_FAIL - On Failure
*  Notes            :
*****************************************************************************/ 
PUBLIC char8 IFX_VMAPI_SendNotifyForRegObject(IN uchar8 ucInfoType,
                                           IN void *pvOldObj , IN void *pvNewObj)
{
  int32 iSize=0;
  int32 fifoFd;
  char8* acBuf;

  acBuf = (char8 *)malloc(5000); 
	if(acBuf == NULL)
	{
		return IFX_VMAPI_FAIL;
	}
	else {
  	   memset(acBuf,0,5000);
	}
 
  IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
	       	"Entering IFX_VMAPI_SendMsgToRegProcess \n");
  {
      /*populate the structure as per the InfoType*/     
	    switch(ucInfoType)
	    {
#ifdef VOIP_NEWVMAPI
				case IFX_VMAPI_INTERFACE_CHANGE:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
					iSize = 4;
          if(pvNewObj != NULL) {
              memcpy((acBuf+iSize),((char8 *)pvNewObj),
                      strlen((char8 *)pvNewObj));
              iSize = iSize + strlen((char8 *)pvNewObj);
					}
					break;
#ifdef DECT_SUPPORT
#ifdef DECT_REPEATER
                case IFX_VMAPI_DECT_REPEATER:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
                    iSize = 4;
          if(pvOldObj != NULL){
                      memcpy((acBuf+4),((x_IFX_VMAPI_DectRepeater *)pvOldObj),
                    sizeof(x_IFX_VMAPI_DectRepeater));
            iSize = iSize + sizeof(x_IFX_VMAPI_DectRepeater);
                 	memcpy((acBuf+iSize),((x_IFX_VMAPI_DectSubsInfo *)((x_IFX_VMAPI_DectRepeater *)pvOldObj)->pxSubsInfo),
                    sizeof(x_IFX_VMAPI_DectSubsInfo));
            iSize = iSize + sizeof(x_IFX_VMAPI_DectSubsInfo);
          }
          if(pvNewObj != NULL){
                      memcpy((acBuf+iSize),((x_IFX_VMAPI_DectRepeater *)pvNewObj),
                    sizeof(x_IFX_VMAPI_DectRepeater));
            iSize = iSize + sizeof(x_IFX_VMAPI_DectRepeater);
                    memcpy((acBuf+iSize),((x_IFX_VMAPI_DectSubsInfo *)((x_IFX_VMAPI_DectRepeater *)pvNewObj)->pxSubsInfo),
                    sizeof(x_IFX_VMAPI_DectSubsInfo));
            iSize = iSize + sizeof(x_IFX_VMAPI_DectSubsInfo);

          }

			break;
#endif
#endif
#endif
		    case IFX_VMAPI_VS_CALL_BLOCK:
          iSize = iSize + sizeof(x_IFX_VMAPI_CallBlock);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_CallBlock *)pvOldObj),
                    sizeof(x_IFX_VMAPI_CallBlock));
          iSize = iSize + sizeof(x_IFX_VMAPI_CallBlock);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_CallBlock *)pvNewObj),
                    sizeof(x_IFX_VMAPI_CallBlock));
          iSize = iSize + sizeof(x_IFX_VMAPI_CallBlock);
  
				break;

		    case IFX_VMAPI_VS_CALL_BLOCK_ENTRY:
          iSize = iSize + sizeof(x_IFX_VMAPI_CallBlockEntry);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= (((x_IFX_VMAPI_CallBlockEntry *)pvOldObj)->ucIndex - 1);
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_CallBlockEntry *)pvOldObj),
                    sizeof(x_IFX_VMAPI_CallBlockEntry));
          iSize = iSize + sizeof(x_IFX_VMAPI_CallBlockEntry);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_CallBlockEntry *)pvNewObj),
                    sizeof(x_IFX_VMAPI_CallBlockEntry));
          iSize = iSize + sizeof(x_IFX_VMAPI_CallBlockEntry);
  
				break;


		    case IFX_VMAPI_VS_DIALCALL_REGISTER:
		    case IFX_VMAPI_VS_PSTN_DIALCALL_REGISTER:
          iSize = iSize + sizeof(x_IFX_VMAPI_DialCallRegister);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(pvOldObj != NULL){
					  memcpy((acBuf+4),((x_IFX_VMAPI_DialCallRegister *)pvOldObj),
                    sizeof(x_IFX_VMAPI_DialCallRegister));
            iSize = iSize + sizeof(x_IFX_VMAPI_DialCallRegister);
          }
          if(pvNewObj != NULL){
					  memcpy((acBuf+iSize),((x_IFX_VMAPI_DialCallRegister *)pvNewObj),
                    sizeof(x_IFX_VMAPI_DialCallRegister));
            iSize = iSize + sizeof(x_IFX_VMAPI_DialCallRegister);
          }
				break;
		    case IFX_VMAPI_VS_MISSCALL_REGISTER:
		    case IFX_VMAPI_VS_PSTN_MISSCALL_REGISTER:
          iSize = iSize + sizeof(x_IFX_VMAPI_MissCallRegister);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(pvOldObj != NULL){
					  memcpy((acBuf+4),((x_IFX_VMAPI_MissCallRegister *)pvOldObj),
                    sizeof(x_IFX_VMAPI_MissCallRegister));
            iSize = iSize + sizeof(x_IFX_VMAPI_MissCallRegister);
          } 
          if(pvNewObj != NULL){
					  memcpy((acBuf+iSize),((x_IFX_VMAPI_MissCallRegister *)pvNewObj),
                    sizeof(x_IFX_VMAPI_MissCallRegister));
            iSize = iSize + sizeof(x_IFX_VMAPI_MissCallRegister);
          }
				break;
		    case IFX_VMAPI_VS_RECVCALL_REGISTER:
		    case IFX_VMAPI_VS_PSTN_RECVCALL_REGISTER:
          iSize = iSize + sizeof(x_IFX_VMAPI_RecvCallRegister);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(pvOldObj != NULL){
					  memcpy((acBuf+4),((x_IFX_VMAPI_RecvCallRegister *)pvOldObj),
                    sizeof(x_IFX_VMAPI_RecvCallRegister));
            iSize = iSize + sizeof(x_IFX_VMAPI_RecvCallRegister);
          }
          if(pvNewObj != NULL){
					  memcpy((acBuf+iSize),((x_IFX_VMAPI_RecvCallRegister *)pvNewObj),
                    sizeof(x_IFX_VMAPI_RecvCallRegister));
            iSize = iSize + sizeof(x_IFX_VMAPI_RecvCallRegister);
          }
				break;

			case IFX_VMAPI_VS_CONTACT_LIST:
			case IFX_VMAPI_VS_PSTN_CONTACT_LIST:
			case IFX_VMAPI_VS_COMMON_CONTACT_LIST:
          iSize = iSize + sizeof(x_IFX_VMAPI_ContactList);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(pvOldObj != NULL){
				  	memcpy((acBuf+4),((x_IFX_VMAPI_ContactList *)pvOldObj),
                    sizeof(x_IFX_VMAPI_ContactList));
            iSize = iSize + sizeof(x_IFX_VMAPI_ContactList);
          }
          if(pvNewObj != NULL){
				   	memcpy((acBuf+iSize),((x_IFX_VMAPI_ContactList *)pvNewObj),
                    sizeof(x_IFX_VMAPI_ContactList));
            iSize = iSize + sizeof(x_IFX_VMAPI_ContactList);
          }
			break;

		    case IFX_VMAPI_VS_ADDRESS_BOOK:
          iSize = iSize + sizeof(x_IFX_VMAPI_AddressBook);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(pvOldObj != NULL){
				  	memcpy((acBuf+4),((x_IFX_VMAPI_AddressBook *)pvOldObj),
                    sizeof(x_IFX_VMAPI_AddressBook));
            iSize = iSize + sizeof(x_IFX_VMAPI_AddressBook);
          }
          if(pvNewObj != NULL){
				   	memcpy((acBuf+iSize),((x_IFX_VMAPI_AddressBook *)pvNewObj),
                    sizeof(x_IFX_VMAPI_AddressBook));
            iSize = iSize + sizeof(x_IFX_VMAPI_AddressBook);
          }
				break;
		    case IFX_VMAPI_VS_ADDRESS_BOOK_ENTRY:
          iSize = iSize + sizeof(x_IFX_VMAPI_AddressBookEntry);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= (((x_IFX_VMAPI_AddressBookEntry *)pvOldObj)->ucIndex - 1);
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_AddressBookEntry *)pvOldObj),
                    sizeof(x_IFX_VMAPI_AddressBookEntry));
          iSize = iSize + sizeof(x_IFX_VMAPI_AddressBookEntry);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_AddressBookEntry *)pvNewObj),
                    sizeof(x_IFX_VMAPI_AddressBookEntry));
          iSize = iSize + sizeof(x_IFX_VMAPI_AddressBookEntry);
  
				break;

		    case IFX_VMAPI_VS_DEBUG_SET:
          iSize = iSize + sizeof(x_IFX_VMAPI_SystemDebugSettings);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_SystemDebugSettings *)pvOldObj),
                    sizeof(x_IFX_VMAPI_SystemDebugSettings));
          iSize = iSize + sizeof(x_IFX_VMAPI_SystemDebugSettings);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_SystemDebugSettings *)pvNewObj),
                    sizeof(x_IFX_VMAPI_SystemDebugSettings));
          iSize = iSize + sizeof(x_IFX_VMAPI_SystemDebugSettings);
  
				break;

		    case IFX_VMAPI_VS_NUM_PLAN:
          iSize = iSize + sizeof(x_IFX_VMAPI_NumPlan);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_NumPlan *)pvOldObj),
                    sizeof(x_IFX_VMAPI_NumPlan));
          iSize = iSize + sizeof(x_IFX_VMAPI_NumPlan);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_NumPlan *)pvNewObj),
                    sizeof(x_IFX_VMAPI_NumPlan));
          iSize = iSize + sizeof(x_IFX_VMAPI_NumPlan);
  
				break;
		    case IFX_VMAPI_VS_NUM_PLAN_RULES:
          iSize = iSize + sizeof(x_IFX_VMAPI_NumPlanRule);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= (((x_IFX_VMAPI_NumPlanRule *)pvOldObj)->ucIndex - 1);
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_NumPlanRule *)pvOldObj),
                    sizeof(x_IFX_VMAPI_NumPlanRule));
          iSize = iSize + sizeof(x_IFX_VMAPI_NumPlanRule);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_NumPlanRule *)pvNewObj),
                    sizeof(x_IFX_VMAPI_NumPlanRule));
          iSize = iSize + sizeof(x_IFX_VMAPI_NumPlanRule);
  
				break;

		    case IFX_VMAPI_VS_TONE_INFO:
          iSize = iSize + sizeof(x_IFX_VMAPI_ToneTable);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_ToneTable *)pvOldObj),
                    sizeof(x_IFX_VMAPI_ToneTable));
          iSize = iSize + sizeof(x_IFX_VMAPI_ToneTable);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_ToneTable *)pvNewObj),
                    sizeof(x_IFX_VMAPI_ToneTable));
          iSize = iSize + sizeof(x_IFX_VMAPI_ToneTable);
  
				break;

		    case IFX_VMAPI_VS_T38:
          iSize = iSize + sizeof(x_IFX_VMAPI_T38Cfg);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_T38Cfg *)pvOldObj),
                    sizeof(x_IFX_VMAPI_T38Cfg));
          iSize = iSize + sizeof(x_IFX_VMAPI_T38Cfg);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_T38Cfg *)pvNewObj),
                    sizeof(x_IFX_VMAPI_T38Cfg));
          iSize = iSize + sizeof(x_IFX_VMAPI_T38Cfg);
  
				break;

		    case IFX_VMAPI_VS_MISC:
          iSize = iSize + sizeof(x_IFX_VMAPI_Misc);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_Misc *)pvOldObj),
                    sizeof(x_IFX_VMAPI_Misc));
          iSize = iSize + sizeof(x_IFX_VMAPI_Misc);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_Misc *)pvNewObj),
                    sizeof(x_IFX_VMAPI_Misc));
          iSize = iSize + sizeof(x_IFX_VMAPI_Misc);
  
				break;

		    case IFX_VMAPI_VS_VER:
          iSize = iSize + sizeof(x_IFX_VMAPI_SystemVersionRegister);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_SystemVersionRegister *)pvOldObj),
                    sizeof(x_IFX_VMAPI_SystemVersionRegister));
          iSize = iSize + sizeof(x_IFX_VMAPI_SystemVersionRegister);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_SystemVersionRegister *)pvNewObj),
                    sizeof(x_IFX_VMAPI_SystemVersionRegister));
          iSize = iSize + sizeof(x_IFX_VMAPI_SystemVersionRegister);
  
				break;

		    case IFX_VMAPI_PHY_INT_TEST:
          iSize = iSize + sizeof(x_IFX_VMAPI_VoiceServPhyIfTest);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_VoiceServPhyIfTest *)pvOldObj),
                    sizeof(x_IFX_VMAPI_VoiceServPhyIfTest));
          iSize = iSize + sizeof(x_IFX_VMAPI_VoiceServPhyIfTest);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_VoiceServPhyIfTest *)pvNewObj),
                    sizeof(x_IFX_VMAPI_VoiceServPhyIfTest));
          iSize = iSize + sizeof(x_IFX_VMAPI_VoiceServPhyIfTest);
  
				break;

		    case IFX_VMAPI_ADD_PROFILE:
		    case IFX_VMAPI_VOICE_PROFILE:
		    case IFX_VMAPI_DELETE_PROFILE:
          iSize = iSize + sizeof(x_IFX_VMAPI_VoiceProfile);
          *(acBuf) = ucInfoType;
          *(acBuf+1)= (((x_IFX_VMAPI_VoiceProfile *)pvOldObj)->ucProfileId - 1);
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_VoiceProfile *)pvOldObj),
                    sizeof(x_IFX_VMAPI_VoiceProfile));
          iSize = iSize + sizeof(x_IFX_VMAPI_VoiceProfile);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_VoiceProfile *)pvNewObj),
                    sizeof(x_IFX_VMAPI_VoiceProfile));
          iSize = iSize + sizeof(x_IFX_VMAPI_VoiceProfile);
  
				break;
       case IFX_VMAPI_VP_SER_PROVIDER:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= (((x_IFX_VMAPI_ProfileServiceProviderInfo *)pvOldObj)->ucProfileId - 1);
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_ProfileServiceProviderInfo *)pvOldObj),
                    sizeof(x_IFX_VMAPI_ProfileServiceProviderInfo));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileServiceProviderInfo);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_ProfileServiceProviderInfo *)pvNewObj),
                    sizeof(x_IFX_VMAPI_ProfileServiceProviderInfo));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileServiceProviderInfo);
          
				break;
      case IFX_VMAPI_VP_SIGNALING:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= (((x_IFX_VMAPI_ProfileSignaling *)pvOldObj)->ucProfileId - 1);
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_ProfileSignaling *)pvOldObj),
                    sizeof(x_IFX_VMAPI_ProfileSignaling));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileSignaling);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_ProfileSignaling *)pvNewObj),
                    sizeof(x_IFX_VMAPI_ProfileSignaling));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileSignaling);
          
				break;

       case IFX_VMAPI_VP_EVENT_SUBSCR:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= (((x_IFX_VMAPI_ProfileEventSubsTable *)pvOldObj)->ucProfileId - 1);
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_ProfileEventSubsTable *)pvOldObj),
                    sizeof(x_IFX_VMAPI_ProfileEventSubsTable));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileEventSubsTable);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_ProfileEventSubsTable *)pvNewObj),
                    sizeof(x_IFX_VMAPI_ProfileEventSubsTable));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileEventSubsTable);
          
				break;

       case IFX_VMAPI_VP_EVENT_SUBSCR_ENTRY:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= (((x_IFX_VMAPI_EventSubscribe *)pvOldObj)->ucProfileId - 1);
          *(acBuf+2)= 1;
          *(acBuf+3)= (((x_IFX_VMAPI_EventSubscribe *)pvOldObj)->ucIndex - 1);
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_EventSubscribe *)pvOldObj),
                    sizeof(x_IFX_VMAPI_EventSubscribe));
          iSize = iSize + sizeof(x_IFX_VMAPI_EventSubscribe);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_EventSubscribe *)pvNewObj),
                    sizeof(x_IFX_VMAPI_EventSubscribe));
          iSize = iSize + sizeof(x_IFX_VMAPI_EventSubscribe);
          
				break;

       case IFX_VMAPI_VP_RTP:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= (((x_IFX_VMAPI_ProfileMediaRTP *)pvOldObj)->ucProfileId - 1);
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_ProfileMediaRTP *)pvOldObj),
                    sizeof(x_IFX_VMAPI_ProfileMediaRTP));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileMediaRTP);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_ProfileMediaRTP *)pvNewObj),
                    sizeof(x_IFX_VMAPI_ProfileMediaRTP));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileMediaRTP);
          
				break;
       case IFX_VMAPI_VP_RTCP:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= (((x_IFX_VMAPI_ProfileMediaRTCP *)pvOldObj)->ucProfileId - 1);
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_ProfileMediaRTCP *)pvOldObj),
                    sizeof(x_IFX_VMAPI_ProfileMediaRTCP));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileMediaRTCP);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_ProfileMediaRTCP *)pvNewObj),
                    sizeof(x_IFX_VMAPI_ProfileMediaRTCP));
          iSize = iSize + sizeof(x_IFX_VMAPI_ProfileMediaRTCP);
          
				break;
       case IFX_VMAPI_VP_FAX:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= (((x_IFX_VMAPI_FaxT38 *)pvOldObj)->ucProfileId - 1);
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_FaxT38 *)pvOldObj),
                    sizeof(x_IFX_VMAPI_FaxT38));
          iSize = iSize + sizeof(x_IFX_VMAPI_FaxT38);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_FaxT38 *)pvNewObj),
                    sizeof(x_IFX_VMAPI_FaxT38));
          iSize = iSize + sizeof(x_IFX_VMAPI_FaxT38);
          
				break;

       case IFX_VMAPI_ADD_LINE:
       case IFX_VMAPI_VOICE_LINE:
       case IFX_VMAPI_DELETE_LINE:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_VoiceLine *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_VoiceLine *)pvOldObj),
                    sizeof(x_IFX_VMAPI_VoiceLine));
          iSize = iSize + sizeof(x_IFX_VMAPI_VoiceLine);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_VoiceLine *)pvNewObj),
                    sizeof(x_IFX_VMAPI_VoiceLine));
          iSize = iSize + sizeof(x_IFX_VMAPI_VoiceLine);
          
				break;

       case IFX_VMAPI_VL_SIGNALING:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_LineSignaling *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_LineSignaling *)pvOldObj),
                    sizeof(x_IFX_VMAPI_LineSignaling));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineSignaling);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_LineSignaling *)pvNewObj),
                    sizeof(x_IFX_VMAPI_LineSignaling));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineSignaling);
          
				break;

       case IFX_VMAPI_VL_AUTHCFG:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_LineSignaling *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= (((x_IFX_VMAPI_SipAuthCfg *)pvOldObj)->ucIndex - 1);
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_SipAuthCfg *)pvOldObj),
                    sizeof(x_IFX_VMAPI_SipAuthCfg));
          iSize = iSize + sizeof(x_IFX_VMAPI_SipAuthCfg);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_SipAuthCfg *)pvNewObj),
                    sizeof(x_IFX_VMAPI_SipAuthCfg));
          iSize = iSize + sizeof(x_IFX_VMAPI_SipAuthCfg);
          
				break;


       case IFX_VMAPI_VL_VOICE_CODEC:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_LineCodec *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_LineCodec *)pvOldObj),
                    sizeof(x_IFX_VMAPI_LineCodec));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineCodec);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_LineCodec *)pvNewObj),
                    sizeof(x_IFX_VMAPI_LineCodec));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineCodec);
          
				break;

       case IFX_VMAPI_VL_CODECLIST:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_LineCodecList *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_LineCodecList *)pvOldObj),
                    sizeof(x_IFX_VMAPI_LineCodecList));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineCodecList);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_LineCodecList *)pvNewObj),
                    sizeof(x_IFX_VMAPI_LineCodecList));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineCodecList);
          
				break;
       case IFX_VMAPI_VL_CODECLIST_ENTRY:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_LineCodecList *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= (((x_IFX_VMAPI_CodecDesc *)pvOldObj)->ucIndex - 1);
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_CodecDesc *)pvOldObj),
                    sizeof(x_IFX_VMAPI_CodecDesc));
          iSize = iSize + sizeof(x_IFX_VMAPI_CodecDesc);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_CodecDesc *)pvNewObj),
                    sizeof(x_IFX_VMAPI_CodecDesc));
          iSize = iSize + sizeof(x_IFX_VMAPI_CodecDesc);
          
				break;


       case IFX_VMAPI_VL_CALLFEAT:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_LineCallingFeatures *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_LineCallingFeatures *)pvOldObj),
                    sizeof(x_IFX_VMAPI_LineCallingFeatures));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineCallingFeatures);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_LineCallingFeatures *)pvNewObj),
                    sizeof(x_IFX_VMAPI_LineCallingFeatures));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineCallingFeatures);
          
				break;

       case IFX_VMAPI_VL_VOICE_SESSION:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_LineSession *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_LineSession *)pvOldObj),
                    sizeof(x_IFX_VMAPI_LineSession));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineSession);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_LineSession *)pvNewObj),
                    sizeof(x_IFX_VMAPI_LineSession));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineSession);
          
				break;

       case IFX_VMAPI_VL_VOICE_PROCESSING:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_LineVoiceProcessing *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_LineVoiceProcessing *)pvOldObj),
                    sizeof(x_IFX_VMAPI_LineVoiceProcessing));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineVoiceProcessing);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_LineVoiceProcessing *)pvNewObj),
                    sizeof(x_IFX_VMAPI_LineVoiceProcessing));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineVoiceProcessing);
          
				break;

       case IFX_VMAPI_VL_STATS:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_LineStats *)pvOldObj)->ucLineId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_LineStats *)pvOldObj),
                    sizeof(x_IFX_VMAPI_LineStats));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineStats);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_LineStats *)pvNewObj),
                    sizeof(x_IFX_VMAPI_LineStats));
          iSize = iSize + sizeof(x_IFX_VMAPI_LineStats);
          
				break;

       case IFX_VMAPI_PHY_IFACE_FXS:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_FxsPhyIf *)pvOldObj)->xVoiceServPhyIf.ucInterfaceId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_FxsPhyIf *)pvOldObj),
                    sizeof(x_IFX_VMAPI_FxsPhyIf));
          iSize = iSize + sizeof(x_IFX_VMAPI_FxsPhyIf);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_FxsPhyIf *)pvNewObj),
                    sizeof(x_IFX_VMAPI_FxsPhyIf));
          iSize = iSize + sizeof(x_IFX_VMAPI_FxsPhyIf);
          
				break;

       case IFX_VMAPI_PHY_IFACE_FXO:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_FxoPhyIf *)pvOldObj)->xVoiceServPhyIf.ucInterfaceId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_FxoPhyIf *)pvOldObj),
                    sizeof(x_IFX_VMAPI_FxoPhyIf));
          iSize = iSize + sizeof(x_IFX_VMAPI_FxoPhyIf);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_FxoPhyIf *)pvNewObj),
                    sizeof(x_IFX_VMAPI_FxoPhyIf));
          iSize = iSize + sizeof(x_IFX_VMAPI_FxoPhyIf);
          
				break;
#if defined(DECT_SUPPORT) || defined(CVOIP_SUPPORT)
			 case IFX_VMAPI_PHY_IFACE_DECT:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= (((x_IFX_VMAPI_DectHandset *)pvOldObj)->xVoiceServPhyIf.ucInterfaceId - 1);
          *(acBuf+3)= 1;
          iSize = 4;
					memcpy((acBuf+4),((x_IFX_VMAPI_DectHandset *)pvOldObj),
                    sizeof(x_IFX_VMAPI_DectHandset));
          iSize = iSize + sizeof(x_IFX_VMAPI_DectHandset);
					memcpy((acBuf+iSize),((x_IFX_VMAPI_DectHandset *)pvNewObj),
                    sizeof(x_IFX_VMAPI_DectHandset));
          iSize = iSize + sizeof(x_IFX_VMAPI_DectHandset);
          
				break;

			 case IFX_VMAPI_DECT_SYSTEM:
          *(acBuf) = ucInfoType;
#ifdef CVOIP_SUPPORT
          if(pvOldObj == NULL) {
			     if(pvNewObj == NULL){
             *(acBuf+1)= 1;
			     }else{
               *(acBuf+1)= 2;
			     }
		      }else {
            *(acBuf+1)= 1;
		      }
#else
          *(acBuf+1)= 1;
#endif
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
		      if(pvOldObj != NULL){
						memcpy((acBuf+4),((x_IFX_VMAPI_DectSystem *)pvOldObj),
                    sizeof(x_IFX_VMAPI_DectSystem));
          	iSize = iSize + sizeof(x_IFX_VMAPI_DectSystem);
					}
		      if(pvNewObj != NULL){
						memcpy((acBuf+iSize),((x_IFX_VMAPI_DectSystem *)pvNewObj),
                    sizeof(x_IFX_VMAPI_DectSystem));
          	iSize = iSize + sizeof(x_IFX_VMAPI_DectSystem);
					}
          
				break;

       case IFX_VMAPI_TRANS_POWER_TEST:
          *(acBuf) = ucInfoType;
          if(pvOldObj == NULL) {
			     if(pvNewObj == NULL){
             *(acBuf+1)= 1;
			     }else{
               *(acBuf+1)= 2;
			      }
		      }else {
            *(acBuf+1)= 0;
		       }
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
		      if(*(acBuf+1) == 1){
			      break;
		      }
		      if(pvOldObj != NULL){
		        memcpy((acBuf+4),((x_IFX_VMAPI_TransmitPowerParam *)pvOldObj),
                    sizeof(x_IFX_VMAPI_TransmitPowerParam));
            iSize = iSize + sizeof(x_IFX_VMAPI_TransmitPowerParam);
		      }
		      if(pvNewObj != NULL){
			      memcpy((acBuf+iSize),((x_IFX_VMAPI_TransmitPowerParam *)pvNewObj),
                    sizeof(x_IFX_VMAPI_TransmitPowerParam));
            iSize = iSize + sizeof(x_IFX_VMAPI_TransmitPowerParam);
          }
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"<VMAPI>iSize:",iSize);
		      break;


       case IFX_VMAPI_BMC_REG_PARAMS_TEST:
          *(acBuf) = ucInfoType;
          if(pvOldObj == NULL) {
			      if(pvNewObj == NULL){
              *(acBuf+1)= 1;
			      }else{
              *(acBuf+1)= 2;
			       }
		      }else {
            *(acBuf+1)= 0;
		       }
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
		      if(*(acBuf+1) == 1){
			      break;
		      }
		      if(pvOldObj != NULL){
		        memcpy((acBuf+4),((x_IFX_VMAPI_DectBMCParams *)pvOldObj),
                    sizeof(x_IFX_VMAPI_DectBMCParams));
            iSize = iSize + sizeof(x_IFX_VMAPI_DectBMCParams);
		      }
		      if(pvNewObj != NULL){
			      memcpy((acBuf+iSize),((x_IFX_VMAPI_DectBMCParams *)pvNewObj),
                    sizeof(x_IFX_VMAPI_DectBMCParams));
            iSize = iSize + sizeof(x_IFX_VMAPI_DectBMCParams);
          }
          IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_INT,"<VMAPI>iSize:",iSize);
		      break;

       case IFX_VMAPI_RF_MODE_TEST:

          *(acBuf) = ucInfoType;
          if(pvOldObj == NULL) {
		        if(pvNewObj == NULL){
              *(acBuf+1)= 1;
		        }else{
              *(acBuf+1)= 2;
			       }  
		      }else{
            *(acBuf+1)= 0;
		       }
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(*(acBuf+1) == 1){
		        break;
		      }	
          if(pvOldObj != NULL) {
			      memcpy((acBuf+4),((x_IFX_VMAPI_RFMode *)pvOldObj),
                    sizeof(x_IFX_VMAPI_RFMode));
            iSize = iSize + sizeof(x_IFX_VMAPI_RFMode);
		      }
		      if(pvNewObj != NULL){
			      memcpy((acBuf+iSize),((x_IFX_VMAPI_RFMode *)pvNewObj),
                    sizeof(x_IFX_VMAPI_RFMode));
            iSize = iSize + sizeof(x_IFX_VMAPI_RFMode);
          }
		      break;


       case IFX_VMAPI_RFPI_TEST:
           *(acBuf) = ucInfoType;
           if(pvOldObj == NULL) {
		         if(pvNewObj == NULL){
               *(acBuf+1)= 1;
		         }else {
               *(acBuf+1)= 2;
			        }  
		      }else{
            *(acBuf+1)= 0;
		       }
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(*(acBuf+1) == 1){
		        break;
		      }	
          if(pvOldObj != NULL) {
			      memcpy((acBuf+4),((x_IFX_VMAPI_DectRfpi *)pvOldObj),
                    sizeof(x_IFX_VMAPI_DectRfpi));
            iSize = iSize + sizeof(x_IFX_VMAPI_DectRfpi);
		      }
		      if(pvNewObj != NULL){
			      memcpy((acBuf+iSize),((x_IFX_VMAPI_DectRfpi *)pvNewObj),
                    sizeof(x_IFX_VMAPI_DectRfpi));
            iSize = iSize + sizeof(x_IFX_VMAPI_DectRfpi);
          }
		      break;


       case IFX_VMAPI_COUNTRY_SETTINGS_TEST:


          *(acBuf) = ucInfoType;
          if(pvOldObj == NULL) {
            if(pvNewObj == NULL) {
              *(acBuf+1)= 1;
            }else {
              *(acBuf+1)= 2;
             }
          }else{
            *(acBuf+1)= 0;
           }
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(*(acBuf+1) == 1) {
            break;
          }
          if(pvOldObj != NULL) {
              memcpy((acBuf+4),((x_IFX_VMAPI_DectCountrySettings *)pvOldObj),
                    sizeof(x_IFX_VMAPI_DectCountrySettings));
              iSize = iSize + sizeof(x_IFX_VMAPI_DectCountrySettings);
          }
          if(pvNewObj != NULL) {
              memcpy((acBuf+iSize),((x_IFX_VMAPI_DectCountrySettings *)pvNewObj),
                    sizeof(x_IFX_VMAPI_DectCountrySettings));
              iSize = iSize + sizeof(x_IFX_VMAPI_DectCountrySettings);
          } 
	        break;


       case IFX_VMAPI_OSC_TRIM_TEST:
          *(acBuf) = ucInfoType;
          if(pvOldObj == NULL) {
            if(pvNewObj == NULL) {
              *(acBuf+1)= 1;
            }else {
              *(acBuf+1)= 2;
             }
		      }else{
            *(acBuf+1)= 0;
		       }	  
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(*(acBuf+1) == 1){
		        break;
		      } //Not needed.	
          if(pvOldObj != NULL) {
			        memcpy((acBuf+4),((x_IFX_VMAPI_DectOscTrimVal *)pvOldObj),
                      sizeof(x_IFX_VMAPI_DectOscTrimVal));
              iSize = iSize + sizeof(x_IFX_VMAPI_DectOscTrimVal);
		      }	  
          if(pvNewObj != NULL) {
			        memcpy((acBuf+iSize),((x_IFX_VMAPI_DectOscTrimVal *)pvNewObj),
                      sizeof(x_IFX_VMAPI_DectOscTrimVal));
              iSize = iSize + sizeof(x_IFX_VMAPI_DectOscTrimVal);
          }
		      break;


       case IFX_VMAPI_GFSK_TEST:
          *(acBuf) = ucInfoType;
          if(pvOldObj == NULL) {
            if(pvNewObj == NULL) {
              *(acBuf+1)= 1;
            }else {
              *(acBuf+1)= 2;
             }
		      }else{
            *(acBuf+1)= 0;
		       }	  
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(*(acBuf+1) == 1){
		        break;
		      }//Not needed.	
          if(pvOldObj != NULL) {
			        memcpy((acBuf+4),((x_IFX_VMAPI_DectGFSKVal *)pvOldObj),
                      sizeof(x_IFX_VMAPI_DectGFSKVal));
              iSize = iSize + sizeof(x_IFX_VMAPI_DectGFSKVal);
		      }	  
          if(pvNewObj != NULL) {
			        memcpy((acBuf+iSize),((x_IFX_VMAPI_DectGFSKVal *)pvNewObj),
                      sizeof(x_IFX_VMAPI_DectGFSKVal));
              iSize = iSize + sizeof(x_IFX_VMAPI_DectGFSKVal);
          }
		      break;

       case IFX_VMAPI_XRAM_TEST:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= *((char8 *)pvOldObj);

          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(pvNewObj != NULL) {
			        memcpy((acBuf+iSize),((x_IFX_VMAPI_DectXRAM *)pvNewObj),
                      sizeof(x_IFX_VMAPI_DectXRAM));
              iSize = iSize + sizeof(x_IFX_VMAPI_DectXRAM);
          }
		      break;

		case IFX_VMAPI_TBR6_TEST:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= *((char8 *)pvOldObj);
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
				break;
				
       case IFX_VMAPI_DECT_DIAGNOSTICS:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= *((char8 *)pvOldObj);
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
			 break;
    
    case IFX_DUMMY_TZ_CHANGE:   
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
        break;
#ifdef CVOIP_SUPPORT
		case  IFX_VMAPI_TBR6_REQUEST: /*!< TBR6 Test */
		case  IFX_VMAPI_DECT_SYSTEM_REQUEST: /*!< Dect System */
		case  IFX_VMAPI_DECT_DIAGNOSTICS_REQUEST: /*!< Dect Diagnostics */
		case  IFX_VMAPI_TRANS_POWER_REQUEST: /*!< Transmit Power Measurement Test */
		case  IFX_VMAPI_RF_MODE_REQUEST: /*!< RF Mode Test */
		case  IFX_VMAPI_RFPI_REQUEST: /*!< RFPI */
		case  IFX_VMAPI_COUNTRY_SETTINGS_REQUEST: /*!< DECT Country */
		case  IFX_VMAPI_BMC_REG_PARAMS_REQUEST: /*!< DECT BMC */
		case  IFX_VMAPI_OSC_TRIM_REQUEST: /*!< DECT Oscillator Trimming */
		case  IFX_VMAPI_GFSK_REQUEST: /*!< DECT GFSK */
		case  IFX_VMAPI_CVOIP_SYSTEM_CAPABALITIES:
					*(acBuf) = ucInfoType;
          *(acBuf+1)= 1;
          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
		break;
	
	case IFX_VMAPI_XRAM_REQUEST:
          *(acBuf) = ucInfoType;
          *(acBuf+1)= 1;

          *(acBuf+2)= 1;
          *(acBuf+3)= 1;
          iSize = 4;
          if(pvNewObj != NULL) {
			        memcpy((acBuf+iSize),((uchar8 *)pvNewObj),
                      strlen((char8 *)pvNewObj));
              iSize = iSize + strlen((char8 *)pvNewObj);
          }
		      break;
#endif
#endif /* DECT_SUPPORT */
    }
    /*send message to registered module*/

		if(access(IFX_IPC_VMAPI_FIFO,F_OK)== -1)
    {
      mkfifo(IFX_IPC_VMAPI_FIFO,0777);
    }
    fifoFd = IFX_OS_OpenFifo((uchar8 *)IFX_IPC_VMAPI_FIFO,O_RDWR);
    if(IFX_IPC_SendMsg(fifoFd,IFX_IPC_APP_ID_VMAPI,IFX_IPC_APP_ID_APP,
                         iSize,0,acBuf)<0)
    {
      free(acBuf);
			close(fifoFd);
    	IFX_DBGA(ucVMAPIModuleId,IFX_DBG_LVL_HIGH,IFX_DBG_STR,
		  	   	"SendMsg to Fifo failed!!! \n");
      return IFX_VMAPI_FAIL;
   	}  
    free(acBuf);
		close(fifoFd);
  }
  return IFX_VMAPI_SUCCESS;
}


