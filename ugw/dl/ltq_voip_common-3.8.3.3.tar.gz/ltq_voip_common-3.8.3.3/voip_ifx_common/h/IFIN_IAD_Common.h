/*****************************************************************************
 **   FILE NAME    : IFIN_IAD_Common.h
 **   PROJECT      : All Projects
 **   MODULES      : All Modules
 **   SRC VERSION  : V1.0
 **
 **   DATE         : 14-01-2004
 **   AUTHOR       : IFIN COM Engineers
 **   DESCRIPTION  :
 **   FUNCTIONS    :
 **   COMPILER     :
 **   REFERENCE    : Coding guide lines for IFIN COM
 **   COPYRIGHT    : Infineon Technologies AG 2003 - 2004
 **
 **  Version Control Section
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
 ****************************************************************************/
#ifndef		__IFIN_SIP_TYPES_H__
#define		__IFIN_SIP_TYPES_H__


#define		IN
#define		OUT
#define		IN_OUT

#define		PUBLIC
#define		EXTERN	extern
#define		STATIC	static

#define		IFIN_SIP_NULL	NULL

#define		PRINT		printf

typedef char				char8;
typedef unsigned char		uchar8;
typedef char				int8;
typedef unsigned char		uint8;
typedef short int			int16;
typedef unsigned short int	uint16;
typedef int					int32;
typedef unsigned int		uint32;
typedef long				int64;
typedef	unsigned long int	uint64;
typedef float				float32;
typedef double				float64;
typedef void				IFIN_SIP_Void;

#endif		/* __IFIN_SIP_TYPES_H__ */
