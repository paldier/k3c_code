/******************************************************************************
 **   SRC_FILE			: IFIN_TLIB_Timelib.h
 **   PROJECT			: EasyPort/IAD, DC BANGALORE
 **   MODULES			:   
 **   SRC VERSION		: Version 1.0
 **   DATE				: 11-02-2003
 **   AUTHOR			: Bharathraj Shetty
 **   DESCRIPTION		:  
 **   FUNCTIONS			: None
 **   COMPILER			: 
 **   REFERENCE			: 
						Coding Guidelines (Easyport-VSS-COD-V1.0)
                    	Author: EasyPort Team
 **   COPYRIGHT			: Infineon Technologies AG 1999-2003
 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$     
 *****************************************************************************/

#ifndef _IFIN_TLIB_TIMLIB_H_
# define _IFIN_TLIB_TIMLIB_H_

#define IFIN_TLIB_ONE_TIME_TIMER 0
#define IFIN_TLIB_PERIODIC_TIMER 1

#define IFIN_TLIB_FAIL 0
#define IFIN_TLIB_SUCCESS 1
#define IFIN_TLIB_INVALID_TIMER_ID 2


#define TRUE 1
#define FALSE 0

typedef void (* pfnVoidFunctPtr)(void *);

typedef struct  {
	
					uint8 ucFree;
					int32 iThreadId;
					uint16 unTimerIndex;
					uint32 uiTimerValue;
					uint32 uiTimerTick;
					uint8 ucTimerType;
					pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn;
					void *pCallBackFnParm;
					uint16 unPrevIndex;
					uint16 unNextIndex;
				 }x_IFIN_TLIB_TimerInfo;
						  
x_IFIN_TLIB_TimerInfo *pxTimerList;
	
					
struct x_IFIN_TLIB_TimMgtInfo{
				x_IFIN_TLIB_TimerInfo *pxTimerList;
				uint16 unActTimLstHeadIndex;
				uint16 unFreeTimLstHeadIndex;
				uint16 unFreeTimLstTailIndex;
				uint16 unMaxNumOfTimer;
			 }vx_IFIN_TLIB_TimMgtInfo;


int8 IFIN_TLIB_TimersInit(uint16 unNumOfTimers);

int8 IFIN_TLIB_StartTimer(uint16 *punTimerId,uint32 uiTimerValue,
		uint8 ucTimerType, pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn,
	  void *pCallBackFnParm);

int32 IFIN_TLIB_StopTimer(uint16 unTimerId);

int8 IFIN_TLIB_TimersDelete(void);						

void IFIN_TLIB_InitializeTimerList(uint16 unNumOfTimers);

void IFIN_TLIB_InsertTimerIntoActList(x_IFIN_TLIB_TimerInfo *pxTempNode,
		uint32 uiTimerValue,uint8 ucTimerType,
		pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn, void *pCallBackFnParm);

int8 IFIN_TLIB_GetTimerNode(x_IFIN_TLIB_TimerInfo **pxTimerNode);

void IFIN_TLIB_InitializeTimerNode(x_IFIN_TLIB_TimerInfo *pxTimerNode,
		uint32 uiTimerValue,uint8 ucTimerType,
		pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn, void *pCallBackFnParm);

#if 1
int32 IFIN_TLIB_SetTimer(uint32 uiUsec);
#else
void IFIN_TLIB_SetTimer(uint32 uiUsec);
#endif

void IFIN_TLIB_FreeListHandler(x_IFIN_TLIB_TimerInfo *pxTempNode);

void IFIN_TLIB_CurrTimerExpiry(int signo);

uint32 IFIN_TLIB_GetCurrTime(void);

int8 IFIN_TLIB_CheckForEqualTimer(uint32 uiCurrTime);

#endif
