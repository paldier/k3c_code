/**************************************************************************
 **   FILE NAME       : ifx_kmp.h
 **   PROJECT         : KMP
 **   MODULES         : Key management Protocol 
 **   SRC VERSION     : V0.1
 **   DATE            : 08-04-2005
 **   AUTHOR          : Radvajesh.M
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS ,
 **
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_KMP_H__
#define __IFX_KMP_H__

/* Max Channels*/
#ifdef ATA
#define IFX_KMP_MAX_CHANNELS 2
#endif

#ifdef IIP
#define IFX_KMP_MAX_CHANNELS 1
#endif

/* KMP API's Repsonse code*/
typedef enum
{
  IFX_KMP_FAIL=-1,
  IFX_KMP_SUCCESS,
  IFX_KMP_INIT_SUCCESS,
  IFX_KMP_ACK_SUCCESS,
  IFX_KMP_NACK_SUCCESS,
  IFX_KMP_DB_FULL,
} e_IFX_KMP_RespCode;

typedef enum
{
 IFX_KMP_INIT_MSG=1,
 IFX_KMP_ACK_MSG,
 IFX_KMP_NACK_MSG,
 IFX_KMP_LOCAL_MSG,
 IFX_KMP_REMOTE_MSG,
} e_IFX_KMP_MsgType;

#define IFX_KMP_DEFAULT_PORT 60000


/*API to communicate with the Key Management Protocol*/

/* To Init the key managment Protocol , it shall create and
 * open Socket to communicate with remote KMP  */
EXTERN uint32 IFX_KMP_Init();

/* To close the Interface with remote KMP*/
EXTERN char8 IFX_KMP_Shut();


/* To clear the remote configuration for the session*/
EXTERN char8 IFX_KMP_CloseSession(IN uchar8 ucConId);



/* Message type to be used based on the message recived
   from locat host or remote host
   IFX_KMP_LOCAL_MSG 1
   IFX_KMP_REMOTE_MSG 2
*/

/* All Message related to KMP shall be processed by this API
 */

EXTERN char8 IFX_KMP_ProcessKMPMsg(IN void *aMsg,
                                   IN uchar8 ucMsgType,
                                   OUT uint16 *pnlocalPort,
																	 OUT char8 *pcIp);

/* Initate host Key transfer to Remote host*/
EXTERN char8 IFX_KMP_InitateKeyTransfer(IN uint16 unChannelId,
                                        IN uint32 uiSSRC,
                                        IN uint16 unLocalRtpPort,
                                        IN uchar8 *pcRemoteIpaddress,
                                        IN uint16 unRemoteRtpPort);


/*SRTP Key ManagementInterface Supporting API's  */

/* Get Crypto Context*/
EXTERN char8 IFX_KMP_GetCryptoContext(IN const uint32 uiSSRC,
                                      IN const uchar8 *pcIpaddress,
                                      IN const uint16 unPortNum,
                                      OUT x_IFX_KM_CryptoRec *pContext);

/* Trigger Rekeying */
EXTERN char8 IFX_KMP_TriggerRekey(IN const uint32 uiSSRC,
                                  IN const uchar8 *pcRemoteIpaddress,
                                  IN const uint16 unRemotePortNum);

#endif /* __IFX_KMP_H__*/
