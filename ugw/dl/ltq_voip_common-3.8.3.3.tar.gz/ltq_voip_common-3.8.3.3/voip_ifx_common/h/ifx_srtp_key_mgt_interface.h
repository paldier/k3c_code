/**************************************************************************
 **   FILE NAME       : ifx_srtp_key_mgt_interface.h
 **   PROJECT         : KM/SRTCP
 **   MODULES         : Key managment module for KM/SRTCP
 **   SRC VERSION     : V0.1
 **   DATE            : 30-08-2004
 **   AUTHOR          : Radvajesh.M
 **   DESCRIPTION     :
 **   FUNCTIONS       :
 **   COMPILER        : gcc
 **   REFERENCE       : Coding guide lines for VSS ,
 **
 **   COPYRIGHT       : Copyright � 2004 Infineon Technologies AG
 **                     St. Martin Strasse 53; 81669 M�nchen, Germany
 **                     Any use of this Software is subject to the conclusion
 **                     of a respective License Agreement.Without such a
 **                     License Agreement no rights to the Software are granted.
 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
#ifndef __IFX_SRTP_KEY_MGT_INTERFACE_H__
#define __IFX_SRTP_KEY_MGT_INTERFACE_H__

/* Constants */

/* Return Values */
#define IFX_KM_FAIL -1
#define IFX_KM_SUCCESS 0
#define IFX_KM_SEC_NDEF 1
#define IFX_KM_DUP_SSRC 2

/* IP address length in bytes*/
#define IFX_KM_MAX_IP_ADDRESS_LEN 16

/* Maximum Number of Hosts that INCA IP can Communicate*/
#define IFX_KM_MAX_HOSTS 2

/* Key management Parmeters */
#define IFX_KM_MAX_SRTP_LIFE_TIME  281474976710655LL /* 2^48-1 */
#define IFX_KM_MAX_SRTCP_LIFE_TIME  2147483647 /*2^31-1*/

#define IFX_KM_MASTER_KEY_LENGTH 32    /* 256 bits */
#define IFX_KM_MATER_SALT_LENGTH 32   /* 256 bits */

/* Maximun Master Keys that a single SRC can have so that it can be rekeyed */
/* This value is not specified by the RFC*/
#define IFX_KM_MAX_MASTER_KEYS 10

/* Enumerations */

/* Different encyrption transforms that can be used */
typedef enum
{
 IFX_KM_NULL_ENCR =0,
 /* Advanced Encription Standard Tranforms */
 /* Counter Mode */
 IFX_KM_AES_CM,
 IFX_KM_AES_ECB,
 IFX_KM_AES_CBC,
 IFX_KM_AES_CFB,
 IFX_KM_AES_OFB,

 /* DES Transforms */
 IFX_KM_DES_CM,
 IFX_KM_DES_ECB,
 IFX_KM_DES_CBC,
 IFX_KM_DES_CFB,
 IFX_KM_DES_OFB,
 
 /*3DES Transforms */
 IFX_KM_3DES_CM,
 IFX_KM_3DES_ECB,
 IFX_KM_3DES_CBC,
 IFX_KM_3DES_CFB,
 IFX_KM_3DES_OFB,
}e_IFX_KM_EncrTransf;

/* Different Authentication Transforms*/
typedef enum
{
 IFX_KM_NULL_AUTH =0,
 IFX_KM_HMAC_SHA1,
}e_IFX_KM_AuthTransf;


/* The Pseduo random function to be used for Key derivation */
typedef e_IFX_KM_EncrTransf e_IFX_KM_KeyDervFunc;

/* Forward Error Correction Parameters section 10 of RFC*/
typedef enum
{
 NONE,
 FIRST_FEC,
 FIRST_SRTP,
}e_IFX_KM_FecOrder;


/* Structures */

/* For each Master key all the below params should exist*/
typedef struct
{
 /* Master Key related parmeters */

   /* Master Key Length*/
   uint16 unMasterKeyLen;
   
   /* Master Key*/
   char8 acMasterKey[IFX_KM_MASTER_KEY_LENGTH];
   
   /* Master Salt Key length*/
   uint16 unMasterSaltLen;
  
   /* Master Salt */
   uchar8 acMasterSalt[IFX_KM_MASTER_KEY_LENGTH];

   /* n_e Session encryption Key Length */
   uint16 unSesEncrKeyLen;

   /* n_a Session Authentication Key Length*/
   uint16 unSesAuthKeyLen;

   /* n_s Session Salt Key Length*/
   uint16 unSesSaltKeyLen;

   /* Key Derivation Rate: {1,2,4,...2^24}  since its is fixed for the
    *  lifetime of the Master key section 4.3.1*/
   uint32 uiKeyDerivationRate:24; /* only 24 bit are supposed to be used */

   /*<From , To> Pair used for rekeying and identifing Master Key */
   uint64 ulFromIndex:48; /* only 48 bits are to be used */
	uint64:16;
   uint64 ulToIndex:48;   /* Only 48 bits are to be used */
   uint64:16;

   /* KM Master key counter to count the number of KM packets sent
    *  out with the same master key */
   uint64 ulSrtpMaxLifeTime;

   /* SRTCP Master key counter to count the number of KM packets sent
    *  out with the same master key */
   uint32 uiSrtcpMaxLifeTime;

   /*Master Key Identifier related parameters*/

   /* MKI ON or OFF */
   uchar8 ucMkiIndicator; /* ON =1 and OFF=0 */

   /* Length of the MKI*/
   uint16 unMkiLength; /* Value in Octent*/

   /* MKI Value identifying each Master key */
   uint32 uiMkiValue;

}x_IFX_KM_MasterKeyParam;


typedef struct
{
   /* crypto content index Parameters */
  
   /* SSRC value, it it is assume we have just one RTP stream,
     if there exists more than one RTP stream this should be a
     vector of [IFX_KM_MAX_STREAMS]
   */
   uint32 uiSsrcValue;
  
   /* Roll over counter, it is assume we have just one RTP stream,
     if there exists more than one RTP stream this should be a
     vector of [IFX_KM_MAX_STREAMS]
   */
   /* sender Roc */
   uint32 uiRoc;

   /* Sequence number */
   uint16 unSeqNumber;

   /* SRTCP Index */
   uint32 uiSrtcpIndex;
  
   /* Transport Address */
   char8 acIpaddress[IFX_KM_MAX_IP_ADDRESS_LEN];
 
   /* Port Number */
   uint16 unPort;
 
}x_IFX_KM_IndexParams;

/* Cryptographic Context Parameters*/
typedef struct
{
  /* Encryption Algorithm to be used, can hold any one of the 
	* values of e_ifx_rtp_encr_transf*/
   uchar8 ucEncrAlgo;
 
   /* Authentication Algorithm to be used, can hold any one of the
	 *  values of e_ifx_rtp_auth_transf*/
   uchar8 ucAuthAlgo;

   /* Authentication Tag Length*/
   uint16 unAuthTagLen;

   /* KM PREFIX_LENGTH*/
   uint16 unSrtpPrefixLen;

   /*KM Pseudo Random Function, can hold any one of the
	 *  values of e_IFX_RTP_KeyDervFunc */
   uchar8 ucPseudoRandomFunc;

   /*Masterkey or TGK  Related parameters or the information
	 *  obtained in the MIKEY payload KEMAC */
   x_IFX_KM_MasterKeyParam xMasterCryptoParam[IFX_KM_MAX_MASTER_KEYS];
 
   /* Parameters that are partialy obtained by the Key mangement 
	 * MIKEY payload KM ID*/
   /* Parametrs that are obtained are SSRCi, ROCi  were i is the session ID */
   x_IFX_KM_IndexParams  xCryptoIndexParam;

   /* Relation to other RTP Profiles*/
   /*Forward Error Correction  Order can Take any one of the 
	 * values of e_IFX_RTP_FecOrder*/
   /* if FIRST_FEC then FEC processing has to be performed  
	 * prior KM on sender side
    * and KM processing before FEC at the reciveing side
    */
   uchar8 ucFecOder;
  
}x_IFX_KM_CryptoContext;

/*Crypto context record to be returned when queried by srtp*/
typedef struct
{
      x_IFX_KM_CryptoContext xSrtp;
      x_IFX_KM_CryptoContext xSrtcp;
}x_IFX_KM_CryptoRec;

#endif /* __IFX_SRTP_KEY_MGT_INTERFACE_H__*/
