#ifdef ULE_SUPPORT
#ifndef __IFX_ULE_DEFS_H__
#define __IFX_ULE_DEFS_H__
typedef enum 
{
	e_IFX_ULE_PAGE=1,
	e_IFX_ULE_BPAGE=2,
	e_IFX_ULE_SEND_MSG=3,
	e_IFX_ULE_SUBSC_CHG=4,
	e_IFX_ULE_CONFIG=5,
	e_IFX_ULE_UNREG=6
}e_IFX_WebMsgId;
typedef struct
{
	e_IFX_WebMsgId eMsgId;
	unsigned char ucInstance;
	char acData[1501];	
}x_IFX_ULE_IPC_Msg;

#endif
#endif
