/******************************************************************************
 **  SRC_FILE			: IFIN_TLIB_Timelib.c
 **   PROJECT			: EasyPort/IAD, DC BANGALORE
 **   MODULES				:
 **   SRC VERSION		: Version 1.0
 **   DATE				: 11-02-2003
 **   AUTHOR			: Bharathraj Shetty
 **   DESCRIPTION		:  
 **   FUNCTIONS			: None
 **   COMPILER			: 
 **   REFERENCE			: 
						Coding Guidelines (Easyport-VSS-COD-V2.0)
                    	Author: EasyPort Team
 **   COPYRIGHT			: Infineon Technologies AG 1999-2003
 **  Version Control Section  **        
 **   $Author$    
 **   $Date$      
 **   $Revisions$ 
 **   $Log$     
 *****************************************************************************/
#ifdef __LINUX__
#include <sys/time.h>
#include <sys/times.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
#else
#include <windows.h>
#include <time.h>
#endif
#include <stdio.h>
#include <stdlib.h>


#include "IFIN_IAD_Common.h"
#include "IFIN_TLIB_Timlib.h"

#ifdef __LINUX__
pthread_mutex_t global_timer_mutex = PTHREAD_MUTEX_INITIALIZER;
#else
LPCTSTR strMutex = "MUTEX LOCK";
HANDLE global_timer_mutex;
#endif
  						
/*****************************************************************************
*  Name: IFIN_TLIB_TimerInit
*  Function: This routine is initializes timer data structure
*  Input: unNumOfTimers
*  Output: None
*  Return Value: INT16 returns success or fail.
******************************************************************************/						
int8 IFIN_TLIB_TimersInit(uint16 unNumOfTimers)
{
#if __LINUX__
	struct sigaction act, oact;

	/* Call the signal catching function */		
	act.sa_handler = IFIN_TLIB_CurrTimerExpiry;
	sigemptyset(&act.sa_mask);
	act.sa_flags = 0;
	act.sa_flags |= SA_RESTART;
	sigaction(SIGALRM,&act,&oact);
#else
    //global_timer_mutex = CreateMutex(NULL,TRUE,strMutex);
	global_timer_mutex = CreateMutex(NULL,FALSE,strMutex);
#endif
	
	vx_IFIN_TLIB_TimMgtInfo.unMaxNumOfTimer = unNumOfTimers;
	
	/* Allocate memory for the Timer node data structure,
	here the number of timer nodes = Num of timers  */
	if((vx_IFIN_TLIB_TimMgtInfo.pxTimerList =
		 (x_IFIN_TLIB_TimerInfo *)malloc(unNumOfTimers * 
		 (sizeof(x_IFIN_TLIB_TimerInfo)))) != NULL)
	{
		/* Initialize the free timer list */
		IFIN_TLIB_InitializeTimerList(unNumOfTimers);
		
		/* Initialize the active list header to zero */
		vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex = 0;	
		
		return IFIN_TLIB_SUCCESS;
	}
	else
	{
		return IFIN_TLIB_FAIL;
	}

}

/******************************************************************************
*  Name: IFIN_TLIB_InitlializeTimerList
*  Function: This routine is initializes all Timer nodes in a free timer list
*  Input: unNumOfTimers
*  Output: None
*  Return Value: None
******************************************************************************/	
void IFIN_TLIB_InitializeTimerList(uint16 unNumOfTimers)
{
	uint16 unIi;
	
	
	for(unIi=1;unIi<=unNumOfTimers;unIi++)
	{
		vx_IFIN_TLIB_TimMgtInfo.pxTimerList[unIi-1].ucFree = TRUE;
		vx_IFIN_TLIB_TimMgtInfo.pxTimerList[unIi-1].unTimerIndex = unIi;
		vx_IFIN_TLIB_TimMgtInfo.pxTimerList[unIi-1].unPrevIndex = unIi-1;
		if(unIi == unNumOfTimers)
		{
			vx_IFIN_TLIB_TimMgtInfo.pxTimerList[unIi-1].unNextIndex = 0;
			vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstTailIndex =
					vx_IFIN_TLIB_TimMgtInfo.pxTimerList[unIi-1].unTimerIndex;
				
		}
		else
		{
			vx_IFIN_TLIB_TimMgtInfo.pxTimerList[unIi-1].unNextIndex = unIi+1;
		}
	
	}
	vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstHeadIndex =
			vx_IFIN_TLIB_TimMgtInfo.pxTimerList[0].unTimerIndex;

	return;
}

/******************************************************************************
*  Name: IFIN_TLIB_StartTimer
*  Function: This routine starts the timer.
*  Input: uiTimerValue,ucTimerType, pfn_IFIN_TLIB_CallBackfn, pCallBackFnParm
*  Output: punTimerId
*  Return Value: None
******************************************************************************/
int8 IFIN_TLIB_StartTimer(uint16 *punTimerId,uint32 uiTimerValue,
						uint8 ucTimerType, pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn,
						void *pCallBackFnParm)
{
	x_IFIN_TLIB_TimerInfo *pxTempNode = NULL;	

	if(uiTimerValue == 0)
	{
		return IFIN_TLIB_FAIL;
	}

#ifdef __LINUX__	
	pthread_mutex_lock(&global_timer_mutex);
#else
	WaitForSingleObject(global_timer_mutex,INFINITE);
#endif
	/* Get the fresh node from free list of timers */
	if(IFIN_TLIB_GetTimerNode(&pxTempNode) != IFIN_TLIB_FAIL)
	{
		*punTimerId = pxTempNode->unTimerIndex;

		/* Insert new node in an appropriate position in active list */
		IFIN_TLIB_InsertTimerIntoActList(pxTempNode,uiTimerValue,ucTimerType,
				pfn_IFIN_TLIB_CallBackfn,pCallBackFnParm);
#ifdef __LINUX__
		pthread_mutex_unlock(&global_timer_mutex);
#else
		ReleaseMutex(global_timer_mutex);
#endif

		return IFIN_TLIB_SUCCESS;
	}
	else
	{
#ifdef __LINUX__
		pthread_mutex_unlock(&global_timer_mutex);
#else
		ReleaseMutex(global_timer_mutex);
#endif
		return IFIN_TLIB_FAIL;
	}
}

/*****************************************************************************
*  Name: IFIN_TLIB_InsertTimerIntoActList
*  Function: This routine inserts the timer into active list of timers
*  Input: pxTempNode,uiTimerValue,ucTimerType, pfn_IFIN_TLIB_CallBackfn,
					pCallBackFnParm
*  Output:None
*  Return Value: success or fail.
******************************************************************************/
					 
void IFIN_TLIB_InsertTimerIntoActList(x_IFIN_TLIB_TimerInfo *pxTempNode,
			uint32 uiTimerValue,uint8 ucTimerType,
			pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn, void *pCallBackFnParm)

{

	x_IFIN_TLIB_TimerInfo *pxTempNextNode,*pxTempActLstNode;
	uint32 uiTimeElapse,uiTempTimeElapse,uiTimeLeft,uiNextTimeLeft,uiCurrTick;

	/* Initialize the new timer node */	
	IFIN_TLIB_InitializeTimerNode(pxTempNode,uiTimerValue,ucTimerType,
			pfn_IFIN_TLIB_CallBackfn,pCallBackFnParm);
		
	/* CLOCKT_CurrTick is number of milliseconds expired since
				system is started */
	uiCurrTick = IFIN_TLIB_GetCurrTime();
		
	/* The active list is empty */
	if(vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex == 0)
	{
		vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex = pxTempNode->unTimerIndex;
		pxTempActLstNode = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
					(vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex - 1);		

		pxTempActLstNode->uiTimerTick = uiCurrTick;
		pxTempActLstNode->unPrevIndex = 0;
		pxTempActLstNode->unNextIndex = 0;
		/*Start the Timer */
#if 1
        pxTempActLstNode->iThreadId = IFIN_TLIB_SetTimer(uiTimerValue);
#else
		IFIN_TLIB_SetTimer(uiTimerValue);
#endif
					
	}
	else
	{
		pxTempActLstNode = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
					(vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex - 1);		
			
		uiTimeElapse = (uiCurrTick - pxTempActLstNode->uiTimerTick);//*10000;
			
		/* Check whether timer in an active list is already elapsed or not */
		if(pxTempActLstNode->uiTimerValue > uiTimeElapse)
		{
			uiTimeLeft = pxTempActLstNode->uiTimerValue - uiTimeElapse;
		}
		else
		{
    	uiTimeLeft = 0;
		}
			
		/*Insert timer at the beginning of active list */
		if(uiTimerValue < uiTimeLeft)
		{
					
			/* Store the Timer tick at creation of timer node */
			pxTempNode->uiTimerTick = uiCurrTick;
			/*adjust the prev index * next index for 1st and 2nd nodes */
			pxTempNode->unPrevIndex = 0;
			pxTempNode->unNextIndex = pxTempActLstNode->unTimerIndex;
			pxTempActLstNode->unPrevIndex = pxTempNode->unTimerIndex;
			/* Time elapse for the 2nd node = Time Elapse for 2nd node +
						 Timervalue of 1st node */
			pxTempActLstNode = pxTempNode;
			/* The active timer list header points to first node */
				
			vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex =
						pxTempActLstNode->unTimerIndex;
#if 1
            pxTempActLstNode->iThreadId = IFIN_TLIB_SetTimer(uiTimerValue);
#else
			IFIN_TLIB_SetTimer(uiTimerValue);
#endif
					
		}
		else
		{

			/*Traverse the Active list of timers to insert the list in
						an appropriate position */
			while(pxTempActLstNode != NULL)
			{

				/* Add at the end of list */
				if(pxTempActLstNode->unNextIndex == 0)
				{

					/* Store the Timer tick at creation of timer node */
					pxTempNode->uiTimerTick = uiCurrTick;

					pxTempActLstNode->unNextIndex = pxTempNode->unTimerIndex;
					pxTempNode->unPrevIndex = pxTempActLstNode->unTimerIndex;
					pxTempNode->unNextIndex = 0;
			
					break;
				}
				else
				{

					pxTempNextNode = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
						(pxTempActLstNode->unNextIndex - 1);
					uiTempTimeElapse = (uiCurrTick - pxTempNextNode->uiTimerTick);//*10000;
						
					/* Check whether next timer in an active list
							is already elapsed or not*/
					if(pxTempNextNode->uiTimerValue > uiTempTimeElapse)
					{
						uiNextTimeLeft = pxTempNextNode->uiTimerValue - uiTempTimeElapse;
					}
					else
					{
						uiNextTimeLeft = 0;
					}

					/*Insert timer at the Middle of active list */
					if((uiTimerValue >= uiTimeLeft) && (uiTimerValue < uiNextTimeLeft))
					{
							
						/* Store the Timer tick at creation of timer node */
						pxTempNode->uiTimerTick = uiCurrTick;

						pxTempActLstNode->unNextIndex = pxTempNode->unTimerIndex;
						pxTempNode->unPrevIndex = pxTempActLstNode->unTimerIndex;
						pxTempNode->unNextIndex = pxTempNextNode->unTimerIndex;
						pxTempNextNode->unPrevIndex = pxTempNode->unTimerIndex;
						break;

					}
					/*Traverse to next node in an active list */
					else
					{
						/* Go to next node */
						pxTempActLstNode=pxTempNextNode;
						/* Time elapse and time left of next node becomes current node */
						uiTimeElapse = uiTempTimeElapse;
						uiTimeLeft = uiNextTimeLeft;
					}
				}
			}
		}

	}
}

/****************************************************************************
*  Name: IFIN_TLIB_GetTimerNode
*  Function: This node gets the fresh node from the Free list of timers
*  Input: pxTimerNode
*  Output:pxTimerNode
*  Return Value: either success or fail. 
*****************************************************************************/

int8 IFIN_TLIB_GetTimerNode(x_IFIN_TLIB_TimerInfo **pxTimerNode)
{
	uint16 unTempFreeTimLstHeadIndex;
	/* If the Free list of timers is not NULL */
	if((vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstHeadIndex != 0) &&
		 (vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstTailIndex != 0))
	{
		unTempFreeTimLstHeadIndex=vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstHeadIndex-1;
		/* Attach free node to pxTimerNode */
		*pxTimerNode = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
					unTempFreeTimLstHeadIndex;

		(*pxTimerNode)->ucFree = FALSE;
		
		
		/*Update free list */
		if(vx_IFIN_TLIB_TimMgtInfo.pxTimerList  
			[unTempFreeTimLstHeadIndex].unNextIndex != 0)
		{
			vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstHeadIndex = vx_IFIN_TLIB_TimMgtInfo 
						.pxTimerList[unTempFreeTimLstHeadIndex].unNextIndex;

			vx_IFIN_TLIB_TimMgtInfo.pxTimerList
				[vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstHeadIndex-1].unPrevIndex = 0;
		}
		else
		{
			vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstHeadIndex = 0;
			vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstTailIndex = 0;
		}
		return IFIN_TLIB_SUCCESS;
	}
	else
	{
		/* return fail for out of memory  */
		return IFIN_TLIB_FAIL;
	}

}

/*************************************************************************
*  Name: IFIN_TLIB_InitializeTimerNode
*  Function: This function initializes the Timer Node
*  Input: pxTimerNode,uiTimerValue,ucTimerType, pfn_IFIN_TLIB_CallBackfn,
					pCallBackFnParm
*  Output:None
*  Return Value: none. 
**************************************************************************/
void IFIN_TLIB_InitializeTimerNode(x_IFIN_TLIB_TimerInfo *pxTimerNode,
			uint32 uiTimerValue,uint8 ucTimerType,
			pfnVoidFunctPtr pfn_IFIN_TLIB_CallBackfn, void *pCallBackFnParm)

{
	/* Set the Timer node fields */
	pxTimerNode->uiTimerValue = uiTimerValue;
	pxTimerNode->ucTimerType = ucTimerType;
	pxTimerNode->pfn_IFIN_TLIB_CallBackfn = pfn_IFIN_TLIB_CallBackfn;
	pxTimerNode->pCallBackFnParm = pCallBackFnParm;
	
}

/****************************************************************************
*  Name: IFIN_TLIB_StopTimer
*  Function: This functions stops the timer
*  Input: unTimerId
*  Output:None
*  Return Value: success or fail. 
*****************************************************************************/
int32 IFIN_TLIB_StopTimer(uint16 unTimerId)
{
	x_IFIN_TLIB_TimerInfo *pxTempNode,*pxPrevTempNode,*pxNextTempNode;
	clock_t CLOCKT_CurrTick;
	uint32 uiTimeLeft;

	/* Check for valid timer id */ 	
	if((unTimerId <= 0) || (unTimerId > vx_IFIN_TLIB_TimMgtInfo.unMaxNumOfTimer))
	{
		return IFIN_TLIB_INVALID_TIMER_ID;

	}

#ifdef __LINUX__
	pthread_mutex_lock(&global_timer_mutex);
#else
	WaitForSingleObject(global_timer_mutex,INFINITE);
#endif
	
	pxTempNode = vx_IFIN_TLIB_TimMgtInfo.pxTimerList + (unTimerId - 1);
	
	/* Check whether node is already freed */
	if(pxTempNode->ucFree == FALSE)
	{

		CLOCKT_CurrTick = IFIN_TLIB_GetCurrTime();
    /*Return Time left */
		uiTimeLeft = (CLOCKT_CurrTick - pxTempNode->uiTimerTick);//*10000;
		if(uiTimeLeft > pxTempNode->uiTimerValue)
		{
			uiTimeLeft = 0;
		}
		else
		{
				uiTimeLeft = pxTempNode->uiTimerValue - uiTimeLeft;
		}
		
		/*Delete the node from beginning of active list */
		if(pxTempNode->unPrevIndex == 0)
		{
			/*Only one node in the active timer list */
			if(pxTempNode->unNextIndex == 0)
			{
				vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex = 0;
				/*Stop the timer */
#if 1
                TerminateThread(pxTempNode->iThreadId,0);
#else
			    IFIN_TLIB_SetTimer(0);
#endif
				
			}
			/* Delete from the beginning of a list */
			else
			{
				
				vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex = pxTempNode->unNextIndex;
				pxNextTempNode = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
					(vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex - 1);

				pxNextTempNode->unPrevIndex = 0;
				CLOCKT_CurrTick = (CLOCKT_CurrTick-pxNextTempNode->uiTimerTick);//*10000;
				if(pxNextTempNode->uiTimerValue > CLOCKT_CurrTick)
				{
#if 1
                    pxNextTempNode->iThreadId = IFIN_TLIB_SetTimer(pxNextTempNode->uiTimerValue -CLOCKT_CurrTick);
#else
					IFIN_TLIB_SetTimer(pxNextTempNode->uiTimerValue -CLOCKT_CurrTick);
#endif
				}
			}

		}
		else
		{
			pxPrevTempNode = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
					(pxTempNode->unPrevIndex - 1);

			/* Delete the node from end of list */
			if(pxTempNode->unNextIndex == 0)
			{
				pxPrevTempNode->unNextIndex = 0;
			}
			/* Delete from the middle of a list */
			else

			{
				pxNextTempNode = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
						(pxTempNode->unNextIndex - 1);
				pxPrevTempNode->unNextIndex = pxNextTempNode->unTimerIndex;
				pxNextTempNode->unPrevIndex = pxPrevTempNode->unTimerIndex;

			}
			
		}
		
		
		/* Free the timer of active list and add it to free list of timers */
#if 1
        if(pxTempNode->iThreadId != 0){
		  TerminateThread(pxTempNode->iThreadId,0);
		}
		pxTempNode->iThreadId=0;
#endif
		IFIN_TLIB_FreeListHandler(pxTempNode);

#ifdef __LINUX__
		pthread_mutex_unlock(&global_timer_mutex);
#else
		ReleaseMutex(global_timer_mutex);
#endif

		return uiTimeLeft;
	}
	else
	{
#ifdef __LINUX__
		pthread_mutex_unlock(&global_timer_mutex);
#else
		ReleaseMutex(global_timer_mutex);
#endif

		return IFIN_TLIB_FAIL;
	}

	
}

/******************************************************************************
*  Name: CurrTimerExpiry
*  Function: This function is called when timer has been expired
*  Input: None
*  Output:None
*  Return Value: none. 
******************************************************************************/

void IFIN_TLIB_CurrTimerExpiry(int signo)
{
	x_IFIN_TLIB_TimerInfo *pxTempNode,*pxTempActTimLstHead;
	uint32 uiGetCurrTime;
  clock_t CLOCKT_TimeDiff;

	/* Get the current timer tick */
	uiGetCurrTime = IFIN_TLIB_GetCurrTime();
		
#ifdef __LINUX__
	pthread_mutex_lock(&global_timer_mutex);
#else
	WaitForSingleObject(global_timer_mutex,INFINITE);
#endif
		
	if(vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex != 0)
	{

		pxTempActTimLstHead = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
				(vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex - 1);

		CLOCKT_TimeDiff = (uiGetCurrTime - pxTempActTimLstHead->uiTimerTick);//*10000;
			
		if(CLOCKT_TimeDiff >= pxTempActTimLstHead->uiTimerValue)
		{	
			pxTempNode = pxTempActTimLstHead;
	
			if(pxTempNode->unNextIndex == 0)
			{
				vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex = 0;
			
				/* Noitfy timer expiry to the corresponding process */
				pxTempNode->pfn_IFIN_TLIB_CallBackfn(pxTempNode->pCallBackFnParm);

				/* if the timer is periodic then restart it */	
				if(pxTempNode->ucTimerType == IFIN_TLIB_PERIODIC_TIMER)
			 	{
					pxTempNode->uiTimerTick = uiGetCurrTime;
					IFIN_TLIB_InsertTimerIntoActList(pxTempNode,pxTempNode->uiTimerValue,
						pxTempNode->ucTimerType, pxTempNode->pfn_IFIN_TLIB_CallBackfn,
						pxTempNode->pCallBackFnParm);
				}
				else
				{

					/* Free the timer from active list and add it to
						 free list of timers */
					IFIN_TLIB_FreeListHandler(pxTempNode);
				}
			}
			else
			{
				IFIN_TLIB_CheckForEqualTimer(uiGetCurrTime);

			}
		}
	}

#ifdef __LINUX__
		pthread_mutex_unlock(&global_timer_mutex);
#else
		ReleaseMutex(global_timer_mutex);
#endif


}

/******************************************************************************
*  Name: IFIN_TLIB_FreeListHandler
*  Function: This function adds released timer node at the end of
						 free list of timers
*  Input: pxTempNode
*  Output:None
*  Return Value: none. 
******************************************************************************/
void IFIN_TLIB_FreeListHandler(x_IFIN_TLIB_TimerInfo *pxTempNode)
{
	/*Reinitialize all fields in timer node */
	pxTempNode->ucFree = TRUE;
	pxTempNode->uiTimerValue = 0;
	pxTempNode->uiTimerTick = 0;
	pxTempNode->ucTimerType = 0;
	pxTempNode->pfn_IFIN_TLIB_CallBackfn = NULL;
	pxTempNode->pCallBackFnParm = NULL;
	pxTempNode->unNextIndex = 0;

	/* If the Free list is empty */
	if((vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstHeadIndex == 0) &&
		 (vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstHeadIndex == 0))
	{
		pxTempNode->unPrevIndex = 0;
		vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstHeadIndex = pxTempNode->unTimerIndex;
	}
	else
	{
		vx_IFIN_TLIB_TimMgtInfo.pxTimerList[vx_IFIN_TLIB_TimMgtInfo. 
				unFreeTimLstTailIndex-1].unNextIndex = pxTempNode->unTimerIndex;
		pxTempNode->unPrevIndex = vx_IFIN_TLIB_TimMgtInfo. 
			pxTimerList[vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstTailIndex-1]. 
								unTimerIndex;
	}
	/*Tail of free list should point to last node in a list */
	vx_IFIN_TLIB_TimMgtInfo.unFreeTimLstTailIndex = pxTempNode->unTimerIndex;
	
	return;

}

myfunc(uint32 uiUsec)
{
  MSG msg;
  SetTimer(0,0,uiUsec,(TIMERPROC)IFIN_TLIB_CurrTimerExpiry);
  for(;;){
	  if(GetMessage(&msg,0,0,0)){
		  if(msg.message == WM_TIMER){
            DispatchMessage(&msg);
			break;
		  }
	  }
  }
}

/***************************************************************************
*  Name: IFIN_TLIB_SetTimer
*  Function: This function starts the timer
*  Input: uiUsec
*  Output:None
*  Return Value: none. 
****************************************************************************/
#if 1
int32 IFIN_TLIB_SetTimer(uint32 uiUsec)
#else
void IFIN_TLIB_SetTimer(uint32 uiUsec)
#endif
{
#ifdef __LINUX__
	struct itimerval nval,oval;
	sigset_t newmask,oldmask;

 	nval.it_interval.tv_sec =0 ;
	nval.it_interval.tv_usec =0;		

	nval.it_value.tv_sec =0;
	nval.it_value.tv_usec = uiUsec;
	
	sigemptyset(&newmask);
	sigaddset(&newmask,SIGALRM);
	sigprocmask(SIG_BLOCK,&newmask,&oldmask);

	/*Set the Timer */
	setitimer(ITIMER_REAL, &nval, &oval);

	sigprocmask(SIG_SETMASK,&oldmask,NULL);
#else
	return CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)myfunc,uiUsec,0,NULL);	
#endif
}

/****************************************************************************
*  Name: IFIN_TLIB_TimersDelete
*  Function: This function deletes the memory allocated for timers
*  Output:None
*  Return Value: none. 
*****************************************************************************/
int8 IFIN_TLIB_TimersDelete(void)
{
	free(vx_IFIN_TLIB_TimMgtInfo.pxTimerList);
	return IFIN_TLIB_SUCCESS;
}

/****************************************************************************
*  Name: GetCurrTime
*  Function: This function gets the current tick since system has been started
*  Input : None
*  Output:None
*  Return Value: Current Tick
******************************************************************************/
uint32 IFIN_TLIB_GetCurrTime(void)
{
	clock_t CLOCKT_Time;
#ifdef __LINUX__
	CLOCKT_Time = times(NULL);
#else
	CLOCKT_Time = GetTickCount();
#endif
	return ((uint32)CLOCKT_Time);
}

/*****************************************************************************
*  Name: IFIN_TLIB_CheckForEqualTimer
*  Function: This function gets the current tick since system has been started
*  Input : uiCurrTime
*  Output:None
*  Return Value: success or fail.
******************************************************************************/
int8 IFIN_TLIB_CheckForEqualTimer(uint32 uiCurrTime)
{
	x_IFIN_TLIB_TimerInfo *pxTempNode,*pxTempActTimLstHead;
	uint32 uiCurrTimerValue,uiTimeDelay;	
	
	pxTempNode = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
				(vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex - 1);
	
	while(pxTempNode->unNextIndex != 0)
	{
		
		/* Noitfy timer expiry to the corresponding process */
		pxTempNode->pfn_IFIN_TLIB_CallBackfn(pxTempNode->pCallBackFnParm);

		vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex = pxTempNode->unNextIndex;
		pxTempActTimLstHead = vx_IFIN_TLIB_TimMgtInfo.pxTimerList +
				(vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex - 1);
		pxTempActTimLstHead->unPrevIndex = 0;

		
		/*Calculate Time elapsed for the next node */
		uiTimeDelay = (uiCurrTime - pxTempActTimLstHead->uiTimerTick);// * 10000;
		
		/*Check next timer also been elapsed */
		if(pxTempActTimLstHead->uiTimerValue > uiTimeDelay)
		{
			uiCurrTimerValue = pxTempActTimLstHead->uiTimerValue - uiTimeDelay ;
		}
		else
		{
			uiCurrTimerValue = 0;
		}
		
		/* Checking for threshold of 1ms */
		if (uiCurrTimerValue > 1000) 
		{
#if 1
            pxTempNode->iThreadId = IFIN_TLIB_SetTimer(uiCurrTimerValue);
#else
			IFIN_TLIB_SetTimer(uiCurrTimerValue);
#endif		    	
			/* if the timer is periodic then restart it */			
			if(pxTempNode->ucTimerType == IFIN_TLIB_PERIODIC_TIMER)
		 	{
				pxTempNode->uiTimerTick = uiCurrTime;
				IFIN_TLIB_InsertTimerIntoActList(pxTempNode,pxTempNode->uiTimerValue,
						pxTempNode->ucTimerType, pxTempNode->pfn_IFIN_TLIB_CallBackfn,
						pxTempNode->pCallBackFnParm);
			}
			/* Free the timer from active list and add it to free list of timers */
			else
			{
			
				IFIN_TLIB_FreeListHandler(pxTempNode);
			}

			
			break;
		}
		/* The next timer also been elapsed , so release that timer */
	  /* if the timer is periodic then restart it */
		if(pxTempNode->ucTimerType == IFIN_TLIB_PERIODIC_TIMER)
		{
			pxTempNode->uiTimerTick = uiCurrTime;
			IFIN_TLIB_InsertTimerIntoActList(pxTempNode,pxTempNode->uiTimerValue,
						pxTempNode->ucTimerType, pxTempNode->pfn_IFIN_TLIB_CallBackfn,
					  pxTempNode->pCallBackFnParm);
		}
		/* Free the timer from active list and add it to free list of timers */
		else
		{
			
			IFIN_TLIB_FreeListHandler(pxTempNode);
		}

		pxTempNode = pxTempActTimLstHead;

		/* The last node in the active list of timer */
		if(pxTempActTimLstHead->unNextIndex == 0)
		{
			vx_IFIN_TLIB_TimMgtInfo.unActTimLstHeadIndex = 0;
			
			/* Noitfy timer expiry to the corresponding process */
		
			pxTempNode->pfn_IFIN_TLIB_CallBackfn(pxTempNode->pCallBackFnParm);
			/* if the timer is periodic then restart it */
			if(pxTempNode->ucTimerType == IFIN_TLIB_PERIODIC_TIMER)
		 	{
				pxTempNode->uiTimerTick = uiCurrTime;
				IFIN_TLIB_InsertTimerIntoActList(pxTempNode,pxTempNode->uiTimerValue,
						pxTempNode->ucTimerType, pxTempNode->pfn_IFIN_TLIB_CallBackfn,
					  pxTempNode->pCallBackFnParm);
			}
			/* Free the timer from active list and add it to free list of timers */
			else
			{
			
				IFIN_TLIB_FreeListHandler(pxTempNode);
			}
			break;
		}
		
	}


	return IFIN_TLIB_SUCCESS;
}

