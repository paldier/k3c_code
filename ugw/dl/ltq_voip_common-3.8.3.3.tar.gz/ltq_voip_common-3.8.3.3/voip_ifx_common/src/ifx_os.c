/**************************************************************************
 **   FILE NAME		: ifx_os.c
 **   PROJECT			:
 **   MODULES	      : OS Interface for all IFX modules
 **   SRC VERSION		: V1.0
 **
 **   DATE				: 2-11-2004
 **   AUTHOR			: Hari
 **   DESCRIPTION		:	
 **   FUNCTIONS		:	
 **   COMPILER			:
 **   REFERENCE		:
 **							
 **   COPYRIGHT		: Infineon Technologies AG 2003-2004

 **  Version Control Section  **
 **   $Author$
 **   $Date$
 **   $Revisions$
 **   $Log$       Revision history
***********************************************************************/
/* All Standard Header files included in ifx_os.h */
#include <unistd.h>
//#include <sys/types.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <asm/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/time.h>
#include <time.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <pthread.h>
#include <sys/time.h>
#include <time.h>

#include "ifx_common_defs.h"
#include "ifx_debug.h"
#include "ifx_os.h"

#define IFX_OS_FIFO_PERM 0666

#define IFX_OS_MX_BUFF 100
#define IFX_OS_IP_SIZE 20
#define IFX_SUCCESS 0

uchar8 vcOsModId = 0;


/******************************************************************
 *  Function Name    : IFX_OS_Init
 *  Description      : This function Initialises the OS Interface
 *  Input Values     : None
 *  Output Values    : None
 *  Return Value     : None
 *  Notes            :
 ******************************************************************/
PUBLIC void 
IFX_OS_Init(void)
{  
   char8 * pcDbgExportStr;
   char8 * pcDbgTypeStr;
   uchar8 ucDbgLvl = IFX_DBG_LVL_NONE;
   uchar8 ucDbgType = IFX_DBG_TYPE_NONE;
   char8 cRet = -1;

   /*Init the Debug Libray*/   
   pcDbgExportStr = getenv("OS_IFX_DBG_LVL");

   if (pcDbgExportStr)
   {
      if (!strcmp(pcDbgExportStr, "IFX_DBG_LVL_HIGH"))
      {
         ucDbgLvl = IFX_DBG_LVL_HIGH;
      }
      else if (!strcmp(pcDbgExportStr, "IFX_DBG_LVL_NORMAL"))
      {
         ucDbgLvl = IFX_DBG_LVL_NORMAL;
      }
      else if (!strcmp(pcDbgExportStr, "IFX_DBG_LVL_LOW"))
      {
         ucDbgLvl = IFX_DBG_LVL_LOW;
      }
      else if (!strcmp(pcDbgExportStr, "IFX_DBG_LVL_ERROR"))
      {
         ucDbgLvl = IFX_DBG_LVL_ERROR;
      }
   }
   pcDbgTypeStr = getenv("OS_IFX_DBG_TYPE");
   if (pcDbgTypeStr)
   {
      if (!strcmp(pcDbgTypeStr, "CONSOLE"))
      {
         ucDbgType = IFX_DBG_TYPE_CONSOLE;
      }
      if (!strcmp(pcDbgTypeStr, "FILE"))
      {
         ucDbgType = IFX_DBG_TYPE_FILE;
      }
   }
#ifndef TEST
   ucDbgType = IFX_DBG_TYPE_CONSOLE;
   ucDbgLvl = IFX_DBG_LVL_HIGH;
#endif
   IFX_DBG_Init("OS", ucDbgType, ucDbgLvl, &vcOsModId, &cRet);
   if (cRet != IFX_SUCCESS)
   {
      printf("Error Registering with IFX_DBG Libary, exiting\n");
      return;
   }
}


/* Functions for FIFO Operations */

/* The OS library doesn't provide much of debug information.
 * The upper layer applications already have debugs in place
 * for error conditions.  It will increase the number of debugs
 * if they are put in both places.
 */

/******************************************************************
 *  Function Name    : IFX_OS_CreateFifo
 *  Description      : This function creates a FIFO with a given name
 *  Input Values     : Pointer to the name of the FIFO
 *  Output Values    : None
 *  Return Value     : Descriptor to the FIFO
 *  Notes            :
 ******************************************************************/
PUBLIC int32 
IFX_OS_CreateFifo(IN uchar8 * pucName)
{
   int32 iRet = 0;
   /* Check for the existence of FIFO */
   if (access(((char8 *)pucName), F_OK) == -1)
   {
      iRet = mkfifo(((char8 *)pucName), IFX_OS_FIFO_PERM);
   }/*end of if*/
   return iRet;
}

/******************************************************************
 *  Function Name    : IFX_OS_OpenFifo
 *  Description      : This function opens a FIFO with a given name
 *                     If Fifo doesnt exist, it is created first
 *  Input Values     : Pointer to the name of the FIFO, Flags
 *  Output Values    : None
 *  Return Value     : Descriptor to the FIFO
 *  Notes            :
 ******************************************************************/
PUBLIC int32
IFX_OS_OpenFifo(IN uchar8 * pucName, IN int32 iFlags)
{
   int32 iRet = 0;
   /* Check for the existence of FIFO */
   if (access(((char8 *)pucName), F_OK) == -1)
   {
      iRet = mkfifo(((char8 *)pucName), IFX_OS_FIFO_PERM);
      if (iRet < 0)
      {
         return iRet;
      }
   }/*end of if*/
   iRet = open(((char8 *)pucName), iFlags);
   return iRet;
}


/* C Library Functions for String Operations */

/******************************************************************************
 * Function Name: IFX_OS_Memcmp
 * Description  : Compare characters in two buffers
 * Input Values : pPtr1  - Pointer to first buffer
 *                pPtr2  - Pointer to second buffer
 *                uiSize - Number of characters to copy
 * Output Values:
 * Return Value : < 0 - buf1 less than buf2
 *                0   - buf1 identical to buf2
 *                > 0 - buf1 greater than buf2
 * Notes        :
 *****************************************************************************/
PUBLIC int32 
IFX_OS_Memcmp(IN const void * pPtr1, 
              IN const void * pPtr2,
              IN uint32 uiSize)
{
   if (!uiSize) return 0;
   while ((--uiSize != 0) && (*(char8*)pPtr1 == *(char8*)pPtr2)) 
   {
      pPtr1 = (char8*)pPtr1 + 1;
      pPtr2 = (char8*)pPtr2 + 1;
   }
   return (*((uchar8*)pPtr1) - *((uchar8*)pPtr2));
}

/******************************************************************************
 * Function Name: IFX_OS_Strlen
 * Description  : Get the length of a string
 * Input Values : pcPtr  - Pointer to buffer to copy from
 * Output Values:
 * Return Value : The number of characters in string
 * Notes        : No return value is reserved to indicate an error
 *****************************************************************************/
PUBLIC int32 
IFX_OS_Strlen(IN const char8 * pcPtr)
{
   int32 iRc = -1;
   do 
   {
      iRc++;
   } while (*pcPtr++);
   return iRc;
}

/******************************************************************************
 * Macro Name   : IFX_OS_Strcpy
 * Description  : Copy a string
 * Input Values : pcSrc  - Pointer to string buffer to copy from
 * Output Values: pcDst  - Pointer to destination string buffer
 * Return Value : The number of characters in string
 * Notes        : Pointer to destination string buffer
 *****************************************************************************/
PUBLIC char8 * 
IFX_OS_Strcpy(IN char8 * pcDst, 
              IN const char8 * pcSrc)
{
   char8 * cRc = pcDst;
   do 
   {
      *pcDst = *pcSrc++;
   } while (*pcDst++);
   return cRc;
}

/* Network Routines */

/******************************************************************
 *  Function Name    : IFX_OS_CreateSocket
 *  Description      : This function Creates a TCP/UDP Socket
 *  Input Values     : Protocol Type (TCP/UDP)
 *                     Local Port
 *                     Remote Port
 *                     Remote IP Address
 *                     TCP Socket Type (Server / Client)
 *  Output Values    : None
 *  Return Value     : Socket Fd (on Success) or -1 (on Failure)
 *  Notes            :
*******************************************************************/
PUBLIC int32
IFX_OS_CreateSocket(IN uchar8 ucProtocol,
                    IN uint16 unLocalPort,
                    IN uint16 unRemotePort,
                    IN char8 * pacRemoteIpAddress,
                    IN uchar8 ucTcpSocketType)
{
   int32 iSockFd = -1, iResult = 0;
   int32 iOn = 1;
   struct sockaddr_in xLocalAddr, xRemoteAddr;

   /* Create the Socket */
   if (ucProtocol == IFX_OS_PROTOCOL_TCP)
   {
      iSockFd = socket(AF_INET, SOCK_STREAM, 0);
   }
   else if (ucProtocol == IFX_OS_PROTOCOL_UDP)
   {
      iSockFd = socket(AF_INET, SOCK_DGRAM, 0);
   }
   else
   {
      return iSockFd;
   }
   if (iSockFd < 0)
   {
      IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
                            "Error Creating Socket : Type %d", ucProtocol);
      goto Fail;
   }
   if (ucProtocol == IFX_OS_PROTOCOL_TCP)
   {
      setsockopt(iSockFd, SOL_SOCKET, SO_REUSEADDR, &iOn, sizeof(iOn));
   }

   bzero(&xLocalAddr, sizeof(xLocalAddr));
   xLocalAddr.sin_family = AF_INET;
   xLocalAddr.sin_addr.s_addr = htonl(INADDR_ANY);
   xLocalAddr.sin_port = htons(unLocalPort);

   /* Bind the Socket to the local port */
   iResult = bind(iSockFd, (struct sockaddr *) &xLocalAddr, sizeof(xLocalAddr));
   if (iResult < 0)
   {
      IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
                            "Error Binding Socket : Type %d", ucProtocol);
      goto Fail;
   }

   /* If the protocol is TCP, we need to know the type of socket.
    * Whether its a server socket or a client socket
    */
   if (ucProtocol == IFX_OS_PROTOCOL_TCP)
   {
      if (ucTcpSocketType == IFX_OS_TCP_SOCKTYPE_CLIENT)
      {
         bzero(&xRemoteAddr, sizeof(xRemoteAddr));
         xRemoteAddr.sin_family = AF_INET;
         inet_pton(AF_INET, pacRemoteIpAddress,  &xRemoteAddr.sin_addr);
         xRemoteAddr.sin_port = htons(unRemotePort);

         iResult = connect(iSockFd, (struct sockaddr *) &xRemoteAddr,
                                          sizeof(xRemoteAddr));
         if (iResult < 0)
         {
            IFX_DBGA(vcOsModId, IFX_DBG_LVL_ERROR, IFX_DBG_STR, 
                            "Error Connecting to Remote Socket");
            goto Fail;
         }
      }
      else if (ucTcpSocketType == IFX_OS_TCP_SOCKTYPE_SERVER)
      {
         listen(iSockFd, 5);
      }
   }
   return iSockFd;

Fail :
   return iSockFd;

}

/*****************************************************************************
 *  Function Name :  IFX_OS_Select
 *  Description   :  Wrapper Function for the system call select
 *  Input Values  :  Read, Write and Exception file descriptors list
 *                :  Time to block in Millisecs
 *  Output Values :  None
 *  Return Value  :  Number of Fds set (Success) / -1 (Failure
 *  Notes         :
 *****************************************************************************/
PUBLIC int32
IFX_OS_Select(IN fd_set * pRdSelectFd, 
              IN fd_set * pWrSelectFd, 
              IN fd_set * pExSelectFd,
              IN int32 iTimeSec)
{
   int32 iNoFds = 0;
   struct timeval xTv;

   if (iTimeSec != (int32)NULL)
   {
		xTv.tv_sec = iTimeSec;
		xTv.tv_usec = 0;

		iNoFds = select(FD_SETSIZE, pRdSelectFd, pWrSelectFd, pExSelectFd, &xTv);
   }
   else
   {
		iNoFds = select(FD_SETSIZE, pRdSelectFd, pWrSelectFd, pExSelectFd, NULL);
   }
   return iNoFds;
}
/*****************************************************************************
 *  Function Name :  IFX_OS_GetHostMac
 *  Description   :  Function to get the Mac address
 *  Input Values  :  Interface Name
 *  Output Values :  Pointer to Mac buffer
 *  Return Value  : 
 *  Notes         : 
 *****************************************************************************/
PUBLIC char8 
IFX_OS_GetHostMac(IN char8 *pcIntfacename, OUT char8 * pcHostMac)
{
   struct ifreq Interface;
   int iRetVal = 0, Fd=0;
   char8 * pcIfName=NULL;
   char8 acIf[16] = "";
   char8 *pcDefIf="br0";
	
	if(pcIntfacename == NULL)
	{
   		pcIfName = getenv("WAN");
	}
   if(pcIfName == NULL)
   {
		if(pcIntfacename != NULL)
		{
       		strcpy(acIf,pcIntfacename);
		}
		else
		{
       		strcpy(acIf,pcDefIf);
		}
       pcIfName = acIf;
   }
   else{
       strcpy(acIf,pcIfName);
   }
   
	Fd =  socket(PF_INET, SOCK_DGRAM, 0);
  if (Fd < 0){
      return -1;
   }
   memset(&Interface, 0, sizeof(struct ifreq));
   Interface.ifr_ifru.ifru_addr.sa_family = PF_INET;
   strcpy(Interface.ifr_ifrn.ifrn_name, acIf);
   
   iRetVal = ioctl(Fd, SIOCGIFHWADDR, &Interface); 

   if (iRetVal < 0){
		//perror("<OS_GetHostIP>Failed Reason -- ");
   	close(Fd);
		return -1;
   }
   memcpy(pcHostMac,&Interface.ifr_hwaddr.sa_data[0],6);
   close(Fd);

   return iRetVal;
}

/*****************************************************************************
 *  Function Name :  IFX_OS_GetHostIp
 *  Description   :  Function to get the local host IP Address 
 *  Input Values  :  Interface Name
 *  Output Values :  Pointer Host IP Address
 *  Return Value  : 
 *  Notes         : 
 *****************************************************************************/
PUBLIC char8 
IFX_OS_GetHostIp(OUT char8 * pcHostIp)
{
   struct ifreq Interface;
   int iRetVal = 0, Fd=0;
   struct in_addr * pAddr;
   char8 * pcIfName;
   char8 acIf[16] = {0};
   char8 *pcDefIf="br0";
	 
   pcIfName = getenv("WAN");
   if(pcIfName == NULL){
       strncpy(acIf,pcDefIf,15);
       pcIfName = acIf;
   }
   else{
       strncpy(acIf,pcIfName,15);
   }
   
	Fd =  socket(AF_INET, SOCK_DGRAM, 0);
  if (Fd < 0){
      return -1;
   }
   memset(&Interface, 0, sizeof(struct ifreq));
   Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
   strcpy(Interface.ifr_ifrn.ifrn_name, acIf);
   
   iRetVal = ioctl(Fd, SIOCGIFADDR, &Interface); 

   if (iRetVal < 0){
		//perror("<OS_GetHostIP>Failed Reason -- ");
   	close(Fd);
		return -1;
   }
   Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
   pAddr= (struct in_addr*)&Interface.ifr_ifru.ifru_addr.sa_data[2];	
   strcpy(pcHostIp, inet_ntoa(*pAddr));
   //printf("<GetHostIP> Got IP addr = %s\n",pcHostIp);
   close(Fd);

   return iRetVal;
}

/*****************************************************************************
 *  Function Name :  IFX_OS_GetHostNetmask
 *  Description   :  Function to get the local host Netmask
 *  Input Values  :  Interface Name
 *  Output Values :  Pointer Host Network Mask
 *  Return Value  :
 *  Notes         :
 *****************************************************************************/
PUBLIC char8
IFX_OS_GetHostNetmask(OUT char8 * pcHostNetmask)
{
   struct ifreq Interface;
   int iRetVal = 0, Fd;
   struct in_addr * pAddr;
   char8 * pcIfName;
#ifdef ATA
   (pcIfName = getenv("WAN"))? pcIfName : "adm1";
#endif
#ifdef IIP
   (pcIfName = getenv("WAN"))? pcIfName : "eth0";
#endif
#ifdef DANUBE
   (pcIfName = getenv("WAN"))? pcIfName : "br0";
#endif

   Fd =  socket(AF_INET, SOCK_DGRAM, 0);
   if (Fd < 0)
   {
      return -1;
   }
   memset(&Interface, 0, sizeof(struct ifreq));
   Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;

   if(pcIfName)
   {
     strncpy(Interface.ifr_ifrn.ifrn_name, pcIfName, sizeof(Interface.ifr_ifrn.ifrn_name)-1);
   }
    
   iRetVal = ioctl(Fd, SIOCGIFNETMASK, &Interface);
   close(Fd);
   if (iRetVal < 0)
   {
      return -1;
   }
   Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
   pAddr= (struct in_addr*)&Interface.ifr_ifru.ifru_addr.sa_data[2];
   strcpy(pcHostNetmask, inet_ntoa(*pAddr));
   return iRetVal;
}

/************************************************************************
 *  Function Name: IFX_OS_SetIp
 *  Description  : This function sets the IP address to a particular 
 *                 Interface 
 *  Input Values : Pointer to the IP address to be added
 *               : Interface Name
 *  Output Values: None
 *  Return Value : 0 or -1
 *  Notes		  :
 ************************************************************************/
PUBLIC int32 
IFX_OS_SetIp(IN char8 * pcIpAdd)
{
  struct ifreq Interface;
  int32 iRetVal = -1;
  int32 Fd;
  char8 * pcIfName;
#ifdef ATA
  (pcIfName = getenv("WAN"))? pcIfName : "adm1";
#endif
#ifdef IIP
   (pcIfName = getenv("WAN"))? pcIfName : "eth0";
#endif
#ifdef DANUBE
   (pcIfName = getenv("WAN"))? pcIfName : "br0";
#endif
	if (pcIfName == NULL)
		return iRetVal;
  Fd =  socket(AF_INET, SOCK_DGRAM, 0);
  if (Fd < 0)
  {
     return -1;
  }
  Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
  inet_pton(AF_INET, pcIpAdd, 
            (struct in_addr * ) &Interface.ifr_addr.sa_data[2]);
  strncpy(Interface.ifr_ifrn.ifrn_name, pcIfName,sizeof(Interface.ifr_ifrn.ifrn_name)-1);
  iRetVal = ioctl(Fd, SIOCSIFADDR, &Interface);
  close(Fd);
  return iRetVal;
}

/************************************************************************
 *  Function Name: IFX_OS_SetNetmask
 *  Description  : This function sets the Netmask to a particular
 *                 Interface 
 *  Input Values : Pointer to the Netmask to be added
 *               : Interface Name
 *  Output Values: None
 *  Return Value : 0 or -1
 *  Notes        :
 ************************************************************************/
PUBLIC int32 
IFX_OS_SetNetmask(IN char8 * pcNetmask)
{
  struct ifreq Interface;
  int32 iRetVal = -1;
  int32 Fd;
  char8 * pcIfName;
#ifdef ATA
  (pcIfName = getenv("WAN"))? pcIfName : "adm1";
#endif
#ifdef IIP
  (pcIfName = getenv("WAN"))? pcIfName : "eth0";
#endif
#ifdef DANUBE
  (pcIfName = getenv("WAN"))? pcIfName : "br0";
#endif
	if (pcIfName == NULL)
		return iRetVal;
  Fd =  socket(AF_INET, SOCK_DGRAM, 0);
  if (Fd < 0)
  {
     return -1;
  }
  Interface.ifr_ifru.ifru_addr.sa_family = AF_INET;
  inet_pton(AF_INET, pcNetmask,
            (struct in_addr * ) &Interface.ifr_addr.sa_data[2]);
  strncpy(Interface.ifr_ifrn.ifrn_name, pcIfName,sizeof(Interface.ifr_ifrn.ifrn_name)-1);
  iRetVal = ioctl(Fd, SIOCSIFNETMASK, &Interface);
  close(Fd);
  return iRetVal;
}

/******************System V Semphore operations **********/

/************************************************************************
 *  Function Name: IFX_OS_LOCK
 *  Description  : This function sets the Netmask to a particular
 *                 Interface 
 *  Input Values : Pointer to the Netmask to be added
 *               : Interface Name
 *  Output Values: None
 *  Return Value : 0 or -1
 *  Notes        :
 ************************************************************************/
/* Lock Semphore*/
PUBLIC int32 IFX_OS_LOCK(IN int32 iSemId)
{
  struct sembuf xWait ={0,-1,SEM_UNDO};
  
  return IFX_OS_SemOp(iSemId,&xWait,1);

  
}
/************************************************************************
 *  Function Name: IFX_OS_UNLOCK
 *  Description  : This function sets the Netmask to a particular
 *                 Interface 
 *  Input Values : Pointer to the Netmask to be added
 *               : Interface Name
 *  Output Values: None
 *  Return Value : 0 or -1
 *  Notes        :
 ************************************************************************/

/*Unlock Semphore*/
PUBLIC int32 IFX_OS_UNLOCK(IN int32 iSemId)
{
   struct sembuf xPost = {0,1,SEM_UNDO};
   return IFX_OS_SemOp(iSemId,&xPost,1);
       
}

/************** File Operations ****************/
/* MD5 Algorithm */
/* MD5 initialization. Begins an MD5 operation, writing a new context. */

STATIC void
MDInit(MD_CT * context)
{
  context->count[0] = context->count[1] = 0;
  /* Load magic initialization constants */

  context->state[0] = 0x67452301;
  context->state[1] = 0xefcdab89;
  context->state[2] = 0x98badcfe;
  context->state[3] = 0x10325476;
}
/* STATIC Functions */

STATIC void Encode PROTO_LIST((uchar8 *, uint32  *, uint32));
STATIC void Decode PROTO_LIST((uint32 *, uchar8 *, uint32));
STATIC void MD_memcpy (POINTER output, POINTER input,uint32 len);
STATIC void MD_memcpy PROTO_LIST ((POINTER, POINTER, uint32));
STATIC void MD_memset PROTO_LIST ((POINTER, int32, uint32));

/* STATIC Variables */

STATIC uchar8 PADDING[64] =
{
  0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};


/* MD5 basic transformation. Transforms state based on block */
STATIC void
MDTransform (uint32 * state, uchar8 * block)
{
  uint32 a = state[0], b = state[1], c = state[2], d = state[3], x[16];

  Decode (x, block, 64);

  /* Round 1 */
  FF (a, b, c, d, x[ 0], S11, 0xd76aa478); /* 1 */
  FF (d, a, b, c, x[ 1], S12, 0xe8c7b756); /* 2 */
  FF (c, d, a, b, x[ 2], S13, 0x242070db); /* 3 */
  FF (b, c, d, a, x[ 3], S14, 0xc1bdceee); /* 4 */
  FF (a, b, c, d, x[ 4], S11, 0xf57c0faf); /* 5 */
  FF (d, a, b, c, x[ 5], S12, 0x4787c62a); /* 6 */
  FF (c, d, a, b, x[ 6], S13, 0xa8304613); /* 7 */
  FF (b, c, d, a, x[ 7], S14, 0xfd469501); /* 8 */
  FF (a, b, c, d, x[ 8], S11, 0x698098d8); /* 9 */
  FF (d, a, b, c, x[ 9], S12, 0x8b44f7af); /* 10 */
  FF (c, d, a, b, x[10], S13, 0xffff5bb1); /* 11 */
  FF (b, c, d, a, x[11], S14, 0x895cd7be); /* 12 */
  FF (a, b, c, d, x[12], S11, 0x6b901122); /* 13 */
  FF (d, a, b, c, x[13], S12, 0xfd987193); /* 14 */
  FF (c, d, a, b, x[14], S13, 0xa679438e); /* 15 */
  FF (b, c, d, a, x[15], S14, 0x49b40821); /* 16 */

 /* Round 2 */
  GG (a, b, c, d, x[ 1], S21, 0xf61e2562); /* 17 */
  GG (d, a, b, c, x[ 6], S22, 0xc040b340); /* 18 */
  GG (c, d, a, b, x[11], S23, 0x265e5a51); /* 19 */
  GG (b, c, d, a, x[ 0], S24, 0xe9b6c7aa); /* 20 */
  GG (a, b, c, d, x[ 5], S21, 0xd62f105d); /* 21 */
  GG (d, a, b, c, x[10], S22,  0x2441453); /* 22 */
  GG (c, d, a, b, x[15], S23, 0xd8a1e681); /* 23 */
  GG (b, c, d, a, x[ 4], S24, 0xe7d3fbc8); /* 24 */
  GG (a, b, c, d, x[ 9], S21, 0x21e1cde6); /* 25 */
  GG (d, a, b, c, x[14], S22, 0xc33707d6); /* 26 */
  GG (c, d, a, b, x[ 3], S23, 0xf4d50d87); /* 27 */
  GG (b, c, d, a, x[ 8], S24, 0x455a14ed); /* 28 */
  GG (a, b, c, d, x[13], S21, 0xa9e3e905); /* 29 */
  GG (d, a, b, c, x[ 2], S22, 0xfcefa3f8); /* 30 */
  GG (c, d, a, b, x[ 7], S23, 0x676f02d9); /* 31 */
  GG (b, c, d, a, x[12], S24, 0x8d2a4c8a); /* 32 */

  /* Round 3 */
  HH (a, b, c, d, x[ 5], S31, 0xfffa3942); /* 33 */
  HH (d, a, b, c, x[ 8], S32, 0x8771f681); /* 34 */
  HH (c, d, a, b, x[11], S33, 0x6d9d6122); /* 35 */
  HH (b, c, d, a, x[14], S34, 0xfde5380c); /* 36 */
  HH (a, b, c, d, x[ 1], S31, 0xa4beea44); /* 37 */
  HH (d, a, b, c, x[ 4], S32, 0x4bdecfa9); /* 38 */
  HH (c, d, a, b, x[ 7], S33, 0xf6bb4b60); /* 39 */
  HH (b, c, d, a, x[10], S34, 0xbebfbc70); /* 40 */
  HH (a, b, c, d, x[13], S31, 0x289b7ec6); /* 41 */
  HH (d, a, b, c, x[ 0], S32, 0xeaa127fa); /* 42 */
  HH (c, d, a, b, x[ 3], S33, 0xd4ef3085); /* 43 */
  HH (b, c, d, a, x[ 6], S34,  0x4881d05); /* 44 */
  HH (a, b, c, d, x[ 9], S31, 0xd9d4d039); /* 45 */
  HH (d, a, b, c, x[12], S32, 0xe6db99e5); /* 46 */
  HH (c, d, a, b, x[15], S33, 0x1fa27cf8); /* 47 */
  HH (b, c, d, a, x[ 2], S34, 0xc4ac5665); /* 48 */

  /* Round 4 */
  II (a, b, c, d, x[ 0], S41, 0xf4292244); /* 49 */
  II (d, a, b, c, x[ 7], S42, 0x432aff97); /* 50 */
  II (c, d, a, b, x[14], S43, 0xab9423a7); /* 51 */
  II (b, c, d, a, x[ 5], S44, 0xfc93a039); /* 52 */
  II (a, b, c, d, x[12], S41, 0x655b59c3); /* 53 */
  II (d, a, b, c, x[ 3], S42, 0x8f0ccc92); /* 54 */
  II (c, d, a, b, x[10], S43, 0xffeff47d); /* 55 */
  II (b, c, d, a, x[ 1], S44, 0x85845dd1); /* 56 */
  II (a, b, c, d, x[ 8], S41, 0x6fa87e4f); /* 57 */
  II (d, a, b, c, x[15], S42, 0xfe2ce6e0); /* 58 */
  II (c, d, a, b, x[ 6], S43, 0xa3014314); /* 59 */
  II (b, c, d, a, x[13], S44, 0x4e0811a1); /* 60 */
  II (a, b, c, d, x[ 4], S41, 0xf7537e82); /* 61 */
  II (d, a, b, c, x[11], S42, 0xbd3af235); /* 62 */
  II (c, d, a, b, x[ 2], S43, 0x2ad7d2bb); /* 63 */
  II (b, c, d, a, x[ 9], S44, 0xeb86d391); /* 64 */

  state[0] += a;
  state[1] += b;
  state[2] += c;
  state[3] += d;


  /* Zeroize sensitive information. */

  MD_memset ((POINTER)x, 0, sizeof (x));
}

/************************************************************************
 Encodes input (uint32) into output (uchar8). Assumes len is  a multiple of 4
*************************************************************************/
STATIC void
Encode (uchar8 *output, uint32 *input, uint32 len)
{
  uint32 i, j;

  for (i = 0, j = 0; j < len; i++, j += 4)
  {
    output[j] = (uchar8)(input[i] & 0xff);
    output[j+1] = (uchar8)((input[i] >> 8) & 0xff);
    output[j+2] = (uchar8)((input[i] >> 16) & 0xff);
    output[j+3] = (uchar8)((input[i] >> 24) & 0xff);
  }
}

/***************************************************************************
 Decodes input (uchar8) into output (uint32). Assumes len is  a multiple of 4
***************************************************************************/
STATIC void
Decode (uint32 *output, uchar8 *input, uint32 len)
{
  uint32 i, j;

  for (i = 0, j = 0; j < len; i++, j += 4)
  {
    output[i] = ((uint32)input[j]) | (((uint32)input[j+1]) << 8) |
    (((uint32)input[j+2]) << 16) | (((uint32)input[j+3]) << 24);
  }
}


STATIC void
MD_memcpy (POINTER output, POINTER input,uint32 len)
{
  uint32 i;
  for (i = 0; i < len; i++)
  {
     output[i] = input[i];
  }
}


STATIC void
MD_memset(POINTER output, int32 value, uint32 len)
{
  uint32 i;
  for (i = 0; i < len; i++)
  {
    ((char8 *)output)[i] = (char8)value;
  }
}

/****************************************************************************/
STATIC void
MDUpdate (MD_CT *context, uchar8 *input, uint32 inputLen)
{
  uint32 i, index, partLen;

  /* Compute number of bytes mod 64 */
  index = (uint32)((context->count[0] >> 3) & 0x3F);

  /* Update number of bits */
  if ((context->count[0] += ((uint32)inputLen << 3))
                               < ((uint32)inputLen << 3))
  {
    context->count[1]++;
  }
  context->count[1] += ((uint32)inputLen >> 29);

  partLen = 64 - index;
/* Transform as many times as possible.*/
  if (inputLen >= partLen)
  {
     MD_memcpy((POINTER)&context->buffer[index], (POINTER)input, partLen);
     MDTransform (context->state, context->buffer);

     for (i = partLen; i + 63 < inputLen; i += 64)
     MDTransform (context->state, &input[i]);

     index = 0;
  }
  else
    i = 0;

  /* Buffer remaining input */
  MD_memcpy((POINTER)&context->buffer[index], (POINTER)&input[i],inputLen-i);
}
/*****************************************************************************
 MD5 finalization. Ends an MD5 message-digest operation, writing the
 the message digest and zeroizing the context.
******************************************************************************/
STATIC void
MDFinal (uchar8 * digest, MD_CT * context)
{
  uchar8 bits[8];
  uint32 index, padLen;

  /* Save number of bits */
  Encode (bits, context->count, 8);

  /* Pad out to 56 mod 64.*/

  index = (uint32)((context->count[0] >> 3) & 0x3f);
  padLen = (index < 56) ? (56 - index) : (120 - index);
  MDUpdate (context, PADDING, padLen);

  /* Append length (before padding) */
  MDUpdate (context, bits, 8);

  /* Store state in digest */
  Encode (digest, context->state, 16);

  /* Zeroize sensitive information.*/
  MD_memset ((POINTER)context, 0, sizeof (*context));
}

/******************************************************************
*  Function Name                :  IFX_OS_Md32
*  Description                  :  This function returns a decimal  
*                               :  for an integer input 
*  Input Values                 :  string, length
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/
STATIC int32   IFX_OS_Md32( char8 *string, int32 length )
{
   MD_CT context;
   union
   {
      char8 c[16];
      uint32 x[4];
   } digest;
   int32 r, i;


   MDInit( &context );
   MDUpdate( &context,((uchar8 *)string),length );
   MDFinal( ( uchar8 * ) &digest,&context );

   r = 0;
   for( i = 0; i < 3; i++ )
   {
      r ^= digest.x[i];
   }
   return r;
}

/******************************************************************
*  Function Name                :  IFX_OS_MD5_GetRandomValue
*  Description                  :  This function returns random number 
*                               :   
*  Input Values                 :  
*  Output Values                :  None 
*  Return Value                 :  Decimal Value 
*  Notes                        :
*********************************************************************/
PUBLIC uint32  IFX_OS_MD5_GetRandomValue( void )
{
   struct
   {
      struct  timeval tv;
      clock_t cpu;

      pid_t pid;
      uint32 hid;

      uid_t uid;
      gid_t gid;
      struct  utsname name;
   } s;
   s.tv.tv_usec = 200;
   s.tv.tv_sec = 0;

   gettimeofday( &s.tv,0 );
   uname( &s.name );

   s.cpu = clock();

   s.pid = getpid();
   s.uid = getuid();
   s.gid = getgid();
   return IFX_OS_Md32( ( char8 * ) &s,sizeof( s ) );
}

/*******************************************************************************
 									Memory Debug Library to check Memory Leaks	
*********************************************************************************/
#ifdef MEM_DBG

x_IFX_OS_DbgMem *pxHead;

x_IFX_OS_DbgMem* 
IFX_OS_StoreMemInfo(void *vId,int32 iSize,char8 *pcFile, int32 iLine)
{
  x_IFX_OS_DbgMem *pxNew, *pxPrev, *pxCurr;
  if((pxNew = calloc(1,sizeof(x_IFX_OS_DbgMem))) != NULL)
  {
    pxNew->vId = vId;
    pxNew->iSize = iSize;
    pxNew->iLine = iLine;
    strcpy(pxNew->acFile,pcFile+21);
    pxNew->pxNext = NULL;
  }
  else
  {
    printf("Should not come here\n");		
  }
  if(pxHead == NULL)
  {
    pxHead = pxNew;
  }
  else
  {
    pxPrev = pxCurr = pxHead;
    while((pxCurr!=NULL) && (pxCurr->pxNext != NULL))
	 {
      pxPrev = pxCurr;
      pxCurr = pxCurr->pxNext;
    }
    if(pxCurr != NULL)
	 {
      pxCurr->pxNext = pxNew;
    }
    else
	 {
      pxPrev->pxNext = pxNew;
    }
  }
  return pxNew;
}

x_IFX_OS_DbgMem*
IFX_OS_LocateMemInfo(void *vId, x_IFX_OS_DbgMem **pxPrevNode)
{
  x_IFX_OS_DbgMem *pxCurr, *pxPrev=NULL;
  pxCurr = pxHead;
  while((pxCurr!=NULL) && (pxCurr->vId != vId))
  {
    pxPrev = pxCurr;
    pxCurr = pxCurr->pxNext;
  }
  if(pxPrevNode != NULL)
  {
    *pxPrevNode = pxPrev;
  }
  return pxCurr;
}

int32
IFX_OS_BytesAllocated(int32 *piNumBytes)
{
  int32 iCount=0,iNumAllocs=0;
  x_IFX_OS_DbgMem *pxCurr;
  pxCurr = pxHead;
  while(pxCurr != NULL)
  {
    iCount += pxCurr->iSize;
    iNumAllocs++;
    pxCurr = pxCurr->pxNext;
  }
  if(piNumBytes != NULL)
  {
    *piNumBytes = iCount;
  }
  return iNumAllocs;	
}
	

int32 
IFX_OS_FreeDbg(void* pcFree, char8 *pcFile, int32 iLine)
{
  x_IFX_OS_DbgMem *pxCurr, *pxPrev;
  if((pxCurr = IFX_OS_LocateMemInfo(pcFree,&pxPrev)) != NULL)
  {
    if(pxPrev != NULL)
	 {
			pxPrev->pxNext = pxCurr->pxNext;
	}
	else
	{
			pxHead = pxCurr->pxNext;
	}
	  free(pxCurr);
	}
	else{
		printf("Already Freed %x Line: %d File: %s\n",pcFree,iLine,pcFile+25);			
	}

	if(pcFree)
	{
	  int iSize1, iNumAllocs;
		iNumAllocs=IFX_OS_BytesAllocated(&iSize1);
	  printf("Freed %x Line: %d  File: %s TotalAllocs = %d\n",pcFree,iLine,pcFile+25,iNumAllocs);			
		free(pcFree);	
	}
	return 0;
}



void* 
IFX_OS_CallocDbg(int32 uiNum, int32 iSize, char8 *pcFile, int32 iLine)
{
	x_IFX_OS_DbgMem *pxMemDbg;
	int32 iNumAllocs, iSize1=0;
	void *pTemp;
  
	pTemp = calloc(uiNum,iSize + 1);
	if(pTemp == NULL)
	{
		printf("$$$$$$$$$$$$$$$$$$$$$$Memory allocation failed\n");	  
		return NULL;
	}

	if((pxMemDbg = IFX_OS_StoreMemInfo(pTemp,iSize,pcFile,iLine)) == NULL)
	{
          IFX_OS_FreeDbg(pTemp,pcFile,iLine);
	  return NULL;
	}
	iNumAllocs=IFX_OS_BytesAllocated(&iSize1);
	printf("Alloc at addr %x ,Bytes Alloc %d ,File %s line %d , TotalAllocs = %d\n",
				 pTemp,(iSize*uiNum),pcFile+25,iLine,iNumAllocs);			
	memset(pTemp, 0, iSize);
	return pTemp;
}


void* 
IFX_OS_MallocDbg(int32 iSize, char8 *pcFile, int32 iLine)
{
  return IFX_OS_CallocDbg(1,iSize,pcFile,iLine);
}

void
IFX_OS_MemInfo()
{
/*	IFX_MLIB_DbgInfo(vMLibId);*/
	x_IFX_OS_DbgMem *pxCurr;
	pxCurr = pxHead;
	printf("\n---------------MEMORY INFO START--------------");
	printf("\n----------------------------------------------");
	printf("\n Address | Size  | Line | File name");
	printf("\n----------------------------------------------");
	while(pxCurr != NULL){
		printf("\n%8x | %5u | %4d | %s",(uint32)pxCurr->vId,pxCurr->iSize,pxCurr->iLine,
							 pxCurr->acFile);
		pxCurr = pxCurr->pxNext;
	}
	printf("\n----------------------------------------------");
	printf("\n---------------MEMORY INFO END----------------\n");
   /*IFX_MLIB_DbgInfo(vMLibId);*/
}
#else

void* IFX_OS_Malloc(uint32 iBytes) 
{
 return calloc(1,iBytes);
}

void* IFX_OS_Calloc(int32 uiNum,int32 iBytes) 
{
	return calloc(uiNum,iBytes);
}
void IFX_OS_Free(void *pBuff) 
{
	if(pBuff)
	{
	 free(pBuff);
  }
}
#endif
#ifdef __LINUX__
uint32 IFX_OS_CreateThread(void * (*start_routine)(void *),void* pvParam)
{
  pthread_t uiThreadId = 0;
  pthread_attr_t xAttrib;
  int32 iRetVal;
  iRetVal = pthread_attr_init(&xAttrib);
  iRetVal = pthread_attr_setdetachstate(&xAttrib, PTHREAD_CREATE_DETACHED);
  if ((iRetVal =
         pthread_create(&uiThreadId, &xAttrib,start_routine,
                        pvParam)) != 0) {
    printf(" stack Thread Creation Error\n");
		pthread_attr_destroy(&xAttrib);
    return 0;
  }
  return uiThreadId;
}
int32 IFX_OS_LockAcquire(x_IFX_OS_LockType xSemId)
{
  return IFX_SUCCESS;
  struct sembuf xWait ={0,-1,SEM_UNDO};
  return semop((int32)xSemId,&xWait,1);
  
}
int32 IFX_OS_LockRelease(x_IFX_OS_LockType xSemId)
{
  return IFX_SUCCESS;
  struct sembuf xPost = {0,1,SEM_UNDO};
  return semop((int32)xSemId,&xPost,1);
}
int32 IFX_OS_LockCreate(x_IFX_OS_LockType *pxSemId)
{
  ux_IFX_OS_SEMUN uxArg={0};
  static int32 iKey =6666;
  /* Create Semaphore */
  if (( *pxSemId = semget(iKey,1,IPC_CREAT |0666))
       == IFX_FAILURE)
  {
     perror("error creating semaphore is");
     return IFX_FAILURE;
  }
   iKey++;
  /* Initilize Sempahore */
  uxArg.val = 1;
  if (semctl(*pxSemId,0,SETVAL,uxArg) == IFX_FAILURE)
  {
     perror("error initilizing semaphore is");
     return IFX_FAILURE;
  }
  return 0;
}
int32 IFX_OS_LockDestroy(x_IFX_OS_LockType *pxSemId)
{
	semctl(*pxSemId,1,IPC_RMID);
  return 0;
}
#endif

