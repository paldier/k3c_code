/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#include "croom_getopt.h"
#include <string.h>

bool is_option_char (const char *str, char *option_char, bool *ill_formed)
{
        bool retval = false;

        /* For an argv element to be a parameter is must have the following properties
         * 1. The argv pointer must not be equal to NULL
         * 2. The string length of the argv parameter must be equal to 2
         * 3. The first character in string must be equal to '-'
         * 4. The second character in string must not be another '-'
         */

        *ill_formed = false;
        *option_char = ' ';

        /* the evalation of this expression is left to right */
        if (NULL != str) {
                if ((1 == strlen(str)) && ('-' == str[0])) {
                        *ill_formed = true;
                }  else if ((2 == strlen(str)) && ('-' == str[0]) && ('-' != str[1])) {
                        *option_char = str[1];
                        retval = true;
                }  else if ((2 == strlen(str)) && ('-' == str[0]) && ('-' == str[1])) {
                        *option_char = str[1];
                }
        }
        return (retval);
}


bool parse_option (const char *opt_string, char option_char, bool *expect_str)
{
        bool valid = false;
        uint32_t index = 0;
        uint32_t options;

        if (NULL != opt_string ) {
                options = (uint32_t) strlen (opt_string);
                for ( ; index < options ; index++ ) {
                        if( opt_string[index] == option_char ) {
                                valid = true;
                                /* added check to make sure there there is enough
                                 * room in the argv for a string parameter
                                 */
                                *expect_str = false;
                                if ( (index + 1) < options ) {
                                        if (':' == opt_string[index + 1]) {
                                                /* yep there is a string next, tell
                                                 * the caller
                                                 */
                                                *expect_str = true;
                                        }
                                }
                                break;
                        }
                }
        }
        return (valid);
}


int32_t croom_getopt(uint32_t argc, const char *argv[], const char *opt_string, uint32_t *opt_index)
{
        int32_t retval = -1;

        char option_char = ' ';
        bool expect_str = false;
        bool ill_formed = false;

        for ( ; (*opt_index) < argc; (*opt_index)++) {
                /* if option character found then break from loop */
                if (true == is_option_char (argv[*opt_index], &option_char, &ill_formed)) {
                        if (true == parse_option(opt_string, option_char, &expect_str)) {
                                retval = option_char;
                                if (true == expect_str) {
                                        /* then there must be enough room */
                                        if (((*opt_index) + 1) >= argc) {
                                                retval = -2;
                                        }
                                }
                        } else {
                                retval = -3;
                        }
                        /* option index always points to the next argv element */
                        (*opt_index)++;
                        break;
                } else {
                        /* space after the dash case */
                        if (true == ill_formed) {
                                retval = -3;
                                break;
                        }
                        /* double dash means that we are done */
                        if ('-' == option_char) {
                                retval = -1;
                                break;
                        }
                }
        }
        return (retval);
}
