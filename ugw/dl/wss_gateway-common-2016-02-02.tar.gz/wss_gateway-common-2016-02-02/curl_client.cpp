/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */
#include "curl_client.h"
#include "gw_error_code.h"
#include "gwlog.h"
#include <iostream>

using namespace std;

#define DEFAULT_CURL_TIMEOUT     60L

pthread_mutex_t g_curl_command_lock;
uint32_t g_lock_initialized = 0;

size_t CurlClient::WriteCallback(
                                 void *contents,
                                 size_t size,
                                 size_t nmemb,
                                 void *userp)
{
    size_t realsize = size * nmemb;
    MemoryChunk *mem = static_cast<MemoryChunk*>(userp);

    mem->memory = reinterpret_cast<char*>(realloc(mem->memory, mem->size + realsize + 1));
    if(mem->memory == NULL)
    {
        GWLOG(LOG_ERR, "not enough memory!");
        return 0;
    }

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}

CurlClient::CurlClient()
{
    if(g_lock_initialized == 0) {
        memset(&g_curl_command_lock, 0, sizeof(pthread_mutex_t));

        if (pthread_mutex_init(&g_curl_command_lock, NULL) != 0) {
            GWLOG(LOG_ERR,"Unable to initialize g_curl_command_lock.");
        }
        else {
            GWLOG(LOG_INFO,"Initialized g_curl_command_lock successfully");
            g_lock_initialized = 1;
        }
    }
}

CurlClient::CurlClient(const curl_usessl useSsl)
{
    // must be one of the CURLUSESSL_x options
    m_useSsl = useSsl;
}

CurlClient::~CurlClient()
{
}

int CurlClient::doDeleteRequest(const std::string& url,
                    const std::vector<std::string>& inHeaders,
                    std::string& response)
{
    std::vector<std::string> outHeaders;
    return doInternalRequest(url, "DELETE", inHeaders, "", "", outHeaders, response);
}

int CurlClient::doDeleteRequest(const std::string& url,
                    const std::vector<std::string>& inHeaders,
                    const std::string& request,
                    std::string& response)
{
    std::vector<std::string> outHeaders;
    return doInternalRequest(url, "DELETE", inHeaders, request, "", outHeaders, response);
}

int CurlClient::doDeleteRequest(const std::string& url,
                 const std::vector<std::string>& inHeaders,
                 const std::string& request,
                 const std::string& username,
                 std::vector<std::string>& outHeaders,
                 std::string& response)
{
    return doInternalRequest(url, "DELETE", inHeaders, request, username, outHeaders, response);
}

int CurlClient::doGetRequest(const std::string& url,
                 const std::vector<std::string>& inHeaders,
                 std::string& response)
{
    std::vector<std::string> outHeaders;
    return doInternalRequest(url, "GET", inHeaders, "", "", outHeaders, response);
}

int CurlClient::doGetRequest(const std::string& url,
                 const std::vector<std::string>& inHeaders,
                 const std::string& request,
                 std::string& response)
{
    std::vector<std::string> outHeaders;
    return doInternalRequest(url, "GET", inHeaders, request, "", outHeaders, response);
}

int CurlClient::doGetRequest(const std::string& url,
                 const std::vector<std::string>& inHeaders,
                 const std::string& request,
                 const std::string& username,
                 std::vector<std::string>& outHeaders,
                 std::string& response)
{
    return doInternalRequest(url, "GET", inHeaders, request, username, outHeaders, response);
}

int CurlClient::doPutRequest(const std::string& url,
                 const std::vector<std::string>& inHeaders,
                 std::string& response)
{
    std::vector<std::string> outHeaders;
    return doInternalRequest(url, "PUT", inHeaders, "", "", outHeaders, response);
}

int CurlClient::doPutRequest(const std::string& url,
                 const std::vector<std::string>& inHeaders,
                 const std::string& request,
                 std::string& response)
{
    std::vector<std::string> outHeaders;
    return doInternalRequest(url, "PUT", inHeaders, request, "", outHeaders, response);
}

int CurlClient::doPutRequest(const std::string& url,
                 const std::vector<std::string>& inHeaders,
                 const std::string& request,
                 const std::string& username,
                 std::vector<std::string>& outHeaders,
                 std::string& response)
{
    return doInternalRequest(url, "PUT", inHeaders, request, username, outHeaders, response);
}

int CurlClient::doPostRequest(
                    const std::string& url,
                    const std::vector<std::string>& inHeaders,
                    std::string& response)
{
    std::vector<std::string> outHeaders;
    return doInternalRequest(url, "", inHeaders, "", "", outHeaders, response);
}

int CurlClient::doPostRequest(
                    const std::string& url,
                    const std::vector<std::string>& inHeaders,
                    const std::string& request,
                    std::string& response)
{
    std::vector<std::string> outHeaders;
    return doInternalRequest(url, "", inHeaders, request, "", outHeaders, response);
}

int CurlClient::doPostRequest(
                    const std::string& url,
                    const std::vector<std::string>& inHeaders,
                    const std::string& request,
                    const std::string& username,
                    std::vector<std::string>& outHeaders,
                    std::string& response)
{

    return doInternalRequest(url, "", inHeaders, request, username, outHeaders, response);
}

int CurlClient::decomposeHeader(const char* header, std::vector<std::string>& headers)
{
    size_t npos = 0;
    if(NULL == header)
    {
        return GW_RESULT_INVALID_PARAMETER;
    }

    std::string header_s = header;

    npos = header_s.find("\r\n");
    while(npos != std::string::npos)
    {
        std::string s = header_s.substr(0, npos);
        headers.push_back(s);
        header_s = header_s.substr(npos + 2);
        npos = header_s.find("\r\n");
    }

    return GW_RESULT_OK;
}

int CurlClient::doInternalRequest(const std::string& url,
                                  const std::string& method,
                                  const std::vector<std::string>& inHeaders,
                                  const std::string& request,
                                  const std::string& username,
                                  std::vector<std::string>& outHeaders,
                                  std::string& response)
{

    pthread_mutex_lock(&g_curl_command_lock);
    int result = GW_RESULT_OK;
    CURL *curl = NULL;
    CURLcode res = CURLE_OK;
    struct curl_slist *headers = NULL;
    MemoryChunk rsp_body;
    MemoryChunk rsp_header;
    m_lastResponseCode = INVALID_RESPONSE_CODE; // initialize recorded code value in case of early return

    if(url.empty())
    {
        GWLOG(LOG_ERR, "url is empty");
        pthread_mutex_unlock(&g_curl_command_lock);
        return GW_RESULT_INVALID_PARAMETER;
    }

    curl = curl_easy_init();
    if(curl != NULL)
    {
        curl_easy_reset(curl);

        for(unsigned int i=0; i<inHeaders.size(); i++)
        {
            std::string hdropt = inHeaders[i];
            headers = curl_slist_append(headers, inHeaders[i].c_str());
            if (NULL == headers) {
                GWLOG(LOG_ERR, "curl_slist_append failed");
                result = GW_RESULT_OUT_OF_MEMORY;
                goto CLEANUP;
            }
        }

        // Expect the transfer to complete within DEFAULT_CURL_TIMEOUT seconds
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, DEFAULT_CURL_TIMEOUT);

        // Set CURLOPT_VERBOSE to 1L below to see detailed debugging
        // information on curl operations.
        curl_easy_setopt(curl, CURLOPT_VERBOSE, 0);
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, request.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &rsp_body);
        curl_easy_setopt(curl, CURLOPT_HEADERDATA, &rsp_header);
        if (CURLUSESSL_NONE != m_useSsl) {
            curl_easy_setopt(curl, CURLOPT_USE_SSL, m_useSsl);
        }

        if(!username.empty())
        {
            curl_easy_setopt(curl, CURLOPT_USERNAME, username.c_str());
        }

        if(!method.empty())
        {
            // NOTE: The documentation for CURLOPT_CUSTOMREQUEST only lists HTTP, FTP, IMAP, POP3, and SMTP
            //       as valid options, although it says all this option does is change the string used in
            //       the request. (Basically, don't know whether this option has any effect as currently
            //       used?

            /// only required for GET, PUT, DELETE
            curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, method.c_str());
        }

        res = curl_easy_perform(curl);
        if(res != CURLE_OK)
        {
            GWLOG(LOG_ERR, "curl_easy_perform failed with %lu", (unsigned long) res);
            result = GW_RESULT_NETWORK_ERROR;
            goto CLEANUP;
        }

        if (CURLE_OK != curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &m_lastResponseCode)) {
            GWLOG(LOG_WARNING, "curl_easy_getinfo(CURLINFO_RESPONSE_CODE) failed.");
            m_lastResponseCode = INVALID_RESPONSE_CODE;
        }

        response = rsp_body.memory;

        decomposeHeader(rsp_header.memory, outHeaders);

        std::string hdr_ut = rsp_header.memory;
    }
    else {
        GWLOG(LOG_ERR, "curl_easy_init failed");
        result = GW_RESULT_INTERNAL_ERROR;
    }

CLEANUP:
    if (NULL != headers) {
        curl_slist_free_all(headers);
    }

    if (NULL != rsp_body.memory) {
        // memory can be NULL if failure in WriteCallBack
        free(rsp_body.memory);
    }

    if (NULL != rsp_header.memory) {
        // memory can be NULL if failure in WriteCallBack
        free(rsp_header.memory);
    }

    if (NULL != curl) {
        curl_easy_cleanup(curl);
    }

    pthread_mutex_unlock(&g_curl_command_lock);
    return result;
}
