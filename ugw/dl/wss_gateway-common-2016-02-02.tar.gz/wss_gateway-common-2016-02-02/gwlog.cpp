/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#include "gwlog.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdbool.h>
#include <syslog.h>

#define LOG_EMERG_STR "EMERG"
#define LOG_ALERT_STR "ALERT"
#define LOG_CRIT_STR "CRIT"
#define LOG_ERR_STR "ERR"
#define LOG_WARNING_STR "WARNING"
#define LOG_NOTICE_STR "NOTICE"
#define LOG_INFO_STR "INFO"
#define LOG_DEBUG_STR "DEBUG"
#define LOG_UNKNOWN_STR "UNKNOWN"

static void gw_log_init();

static void __gw_log_write(
        int8_t severity,
        const char *tag,
        const char *message);

static const char *gw_log_severity_string(int8_t severity);

static FILE *g_logfile = NULL;
static bool g_syslogopen = false;

static void gw_log_init()
{
        if (g_syslogopen != true) {
                g_syslogopen = true;
                openlog("GW", LOG_PID, LOG_USER);
        }
}

void gw_log_deinit()
{
        if (g_syslogopen == true) {
                g_syslogopen = false;
                closelog();
        }

        gw_log_close_file();
}

GW_RESULT gw_log_open_file(const char *filename)
{
        GW_RESULT result = GW_RESULT_FILE_NOT_OPEN;

        gw_log_init();

        if (g_logfile == NULL) {
                g_logfile = fopen(filename, "a");
                if (g_logfile == NULL) {
                        printf("Failed to open log file: %s", filename);
                        result = GW_RESULT_FILE_NOT_OPEN;
                } else {
                        result = GW_RESULT_OK;
                }
        } else {
                result = GW_RESULT_FILE_ALREADY_OPEN;
        }
        return result;
}

GW_RESULT gw_log_close_file()
{
        GW_RESULT result = GW_RESULT_FILE_NOT_CLOSED;

        if (g_logfile != NULL) {
                if (fclose(g_logfile) != 0) {
                        printf("Failed to close log file\n");
                        result = GW_RESULT_FILE_NOT_CLOSED;
                } else {
                        g_logfile = NULL;
                        result = GW_RESULT_OK;
                }
        } else {
                result = GW_RESULT_OK;
        }
        return result;
}

static void __gw_log_write(int8_t severity, const char *tag, const char *message)
{
        char cSeverity[32];
        time_t rawtime;
        struct tm *logt = NULL;
        memset(cSeverity, 0, sizeof(cSeverity));

        if (!g_syslogopen) {
                gw_log_init();
        }

        strncpy(cSeverity, gw_log_severity_string(severity), sizeof(cSeverity)-1);

        syslog(severity, "%s [%s] %s", cSeverity, tag, message);

        /* Redirect log to terminal if _GW_DEBUG macro is defined */
#ifdef _GW_DEBUG
        if (logt == NULL) {
                time(&rawtime);
                logt = localtime(&rawtime);
        }
        if(logt != NULL) {
            printf(" *** %02d:%02d:%02d %s [%s] %s \n",
                    logt->tm_hour,
                    logt->tm_min,
                    logt->tm_sec,
                    cSeverity,
                    tag,
                    message);
        }
#endif

        if (g_logfile != NULL) {
                if (logt == NULL) {
                        time(&rawtime);
                        logt = localtime(&rawtime);
                }
                if (logt != NULL) {
                        fprintf(g_logfile,
                                "%02d:%02d:%02d %s [%s] %s\n",
                                logt->tm_hour,
                                logt->tm_min,
                                logt->tm_sec,
                                cSeverity,
                                tag,
                                message);
                }
        }
}

static const char *gw_log_severity_string(int8_t severity)
{
        switch (severity) {
                case LOG_EMERG:
                        return LOG_EMERG_STR;
                case LOG_ALERT:
                        return LOG_ALERT_STR;
                case LOG_CRIT:
                        return LOG_CRIT_STR;
                case LOG_ERR:
                        return LOG_ERR_STR;
                case LOG_WARNING:
                        return LOG_WARNING_STR;
                case LOG_NOTICE:
                        return LOG_NOTICE_STR;
                case LOG_INFO:
                        return LOG_INFO_STR;
                case LOG_DEBUG:
                        return LOG_DEBUG_STR;
                default:
                        return LOG_UNKNOWN_STR;
        }
}

void gw_log_write(
        const char *file,
        const char *function,
        int32_t line,
        const char *tag,
        int8_t severity,
        const char *fmt,
        ...)
{
        char buf[LOG_BUFFER_SIZE];
        char *index = NULL;

        /* Find the location of the file name in the full file path  */
        const char *filename = NULL;
        filename = (filename = strrchr(file, '/')) ? filename + 1 : file;

        snprintf(buf, sizeof(buf), "%s:%d::%s - ", filename, line, function);

        /*
         * Set the index to be the end of the log messsage header. The variable
         * argument list will be added on from this location.
         */
        index = buf + strlen(buf);

        va_list argp;
        va_start(argp, fmt);
        vsprintf(index, fmt, argp);
        va_end(argp);

        __gw_log_write(severity, tag, buf);
}

/*
 * Print text of max_len size and then buffer 16 chars per line
 * If the text doesnt exist then just print the buffer.
 */
void gw_log_write_buffer(
        const char *file,
        const char *function,
        int32_t line,
        const char *tag,
        int8_t severity,
        const char *text,
        void *buffer,
        uint32_t buffer_len)
{
        uint8_t *int_buffer = (uint8_t *)buffer;
        char hex_buffer[128];
        uint32_t bytes_left = buffer_len;
        uint32_t bytes_to_print = 0;
        uint32_t offset = 0;

        /* if the text part is not null print that first */
        if (text != NULL) {
                gw_log_write(
                        file,
                        function,
                        line,
                        tag,
                        severity,
                        "%s (%lu)",
                        text,
                        buffer_len);
        }

        /* Print the buffer 16 chars per line */
        for (offset = 0; offset < buffer_len; offset += 16) {
                /* determine how many to print this round */
                bytes_to_print = ((bytes_left < 16) ? bytes_left : 16);

                /* get string to print */
                memset(hex_buffer, 0, sizeof(hex_buffer));
                uint32_t char_index = 0;
                size_t i = 0;
                for (i = 0; i < bytes_to_print; i++) {
                        sprintf(&(hex_buffer[char_index]), "%02X ", (int_buffer[offset + i]));
                        char_index += (2 + 1); /* 2 for byte, 1 for space */
                }

                gw_log_write(
                        file,
                        function,
                        line,
                        tag,
                        severity,
                        "%s",
                        hex_buffer);

                /* decrease the remaining byte count */
                bytes_left -= bytes_to_print;
        }
}
