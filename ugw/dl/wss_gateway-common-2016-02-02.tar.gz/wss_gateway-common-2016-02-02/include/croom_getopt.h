/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#ifndef __CROOM_GETOPT_H__
#define __CROOM_GETOPT_H__

/* The clean room get options function AKA croom_getopt has roughly the same
 * interface and use as the commonly known getopts interface, however the
 * implementation was done in a clean room and it avoids static variables or
 * global variables outside of argc and argv.
 */

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* croom_getopt takes as input argc, argv, optstr, and the optind value must
 * be initially set to zero. croom_getopt needs to be called in a loop where
 * the return value will either be the option letter or -1 when there are no
 * more options available.
 *
 * examples of option strings are as follows:
 * "fs:"    indicates flag f, and a string s is passed
 * "fyb:s:" indicates flags f and y will be passed along with strings b and s.
 *
 *      int32_t flag = 0;
 *      char *file_name[300];
 *      uint32_t opt_index = 0;     must be initialized to 0
 *      int32_t option_char;
 *
 *      do {
 *           option_char = croot_getopt (argc, argv, "fs:", &opt_index);
 *           switch (option_char) {
 *                case 'f':
 *                     flag = 1;
 *                     break;
 *                case 's':
 *                     pal_strcpy(file_name, argv[opt_index], 300);
 *                     break;
 *                default:
 *                     if (option_char < 0) {
 *                           natural or error return
 *                     } else {
 *                           invalid option
 *                     }
 *                     break;
 *           }
 *      } while (option_char > 0);
 *
 */

/* croom_getopt will return -1 for normal and successful completion of parsing.
 * it will return -2 for a parsing error situation.
 */


/* The opt_index is a variable used to indicate the next element in argv to be
 * parsed. For the very first call to croom_getopt, it is expected that the
 * value of opt_index is set to zero. The croom_getopt will return -1 when it
 * encounters the first non option element.
 *
 * The special argument of `--' forces an end to option parsing.  In this case
 * the croot_getopt will return a -1.
 *
 * If an element of argv is prepended with '-', and is not exactly "-" alone or
 * the special argument of "--", then the argv element is an option element.
 * The very first character adjacent to the "-" is the option character.  This
 * implementation does not support aggregation of flag parameters.  There is a
 * one to one relationship between the "-" and the option character.
 *
 * It is expected to to call the croom_getopt repeatedly until the croom_getopt
 * returns a -1 indicating that there are no more parameters to parse.
 *
 * This implementation does not understand the long names associated with
 * getopt_long nor does it understand the "=" character.
 */



int32_t croom_getopt(uint32_t argc, const char *argv[], const char *opt_string, uint32_t *opt_index);

#ifdef __cplusplus
}
#endif

#endif /* __CROOM_GETOPT_H__ */




