/* INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */
#ifndef __CURL_CLIENT_H__
#define __CURL_CLIENT_H__

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string>
#include <vector>
#include <curl/curl.h>
#include "gw_error_code.h"

#define CURL_CONTENT_TYPE_JSON         "content-type: application/json"
#define CURL_CONTENT_TYPE_URL_ENCODED  "content-type: application/x-www-form-urlencoded"
#define CURL_HEADER_ACCEPT_JSON        "accept: application/json"
#define INVALID_RESPONSE_CODE           0

class CurlClient
{
public:
    CurlClient();
    CurlClient(const curl_usessl useSsl);
    virtual ~CurlClient();

    // Delete Request APIs
    int doDeleteRequest(const std::string& url,
                        const std::vector<std::string>& inHeaders,
                        std::string& response);

    // Use this API if you have request apart from
    // the URL, inHeaders and response
    int doDeleteRequest(const std::string& url,
                        const std::vector<std::string>& inHeaders,
                        const std::string& request,
                        std::string& response);

    // Use this API if you have username or outHeaders apart from
    // the URL, inHeaders, request and response
    int doDeleteRequest(const std::string& url,
                        const std::vector<std::string>& inHeaders,
                        const std::string& request,
                        const std::string& username,
                        std::vector<std::string>& outHeaders,
                        std::string& response);

    // Get request APIs
    int doGetRequest(const std::string& url,
                     const std::vector<std::string>& inHeaders,
                     std::string& response);

    // Use this API if you have request apart from
    // the URL, inHeaders and response
    int doGetRequest(const std::string& url,
                     const std::vector<std::string>& inHeaders,
                     const std::string& request,
                     std::string& response);

    // Use this API if you have username or outHeaders apart from
    // the URL, inHeaders, request and response
    int doGetRequest(const std::string& url,
                     const std::vector<std::string>& inHeaders,
                     const std::string& request,
                     const std::string& username,
                     std::vector<std::string>& outHeaders,
                     std::string& response);

    // Put request APIs
    int doPutRequest(const std::string& url,
                     const std::vector<std::string>& inHeaders,
                     std::string& response);

    // Use this API if you have request apart from
    // the URL, inHeaders and response
    int doPutRequest(const std::string& url,
                     const std::vector<std::string>& inHeaders,
                     const std::string& request,
                     std::string& response);

    // Use this API if you have username or outHeaders apart from
    // the URL, inHeaders, request and response
    int doPutRequest(const std::string& url,
                     const std::vector<std::string>& inHeaders,
                     const std::string& request,
                     const std::string& username,
                     std::vector<std::string>& outHeaders,
                     std::string& response);

    // Post request APIs
    int doPostRequest(const std::string& url,
                     const std::vector<std::string>& inHeaders,
                     std::string& response);

    // Use this API if you have request apart from
    // the URL, inHeaders and response
    int doPostRequest(const std::string& url,
                     const std::vector<std::string>& inHeaders,
                     const std::string& request,
                     std::string& response);

    // Use this API if you have username or outHeaders apart from
    // the URL, inHeaders, request and response
    int doPostRequest(const std::string& url,
                     const std::vector<std::string>& inHeaders,
                     const std::string& request,
                     const std::string& username,
                     std::vector<std::string>& outHeaders,
                     std::string& response);

    long getLastResponseCode() { return m_lastResponseCode; }

private:
    static size_t WriteCallback(void *contents,
                                size_t size,
                                size_t nmemb,
                                void *userp);
    ///
    /// Represents contiguos memory to hold a HTTP response.
    ///
    typedef struct _MemoryChunk {
        _MemoryChunk() : size(0)
        {
            memory = reinterpret_cast<char*>(malloc(1));
        }
        char *memory;
        size_t size;

    } MemoryChunk;

    int decomposeHeader(const char* header, std::vector<std::string>& headers);

    ///
    /// Performs a RESTful HTTP call with the parameters below.
    ///
    /// @param url the full URI to make the call to.
    ///
    /// @param method indicates the method, "PUT", "GET", etc. POST does not
    /// require any special method indication.
    ///
    /// @param inHeaders contains the input headers for the call
    ///
    /// @param request contains the request body
    ///
    /// @param outHeaders is a vector of strings containing the response headers.
    ///
    /// @param response contains the response body.
    int doInternalRequest(const std::string& url,
                          const std::string& method,
                          const std::vector<std::string>& inHeaders,
                          const std::string& request,
                          const std::string& username,
                          std::vector<std::string>& outHeaders,
                          std::string& response);

    long m_lastResponseCode; // last response code registered in a doInternalRequest call

    /// Indicates whether to use CURLOPT_USE_SSL option in doInternalRequest.
    /// Curl default is no SSL (CURLUSESSL_NONE). Specify one of the other CURL SSL options
    /// (for example, CURLUSESSL_TRY) if you need to perform SSL transactions.
    curl_usessl m_useSsl;
};

#endif
