/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#include <stdint.h>

#ifndef __GW_ERROR_CODE_H__
#define __GW_ERROR_CODE_H__

/*
 * Definitions for error codes for the gateway
 */
typedef uint32_t GW_RESULT;

#define GW_RESULT_OK                                  0u
#define GW_RESULT_NOT_CREATED                         1u   /*< Module has not been created. */
#define GW_RESULT_CREATED_FAILED                      2u   /*< Module has failed during create. */
#define GW_RESULT_INVALID_HANDLE                      3u   /*< The handle is invalid. */
#define GW_RESULT_INVALID_PARAMETER                   4u   /*< Parameters are invalid. */
#define GW_RESULT_INTERNAL_ERROR                      5u   /*< Some unknown error occurred. */
#define GW_RESULT_INVALID_VERSION                     6u   /*< Invalid plugin API version. */
#define GW_RESULT_MISSING_API                         7u   /*< One or more expected API is missing in the callback. */
#define GW_RESULT_NOT_IMPLEMENTED                     8u   /*< API function is not implemented. */
#define GW_RESULT_OUT_OF_MEMORY                       9u   /*< Memory allocation failure. */
#define GW_RESULT_ERROR_ADD_MESSAGE_QUEUE             10u  /*< add message queue failure. */
#define GW_RESULT_LOADLIBRARY_FAILED                  11u
#define GW_RESULT_INSUFFICIENT_BUFFER                 12u
#define GW_RESULT_DUPLICATE_API_CALL                  13u
#define GW_RESULT_FILE_NOT_OPEN                       14u
#define GW_RESULT_FILE_ALREADY_OPEN                   15u
#define GW_RESULT_FILE_NOT_CLOSED                     16u
#define GW_RESULT_NOT_STARTED                         17u   /*< Module has not been started. */
#define GW_RESULT_STARTED_FAILED                      18u   /*< Module has failed during start. */
#define GW_RESULT_ALREADY_STARTED                     19u   /*< Module already started. */
#define GW_RESULT_NOT_STOPPED                         20u
#define GW_RESULT_ALREADY_CREATED                     21u   /*< Module already created. */
#define GW_RESULT_NOT_AUTHORIZED                      22u   /*< Not authorized */
#define GW_RESULT_NOT_PRESENT                         23u   /*< Not present or available */
#define GW_RESULT_ALREADY_AUTH                        24u
#define GW_RESULT_DEAUTH_FAILED                       25u
#define GW_RESULT_ALREADY_DEAUTH                      26u
#define GW_RESULT_NETWORK_ERROR                       27u
#define GW_RESULT_JSON_ERROR                          28u
#define GW_RESULT_MEMORY_ERROR                        29u
#define GW_RESULT_INVALID_DATA                        30u
#define GW_RESULT_INDEX_OUT_OF_BOUNDS                 31u   /*< Specified an index too great for array. */
#define GW_RESULT_UNEXPECTED_RESULT                   32u   /*< Result code did not match expected response */

#endif /* __GW_ERROR_CODE_H__ */
