/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

/*
 * LOG_TAG "can" be defined by the module including gwlog.h
 * This will help in filtering based on the TAG specific to module
 * If the module chooses not to define LOG_TAG the default is "GW"
 */
#ifndef LOG_TAG
#define LOG_TAG "GW"
#endif

#include <stdint.h>
#include "gw_error_code.h"

#ifndef __GWLOG_H__
#define __GWLOG_H__

#ifdef __cplusplus
extern "C"
{
#endif

/*
 * Use the smallest buffer size used by all platforms. Currently Android is the
 * limiting factor at 1024 bytes.
 */
#define LOG_BUFFER_SIZE 1024

/*
 * Severity copied from Linux syslog
 */
#define LOG_EMERG       0
#define LOG_ALERT       1
#define LOG_CRIT        2
#define LOG_ERR         3
#define LOG_WARNING     4
#define LOG_NOTICE      5
#define LOG_INFO        6
#define LOG_DEBUG       7

void gw_log_deinit();

GW_RESULT gw_log_open_file(const char *filename);

GW_RESULT gw_log_close_file(void);

void gw_log_write(
        const char *file,
        const char *function,
        int32_t line,
        const char *tag,
        int8_t severity,
        const char *fmt,
        ...
        );

void gw_log_write_buffer(
        const char *file,
        const char *function,
        int32_t line,
        const char *tag,
        int8_t severity,
        const char *text,
        void *buffer,
        uint32_t buffer_len);

/*
 * GWLOG macro will be used throughout the GW framework
 */
#define GWLOG(severity, fmt, ...) \
        gw_log_write(__FILE__, __FUNCTION__, __LINE__, LOG_TAG, severity, fmt, ##__VA_ARGS__)

#define GWLOG_BUFFER(severity, text, buffer, buffer_len) \
        gw_log_write_buffer(__FILE__, __FUNCTION__, __LINE__, LOG_TAG, severity, text, buffer, buffer_len)

#ifdef __cplusplus
}
#endif

#endif /* __GWLOG_H__ */
