/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#ifndef __JSON_HELPER_H__
#define __JSON_HELPER_H__
#include "rapidjson.h"
#include "document.h"
#include "stringbuffer.h"
#include "writer.h"
#include <string>

#include <typeinfo>

class JsonHelper
{
public:

    static std::string toString(rapidjson::Value& doc)
    {
        rapidjson::StringBuffer sb;
        std::string jsonRep;

        rapidjson::Writer<rapidjson::StringBuffer> writer(sb);
        doc.Accept(writer);
        return sb.GetString();
    }

    static std::string toString(rapidjson::Value::ConstMemberIterator& it)
    {
        rapidjson::StringBuffer sb;
        std::string jsonRep;

        rapidjson::Writer<rapidjson::StringBuffer> writer(sb);
        it->value.Accept(writer);
        return sb.GetString();
    }

        template<typename T>
        static void setMember(rapidjson::Document& doc, std::string obj,
                std::string name, T& value)
        {
            if(doc.HasMember(obj.c_str()))
            {
                rapidjson::Document::AllocatorType& allocator = doc.GetAllocator();
                doc[obj.c_str()].RemoveMember(name.c_str());
                rapidjson::Value nameValue (name.c_str(), allocator);
                doc[obj.c_str()].AddMember(nameValue, value, allocator);
            }
        }

    template<typename T>
    static void setMember(rapidjson::Document& doc, const std::string& name, T& value)
    {
        if(doc.HasMember(name.c_str()))
        {
            doc[name.c_str()] = value;
        }
        else
        {
            rapidjson::Document::AllocatorType& allocator = doc.GetAllocator();
            rapidjson::Value nameValue (name.c_str(), allocator);
            doc.AddMember(nameValue, value, allocator);
        }

    }

    template<typename T>
    static bool getMember(rapidjson::Document& doc, std::string name, T& value)
    {
        if(doc.HasMember(name.c_str()))
        {
            if(typeid(T) == typeid(std::string))
            {
                value = doc[name.c_str()].GetString();
            }
            return true;
        }
        return false;
    }

    static void tryRemoveMember(rapidjson::Document& doc, std::string name)
    {
        if(doc.HasMember(name.c_str()))
        {
            doc.RemoveMember(name.c_str());
        }
    }
};
#endif /* __JSON_HELPER_H__ */
