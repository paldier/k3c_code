/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#ifndef __MISC_UTILITY_FUNCS__
#define __MISC_UTILITY_FUNCS__

#include "gw_error_code.h"

// SOME C MODULES CONSUME THIS FILE; DON'T EXPOSE C++ FUNCS TO THEM.
#ifdef __cplusplus
#include <string>

/// Loads a text file into a string.
///
/// @param filePath - (input) Path/filename to load.
/// @param fileContents - (output) Returned file contents.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT LoadFileIntoString(const char* filePath, std::string& fileContents);

/// Saves a string into a text file.
///
/// @param stringData - (input) String to save to file.
/// @param filePath - (input) Path/filename to load.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT SaveStringIntoFile(const char* stringData, const char* filePath);

/// Copies a file.
///
/// @param sourceFilePath - (input) source file/path to copy
/// @param destFilePath - (input) target file/path
/// @param binaryFile - (input) true if source is binary file, false if text file.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT CopyFile(const char* sourceFilePath, const char* destFilePath, const bool binaryFile);

/// Retrieves a named string from a JSON blob.
///
/// @param jsonBlob - (input) JSON blob to inspect.
/// @param valueName - (input) Name of string to retrieve.
/// @param returnedValue - (output) Returned string value.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonString(const char* jsonBlob, const char* valueName, std::string& returnedValue);

/// Retrieves a named double value from a nested JSON blob.
///
/// @param jsonBlob - (input) JSON blob to inspect.
/// @param nodeName - (input) Name of subelement containing desired value.
/// @param valueName - (input) Name of value to retrieve.
/// @param returnedValue - (output) Returned value.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonEmbeddedDouble(const char* jsonBlob, const char* nodeName, const char* valueName,
    double& returnedValue);

/// Retrieves a named int value from a JSON blob.
///
/// @param jsonBlob - (input) JSON blob to inspect.
/// @param valueName - (input) Name of value to retrieve.
/// @param returnedValue - (output) Returned value.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonInt(const char* jsonBlob, const char* valueName, int& returnedValue);

/// Retrieves a numerical value from a JSON blob in both int and double form.
///
/// @param jsonBlob - (input) JSON blob to inspect.
/// @param valueName - (input) Name of value to retrieve.
/// @param returnedInt - (output) Returned value.
/// @param returnedDouble - (output) Returned value (double form).
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonNumber(const char* jsonBlob, const char* valueName, int& returnedInt, double& returnedDouble);

/// Retrieves a named double value from a JSON blob.
///
/// @param jsonBlob - (input) JSON blob to inspect.
/// @param valueName - (input) Name of value to retrieve.
/// @param returnedValue - (output) Returned value.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonDouble(const char* jsonBlob, const char* valueName, double& returnedValue);

/// Returns number of elements in a JSON array.
///
/// @param jsonBlob - (input) Array in JSON format.
/// @param arraySize - (output) Number of elements in passed array.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonArraySize(const char* jsonBlob, int& arraySize);

/// Retrieves a named int value from a JSON array.
///
/// @param jsonBlob - (input) JSON array blob to inspect.
/// @param arrayItem - (input) Index of desired array element.
/// @param valueName - (input) Name of value to retrieve from array element.
/// @param returnedValue - (output) Returned value.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonIntFromArray(const char* jsonBlob, const int arrayItem, const char* valueName, int& returnedValue);

/// Retrieves a named double value from a JSON array.
///
/// @param jsonBlob - (input) JSON array blob to inspect.
/// @param arrayItem - (input) Index of desired array element.
/// @param valueName - (input) Name of value to retrieve from array element.
/// @param returnedValue - (output) Returned value.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonDoubleFromArray(const char* jsonBlob, const int arrayItem, const char* valueName,
    double& returnedValue);

/// Retrieves both named int and double value from a JSON array. cJSON always stores both int and double
/// representations in cJSON_Number-type items, and the caller needs to know which kind to use. There
/// are int-only and double-only wrappers for this function.
///
/// @param jsonBlob - (input) JSON array blob to inspect.
/// @param arrayItem - (input) Index of desired array element.
/// @param valueName - (input) Name of value to retrieve from array element.
/// @param returnedInt - (output) Returned value.
/// @param returnedDouble - (output) Returned value.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonNumberFromArray(const char* jsonBlob, const int arrayItem, const char* valueName, int& returnedInt,
    double& returnedDouble);

/// Retrieves a named string value from a JSON array.
///
/// @param jsonBlob - (input) JSON array blob to inspect.
/// @param arrayItem - (input) Index of desired array element.
/// @param valueName - (input) Name of value to retrieve from array element.
/// @param returnedValue - (output) Returned value.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonStringFromArray(const char* jsonBlob, int arrayItem, const char* valueName,
    std::string& returnedValue);

/// Retrieves a named array from the passed JSON array in string form.
/// This is for complex JSON blobs with nested arrays.
///
/// @param jsonBlob - (input) JSON array blob to inspect.
/// @param arrayItem - (input) Index of desired parent array element.
/// @param arrayName - (input) Name of child array to retrieve from parent array element.
/// @param returnedArray - (output) Returned array.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonArrayFromArray(const char* jsonBlob, const int arrayItem, const char* arrayName,
    std::string& returnedArray);

/// Retrieves an element from a JSON array in string form.
///
/// @param jsonBlob - (input) JSON array blob to parse.
/// @param arrayItem - (input) Index of desired array element.
/// @param returnedItem - (output) Returned JSON item.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonElementFromArray(const char* jsonBlob, const int arrayItem, std::string& returnedItem);

/// Retrieves a top-level named element from a JSON blob in string form.
///
/// @param jsonBlob - (input) JSON array blob to parse.
/// @param elementName - (input) Name of desired JSON element.
/// @param returnedItem - (output) Returned JSON item.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT GetJsonElement(const char* jsonBlob, const char* elementName, std::string& returnedItem);

/// Replaces the contents of a named JSON property with a new value and/or type.
/// Use this to live-edit JSON blobs.
///
/// @param jsonBlob - (input) JSON array blob to parse.
/// @param propertyName - (input) Name of JSON property to replace.
/// @param propertyType - (output) Type of property to replace it with. Supported types:
///        - cJSON_False
///        - cJSON_True
///        - cJSON_NULL
///        - cJSON_Number (uses doubleVal param)
///        - cJSON_String (uses stringVal param)
///        - cJSON_Array
///        - cJSON_Object
/// @param doubleVal - (input) Value of new propery (when propertyType is cJSON_Number).
/// @param stringVal - (input) Value of new propery (when propertyType is cJSON_String).
/// @param returnedItem - (output) Returned JSON blob with updated contents.
///
/// @return GW_RESULT_OK on success, error code otherwise.
GW_RESULT ReplaceJsonElement(const char* jsonBlob, const char* propertyName, const int propertyType,
    const double doubleVal, const char* stringVal, std::string& returnedItem);

// Checks whether passed JSON is a fault response and extracts fault description if so.
// Lyric fault responses begin with something like this: {"fault":{"faultstring":"invalid_client"...
// This checks for the "fault" element and extracts the "faultstring" value if present.
//
// @param response - (in) JSON blob to parse.
// @param isFaultResponse - (out) If the JSON contained the fault and faultstring elements, this
//        value returns true. Otherwise it is false, indicating the response was not a Lyric
//        failure blob.
// @param faultString - (out) If isFaultResponse is true on return, this value contains the description
//        of the fault.
GW_RESULT checkForFailure(const char* response, bool& isFaultResponse, std::string& faultString);

#endif // __cplusplus

/// Indicates whether a given file exists.
///
/// @param fileName - (input) path/filename to look for
///
/// @return true if file exists, false otherwise.
bool fileExists(const char* fileName);

/// Safe wrapper for strncpy. Makes sure never overflows and also terminates target string
/// in case of truncation. Exists because we're supposed to avoid regular "strcpy" but using
/// strncpy as a replacement for strcpy often results in serious errors (overflows) due to lack
/// of understanding of how it works. If source string is longer than destination, strncpysafe
/// ensures that the resulting string is NULL terminated. You can check whether truncation occurred
/// by comparing strlen(destination) with strlen(source). If source length is greater, the string
/// was truncated.
///
/// @param destination - (out) target string. buffer must be at least 2 chars long.
/// @param source - (in) source string. can be any valid string length.
/// @param destBufLen - (in) total size of destination buffer, in bytes.
///
/// @return destination string.
char *strncpysafe(char *destination, const char* source, const size_t destBufLen);


#endif // __MISC_UTILITY_FUNCS__
