/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#include <stdint.h>
#include "gw_error_code.h"
#include "plugin_server.h"

#ifndef __PLUGIN_AUTH_H__
#define __PLUGIN_AUTH_H__

/* Enforcing a stricter max length on the URI*/
#define MAX_URI_SIZE    32
#define MAX_ID_SIZE     MAX_URI_SIZE

#define RT_PBC        "x.intel-com.pbc"
#define RT_OAUTH      "x.intel-com.oauth"
#define RT_TWOFA      "x.intel-com.2fa"
#define AUTH_RES_TYPE "x.intel-com.auth.ctx"

/**
 * Enum to identify the supported authorization methods
 */
typedef enum {
    AUTH_TYPE_UNDEFINED = 0u,
    // OAuth is used to authorize devices/software components without providing
    // them access to user credentials
    AUTH_TYPE_OAUTH     = 1u,
    // PBC is a push button mechanism to authorize devices/software components
    AUTH_TYPE_PBC       = 2u,
    // 2FA uses 2 factors (from the ones listed in MFAIdentifier) to authenticate
    // or authorize the device/software components.
    AUTH_TYPE_2FA       = 3u,

    // Add more Auth types here

    AUTH_TYPE_MAX       = 4u,
} AuthMethodType;

/**
 * Enum to identify the factors to be used in multi-factor
 * authentication method supported by this module.
 */
typedef enum {
    MFA_ID_INVALID      = 0u,
    MFA_ID_EMAIL        = (1u << 0),
    MFA_ID_PHONE        = (1u << 1),
    MFA_ID_PIN          = (1u << 2),
    // Add more factors here
    // Using a 16 bit mask FFFF = 2^16-1
    MFA_ID_MASK         = ((1u << 16) - 1)
} MFAIdentifier;

/**
 * Typedef to idenfity a unique Authorization context which can
 * be started and stopped
 */
typedef uint16_t AuthHandle;

/**
 * Typedef struct to represent the oAuth context needed by the
 * authorization module.
 */
typedef struct {
    // Must be set by the plugin before calling start
    char *authUrl;
    // Set by the Auth Module before calling the callbacks
    char *code;
    // Auth code time to live.
    uint32_t code_ttl;
} OAuthContextType;

/**
 * Typedef struct that represents the Push Button context needed
 * by the authorization module.
 */
typedef struct {
    // Must be set by the plugin before calling start
    char *authUrl;
} PushButtonContextType;

/**
 * Typedef struct that represents the 2FA context need by the
 * authorization module.
 */
typedef struct {
    char *code_2FA;
    // Must be set by the plugin before calling start
    MFAIdentifier supportedIdentifiers;
    // Set by the Auth Module before calling the callbacks
    char *password;
    // Set by the Auth Module before calling the callbacks
    char *identifier;
    // Set by the Auth Module before calling the callbacks
    char *code;
} TwoFAContexttype;

/**
 * Typedef struct that represents the context taken as an input by the
 * Authorization module during start and returned to the plugin every
 * time the Authorization module calls back into the plugin
 */
typedef struct {
    // Type identifies which context within the union is being used
    AuthMethodType type;
    union {
        OAuthContextType oAuthCtx;
        PushButtonContextType PBCCtx;
        TwoFAContexttype twoFACtx;
    }authCtx;
    // Must be set by the plugin before calling start
    char *manufacturerName;
    // Must be set by the plugin before calling start
    char *productName;
    // Must be set by the plugin before calling start
    // Plugin will use this to give more details about the auth server
    // For example the hue plugin will put the mac address of the bridge
    char *authServerInfo;
} AuthModuleContext;


/**
 * Callback registered by the plugin which will be called by the
 * authorization module when an authorization request is received
 * from a trusted client.
 *
 * @param handle
 *    Unique id to identify this authorization context
 * @param authCtx
 *    Context of the specific authorization request made by calling start
 * @param clientID
 *    Uniquely identifies the user associating with the authorization
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_AUTH_FAILED    - auth failed
 *    GW_RESULT_AUTH_PENDING   - auth is pending some client action
 *    GW_RESULT_ALREADY_AUTH   - auth has already been done for this user
 */
typedef GW_RESULT (*DoAuthCallback)
    (AuthHandle handle, AuthModuleContext *authCtx, const char *clientID);

/**
 * Callback registered by the plugin which will be called by the
 * authorization module when a de-authorization request is received
 * from a trusted client.
 *
 * @param handle
 *    Unique id to identify this authorization context
 * @param authCtx
 *    Context of the specific authorization request made by calling start
 * @param clientID
 *    Uniquely identifies the user associating with the authorization
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_DEAUTH_FAILED  - deauth failed
 *    GW_RESULT_ALREADY_DEAUTH - deauth has already been done for this user
 */
typedef GW_RESULT (*DoDeauthCallback)
    (AuthHandle handle, AuthModuleContext *authCtx, const char *clientID);


/**
 * Initialize the Authorization module. Must be called prior to
 * calling start to allocate all the memory/resources/context
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_CREATED_FAILED - auth create error
 *    GW_RESULT_ALREADY_CREATED- auth create has already been called
 */
GW_RESULT authModuleCreate();

/**
 * Start a specific authorization method with unique context
 * which is represented by a specific auth resource in Iotivity
 * Multiple starts can be called by the same plugin. Start is not
 * a thread safe function. Caller needs to ensure thread safety
 *
 * @param handle
 *    Unique id to identify this authorization context
 * @param authCtx
 *    Context of the specific authorization request made by calling start
 * @param authHandler
 *    Plugin provides a callback when a request to authorize is received
 *    from the trusted client
 * @param deauthHandler
 *    Plugin provides a callback for when a request to deauthorize is
 *    received from the trusted client
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_START_FAILED   - start failed
 */
GW_RESULT authModuleStart(AuthHandle *handle,
                          AuthModuleContext *authCtx,
                          DoAuthCallback authHandler,
                          DoDeauthCallback deauthHandler);

/**
 * Stop a specific authorization method which was started at some point.
 * All started contexts must be stopped before destroy gets called. Stop
 * is not a thread safe function. Caller needs to ensure thread safety.
 *
 * @param handle
 *    Unique id to identify this authorization context
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_STOP_FAILED    - stop failed
 *    GW_RESULT_INVALID_HANDLE - invalid handle provided
 */
GW_RESULT authModuleStop(AuthHandle handle);

/**
 * Deinitializes the Authorization module. Must be called after
 * calling stop to free all the memory/resources/context
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_DESTROY_FAILED - auth destroy error
 */
GW_RESULT authModuleDestroy();

OCEntityHandlerResult handleOCRequests(
        OCEntityHandlerFlag flag,
        OCEntityHandlerRequest* EHRequest);

bool buildURI(AuthMethodType type, AuthHandle handle, char *uri, size_t uriSize);

typedef struct ListItemStruct {
    OCPayload* payload;
    bool isAuthorized;
    DoAuthCallback authCB;
    DoDeauthCallback deauthCB;
    AuthHandle handle;
    OCResourceHandle OCHandle;
    char uri[MAX_URI_SIZE];
    AuthMethodType type;
    // Not NULL for auth ctx resources, points to the auth server items
    struct ListItemStruct *parentItem;
    // True only if this is an auth_ctx resource item
    // If true parentItem cannot be NULL
    bool isAuthResource;
} ListItem;

bool isValidResourceType(const char* RT, AuthMethodType *MT);

AuthMethodType uriToAuthMethodType(const char *uri);

uint32_t translateOcMethod(const OCMethod ocMethod);

#endif /* __PLUGIN_AUTH_H__ */
