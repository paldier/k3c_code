/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

/* This file contains the "C" plugin interface definition.  This header file
 * and its corresponding implementation file is intended to be shared among
 * ALL plugins.  Modification of this file is not necessary for the construction
 * of a new plugin.
 */

#include <stdint.h>
#include <cpluff.h>
#include <pthread.h>
#include "gw_error_code.h"
#include <stdbool.h>

#ifndef __PLUGIN_IF_H__
#define __PLUGIN_IF_H__

/* This is a clear way to store file descriptors for unnamed pipes.  Each pipe
 * has a read end and a write end.
 */
typedef struct pipe_tag {
        int32_t read_fd;    /* descriptor used for reading */
        int32_t write_fd;   /* descriptor used for writing */
} pipe_t;

typedef struct common_plugin_ctx_tag  common_plugin_ctx_t;

struct common_plugin_ctx_tag
{
        /* The ppm ctx is passed into plugin at create time, it is stored in
         * the common plugin context.
         */
        cp_context_t *ppm_ctx;

        /* Unnamed pipes are used in this implementation of the common plugin code,
         * however the unnamed pipes are NOT exposed outside of the common plugin code.
         * One of the unnamed pipes is used by the child to tell parent that the
         * child has created and started the plugin content section successfully or not.
         * The other unnamed pipe is used by the parent to stop the child which in turn
         * stops and destroys the plugin content. As you know the unnamed pipes may be
         * only used with related processes (i.e. having the same parent). The pipes exist
         * as long as their descriptors are open.
         */
        pipe_t  parent_reads_fds;
        pipe_t  child_reads_fds;

        /* The "started" variable is used by the parent process to not permit
         * more than one fork to happen per instance of the plugin.
         */
        int32_t  started;

        /* The main thread in the child process needs to know when it should
         * leave the OIC process loop.
         */
        bool  exit_process_loop;

        /* Save the child's process handle to wait on it being signaled later */
        pid_t child_pid;

};

/* Pipe Messages that are used to martial APIs inside the common portion of
 * of the plugin.  The messages are defined here.
 */
#define PLUGIN_START_COMPLETE       "DONE"
#define PLUGIN_START_COMPLETE_ERROR "ERRR"
#define PLUGIN_STOP_REQUEST         "STOP"
#define PLUGIN_MESSAGE_SIZE          5

#define MY_END_READ     0
#define MY_END_WRITE    1

// Add a preprocessor directive control to reduce the TIMEOUT time for
// tier1 testing to be 10s to save test time. Otherwise, it is 60s.
#ifdef TIER1_MODE
    #define TIMEOUT_VAL_IN_SEC  10
#else
    #define TIMEOUT_VAL_IN_SEC  60
#endif

GW_RESULT plugin_service(common_plugin_ctx_t *plugin_ctx);

#endif /* __PLUGIN_IF_H__ */
