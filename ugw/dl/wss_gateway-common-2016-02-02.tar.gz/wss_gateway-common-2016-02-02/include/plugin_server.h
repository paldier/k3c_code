/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

/* This file contains the interface between the plugin's OIC server and the
 * plugin specific implmentation
 */

#include "plugin_if.h"
#include "gw_error_code.h"
#include "ocstack.h"
#include <stdbool.h>
#include "queue.h"

#ifndef __PLUGIN_SERVER_H__
#define __PLUGIN_SERVER_H__

/* This resource implementation has a work queue.  The work queue types are
 * defined here.
 */
#define WORK_ITEM_START_PRESENCE     1
#define WORK_ITEM_CREATE_RESOURCE    2
#define WORK_ITEM_DESTROY_RESOURCE   3
#define WORK_ITEM_STOP_PRESENCE      4
#define WORK_ITEM_NOTIFY_OBSERVERS   5
#define WORK_ITEM_DO_RESPONSE        6

#define THREAD_PROCESS_SLEEPTIME     1

/* Plugin context is owned by the plugin specific content provider (you).
 */
typedef struct plugin_ctx_tag
{
        /* This plugin specific content provider has chosen to use a worker thread
         * to manage all the devices.  Keeping track if the thread is started.
         */
        bool  started;

        /* The thread is staying around for the lifetime of the plugin instance.
         * This state variable is required to tell the thread leave the thread
         * function when that time comes.
         */
        bool  stay_in_process_loop;

        /* Save the thread handle so there is a possibility to wait on thread
         * handles for synchronization purposes.
         */
        pthread_t thread_handle;
}plugin_ctx_t;

/* The intention here is create a queue-able structure for a work item queue
 * The most important field is the first field which denotes the the work item
 * type.  The other field's relevancy depends on the work_id value.
 */
typedef struct work_item_tag work_item_t;
struct work_item_tag
{
        OCResourceHandle *handle;
        uint32_t work_id;
        char uri[MAX_URI_LENGTH];
        char resource_type[MAX_URI_LENGTH];
        char resource_interface_name[MAX_URI_LENGTH];
        OCEntityHandler entity_handler;
        uint8_t res_property;
        OCEntityHandlerResponse response;
};

GW_RESULT server_init();
GW_RESULT server_deinit();
GW_RESULT plugin_process();

/* These functions are called by the by the plugin's own OIC server which is
 * common code for all plugins.  There is one OIC server per plugin.  The APIs
 * shown below permit the plugin to initialize and to allow the plugin specific
 * code to call other OC APIs.  The implementation of these functions is found
 * in the plugin specific code.
 */
GW_RESULT plugin_create(plugin_ctx_t **plugin_specific_ctx);
GW_RESULT plugin_start(plugin_ctx_t *plugin_specific_ctx);
GW_RESULT plugin_stop(plugin_ctx_t *plugin_specific_ctx);
GW_RESULT plugin_destroy(plugin_ctx_t *plugin_specific_ctx);
void plugin_specific_process(void);

#endif /* __PLUGIN_SERVER_H__ */
