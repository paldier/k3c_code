/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#ifndef __QUEUE_H__
#define __QUEUE_H__

#include <stdint.h>
#include <stdbool.h>

/* When this queue is shared across boundaries like 32 bit and 64 bit environments
 * it is important to keep the structure packed, otherwise there is optimizations
 * that compilers use which mess up the structure by packinging it on certain
 * boundaries
 */
#pragma pack(1)

typedef struct queue_node_tag
{
        void*                    buffer;
        uint32_t                 size;
        struct queue_node_tag*   next;
        struct queue_node_tag*   prev;
} queue_node_t;

#pragma pack( )

/*
 * This queue was intended not to be general purpose.  It is a double linked
 * list to make the adding and removal of nodes optimal.  If you are using
 * this list with multi threading you must install your own thread protection.
 */

#ifdef __cplusplus
extern "C" {
#endif

void initialize_queue(queue_node_t *pqueue);
void* remove_from_head(queue_node_t *pqueue, uint32_t* size);
void add_to_tail(queue_node_t *pqueue, char *buffer, uint32_t size);
bool is_queue_empty(queue_node_t *pqueue);
queue_node_t *get_head_node(queue_node_t *pqueue);
queue_node_t *get_next_node(queue_node_t *pnode);
void *get_buffer_from_node(queue_node_t *pnode, uint32_t *size);
bool remove_from_middle(queue_node_t *pnode, void **buffer);

#ifdef __cplusplus
}
#endif

#endif /* __QUEUE_H__ */
