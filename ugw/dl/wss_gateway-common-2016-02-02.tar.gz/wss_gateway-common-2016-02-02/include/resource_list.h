/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#ifndef __RESOURCE_LIST_H__
#define __RESOURCE_LIST_H__

#include "octypes.h"

#include "plugin_server.h"

/* Resources can come and go based on having a IOT device added or removed from
 * the physical infrastructure.  Also the Iotivity entity handler does not pass
 * or present a resource handle in the entity handler callback.  Therefore, in
 * the plugin specific code an associative structure needs to be kept around in
 * global space to allow the implementer to make the association between URI and
 * other attributes corresponding with the IOT device in the data model.
 *
 * NOTE: Iotivity guarantees that one can not represent two devices with exactly
 *       the same URI, so keying off of the URI is a successful strategy.
 */
typedef struct resource_instance_tag resource_instance_t;
struct resource_instance_tag
{
    char uri[MAX_URI_LENGTH];
    OCResourceHandle resource_handle;

    /* NOTE: This structure is intended to associate the URI with
     * something/anything that connects the URI to a physical device.
     * The plugin specific developer, please put whatever else is needed
     * in this association structure.
     */
    /* the number of observers interested in this resource */
    uint32_t observe_cnt;
};

GW_RESULT        add_resource(const char *uri, OCResourceHandle handle);
bool             remove_resource_with_uri(const char *uri);
bool             find_resource(OCResourceHandle handle, char *uri, uint32_t **observe_cnt);
OCResourceHandle find_resource_from_uri(const char *uri, uint32_t *observe_cnt);

#endif /*__RESOURCE_LIST_H__*/
