/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#ifndef LOG_TAG
#define LOG_TAG "UTIL_FUNCS"
#endif

#include "misc_utility_funcs.h"
#include "gwlog.h"
#include <sstream> // ostringstream
#include <fstream> // ifstream
#include "cJSON.h"
#include <sys/stat.h> // for fileExists
#include <unistd.h> // for fileExists
#include <string.h> // strncpy
#include <stdlib.h> // free

GW_RESULT LoadFileIntoString(const char* filePath, std::string& fileContents) {
    GW_RESULT result = GW_RESULT_OK;
    if (NULL == filePath) {
        GWLOG(LOG_ERR, "filePath is NULL.");
        result = GW_RESULT_INVALID_PARAMETER;
    }

    if (GW_RESULT_OK == result) {
        try {
            std::ostringstream buffer;
            std::ifstream inputFile(filePath);
            if (false == inputFile.is_open()) {
                GWLOG(LOG_ERR, "Couldn't open file %s", filePath);
                result = GW_RESULT_FILE_NOT_OPEN;
            }
            else {
                buffer << inputFile.rdbuf();
                fileContents = buffer.str();
                GWLOG(LOG_INFO, "Read %lu bytes from file", (unsigned long) fileContents.size());
            }
        }
        catch (...) {
            GWLOG(LOG_ERR, "caught exception.");
            result = GW_RESULT_INTERNAL_ERROR;
        }
    }

    return result;
}

GW_RESULT GetJsonEmbeddedDouble(const char* jsonBlob, const char* nodeName, const char* valueName, double& returnedValue)
{
    GW_RESULT result = GW_RESULT_OK;
    cJSON* jsonRoot = NULL;
    cJSON* jsonNode = NULL;
    cJSON* jsonValue = NULL;

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // locate top-level node
    jsonNode = cJSON_GetObjectItem(jsonRoot, nodeName);
    if (NULL == jsonNode) {
        GWLOG(LOG_ERR, "cJSON_GetObjectItem failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // locate named value
    jsonValue = cJSON_GetObjectItem(jsonNode, valueName);
    if (NULL == jsonValue) {
        GWLOG(LOG_ERR, "cJSON_GetObjectItem failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // make sure it's a number value
    if (cJSON_Number != jsonValue->type) {
        GWLOG(LOG_ERR, "Value %s is wrong type (%lu)", valueName, (unsigned long) jsonValue->type);
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    // store refresh token value
    returnedValue = jsonValue->valuedouble;

    cleanUp:

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}

GW_RESULT GetJsonString(const char* jsonBlob, const char* valueName, std::string& returnedValue) {
    GW_RESULT result = GW_RESULT_OK;
    cJSON* jsonRoot = NULL;
    cJSON* jsonValue = NULL;

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // locate named value
    jsonValue = cJSON_GetObjectItem(jsonRoot, valueName);
    if (NULL == jsonValue) {
        GWLOG(LOG_ERR, "cJSON_GetObjectItem failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // make sure it's a string value
    if (cJSON_String != jsonValue->type) {
        GWLOG(LOG_ERR, "Value %s is wrong type (%lu)", valueName, (unsigned long) jsonValue->type);
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    // store refresh token value
    returnedValue = jsonValue->valuestring;

    cleanUp:

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}

GW_RESULT SaveStringIntoFile(const char* stringData, const char* filePath) {
    GW_RESULT result = GW_RESULT_OK;

    if ((NULL == stringData) || (NULL == filePath)) {
        GWLOG(LOG_ERR, "stringData or filePath are NULL");
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    try {
        std::ofstream outFile(filePath, std::ofstream::out);
        if (false == outFile.is_open()) {
            GWLOG(LOG_ERR, "Failed to open file %s for output", filePath);
            result = GW_RESULT_FILE_NOT_OPEN;
            goto cleanUp;
        }
        outFile << stringData;
        outFile.close();
    }
    catch (...) {
        GWLOG(LOG_ERR, "Caught exception.");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    cleanUp:

    return result;
}

GW_RESULT CopyFile(const char* sourceFilePath, const char* destFilePath, const bool binaryFile) {
    GW_RESULT result = GW_RESULT_OK;

    std::ofstream::openmode outMode = std::ofstream::out;
    std::ifstream::openmode inMode = std::ifstream::in;

    if (binaryFile) {
        outMode |= std::ofstream::binary;
        inMode |= std::ifstream::binary;
    }

    if ((NULL == sourceFilePath) || (NULL == destFilePath)) {
        GWLOG(LOG_ERR, "sourceFilePath or destFilePath are NULL");
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    try {
        std::ofstream outFile(destFilePath, outMode);
        if (false == outFile.is_open()) {
            GWLOG(LOG_ERR, "Failed to open file %s for output", destFilePath);
            result = GW_RESULT_FILE_NOT_OPEN;
            goto cleanUp;
        }

        std::ifstream inFile(sourceFilePath, inMode);
        if (false == inFile.is_open()) {
            GWLOG(LOG_ERR, "Failed to open file %s for input", sourceFilePath);
            result = GW_RESULT_FILE_NOT_OPEN;
            goto cleanUp;
        }

        outFile << inFile.rdbuf();
        outFile.close();
        inFile.close();
    }
    catch (...) {
        GWLOG(LOG_ERR, "Caught exception.");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    cleanUp:

    return result;
}

GW_RESULT GetJsonInt(const char* jsonBlob, const char* valueName, int& returnedValue)
{
    double returnedDouble = 0;
    return GetJsonNumber(jsonBlob, valueName, returnedValue, returnedDouble);
}

GW_RESULT GetJsonDouble(const char* jsonBlob, const char* valueName, double& returnedValue)
{
    int returnedInt = 0;
    return GetJsonNumber(jsonBlob, valueName, returnedInt, returnedValue);
}

GW_RESULT GetJsonNumber(const char* jsonBlob, const char* valueName, int& returnedInt, double& returnedDouble) {
    GW_RESULT result = GW_RESULT_OK;
    returnedInt = 0;
    returnedDouble = 0.0;
    cJSON* jsonRoot = NULL;
    cJSON* jsonValue = NULL;

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // locate named value
    jsonValue = cJSON_GetObjectItem(jsonRoot, valueName);
    if (NULL == jsonValue) {
        GWLOG(LOG_ERR, "cJSON_GetObjectItem failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // make sure it's a number value
    if (cJSON_Number != jsonValue->type) {
        GWLOG(LOG_ERR, "Value %s is wrong type (%lu)", valueName, (unsigned long) jsonValue->type);
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    // store retrieved value
    returnedInt = jsonValue->valueint;
    returnedDouble = jsonValue->valuedouble;

    cleanUp:

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}

GW_RESULT GetJsonArraySize(const char* jsonBlob, int& arraySize) {
    GW_RESULT result = GW_RESULT_OK;
    cJSON* jsonRoot = NULL;

    // initialize return value
    arraySize = 0;

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    arraySize = cJSON_GetArraySize(jsonRoot);

    cleanUp:

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}

GW_RESULT ReplaceJsonElement(const char* jsonBlob, const char* propertyName, const int propertyType,
    const double doubleVal, const char* stringVal, std::string& returnedItem)
{
    GW_RESULT result = GW_RESULT_OK;
    cJSON* jsonRoot = NULL;
    cJSON* jsonValue = NULL;
    char* localItem = NULL;

    if ((NULL == jsonBlob) || (strlen(jsonBlob) == 0)) {
        GWLOG(LOG_ERR, "jsonBlob is NULL or zero len");
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    if ((NULL == propertyName) || (strlen(propertyName) == 0)) {
        GWLOG(LOG_ERR, "propertyName is NULL or zero len");
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // create appropriate item type depending on propertyType
    // NOTE: Don't delete "cJSON_CreateXXX" items!
    switch (propertyType) {
        case cJSON_False :
            jsonValue = cJSON_CreateFalse();
            break;
        case cJSON_True :
            jsonValue = cJSON_CreateTrue();
            break;
        case cJSON_NULL :
            jsonValue = cJSON_CreateNull();
            break;
        case cJSON_Number :
            jsonValue = cJSON_CreateNumber(doubleVal);
            break;
        case cJSON_String :
            if (NULL == stringVal) {
                GWLOG(LOG_ERR, "stringVal is NULL for cJSON_String property type!");
                result = GW_RESULT_INVALID_PARAMETER;
                goto cleanUp;
            }
            jsonValue = cJSON_CreateString(stringVal);
            break;
        case cJSON_Array :
            jsonValue = cJSON_CreateArray();
            break;
        case cJSON_Object :
            jsonValue = cJSON_CreateObject();
            break;
        default:
            GWLOG(LOG_WARNING, "Unexpected propertyType: %d", propertyType);
    }
    if (NULL == jsonValue) {
        GWLOG(LOG_ERR, "Failed to create temporary value.");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // this function returns void for some reason, so input validation is the only
    // thing we can do.
    cJSON_ReplaceItemInObject(jsonRoot, propertyName, jsonValue);

    // convert array to string
    localItem = cJSON_PrintUnformatted(jsonRoot);
    if (NULL == localItem) {
        GWLOG(LOG_ERR, "cJSON_PrintUnformatted failed!");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // store retrieved value
    returnedItem = localItem;

    cleanUp:

    // free formatted text
    if (NULL != localItem) {
        free(localItem);
    }

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}

GW_RESULT GetJsonElement(const char* jsonBlob, const char* elementName, std::string& returnedItem)
{
    GW_RESULT result = GW_RESULT_OK;
    returnedItem.clear();
    cJSON* jsonRoot = NULL;
    cJSON* jsonValue = NULL;
    char* localItem = NULL;

    if ((NULL == jsonBlob) || (strlen(jsonBlob) == 0)) {
        GWLOG(LOG_ERR, "jsonBlob is NULL or zero len");
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    jsonValue = cJSON_GetObjectItem(jsonRoot, elementName);
    if (NULL == jsonValue) {
        // Below failure can occur in expected/harmless cases, depending on who's calling.
        // Commenting out log to prevent misleading output.
        //GWLOG(LOG_ERR, "cJSON_GetObjectItem failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // convert array to string
    localItem = cJSON_PrintUnformatted(jsonValue);
    if (NULL == localItem) {
        GWLOG(LOG_ERR, "cJSON_PrintUnformatted failed!");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // store retrieved value
    returnedItem = localItem;

    cleanUp:

    // free rendered text
    if (NULL != localItem) {
        free(localItem);
    }

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}


GW_RESULT GetJsonElementFromArray(const char* jsonBlob, const int arrayItem, std::string& returnedItem)
{
    GW_RESULT result = GW_RESULT_OK;
    returnedItem.clear();
    cJSON* jsonRoot = NULL;
    cJSON* jsonArrayItem = NULL;
    int arraySize = 0;
    char* localItem = NULL;

    // NOTE: You're supposed to initialize a cJSON_Hooks struct with cJSON_InitHooks
    //       in order to get malloc/free capability for JSON, but for unknown reasons,
    //       calling cJSON_InitHooks seems to cause instability in subsequent functions
    //       like cJSON_Parse. Instead we're just calling free directly. It appears to
    //       work and be safe. (The returned strings from the cJSON_Print functions
    //       need to be freed, but not by cJSON_Delete... that's why we need free.)

    if ((NULL == jsonBlob) || (strlen(jsonBlob) == 0)) {
        GWLOG(LOG_ERR, "jsonBlob is NULL or zero len");
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    arraySize = cJSON_GetArraySize(jsonRoot);
    if (arrayItem >= arraySize) {
        GWLOG(LOG_ERR, "Index %i is beyond array's size of %i", arrayItem, arraySize);
        result = GW_RESULT_INDEX_OUT_OF_BOUNDS;
        goto cleanUp;
    }

    jsonArrayItem = cJSON_GetArrayItem(jsonRoot, arrayItem);
    if (NULL == jsonArrayItem) {
        GWLOG(LOG_ERR, "cJSON_GetArrayItem failed");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // convert item to string
    localItem = cJSON_PrintUnformatted(jsonArrayItem);
    if (NULL == localItem) {
        GWLOG(LOG_ERR, "cJSON_PrintUnformatted failed!");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // store retrieved value
    returnedItem = localItem;

    cleanUp:

    if (NULL != localItem) {
        free(localItem);
    }

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}

GW_RESULT GetJsonArrayFromArray(const char* jsonBlob, const int arrayItem, const char* arrayName,
    std::string& returnedArray)
{
    GW_RESULT result = GW_RESULT_OK;
    returnedArray.clear();
    cJSON* jsonRoot = NULL;
    cJSON* jsonArrayItem = NULL;
    cJSON* jsonValue = NULL;
    int arraySize = 0;
    char* localArray = NULL;

    // NOTE: You're supposed to initialize a cJSON_Hooks struct with cJSON_InitHooks
    //       in order to get malloc/free capability for JSON, but for unknown reasons,
    //       calling cJSON_InitHooks seems to cause instability in subsequent functions
    //       like cJSON_Parse. Instead we're just calling free directly. It appears to
    //       work and be safe. (The returned strings from the cJSON_Print functions
    //       need to be freed, but not by cJSON_Delete... that's why we need free.)

    if ((NULL == jsonBlob) || (strlen(jsonBlob) == 0)) {
        GWLOG(LOG_ERR, "jsonBlob is NULL or zero len");
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    arraySize = cJSON_GetArraySize(jsonRoot);
    if (arrayItem >= arraySize) {
        GWLOG(LOG_ERR, "Index %i is beyond array's size of %i", arrayItem, arraySize);
        result = GW_RESULT_INDEX_OUT_OF_BOUNDS;
        goto cleanUp;
    }

    jsonArrayItem = cJSON_GetArrayItem(jsonRoot, arrayItem);
    if (NULL == jsonArrayItem) {
        GWLOG(LOG_ERR, "cJSON_GetArrayItem failed");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // locate named array
    jsonValue = cJSON_GetObjectItem(jsonArrayItem, arrayName);
    if (NULL == jsonValue) {
        GWLOG(LOG_ERR, "cJSON_GetObjectItem failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // make sure it's an array
    if (cJSON_Array != jsonValue->type) {
        GWLOG(LOG_ERR, "Value %s is wrong type (%lu)", arrayName, (unsigned long) jsonValue->type);
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    // convert array to string
    localArray = cJSON_PrintUnformatted(jsonValue);
    if (NULL == localArray) {
        GWLOG(LOG_ERR, "cJSON_PrintUnformatted failed!");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // store retrieved array
    returnedArray = localArray;

    cleanUp:

    if (NULL != localArray) {
        free(localArray);
    }

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}

GW_RESULT GetJsonStringFromArray(const char* jsonBlob, int arrayItem, const char* valueName, std::string& returnedValue)
{
    GW_RESULT result = GW_RESULT_OK;
    returnedValue.clear();
    cJSON* jsonRoot = NULL;
    cJSON* jsonArrayItem = NULL;
    cJSON* jsonValue = NULL;
    int arraySize = 0;

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    arraySize = cJSON_GetArraySize(jsonRoot);
    if (arrayItem >= arraySize) {
        GWLOG(LOG_ERR, "Index %i is beyond array's size of %i", arrayItem, arraySize);
        result = GW_RESULT_INDEX_OUT_OF_BOUNDS;
        goto cleanUp;
    }

    jsonArrayItem = cJSON_GetArrayItem(jsonRoot, arrayItem);
    if (NULL == jsonArrayItem) {
        GWLOG(LOG_ERR, "cJSON_GetArrayItem failed");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // locate named value
    jsonValue = cJSON_GetObjectItem(jsonArrayItem, valueName);
    if (NULL == jsonValue) {
        // Intentionally not logging this because it can occur in non-error situations as used by Honeywell.
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // make sure it's a number value
    if (cJSON_String != jsonValue->type) {
        GWLOG(LOG_ERR, "Value %s is wrong type (%lu)", valueName, (unsigned long) jsonValue->type);
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    // store retrieved value
    returnedValue = jsonValue->valuestring;

    cleanUp:

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}

GW_RESULT GetJsonDoubleFromArray(const char* jsonBlob, const int arrayItem, const char* valueName, double& returnedValue)
{
    int returnedInt = 0; // will ignore
    return GetJsonNumberFromArray(jsonBlob, arrayItem, valueName, returnedInt, returnedValue);
}

GW_RESULT GetJsonNumberFromArray(const char* jsonBlob, const int arrayItem, const char* valueName, int& returnedInt,
    double& returnedDouble)
{
    GW_RESULT result = GW_RESULT_OK;
    returnedInt = 0;
    returnedDouble = 0.0;
    cJSON* jsonRoot = NULL;
    cJSON* jsonArrayItem = NULL;
    cJSON* jsonValue = NULL;
    int arraySize = 0;

    jsonRoot = cJSON_Parse(jsonBlob);
    if (NULL == jsonRoot) {
        GWLOG(LOG_ERR, "cJSON_Parse failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    arraySize = cJSON_GetArraySize(jsonRoot);
    if (arrayItem >= arraySize) {
        GWLOG(LOG_ERR, "Index %i is beyond array's size of %i", arrayItem, arraySize);
        result = GW_RESULT_INDEX_OUT_OF_BOUNDS;
        goto cleanUp;
    }

    jsonArrayItem = cJSON_GetArrayItem(jsonRoot, arrayItem);
    if (NULL == jsonArrayItem) {
        GWLOG(LOG_ERR, "cJSON_GetArrayItem failed");
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // locate named value
    jsonValue = cJSON_GetObjectItem(jsonArrayItem, valueName);
    if (NULL == jsonValue) {
        GWLOG(LOG_ERR, "cJSON_GetObjectItem failed because %s", cJSON_GetErrorPtr());
        result = GW_RESULT_INTERNAL_ERROR;
        goto cleanUp;
    }

    // make sure it's a number value
    if (cJSON_Number != jsonValue->type) {
        GWLOG(LOG_ERR, "Value %s is wrong type (%lu)", valueName, (unsigned long) jsonValue->type);
        result = GW_RESULT_INVALID_PARAMETER;
        goto cleanUp;
    }

    // store retrieved values
    returnedInt = jsonValue->valueint;
    returnedDouble = jsonValue->valuedouble;

    cleanUp:

    // cJSON_Parse results need to be deleted.
    if (NULL != jsonRoot) {
        cJSON_Delete(jsonRoot);
    }

    return result;
}

GW_RESULT GetJsonIntFromArray(const char* jsonBlob, const int arrayItem, const char* valueName, int& returnedValue)
{
    double returnedDouble = 0; // will ignore
    return GetJsonNumberFromArray(jsonBlob, arrayItem, valueName, returnedValue, returnedDouble);
}

bool fileExists(const char* fileName)
{
    bool fileExists = false;
    struct stat fileStats;
    if (NULL != fileName) {
        if (0 == stat(fileName, &fileStats)) {
            fileExists = true;
        }
    }
    return fileExists;
}

char *strncpysafe(char *destination, const char* source, const size_t destBufLen)
{
    char* result = NULL;

    if (destBufLen < 2) {
        GWLOG(LOG_ERR, "destBufLen can't be less than 2");
        goto Finish;
    }

    result = strncpy(destination, source, destBufLen);
    // strncpy will not null-terminate output if target buffer is same size or smaller than source
    // string length. Truncate to maximum terminatable string size and warn caller.
    if ((NULL != result) && (strlen(source) >= destBufLen)) {
        GWLOG(LOG_INFO, "Truncating output to %lu characters", (unsigned long) (destBufLen - 1));
        // null-terminate in case of truncation
        destination[destBufLen - 1] = '\0';
    }

Finish:

    return result;
}

#define JSON_FAULT "fault"
#define JSON_FAULT_STRING "faultstring"
GW_RESULT checkForFailure(const char* response, bool& isFaultResponse, std::string& faultString)
{
    GW_RESULT result = GW_RESULT_OK;
    isFaultResponse = false; // assume it's not a fault response
    std::string jsonFault;

    // check params (fail on null or zero len)
    if ((NULL == response) || (strlen(response) == 0)) {
        GWLOG(LOG_ERR, "response is NULL or zero-length");
        result = GW_RESULT_INVALID_PARAMETER;
        goto CLEANUP;
    }

    // get fault element from response
    result = GetJsonElement(response, JSON_FAULT, jsonFault);
    if (GW_RESULT_OK != result) {
        // intentionally not logging error here (just means it's not a failure response)
        goto CLEANUP;
    }

    // get faultstring value from fault element
    result = GetJsonString(jsonFault.c_str(), JSON_FAULT_STRING, faultString);
    if (GW_RESULT_OK != result) {
        // intentionally not logging error here (just means it's not a failure response)
        goto CLEANUP;
    }

    // set isFaultResponse to true if faultstring retrieved
    isFaultResponse = true;

    CLEANUP:

    return result;
}
