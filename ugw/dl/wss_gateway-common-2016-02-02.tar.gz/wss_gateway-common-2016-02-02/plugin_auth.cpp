/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#include "plugin_auth.h"
#define LOG_TAG "PLUGIN_AUTH"
#include "gwlog.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "octypes.h"
#include "ocstack.h"
#include "ocpayload.h"
#include <time.h>
#include <stdlib.h>
#include <pthread.h>
#include <list>
#include <unistd.h>
#include "work_item_queue.h"

/**
 * Internal declarations for the Auth Module
 * Move this to an internal header if we have more than 1 c files
 */

/* Internal #defines */
#define BASE_URI      "/a/"
#define PBC           "pbc"
#define OAUTH         "oauth"
#define TWOFA         "2fa"
#define AUTH_CTX      "auth_ctx"

/* Total size here should not exceed MAX_URI_SIZE */
#define PBC_URI         (BASE_URI PBC "/")
#define OAUTH_URI       (BASE_URI OAUTH "/")
#define TWOFA_URI       (BASE_URI TWOFA "/")
#define AUTH_CTX_URI    (BASE_URI AUTH_CTX "/")
#define DEFAULT_IF_NAME "oic.if.a"
/* TODO: Use the stack ID from OIC instead */
#define CLIENT_ID       "newdeveloper"

pthread_mutex_t request_queue_lock;

OCEntityHandlerResult authEntityHandlerCB(
    OCEntityHandlerFlag flag,
    OCEntityHandlerRequest *entityHandlerRequest,
    void* callbackParam);

//processing requests in the slow response mode
OCEntityHandlerResult handleOCRequests(
        OCEntityHandlerFlag flag,
        OCEntityHandlerRequest* EHRequest);

/**
 * Enum to identify the various states of the Auth Module.
 */
typedef enum {
    AUTH_NOT_CREATED     = 0,
    AUTH_CREATED,
    AUTH_STARTED,
// Add more state here
    AUTH_MAX
} PluginAuthState;

/**
 * Internal context for the Plugin Auth Module
 */
struct PluginAuthCtx{
    // Current State of the Plugin Auth Module
    PluginAuthState state;

    // List to store each context of a start
    queue_node_t resourceList;

    // Keeps track if the slow response thread is started.
    bool  threadStarted;

    // tells the thread if it needs to continue or stop
    bool  stayInProcessLoop;

    /* Save the thread handle so there is a possibility to wait on thread
     * handles for synchronization purposes.
     */
    pthread_t threadHandle;

    PluginAuthCtx(){
        state = AUTH_NOT_CREATED;
        threadStarted = false;
        stayInProcessLoop = false;
    }

};

typedef struct EntityHandlerRequest {
    OCEntityHandlerFlag flag;
    OCEntityHandlerRequest* request;

    EntityHandlerRequest(){
        request = NULL;
    }
}EntityHandlerRequest;

static std::list<EntityHandlerRequest> gRequestList;

/* Static globals */
static PluginAuthCtx gAuthCtx;
static AuthHandle gHandle = 0;

/* Get a unique handle starting at 1 by calling this function */
AuthHandle getNewHandle()
{
    return ++gHandle;
}

void resetHandle()
{
    gHandle=0;
}


/*
 * thread procedure for processing requests that were queued for slow response
 */
void* slowResponseProcess(void *param)
{
    (void)param;
    while (true == gAuthCtx.stayInProcessLoop)
    {
        pthread_mutex_lock(&request_queue_lock);
        if (!gRequestList.empty())
        {
            // Get the request from the list
            EntityHandlerRequest request = gRequestList.front();
            gRequestList.pop_front();
            pthread_mutex_unlock(&request_queue_lock);

            //process previously queued request
            handleOCRequests(request.flag, request.request);

            // Free the request
            if(request.request){
                if(request.request->query){
                    free(request.request->query);
                }
                OCPayloadDestroy(request.request->payload);
                free(request.request);
            }
        }
        else{
            pthread_mutex_unlock(&request_queue_lock);
        }
    }

    GWLOG(LOG_INFO, "Leaving plugin specific thread handler.");
    return NULL;
}

GW_RESULT startSlowResponseThread()
{
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    if (!gAuthCtx.threadStarted){

        memset(&request_queue_lock, 0, sizeof(pthread_mutex_t));
        if (pthread_mutex_init(&request_queue_lock, NULL) != 0) {
            GWLOG(LOG_ERR,"Unable to initialize request_queue_lock.");
            return result;
        }

        //create slow response thread
        gAuthCtx.stayInProcessLoop = true;
        if(pthread_create(&(gAuthCtx.threadHandle), NULL, slowResponseProcess, (void *)NULL) == 0)
        {
            gAuthCtx.threadStarted = true;
            result = GW_RESULT_OK;
        }
        else
        {
            GWLOG(LOG_ERR,"Can't create plugin specific thread");
        }
    }
    return result;
}


/* Convert authorization type to string */
const char *AuthTypetoString(AuthMethodType type)
{
    switch(type) {
    case AUTH_TYPE_PBC:
        return RT_PBC;
    case AUTH_TYPE_OAUTH:
        return RT_OAUTH;
    case AUTH_TYPE_2FA:
        return RT_TWOFA;
    default:
        GWLOG(LOG_ERR, " Unknown authorization method type");
        return NULL;
    }
}

/* Use the handle and type to build the URI */
bool buildURI(AuthMethodType type, AuthHandle handle, char* uri, size_t uriSize)
{
    bool validURI = false;

    if ((uri != NULL) && (uriSize >= MAX_URI_SIZE)) {
        memset(uri, 0, MAX_URI_SIZE);
        switch (type) {
        case AUTH_TYPE_PBC:
            snprintf(uri, MAX_URI_SIZE, "%s%d", PBC_URI, handle);
            validURI = true;
            break;
        case AUTH_TYPE_OAUTH:
            snprintf(uri, MAX_URI_SIZE, "%s%d", OAUTH_URI, handle);
            validURI = true;
            break;
        case AUTH_TYPE_2FA:
            snprintf(uri, MAX_URI_SIZE, "%s%d", TWOFA_URI, handle);
            validURI = true;
            break;
        default:
            GWLOG(LOG_ERR, " Unknown authorization method type");
            break;
        }
        if (validURI) {
            GWLOG(LOG_INFO, "The URI for handle = %d, type = %d is %s", handle, type, uri);
        }
    } else {
        GWLOG(LOG_ERR, "uriSize must be at least %lu and uri must be non-NULL", MAX_URI_SIZE);
    }
    return validURI;
}

bool buildURIForAuth(AuthHandle handle, char *uri)
{
    bool validURI = false;
    uint32_t len = 0;
    if ( uri != NULL) {
        memset(uri, 0, MAX_URI_SIZE);
        strcat(uri, AUTH_CTX_URI);
        len = strlen(uri);
        if (len != 0) {
            // Append handle(unique int) to the URI to create resource URI
            snprintf((uri + len), (MAX_URI_SIZE - len), "%d", handle);
            validURI = true;
            GWLOG(LOG_INFO, "The Auth URI for handle = %d is %s",
                  handle, uri);
        }
    } else {
        GWLOG(LOG_ERR, "Malloc failed");
    }
    return validURI;
}

void buildOAUTHPayload(AuthModuleContext *ctx, OCRepPayload* payload)
{
    if(!payload){
        GWLOG(LOG_ERR, "Payload is NULL");
        return;
    }
    if(!ctx){
        GWLOG(LOG_ERR, "ctx is NULL");
        return;
    }

    // Always called from buildGetPayload Not checking for NULL
    OCRepPayloadSetPropString(payload, "mnmm", ctx->manufacturerName);
    OCRepPayloadSetPropString(payload, "pn", ctx->productName);
    OCRepPayloadSetPropString(payload, "aurl", ctx->authCtx.oAuthCtx.authUrl);

    OCRepPayloadSetPropString(payload, "acode", "");
    OCRepPayloadSetPropInt(payload, "acode-ttl", 0);
}

/*
 * Build Iotivity payload from PBC resource.
 * Always called from buildGetPayload Not checking for NULL
 */
void buildPBCGetPayload(AuthModuleContext *ctx, OCRepPayload* payload)
{
    if(!payload){
        GWLOG(LOG_ERR, "Payload is NULL");
        return;
    }
    if(!ctx){
        GWLOG(LOG_ERR, "ctx is NULL");
        return;
    }

    // Always called from buildGetPayload Not checking for NULL
    OCRepPayloadSetPropString(payload, "mnmm", ctx->manufacturerName);
    OCRepPayloadSetPropString(payload, "pn", ctx->productName);
    OCRepPayloadSetPropString(payload, "id", ctx->authServerInfo);
    OCRepPayloadSetPropString(payload, "aurl", ctx->authCtx.PBCCtx.authUrl);
    // pbc is a write only attribute, always passing it as false
    OCRepPayloadSetPropBool(payload, "pbc", false);
}

/*
 * Build payload from the context information
 * This will effectively be the get response
 */
OCRepPayload *buildGetPayload(AuthModuleContext *ctx,
                         const char *uri,
                         AuthMethodType type)
{
    if ((ctx == NULL) || (uri == NULL)) {
        GWLOG(LOG_ERR,"Can't build GET payload. Ctx or uri is NULL");
        return NULL;
    }

    OCRepPayload* payload = OCRepPayloadCreate();
    if(!payload)
    {
          GWLOG(LOG_ERR,"Invalid OCRepPayload");
          return NULL;
    }

    OCRepPayloadSetUri(payload, uri);
    switch(type) {
    case AUTH_TYPE_PBC:
        buildPBCGetPayload(ctx, payload);
        break;
    case AUTH_TYPE_OAUTH:
        buildOAUTHPayload(ctx, payload);
        break;
    case AUTH_TYPE_2FA:
        // TODO:
        //buildTWOFAPayload(authCtx, Payload);
        GWLOG(LOG_WARNING, "Add support for 2FA here");
        //break;
    default:
        //This will happen for auth_ctx resource
        GWLOG(LOG_ERR, " Unknown authorization method type");
        break;
    }

    return payload;
}


OCRepPayload *buildPayloadForAuth(AuthModuleContext *ctx, const char *uri, const char *id)
{
    if ((ctx == NULL) || (uri == NULL)) {
        GWLOG(LOG_ERR, "Null parameter passed");
        return NULL;
    }

    OCRepPayload* payload = buildGetPayload(ctx, uri, ctx->type);;
    if(!payload) {
        GWLOG(LOG_ERR,"Invalid OCRepPayload");
        return NULL;
    }
    if (id != NULL) {
       OCRepPayloadSetPropString(payload, "id", id);
    }
    return payload;
}

/*
 * Create a new resource context, send the request to the plugin queue
 */
GW_RESULT createResource(ListItem *item, bool isAuthResource)
{
    const char *res_type = NULL;

    if (item == NULL) {
        GWLOG(LOG_ERR, "Invalid input");
        return GW_RESULT_INTERNAL_ERROR;
    }

    if (isAuthResource == true) {
        res_type = AUTH_RES_TYPE;
    } else {
        res_type = AuthTypetoString(item->type);
    }
    if (res_type == NULL) {
        GWLOG(LOG_ERR, "Invalid authorization type");
        return GW_RESULT_INVALID_PARAMETER;
    }

    // Queue the work item to be processed by the plugin
    GWLOG(LOG_INFO, "Adding workItem to work_queue...");
    if(GW_RESULT_OK != add_work_item(
            NULL,
            WORK_ITEM_CREATE_RESOURCE,
            item->uri,
            res_type,
            DEFAULT_IF_NAME,
            authEntityHandlerCB,
            NULL,
            (OCResourceHandle*)(&(item->OCHandle))))
    {
        GWLOG(LOG_ERR,"failed to add work item of creating resource");
        return GW_RESULT_INTERNAL_ERROR;
    }

    return GW_RESULT_OK;
}
/*
 * Destroy the resource by putting the request to the plugin queue
 */
GW_RESULT destroyResource(ListItem *item)
{
    if (item == NULL) {
        GWLOG(LOG_ERR, "Invalid input");
        return GW_RESULT_INTERNAL_ERROR;
    }

    add_work_item(NULL, WORK_ITEM_DESTROY_RESOURCE,item->uri,NULL,NULL,NULL, NULL,
            (OCResourceHandle*)(&(item->OCHandle)));

    // Item has already been removed from the resourceList
    if (item->payload != NULL) {
        free(item->payload);
        item->payload = NULL;
    }

    return GW_RESULT_OK;
}

/*
 * Find the ListItem in the resource list matching the OC handle
 * This function does not remove the node from the list
 */
GW_RESULT getListNodeFromOCHandle(OCResourceHandle handle, ListItem **item)
{
    GW_RESULT result = GW_RESULT_INVALID_PARAMETER;
    ListItem *currItem = NULL;
    queue_node_t *currNode = NULL;
    uint32_t size = 0;
    if (item == NULL) {
        GWLOG(LOG_ERR, "invalid parameter node");
        return result;
    }
    if(is_queue_empty(&(gAuthCtx.resourceList)) == true) {
        GWLOG(LOG_ERR, "internal resourceList is empty, was there a start?");
        return result;
    }

    // Get the Head node of the list
    currNode = get_head_node(&(gAuthCtx.resourceList));
    // Head node will not have content, get the next node
    currNode = get_next_node(currNode);
    while (currNode != NULL) {
        // Peak into the content of the node
        currItem = (ListItem *)get_buffer_from_node(currNode, &size);
        if (currItem == NULL) {
            GWLOG(LOG_ERR, "get_buffer_from_node returned NULL item.");
            result = GW_RESULT_INTERNAL_ERROR;
            break;
        }
        if (size != sizeof(ListItem)) {
            GWLOG(LOG_ERR, "get_buffer_from_node returned item size %lu different from %lu ",
                (unsigned long) size, (unsigned long) sizeof(ListItem));
            result = GW_RESULT_INTERNAL_ERROR;
            break;
        }
        if (currItem->OCHandle == handle) {
            *item = currItem;
            result = GW_RESULT_OK;
            break;
        }
        // Get the next node
        currNode = get_next_node(currNode);
    }

    if (GW_RESULT_OK != result) {
        GWLOG(LOG_ERR, "No matching ListItem found.");
    }
    return result;
}

/*
 * Find the ListItem node in the resource list matching the Auth handle
 * This function does not remove the node from the list
 */
GW_RESULT getListNodeFromAuthHandle(AuthHandle handle, queue_node_t **node)
{
    GW_RESULT result = GW_RESULT_INVALID_PARAMETER;
    ListItem *currItem = NULL;
    queue_node_t *currNode = NULL;
    uint32_t size = 0;
    if (node == NULL) {
        GWLOG(LOG_ERR, "invalid parameter node");
        return result;
    }
    if(is_queue_empty(&(gAuthCtx.resourceList)) == true) {
        GWLOG(LOG_ERR, "internal resource list is empty, was there a start");
        return result;
    }
    // Get the Head node of the list
    currNode = get_head_node(&(gAuthCtx.resourceList));
    // Head node will not have content, get the next node
    currNode = get_next_node(currNode);
    while (currNode != NULL) {
        // Peak into the content of the node
        currItem = (ListItem *)get_buffer_from_node(currNode, &size);
        if ((currItem == NULL) || (size != sizeof(ListItem))) {
            GWLOG(LOG_ERR, "FATAL: bad object %d, %d", currItem, size);
            result = GW_RESULT_INTERNAL_ERROR;
            break;
        }
        if (currItem->handle == handle) {
            *node = currNode;
            result = GW_RESULT_OK;
            break;
        }
        // Get the next node
        currNode = get_next_node(currNode);
    }
    return result;
}

/**
 * Initialize the Authorization module. Must be called prior to
 * calling start to allocate all the memory/resources/context
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_CREATED_FAILED - auth create error
 *    GW_RESULT_ALREADY_CREATED- auth create has already been called
 */
GW_RESULT authModuleCreate()
{
    GW_RESULT result = GW_RESULT_DUPLICATE_API_CALL;
    if (gAuthCtx.state != AUTH_NOT_CREATED) {
        GWLOG(LOG_ERR, " Already created ");
        return result;
    }

    // initialize oauth handle
    resetHandle();

    initialize_queue(&(gAuthCtx.resourceList));

    startSlowResponseThread();

    // Add more create logic above this, below code is finalizing create
    gAuthCtx.state = AUTH_CREATED;
    result = GW_RESULT_OK;
    return result;
}

/**
 * Start a specific authorization method with unique context
 * which is represented by a specific auth resource in Iotivity
 * Multiple starts can be called by the same plugin.
 *
 * @param handle
 *    Unique id to identify this authorization context
 * @param authCtx
 *    Context of the specific authorization request made by calling start
 * @param authHandler
 *    Plugin provides a callback when a request to authorize is received
 *    from the trusted client
 * @param deauthHandler
 *    Plugin provides a callback for when a request to deauthorize is
 *    received from the trusted client
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_START_FAILED   - start failed
 */
GW_RESULT authModuleStart(AuthHandle *handle,
                          AuthModuleContext *authCtx,
                          DoAuthCallback authHandler,
                          DoDeauthCallback deauthHandler)
{
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    // Start can be called multiple times. Hence allow state = started
    if ((gAuthCtx.state != AUTH_CREATED) && (gAuthCtx.state != AUTH_STARTED)) {
        GWLOG(LOG_ERR, "Not Created yet");
        return GW_RESULT_NOT_CREATED;
    }
    if ((handle == NULL) || (authCtx == NULL) ||
        (authHandler == NULL) || (deauthHandler == NULL) ||
        (authCtx->manufacturerName == NULL) ||
        (authCtx->productName == NULL) ||
        (authCtx->authServerInfo == NULL) ||
        (authCtx->type >= AUTH_TYPE_MAX)) {
        GWLOG(LOG_ERR, "Invalid parameters");
        return GW_RESULT_INVALID_PARAMETER;
    }
    // Add a new List item to the list to represent the context
    ListItem *item = (ListItem *)malloc(sizeof(ListItem));
    if (item == NULL) {
        GWLOG(LOG_ERR, "Malloc Failed");
        goto CLEANUP;
    }
    // Always start with Zeroed out memory
    memset(item, 0, sizeof(ListItem));

    // Build the item to be queued
    item->handle = getNewHandle();
    if (buildURI(authCtx->type, item->handle, item->uri, sizeof(item->uri)) == false) {
        // Could not build the uri
        GWLOG(LOG_ERR, "URI could not be built");
        goto CLEANUP;
    }
    item->isAuthorized = false;
    item->type = authCtx->type;
    item->authCB = authHandler;
    item->deauthCB = deauthHandler;
    item->payload = (OCPayload*)buildGetPayload(authCtx,
                                    item->uri,
                                    authCtx->type);
    if (item->payload == NULL) {
        // Created payload from context failed
        GWLOG(LOG_ERR, "Bad context, failed to create payload");
        goto CLEANUP;
    }
    // TODO: figure out how to convert payload struct to string
    //GWLOG(LOG_INFO, "Payload = %s", item->payload);
    // Plugin will ensure thread safety of APIs
    // Do not lock the queue unless this assumption changes
    add_to_tail(&(gAuthCtx.resourceList), (char *)item, sizeof(ListItem));

    result = createResource(item, false);
    if (result != GW_RESULT_OK) {
        GWLOG(LOG_ERR, "Failed to createresource");
        goto CLEANUP;
    }

    // Add more start logic above this, below code is finalizing start
    if (gAuthCtx.state != AUTH_STARTED) {
        GWLOG(LOG_INFO, "First start called");
        gAuthCtx.state = AUTH_STARTED;
    }
    //return the handle back to the caller
    *handle = item->handle;

    // if we're here we succeeded.
    result = GW_RESULT_OK;
CLEANUP:
    if((GW_RESULT_OK != result) &&(item != NULL)) {
        if (item->payload != NULL) {
            free(item->payload);
            item->payload = NULL;
        }
        free(item);
        item = NULL;
    }
    return result;
}

/**
 * Stop a specific authorization method which was started at some point.
 * All started contexts must be stopped before destroy gets called.
 *
 * @param handle
 *    Unique id to identify this authorization context
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_STOP_FAILED    - stop failed
 *    GW_RESULT_INVALID_HANDLE - invalid handle provided
 */
GW_RESULT authModuleStop(AuthHandle handle)
{
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    queue_node_t *node = NULL;
    ListItem *item = NULL;
    if (gAuthCtx.state == AUTH_CREATED) {
        GWLOG(LOG_ERR, "Not been started yet");
        return GW_RESULT_NOT_STARTED;
    }
    result = getListNodeFromAuthHandle(handle, &node);
    if ((result != GW_RESULT_OK) || (node == NULL)) {
        GWLOG(LOG_ERR, "Invalid handle, item not found");
        result = GW_RESULT_INVALID_HANDLE;
        goto CLEANUP;
    }
    // remove the item from the list
    remove_from_middle(node, (void **)&item);
    if (item == NULL) {
        GWLOG(LOG_ERR, "List err, no item for the node");
        result = GW_RESULT_INTERNAL_ERROR;
        goto CLEANUP;
    }

    result = destroyResource(item);

CLEANUP:
    //Even if stop fails this is a good opportunity to reset the state
    if (is_queue_empty(&(gAuthCtx.resourceList))) {
        // All the resources have been stopped go back to created state
        gAuthCtx.state = AUTH_CREATED;
    }
    if (item != NULL) {
        free(item);
        item = NULL;
    }
    return result;
}

/**
 * Deinitializes the Authorization module. Must be called after
 * calling stop to free all the memory/resources/context
 *
 * @return
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_DESTROY_FAILED - auth destroy error
 */
GW_RESULT authModuleDestroy()
{
    uint32_t size = 0;
    ListItem *item = NULL;
    if (gAuthCtx.state == AUTH_STARTED) {
        GWLOG(LOG_INFO, "Some resources have not been stopped yet. Emptying queue.");
        while (is_queue_empty(&(gAuthCtx.resourceList)) == false) {
            item = (ListItem *)remove_from_head(&(gAuthCtx.resourceList), &size);
            if ((item == NULL) || (size == 0)) {
                GWLOG(LOG_ERR, "FATAL: The resource list has a bad object");
                break;
            }
            // This can only fail in queueing up the destroy resource request
            // to plugin queue. Log that failure
            destroyResource(item);
            free(item);
        }
    }

    gAuthCtx.stayInProcessLoop = false;

    //Free requests
    pthread_mutex_lock(&request_queue_lock);
    if (!gRequestList.empty())
    {
        for(std::list<EntityHandlerRequest>::iterator iter = gRequestList.begin();
                iter != gRequestList.end(); ++iter)
        {
            // Free the request
            if((*iter).request){
                if((*iter).request->query){
                    free((*iter).request->query);
                }
                OCPayloadDestroy((*iter).request->payload);
                free((*iter).request);
            }
        }
        gRequestList.clear();
    }
    pthread_mutex_unlock(&request_queue_lock);

    pthread_mutex_destroy(&request_queue_lock);

    // Reset the handle to 0 before exiting
    resetHandle();
    memset(&gAuthCtx, 0, sizeof(PluginAuthCtx));
    // Even though the whole ctx is memset need to set the state
    gAuthCtx.state = AUTH_NOT_CREATED;
    // Destroy always returns OK
    return GW_RESULT_OK;
}

/* Helper functions for the entity handler */
GW_RESULT convertPayloadToCtx(AuthModuleContext* ctx, OCPayload* input)
{
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    bool ret = false;
    OCRepPayload* payload = NULL;
    AuthMethodType authType = AUTH_TYPE_UNDEFINED;

    // indicate what kind of context we're working with
    GWLOG(LOG_INFO, "Converting payload to context");

    if (!input || input->type != PAYLOAD_TYPE_REPRESENTATION) {
        GWLOG(LOG_ERR, "Input payload is invalid.");
        goto CLEANUP;
    }

    payload = (OCRepPayload*)input;
    if (!payload) {
        GWLOG(LOG_ERR, "Payload is NULL");
        goto CLEANUP;
    }

    if (NULL == ctx) {
        GWLOG(LOG_ERR, "ctx is null");
        goto CLEANUP;
    }

    authType = uriToAuthMethodType(payload->uri);
    if (AUTH_TYPE_UNDEFINED == authType) {
        GWLOG(LOG_ERR, "authType came back AUTH_TYPE_UNDEFINED");
        goto CLEANUP;
    }

    if ((AUTH_TYPE_PBC == authType) || (AUTH_TYPE_2FA == authType)) {
        ret = OCRepPayloadGetPropString(payload, "id", &(ctx->authServerInfo));
        if ((false == ret) || (NULL == ctx->authServerInfo)) {
            GWLOG(LOG_ERR, "No id in representation");
            goto CLEANUP;
        }
    }

    ret = OCRepPayloadGetPropString(payload, "aurl", &ctx->authCtx.PBCCtx.authUrl);
    if ((false == ret) || (NULL == ctx->authCtx.PBCCtx.authUrl)) {
        GWLOG(LOG_ERR, "No aurl in representation");
        goto CLEANUP;
    }

    ret = OCRepPayloadGetPropString(payload, "mnmm", &ctx->manufacturerName);
    if ((false == ret) || (NULL == ctx->manufacturerName)) {
        GWLOG(LOG_ERR, "No mnmm in representation");
        goto CLEANUP;
    }

    ret = OCRepPayloadGetPropString(payload, "pn", &ctx->productName);
    if ((false == ret) || (NULL == ctx->productName)) {
        GWLOG(LOG_ERR, "No pn in representation");
        goto CLEANUP;
    }

    // save authType.
    ctx->type = authType;

    // if we're here it was successful.
    result = GW_RESULT_OK;

CLEANUP:

    return result;
}

GW_RESULT addResponseWorkItem(OCRepPayload *payload,
                                   OCEntityHandlerRequest *EHRequest,
                                   OCEntityHandlerResult OCresult)
{
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;

    if (NULL == EHRequest) {
        GWLOG(LOG_ERR, "EHRequest cannot be NULL");
        return result;
    }

    OCEntityHandlerResponse response;
    // build the response
    response.requestHandle = EHRequest->requestHandle;
    response.resourceHandle = EHRequest->resource;
    response.ehResult = OCresult;
    response.payload = (OCPayload*)payload;
    response.numSendVendorSpecificHeaderOptions = 0;
    memset(response.sendVendorSpecificHeaderOptions, 0,
           sizeof(response.sendVendorSpecificHeaderOptions));
    memset(response.resourceUri, 0, sizeof(response.resourceUri));
    // Indicate that response is NOT in a persistent buffer
    response.persistentBufferFlag = 0;
    result = add_work_item(NULL, WORK_ITEM_DO_RESPONSE, NULL, NULL, NULL, NULL, &response);

    if(result != GW_RESULT_OK){
        GWLOG(LOG_ERR, "Failed to add work item");
    }
    return result;
}


void deauthRequest(ListItem *resItem,
    OCEntityHandlerRequest *EHRequest)
{
    ListItem *parentItem = NULL;
    ListItem *item = NULL;
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    AuthModuleContext authCtx;
    queue_node_t *node = NULL;
    OCRepPayload *responsePayload = NULL;
    if (resItem == NULL) {
        GWLOG(LOG_ERR, "invalid param resource item");
        return;
    }
    parentItem = resItem->parentItem;
    result = convertPayloadToCtx(&authCtx, parentItem->payload);
    if (result != GW_RESULT_OK) {
        GWLOG(LOG_ERR, "Internal parsing of the context string failed");
        return;
    }
    // Call the deauthorize callback of the plugin
    result = resItem->deauthCB(parentItem->handle, &authCtx, CLIENT_ID);
    if (result != GW_RESULT_OK) {
        GWLOG(LOG_ERR, "DeAuthorization failed in the plugin");
    }

    // Even if the deauthorization fails in the plugin, cannot ignore
    // Client's explicit request to deauth. Hence deleting resources.
    getListNodeFromAuthHandle(resItem->handle, &node);

    // remove the item from the list
    remove_from_middle(node, (void **)&item);
    if (item->handle != resItem->handle) {
        GWLOG(LOG_ERR, "Un-expected error, but continue");
    }
    result = destroyResource(resItem);
    if (result != GW_RESULT_OK) {
        GWLOG(LOG_ERR, "Destroy resource failed");
    }
    //Deauth happened the auth_ctx ID is invalid now
    if (EHRequest->method == OC_REST_PUT) {
        // For PUT response the id should be empty
        responsePayload = buildPayloadForAuth(&authCtx, resItem->uri, "");
    } else {
        // For DELETE response no representation is passed to the client
        // Hence passing NULL for the id param to buildPayload func
        responsePayload = buildPayloadForAuth(&authCtx, resItem->uri, NULL);
    }

    addResponseWorkItem(responsePayload, EHRequest, OC_EH_OK);

    // There is only one client and it has been de-authorized
    // TODO: undo this with multi-client support
    parentItem->isAuthorized = false;
    if (resItem != NULL) {
        free(resItem);
    }
    return;
}

GW_RESULT getPutRequestAuthData(AuthModuleContext* ctx, OCPayload* input)
{
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    bool pbc = false;
    bool ret = false;
    OCRepPayload* payload = NULL;

    if (!input || input->type != PAYLOAD_TYPE_REPRESENTATION) {
        GWLOG(LOG_ERR, "Input payload is invalid");
        goto CLEANUP;
    }

    payload = (OCRepPayload*)input;
    if (!payload) {
        GWLOG(LOG_ERR, "Payload is NULL");
        goto CLEANUP;
    }

    if (NULL == ctx) {
        GWLOG(LOG_ERR, "ctx is null");
        goto CLEANUP;
    }

    switch(ctx->type) {
    case AUTH_TYPE_PBC:
        ret = OCRepPayloadGetPropBool(payload, "pbc", &pbc);
        if (ret == false) {
            GWLOG(LOG_ERR, "No pbc in representation");
            goto CLEANUP;
        }
        break;
    case AUTH_TYPE_OAUTH:
        ret = OCRepPayloadGetPropString(payload, "acode", &ctx->authCtx.oAuthCtx.code);
        if (ret == false) {
            GWLOG(LOG_ERR, "No acode in representation");
            goto CLEANUP;
        }
        break;
    case AUTH_TYPE_2FA:
        // TODO: Add support for 2FA here
        GWLOG(LOG_WARNING, "Add support for 2FA here");
        //break;
    default:
        GWLOG(LOG_ERR, " Unknown authorization method type");
        goto CLEANUP;
    }
    result = GW_RESULT_OK;
CLEANUP:
    return result;
}

GW_RESULT authorizePutRequest(ListItem* resItem, OCEntityHandlerRequest* EHRequest)
{
    GWLOG(LOG_INFO, "authorizePutRequest EHRequest %s", resItem->uri);

    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    OCEntityHandlerResult ocResult = OC_EH_ERROR;
    AuthModuleContext authCtx;

    OCRepPayload *putResponse = NULL;
    char id[MAX_ID_SIZE] = "";
    ListItem *authItem = NULL;

    if ((NULL == EHRequest) || (NULL == resItem)) {
        GWLOG(LOG_ERR, "Invalid input param");
        return result;
    }
    if (NULL == EHRequest->payload) {
        GWLOG(LOG_ERR, "EHRequest->payload is NULL");
        return result;
    }
    // initialize the auth context with data from the list item.
    // this won't contain all the necessary auth details yet.
    result = convertPayloadToCtx(&authCtx, resItem->payload);
    if (result != GW_RESULT_OK) {
        GWLOG(LOG_ERR, "convertStringToCtx (1) failed");
        return result;
    }

    result = getPutRequestAuthData(&authCtx, EHRequest->payload);
    if (GW_RESULT_OK != result) {
        GWLOG(LOG_ERR, "Put request does not have valid auth data");
        return result;
    }

    // Call the authorize callback of the plugin
    GWLOG(LOG_INFO, "Checking resItem->authCB...");
    result = resItem->authCB(resItem->handle, &authCtx, CLIENT_ID);
    if (result != GW_RESULT_OK) {
        GWLOG(LOG_ERR, "Authorization failed in the plugin");
        goto CLEANUP;
    } else {
        GWLOG(LOG_INFO, "Authorization in plugin return success");
        // Generate a new id for this transaction
        srand(time(NULL));
        snprintf(id, MAX_ID_SIZE, "%d", rand());

        // Add a new List item to the list to represent the context
        authItem = (ListItem*)malloc(sizeof(ListItem));
        if (authItem == NULL) {
            GWLOG(LOG_ERR, "Malloc Failed");
            result = GW_RESULT_INTERNAL_ERROR;
            return result;
        }
        // Always start with Zeroed out memory
        memset(authItem, 0, sizeof(ListItem));
        // Build the authItem to be queued
        authItem->handle = getNewHandle();
        if (buildURIForAuth(authItem->handle, authItem->uri) == false) {
            // Could not build the uri
            GWLOG(LOG_ERR, "URI could not be built");
            goto CLEANUP;
        }
        authItem->isAuthorized = false;
        authItem->authCB = resItem->authCB;
        authItem->deauthCB = resItem->deauthCB;

        authItem->payload =
            (OCPayload*)buildPayloadForAuth(&authCtx, authItem->uri, id);
        if (authItem->payload == NULL) {
            // Created payload from context failed
            GWLOG(LOG_ERR, "Bad context, failed to create payload");
            goto CLEANUP;
        }
        result = createResource(authItem, true);
        if (result != GW_RESULT_OK) {
            GWLOG(LOG_ERR, "Failed to create the Auth resource");
            goto CLEANUP;
        }
        authItem->parentItem = resItem;
        authItem->isAuthResource = true;
        add_to_tail(&(gAuthCtx.resourceList), (char*)authItem, sizeof(ListItem));
        ocResult = OC_EH_OK;
    }

    // Use Auth Item's get string as the put response of the resource item
    // The only difference is the uri
    putResponse = buildPayloadForAuth(&authCtx, resItem->uri, id);

    resItem->isAuthorized = true;
    result = GW_RESULT_OK;


CLEANUP:
    result = addResponseWorkItem(putResponse, EHRequest, ocResult);

    if ((GW_RESULT_OK != result) && authItem != NULL) {
        if (authItem->payload != NULL) {
            free(authItem->payload);
            authItem->payload = NULL;
        }
        free(authItem);
        authItem = NULL;
    }

    return result;
}


OCEntityHandlerResult
handleOCRequests(OCEntityHandlerFlag flag, OCEntityHandlerRequest* EHRequest)
{
    OCEntityHandlerResult ehResult = OC_EH_ERROR;
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;

    ListItem *resourceItem = NULL;

    if (EHRequest == NULL) {
        GWLOG(LOG_ERR, "Null entityHandlerRequest");
        return ehResult;
    }

    // Dump request info
    GWLOG(LOG_INFO, "EHRequest resource: %lu", (unsigned long)EHRequest->resource);
    GWLOG(LOG_INFO, "EHRequest requestHandle: %lu", (unsigned long)EHRequest->requestHandle);
    GWLOG(LOG_INFO, "EHRequest method: %lu", (unsigned long)EHRequest->method);
    translateOcMethod(EHRequest->method);
    if (NULL == EHRequest->query) {
        GWLOG(LOG_INFO, "EHRequest query is NULL");
    }
    else {
        GWLOG(LOG_INFO, "EHRequest query: %s", (unsigned long)EHRequest->query);
    }
    GWLOG(LOG_INFO,
          "EHRequest numRcvdVendorSpecificHeaderOptions: %lu",
          (unsigned long)EHRequest->numRcvdVendorSpecificHeaderOptions);
    if (NULL == EHRequest->payload) {
        GWLOG(LOG_INFO, "EHRequest payload is NULL");
    }

    // Retrieve listitem associated with request handle (EHRequest->resource)
    result = getListNodeFromOCHandle(EHRequest->resource, &resourceItem);
    if ((result != GW_RESULT_OK) || (resourceItem == NULL)) {
        GWLOG(LOG_ERR, "Could not find the resource in the internal list");
        return ehResult;
    }

    // Check whether request or observe.
    if (flag & OC_REQUEST_FLAG) {
        GWLOG(LOG_INFO, "Got a request on resource %s", resourceItem->uri);

        // Check which method this request represents.
        if (OC_REST_GET == EHRequest->method) {
            GWLOG(LOG_INFO, "Got a GET request from the client");

            addResponseWorkItem((OCRepPayload *)resourceItem->payload, EHRequest,OC_EH_OK);

            ehResult = OC_EH_OK;
        }
        else if (OC_REST_PUT == EHRequest->method) {
            GWLOG(LOG_INFO, "Got a PUT request from the client");

            // Put on auth_ctx resource implies deauthorization req
            // Put on PBC/OAUTH/2FA implies authorization req
            if ((strstr(resourceItem->uri, AUTH_CTX_URI) != NULL) && (resourceItem->parentItem != NULL) &&
                (resourceItem->isAuthResource == true)) {
                // This is an auth_ctx resource, Do Deauthorization
                GWLOG(LOG_INFO, "PUT on an auth resource");
                // Deauth can never fail
                deauthRequest(resourceItem, EHRequest);
                ehResult = OC_EH_OK;
            }
            else {
                result = authorizePutRequest(resourceItem, EHRequest);
                if (result == GW_RESULT_OK) {
                    ehResult = OC_EH_OK;
                    GWLOG(LOG_INFO, "Successfully authorized the bridge");
                }
                else {
                    GWLOG(LOG_ERR, "The bridge could not be authorized");
                }
            }
        }
        else if (OC_REST_DELETE == EHRequest->method) {
            GWLOG(LOG_INFO, "Got a delete request from the client %s", resourceItem->uri);
            if ((strstr(resourceItem->uri, AUTH_CTX_URI) != NULL) && (resourceItem->parentItem != NULL) &&
                (resourceItem->isAuthResource == true)) {
                // This is an auth_ctx resource, Do Deauthorization
                GWLOG(LOG_INFO, "Put on an auth resource");
                // Deauth can never fail
                deauthRequest(resourceItem, EHRequest);
                ehResult = OC_EH_OK;
            }
            else {
                GWLOG(LOG_ERR, "Cannot do delete on %s, disallowed", resourceItem->uri);
                ehResult = OC_EH_ERROR;
            }
        }
        else {
            GWLOG(LOG_ERR, "unsupported method %d", EHRequest->method);
        }
    }
    else {
        // TODO: Add observe/presence code here
        GWLOG(LOG_ERR, "Unable to handle this flag at this point 0x%x", flag);
    }

    GWLOG(LOG_INFO, "return Entity handler: %d", ehResult);
    return ehResult;
}

OCEntityHandlerRequest *copyRequest(OCEntityHandlerRequest *entityHandlerRequest)
{
    if (entityHandlerRequest == NULL){
        return NULL;
    }

    OCEntityHandlerRequest *copyOfRequest =
            (OCEntityHandlerRequest *)malloc(sizeof(OCEntityHandlerRequest));

    if (copyOfRequest != NULL)
    {
        memcpy(copyOfRequest, entityHandlerRequest, sizeof(OCEntityHandlerRequest));

        if (entityHandlerRequest->query)
        {
            copyOfRequest->query = (char *) malloc(
                    strlen((const char *)entityHandlerRequest->query) + 1);

            strncpy((char *)copyOfRequest->query,
                    (const char *)entityHandlerRequest->query,
                    strlen((const char *)entityHandlerRequest->query) + 1);

            GWLOG(LOG_INFO, "copyRequest query %s , new query ", entityHandlerRequest->query, copyOfRequest->query);
        }

        if (entityHandlerRequest->payload)
        {
            //TODO verify it's ok to do memory wise
            copyOfRequest->payload = reinterpret_cast<OCPayload*>
            (OCRepPayloadClone ((OCRepPayload*) entityHandlerRequest->payload));
        }

        // Ignore vendor specific header options for example
        copyOfRequest->numRcvdVendorSpecificHeaderOptions =
                entityHandlerRequest->numRcvdVendorSpecificHeaderOptions;
        copyOfRequest->rcvdVendorSpecificHeaderOptions =
                entityHandlerRequest->rcvdVendorSpecificHeaderOptions;
    }
    else
    {
        GWLOG(LOG_ERR, "Error copying request");
    }
    return copyOfRequest;
}

/* One Entity Handler for all the authorization resources */
OCEntityHandlerResult authEntityHandlerCB (
        OCEntityHandlerFlag flag,
        OCEntityHandlerRequest *entityHandlerRequest,
        void* callbackParam)
{
    (void) callbackParam;

    if (entityHandlerRequest == NULL){
        return OC_EH_ERROR;
    }

    if(OC_REST_PUT == entityHandlerRequest->method)
    {
        // Make deep copy of received request and queue it for slow processing
        OCEntityHandlerRequest *request = copyRequest(entityHandlerRequest);

        if (request)
        {
            GWLOG(LOG_INFO, "Scheduling slow response for received request");
            EntityHandlerRequest fullRequest;
            fullRequest.request = request;
            fullRequest.flag = flag;
            pthread_mutex_lock(&request_queue_lock);
            //push request in the queue along with the request flag for slow response processing
            gRequestList.push_back(fullRequest);
            pthread_mutex_unlock(&request_queue_lock);
            // Indicate to the stack that this is a slow response
            return OC_EH_SLOW;
        }
        else
        {
            GWLOG(LOG_ERR, "Error queuing request for slow response");
            // Indicate to the stack that this is a slow response
            return OC_EH_ERROR;
        }
    }
    else{
        //do not queue for all requests just for put requests
        return handleOCRequests(flag, entityHandlerRequest);
    }

    return OC_EH_OK;
}

bool isValidResourceType(const char* RT, AuthMethodType *MT)
{
    bool result = false;
    if (NULL == MT) {
        GWLOG(LOG_ERR, "MT cannot be NULL");
        return false;
    }

    *MT = AUTH_TYPE_UNDEFINED;

    if (NULL != RT) {
        if (NULL != strstr(RT_OAUTH, RT)) {
            *MT = AUTH_TYPE_OAUTH;
            result = true;
        }
        else if (NULL != strstr(RT_PBC, RT)) {
            *MT = AUTH_TYPE_PBC;
            result = true;
        }
        else if (NULL != strstr(RT_TWOFA, RT)) {
            *MT = AUTH_TYPE_2FA;
            result = true;
        }
        else if (NULL != strstr(AUTH_RES_TYPE, RT)) {
            // return success, but no associated AuthMethodType.
            result = true;
        }
        else {
            GWLOG(LOG_WARNING, "%s is an unknown resource type", RT);
        }
    }

    return result;
}

AuthMethodType uriToAuthMethodType(const char *uri)
{
    AuthMethodType result = AUTH_TYPE_UNDEFINED;
    char* localUri = NULL;
    size_t uriLen = 0;
    char* curToken = NULL;

    // uri in format /a/resourcetype/1
    if (NULL == uri) {
        GWLOG(LOG_ERR, "uri is NULL");
        goto CLEANUP;
    }

    uriLen = strlen(uri);
    if (0 == uriLen) {
        GWLOG(LOG_ERR, "uri is 0-length");
        goto CLEANUP;
    }

    localUri = (char*)malloc(uriLen + 1);
    if (NULL == localUri) {
        GWLOG(LOG_ERR, "malloc failed");
        goto CLEANUP;
    }

    if (NULL == strncpy(localUri, uri, uriLen + 1)) {
        GWLOG(LOG_ERR, "strncpy failed");
        goto CLEANUP;
    }

    // get and discard first token
    curToken = strtok(localUri, "/");
    if (NULL == curToken) {
        GWLOG(LOG_ERR, "strtok 1 failed");
        goto CLEANUP;
    }

    // get and check second token
    curToken = strtok(NULL, "/");
    if (NULL == curToken) {
        GWLOG(LOG_ERR, "strtok 2 failed");
        goto CLEANUP;
    }

    if (false == isValidResourceType(curToken, &result)) {
        GWLOG(LOG_ERR, "isValidResourceType returned false");
        goto CLEANUP;
    }

    // If we're here, the result code will have been set by isValidResourceType
    // just checking here for log purposes
    if (AUTH_TYPE_UNDEFINED == result) {
        GWLOG(LOG_WARNING, "result came back AUTH_TYPE_UNDEFINED");
    }

    CLEANUP:
    if (NULL != localUri) {
        free(localUri);
    }
    return result;
}

uint32_t translateOcMethod(const OCMethod ocMethod) {
    uint32_t result = (uint32_t) ocMethod;
    char curMethod[64] = {0};
    char outputLine[128];

    switch (ocMethod) {
        case OC_REST_NOMETHOD :
            strncpy(curMethod, "OC_REST_NOMETHOD", sizeof(curMethod));
            break;
        case OC_REST_GET :
            strncpy(curMethod, "OC_REST_GET", sizeof(curMethod));
            break;
        case OC_REST_PUT :
            strncpy(curMethod, "OC_REST_PUT", sizeof(curMethod));
            break;
        case OC_REST_POST :
            strncpy(curMethod, "OC_REST_POST", sizeof(curMethod));
            break;
        case OC_REST_DELETE :
            strncpy(curMethod, "OC_REST_DELETE", sizeof(curMethod));
            break;
        case OC_REST_OBSERVE :
            strncpy(curMethod, "OC_REST_OBSERVE", sizeof(curMethod));
            break;
        case OC_REST_OBSERVE_ALL :
            strncpy(curMethod, "OC_REST_OBSERVE_ALL", sizeof(curMethod));
            break;
        case OC_REST_CANCEL_OBSERVE :
            strncpy(curMethod, "OC_REST_CANCEL_OBSERVE", sizeof(curMethod));
            break;
        case OC_REST_PRESENCE :
            strncpy(curMethod, "OC_REST_PRESENCE", sizeof(curMethod));
            break;
        default :
            strncpy(curMethod, "(unknown method)", sizeof(curMethod));
            break;
    }

    snprintf(outputLine, 128, "ocMethod %lu = %s", (unsigned long) ocMethod, curMethod);
    GWLOG(LOG_INFO, outputLine);
    return result;

}
