/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

/* This file contains the "C" plugin interface implementation */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <spawn.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/select.h>
#include <sys/types.h>
#include <sys/wait.h>

#define LOG_TAG "PI_IF"
#include "gwlog.h"
#include "gw_error_code.h"
#include "plugin_if.h"
#include "plugin_server.h"

#ifdef __cplusplus
extern "C"
{
#endif

void wait_for_child_process_to_complete(pid_t child_pid, int32_t timeout);
void timed_wait_for_pipe_write(int32_t fd_to_parent, char *message,
                               uint32_t message_size, int32_t timeout);

/*  The purpose of this function is to create a context or instance of the
 *  plugin.  There is nothing stopping one from creating more than one
 *  instance of the plugin.  Currently it is expected that only one instance
 *  is created.
 *
 *  input - ppm_ctx is the protocol plugin manager's context representing
 *          this instance of this plugin.  Any calls from this instance must
 *          use this context when addressing the protocol plugin manager.
 *
 *  output - a pointer to the context data of this plugin that is managed
 *           by this plugin.
 */
static void *create(cp_context_t *ppm_ctx)
{
        /* always try to create a new instance */
        common_plugin_ctx_t *ctx = (common_plugin_ctx_t *)malloc(sizeof(common_plugin_ctx_t));

        if (ctx != NULL) {
                memset(ctx, 0, sizeof(common_plugin_ctx_t));
                ctx->ppm_ctx = ppm_ctx;
        } else {
                GWLOG(LOG_ERR,"Unable to allocate context.");
        }
        return ctx;
}

/*  This function forks a new process and starts an OIC server in that
 *  process.  The plan is to only allow one forked thread per instance of
 *  the plugin.  There is a check for this, the start will fail if you
 *  call start twice on the same instance.
 *
 *  input - plugin_ctx - the protocol plugin manager hands back the plugin
 *          context created with the "create" function
 *
 *  returns - 0 for success
 *            1 for error
 */
static int start(void *plugin_ctx)
{
        pid_t pid;
        int result = 1;
        common_plugin_ctx_t *ctx = (common_plugin_ctx_t *)plugin_ctx;

        /* IPC message variable */
        char message[PLUGIN_MESSAGE_SIZE];
        int32_t timeout = TIMEOUT_VAL_IN_SEC;

        memset(message, 0, PLUGIN_MESSAGE_SIZE);

        if (ctx && (ctx->started == 0)) {

                /* Create unnamed pipes for IPC prior to the fork so that both
                 * parent and child have the same information on the unnamed
                 * pipes.
                 */
                int32_t parent_result = pipe(&(ctx->parent_reads_fds.read_fd));
                int32_t child_result =  pipe(&(ctx->child_reads_fds.read_fd));

                if ((-1 != parent_result)&&(-1 != child_result)) {

                        switch(pid =fork()) {
                        case 0:
                                /* This code path is ONLY executed in the child
                                 * process.  The  expectation is that the main
                                 * thread of the child process will not return for
                                 * quite a while.
                                 */

                                /* Close unused edges of unnamed pipes from the
                                 * child's perspective.  (i.e. child is not going
                                 * write to the child's read pipe nor is the child
                                 * going to read from the parent's read pipe
                                 */
                                close(ctx->child_reads_fds.write_fd);
                                close(ctx->parent_reads_fds.read_fd);

                                /* Start the OIC server */
                                plugin_service(ctx);

                                GWLOG(LOG_INFO,"Child process complete.");

                                /* Let's close the other sides of the pipes from
                                 * the child's perspective
                                 */
                                close(ctx->child_reads_fds.read_fd);
                                close(ctx->parent_reads_fds.write_fd);

                                exit(0);
                        break;
                        default:
                                /* This is the parent process who just forked a
                                 * child process.
                                 */
                                ctx->child_pid = pid;

                                /* Like was done with the child process let's do
                                 * the same for the parent process.   Close the
                                 * unused sides of the pipes from parents perspective.
                                 * With this case the parent is not going to read
                                 * from the child's read pipe and the parent is not
                                 * going to write the parents read pipe.
                                 */
                                close(ctx->child_reads_fds.read_fd);
                                close(ctx->parent_reads_fds.write_fd);

                                /* The plugin may fail to create or fail to start.
                                 * The parent must wait here for a length of time to
                                 * learn what happened.  The wait time is short, on the
                                 * order of TIMEOUT_VAL_IN_SEC seconds.  If the plugin finishes
                                 * create and start early then the wait will be
                                 * much shorter.
                                 */
                                timed_wait_for_pipe_write(ctx->parent_reads_fds.read_fd,
                                                          message, PLUGIN_MESSAGE_SIZE, timeout);

                                if (strncmp(message, PLUGIN_START_COMPLETE, PLUGIN_MESSAGE_SIZE) == 0) {
                                        /* plugin was successful with it's create and start */
                                        GWLOG(LOG_INFO,"Child: %d started successfully", ctx->child_pid);
                                        result = 0;
                                        ctx->started = 1;
                                } else {
                                        /* We have a problem, and the plugin is NOT going to load.
                                         */
                                        GWLOG(LOG_ERR,"Child: %d failed, either plugin create or start.",
                                                      ctx->child_pid);

                                        GWLOG(LOG_ERR,"Forced completion of the child");

                                        /* The parent must wait here until the child process is dead.
                                         * but this time we are not going to wait, we are only going
                                         * to force completion
                                         */
                                        wait_for_child_process_to_complete(ctx->child_pid, 0);

                                        /* Lets close the rest of the pipe interfaces. Sides of the pipes
                                         * from the parents perspective
                                         */
                                        close(ctx->child_reads_fds.write_fd);
                                        close(ctx->parent_reads_fds.read_fd);
                                }
                        break;
                        case -1:
                               perror("fork");
                               GWLOG(LOG_ERR,"Fork returned error.");
                        break;
                        }

                } else {
                        GWLOG(LOG_ERR,"Plugin instance already forked or has not been created.");
                }
        } else {
                GWLOG(LOG_ERR,"Failed to create IPC unnamed pipes.");
        }
        return (result);
}


static void stop(void *plugin_ctx)
{
        common_plugin_ctx_t *ctx = (common_plugin_ctx_t *)plugin_ctx;
        int32_t timeout = TIMEOUT_VAL_IN_SEC;
        ssize_t write_size = 0;
        /* IPC message variable */
        char message[PLUGIN_MESSAGE_SIZE];

        memset(message, 0, PLUGIN_MESSAGE_SIZE);

        if (ctx && (ctx->started == 1)) {
                write_size = write(ctx->child_reads_fds.write_fd, PLUGIN_STOP_REQUEST, PLUGIN_MESSAGE_SIZE);
                if (write_size != PLUGIN_MESSAGE_SIZE) {
                        GWLOG(LOG_ERR, "Failed to write to pipe for stop");
                        return;
                }
                GWLOG(LOG_INFO,"Parent telling the child process pid: %d to stop.",ctx->child_pid);

                /* the parent must wait here until the child process is dead */
                wait_for_child_process_to_complete(ctx->child_pid, timeout);

                ctx->started = 0;
        } else {
                GWLOG(LOG_ERR,"Stop has no effect; Plugin has not been started");
        }
        return;
}


static void destroy(void *plugin_ctx)
{
        common_plugin_ctx_t *ctx = (common_plugin_ctx_t *)plugin_ctx;

        if (ctx && (ctx->started == 1)) {
                stop(ctx);
        }

        if (ctx) {
                free(ctx);
        }
}


/* this function waits for a child process to signal that it is complete
 */
void wait_for_child_process_to_complete(pid_t child_pid, int32_t timeout)
{
        int32_t waittime = 0;
        int32_t status = 0;
        int32_t wpid = 0;

        do {
                wpid = waitpid(child_pid, &status, WNOHANG);
                if (wpid == 0) {
                        if (waittime < timeout) {
                                GWLOG(LOG_INFO,"Parent waiting on child: %d second(s): %d",
                                      child_pid, waittime);
                                sleep(1);
                                waittime ++;
                        } else {
                                GWLOG(LOG_ERR,"Parent forced stopping of child: %d", child_pid);
                                kill(child_pid, SIGKILL);
                                break;
                        }
                }
        } while ((wpid == 0) && (waittime <= timeout));

        if (WIFEXITED(status)) {
                GWLOG(LOG_INFO,"Child: %d completed \"exited\" with status: %d",
                                child_pid, WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
                GWLOG(LOG_INFO,"Child: %d completed \"signaled\" with status: %d",
                                child_pid, WTERMSIG(status));
        }
}


/* this is a timed wait for pipe write; the written value is returned in the passed
 * in message buffer.
 */
void timed_wait_for_pipe_write(int32_t fd, char *msg, uint32_t msg_size, int32_t timeout)
{
        struct timeval tv;
        fd_set  fdset;
        int32_t nfd;
        int32_t waittime = 0;
        int32_t nbytes = 0;

        /* wait for 1 second on each time through the loop for up to timeout */
        tv.tv_sec = 0;
        tv.tv_usec = 0;

        if ((NULL != msg)&&(msg_size > 0)) {
                memset(msg, 0, msg_size);
                do {
                        FD_ZERO(&(fdset));
                        FD_SET(fd, &(fdset));
                        sleep(1);  /* tried to set the timeout on select and it was not reliable */
                        nfd = select(fd+1, &(fdset), NULL, NULL, &tv);
                        if (nfd == -1) {
                                perror("select error");
                                nbytes = 1;  /* break out of loop by setting this */
                        } else if (nfd) {
                                if (FD_ISSET(fd, &(fdset))) {
                                        nbytes = read(fd, msg, msg_size);
                                        GWLOG(LOG_INFO, "Message from child: %s", msg);
                                }
                        } else {
                                /* got nothing case */
                                GWLOG(LOG_INFO, "Parent waiting on child seconds(s): %d", waittime);
                        }

                        waittime++;

                } while ((nbytes == 0) && (waittime <= timeout));
        }
}


CP_EXPORT cp_plugin_runtime_t plugin_funcs =
{
    create,
    start,
    stop,
    destroy
};

#ifdef __cplusplus
}
#endif
