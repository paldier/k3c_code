/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

/* This file contains the plugin server implementation.  Most of this
 * implementation is reused for other plugins.  There is NO customization
 * required of functions in this file to accommodate plugin specific code.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#define LOG_TAG "PI_SERVER"
#include "gwlog.h"
#include "plugin_server.h"
#include "resource_list.h"

#include <iostream>

/* function prototypes */
GW_RESULT init_oic_infrastructure(common_plugin_ctx_t *ctx);
GW_RESULT maintain_oic_infrastructure(GW_RESULT result, common_plugin_ctx_t *ctx);

OCPlatformInfo platform_info;
OCDeviceInfo device_info;

const char* OC_RSRVD_INTERFACE_BASELINE = "oic.if.baseline";

//TODO Replace dummy strings below with meaningful info
const char* g_date_of_manufacture = "GW_DateOfManufacture";
const char* g_device_name = "GW_DeviceName";
const char* g_firmware_version = "GW_FirmwareVersion";
const char* g_manufacturer_name = "GW_Name";
const char* g_operating_system_version = "GW_OS";
const char* g_hardware_version = "GW_HardwareVersion";
const char* g_platform_id = "GW_PlatformID";
const char* g_manufacturer_url = "GW_ManufacturerUrl";
const char* g_model_number = "GW_ModelNumber";
const char* g_platform_version = "GW_PlatformVersion";
const char* g_support_url = "GW_SupportUrl";
const char* g_version = "GW_Version";
const char* g_system_time = "GW_Time";

extern queue_node_t g_resource_list;
extern pthread_mutex_t g_resource_list_lock;

/* Work queue used to serialize calls with Iotivity thread*/
extern pthread_mutex_t work_queue_lock;
extern queue_node_t    work_queue;

/* plugin specific context storage point.  the plugin owns the allocation
 * and freeing of its own context */
plugin_ctx_t *g_plugin_context = NULL;

//Secure Virtual Resource database for Iotivity Server
//It contains Server's Identity and the PSK credentials
//of other devices which the server trusts
static char CRED_FILE[] = "./oic_svr_db_server.json";

FILE* server_fopen(const char *path, const char *mode)
{
    (void)path;
    return fopen(CRED_FILE, mode);
}

void empty_queue(queue_node_t *queue, pthread_mutex_t *queue_lock)
{
    uint32_t size = 0;
    void *item = NULL;
    if(NULL == queue || NULL == queue_lock) {
        return;
    }
    do {
        size = 0;
        pthread_mutex_lock(queue_lock);
        if (false == is_queue_empty(queue)) {
                item = remove_from_head(queue, &size);
        }
        pthread_mutex_unlock(queue_lock);
        if ((size > 0) && (item != NULL)) {
                free(item);
        }
    } while (size > 0);
    return;
}


GW_RESULT server_init()
{
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;

    initialize_queue(&g_resource_list);
    initialize_queue(&work_queue);

    memset(&g_resource_list_lock, 0, sizeof(pthread_mutex_t));
    memset(&work_queue_lock, 0, sizeof(pthread_mutex_t));
    if (pthread_mutex_init(&g_resource_list_lock, NULL) != 0) {
            GWLOG(LOG_ERR,"Unable to initialize g_resource_list_lock.");
            return result;
    }
    if (pthread_mutex_init(&work_queue_lock, NULL) != 0) {
            GWLOG(LOG_ERR,"Unable to initialize work_queue_lock.");
            return result;
    }
    return GW_RESULT_OK;
}

GW_RESULT server_deinit()
{
    empty_queue(&g_resource_list, &g_resource_list_lock);
    empty_queue(&work_queue, &work_queue_lock);

    pthread_mutex_destroy(&g_resource_list_lock);
    pthread_mutex_destroy(&work_queue_lock);

    return GW_RESULT_OK;
}

/*
 * This is a non blocking pipe read function
 *
 * returns
 *      false - nothing was written to the pipe
 *      true - something was written to the pipe
 */
bool pipe_write_check(int32_t fd)
{
        struct timeval tv;
        fd_set  fdset;
        int32_t nfd;
        int32_t nbytes = 0;
        char msg[PLUGIN_MESSAGE_SIZE];
        bool shutdown = false;

        tv.tv_sec = 0;
        tv.tv_usec = 0;

        memset(msg, 0, PLUGIN_MESSAGE_SIZE);

        FD_ZERO(&(fdset));
        FD_SET(fd, &(fdset));
        nfd = select(fd+1, &(fdset), NULL, NULL, &tv);
        if (nfd == -1) {
                perror("select error");
        } else if (nfd) {
                if (FD_ISSET(fd, &(fdset))) {
                        nbytes = read(fd, msg, PLUGIN_MESSAGE_SIZE);
                        GWLOG(LOG_INFO, "Message from parent: %s", msg);
                        if (nbytes == PLUGIN_MESSAGE_SIZE) {
                                shutdown = true;
                        }
                }
        } else {
                /* This is the case when there is nothing in the pipe.
                 * Essentially do nothing and return false.
                 */
        }
        return (shutdown);
}


/* this function is a OIC server.  The function does not return unless there is an
 * error or this main thread was signaled by the parent process main thread.
 */
GW_RESULT plugin_service(common_plugin_ctx_t *ctx)
{
        GW_RESULT result = GW_RESULT_INTERNAL_ERROR;

        if (ctx != NULL) {

            /* initialize the OIC infrastructure to be setup for a server */
            result = init_oic_infrastructure(ctx);

            if (result == GW_RESULT_OK) {
                /* initialize the back end infrastructure or plugin specific
                 * code. If he plugin has problems with its own infrastructure
                 * such that it does NOT work, it can stop the whole process
                 * by returning a failure here.
                 */
                result = server_init();
                if(result == GW_RESULT_OK) {
                    result = plugin_create(&g_plugin_context);
                    if (result == GW_RESULT_OK) {
                        GWLOG(LOG_INFO,"Creation succeeded");
                        result = plugin_start(g_plugin_context);
                        if (result == GW_RESULT_OK) {
                                GWLOG(LOG_INFO,"Start succeeded");
                        } else {
                                GWLOG(LOG_ERR, "Start failed result: %d\n", result);
                        }
                    } else {
                        GWLOG(LOG_ERR, "Creation failed result: %d\n", result);
                    }
                }else {
                    GWLOG(LOG_ERR, "server_init failed result: %d\n", result);
                }
                /* this is a blocking function that will unblock if there is
                 * is either an error or the protocol plugin manager decides to
                 * shut this plugin down.
                 */
                result =  maintain_oic_infrastructure(result, ctx);
            } else {
                GWLOG(LOG_ERR,"init_oic_infrastructure failed");
            }
        } else {
            GWLOG(LOG_ERR,"Bad context handed to plugin server");
        }
        return (result);
}

GW_RESULT set_platform_info()
{
        if((strlen(g_manufacturer_name) > MAX_MANUFACTURER_NAME_LENGTH)
                        ||(strlen(g_manufacturer_url) > MAX_MANUFACTURER_URL_LENGTH))
        {
                GWLOG(LOG_ERR,"Manufacture name or/and url string length exceeded max length");
                return GW_RESULT_INTERNAL_ERROR;
        }

        platform_info.platformID = (char *)g_platform_id;
        platform_info.manufacturerName = (char *)g_manufacturer_name;
        platform_info.manufacturerUrl = (char *)g_manufacturer_url;
        platform_info.modelNumber = (char *)g_model_number;
        platform_info.dateOfManufacture = (char *)g_date_of_manufacture;
        platform_info.platformVersion = (char *)g_platform_version;
        platform_info.operatingSystemVersion = (char *)g_operating_system_version;
        platform_info.hardwareVersion = (char *)g_hardware_version;
        platform_info.firmwareVersion = (char *)g_firmware_version;
        platform_info.supportUrl = (char *)g_support_url;
        platform_info.systemTime = (char *)g_system_time;

        return GW_RESULT_OK;
}

GW_RESULT set_device_info()
{
        device_info.deviceName = (char *)g_device_name;
        return GW_RESULT_OK;
}


/*
 * this function initializes all the boiler plate items for the OIC server.
 * it relies strictly on the "C" layer of the OIC stack.  This is common
 * code for all plugins.
 *
 * Parameters:
 * ctx (in) - the context structure used by this implementation
 *
 * Returns:
 *     GW_RESULT_OK             - no errors
 *     GW_RESULT_INTERNAL_ERROR - initialization failure
 */
GW_RESULT init_oic_infrastructure(common_plugin_ctx_t *ctx)
{
        GW_RESULT result = GW_RESULT_INTERNAL_ERROR;

        uint16_t  port = 0;

        if (ctx != NULL) {
                /* Create the unnamed pipe listener thread that will clear the
                 * child's stay in the loop variable when the parent wants to
                 * shut down the child process.
                 */
                ctx->exit_process_loop = false;

                // Initialize Persistent Storage for SVR database
                static OCPersistentStorage ps = { server_fopen, fread, fwrite, fclose, unlink };
                OCRegisterPersistentStorageHandler(&ps);

                result = OCInit(NULL, port, OC_SERVER);
                if (result != GW_RESULT_OK) {
                        GWLOG(LOG_ERR,"OCStack init error");
                        return result;
                }

                if(set_platform_info() != GW_RESULT_OK) {
                        GWLOG(LOG_ERR,"Platform info setting failed locally!");
                        return result;
                }

                if (OCSetPlatformInfo(platform_info) != OC_STACK_OK) {
                        GWLOG(LOG_ERR,"Platform Registration failed!");
                        return result;
                }

                if(set_device_info() != GW_RESULT_OK)
                {
                        GWLOG(LOG_ERR,"Device info setting failed locally!");
                        return result;
                }

                if (OCSetDeviceInfo(device_info) != OC_STACK_OK)
                {
                        GWLOG(LOG_ERR,"Device Registration failed!");
                        return result;
                }
        }
        return GW_RESULT_OK;
}


/*
 * this function is a blocking function that hold the iotivity processing
 * loop. this OIC server relies strictly on the "C" layer of the OIC stack.
 * This is common code for all plugins.
 *
 * Parameters:
 * ctx (in) - the context structure used by this implementation
 *
 * Returns:
 *     GW_RESULT_OK             - no errors
 *     GW_RESULT_INTERNAL_ERROR - maintenance failure
 */
GW_RESULT maintain_oic_infrastructure(GW_RESULT result, common_plugin_ctx_t *ctx)
{
        ssize_t write_size = 0;
        if (ctx != NULL) {
                /* child tells status to parent prior to getting in the
                 * processing loop
                 */
                if (result == GW_RESULT_OK) {
                        write_size = write(ctx->parent_reads_fds.write_fd, PLUGIN_START_COMPLETE, PLUGIN_MESSAGE_SIZE);
                } else {
                        write_size = write(ctx->parent_reads_fds.write_fd, PLUGIN_START_COMPLETE_ERROR, PLUGIN_MESSAGE_SIZE);
                }
                if (write_size != PLUGIN_MESSAGE_SIZE) {
                        GWLOG(LOG_ERR, "Failed to write to pipe from plugin");
                        return GW_RESULT_INTERNAL_ERROR;
                }
                if (result == GW_RESULT_OK) {
                        do {
                                /* give the plugin a chance to process information on the
                                 * server thread and possibly stop the server
                                 */
                                result = plugin_process();
                                if (result != GW_RESULT_OK) {
                                        GWLOG(LOG_ERR,"Plugin process - error");
                                        break;
                                }

                                /* check to see if the loop should be terminated */
                                ctx->exit_process_loop = pipe_write_check(ctx->child_reads_fds.read_fd);

                                /* give the oc stack a chance to process information that
                                 * it may have received from the wire
                                 */
                                if(OC_STACK_OK != OCProcess()) {
                                    GWLOG(LOG_ERR,"OCprocess - error");
                                    result = GW_RESULT_INTERNAL_ERROR;
                                    break;
                                }
                        } while (ctx->exit_process_loop == false);
                }
                GWLOG(LOG_INFO,"Calling plugin_stop...........");
                result = plugin_stop(g_plugin_context);
                if (result != GW_RESULT_OK) {
                        GWLOG(LOG_ERR,"Plugin specific stop returned error");
                }
                //make sure all the work_items added in plugin_stop are processed
                if(GW_RESULT_OK == plugin_process()) {
                    if(OC_STACK_OK != OCProcess()) {
                        result = GW_RESULT_INTERNAL_ERROR;
                        GWLOG(LOG_ERR,"OCprocess - error");
                    } else {
                        sleep(THREAD_PROCESS_SLEEPTIME);
                    }
                }

                result = plugin_destroy(g_plugin_context);
                if (result != GW_RESULT_OK) {
                        GWLOG(LOG_ERR,"Plugin specific destroy returned error");
                }

                GWLOG(LOG_INFO,"Exiting ocserver main loop...");

                result = OCStop();

                if (result != GW_RESULT_OK) {
                        GWLOG(LOG_ERR,"OCStack process error");
                }
                result = server_deinit();
                if (result != GW_RESULT_OK) {
                        GWLOG(LOG_ERR,"server_deinit returned error");
                }
        } else {
                GWLOG(LOG_ERR,"Bad context handed to maintain oic infrastructure");
        }
        return (result);
}

GW_RESULT plugin_process()
{
        GW_RESULT result = GW_RESULT_OK;
        work_item_t *work_item = NULL;
        uint32_t observe_cnt = 0;
        OCResourceHandle handle = 0;
        uint32_t size = 0;

        plugin_specific_process();

        if (g_plugin_context != NULL) {
                /* empty plugin specific work queue each time this periodic
                 * function is called
                 */
                do {
                        size = 0;
                        pthread_mutex_lock(&work_queue_lock);
                        if (false == is_queue_empty(&work_queue)) {
                                work_item = (work_item_t *) remove_from_head(&work_queue, &size);
                        }
                        pthread_mutex_unlock(&work_queue_lock);
                        if ((size > 0) && (work_item != NULL)) {
                                switch (work_item->work_id) {
                                case WORK_ITEM_START_PRESENCE:
                                        GWLOG(LOG_INFO,"Starting presence.");
                                        OCStartPresence(0);
                                        break;
                                case WORK_ITEM_CREATE_RESOURCE:
                                        GWLOG(LOG_INFO,"Creating resource:%s", work_item->uri);

                                        result = OCCreateResource(&(handle), work_item->resource_type,
                                                work_item->resource_interface_name, work_item->uri,
                                                work_item->entity_handler, NULL, work_item->res_property);
                                        if (result == OC_STACK_OK) {
                                                if (work_item->handle != NULL) {
                                                    GWLOG(LOG_INFO, "adding handle = %p", work_item->handle);
                                                    // Pass the handle to caller that queued the work item
                                                    *(work_item->handle) = handle;
                                                }
                                                // Add baseline interface
                                                OCBindResourceInterfaceToResource(handle,
                                                                       OC_RSRVD_INTERFACE_BASELINE);
                                                result = add_resource(work_item->uri, handle);
                                        } else {
                                                GWLOG(LOG_ERR,"Creating resource:%s failed: %d", work_item->uri,
                                                        result);
                                                result = GW_RESULT_INTERNAL_ERROR;
                                        }
                                        break;
                                case WORK_ITEM_DESTROY_RESOURCE:
                                        handle = find_resource_from_uri(work_item->uri, &observe_cnt);
                                        if (handle != 0) {
                                                GWLOG(LOG_INFO,"Destroying resource:%s", work_item->uri);
                                                OCDeleteResource(handle);
                                                remove_resource_with_uri(work_item->uri);
                                        }
                                        break;
                                case WORK_ITEM_STOP_PRESENCE:
                                        GWLOG(LOG_INFO,"Stop presence.");
                                        OCStopPresence();
                                        break;
                                case WORK_ITEM_NOTIFY_OBSERVERS:
                                {
                                        GWLOG(LOG_INFO,"Observe received for uri=%s", work_item->uri);
                                        handle = find_resource_from_uri(work_item->uri, &observe_cnt);
                                        // Use HIGH_QOS to ensure that best attempt is made to notify observers
                                        OCNotifyAllObservers(handle, OC_HIGH_QOS);
                                        GWLOG(LOG_INFO,"Notified observers for uri=%s using HIGH_QOS", work_item->uri);
                                }
                                        break;
                                case WORK_ITEM_DO_RESPONSE:
                                {
                                        GWLOG(LOG_INFO,"Send back response = %s", work_item->response.payload);
                                        result = OCDoResponse(&(work_item->response));
                                        if (result != OC_STACK_OK) {
                                                GWLOG(LOG_ERR, "Failed to send response back %d", result);
                                                result = GW_RESULT_INTERNAL_ERROR;
                                        } else {
                                            result = GW_RESULT_OK;
                                        }
                                }
                                        break;
                                default:
                                        GWLOG(LOG_ERR,"Invalid plugin specific work queue item.");
                                        result = GW_RESULT_INTERNAL_ERROR;
                                        break;
                                }
                                free(work_item);
                        }
                } while (size > 0);
        } else {
            GWLOG(LOG_ERR, "plugin context is NULL");
            result = GW_RESULT_INTERNAL_ERROR;
        }
        return (result);
}
