/*
INTEL CONFIDENTIAL
Copyright 1996-2013 Intel Corporation All Rights Reserved.

The source code contained or described herein and all documents related to
the source code ("Material") are owned by Intel Corporation or its
suppliers or licensors.  Title to the Material remains with Intel
Corporation or its suppliers and licensors.  The Material contains trade
secrets and proprietary and confidential information of Intel or its
suppliers and licensors.  The Material is protected by worldwide copyright
and trade secret laws and treaty provisions. No part of the Material may
be used, copied, reproduced, modified, published, uploaded, posted,
transmitted, distributed, or disclosed in any way without Intel's prior
express written permission.

No license under any patent, copyright, trade secret or other intellectual
property right is granted to or conferred upon you by disclosure or
delivery of the Materials,  either expressly, by implication, inducement,
estoppel or otherwise.  Any license under such intellectual property
rights must be express and approved by Intel in writing.
*/

#include "queue.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define LOG_TAG "QUEUE"
#include "gwlog.h"
#include "gw_error_code.h"

void initialize_queue(queue_node_t * pqueue)
{
        /* It is expected that the head of a queue has it's size and buffer
         * fields set to null
         */
        if (pqueue != NULL) {
                memset(pqueue, 0, sizeof(queue_node_t));
                pqueue->next = pqueue;
                pqueue->prev = pqueue;
        } else {
          GWLOG(LOG_ERR,"Invalid queue pointer.");
        }
}

bool is_queue_empty(queue_node_t * pqueue)
{
        if ((pqueue->next == pqueue) && (pqueue->prev == pqueue)) {
                return (true);
        }
        return (false);
}

void* remove_from_head(queue_node_t * pqueue, uint32_t* size)
{
        queue_node_t * old_node;
        void *ret_buffer = NULL;
        *size = 0;

        /* If the queue is NOT empty then copy the data from the head
         * of the list into the return values of this function
         */
        if (false == is_queue_empty(pqueue)) {
                old_node = pqueue -> next;
                ret_buffer = old_node->buffer;
                *size = old_node->size;

                /* Update the pointers of the two nodes affected by this
                 * removal
                 */
                pqueue->next = old_node->next;
                pqueue->next->prev = pqueue;
                free(old_node);
        }
        return (ret_buffer);
}

void add_to_tail(queue_node_t * pqueue, char *buffer, uint32_t size)
{
        queue_node_t * prev_node;
        queue_node_t * new_node;

        /* Allocate a new node to hold the buffer pointer and the size */
        new_node = (queue_node_t *)malloc(sizeof(queue_node_t));
        if (new_node != NULL)
        {
                new_node->buffer = buffer;
                new_node->size = size;
                prev_node = pqueue->prev;

                /* Update pointers of the three nodes affected with this addition */
                pqueue->prev = new_node;
                new_node->prev = prev_node;
                new_node->next = pqueue;
                prev_node->next = new_node;
        }
}

queue_node_t *get_head_node(queue_node_t *pqueue)
{
        return (pqueue);
}

queue_node_t *get_next_node(queue_node_t *pnode)
{
        queue_node_t *next = NULL;

        if (pnode != NULL) {
                next = pnode->next;
        }
        return (next);
}

void *get_buffer_from_node(queue_node_t *pnode, uint32_t *size)
{
        void *buffer = NULL;

        if (pnode != NULL) {
                *size  = pnode->size;
                buffer = pnode->buffer;
        }

        return (buffer);
}

bool remove_from_middle(queue_node_t *pnode, void **buffer)
{
        bool removed = false;
        queue_node_t *prev;
        queue_node_t *next;

        /* make sure the node is not the top of queue */
        if ((pnode != NULL) && (pnode->size != 0)) {
                prev = pnode->prev;
                next = pnode->next;

                prev->next = next;
                next->prev = prev;

                /* strip the buffer from the node */
                *buffer = pnode->buffer;

                free (pnode);

                removed = true;
        }
        return (removed);
}
