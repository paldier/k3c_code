/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "resource_list.h"
#include "gwlog.h"
#include <pthread.h>

queue_node_t      g_resource_list;
pthread_mutex_t   g_resource_list_lock;

/* This function permits a thread safe way to add resources to the plugin
 *
 * Inputs
 * uri - string identifier associated with the resource being added
 * resource_handle - this is used to destroy the resource at a later time
 *
 * Outputs
 *     GW_RESULT_OK    - no errors
 *     GW_RESULT_INTERNAL_ERROR - error in adding item in queue
 */
GW_RESULT add_resource(const char *uri, OCResourceHandle handle)
{
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    resource_instance_t *resource_instance;

    if ((uri != NULL) && (strlen(uri) > 0)) {
        resource_instance = (resource_instance_t *) malloc(sizeof(resource_instance_t));

        if (resource_instance != NULL) {
            memset(resource_instance, 0, sizeof(resource_instance_t));
            strncpy(resource_instance->uri, uri, MAX_URI_LENGTH);
            if (strlen(uri) >= MAX_URI_LENGTH) {
                // protect against overflows
                GWLOG(LOG_WARNING, "Source URI too long. Safely terminating resource_instance->uri.");
                resource_instance->uri[MAX_URI_LENGTH - 1] = '\0';
            }
            resource_instance->resource_handle = handle;

            pthread_mutex_lock(&g_resource_list_lock);
            add_to_tail(&(g_resource_list), (char *) resource_instance, sizeof(resource_instance_t));
            pthread_mutex_unlock(&g_resource_list_lock);
            result = GW_RESULT_OK;
        }
    }
    return result;
}

/* This function removes a resource from the resource queue which may be in the
 * middle of the queue.  It cleans up the memory of the node and of the buffer.
 *
 * input
 *      uri string of the resource to remove
 *
 * output
 *      true  - if resource was removed
 *      false - if resource was not removed
 */
bool remove_resource_with_uri(const char *uri)
{
    bool removed = false;
    queue_node_t *node;
    uint32_t size;
    resource_instance_t *data;

    if ((uri != NULL) && (strlen(uri) > 0)) {
        pthread_mutex_lock(&g_resource_list_lock);
        if (false == is_queue_empty(&g_resource_list)) {
            node = get_head_node(&g_resource_list);
            node = get_next_node(node);
            data = (resource_instance_t *) get_buffer_from_node(node, &size);
            while (size > 0) {
                if (strcmp(uri, data->uri) == 0) {
                    removed = remove_from_middle(node, (void **)&data);
                    if (true == removed) {
                            free(data);
                    }
                    break;
                }
                node = get_next_node(node);
                data = (resource_instance_t *) get_buffer_from_node(node, &size);
            }
        }
        pthread_mutex_unlock(&g_resource_list_lock);
    }
    return (removed);
}

/* This function allows the resource information associated with a particular
 * resource to be located from the IoTivity handle.  The list of number of
 * resources that can be allocated is limited by the amount of memory in the
 * computing device.
 *
 * Inputs
 * handle - the Iotivity handle associated with the resource
 *
 * Outputs
 * uri - a unique identifier string associated with the device
 * observe_cnt - a pointer to the observe count so that caller can modify value
 * return value - true if found, false if not found
 */
bool find_resource(OCResourceHandle handle, char *uri, uint32_t **observe_cnt)
{
    bool found_it = false;
    queue_node_t *node;
    uint32_t size;
    resource_instance_t *data;

    if ((uri != NULL) && (handle != NULL)) {
        pthread_mutex_lock(&g_resource_list_lock);
        if (false == is_queue_empty(&g_resource_list)) {
            node = get_head_node(&g_resource_list);
            node = get_next_node(node);
            data = (resource_instance_t *) get_buffer_from_node(node, &size);
            while (size > 0) {
                if (handle == data->resource_handle) {
                    found_it = true;
                    strncpy(uri, data->uri, MAX_URI_LENGTH);
                    *observe_cnt = &(data->observe_cnt);
                    break;
                }
                node = get_next_node(node);
                data = (resource_instance_t *) get_buffer_from_node(node, &size);
            }
        }
        pthread_mutex_unlock(&g_resource_list_lock);
    }
    return found_it;
}

/* This function allows the resource information associated with a particular
 * resource to be located.  The list of number of resources that can be allocated
 * is limited by the amount of memory in the computing device.
 *
 * Inputs
 * uri - the identifier of the resource
 *
 * Outputs
 * observe_cnt - a value of the observe count (parameter style return)
 * handle - which is a return value as well.  If it is 0, it indicates that
 *          no resource was found.
 */
OCResourceHandle find_resource_from_uri(const char *uri, uint32_t *observe_cnt)
{
    OCResourceHandle handle = 0;
    queue_node_t *node;
    uint32_t size;
    resource_instance_t *data;
    if ((uri != NULL) && (strlen(uri) > 0)) {
        pthread_mutex_lock(&g_resource_list_lock);
        if (false == is_queue_empty(&g_resource_list)) {
            node = get_head_node(&g_resource_list);
            node = get_next_node(node);
            data = (resource_instance_t *) get_buffer_from_node(node, &size);
            while (size > 0) {
                if (strcmp(uri, data->uri) == 0) {
                    handle = data->resource_handle;
                    *observe_cnt = data->observe_cnt;
                    break;
                }
                node = get_next_node(node);
                data = (resource_instance_t *) get_buffer_from_node(node, &size);
            }
        }
        pthread_mutex_unlock(&g_resource_list_lock);
    }
    return handle;
}
