/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#include <stdlib.h>
#include "queue.h"
#include "work_item_queue.h"
#include "gwlog.h"

/* Work queue used to serialize calls with Iotivity thread*/
pthread_mutex_t work_queue_lock;
queue_node_t    work_queue;

/* This function permits thread-safe way to add work items to a queue that is
 * consumed by the process plugin function. The operation of this work queue is
 * similar to the operation of message queue.
 *
 * Inputs
 * ctx (obsolete)- plugin specific context structure pointer
 * work_id - unsigned integer describing the work to be done
 * uri - extra params - whos use is based on the work_id value
 * resource_type - extra params - whos use is based on work_id value
 * resource_interface_name - extra params - whos use is based on work_id value
 * entity_handler - callback function for entity_handler
 * Outputs
 *     GW_RESULT_OK    - no errors
 *     GW_RESULT_INTERNAL_ERROR - error in adding item in queue
 */
GW_RESULT add_work_item(
        plugin_ctx_t *ctx,
        uint32_t work_id,
        const char *uri,
        const char *resource_type,
        const char *resource_interface_name,
        OCEntityHandler entity_handler,
        OCEntityHandlerResponse *response,
        OCResourceHandle *handle)
{
    //TODO remove ctx in future, it's not used here anyhow
    (void)ctx;
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    work_item_t *work_item = (work_item_t *) malloc(sizeof(work_item_t));
    char* non_secure_env = NULL;
    bool non_secure_resources = false;

    if ((NULL != work_item)) {
        /* initialize the work item structure */
        memset(work_item, 0, sizeof(work_item_t));
        work_item->work_id = work_id;
        if (NULL != uri) {
                strncpy(work_item->uri, uri, MAX_URI_LENGTH);
                // KW fixes: strncpy won't terminate string if source longer than dest;
                //           subtracting 1 from actual dest buffer size (3rd parameter) only truncates
                //           the result; it doesn't guarantee termination.
                if (strlen(uri) >= MAX_URI_LENGTH) {
                    work_item->uri[MAX_URI_LENGTH - 1] = '\0';
                }
        }
        if (NULL != resource_type) {
                strncpy(work_item->resource_type, resource_type, MAX_URI_LENGTH);
                if (strlen(resource_type) >= MAX_URI_LENGTH) {
                    work_item->resource_type[MAX_URI_LENGTH - 1] = '\0';
                }
        }
        if (NULL != resource_interface_name) {
                strncpy(work_item->resource_interface_name, resource_interface_name, MAX_URI_LENGTH);
                if (strlen(resource_interface_name) >= MAX_URI_LENGTH) {
                    work_item->resource_interface_name[MAX_URI_LENGTH - 1] = '\0';
                }
        }
        work_item->entity_handler = entity_handler;

        non_secure_env = getenv("NONSECURE");
        if (NULL != non_secure_env) {
            if (0 == strcmp(non_secure_env, "true")) {
                non_secure_resources = true;
            }
        }

        // set resource properties
        work_item->res_property = OC_DISCOVERABLE | OC_OBSERVABLE;
        if (non_secure_resources) {
            GWLOG(LOG_INFO, "Preparing non-secure resource...");
        }
        else {
            GWLOG(LOG_INFO, "Preparing secure resource...");
            work_item->res_property |= OC_SECURE;
        }

        if(response != NULL) {
            memcpy(&(work_item->response), response, sizeof(OCEntityHandlerResponse));
            work_item->response.payload = response->payload;
            work_item->handle = &(response->resourceHandle);
        }

        if(handle != NULL)
        {
            work_item->handle = handle;
        }

        /* add work item to work queue */
        pthread_mutex_lock(&work_queue_lock);
        add_to_tail(&work_queue, (char *) work_item, sizeof(work_item_t));
        pthread_mutex_unlock(&work_queue_lock);

        result = GW_RESULT_OK;
    } else {
            GWLOG(LOG_ERR,"Failed to allocate and add the work item.");
    }
    return result;
}
