/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <regex.h>
#include "gw_error_code.h"
#include "hue_auth_spec.h"
#include "hue_file.h"
#include "hue_defs.h"
#include "curl_client.h"
#include "cJSON.h"
#ifdef LOG_TAG
#undef LOG_TAG
#endif
#define LOG_TAG "HUE_AUTH"
#include "gwlog.h"

/*
 * This is the global context of the Hue specific authorization module.  There
 * can only be one instance of this in a process boundary and that is the
 * case for a decoupled plugin.  So a global context is the best solution. It
 * is the only global structure required for the implementation of the Hue
 * specific authorization module.
 */
typedef struct HueAuthCtxTag
{
        bool structInitialized;

        // client called the created method
        bool created;

        // store for the client as it is opaque for the authorization module
        plugin_ctx_t *pluginCtx;

        // call back functions on the client
        HueAuthFoundBridgeCallback   foundBridge;
        HueAuthRemoveBridgeCallback  removeBridge;

        queue_node_t    discoveredList;
        pthread_mutex_t discoveredLock;
} HueAuthCtx;

/* NOTE: There is an assumption that global data structures are initialized to 0
 *       when they are loaded into memory.  If this is not the case then we are
 *       going have to figure out how to make this behavior happen.  The code
 *       depends on this structure being set to zero at the beginning of time.
 */
HueAuthCtx g_hueAuthCtx;

// Global variable for input headers on Curl operations
std::vector<std::string> g_inHeaders;

/*
 * Function Prototypes
 */
void initializeHueAuthCtx();
GW_RESULT doAuthCallback (AuthHandle handle, AuthModuleContext *authCtx, const char *clientID);
GW_RESULT doDeauthCallback (AuthHandle handle, AuthModuleContext *authCtx, const char *clientID);
GW_RESULT parseHueBridgeDiscovery(std::string response);
GW_RESULT parseOneHueBridge(char *macAddrString, char *ipAddrString);
GW_RESULT parseHueAuthResponseArray(std::string payload, HueDiscoveredCtx *discoveredCtx);
GW_RESULT parseHueAuthResponse(cJSON *object, HueDiscoveredCtx *discoveredCtx);
GW_RESULT addDiscovered(HueDiscoveredCtx *discoveredCtx);
bool findDiscoveredWithMacAddress(const char *macAddrString, HueDiscoveredCtx *discoveredCtx);
bool updateDiscoveredContext(const char *macAddrString, HueDiscoveredCtx *discoveredCtx);
bool discoveredFindClientID(HueDiscoveredCtx *discoveredCtx, const char *clientID);
bool discoveredAddClientID(HueDiscoveredCtx *discoveredCtx, const char *clientID);
bool discoveredRemoveClientID(HueDiscoveredCtx *discoveredCtx, const char *clientID);
void discoveredCompactClientIDs(HueDiscoveredCtx *discoveredCtx);

/*
 * Implementation start
 */

/*
 * The intention of this function is to register the callbacks and the
 * context pointer of the plugin.  The authorization modules needs to use the
 * work queue that is based out of the plugin context. This function must
 * only be called once at plugin startup time.
 */
GW_RESULT hueAuthCreate(plugin_ctx_t *ctx, HueAuthFoundBridgeCallback foundBridgeCb,
                        HueAuthRemoveBridgeCallback removeBridgeCb)
{
        GW_RESULT result = GW_RESULT_CREATED_FAILED;
        GWLOG(LOG_INFO, "hue_auth_spec - hueAuthCreate enter");
        initializeHueAuthCtx();

        if ((g_hueAuthCtx.created == false)&&(g_hueAuthCtx.structInitialized == true)) {
                g_hueAuthCtx.foundBridge = foundBridgeCb;
                g_hueAuthCtx.removeBridge = removeBridgeCb;
                g_hueAuthCtx.pluginCtx = ctx;
                g_hueAuthCtx.created = true;

                // put the previously authorized bridges in a file cache
                readAuthorizedBridgeFile();

                // create the general plugin authorization module
                result =  authModuleCreate();
        }
        return (result);
}

/*
 * The intention is to send a request to the Hue bridges on the network to identify
 * them.  There is no Authorization required to do a discovery of bridges in the Hue
 * case.
 *
 * This function blindly makes a request for the bridges on a network.  The
 * doGetReqest is a synchronous function call; so it may take a while.  When
 * the doGetRequest returns it has a discovery payload which is then parsed
 * by the parseHueBridgeDiscovery function.  It is in the parsing of each bridge
 * found where you will see the callbacks to either the authorize module or
 * section five.
 *
 * return
 *    GW_RESULT_OK                - no error
 *    GW_RESULT_INTERNAL_ERROR    - mechanics of sending out discovery failed
 */
GW_RESULT hueAuthDiscoverBridgesRemote()
{
        GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
        std::string response;
        CurlClient cc;
        int curlRet = 0;
        curlRet = cc.doGetRequest(BRIDGE_NUPNP_URI, g_inHeaders, response);
        if (curlRet == GW_RESULT_OK) {
                result = parseHueBridgeDiscovery(response);
        } else {
                GWLOG(LOG_ERR,"curl get failed, curlRet=%d");
        }
        return (result);
}

#define UPNP_REQUEST "M-SEARCH * HTTP/1.1\r\n" \
              "HOST: 239.255.255.250:1900\r\n" \
              "MAN: \"ssdp:discover\"\r\n" \
              "MX: 1000\r\n" \
              "ST: libhue:idl\r\n" \
              "\r\n"

/*
 * This finds all Hue Bridges in the local network by sending a multicast
 * message. No Internet connection is needed.
 *
 * The Hue Bridges are using Simple Service Discovery Protocol (SSDP) and
 * joined the multicast group 239.255.255.250. When I send a SSDP package to
 * this multicast group all Hue bridges will answer to me with a unicast
 * message containing their ID (mac address) and I get the IP address from the
 * normal IP header. Be aware that at least some Hues are answering more than
 * one time, in my testes I got 3 different answer packages, probably to work
 * with different (broken) implementations and these were send two times, each
 * with a little delay, to prevent package loses, combined I got 6 answers from
 * one Hue bridge to one request. Instead of using a library to create and
 * parse the SSDP packages, do it manually because we only want to support Hue
 * bridges and this is a simple protocol, when more features are needed using
 * a real lib would be better.
 *
 * The answer from a Hue bridge with a firmware from October 2015 looks like this:
 *
 * HTTP/1.1 200 OK
 * HOST: 239.255.255.250:1900
 * EXT:
 * CACHE-CONTROL: max-age=100
 * LOCATION: http://192.168.178.241:80/description.xml
 * SERVER: FreeRTOS/7.4.2 UPnP/1.0 IpBridge/1.10.0
 * hue-bridgeid: 001788FFFE09A206
 * ST: upnp:rootdevice
 * USN: uuid:2f402f80-da50-11e1-9b23-00178809a206::upnp:rootdevice
 *
 * source: http://www.developers.meethue.com/documentation/changes-bridge-discovery
 *
 * return
 *    GW_RESULT_OK                - no error
 *    GW_RESULT_INTERNAL_ERROR    - mechanics of sending out discovery failed
 */
GW_RESULT hueAuthDiscoverBridgesLocal()
{
        int sock;
        int err;
        ssize_t len;
        char recv_buf[500];
        struct sockaddr_in recv_addr;
        socklen_t recv_addr_len;
        struct sockaddr_in address;
        fd_set rfds;
        struct timeval tv;
        regex_t preg;
        regmatch_t pmatch_id[2];
        char err_buff[40];
        char macAddrString[17];
        int i;
        unsigned int j;
        GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
        memset(&address, 0, sizeof(sockaddr_in));

        sock = socket(AF_INET, SOCK_DGRAM, 0);
        if (sock == -1) {
                perror("socket()");
                GWLOG(LOG_ERR, "socket error");
                return GW_RESULT_INTERNAL_ERROR;
        }

        address.sin_family = AF_INET;
        address.sin_addr.s_addr = inet_addr ("239.255.255.250");
        address.sin_port = htons (1900);

        // send the request to the multicast group  239.255.255.250:1900 the
        // Hue Bridges are listening to.
        len = sendto(sock, UPNP_REQUEST, sizeof(UPNP_REQUEST), 0,
                     (struct sockaddr *)&address, sizeof(address));
        if (len == -1) {
                perror("sendto()");
                GWLOG(LOG_ERR,"sendto() error");
                goto err_close;
        }

        // Compile a regular expression to search in the answer message for the
        // Hue Bridge ID. The answer is send in a text based protocol, one
        // line is containing an uuid with the mac address at the end. This line
        // looks like this: "USN: uuid:00112233-4455-6677-8899-aabbccddeeff"
        err = regcomp(&preg,
                      "uuid:[0-9a-fA-F]*-[0-9a-fA-F]*-[0-9a-fA-F]*-[0-9a-fA-F]*-([0-9a-fA-F]*)",
                      REG_EXTENDED);
        if (err) {
                regerror(err, &preg, err_buff, sizeof(err_buff));
                GWLOG(LOG_ERR, "problem in regcomp(): %s\n", err_buff);
                goto err_close;
        }

        FD_ZERO(&rfds);
        FD_SET(sock, &rfds);

        tv.tv_sec = 3;
        tv.tv_usec = 0;

        while (1) {
                err = select(sock + 1, &rfds, NULL, NULL, &tv);
                if (err == -1) {
                        GWLOG(LOG_ERR, "error in select()");
                        goto err_regfree;
                }
                if (!FD_ISSET(sock, &rfds)) {
                        break;
                }

                // receive the answer package to the multicast request and also
                // get the address from where we received the package because
                // we also need the IP-address of the Hue bridge.
                recv_addr_len = sizeof(recv_addr);
                memset(&recv_buf, 0x0, sizeof(recv_buf));
                len = recvfrom(sock, recv_buf, sizeof(recv_buf), 0,
                               (struct sockaddr *)&recv_addr, &recv_addr_len);
                if (len == -1) {
                        GWLOG(LOG_ERR, "error in recvfrom()");
                        continue;
                }
                // use the compiled regular expression to get the Hue Bridge
                // ID, the first match is the complete line and the second
                // match is the mac address we are searching for. We store the
                // mac address in lower case, so we have to go through it char
                // by char. After it is parsed add to our internal database.
                memset(pmatch_id, 0x0, sizeof(pmatch_id));
                err = regexec(&preg, recv_buf, 2, pmatch_id, 0);
                if (err) {
                        regerror(err, &preg, err_buff, sizeof(err_buff));
                        GWLOG(LOG_ERR, "error in regexec() err_buff=%s", err_buff);
                        continue;
                }
                if (pmatch_id[1].rm_so == -1 || pmatch_id[1].rm_eo == -1) {
                        continue;
                }

                for (i = pmatch_id[1].rm_so, j = 0;
                     i < pmatch_id[1].rm_eo && j < sizeof(macAddrString);
                     i++, j++) {
                        // convert the MAC address into a EUI-64 like it is
                        // done in IPv6.
                        if (j == 6) {
                            macAddrString[j++] = 'f';
                            macAddrString[j++] = 'f';
                            macAddrString[j++] = 'f';
                            macAddrString[j++] = 'e';
                        }
                        macAddrString[j] = tolower(recv_buf[i]);
                }
                macAddrString[16] = '\0';
                result = parseOneHueBridge(macAddrString, inet_ntoa(recv_addr.sin_addr));
        }
err_regfree:
        regfree(&preg);
err_close:
        close(sock);

        return (result);
}

GW_RESULT hueAuthDiscoverBridges() {
    GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
    GW_RESULT resultRemote = hueAuthDiscoverBridgesRemote();
    GW_RESULT resultLocal = hueAuthDiscoverBridgesLocal();
    //if either discovery was OK, then return result OK.
    if(resultRemote == GW_RESULT_OK || resultLocal == GW_RESULT_OK) {
        result = GW_RESULT_OK;
    }
    return result;
}

/* This function is used to obtain the HTTP prefix string needed for libcurl puts and
 * gets for the Hue implementation case. More importantly this function tells the plugin
 * if the application and the bridge are authorized.  This function is called on every
 * get, put, post, on light resources.
 *
 * The macAddrString is used to determine which bridge and the clientId is checked to
 * see if that client application has been authorized to access the bridge.
 *
 * inputs:
 *    prefix - memory where the prefix is written if bridge authorized
 *    *prefixSize - size of the prefix buffer
 *    *macAddrString - 6 byte MAX address of hue bridge
 *    clientId - supplied by IoTivity ultimately, another name for this
 *               parameter in Iotivity parlance is stack id.
 * returns:
 *    GW_RESULT_OK                  - application is authorized
 *    GW_RESULT_NOT_AUTHORIZED      - bridge found but application not authorized
 *    GW_RESULT_INSUFFICIENT_BUFFER - not enough memory supplied
 *    GW_RESULT_INVALID_PARAMETER   - a pointer was null
 *    GW_RESULT_NOT_PRESENT         - bridge was not found
 *
 */
GW_RESULT hueAuthGetHttpPrefix(char *prefix, uint32_t *prefixSize, const char *macAddrString, const char *clientID)
{
        GW_RESULT result = GW_RESULT_INVALID_PARAMETER;
        HueDiscoveredCtx discoveredCtx;
        bool bridgeFound = false;
        uint32_t size = 0;

        if ((prefix != NULL) && (prefixSize != NULL) && (macAddrString != NULL) && (clientID != NULL)) {
                result = GW_RESULT_NOT_PRESENT;
                bridgeFound = findDiscoveredWithMacAddress(macAddrString, &discoveredCtx);
                if (bridgeFound == true) {
                        result = GW_RESULT_NOT_AUTHORIZED;
                        if (discoveredFindClientID(&discoveredCtx, clientID) == true) {
                                result = GW_RESULT_INSUFFICIENT_BUFFER;

                                size = strlen(clientID);
                                size += strlen(discoveredCtx.ipAddrString);
                                size += strlen("/api/");
                                size += 1;

                                if (*prefixSize >= size) {
                                        result = GW_RESULT_OK;
                                        memset(prefix, 0, *prefixSize);
                                        strcpy(prefix, discoveredCtx.ipAddrString);
                                        strcat(prefix, "/api/");
                                        strcat(prefix, clientID);
                                } else {
                                    *prefixSize = size;
                                }
                        }
                }
        }
        return (result);
}

/* This function does the opposite of creating the Hue Authorization module
 *  it is the last thing called on the Hue Authorization module.
 *
 * returns:
 *    GW_RESULT_OK                - no error
 */
GW_RESULT hueAuthDestroy()
{
        GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
        HueDiscoveredCtx *data = NULL;
        uint32_t size = 0;

        if (g_hueAuthCtx.structInitialized == true) {
                result = GW_RESULT_OK;

                // Write authorized bridges out to a file.  This action frees all
                // of the memory associated with the file cache.
                // NOTE: comment out the following file for the comdex demo
                writeAuthorizedBridgeFile();

                // empty and free remaining discovered bridges in the discovered list
                do {
                        size = 0;
                        pthread_mutex_lock(&(g_hueAuthCtx.discoveredLock));
                        if (false == is_queue_empty(&(g_hueAuthCtx.discoveredList))) {
                                GWLOG(LOG_INFO, "bridge is removed");
                                data = (HueDiscoveredCtx *)remove_from_head(&(g_hueAuthCtx.discoveredList), &size);
                        }
                        pthread_mutex_unlock(&(g_hueAuthCtx.discoveredLock));
                        if ((size > 0) && (data != NULL)) {
                                // call the authorization module for every discovered bridge
                                result = authModuleStop(data->handle);
                                if (result != GW_RESULT_OK) {
                                        GWLOG(LOG_ERR,"Stopping bridge was a failure");
                                }
                                // only call remove bridge on section 5 when all
                                // of the clients have been removed, however, at
                                // the end of time all clients are assumed removed.
                                // since this is the end of time, there is no need
                                // to update the physical records
                                if ((data->notifiedSection5 == true) && (g_hueAuthCtx.removeBridge != NULL)) {
                                        g_hueAuthCtx.removeBridge(g_hueAuthCtx.pluginCtx, data->macAddrString);
                                }
                                free (data);
                        }
                } while (size > 0);

                result = authModuleDestroy();

                // wipe the rest of the context
                memset(&g_hueAuthCtx, 0, sizeof(HueAuthCtx));
        }

        return (result);
}

/*
 * Function used to initialize the global context.  It depends on the fact
 * that global variables initialize to all 0s.
 */
void initializeHueAuthCtx()
{
        if (g_hueAuthCtx.structInitialized == false) {

                memset(&g_hueAuthCtx, 0, sizeof(HueAuthCtx));
                g_hueAuthCtx.structInitialized = true;
                initialize_queue(&(g_hueAuthCtx.discoveredList));

                if (pthread_mutex_init(&(g_hueAuthCtx.discoveredLock), NULL) != 0) {
                        GWLOG(LOG_ERR,"Unable to initialize global resource mutex.");
                        // The context will stay uninitialized in the error case
                        memset(&g_hueAuthCtx, 0, sizeof(HueAuthCtx));
                }
        }

        // In hueAuthDiscoverBridges call and doAuthCallback call
        // these headers are commonly used.
        g_inHeaders.push_back(CURL_CONTENT_TYPE_JSON);
        g_inHeaders.push_back(CURL_HEADER_ACCEPT_JSON);
}

/*
 * Callback registered by the plugin which will be called by the
 * authorization module when an authorization request is received
 * from a trusted client.
 *
 * input:
 *    handle   - 16 bit handle tied to this authorization
 *    authCtx  - a context for this authorization
 *    clientID - associates an application client id with the authorization
 *
 * returns:
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_AUTH_FAILED    - auth failed
 *    GW_RESULT_AUTH_PENDING   - auth is pending some client action
 *    GW_RESULT_ALREADY_AUTH   - auth has already been done for this user
 *    GW_RESULT_INVALID_PARAMETER - invalid parameter
 */
GW_RESULT doAuthCallback (AuthHandle handle, AuthModuleContext *authCtx, const char *clientID)
{
        GW_RESULT result = GW_RESULT_INVALID_PARAMETER;
        char *json_string = NULL;
        cJSON *object = NULL;
        char ipAddrString[MAX_STRING];
        char macAddrString[MAX_STRING];
        HueDiscoveredCtx discoveredCtx;
        std::string uri;
        std::string request;
        std::string response;
        CurlClient cc;
        bool foundBridge = false;
        bool foundClient = false;
        int curlRet = 0;

        // Using the mac address instead of using the handle
        handle = handle;

        memset(macAddrString, 0, MAX_STRING);
        memset(&discoveredCtx, 0, sizeof(HueDiscoveredCtx));

        if ((authCtx != NULL)&&(authCtx->authServerInfo != NULL)&&(clientID != NULL)) {

                // for clarity let copy the authServerInfo into what it is for Hue that is
                // a mac address
                strncpy (macAddrString, authCtx->authServerInfo, MAX_STRING - 1);

                // find a discovered bridge with the same macAddrString.  We need the IP
                // address of this discovered bridge to talk to it
                foundBridge = findDiscoveredWithMacAddress(macAddrString, &discoveredCtx);
                if (foundBridge == true) {
                        strcpy(ipAddrString, discoveredCtx.ipAddrString);
                }

                // check to see if the client ID is already in the client array.  This
                // means if found the client application is already authorized.
                foundClient = discoveredFindClientID(&discoveredCtx, clientID);

                if (foundClient == true) {
                        result = GW_RESULT_ALREADY_AUTH;
                } else {
                        // create a request for the Hue bridge with the given
                        // client ID and IP address.  It will form a payload that
                        // looks something like the following:
                        // {"devicetype": "test user", "username":"1234590"}
                        object = cJSON_CreateObject();

                        cJSON_AddStringToObject(object, "devicetype", "test user");
                        cJSON_AddStringToObject(object, "username", clientID);
                        json_string = cJSON_Print(object);
                        if (json_string != NULL) {
                                request.assign(json_string);
                                free(json_string);
                        }
                        cJSON_Delete(object);

                        uri = std::string(ipAddrString) + std::string("/api");

                        curlRet = cc.doPostRequest(uri, g_inHeaders, request, response);

                        GWLOG(LOG_INFO,"post uri %s", uri.c_str());
                        GWLOG(LOG_INFO,"post request %s", request.c_str());
                        GWLOG(LOG_INFO,"post response %s", response.c_str());

                        if (curlRet == GW_RESULT_OK) {
                                result = parseHueAuthResponseArray(response, &discoveredCtx);
                        } else {
                                GWLOG(LOG_ERR,"curl post failed, curlRet=%d");
                        }
                }
        }
        return (result);
}

/*
 * Callback registered by the plugin which is called by the authorization module
 * when a de-authorization request is received from a trusted client.
 *
 * input:
 *    handle   - handle tied to the bridge of the authorization
 *    authCtx  - authorization module context for this authorization
 *    clientID - associates an application client id with this bridge
 *
 * returns:
 *    GW_RESULT_OK             - no error
 *    GW_RESULT_DEAUTH_FAILED  - deauth failed
 *    GW_RESULT_ALREADY_DEAUTH - deauth has already been done for this user
 */
GW_RESULT doDeauthCallback (AuthHandle handle, AuthModuleContext *authCtx, const char *clientID)
{
        GW_RESULT result = GW_RESULT_DEAUTH_FAILED;
        HueAuthorizedBridgeCtx fileBridgeCtx;
        HueDiscoveredCtx discoveredCtx;

        // mac address is more convienent to use with this implementation, so handle is unused for
        // identification
        handle = handle;

        if ((authCtx != NULL) && (clientID != NULL)) {
                GWLOG(LOG_INFO,"doDeauthCallback - clientID: %s from mac: %s",
                      clientID, authCtx->authServerInfo);

                // first thing needed; find the client/bridge in stored file and remove it.
                if (findAuthorizedBridge((char *)authCtx->authServerInfo, clientID, &fileBridgeCtx) == true) {
                        if (removeAuthorizedBridge((char *)authCtx->authServerInfo, clientID) == false) {
                                GWLOG(LOG_ERR,"doDeauthCallback - client ID record not found in auth record");
                        } else {
                                GWLOG(LOG_INFO,"doDeauthCallback - client ID removed from auth record");
                        }
                } else {
                        // if it was not found then it was already or client application was never authorized
                        GWLOG(LOG_ERR,"doDeauthCallback - already deauthorized, why are we getting this callback??");
                        result = GW_RESULT_ALREADY_DEAUTH;
                }

                // next find the discovered bridge in the discovered bridge list and remove
                // the client.  If there are no more clients then the discovered bridge needs
                // section 5 needs to get notified.
                if (findDiscoveredWithMacAddress((const char *)authCtx->authServerInfo, &discoveredCtx) == true) {
                        if (discoveredFindClientID(&discoveredCtx, clientID) == true) {
                                result = GW_RESULT_OK;
                                if (discoveredRemoveClientID(&discoveredCtx, clientID) == false) {
                                        GWLOG(LOG_ERR,"doDeauthCallback - unable to remove clientID from discovery record");
                                } else {
                                        GWLOG(LOG_INFO,"doDeauthCallback - removed clientID from discovery record");
                                }
                                if (discoveredCtx.numClients == 0) {
                                        GWLOG(LOG_INFO,"doDeauthCallback - refcount on %s is 0, marking bridge as unauthorized",
                                              discoveredCtx.macAddrString);

                                        // Mark the fact that section 5 was told that the bridge is gone, this is used
                                        // for clean up.   This needs to be done just before the update.
                                        if (g_hueAuthCtx.removeBridge != NULL) {
                                                discoveredCtx.notifiedSection5 = false;
                                        }
                                        updateDiscoveredContext(discoveredCtx.macAddrString, &discoveredCtx);

                                        if (g_hueAuthCtx.removeBridge != NULL) {
                                                GWLOG(LOG_INFO,"doDeauthCallback - calling section 5 to clean up");
                                                g_hueAuthCtx.removeBridge(g_hueAuthCtx.pluginCtx, discoveredCtx.macAddrString);
                                        }
                                }
                        }
                } else {
                        GWLOG(LOG_ERR,"doDeauthCallback - client application auth record not found in discovered list");
                }
        }
        return(result);
}

/* Helper function to parse the discovery and add a bridge to the bridge
 * list if it is not already there.
 *
 * NOTE: parsing data patterns that have the following form
 *      []
 *
 *      [{"id":"001788fffe155cbb","internalipaddress":"172.16.20.133"}]
 *
 *      [{"id":"001788fffe155cbb","internalipaddress":"172.16.20.133"},
 *       {"id":"001788fffe1eeeee","internalipaddress":"172.16.20.134"}]
 *
 * input:
 *     payload - contents of the discovery request.
 *
 * returns:
 *      GW_RESULT_OK - parsed ok
 *      GW_RESULT_ERROR - failure in parsing
 */
GW_RESULT parseHueBridgeDiscovery(std::string payload)
{
        GW_RESULT result = GW_RESULT_INVALID_PARAMETER;
        cJSON *object = NULL;
        cJSON *array = NULL;
        int32_t numBridges = 0;
        int32_t index;
        char *macAddrString = NULL;
        char *ipAddrString = NULL;

        if (!payload.empty()) {
                //GWLOG(LOG_INFO,"payload is %s", payload.c_str());
                result = GW_RESULT_INTERNAL_ERROR;
                array = cJSON_Parse((char *)payload.c_str());
                if (array != NULL) {
                        numBridges = cJSON_GetArraySize(array);
                        for (index = 0; index < numBridges; index++) {
                                object = cJSON_GetArrayItem(array, index);
                                if (object == NULL) {
                                        // if one element is not OK then bail
                                        GWLOG(LOG_ERR,"failed parsing json");
                                        break;
                                }
                                if (cJSON_GetObjectItem(object,"id") != NULL) {
                                        macAddrString = cJSON_GetObjectItem(object,"id")->valuestring;
                                }
                                if (cJSON_GetObjectItem(object,"internalipaddress") != NULL) {
                                        ipAddrString = cJSON_GetObjectItem(object,"internalipaddress")->valuestring;
                                }
                                result = parseOneHueBridge(macAddrString, ipAddrString);
                                if (result != GW_RESULT_OK) {
                                        // if one element is not OK then bail
                                        //GWLOG(LOG_ERR,"parseOneHueBridge failed");
                                        break;
                                }
                        }
                }
                else {
                        GWLOG(LOG_ERR,"array returned from call to cJSON_Parse is NULL.");
                }
        } else {
            GWLOG(LOG_ERR,"payload is empty");
        }
        return (result);
}

/*
 * Helper function to parse one bridge out of the discovery response
 */
GW_RESULT parseOneHueBridge(char *macAddrString, char *ipAddrString)
{
        GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
        HueDiscoveredCtx discoveredCtx;
        bool bridgeFound = false;
        bool  bridgeAuthorized = false;
        AuthModuleContext  authCtx;
        HueAuthorizedBridgeCtx fileBridgeCtx;

        if ((macAddrString != NULL) && (ipAddrString != NULL)) {

                //GWLOG(LOG_INFO,"found mac: %s", macAddrString);

                // check to see if the bridge is already there if not then
                // add the bridge to the list
                memset (&discoveredCtx,0,sizeof(HueDiscoveredCtx));
                bridgeFound = findDiscoveredWithMacAddress(macAddrString, &discoveredCtx);
                if (bridgeFound == false) {
                        GWLOG(LOG_INFO,"Found the bridge for the first time %s", macAddrString);
                        // The bridge is not in the discovered list meaning that we have not seen
                        // the discovered bridge until just now.

                        // At this point try to find at least one application client in the
                        // the file list to see if it has been previously authorized.
                        bridgeAuthorized = findAuthorizedBridge(macAddrString, NULL, &fileBridgeCtx);

                        // Build discovered bridge structure to add in the discovered list
                        strncpy(discoveredCtx.macAddrString, macAddrString, MAX_STRING - 1);
                        strncpy(discoveredCtx.ipAddrString, ipAddrString, MAX_STRING - 1);

                        // Add all the client IDs found in the file list into the client array
                        // of the discovered list entry
                        if (bridgeAuthorized == true) {
                                // Add all the clients found in the file list to the discovered
                                // bridge list object.
                                collectAuthorizedClients(macAddrString, (char*)(discoveredCtx.clientIDs), &(discoveredCtx.numClients));
                        }
                        GWLOG(LOG_INFO, "Added bridge MAC=%s, IP=%s", discoveredCtx.macAddrString, discoveredCtx.ipAddrString);
                        result = addDiscovered(&discoveredCtx);

                        // make a call to plugin auth module to tell it about the discovered bridge.
                        memset(&authCtx, 0, sizeof(AuthModuleContext));
                        authCtx.type = AUTH_TYPE_PBC;
                        authCtx.authCtx.PBCCtx.authUrl = (char *)ipAddrString;
                        authCtx.manufacturerName  = (char *)"Philips";
                        authCtx.productName = (char *)"Hue";
                        authCtx.authServerInfo = macAddrString;

                        result = authModuleStart(&(discoveredCtx.handle), &authCtx, doAuthCallback, doDeauthCallback);
                        // TODO: start will not fail for the early implementations, so I am not
                        //       checking for it

                        // Mark the fact that section 5 was told about the bridge, this is used
                        // for clean up.   This needs to be done just before the update.
                        if ((bridgeAuthorized)&&(g_hueAuthCtx.foundBridge != NULL)) {
                                discoveredCtx.notifiedSection5 = true;
                        }
                        updateDiscoveredContext(macAddrString, &discoveredCtx);

                        // Call section 5 telling that a new bridge has been found.
                        if ((bridgeAuthorized)&&(g_hueAuthCtx.foundBridge != NULL)) {
                                g_hueAuthCtx.foundBridge(g_hueAuthCtx.pluginCtx, macAddrString);
                        }
                }
        } else if ((macAddrString == NULL) && (ipAddrString == NULL)) {
                // this is the empty set case []
                GWLOG(LOG_INFO, "this is empty set case []");
                result = GW_RESULT_OK;
        } else {
                result = GW_RESULT_INTERNAL_ERROR;
        }
        return (result);
}

/* parse the authorization response array
 *
 * NOTE: responses have the forms
 *
 *      [{"success": {"username": "1234567890"}}]
 *
 *      [{"error": {"type": 101, "address": "", "description": "link button not pressed"}}]
 *
 *      [{"error": {"type": 7, "address": "/username", "description": "invalid value,
 *                   1234590, for parameter, username"}}]
 *
 */
GW_RESULT parseHueAuthResponseArray(std::string payload, HueDiscoveredCtx *discoveredCtx)
{
        GW_RESULT result = GW_RESULT_INVALID_PARAMETER;
        cJSON *object = NULL;
        cJSON *array = NULL;
        int32_t numResponses = 0;
        int32_t index;

        if (!payload.empty()) {

                result = GW_RESULT_INTERNAL_ERROR;
                array = cJSON_Parse((char *)payload.c_str());
                if (array != NULL) {
                        numResponses = cJSON_GetArraySize(array);
                        for (index = 0; index < numResponses; index++) {
                                object = cJSON_GetArrayItem(array, index);
                                result = parseHueAuthResponse(object, discoveredCtx);
                        }
                }
                else {
                    GWLOG(LOG_ERR,"array returned from call to cJSON_Parse is NULL.");
                }
        }
        return (result);
}

GW_RESULT parseHueAuthResponse(cJSON *object, HueDiscoveredCtx *discoveredCtx)
{
        GW_RESULT result = GW_RESULT_DEAUTH_FAILED;
        cJSON *inner = NULL;
        char *username = NULL;
        char *description = NULL;
        HueAuthorizedBridgeCtx fileBridgeCtx;

        memset(&fileBridgeCtx, 0, sizeof(HueAuthorizedBridgeCtx));

        if (object != NULL) {
                if (cJSON_GetObjectItem(object,"success") != NULL) {
                        inner = cJSON_GetObjectItem(object,"success");
                        if (inner != NULL) {
                                if (cJSON_GetObjectItem(inner,"username") != NULL) {
                                        username = cJSON_GetObjectItem(inner,"username")->valuestring;
                                }
                        }
                }
                if (cJSON_GetObjectItem(object,"error") != NULL) {
                        inner = cJSON_GetObjectItem(object,"error");
                        if (inner != NULL) {
                                if (cJSON_GetObjectItem(inner,"description") != NULL) {
                                        description = cJSON_GetObjectItem(inner,"description")->valuestring;
                                }
                        }
                }

                if (username != NULL) {
                        // authorized case
                        if (discoveredAddClientID(discoveredCtx, username) == true) {
                                updateDiscoveredContext(discoveredCtx->macAddrString, discoveredCtx);

                                // Update the authorization file
                                if (findAuthorizedBridge(fileBridgeCtx.macAddrString, username, &fileBridgeCtx) == false) {
                                         strcpy(fileBridgeCtx.macAddrString, discoveredCtx->macAddrString);
                                         strncpy(fileBridgeCtx.clientID, username, MAX_STRING - 1);
                                         addAuthorizedBridge(&fileBridgeCtx);
                                } else {
                                         GWLOG(LOG_ERR,"Client already in the list - inconsistent");
                                }

                                // Mark the fact that section 5 was told about the bridge, this is used
                                // for clean up.   This needs to be done just before the update.
                                if (g_hueAuthCtx.foundBridge != NULL) {
                                        discoveredCtx->notifiedSection5 = true;
                                }
                                updateDiscoveredContext(discoveredCtx->macAddrString, discoveredCtx);

                                // Call section 5 telling that a new bridge has been found.
                                if (g_hueAuthCtx.foundBridge != NULL) {
                                          g_hueAuthCtx.foundBridge(g_hueAuthCtx.pluginCtx, discoveredCtx->macAddrString);
                                }
                        }
                        result = GW_RESULT_OK;
                } else if (description != NULL) {
                        result = GW_RESULT_DEAUTH_FAILED;
                        if (strcmp(description, "link button not pressed") == 0) {
                                // push button is requested by the bridge
                                // TODO:  should we tell the user in this case
                        } else {
                                // error forming the authorization request message
                                // TODO:  should we tell the user in this case too
                        }
                }
        }
        return (result);
}

/* Helper function to add a bridge context to a list owned by Hue Authorization
 * module.
 *
 * NOTE: Only add bridge if it is not already present in list.  Prior to calling
 *       this function please check to avoid putting in two Hue bridges with the
 *       same mac address.
 *
 * returns:
 *     GW_RESULT_OK    - no errors
 *     GW_RESULT_INTERNAL_ERROR - unable to allocate a bridge context
 */
GW_RESULT addDiscovered(HueDiscoveredCtx *discoveredCtx)
{
        GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
        HueDiscoveredCtx *bridge = NULL;

        if (discoveredCtx != NULL) {
                bridge = (HueDiscoveredCtx *) malloc(sizeof(HueDiscoveredCtx));

                if (bridge != NULL) {
                        memcpy(bridge, discoveredCtx, sizeof(HueDiscoveredCtx));
                        pthread_mutex_lock(&(g_hueAuthCtx.discoveredLock));
                        add_to_tail(&(g_hueAuthCtx.discoveredList), (char *)bridge, sizeof(HueDiscoveredCtx));
                        pthread_mutex_unlock(&(g_hueAuthCtx.discoveredLock));
                        result = GW_RESULT_OK;
                }
        }
        return result;
}

/* Helper function to find a bridge context in a list owned by Hue Authorization
 * module that corresponds to a certain mac address.
 *
 * inputs
 * macAddString - a pointer to an string containing the mac address
 * discoveredCtx  - a pointer to empty memory that will be a target for a copy of
 *              the found context. Only copies if the context has been found.
 * Outputs
 * discoveredCtx  - if a bridge context was found then the contents of the bridge
 *              context is placed in this memory.
 * returns:
 *      true -  bridge context found
 *      false - bridge context not found
 */
bool findDiscoveredWithMacAddress(const char *macAddrString, HueDiscoveredCtx *discoveredCtx)
{
        bool found_it = false;
        queue_node_t *node;
        uint32_t size;
        HueDiscoveredCtx *data;

        if ((macAddrString != NULL) && (discoveredCtx != NULL)) {
                pthread_mutex_lock(&(g_hueAuthCtx.discoveredLock));
                if (false == is_queue_empty(&(g_hueAuthCtx.discoveredList))) {
                        node = get_head_node(&(g_hueAuthCtx.discoveredList));
                        node = get_next_node(node);
                        data = (HueDiscoveredCtx *)get_buffer_from_node(node, &size);

                        while(size > 0) {
                                if (strcmp(macAddrString, data->macAddrString)==0) {
                                       memcpy(discoveredCtx, data, sizeof(HueDiscoveredCtx));
                                       found_it = true;
                                       break;
                                }
                                node = get_next_node(node);
                                data = (HueDiscoveredCtx *)get_buffer_from_node(node, &size);
                        }
                }
                pthread_mutex_unlock(&(g_hueAuthCtx.discoveredLock));
        }
        return (found_it);
}

bool updateDiscoveredContext(const char *macAddrString, HueDiscoveredCtx *newCtx)
{
        bool found_it = false;
        queue_node_t *node;
        uint32_t size;
        HueDiscoveredCtx *data;

        if (macAddrString != NULL) {
                pthread_mutex_lock(&(g_hueAuthCtx.discoveredLock));
                if (false == is_queue_empty(&(g_hueAuthCtx.discoveredList))) {
                        node = get_head_node(&(g_hueAuthCtx.discoveredList));
                        node = get_next_node(node);
                        data = (HueDiscoveredCtx *)get_buffer_from_node(node, &size);
                        while(size > 0) {
                                if (strcmp(macAddrString, data->macAddrString)==0) {
                                       memcpy(data, newCtx, sizeof(HueDiscoveredCtx));
                                       found_it = true;
                                       break;
                                }
                                node = get_next_node(node);
                                data = (HueDiscoveredCtx *)get_buffer_from_node(node, &size);
                        }
                }
                pthread_mutex_unlock(&(g_hueAuthCtx.discoveredLock));
        }
        return (found_it);
}

/*
 * Based on a single context structure find a client in the clientID list.
 *
 * input
 *    *discoveredCtx - bridge context
 *    clientId   - id given by IoTivity ultimately
 *
 * returns:
 *    true  - clientId exists
 *    false - clientId does NOT exit
 */
bool discoveredFindClientID(HueDiscoveredCtx *discoveredCtx, const char *clientID)
{
        bool clientFound = false;
        uint32_t index = 0;

        if ((discoveredCtx != NULL)&&(clientID != NULL)) {
                // search an array for the client id.
                for (index = 0; index < discoveredCtx->numClients; index++) {
                        if (strcmp(&(discoveredCtx->clientIDs[index * MAX_STRING]), clientID) == 0) {
                                clientFound = true;
                                break;
                        } else if (strlen(&(discoveredCtx->clientIDs[index * MAX_STRING])) == 0) {
                                // there are no more clients in the array
                                break;
                        }
                }
        }
        return (clientFound);
}

/* Based on a single context structure add a client to the clientID list.
 *
 * input
 *    *discoveredCtx - discovered bridge context
 *    clientId     - id given by IoTivity ultimately
 *
 * returns:
 *    true  - clientId added
 *    false - clientId NOT added
 */
bool discoveredAddClientID(HueDiscoveredCtx *discoveredCtx, const char *clientID)
{
        bool clientAdded = false;
        uint32_t index = 0;

        if ((discoveredCtx != NULL)&&(clientID != NULL)) {
                for (index = discoveredCtx->numClients; index < MAX_CLIENTS; index++) {
                        if (strcmp(&(discoveredCtx->clientIDs[index * MAX_STRING]), clientID) == 0) {
                                // duplicate found, do not add this client
                                break;
                        } else if (strlen(&(discoveredCtx->clientIDs[index * MAX_STRING])) == 0) {
                                // you have an opening to add a client
                                strcpy(&(discoveredCtx->clientIDs[index * MAX_STRING]), clientID);
                                discoveredCtx->numClients += 1;
                                clientAdded = true;
                                break;
                        } else {
                                // the slot is occupied, move to the next slot
                        }
                }
        }
        return (clientAdded);
}

/*
 * Based on a SINGLE context structure remove a client from the client ID array
 * of pointers.  This routine through the compact routine makes sure that when
 * this operation is done that all the entries have indicies with a value numerically
 * less than the numClients variable
 *
 * input
 *    *discoveredCtx - discovered bridge context
 *    clientId     - id string given by IoTivity ultimately
 *
 * returns:
 *    true  - clientId got removed
 *    false - clientId NOT removed
 */
bool discoveredRemoveClientID(HueDiscoveredCtx *discoveredCtx, const char *clientID)
{
        bool clientRemoved = false;
        uint32_t index = 0;

        if ((discoveredCtx != NULL)&&(clientID != NULL)) {
                // search an array for the client id.
                for (index = 0; index < MAX_CLIENTS; index++) {
                        if (strcmp(&(discoveredCtx->clientIDs[index * MAX_STRING]), clientID) == 0) {
                                // you found it, now remove it
                                memset(&(discoveredCtx->clientIDs[index * MAX_STRING]), 0, MAX_STRING);
                                if ( discoveredCtx->numClients > 0) {
                                        discoveredCtx->numClients -= 1;
                                        discoveredCompactClientIDs(discoveredCtx);
                                        clientRemoved = true;
                                }
                                break;
                        } else if (strlen(&(discoveredCtx->clientIDs[index * MAX_STRING])) == 0) {
                                // you found the end
                                break;
                        } else {
                                // a entry here that does not match go to next one
                        }
                }
        }
        return (clientRemoved);
}

/*
 * Based on a SINGLE context structure compact all of the non-zero entries in
 * the client ID array of strings.  Meaning that all the non-zero entries (i.e.
 * actual client ID strings need to have an index with a value less than the
 * number of clients.
 *
 * NOTE: The algorithm works as follows: First search for non-zero entries above
 * and equal to the numClients and when found place them in array locations with
 * a value less than the numClients index.
 *
 * input
 *    *discoveredCtx - discovered bridge context
 *
 */
void discoveredCompactClientIDs(HueDiscoveredCtx *discoveredCtx)
{
        uint32_t index = 0;
        uint32_t lowerIndex = 0;

        if (discoveredCtx != NULL) {
                // search an array for the client id.
                for (index = discoveredCtx->numClients; index < MAX_CLIENTS; index++) {
                        if (strlen(&(discoveredCtx->clientIDs[index * MAX_STRING])) != 0) {
                                for ( ; lowerIndex < discoveredCtx->numClients; lowerIndex++) {
                                        if (strlen(&(discoveredCtx->clientIDs[lowerIndex * MAX_STRING])) == 0) {
                                                strcpy(&(discoveredCtx->clientIDs[lowerIndex * MAX_STRING]),
                                                       &(discoveredCtx->clientIDs[index * MAX_STRING]));
                                                memset(&(discoveredCtx->clientIDs[index * MAX_STRING]), 0, MAX_STRING);
                                                break;
                                        }
                                }
                        }
                }
        }
}
