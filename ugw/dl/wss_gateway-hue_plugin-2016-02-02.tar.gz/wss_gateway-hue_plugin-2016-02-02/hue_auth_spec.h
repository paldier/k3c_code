/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#include <stdint.h>
#include "gw_error_code.h"
#include "plugin_server.h"
#include "plugin_auth.h"
#include "hue_file.h"
#include "queue.h"
#include <pthread.h>

#ifndef __HUE_AUTH_SPEC_H__
#define __HUE_AUTH_SPEC_H__

#ifdef __cplusplus
extern "C"
{
#endif

/*
 * Each bridge discovered is put into a record which is described below
 */
typedef struct HueDiscoveredTag
{
        // The client IDs storage will eventually be in a list when we actually figure
        // out how client applications need to work.  Until we have that data then there
        // is a client array where index 0 holds the primary client.
        uint32_t numClients;
        char clientIDs[MAX_CLIENTS * MAX_STRING];
        char macAddrString[MAX_STRING];
        char ipAddrString[MAX_STRING];
        AuthHandle handle;
        bool notifiedSection5;   // need to keep of what was said to section 5.
} HueDiscoveredCtx;


/*
 * Callback registered by the HUE plugin back end that allows the plugin specific
 * authorization code to tell the back end that a new user on a HUE bridge can use the bridge.
 *
 * param *ctx
 *    The user context registered by the HueAuthCreate API. This context is
 *    for the convenience of the hue backend implementation.
 * param *macAddrString
 *    In the HUE case this identifier is a 6 byte MAX address of the HUE bridge
 * param *clientId
 *    This is a simple string representing the client application that now has permission to use the
 *    HUE bridge.
 *
 */
typedef void (*HueAuthFoundBridgeCallback) (plugin_ctx_t *ctx, const char *macAddrString);


/*
 * Callback registered by the plugin back end which allow the plugin specific
 * authorization code to remove or revoke a bridge user that tells the back end
 * that a client can no longer use the bridge.
 *
 * param *ctx
 *    The user context registered by the HueAuthCreate API. This context is
 *    for the convenience of the hue backend implementation.
 * param *macAddrString
 *    In the HUE case this identifier is a 6 byte MAX address of the HUE bridge
 * param *clientId
 *    This is a simple string representing the client that now has permission to use the
 *    HUE bridge.
 */
typedef void (*HueAuthRemoveBridgeCallback) (plugin_ctx_t *ctx, const char *macAddrString);


/*
 * Create the Hue specific authorization module
 *
 * param ctx
 *    This is the "back end" context which is considered opaque by the Hue
 *    authorization implementation code, it has been provided as a convenience
 *    for the "back end" implementation.
 * param FoundBridgeCb
 *    Plugin provides a callback for the authorization implementation for the
 *    case where a new user on a bridge is found
 * param RemoveBridgeCb
 *    Plugin provides a callback for the authorization implementation in the
 *    case where a a bridge has been deauthorized
 *
 * return
 *    GW_RESULT_OK               - no error
 *    GW_RESULT_CREATED_FAILED   - create failed
 */
GW_RESULT hueAuthCreate(plugin_ctx_t *ctx, HueAuthFoundBridgeCallback foundBridgeCb,
                        HueAuthRemoveBridgeCallback removeBridgeCb);


/*
 * Request a discovery of the HUE bridges. Needs to be called at least once, it does
 * not hurt to call it many times.  Preferably call it the number of times needed.
 * This is an asyncronous call, the return value tells you if the request got out
 * and that is all.
 *
 * return
 * return
 *    GW_RESULT_OK                - no error
 *    GW_RESULT_INTERNAL_ERROR    - mechanics of sending out discovery failed
 */
GW_RESULT hueAuthDiscoverBridges();


/* Helper function to obtain the HTTP prefix string needed for libcurl puts and gets
 * but more importantly this function tells the plugin if the application and hub are
 * authorized.
 *
 * The macAddr is used to determine which hub  and the clientId is checked to see if
 * that client application has been authorized to access the bridge.
 *
 * inputs:
 *    *prefix - memory where the prefix is written if bridge authorized
 *    *prefixSize - size of the prefix buffer
 *    *macAddrString - mac address string of hue bridge
 *    *clientId - supplied by IoTivity ultimately, another name for this
 *               parameter in Iotivity parlance is stack id.
 * returns:
 *    GW_RESULT_OK                  - application is authorized
 *    GW_RESULT_NOT_AUTHORIZED      - bridge found but application not authorized
 *    GW_RESULT_INSUFFICIENT_BUFFER - not enough memory supplied
 *    GW_RESULT_INVALID_PARAMETER   - a pointer was null
 *    GW_RESULT_NOT_PRESENT         - bridge was not found
 *
 */
GW_RESULT hueAuthGetHttpPrefix(char *prefix, uint32_t *prefixSize, const char *macAddrString, const char *clientId);


/* This function does the opposite of creating the Hue Authorization module
 *  it is the last thing called on the Hue Authorization module.
 *
 * returns:
 *    GW_RESULT_OK                - no error
 */
GW_RESULT hueAuthDestroy();


#ifdef __cplusplus
}
#endif

#endif /* __HUE_AUTH_SPEC_H__ */
