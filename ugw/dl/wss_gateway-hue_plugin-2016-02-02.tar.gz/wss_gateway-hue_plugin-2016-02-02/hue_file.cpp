/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string>
#include <string.h>
#include "gw_error_code.h"
#include "hue_file.h"
#include "cJSON.h"
#include "queue.h"
#include <pthread.h>
#include "secure_storage.h"

#ifdef LOG_TAG
#undef LOG_TAG
#endif
#define LOG_TAG "HUE_FILE"
#include "gwlog.h"

/*
 * This is the global context of the Hue File Implementation.  There can only be
 * one instance in a process boundary and this is the case for a decoupled plugin.
 * So a global context is the best solution.  This is the only global structure
 * required for the implementation of the Hue file module.
 */
typedef struct HueAuthorizedCtxTag
{
        bool structInitialized;
        queue_node_t    fileBridgeList;
        pthread_mutex_t fileBridgeLock;
        char authorizedFileLocation[MAX_STRING];
} HueAuthorizedCtx;


/* NOTE: There is an assumption that global data structures are initialized to 0
 *       when they are loaded into memory.  If this is not the case then we are
 *       going have to figure out how to make this behavior happen.  The code
 *       currently depends on this structure being set to zero at the beginning of time.
 */
HueAuthorizedCtx g_hueFileCtx;


/*
 * Function Prototypes
 */
bool parseAuthorizedBridgeArray(char *fileBuffer, uint32_t fileBufferSize);
bool parseAuthorizedBridge(cJSON *object);
void renderAuthorizedBridgeObject(cJSON *array, HueAuthorizedBridgeCtx *bridgeCtx);
void initializeAuthorizedBridgeCtx();
void cleanupAuthorizedBridgeCtx();


/*
 * Implementation start
 */


/*
 * This API has a create/initialize behavior, it reads all of the
 * bridge clients contained in a given file into the cached file bridge list.  The
 * assumption is that this only happens only once when the plugin is loaded.   In
 * other words (to stess this point); this function should not be called periodically
 * for the first implementation.
 *
 * NOTE: This function rewrites all of the enteries in the hue authorization list
 * into a file.  It has the form as follows:
 *
 * {"id":"001788fffe155cbb","username":"A234532444"}
 *
 * returns:
 *    true - file was read
 *    false - file was not read
 */
bool readAuthorizedBridgeFile()
{
        bool   parsedOk = false;
        long   lSize;
        char   *buffer = NULL;
        size_t fileResult;
        FILE   *pFile = NULL;

        initializeAuthorizedBridgeCtx();

        if (g_hueFileCtx.structInitialized == true) {
                pFile = fopen(g_hueFileCtx.authorizedFileLocation, "r");
                if (pFile == NULL) {
                        GWLOG(LOG_INFO,"File %s not present",
                              g_hueFileCtx.authorizedFileLocation);
                } else {
                        GWLOG(LOG_INFO,"Auth file location = %s",
                                        g_hueFileCtx.authorizedFileLocation);
                        // obtain file size:
                        fseek (pFile , 0 , SEEK_END);
                        lSize = ftell (pFile);
                        rewind (pFile);

                        // allocate memory to contain the whole file:
                        buffer = (char*) malloc (sizeof(char)*lSize);
                        if ((buffer != NULL) && (lSize > 1)) {
                                // copy the file into the buffer:
                                fileResult = fread (buffer,1,lSize,pFile);
                                if (fileResult == (size_t)lSize) {
                                        GWLOG(LOG_INFO,"file buffer = %s", buffer);
                                        parsedOk = parseAuthorizedBridgeArray(buffer, lSize);
                                }
                        }
                }
        }
        if (NULL != buffer) {
            free(buffer);
        }
        if (NULL != pFile) {
            fclose(pFile);
        }
        return (parsedOk);
}


/* This function renders one bridge object to the JSON representation
 */
void renderAuthorizedBridgeObject(cJSON *array, HueAuthorizedBridgeCtx *bridgeCtx)
{
        if (bridgeCtx != NULL) {
                cJSON *object = cJSON_CreateObject();
                cJSON_AddItemToArray(array, object);
                cJSON_AddStringToObject(object, "id", ((const char*)bridgeCtx->macAddrString));
                cJSON_AddStringToObject(object, "username", ((const char*)bridgeCtx->clientID));
        }
}


/*
 * This API has a flush/destroy behavior, it writes all bridge file cache into the
 * the file.  There will one entry added for each client application.  In the life
 * cycle of a plugin this function should only be called once for the first implementation.
 *
 * returns
 *    true - records were written
 *    false - records were not written
 */
bool writeAuthorizedBridgeFile()
{
        bool fileWrittenOk = false;
        bool removed = false;
        char *jsonString = NULL;
        HueAuthorizedBridgeCtx *data;
        uint32_t size;
        queue_node_t *node;
        long   lSize;
        size_t fileResult;

        if (g_hueFileCtx.structInitialized == true) {
                cJSON *array = cJSON_CreateArray();
                if (array != NULL) {
                        do {
                                removed = false;
                                // empty the list as it is getting rendered to a file
                                pthread_mutex_lock(&(g_hueFileCtx.fileBridgeLock));
                                if (false == is_queue_empty(&(g_hueFileCtx.fileBridgeList))) {
                                        node = get_head_node(&(g_hueFileCtx.fileBridgeList));
                                        node = get_next_node(node);
                                        data = (HueAuthorizedBridgeCtx *)get_buffer_from_node(node, &size);
                                        if (size > 0) {
                                                removed = remove_from_middle(node, (void **)&data);
                                        }
                                }
                                pthread_mutex_unlock(&(g_hueFileCtx.fileBridgeLock));

                                if (removed == true) {
                                        renderAuthorizedBridgeObject(array, data);
                                        free (data);
                                }
                        } while (removed == true);

                        jsonString = cJSON_Print(array);
                        if (jsonString != NULL) {
                                // write this information out to a file
                                lSize = strlen(jsonString);
                                FILE *pFile = fopen(g_hueFileCtx.authorizedFileLocation, "w");
                                if (pFile) {
                                        fileResult = fwrite(jsonString, 1, lSize, pFile);
                                        if (fileResult == (size_t)lSize) {
                                                fileWrittenOk = true;
                                                GWLOG(LOG_INFO,"writing file contents %s", jsonString);
                                        } else {
                                                GWLOG(LOG_ERR,"Failed to write the authorization contents");
                                        }
                                        fclose (pFile);
                                } else {
                                        GWLOG(LOG_ERR,"Failed to open the authorization file for writing");
                                }
                                free(jsonString);
                        }
                        cJSON_Delete(array);
                        fileWrittenOk = true;
                }
                memset(&g_hueFileCtx, 0, sizeof(HueAuthorizedCtx));
        }
        return (fileWrittenOk);
}


/*
 * One can add a bridge file context however one must make sure that the bridge
 * context is not already in the list.  There should never be two identical
 * contexts in the list.  One can use the findAuthorizedBridge API to the file
 * bridge objects in the list prior to adding a bridge client.  NOTE: a mac address
 * + client ID constitutes uniqueness of an entry.
 *
 * returns
 *    true - bridge file record was added
 *    false - bridge file record was not added
 */
bool addAuthorizedBridge(HueAuthorizedBridgeCtx *bridgeCtx)
{
        bool bridgeAdded = false;
        HueAuthorizedBridgeCtx *bridge = NULL;

        if (g_hueFileCtx.structInitialized == true) {
                if (bridgeCtx != NULL) {
                        bridge = (HueAuthorizedBridgeCtx *) malloc(sizeof(HueAuthorizedBridgeCtx));
                        if (bridge != NULL) {
                                memcpy(bridge, bridgeCtx, sizeof(HueAuthorizedBridgeCtx));
                                pthread_mutex_lock(&(g_hueFileCtx.fileBridgeLock));
                                add_to_tail(&(g_hueFileCtx.fileBridgeList), (char *)bridge, sizeof(HueAuthorizedBridgeCtx));
                                pthread_mutex_unlock(&(g_hueFileCtx.fileBridgeLock));
                                bridgeAdded = true;
                        }
                }
        }
        return (bridgeAdded);
}


/*
 * Find the file bridge records with the matching mac address and client ID. If
 * either input is set to NULL, then this routine will return the very first
 * record where there is a match.  It is not OK to specify both mac address and
 * client ID as being NULL.
 *
 * returns
 *    true - bridge file record was removed
 *    false - bridge file record was not removed
 */
bool findAuthorizedBridge(const char *macAddrString, const char *clientID, HueAuthorizedBridgeCtx *bridgeCtx)
{
        bool found_it = false;
        queue_node_t *node;
        uint32_t size;
        HueAuthorizedBridgeCtx *data;
        if (g_hueFileCtx.structInitialized == true) {
                if (bridgeCtx != NULL) {
                        pthread_mutex_lock(&(g_hueFileCtx.fileBridgeLock));
                        if (false == is_queue_empty(&(g_hueFileCtx.fileBridgeList))) {
                                node = get_head_node(&(g_hueFileCtx.fileBridgeList));
                                node = get_next_node(node);
                                data = (HueAuthorizedBridgeCtx *)get_buffer_from_node(node, &size);
                                while(size > 0) {
                                       if ((macAddrString != NULL) && (clientID == NULL)) {
                                                if (strcmp(macAddrString, data->macAddrString)==0) {
                                                        memcpy(bridgeCtx, data, sizeof(HueAuthorizedBridgeCtx));
                                                        found_it = true;
                                                        break;
                                                }
                                       } else if ((macAddrString == NULL) && (clientID != NULL)) {
                                                if (strcmp(clientID, data->clientID)==0) {
                                                        memcpy(bridgeCtx, data, sizeof(HueAuthorizedBridgeCtx));
                                                        found_it = true;
                                                        break;
                                                }
                                       } else if ((macAddrString != NULL) && (clientID != NULL)) {
                                                if ((strcmp(macAddrString, data->macAddrString)==0) &&
                                                    (strcmp(clientID, data->clientID)==0)) {
                                                        memcpy(bridgeCtx, data, sizeof(HueAuthorizedBridgeCtx));
                                                        found_it = true;
                                                        break;
                                                }
                                       } else {
                                                memcpy(bridgeCtx, data, sizeof(HueAuthorizedBridgeCtx));
                                                found_it = true;
                                                break;
                                       }
                                       node = get_next_node(node);
                                       data = (HueAuthorizedBridgeCtx *)get_buffer_from_node(node, &size);
                                }
                        }
                        pthread_mutex_unlock(&(g_hueFileCtx.fileBridgeLock));
                }
        }
        return (found_it);
}


/*
 * Removes the file bridge records with the matching mac address and client ID.  If
 * either of the inputs are set to NULL means that you want all records removed
 * with either the mac address or the client ID depending on which parameter is
 * set to NULL. If you set both to NULL then all the bridges are removed.
 *
 * returns
 *    true - bridge file record was removed
 *    false - bridge file record was not removed
 */
bool removeAuthorizedBridge(const char *macAddrString, const char *clientID)
{
        bool removed = false;
        queue_node_t *node;
        queue_node_t *next_node = NULL;
        uint32_t size;
        HueAuthorizedBridgeCtx *data;

        if (g_hueFileCtx.structInitialized == true) {
                if (macAddrString != NULL) {
                        pthread_mutex_lock(&(g_hueFileCtx.fileBridgeLock));
                        if (false == is_queue_empty(&(g_hueFileCtx.fileBridgeList))) {
                                node = get_head_node(&(g_hueFileCtx.fileBridgeList));
                                node = get_next_node(node);

                                data = (HueAuthorizedBridgeCtx *)get_buffer_from_node(node, &size);
                                while(size > 0) {
                                        if ((clientID == NULL) && (macAddrString != NULL)) {
                                                if (strcmp(macAddrString, data->macAddrString) == 0) {
                                                        removed = remove_from_middle(node, (void **)&data);
                                                        free(data);
                                                        break;
                                                }
                                        } else if ((clientID != NULL) && (macAddrString == NULL)) {
                                                if (strcmp(clientID, data->clientID) == 0) {
                                                        removed = remove_from_middle(node, (void **)&data);
                                                        free(data);
                                                        break;
                                                }
                                        } else if ((clientID != NULL) && (macAddrString != NULL)) {
                                                if ((strcmp(macAddrString, data->macAddrString) == 0) &&
                                                    (strcmp(clientID, data->clientID) == 0)) {
                                                        removed = remove_from_middle(node, (void **)&data);
                                                        free(data);
                                                        break;
                                                }
                                        } else {
                                                next_node = get_next_node(node);
                                                removed = remove_from_middle(node, (void **)&data);
                                                free(data);

                                        }
                                        node = next_node;
                                        data = (HueAuthorizedBridgeCtx *)get_buffer_from_node(node, &size);
                                }
                        }
                        pthread_mutex_unlock(&(g_hueFileCtx.fileBridgeLock));
                }
        }
        return (removed);
}


bool parseAuthorizedBridgeArray(char *fileBuffer, uint32_t fileBufferSize)
{
        bool parsedOk = false;
        cJSON *object = NULL;
        cJSON *array = NULL;
        int32_t numBridges = 0;
        int32_t index;

        if ((fileBuffer != NULL) && (fileBufferSize > 0)) {
                array = cJSON_Parse((char *)fileBuffer);
                if (array != NULL) {
                        numBridges = cJSON_GetArraySize(array);
                        parsedOk = true;
                        for (index = 0; index < numBridges; index++) {
                                object = cJSON_GetArrayItem(array, index);
                                parsedOk = parseAuthorizedBridge(object);
                                if (parsedOk == false) {
                                        GWLOG(LOG_ERR,"Parsing one of the bridge lines in file failed");
                                }
                        }
                }
                else {
                           GWLOG(LOG_ERR,"array returned from call to cJSON_Parse is NULL.");
                }
        }
        return (parsedOk);
}


bool parseAuthorizedBridge(cJSON *object)
{
        bool addedOk = false;
        HueAuthorizedBridgeCtx bridgeCtx;
        char *macAddrString = NULL;
        char *clientID = NULL;
        bool bridgeFound = false;

        if (object != NULL) {
                if (cJSON_GetObjectItem(object,"id") != NULL) {
                        macAddrString = cJSON_GetObjectItem(object,"id")->valuestring;
                }
                if (cJSON_GetObjectItem(object,"username") != NULL) {
                        clientID = cJSON_GetObjectItem(object,"username")->valuestring;
                }

                if ((macAddrString != NULL) && (clientID != NULL)) {
                        memset(&bridgeCtx, 0, sizeof(HueAuthorizedBridgeCtx));
                        strncpy(bridgeCtx.macAddrString, macAddrString, MAX_STRING - 1);
                        strncpy(bridgeCtx.clientID, clientID, MAX_STRING - 1);

                        // Not expecting this bridge to be found
                        bridgeFound = findAuthorizedBridge(macAddrString, clientID, &bridgeCtx);

                        if (bridgeFound == false) {
                                addedOk = addAuthorizedBridge(&bridgeCtx);
                        }
                }
        }
        return (addedOk);
}


/*
 * Function used to initialize the global context.  It depends on the fact
 * that global variables initialize to all 0s.
 */
void initializeAuthorizedBridgeCtx()
{
        if (g_hueFileCtx.structInitialized == false) {

                memset(&g_hueFileCtx, 0, sizeof(HueAuthorizedCtx));
                g_hueFileCtx.structInitialized = true;
                initialize_queue(&(g_hueFileCtx.fileBridgeList));

                //get the hue auth file from current directory
                strcpy(g_hueFileCtx.authorizedFileLocation, "./");
                strcat(g_hueFileCtx.authorizedFileLocation,  HUE_AUTHORIZATION_FILE);

                if (pthread_mutex_init(&(g_hueFileCtx.fileBridgeLock), NULL) != 0) {
                        GWLOG(LOG_ERR,"Unable to initialize global resource mutex.");
                        // The context will stay unitialized in the error case
                        memset(&g_hueFileCtx, 0, sizeof(HueAuthorizedCtx));
                }
        }
}


/* function used to cleanup the global context
 */
void cleanupAuthorizedBridgeCtx()
{
        uint32_t size = 0;
        void *item = NULL;

        if (g_hueFileCtx.structInitialized == true) {

                // empty and free remaining items
                do {
                        size = 0;
                        pthread_mutex_lock(&(g_hueFileCtx.fileBridgeLock));
                        if (false == is_queue_empty(&(g_hueFileCtx.fileBridgeList))) {
                                item = remove_from_head(&(g_hueFileCtx.fileBridgeList), &size);
                        }
                        pthread_mutex_unlock(&(g_hueFileCtx.fileBridgeLock));
                        if ((size > 0) && (item != NULL)) {
                                free (item);
                        }
                } while (size > 0);

                // wipe the rest of the context
                memset(&g_hueFileCtx, 0, sizeof(HueAuthorizedCtx));
        }
}


/*
 * Collect Clients strings in an array of strings from records in the file list
 */
bool collectAuthorizedClients(const char *macAddrString, char *clientArray, uint32_t *numClients)
{
        bool worked = false;
        queue_node_t *node;
        uint32_t size;
        HueAuthorizedBridgeCtx *data;
        uint32_t index = 0;

        if (g_hueFileCtx.structInitialized == true) {
                if ((macAddrString != NULL) && (clientArray != NULL)) {
                        worked = true;
                        pthread_mutex_lock(&(g_hueFileCtx.fileBridgeLock));
                        if (false == is_queue_empty(&(g_hueFileCtx.fileBridgeList))) {
                                node = get_head_node(&(g_hueFileCtx.fileBridgeList));
                                node = get_next_node(node);
                                data = (HueAuthorizedBridgeCtx *)get_buffer_from_node(node, &size);
                                while(size > 0) {
                                        if (strcmp(macAddrString, data->macAddrString) == 0) {
                                                if (index < MAX_CLIENTS) {
                                                        strncpy(&(clientArray[(index++) * MAX_STRING]), (const char*)(data->clientID), MAX_STRING);
                                                }
                                        }
                                        node = get_next_node(node);
                                        data = (HueAuthorizedBridgeCtx *)get_buffer_from_node(node, &size);
                                }
                                // tell the user how many clients are in the array
                                *numClients = index;
                        }
                        pthread_mutex_unlock(&(g_hueFileCtx.fileBridgeLock));
                }
        }
        return (worked);
}
