/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#include <stdint.h>
#include "gw_error_code.h"
#include "queue.h"
#include <pthread.h>

#ifndef __HUE_FILE_H__
#define __HUE_FILE_H__

#ifdef __cplusplus
extern "C"
{
#endif

/*******************************************************************************
 * defines go here
 ******************************************************************************/

#define     MAX_CLIENTS                 5
#define     MAX_STRING                  512
#define     HUE_AUTHORIZATION_FILE     "hue_auth_json.txt"

/*
 * Each bridge client stored in this file has been authenticated, there are really
 * two pieces of information that are needed to identify an authorized bridge client:
 * macAddrString, clientID.
 */
typedef struct HueAuthorizedBridgeTag
{
        char macAddrString[MAX_STRING];
        char clientID[MAX_STRING];
} HueAuthorizedBridgeCtx;


/*
 * This API has a create/initialize behavior, it reads all of the
 * bridge clients contained in a given file into the cached authorized bridge list.  The
 * assumption is that this only happens only once when the plugin is loaded.   In
 * other words (to stess this point); this function should not be called periodically
 * for the first implementation.
 *
 * returns:
 *    true - file was read
 *    false - file was not read
 */
bool readAuthorizedBridgeFile();


/*
 * This API has a flush/destroy behavior, it writes all bridge cache into the
 * the file.  There will one entry added for each client application.  In the life
 * cycle of a plugin this function should only be called once for the first implementation.
 *
 * returns
 *    true - records were written
 *    false - records were not written
 */
bool writeAuthorizedBridgeFile();


/*
 * One can add a bridge file context however one must make sure that the bridge
 * context is not already in the list.  There should never be two identical
 * contexts in the list.  One can use the fileFindBridge API to the file
 * bridge objects in the list prior to adding a bridge client.  NOTE: a mac address
 * + client ID constitutes uniqueness of an entry.
 *
 * returns
 *    true - bridge file record was added
 *    false - bridge file record was not added
 */
bool addAuthorizedBridge(HueAuthorizedBridgeCtx *bridgeCtx);


/*
 * Find the file bridge records with the matching mac address and client ID. If
 * either input is set to NULL, then this routine will return the very first
 * record where there is a match.  It is not OK to specify both mac address and
 * client ID as being NULL.
 *
 * returns
 *    true - bridge file record was removed
 *    false - bridge file record was not removed
 */
bool findAuthorizedBridge(const char *macAddrString, const char *clientID, HueAuthorizedBridgeCtx *bridgeCtx);


/*
 * Removes the file bridge records with the matching mac address and client ID.  If
 * either of the inputs are set to NULL means that you want all records removed
 * with either the mac address or the client ID depending on which parameter is
 * set to NULL. If you set both to NULL then all the bridges are removed.
 *
 * returns
 *    true - bridge file record was removed
 *    false - bridge file record was not removed
 */
bool removeAuthorizedBridge(const char *macAddrString, const char *clientID);


/*
 * Collect Clients strings in an array of strings from records in the file list.
 * The client array is really a flattened out two dimensional MAX_CLIENTS, MAX_STRING
 */
bool collectAuthorizedClients(const char *macAddrString, char *clientArray, uint32_t *numClients);

#ifdef __cplusplus
}
#endif

#endif /* __HUE_FILE_H__ */
