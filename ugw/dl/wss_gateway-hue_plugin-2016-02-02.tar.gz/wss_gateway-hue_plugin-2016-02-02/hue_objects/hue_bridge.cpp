/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */
#include "hue_bridge.h"
#include "stringbuffer.h"
#include "writer.h"
#include "curl_client.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>

HueBridge::HueBridge(hue_bridge_data_t data) :
        m_bridgeData(data)
{
}

HueBridge::~HueBridge()
{
        m_lights.clear();
}

/*
 * Enumerate the lights attached to the bridge device.
 */
int32_t HueBridge::discoverLights()
{
        CurlClient cc;
        rapidjson::Document doc;
        std::string response;
        std::vector<std::string> inHeaders;
        int32_t result = GW_RESULT_OK;
        std::string uri;

        uri = m_curlQuery + "/lights/";

        inHeaders.push_back(CURL_CONTENT_TYPE_JSON);
        inHeaders.push_back(CURL_HEADER_ACCEPT_JSON);

        result = cc.doGetRequest(uri, inHeaders, response);
        if (result != GW_RESULT_OK) {
                goto exit;
        }

        doc.SetObject();
        if (doc.Parse<0>(response.c_str()).HasParseError()) {
                result = GW_RESULT_JSON_ERROR;
                goto exit;
        }

        if (doc.IsObject()) {
                m_lights.clear();
                std::string lightUri;
                std::string lightData;
                for (rapidjson::Value::ConstMemberIterator itr = doc.MemberBegin(); itr != doc.MemberEnd(); itr++) {
                        rapidjson::StringBuffer sb;
                        rapidjson::Writer<rapidjson::StringBuffer> writer(sb);

                        lightUri = itr->name.GetString();
                        doc[lightUri.c_str()].Accept(writer);
                        lightData = sb.GetString();
                        HueLight light(uri + lightUri, m_bridgeData.ip, lightUri, lightData);
                        m_lights.push_back(light);
                }
        }
        if (m_lights.empty())
                printf("\n HueBridge::discoverLights - no lights found \n");

exit:
        return result;
}
/*
 * returns the m_lights in lights.
 *
 * @param lights (in/out) is a vector that will be copied with the linked lights.
 */
void HueBridge::getLights(HueLight::HueLightV& lights)
{
        lights = m_lights;
}
