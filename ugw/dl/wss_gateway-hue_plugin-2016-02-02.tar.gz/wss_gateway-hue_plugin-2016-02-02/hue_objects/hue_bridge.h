/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */
#ifndef __HUE_BRIDGE_H__
#define __HUE_BRIDGE_H__

#include <stdio.h>
#include <vector>
#include <string>
#include "hue_light.h"

class HueBridge
{
public:
        typedef std::vector<HueBridge> HueBridgeV;

        typedef std::vector<HueLight> HueLightV;

        virtual ~HueBridge();

        typedef struct hue_bridge_data_tag
        {
                std::string name; /* Friendly name of the bridge */
                std::string id; /* Unique ID for the bridge */
                std::string channel; /* The ZigBee channel in use */
                std::string mac; /* MAC address of the bridge */
                std::string ip; /* IP address of the bridge */
                std::string gateway; /* Gateway IP address */
                std::string timezone; /* Current / configured timezone */
                std::string localTime; /* Local time */
                std::string swVersion; /* Software version */
                std::string apiVersion; /* API version */
        } hue_bridge_data_t;

        HueBridge() {
            m_bridgeData.mac.empty();
            m_curlQuery.empty();
            m_lights.clear();
        }
        HueBridge(hue_bridge_data_t data);

        /*
         * sets the bridge MAC
         */
        void setBridgeMAC(std::string strMac) {
            m_bridgeData.mac = strMac;
        }
        /*
         * sets the lib curl query to get the lights associated with the bridge
         */
        void setBridgeCurlQuery(std::string strQuery) {
            m_curlQuery = strQuery;
        }
        /*
         * Queries the hue bridge for the new lights associated with it.
         *
         * @return GW_RESULT_OK on success, or another GW_RESULT_XXX on error.
         */
        int32_t discoverLights();

        /*
         * Gets all the lights that are associated with the bridge.
         *
         * @param huelights is a vector of HueLight instances. Each
         * one representing a physical light associated with the bridge.
         *
         * @return GW_RESULT_OK on success, or another GW_RESULT_XXX on error.
         */
        void getLights(HueLight::HueLightV& lights);

private:
        hue_bridge_data_t   m_bridgeData;
        std::string         m_curlQuery;
        /*Vector of lights associated with the bridge*/
        HueLightV           m_lights;
};

#endif /* __HUE_BRIDGE_H__ */
