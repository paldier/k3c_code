/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

#ifndef __HUE_DEFS_H__
#define __HUE_DEFS_H__

#include <string>

#define HUE_TIMESLICE               2

/*
 * Constants for the Philiphs Hue Data Model
 */
static const std::string DM_STATE_BRI           = "bri";
static const std::string DM_STATE_SAT           = "sat";
static const std::string DM_STATE_HUE           = "hue";
static const std::string DM_STATE_POWERED       = "on";
static const std::string DM_NAME                = "name";
static const std::string DM_TYPE                = "type";
static const std::string DM_MODEL_ID            = "modelid";
static const std::string DM_UNIQUE_ID           = "uniqueid";
static const std::string DM_VERSION             = "swversion";
static const std::string DM_STATE               = "state";
static const std::string DM_STATE_REACHABLE     = "reachable";
static const std::string DM_STATE_EFFECT        = "effect";
static const std::string DM_STATE_CT            = "ct";
static const std::string DM_STATE_ALERT         = "alert";
static const std::string DM_STATE_COLORMODE     = "colormode";
static const std::string DM_POINT_SYMBOL        = "pointsymbol";

/*
 * Bridge Constants
 */
static std::string BRIDGE_NUPNP_URI             = "https://www.meethue.com/api/nupnp";
static const std::string BRIDGE_ID              = "id";
static const std::string BRIDGE_IP              = "internalipaddress";
static const std::string BRIDGE_MAC             = "macaddress";
static const std::string BRIDGE_NAME            = "name";
static const std::string BRIDGE_USERNAME        = "mytestapplication";

#endif /* __HUE_DEFS_H__ */
