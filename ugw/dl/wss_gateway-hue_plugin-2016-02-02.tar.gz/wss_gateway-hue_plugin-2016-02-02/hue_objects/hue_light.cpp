/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */
#define LOG_TAG "HUE_PLUGIN"
#include "hue_light.h"
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include "rapidjson.h"
#include "document.h"
#include "stringbuffer.h"
#include "writer.h"
#include "curl_client.h"
#include "json_helper.h"
#include "gwlog.h"

using namespace rapidjson;

const std::string HUE_LIGHT_URI  = "/a/light/";

HueLight::HueLight()
{
        m_initialized = true;
        m_uri.empty();
        m_lastCurlResponse.empty();
        m_user.empty();
        m_bridge_ip.empty();
        m_short_id.empty();

        // Call to add Hue related Curl Headers
        useCurlHeaders();
}

HueLight::HueLight(std::string uri, std::string bridge_ip, std::string short_id, std::string json) :
        m_uri(uri), m_bridge_ip(bridge_ip), m_short_id(short_id), m_initialized(false)
{
        m_initialized = true;

        if (!json.empty()) {
                parseJsonResponse(json);
        }
        /*URI - For now URI is in this format /a/light/1, /a/light/2 and so on*/
        m_config.uri = HUE_LIGHT_URI + m_short_id;

        // Call to add Hue related Curl headers
        useCurlHeaders();
}

HueLight::~HueLight()
{
}

int32_t HueLight::get()
{
        CurlClient cc;
        std::string response;
        int32_t result;

        result = cc.doGetRequest(m_uri, m_inHeaders, response);
        if (GW_RESULT_OK != result) {
                return result;
        }
        return parseJsonResponse(response);
}

int32_t HueLight::parseJsonResponse(std::string json)
{
        int32_t result = GW_RESULT_OK;
        rapidjson::Document doc;

        doc.SetObject();
        if (doc.Parse<0>(json.c_str()).HasParseError()) {
                return GW_RESULT_JSON_ERROR;
        }
        if (GW_RESULT_OK != getInternalState(doc) ||
            GW_RESULT_OK != getInternalConfig(doc)) {
                result = GW_RESULT_JSON_ERROR;
        }
        return result;
}

void HueLight::useCurlHeaders()
{
        // For now, these are the only two curl headers used by Hue plugin. In case
        // of more headers, either add them here or provide a parameter in the function
        if(m_inHeaders.empty()) {
                m_inHeaders.push_back(CURL_CONTENT_TYPE_JSON);
                m_inHeaders.push_back(CURL_HEADER_ACCEPT_JSON);
        }
}

int32_t HueLight::put(rapidjson::Document& doc)
{
        int32_t result = GW_RESULT_INTERNAL_ERROR;
        std::string uri = m_uri + "/" + DM_STATE;
        CurlClient cc;

        rapidjson::StringBuffer sb;
        rapidjson::Writer<rapidjson::StringBuffer> writer(sb);
        doc.Accept(writer);
        std::string jsonRequest = sb.GetString();
        std::string jsonResponse = sb.GetString();

        result = cc.doPutRequest(uri, m_inHeaders, jsonRequest, jsonResponse);
        return result;
}

int32_t HueLight::getInternalState(rapidjson::Document& doc)
{
        if (doc.HasMember(DM_STATE.c_str()) && doc[DM_STATE.c_str()].IsObject()) {
                for (Value::ConstMemberIterator it = doc[DM_STATE.c_str()].MemberBegin();
                        it != doc[DM_STATE.c_str()].MemberEnd(); it++) {
                        if (!strcmp(it->name.GetString(), DM_STATE_POWERED.c_str())) {
                                m_state.power = it->value.GetBool();
                        } else if (!strcmp(it->name.GetString(), DM_STATE_HUE.c_str())) {
                                m_state.hue = it->value.GetInt();
                        } else if (!strcmp(it->name.GetString(), DM_STATE_BRI.c_str())) {
                                m_state.bri = it->value.GetInt();
                        } else if (!strcmp(it->name.GetString(), DM_STATE_SAT.c_str())) {
                                m_state.sat = it->value.GetInt();
                        } else if (!strcmp(it->name.GetString(), DM_STATE_REACHABLE.c_str())) {
                                m_state.reachable = it->value.GetBool();
                        } else if (!strcmp(it->name.GetString(), DM_STATE_COLORMODE.c_str())) {
                                m_state.colorMode = it->value.GetString();
                        } else if (!strcmp(it->name.GetString(), DM_STATE_ALERT.c_str())) {
                                m_state.alert = it->value.GetString();
                        } else if (!strcmp(it->name.GetString(), DM_STATE_CT.c_str())) {
                                m_state.ct = it->value.GetUint();
                        }

                }
        } else {
                return GW_RESULT_JSON_ERROR;
        }
        return GW_RESULT_OK;
}

/*
 * Generates URI for this resource using the bridge's IP address and resource's unique id
 * All of the URIs for the HUE resources begin with /a/light/.
 * If multiple bridges are discoverd the bridge_ip will give the uniqueness to the URI
 * URI example for light 1 : /a/light/192.168.1.120/1
 * NOTE: today we are not concerned with the URI size, however, in the future we may have to change
 * the size of unique string.
 *
 */
std::string HueLight::generateURI()
{
        /*TODO - revisit the bridge IP later*/
        //return HUE_LIGHT_URI + m_bridge_ip + "/" + m_short_id;
        return HUE_LIGHT_URI + m_short_id;
}

int32_t HueLight::getInternalConfig(rapidjson::Document& doc)
{
        if (!JsonHelper::getMember(doc, DM_TYPE, m_config.type)) {
            GWLOG(LOG_INFO, "config type is missing");
        }
        if (!JsonHelper::getMember(doc, DM_NAME, m_config.name)) {
            GWLOG(LOG_INFO, "config  name is missing");
        }
        if (!JsonHelper::getMember(doc, DM_MODEL_ID, m_config.modelId)) {
            GWLOG(LOG_INFO, "config modelId is missing");
        }
        if (!JsonHelper::getMember(doc, DM_UNIQUE_ID, m_config.uniqueId)) {
            GWLOG(LOG_INFO, "config uniqueId is missing");
        }
        if (!JsonHelper::getMember(doc, DM_VERSION, m_config.swversion)) {
            GWLOG(LOG_INFO, "config swversion is missing");
        }
        return GW_RESULT_OK;
}

int32_t HueLight::getState(light_state_t& state, bool refresh)
{
        int32_t result = GW_RESULT_OK;

        if (m_initialized) {
                if (refresh == true) {
                        result = get();
                }
                if(result == GW_RESULT_OK) {
                    /* this is a structure copy */
                    state = m_state;
                }
        } else {
            result = GW_RESULT_INVALID_DATA;
        }
        return result;
}

int32_t HueLight::setState(light_state_t& state)
{
    int32_t result = GW_RESULT_INVALID_DATA;
    if (m_initialized) {
            rapidjson::Document doc;
            doc.SetObject();

            JsonHelper::setMember(doc, DM_STATE_BRI, state.bri);
            JsonHelper::setMember(doc, DM_STATE_HUE, state.hue);
            JsonHelper::setMember(doc, DM_STATE_SAT, state.sat);
            JsonHelper::setMember(doc, DM_STATE_POWERED, state.power);

            result = put(doc);
    }
    return result;
}

int32_t HueLight::getConfig(light_config_t& config)
{
        int32_t result = GW_RESULT_INTERNAL_ERROR;

        if (m_initialized) {
                /* this is a structure copy */
                config = m_config;
                result = GW_RESULT_OK;
        }
        return result;
}
