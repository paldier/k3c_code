/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

/* This file contains the C++ representation definition of a Hue light */
#ifndef __HUE_LIGHT_H__
#define __HUE_LIGHT_H__

#include <vector>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <map>
#include <typeinfo>

#include "rapidjson.h"
#include "document.h"
#include "hue_defs.h"

/*
 * The HueLight class represents one Hue Light instance. The class
 * provides methods to get/set of the desired configuration of the light.
 *
 * NOTE: A configuration can be build up by calling the desired set* methods
 *       followed by a call to put().
 *
 * For example;
 *    setOn(true);
 *    setHue(128);
 *    setBrightness(131);
 *    put();
 *
 * The representational state of the light is cached in the instance
 * but can be refreshed by a call to get();
 *
 */
class HueLight
{
public:

        typedef std::vector<HueLight> HueLightV;
        typedef std::vector<HueLight>::iterator HueLightIt;
        typedef std::vector<std::string> HueCurlHeaderV;

        typedef struct light_state_tag
        {
                uint64_t hue; /* Hue                         */
                uint64_t bri; /* Brightness                  */
                uint64_t sat; /* Saturation                  */
                bool power; /* on / off                    */
                std::string effect; /* Effect name                 */
                bool reachable; /* Light reachable (Readonly)  */
                std::string alert; /* Alert mode                  */
                std::string colorMode; /* Color mode      (Readonly)  */
                uint16_t ct; /* ct ?                        */

                light_state_tag()
                {
                        hue = bri =  sat = ct = 0;
                        power = reachable = 0;
                        effect.empty();
                        alert.empty();
                        colorMode.empty();
                }
                /*compares two states and returns true if they are different*/
                bool operator != (light_state_tag &state)
                        {
                                /*we only care about following state changes*/
                                bool bdiff = false;
                                if(state.hue != hue ||
                                   state.bri != bri ||
                                   state.sat != sat ||
                                   state.power != power) {
                                        bdiff = true;
                                }
                                return bdiff;
                        }
                /*compares two states and returns true if they are same*/
                bool operator == (light_state_tag &state)
                        {
                                /*we only care about following state changes*/
                                bool bsame = false;
                                if(state.hue == hue &&
                                   state.bri == bri &&
                                   state.sat == sat &&
                                   state.power == power) {
                                        bsame = true;
                                }
                                return bsame;
                        }
        } light_state_t;

        typedef struct light_config_tag
        {
                std::string type; /* Light type       (Readonly) */
                std::string name; /* Friendly name               */
                std::string modelId; /* Model ID         (Readonly) */
                std::string uniqueId; /* Unique Lamp ID   (Readonly) */
                std::string swversion; /* Software version (Readonly) */
                std::string uri; /*URI for this resource created using uniqueId*/
        } light_config_t;

        /*
         * Constructor initializes a light instance
         *
         * @param uri is the uri for the light instance (e.g. <ip>/api/<user>/light/1)
         *
         * @param json is the initial JSON state for the  light. If empty, the constructor
         * will attempt to get the state directly from the light.
         */
        HueLight();
        HueLight(std::string uri, std::string bridge_ip, std::string short_id, std::string json);
        virtual ~HueLight();

        /*
         * Retrieves the current light state of the Hue light.
         *
         * @param state will hold the light state on success.
         *
         * @param refresh indicates whether to return cached data or not.
         *
         * @return GW_RESULT_OK on success, or another GW_RESULT_XXX on error.
         */
        int32_t getState(light_state_t& state, bool refresh = false);

        /*
         * Sets the current light state of the Hue light.
         *
         * @param state is the desired state of the light.
         *
         * @return  GW_RESULT_OK on success, or another GW_RESULT_XXX on error.
         */
        int32_t setState(light_state_t& state);

        /*
         * Retrieves the configuration information of the Hue light.
         *
         * @param config will hold the configuraion data on success.
         *
         * @return GW_RESULT_OK on success, or another GW_RESULT_XXX on error.
         */
        int32_t getConfig(light_config_t& config);

private:
        /*
         * Retrieves the current state of the light. Values read from
         * are cached until a new get() is issued.
         *
         * @return GW_RESULT_OK on success, or another GW_RESULT_XXX code on error.
         */
        int32_t get();

        /*
         * Sets the configured state of the light. Can be called for each setXXX() call
         * or sent in bulk.
         *
         * @param doc is a reference to the JSON object that holds the configuration to
         * send.
         *
         * @return GW_RESULT_OK on success, or another GW_RESULT_XXX code on error.
         */
        int32_t put(rapidjson::Document& doc);

        /*
         * Retrieves the light state from the JSON representation
         *
         * @param doc is a reference to the DOM that contains the JSON rep.
         *
         * @return GW_RESULT_OK on success, or another GW_RESULT_XXX on error.
         */
        int32_t getInternalState(rapidjson::Document& doc);

        /*
         * Retrieves the configuration from the JSON representation
         *
         * @param doc is a reference to the DOM that contains the JSON rep.
         *
         * @return GW_RESULT_OK on success, or another GW_RESULT_XXX on error.
         */
        int32_t getInternalConfig(rapidjson::Document& doc);


        int32_t parseJsonResponse(std::string json);

        void useCurlHeaders();

        /*
         * Generates unique URI for this resource
         */
        std::string generateURI();

        std::string m_uri;
        std::string m_lastCurlResponse;
        std::string m_user;
        std::string m_bridge_ip;
        std::string m_short_id;

        light_state_t m_state;
        light_config_t m_config;
        bool m_initialized;
        HueCurlHeaderV m_inHeaders;
};

#endif /* __HUE_LIGHT_H__ */
