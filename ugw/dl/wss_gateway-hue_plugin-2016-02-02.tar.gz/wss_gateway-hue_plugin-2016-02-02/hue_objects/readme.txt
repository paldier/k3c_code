
To Instal libcurl:
    sudo apt-get install libcurl4-openssl-dev

If proxy is set, unset the proxy.
    unset http_proxy
    unset https_proxy
