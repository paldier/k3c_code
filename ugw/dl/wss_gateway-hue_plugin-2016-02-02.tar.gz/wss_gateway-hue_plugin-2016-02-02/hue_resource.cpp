/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

/* This file contains plugin specific code that adapts the native resource model
 * of native devices into the resource model of OIC.  The file is divided into two
 * sections; first plugin specific entry points are implemented followed by the
 * implementation of the resource entity handler required by the IoTivity implementation
 * for each resource.
 *
 * NOTE: This file is plumbed ready for dynamic resource additions.  There is a
 * thread provided to manage the devices.  When a resource is found it is added
 * to a work queue which is serviced by the plugin process function.  The plugin
 * process function is a thread safe place for the plugin specific code to call
 * OIC APIs.
 */
#define LOG_TAG "HUE_PLUGIN"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <iostream>
#include <map>
#include "gwlog.h"
#include "gw_error_code.h"
#include "plugin_server.h"
#include "queue.h"
#include "hue_light.h"
#include "hue_auth_spec.h"
#include "hue_common.h"
#include "hue_light.h"
#include "hue_bridge.h"
#include "curl_client.h"
#include "hue_resource.h"
#include "resource_list.h"
#include "work_item_queue.h"
#include <sys/types.h>

/*******************************************************************************
 * Pound defines and structure declarations go here
 ******************************************************************************/

/*Discovery thread is continuously running with sleep in between*/
#define         DISCOVERY_THREAD_SLEEP_TIME     1
#define         MAX_QUERY_STRING                200
/*******************************************************************************
 * global data goes here
 ******************************************************************************/
plugin_ctx_t *g_plugin_ctx = NULL;
pthread_mutex_t g_disc_list_lock;
pthread_mutex_t g_observe_notify_lock;
pthread_mutex_t g_response_lock;

/*map for maintaining history for Observe notifications
 * map<resource_uri, resource_previous_state>
 * */
std::map<std::string, HueLight::light_state_t> g_notif_map;
typedef std::map<std::string, HueBridge> disc_bridges_map;
typedef disc_bridges_map::iterator bridgeItr;
disc_bridges_map g_disc_bridges_map;

const std::string HUE_LIGHT_NAME = "Hue Lamp";

// Resource type for binary switch
const std::string HUE_SWITCH_TYPE = "oic.r.switch.binary";

// Resource type for light brightness
const std::string HUE_BRIGHTNESS_TYPE = "oic.r.light.brightness";

// Resource type for colour chroma
const std::string HUE_CHROMA_TYPE = "oic.r.colour.chroma";

const std::string RES_INTERFACE_NAME = "oic.if.a";
const char * CLIENT_ID = "newdeveloper"; /*TODO - temp, till the entityhandler returns the username*/

/* This is a plugin's specific entry point function that allows the plugin
 * to create and initialize static structures.
 *
 * returns:
 *     GW_RESULT_OK             - no errors
 *     GW_RESULT_INTERNAL_ERROR - stack process error
 */
GW_RESULT plugin_create(plugin_ctx_t **plugin_specific_ctx)
{
     GW_RESULT result = GW_RESULT_INTERNAL_ERROR;
     if(g_plugin_ctx == NULL) {
        /* initialize global data and return value */
        memset(&g_disc_list_lock, 0, sizeof(pthread_mutex_t));
        memset(&g_observe_notify_lock, 0, sizeof(pthread_mutex_t));
        memset(&g_response_lock, 0, sizeof(pthread_mutex_t));

        *plugin_specific_ctx = NULL;

        /* allocate a context structure for the plugin */
        plugin_ctx_t *ctx = (plugin_ctx_t *) malloc(sizeof(plugin_ctx_t));

        /* initialize the plugin context */
        if (ctx != NULL) {
                memset(ctx, 0, sizeof(plugin_ctx_t));
                *plugin_specific_ctx = ctx;
                g_plugin_ctx = ctx;
        } else {
                GWLOG(LOG_ERR,"Unable to allocate plugin specific context.");
                goto exit;
        }
        if (pthread_mutex_init(&g_disc_list_lock, NULL) != 0) {
            GWLOG(LOG_ERR,"Unable to initialize g_disc_list_lock.");
            goto exit;
        }
        if (pthread_mutex_init(&g_observe_notify_lock, NULL) != 0) {
            GWLOG(LOG_ERR,"Unable to initialize g_observe_notify_lock.");
            goto exit;
        }
        if (pthread_mutex_init(&g_response_lock, NULL) != 0) {
            GWLOG(LOG_ERR,"Unable to initialize g_response_lock.");
            goto exit;
        }
        /* From here we can return Success for plugin_create. If we don't find the bridge or lights
         * or if authorization fails, we try again the discovery thread
         * */
        result = OC_STACK_OK;
        g_disc_bridges_map.clear();
        g_notif_map.clear();
    } else {
        result = GW_RESULT_ALREADY_CREATED;
    }
exit:
    GWLOG(LOG_INFO,"Plugin create return value:%d.", result);

    /*
     * NOTE: What do we do if the create for some reason failed.  To we assume that the destroy
     * will be called if the create fails??  Let let the plugin loader pick up the pieces by
     * calling destroy on an imperfectly created plugin.  Calling entry point APIs from within
     * the implementation can cause some real problems (e.g. deadlock situations).
     */

    return (result);
}

/* CALLED BY the plugin's OIC server to allow the plugin to use OIC apis
 *
 * returns:
 *     GW_RESULT_OK             - no errors
 *     GW_RESULT_INTERNAL_ERROR - stack process error
 */
GW_RESULT plugin_start(plugin_ctx_t *ctx)
{
    GW_RESULT result = GW_RESULT_STARTED_FAILED;
    int error = 0;
    if(ctx == NULL || g_plugin_ctx == NULL) {
        goto exit;
    }
    if(ctx->started == true) {
        result = GW_RESULT_ALREADY_STARTED;
        goto exit;
    }

    result = hueAuthCreate(ctx, hue_auth_found_bridge_callback,
                                hue_auth_remove_bridge_callback);
    if (GW_RESULT_OK == result) {
        /*start bridge discovery*/
        if(hueAuthDiscoverBridges() != GW_RESULT_OK) {
            //hueAuthDiscoverBridges if fails we try again in discovery thread, so don't return failure
            GWLOG(LOG_ERR, "hueAuthDiscoverBridges failed");
        } else {
            GWLOG(LOG_INFO, "hueAuthDiscoverBridges succeeded");
        }
        /* create house keeping thread */
        ctx->stay_in_process_loop = true;

        error = pthread_create(&(ctx->thread_handle), NULL,
                hue_lights_discovery_thread_process, ctx);
        if (error == 0) {
            ctx->started = true;
            result = GW_RESULT_OK;
        } else {
            GWLOG(LOG_ERR, "Can't create plugin specific thread :[%s]",
                    strerror(error));
            plugin_stop(ctx);
            result = GW_RESULT_STARTED_FAILED;
        }
    } else {
        GWLOG(LOG_ERR, "hueAuthCreate Failed. Cannot create plugin");
    }
exit:
    GWLOG(LOG_INFO, "Plugin start return value:%d.", result);
    return (result);
}

void compare_attributes_add_obs_item(const HueLight::light_state_t& stateprev,
                                     const HueLight::light_state_t& statenew,
                                     plugin_ctx_t *ctx, const std::string& configURI)
{
        GWLOG(LOG_INFO, "URI received %s", configURI.c_str());
        if(stateprev.power != statenew.power) {
                if(configURI.find("switch") == std::string::npos) {
                        GWLOG(LOG_INFO, "URI is not switch (%s) but power state has changed", configURI.c_str());
                } else {
                        GWLOG(LOG_INFO, "Power has changed; Add notify observer for switch resource - %s", configURI.c_str());
                        add_work_item(ctx, WORK_ITEM_NOTIFY_OBSERVERS, configURI.c_str(),
                                      HUE_SWITCH_TYPE.c_str(), RES_INTERFACE_NAME.c_str(), NULL);
                }
        } else if(stateprev.bri != statenew.bri) {
                if(configURI.find("brightness") == std::string::npos) {
                        GWLOG(LOG_INFO, "URI is not brightness (%s) but brightness value state has changed", configURI.c_str());
                } else {
                        GWLOG(LOG_INFO, "Bri has changed; Add notify observer for brightness resource - %s", configURI.c_str());
                        add_work_item(ctx, WORK_ITEM_NOTIFY_OBSERVERS, configURI.c_str(),
                                      HUE_BRIGHTNESS_TYPE.c_str(), RES_INTERFACE_NAME.c_str(), NULL);
                }
        } else if((stateprev.hue != statenew.hue) || stateprev.sat != statenew.sat) {
                if(configURI.find("chroma") == std::string::npos) {
                        GWLOG(LOG_INFO, "URI is not chroma (%s) but hue/sat state has changed", configURI.c_str());
                } else {
                        GWLOG(LOG_INFO, "Hue/Sat has changed; Add notify observer for chroma resource - %s", configURI.c_str());
                        add_work_item(ctx, WORK_ITEM_NOTIFY_OBSERVERS, configURI.c_str(),
                                      HUE_CHROMA_TYPE.c_str(), RES_INTERFACE_NAME.c_str(), NULL);
               }
        }
}

// Helper function to add work items for different RTs
void add_item_oic_profile_wrapper(plugin_ctx_t *ctx, const std::string& configURI, uint32_t workID)
{
        if(ctx == NULL)
        {
                GWLOG(LOG_ERR, "Plugin context NULL while adding work items for different RTs");
                return;
        }

        // Switch URI to generate: "a/light/lightnumber/switch"
        // Example: "a/light/1/switch"
        std::string switchURI = configURI + "/switch";
        if(GW_RESULT_OK != add_work_item(ctx, workID, switchURI.c_str(),
                      HUE_SWITCH_TYPE.c_str(), RES_INTERFACE_NAME.c_str(), binary_switch_EH))
        {
                GWLOG(LOG_ERR, "Unable to add work item ID for switch resource: %d", workID);
        }

        // Brightness URI to generate: "a/light/lightnumber/brightness"
        // Example: "a/light/1/brightness"
        std::string brightnessURI = configURI + "/brightness";
        if(GW_RESULT_OK != add_work_item(ctx, workID, brightnessURI.c_str(),
                      HUE_BRIGHTNESS_TYPE.c_str(), RES_INTERFACE_NAME.c_str(), brightness_EH))
        {
                GWLOG(LOG_ERR, "Unable to add work item ID for brightness resource: %d", workID);
        }

        // Chroma URI to generate: "a/light/lightnumber/chroma"
        // Example: "a/light/1/chroma"
        std::string chromaURI = configURI + "/chroma";
        if(GW_RESULT_OK != add_work_item(ctx, workID, chromaURI.c_str(),
                      HUE_CHROMA_TYPE.c_str(), RES_INTERFACE_NAME.c_str(), chroma_EH))
        {
                GWLOG(LOG_ERR, "Unable to add work item ID for chroma resource: %d", workID);
        }

        return;
}

/*
 * Callback is called when a bridge is authorized. It adds the bridge in bridge map and inits some
 * bridge data and calls function to discover lights for that bridge
 */
void hue_auth_found_bridge_callback(plugin_ctx_t *ctx, const char *macAddrString)
{
        GWLOG(LOG_INFO,"hue_auth_found_bridge_callback called for bridge = %s", macAddrString);

        ctx = ctx;
        pthread_mutex_lock(&g_disc_list_lock);

        HueBridge bridge;
        std::string str_mac(macAddrString);
        bool bfound = false;
        HueLight::HueLightV lights;
        HueLight::light_config_t config;
        HueLight::light_state_t state;
        HueLight::HueLightIt itr;

        if(!g_disc_bridges_map.empty()) {
                if(g_disc_bridges_map.find(str_mac) != g_disc_bridges_map.end()) {
                        bridge = g_disc_bridges_map[str_mac];
                        bfound = true;
                }
        }
        if(!bfound) {
                bridge.setBridgeMAC(str_mac);
        }
        uint32_t prefix_size = MAX_QUERY_STRING;
        char *prefix = (char*)malloc(prefix_size);

        /*get prefix for discovering lights*/
        GW_RESULT result = hueAuthGetHttpPrefix(prefix, &prefix_size, macAddrString, CLIENT_ID);
        if(result == GW_RESULT_INSUFFICIENT_BUFFER) {
                prefix = (char*)realloc(prefix, prefix_size);
                result = hueAuthGetHttpPrefix(prefix, &prefix_size, macAddrString, CLIENT_ID);
        }
        if(result == GW_RESULT_OK){
              bridge.setBridgeCurlQuery(prefix);
              bridge.discoverLights();
              bridge.getLights(lights);
              if(lights.empty() == false){
                      add_work_item(ctx, WORK_ITEM_START_PRESENCE, NULL, NULL, NULL, NULL);
                      for(itr = lights.begin(); itr != lights.end(); itr++) {
                             (*itr).getConfig(config);
                             (*itr).getState(state);
                             if(state.reachable == true) {
                                      GWLOG(LOG_INFO,"(add) - light name=%s, id=%s",
                                              config.name.c_str(),
                                              config.uniqueId.c_str());
                                      add_item_oic_profile_wrapper(ctx, config.uri, WORK_ITEM_CREATE_RESOURCE);
                              }
                      }
              }
                /*add the bridge in the map*/
                g_disc_bridges_map[str_mac] =  bridge;
        } else {
                GWLOG(LOG_ERR,"hue_auth_found_bridge_callback hueAuthGetHttpPrefix failed");
        }
        free(prefix);
        pthread_mutex_unlock(&g_disc_list_lock);
        return;
}

/*
 * Removes bridge from the authorized bridge map.
 */
void hue_auth_remove_bridge_callback(plugin_ctx_t *ctx, const char *macAddrString)
{
        GWLOG(LOG_INFO,"hue_auth_remove_bridge_callback called for bridge = %s", macAddrString);

        if(ctx == NULL) {
                GWLOG(LOG_ERR,"ctx is NULL");
                return;
        }
        pthread_mutex_lock(&g_disc_list_lock);

        HueLight::HueLightV brdglights;
        HueLight::HueLightIt itlights;
        HueLight::light_config_t config;
        std::string str_mac(macAddrString);
        /*remove the unauthorized bridge from the map and destroy its light resources*/
        bridgeItr it = g_disc_bridges_map.find(str_mac);
        if( it != g_disc_bridges_map.end()) {
                HueBridge bridge = it->second;
                bridge.getLights(brdglights);
                for (itlights = brdglights.begin(); itlights != brdglights.end(); itlights++) {
                        /*remove the lights*/
                        (*itlights).getConfig(config);
                        GWLOG(LOG_INFO, "destroying resource for %s", config.uri.c_str());
                        add_item_oic_profile_wrapper(ctx, config.uri, WORK_ITEM_DESTROY_RESOURCE);
                }
                /*remove the bridge*/
                g_disc_bridges_map.erase(it);
        }
        pthread_mutex_unlock(&g_disc_list_lock);
        return;
}

/*
 * This function checks if Observe notification should be sent to the clients
 * It maintains a map for history of notifications for the resource. If the new state and
 * the state in map are different, it will notify the registered clients and add\overwrite
 * the entry in the map to check for the next time. The maximum map size is the number
 * of resources found
 * @param - uri - URI of the resource whose state has changed
 */
void notify_observers(std::string uri)
{
        HueLight light;
        HueLight::light_state_t statenew;

        //protect this function from multiple entries from different threads
        pthread_mutex_lock(&g_observe_notify_lock);
        uint32_t observe_cnt = 0xdeadbeef;
        bool bsend_notif = true;
        OCResourceHandle handle = find_resource_from_uri(uri.c_str(), &observe_cnt);
        if ((handle != 0)) {
            if(get_light_from_uri((char*)uri.c_str(), light) == true) {
                    light.getState(statenew, true);
            }
            /* check if the notification map is not empty, find the resource in it*/
            if(!g_notif_map.empty()) {
                if(g_notif_map.find(uri) != g_notif_map.end()) {
                    /*resource entry is found
                     * check if the state was same. If same don't send notification*/
                    if(statenew == g_notif_map[uri]) {
                            bsend_notif = false;
                            GWLOG(LOG_INFO,"same states - not sending notification again");
                    } else {
                            GWLOG(LOG_INFO,"states are different - might send notification again");
                    }
                } else {
                        GWLOG(LOG_INFO,"notification map is not empty, but URI entry not found");
                }
            } else {
                GWLOG(LOG_INFO,"notification map is empty");
            }
            GWLOG(LOG_INFO, "bsend_notif = %d, observe_cnt = %d", bsend_notif, observe_cnt);
            if(bsend_notif == true && (observe_cnt != 0)) {
                GWLOG(LOG_INFO,"Yes - Notify observes on:%s observe cnt:%d",
                        uri.c_str(), observe_cnt);
                compare_attributes_add_obs_item(g_notif_map[uri], statenew, g_plugin_ctx, uri);
            }
            /*add\overwrite the state in the map for maintaining history of notifications*/
            g_notif_map[uri] = statenew;
        } else {
                GWLOG(LOG_INFO,"resource handle is invalid");
        }

        pthread_mutex_unlock(&g_observe_notify_lock);
        return;
}
/*  Plugin specific entry-point function to stop the plugin's threads
 *
 * returns:
 *     GW_RESULT_OK             - no errors
 *     GW_RESULT_INTERNAL_ERROR - stack process error
 */
GW_RESULT plugin_stop(plugin_ctx_t *ctx)
{
        GW_RESULT result = GW_RESULT_INTERNAL_ERROR;

        if (NULL != ctx && g_plugin_ctx != NULL) {
                result = GW_RESULT_OK;

                //stop the presence before stopping the plugin
                add_work_item(ctx, WORK_ITEM_STOP_PRESENCE, NULL, NULL, NULL, NULL);

                // This lock is needed here to avoid the plugin
                // from crashing if plugin_stop is called
                // and thread_discovery* is running already or
                // called at the same time
                // Also hueAuthDestroy is moved later
                // as it results in deleting the light and Auth resources
                // and also clearing global context for Auth module, so
                // if the Discover bridge function was called at the same time,
                // just after the clearing of global context, plugin crashed
                // (for bridge discovery)!
                pthread_mutex_lock(&g_disc_list_lock);
                if (ctx->started == true) {
                        ctx->stay_in_process_loop = false;
                        pthread_join(ctx->thread_handle, NULL);
                        ctx->started = false;
                }
                pthread_mutex_unlock(&g_disc_list_lock);

                //destroy the resources
                hueAuthDestroy();
        }
        GWLOG(LOG_INFO,"Plugin stop: OUT - return value:%d", result);

        return (result);
}

/* Plugin specific entry-point function to allow the plugin resources to be
 * freed.
 *
 * returns:
 *     GW_RESULT_OK             - no errors
 *     GW_RESULT_INTERNAL_ERROR - stack process error
 */
GW_RESULT plugin_destroy(plugin_ctx_t *ctx)
{
        GW_RESULT result =  GW_RESULT_INTERNAL_ERROR;

        if (ctx != NULL && g_plugin_ctx != NULL) {
            result = GW_RESULT_OK;
            if (ctx->started == true) {
                   result = plugin_stop(ctx);
            }
            g_notif_map.clear();
            pthread_mutex_destroy(&g_disc_list_lock);
            pthread_mutex_destroy(&g_observe_notify_lock);
            pthread_mutex_destroy(&g_response_lock);
            /* freeing the resource allocated in create */
            free(ctx);
            g_plugin_ctx = NULL;
        }

        GWLOG(LOG_INFO,"Plugin destroy's return value:%d", result);

        return (result);
}

// Helper function to send entity handler response
OCEntityHandlerResult send_response(OCEntityHandlerRequest *entityHandlerRequest,
                                    OCRepPayload* payload,
                                    OCEntityHandlerResult result)
{
        if(entityHandlerRequest == NULL) {
                GWLOG(LOG_ERR, "entityHandlerRequest is null in send_response");
                return OC_EH_ERROR;
        }

        OCEntityHandlerResponse response;

        response.requestHandle = entityHandlerRequest->requestHandle;
        response.resourceHandle = entityHandlerRequest->resource;
        response.ehResult = result;
        response.payload = reinterpret_cast<OCPayload*>(payload);
        response.numSendVendorSpecificHeaderOptions = 0;
        memset(response.sendVendorSpecificHeaderOptions, 0,
                sizeof response.sendVendorSpecificHeaderOptions);
        memset(response.resourceUri, 0, sizeof(response.resourceUri));
        // Indicate that response is NOT in a persistent buffer
        response.persistentBufferFlag = 0;
        // Send the response
        if (OCDoResponse(&response) != OC_STACK_OK) {
                GWLOG(LOG_ERR,"Sending response failed.");
                return OC_EH_ERROR;
        }
        return result;
}

OCEntityHandlerResult handle_EH_requests(
        OCEntityHandlerFlag flag,
        OCEntityHandlerRequest *entityHandlerRequest,
        light_resource_t &light_resource)
{
        OCEntityHandlerResult ehResult = OC_EH_ERROR;
        uint32_t *observe_cnt = NULL;
        char uri[MAX_URI_LENGTH];

        pthread_mutex_lock(&g_response_lock);
        OCRepPayload* responsePayload = NULL;

        if ((entityHandlerRequest != NULL)
                && find_resource(entityHandlerRequest->resource, uri, &observe_cnt)) {
                if (flag & OC_OBSERVE_FLAG) {
                        GWLOG(LOG_INFO,"Observe flag: entityHandlerRequest->obsInfo.action=%d", entityHandlerRequest->obsInfo.action);
                        if (OC_OBSERVE_REGISTER == entityHandlerRequest->obsInfo.action) {
                                (*observe_cnt) += 1;
                                GWLOG(LOG_INFO,"Register observer on %s resource, cnt=%d", uri, observe_cnt);
                                ehResult = OC_EH_OK;
                        } else if (OC_OBSERVE_DEREGISTER == entityHandlerRequest->obsInfo.action) {
                                if ((*observe_cnt) != 0) {
                                        // count must not drop below zero when decrementing
                                        (*observe_cnt) -= 1;
                                }
                                GWLOG(LOG_INFO,"Deregister observer on %s resource, cnt=%d", uri, observe_cnt);
                                ehResult = OC_EH_OK;
                        }
                }
                if (flag & OC_REQUEST_FLAG) {
                        if (OC_REST_GET == entityHandlerRequest->method) {
                                GWLOG(LOG_INFO,"Received OC_REST_GET from client: uri=%s", uri);
                                ehResult = process_get_request(uri, light_resource);
                        }
                        //TODO remove PUT support in future
                        else if (OC_REST_PUT == entityHandlerRequest->method ||
                                        OC_REST_POST == entityHandlerRequest->method) {

                                if(OC_REST_PUT == entityHandlerRequest->method){
                                        GWLOG(LOG_INFO,"Received OC_REST_PUT from client for %s", uri);
                                }
                                else{
                                        GWLOG(LOG_INFO,"Received OC_REST_POST from client for %s", uri);
                                }
                                ehResult = process_put_request(uri, entityHandlerRequest, light_resource);
                                // resource state is changed, add it in work_item queue for the
                                // Observe notification
                                if(g_plugin_ctx != NULL && ehResult == OC_EH_OK) {
                                        GWLOG(LOG_INFO,"PUT - Adding Observer for resource uri=%s", uri);
                                        notify_observers(uri);
                                }
                        } else {
                                GWLOG(LOG_INFO,"Received unsupported method %d from client for uri=%s",
                                        entityHandlerRequest->method, uri);
                        }

                        if (ehResult == OC_EH_OK)
                        {
                            responsePayload = get_payload(uri, light_resource);
                        }

                        ehResult = send_response(entityHandlerRequest, responsePayload, ehResult);
                }
        } else {
                if (entityHandlerRequest == NULL) {
                        GWLOG(LOG_ERR,"Entity handler received a null entity request context.");
                } else {
                        GWLOG(LOG_WARNING, "Resource was not found in entity handler: flag=%d", flag);
                }
        }

        pthread_mutex_unlock(&g_response_lock);

        return ehResult;
}

// Entity handler for binary switch
OCEntityHandlerResult binary_switch_EH(
        OCEntityHandlerFlag flag,
        OCEntityHandlerRequest *entityHandlerRequest,
        void* callbackParam)
{
        (void) callbackParam;
        GWLOG(LOG_INFO,"Binary Switch Entity handler callback Invoked- flags:0x%x", flag);
        light_resource_t light;
        light.rt = HUE_SWITCH_TYPE;
        light.attributes.power = false;
        return handle_EH_requests(flag,
                                  entityHandlerRequest,
                                  light);
}

// Entity handler for brightness resource
OCEntityHandlerResult brightness_EH(
        OCEntityHandlerFlag flag,
        OCEntityHandlerRequest *entityHandlerRequest,
        void* callbackParam)
{
        (void) callbackParam;
        light_resource_t light;
        light.rt = HUE_BRIGHTNESS_TYPE;
        light.attributes.bri = 0;
        return handle_EH_requests(flag,
                entityHandlerRequest,
                light);
}

// Entity handler for chroma resource
OCEntityHandlerResult chroma_EH(
        OCEntityHandlerFlag flag,
        OCEntityHandlerRequest *entityHandlerRequest,
        void* callbackParam)
{
        (void) callbackParam;
        GWLOG(LOG_INFO,"Chroma Entity handler callback Invoked- flags:0x%x", flag);
        light_resource_t light;
        light.rt = HUE_CHROMA_TYPE;
        light.attributes.chroma.hue = 0;
        light.attributes.chroma.sat = 0;
        light.attributes.chroma.colourspacevalue = (char*) "dummy_colourspacevalue";
        return handle_EH_requests(flag,
                                  entityHandlerRequest,
                                  light);
}

OCEntityHandlerResult process_get_request(char *uri, light_resource_t &light_resource)
{
        OCEntityHandlerResult ehResult = OC_EH_ERROR;
        HueLight light;
        HueLight::light_state_t state;

        /* get the light matching the URI. If we don't find the light, return error*/
        if(!uri || (get_light_from_uri(uri, light) == false)) {
                return ehResult;
        }

        if(light.getState(state, true) == GW_RESULT_OK)
        {
                GWLOG(LOG_INFO,"Fetched light state: RT=%s", light_resource.rt.c_str());
                if(HUE_SWITCH_TYPE == light_resource.rt) {
                        light_resource.attributes.power = state.power;
                        GWLOG(LOG_INFO,"GET: Value of power: %s\n",
                              light_resource.attributes.power ? "true" : "false");
                }
                else if(HUE_BRIGHTNESS_TYPE == light_resource.rt) {
                        GWLOG(LOG_INFO,"GET: Value (before) of bri: %d\n", light_resource.attributes.bri);
                        light_resource.attributes.bri = state.bri;
                        GWLOG(LOG_INFO,"GET: Value of bri: %d\n", light_resource.attributes.bri);
                }
                else if(HUE_CHROMA_TYPE == light_resource.rt) {
                        light_resource.attributes.chroma.hue = state.hue;
                        light_resource.attributes.chroma.sat = state.sat;
                        light_resource.attributes.chroma.colourspacevalue = (char*) "dummy_colourspacevalue";
                        GWLOG(LOG_INFO,"GET: Value of hue %d, value of sat %d\n",
                              light_resource.attributes.chroma.hue,
                              light_resource.attributes.chroma.sat);
                }
                else {
                        GWLOG(LOG_INFO,"Invalid resource type");
                        return ehResult;
                }

                ehResult = OC_EH_OK;
        }
        else
        {
                GWLOG(LOG_ERR, "Error while getting light state");
        }

        GWLOG(LOG_INFO,"Command service completed: uri=%s", uri);

        return ehResult;
}

OCEntityHandlerResult process_put_request(char *uri, OCEntityHandlerRequest *ehRequest,
                                          light_resource_t &light_resource)
{
        OCEntityHandlerResult ehResult = OC_EH_ERROR;
        if(!ehRequest || !ehRequest->payload || ehRequest->payload->type != PAYLOAD_TYPE_REPRESENTATION)
        {
                GWLOG(LOG_ERR, "Incoming payload is NULL or not a representation");
                return ehResult;
        }

        HueLight light;
        HueLight::light_state_t state;

        /* get the light matching the URI. If we don't find the light, return error*/
        if(!uri || (get_light_from_uri(uri, light) == false)) {
            GWLOG(LOG_ERR, "light with uri=%s not found", uri);
            return ehResult;
        }

        OCRepPayload* input = reinterpret_cast<OCRepPayload*>(ehRequest->payload);

        if(input)
        {
                // Perform a READ modify WRITE (to presenve the current state of the light
                // except the interested attribute(s) being changed
                if(light.getState(state, true) != GW_RESULT_OK)
                {
                        GWLOG(LOG_WARNING, "light.getState failed; aborting PUT command service.");
                        return ehResult;
                }

                if(HUE_SWITCH_TYPE == light_resource.rt)
                {
                        if(!OCRepPayloadGetPropBool(input, "value", &light_resource.attributes.power))
                        {
                                GWLOG(LOG_ERR, "No value (power) in representation");
                                return ehResult;
                        }

                        GWLOG(LOG_INFO,"PUT/POST value (power):%s",
                              light_resource.attributes.power ? "true" : "false");
                        state.power = light_resource.attributes.power;
                }
                else if(HUE_BRIGHTNESS_TYPE == light_resource.rt)
                {
                        if(!OCRepPayloadGetPropInt(input, "brightness", &light_resource.attributes.bri))
                        {
                                GWLOG(LOG_ERR, "No brightness in representation");
                                return ehResult;
                        }

                        GWLOG(LOG_INFO,"PUT/POST brightness:%d", light_resource.attributes.bri);

                        // Get the current powered state of light and then set the value accordingly.
                        // If the light is turned off, then PUT to bri will yield in a blink
                        // and quickly to off state. In short, it is invalid.
                        state.bri = light_resource.attributes.bri;
                }
                else if(HUE_CHROMA_TYPE == light_resource.rt)
                {
                        if(!OCRepPayloadGetPropInt(input, "hue", &light_resource.attributes.chroma.hue))
                        {
                                GWLOG(LOG_ERR, "No hue in representation");
                                return ehResult;
                        }

                        if(!OCRepPayloadGetPropInt(input, "saturation",
                                                   &light_resource.attributes.chroma.sat))
                        {
                                GWLOG(LOG_ERR, "No saturation in representation");
                                return ehResult;
                        }

                        if(!OCRepPayloadGetPropString(input, "colourspacevalue",
                                                  (char **)&light_resource.attributes.chroma.colourspacevalue))
                        {
                                GWLOG(LOG_ERR, "No colourspacevalue in representation");
                                //Note: don't return bad result here because
                                //this attribute is currently not used and not needed
                                light_resource.attributes.chroma.colourspacevalue = (char*) "dummy_colourspacevalue";
                        }

                        GWLOG(LOG_INFO,"PUT/POST hue :%d", light_resource.attributes.chroma.hue);
                        GWLOG(LOG_INFO,"PUT/POST saturation (sat) :%d", light_resource.attributes.chroma.sat);
                        GWLOG(LOG_INFO,"PUT/POST colourspacevalue (sat) :%s",
                                        light_resource.attributes.chroma.colourspacevalue);

                        // Get the current powered state of light and then set the value accordingly.
                        // If the light is turned off, then PUT to hue/sat will yield in a blink
                        // and quickly to off state. In short, it is invalid.

                        state.hue = light_resource.attributes.chroma.hue;
                        state.sat = light_resource.attributes.chroma.sat;
                }
                else
                {
                        GWLOG(LOG_ERR, "Failed due to unkwown resource type");
                        return ehResult;
                }

                if(light.setState(state) == GW_RESULT_OK)
                {
                        //check if the values set in Put request are actually set. If not return error and
                        //copy the values in return param
                        if(light.getState(state, true) == GW_RESULT_OK)
                        {
                            if(HUE_SWITCH_TYPE == light_resource.rt) {
                                if(light_resource.attributes.power != state.power) {
                                    light_resource.attributes.power = state.power;
                                    GWLOG(LOG_ERR, "HUE_SWITCH_TYPE could not be set");
                                    return ehResult;
                                }
                            } else if(HUE_BRIGHTNESS_TYPE == light_resource.rt) {
                                if((uint64_t)light_resource.attributes.bri != state.bri) {
                                    light_resource.attributes.bri = state.bri;
                                    GWLOG(LOG_ERR, "HUE_BRIGHTNESS_TYPE could not be set");
                                    return ehResult;
                                }
                            } else if(HUE_CHROMA_TYPE == light_resource.rt){
                                if((uint64_t)light_resource.attributes.chroma.hue != state.hue ||
                                   (uint64_t)light_resource.attributes.chroma.sat != state.sat) {
                                    light_resource.attributes.chroma.hue = state.hue;
                                    light_resource.attributes.chroma.sat = state.sat;
                                    GWLOG(LOG_ERR, "HUE_CHROMA_TYPE could not be set hue=%d, sat=%d", state.hue, state.sat);
                                    return ehResult;
                                }
                            }
                            ehResult = OC_EH_OK;
                        }
                        else
                        {
                            GWLOG(LOG_ERR, "Error while getting light state after a PUT");
                        }
                }
                else
                {
                        GWLOG(LOG_ERR, "Light state can not be set");
                }
        }
        else {
                GWLOG(LOG_ERR, "Error request payload is null");
        }

        return ehResult;
}

OCRepPayload* get_payload(const char* uri, light_resource_t &light_resource)
{
        bool success = false;
        OCRepPayload* payload = OCRepPayloadCreate(); // this call allocates memory
        if(!payload)
        {
                GWLOG(LOG_ERR, "Failed to allocate Payload");
                // this is the only time it's safe to return in the middle of the function
                return NULL;
        }

        if(!OCRepPayloadSetUri(payload, uri))
        {
                GWLOG(LOG_ERR, "Unable to set URI in the payload");
                goto CLEANUP;
        }

        if(HUE_SWITCH_TYPE == light_resource.rt)
        {
                GWLOG(LOG_INFO, "Setting 'value' (power) in payload: %s\n",
                      light_resource.attributes.power ? "true" : "false");
                if(!OCRepPayloadSetPropBool(payload, "value", light_resource.attributes.power))
                {
                        GWLOG(LOG_ERR, "Failed to set 'value' (power) in payload");
                        goto CLEANUP;
                } else {
                    GWLOG(LOG_INFO, "Successfully set 'value' (power) in payload");
                }
        }
        else if(HUE_BRIGHTNESS_TYPE == light_resource.rt)
        {
                GWLOG(LOG_INFO, "Setting 'brightness' in payload: %d\n",light_resource.attributes.bri);
                if(!OCRepPayloadSetPropInt(payload, "brightness", light_resource.attributes.bri))
                {
                        GWLOG(LOG_ERR, "Failed to set 'brightness' in payload");
                        goto CLEANUP;
                } else {
                    GWLOG(LOG_INFO, "Successfully set 'brightness' in payload");
                }
        }
        else if(HUE_CHROMA_TYPE == light_resource.rt)
        {
                GWLOG(LOG_INFO, "Setting hue in payload: %d\n",light_resource.attributes.chroma.hue);
                GWLOG(LOG_INFO, "Setting sat in payload: %d\n",light_resource.attributes.chroma.sat);
                if(!OCRepPayloadSetPropInt(payload, "hue", light_resource.attributes.chroma.hue) ||
                   !OCRepPayloadSetPropInt(payload, "saturation", light_resource.attributes.chroma.sat)||
                   !OCRepPayloadSetPropString(payload, "colourspacevalue",
                                   light_resource.attributes.chroma.colourspacevalue))
                {
                        GWLOG(LOG_ERR, "Failed to set 'hue' or 'saturation' or "
                                        "'colourspacevalue' in payload");
                        goto CLEANUP;
                } else {
                    GWLOG(LOG_INFO, "Successfully set hue/sat in payload");
                }
        }
        else
        {
                GWLOG(LOG_ERR, "Failed due to unkwown resource type");
                goto CLEANUP;
        }

        // if we're here, operation succeeded; don't delete the allocated payload.
        success = true;

CLEANUP:
        if (false == success) {
            // if we're here a payload was allocated. must free allocated payload in case of failure.
            OCRepPayloadDestroy(payload);
            payload = NULL;
        }

        return payload;
}

/*
 * thread procedure for the thread specific logic. in the case of the hue plugin
 * it loads up the work queue and does nothing else.  In the future this thread will
 * figure out what is going on with the devices and when things change it will be
 * this thread that will add more items to the work queue.
 */
void *hue_lights_discovery_thread_process(void *pointer)
{
    plugin_ctx_t *ctx = (plugin_ctx_t *) pointer;
    if (ctx == NULL) {
        return NULL;
    }
    GWLOG(LOG_INFO, "Plugin specific thread handler entered");

    /* All resources for the HUE plugin are known ahead of time, therefore,
     * create them prior to entering the poling loop
     */
    HueLight::HueLightV lights_prev, lights_new;
    HueLight::HueLightIt itprev, itnew;
    HueLight::light_config_t configprev, confignew;
    HueLight::light_state_t stateprev, statenew;

    while (true == ctx->stay_in_process_loop) {
        pthread_mutex_lock(&g_disc_list_lock);
        /*iterate for every bridge in the authorized bridge map*/
        for (bridgeItr it = g_disc_bridges_map.begin(); it != g_disc_bridges_map.end(); it++) {
                HueBridge *bridge = &(it->second);
                if(bridge == NULL) {
                    continue;
                }
                /* get previous list and new lights list to check if lights list has changed*/
                bridge->getLights(lights_prev);
                /*now start a new discovery and get new lights*/
                bridge->discoverLights();
                bridge->getLights(lights_new);
                /*find the change in the lights by comparing the two vectors.*/
                /* Since the lights are added or deleted with bridge reset
                   (no dynamic addition/deletion)the vectors would always be of same size*/
                for (itprev = lights_prev.begin(); itprev != lights_prev.end(); itprev++) {
                    /*itprev incremented inside the for loop*/
                        (*itprev).getConfig(configprev);
                        (*itprev).getState(stateprev);
                        for (itnew = lights_new.begin(); itnew != lights_new.end(); itnew++) {
                                (*itnew).getConfig(confignew);
                                (*itnew).getState(statenew);
                                if ((configprev.uri == confignew.uri)) {
                                        /* if the state changes for this resource, we need to add
                                         * work item for Observe notification
                                         * if there are multiple entries for the same resource, the
                                         * notify_observers() function will take care of it*/
                                        GWLOG(LOG_INFO, "Calling notify_observers from discovery thread");
                                        notify_observers(configprev.uri + "/switch");
                                        notify_observers(configprev.uri + "/brightness");
                                        notify_observers(configprev.uri + "/chroma");
                                        /*check specifically for the presence of the resource for
                                          the discovery list*/
                                        if (stateprev.reachable == statenew.reachable) {
                                                /* if same element is found in both vectors without
                                                 * reachable change, its deleted from new
                                                 * discovery vector at the end, lights_prev will
                                                 * have elements which were not discovered in the
                                                 * new list and in lights_new will
                                                 * have elements which are newly discovered or
                                                 * have changed reachable*/
                                                itnew = lights_new.erase(itnew);
                                                break;
                                        }
                                }
                        }
                }
                /* if there is any element left in lights_new, it needs to be created\destroyed depending on
                 * reachable config
                 */
                for (itnew = lights_new.begin(); itnew != lights_new.end(); itnew++) {
                        (*itnew).getConfig(confignew);
                        (*itnew).getState(statenew);
                        if (statenew.reachable == true) {
                                GWLOG(LOG_INFO,
                                        "hue_lights_discovery_thread_process (add) - light name=%s, id=%s, reachable=%d",
                                        confignew.name.c_str(), confignew.uniqueId.c_str(), statenew.reachable);
                                add_item_oic_profile_wrapper(ctx, confignew.uri, WORK_ITEM_CREATE_RESOURCE);
                        } else {
                                GWLOG(LOG_INFO,
                                        "hue_lights_discovery_thread_process (delete) - light name=%s, id=%s, reachable=%d",
                                        confignew.name.c_str(), confignew.uniqueId.c_str(), statenew.reachable);
                                add_item_oic_profile_wrapper(ctx, confignew.uri, WORK_ITEM_DESTROY_RESOURCE);
                        }
                }
            } /* end bridges for()*/
            pthread_mutex_unlock(&g_disc_list_lock);

            /*start the periodic bridge discovery*/
            hueAuthDiscoverBridges();

            sleep(DISCOVERY_THREAD_SLEEP_TIME);
    }

    GWLOG(LOG_INFO, "Leaving plugin specific thread handler");
    pthread_exit (NULL);
}

/*
 * gets a light object with matching URI
 * @param uri - (in) URI to find the matching light
 * @param light (out) the light with matching URI
 * returns true or false
 */
bool get_light_from_uri(char *uri, HueLight &light) {
        HueLight::HueLightV lightsVec;
        HueLight::light_config_t config;
        std::string switchUri;
        std::string brightnessUri;
        std::string chromaUri;
        bool bfound = false;
        /*Need to iterate each bridge to find the light resource*/
        for (bridgeItr it = g_disc_bridges_map.begin();
                it != g_disc_bridges_map.end(); it++) {
            HueBridge bridge = it->second;
            bridge.getLights(lightsVec);

            for (unsigned int i = 0; i < lightsVec.size(); i++) {
                (lightsVec.at(i)).getConfig(config);
                switchUri = config.uri + "/switch";
                brightnessUri = config.uri + "/brightness";
                chromaUri = config.uri + "/chroma";
                if (strcmp(switchUri.c_str(), uri) == 0 ||
                    strcmp(brightnessUri.c_str(), uri) == 0 ||
                    strcmp(chromaUri.c_str(), uri) == 0) {
                    light = lightsVec[i];
                    bfound = true;
                    break;
                }
            }
            if (bfound) {
                break;
            }
        }
        return bfound;
}


