/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

/* This file contains plugin specific code that adapts the native resource model
 * of native devices into the resource model of OIC.  The file is divided into two
 * sections; first plugin specific entry points are implemented followed by the
 * implementation of the resource entity handler required by the IoTivity implementation
 * for each resource.
 *
 * NOTE: This file is plumbed ready for dynamic resource additions.  There is a
 * thread provided to manage the devices.  When a resource is found it is added
 * to a work queue which is serviced by the plugin process function.  The plugin
 * process function is a thread safe place for the plugin specific code to call
 * OIC APIs.
 */

#include "gw_error_code.h"
#include <string.h>
#include "queue.h"
#include "ocstack.h"
#include "octypes.h"
#include "ocpayload.h"
#include "hue_light.h"
#include "hue_bridge.h"

#ifndef __HUE_RESOURCE_H__
#define __HUE_RESOURCE_H__

// This struct consists of members specific to Smart home OIC resource
// with RT oic.r.colour.chroma.
typedef struct chroma_attributes chroma_attributes_t;
struct chroma_attributes
{
        int64_t hue;
        int64_t sat;
        char* colourspacevalue;
};

// This data structure consists of members associated with functional
// aspect (attributes) of Hue light.
typedef union light_attributes light_attributes_t;
union light_attributes
{
        bool power;
        int64_t bri;
        chroma_attributes_t chroma;
};

typedef struct light_resource light_resource_t;
struct light_resource
{
        std::string rt;
        light_attributes_t attributes;
};


/*******************************************************************************
 * prototypes go here
 ******************************************************************************/
OCEntityHandlerResult handle_EH_requests(OCEntityHandlerFlag flag,
                                          OCEntityHandlerRequest *entityHandlerRequest,
                                          light_resource_t &light_resource);

OCEntityHandlerResult binary_switch_EH(OCEntityHandlerFlag flag,
                                          OCEntityHandlerRequest *entityHandlerRequest,
                                          void* callbackParam);

OCEntityHandlerResult brightness_EH(OCEntityHandlerFlag flag,
                                          OCEntityHandlerRequest *entityHandlerRequest,
                                          void* callbackParam);

OCEntityHandlerResult chroma_EH(OCEntityHandlerFlag flag,
                                          OCEntityHandlerRequest *entityHandlerRequest,
                                          void* callbackParam);

OCEntityHandlerResult process_get_request(char *uri, light_resource_t &light_resource);

OCEntityHandlerResult process_put_request(char *uri, OCEntityHandlerRequest *ehRequest,
                                          light_resource_t &light_resource);

OCRepPayload* get_payload(const char* uri, light_resource_t &light_resource);

void *hue_lights_discovery_thread_process(void *pointer);

void notify_observers(std::string uri);

/*gets a light object with matching URI*/
bool get_light_from_uri(char *uri, HueLight &light);

/*define the authorization callbacks*/
void hue_auth_found_bridge_callback(plugin_ctx_t *ctx, const char *macAddrString);
void hue_auth_remove_bridge_callback(plugin_ctx_t *ctx, const char *macAddrString);
#endif /*__HUE_RESOURCE_H__*/
