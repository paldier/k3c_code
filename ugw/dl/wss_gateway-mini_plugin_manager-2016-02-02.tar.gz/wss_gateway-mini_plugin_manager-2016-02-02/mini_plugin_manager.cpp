/*
 * INTEL CONFIDENTIAL
 * Copyright 2015 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors.  Title to the Material remains with Intel
 * Corporation or its suppliers and licensors.  The Material contains trade
 * secrets and proprietary and confidential information of Intel or its
 * suppliers and licensors.  The Material is protected by worldwide copyright
 * and trade secret laws and treaty provisions. No part of the Material may
 * be used, copied, reproduced, modified, published, uploaded, posted,
 * transmitted, distributed, or disclosed in any way without Intel's prior
 * express written permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or
 * delivery of the Materials,  either expressly, by implication, inducement,
 * estoppel or otherwise.  Any license under such intellectual property
 * rights must be express and approved by Intel in writing.
 */

/* The purpose of this file is to simulate the Iotivity protocol plugin manager
 * this file contains a plugin loader for a 32 bit plugin targeted for the X3
 * platform.  It has exactly the same interface as the Iotivity protocol plugin
 * manager.
 */
#include <stdlib.h>
#include <stdio.h>
#include <dlfcn.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <pthread.h>
#define LOG_TAG "PI_MGR"
#include "gwlog.h"
#include "gw_error_code.h"

/*******************************************************************************
 * defines go here
 ******************************************************************************/

#define MAX_SHARED_OBJECT_NAME_LENGTH  300
#define MAX_SHARED_OBJECTS_LOADED       20
#define WAIT_TO_PRINT_INSTRUCTIONS       7

#define PLUGIN_LIST_FILE_NAME          "plugin_load_list.txt"

/*******************************************************************************
 * type defines and structure definitions go here
 ******************************************************************************/

typedef void* (*create_t)(void *ppm_ctx);
typedef int32_t (*start_t)(void *plugin_ctx);
typedef void (*stop_t)(void *plugin_ctx);
typedef void (*destroy_t)(void *plugin_ctx);

typedef struct plugin_context_tag {
        /* function pointers for each shared object loaded */
        create_t  create;
        start_t   start;
        stop_t    stop;
        destroy_t destroy;
        void     *handle;
        void     *plugin_ctx;
        void     *ppm_ctx;
        char shared_object_name[MAX_SHARED_OBJECT_NAME_LENGTH];
} plugin_context_t;


typedef struct plugin_runtime_tag {
        create_t  create;
        start_t   start;
        stop_t    stop;
        destroy_t destroy;
} plugin_runtime_t;

/*******************************************************************************
 * global variables go here
 ******************************************************************************/

pthread_cond_t g_abort_cv;
pthread_mutex_t g_abort_lock;
bool g_abort_signaled = false;
extern char *optarg;
extern int optind, opterr, optopt;

/*******************************************************************************
 * prototypes go here
 ******************************************************************************/

int getopt(int argc, char * const argv[], const char *optstring);

/*******************************************************************************
 * implementation begins here
 ******************************************************************************/

void sig_handler(int32_t signo)
{
        int32_t result;
        if (signo == SIGINT) {
                /* signal the main thread to clean up and exit */
                pthread_mutex_lock(&g_abort_lock);
                g_abort_signaled = true;
                result = pthread_cond_signal(&g_abort_cv);
                pthread_mutex_unlock(&g_abort_lock);
                if (result == 0) {
                        GWLOG(LOG_INFO,"Cntrl C sucessfully signaled the loader to unload plugins.");
                }
        }
}


int main(int argc, char* argv[])
{
        const int MAX_BUF_LENGTH = 50;
        const int MAX_PATH_LENGTH = 200;
        char buf[MAX_BUF_LENGTH];
        char format[32];
        FILE     *file;
        uint32_t nfiles = 0;
        uint32_t index;
        char     *error;
        int32_t  result = 0;
        plugin_context_t contexts[MAX_SHARED_OBJECTS_LOADED];
        char path[MAX_PATH_LENGTH];
        char plugin_list_name[MAX_SHARED_OBJECT_NAME_LENGTH];
        int32_t character;
        size_t size;
        char *cvalue = NULL;
        bool non_secure_resources = false;
        char* non_secure_env = NULL;

        memset(contexts, 0, sizeof(plugin_context_t) * MAX_SHARED_OBJECTS_LOADED);
        memset(buf, 0, MAX_BUF_LENGTH);
        memset(path, 0, MAX_PATH_LENGTH);
        memset(plugin_list_name, 0, MAX_SHARED_OBJECT_NAME_LENGTH);

        while ((character = getopt (argc, argv, "f:p:n")) != -1) {
                switch (character) {
                        case 'f':
                                cvalue = optarg;
                                if (cvalue != NULL) {
                                        if (nfiles < MAX_SHARED_OBJECTS_LOADED) {
                                                strncpy(contexts[nfiles++].shared_object_name, cvalue, MAX_SHARED_OBJECT_NAME_LENGTH - 1);
                                        }
                                }
                        break;
                        case 'p':
                                cvalue = optarg;
                                if (cvalue != NULL) {
                                        strncpy(path, cvalue, MAX_PATH_LENGTH - 1);
                                }
                        break;
                        case 'n':
                            result = setenv("NONSECURE","true", 1);
                            if (0 != result) {
                                GWLOG(LOG_ERR, "setenv failed with %d", result);
                            }
                            break;
                        default:
                                GWLOG(LOG_ERR, "Unknown option 0x%x\n", optopt);
                                return 1;
                        break;
                }
        }

        non_secure_env = getenv("NONSECURE");
        if (NULL != non_secure_env) {
            if (0 == strcmp(non_secure_env, "true")) {
                non_secure_resources = true;
                GWLOG(LOG_INFO, "NONSECURE variable is 'true'");
            }
            else {
                GWLOG(LOG_INFO, "NONSECURE variable is not 'true'");
            }
        }
        else {
            GWLOG(LOG_INFO, "NONSECURE variable not set.");
        }
        if (non_secure_resources) {
            GWLOG(LOG_INFO, "Will create non-secure resources.");
        }
        else {
            GWLOG(LOG_INFO, "Will create secure resources (default).");
        }

        /* initialize a condition variable to its default value */
        result = pthread_cond_init(&g_abort_cv, NULL);
        if (result!=0) {
                GWLOG(LOG_ERR,"Failed to create the conditional variable used for program exit.");
        }

        if (pthread_mutex_init(&g_abort_lock, NULL) != 0) {
                GWLOG(LOG_ERR,"Failed to initialize abort lock mutex.");
        }

        if (signal(SIGINT, sig_handler) == SIG_ERR) {
                GWLOG(LOG_ERR,"Signal handler registration failed, unable to catch SIGINT.");
        }

        /* open the plugin list file.  This file should be in the same directory
         * where this program is run.   When the real protocol plugin manager is
         * primetime for a 32 bit platform then it will replace this plugin manager.
         *
         */
        if (strlen(path) > 0) {
                strcpy(plugin_list_name, path);
                strcat(plugin_list_name, "/");
                strncat(plugin_list_name, PLUGIN_LIST_FILE_NAME, strlen(PLUGIN_LIST_FILE_NAME));
        } else {
                strcpy(plugin_list_name, PLUGIN_LIST_FILE_NAME);
        }

        if (nfiles == 0) {
                file = fopen(plugin_list_name,"r");
                if (file) {
                        snprintf(format, sizeof(format), "%%%ds", (MAX_BUF_LENGTH-1));
                        while(fscanf(file, format, buf) == 1 ) {
                                /* prepend path if there is one */
                                size = strlen(path)+strlen(buf)+strlen("/")+1;
                                if (strlen(path) > 0 &&
                                    (MAX_SHARED_OBJECT_NAME_LENGTH > size)) {
                                        strncpy(contexts[nfiles].shared_object_name, path,
                                                MAX_SHARED_OBJECT_NAME_LENGTH-1);
                                        strncat(contexts[nfiles].shared_object_name, "/", strlen("/"));
                                        strncat(contexts[nfiles].shared_object_name, buf, strlen(buf));
                                } else if(MAX_SHARED_OBJECT_NAME_LENGTH > strlen(buf)) {
                                        strncpy(contexts[nfiles].shared_object_name, buf,
                                                MAX_SHARED_OBJECT_NAME_LENGTH-1);
                                } else {
                                    GWLOG(LOG_ERR,"insufficient buffer length. Could not copy file");
                                }
                                nfiles += 1;

                                /* get the buffer ready for the next read */
                                memset(buf, 0, MAX_BUF_LENGTH);
                                if (nfiles >= MAX_SHARED_OBJECTS_LOADED) {
                                        break;
                                }
                        }
                        fclose(file);
                } else {
                        GWLOG(LOG_ERR,"Could not find the file %s", PLUGIN_LIST_FILE_NAME);
                        return 1;
                }
        } else {
                GWLOG(LOG_INFO,"Using command line file specification for input");
        }

        GWLOG(LOG_INFO,"Plugin manager is told to load and start  %d plugins.\n", nfiles);

        /* Now lets load the plugin and resolve the exported functions of the plugin
         * The exported functions of interest: create, start, stop, destroy
         */
        for (index = 0; index < nfiles; index++) {
                GWLOG(LOG_INFO,"Loading library on \"%s\"", contexts[index].shared_object_name);
                contexts[index].handle = dlopen(contexts[index].shared_object_name, RTLD_LAZY);
                if (!contexts[index].handle) {
                        if ((error = dlerror()) != NULL)  {
                                fputs (error, stderr);
                        }
                        return 1;
                }

                GWLOG(LOG_INFO, "Resolving function table from plugin.\n");
                plugin_runtime_t *ftab = (plugin_runtime_t *)dlsym(contexts[index].handle, "plugin_funcs");
                if ((error = dlerror()) != NULL)  {
                        fputs(error, stderr);
                        GWLOG(LOG_ERR,"Invalid plugin file.");
                        return 1;
                }
                if (ftab == NULL) {
                        GWLOG(LOG_ERR,"ftab returned from call to dlsym is NULL.");
                        return 1;
                }

                contexts[index].create = ftab->create;
                contexts[index].start  = ftab->start;
                contexts[index].stop   = ftab->stop;
                contexts[index].destroy = ftab->destroy;
        }

        /* Time to call the entry points (create and start) */

        for (index = 0; index < nfiles; index++) {
                  GWLOG(LOG_INFO,"Calling create on \"%s\":", contexts[index].shared_object_name);
                  contexts[index].plugin_ctx = (*(contexts[index].create))(contexts[index].ppm_ctx);
                  GWLOG(LOG_INFO,"Exported functions have been resolved for this library");
                  if (NULL != contexts[index].plugin_ctx) {
                        GWLOG(LOG_INFO,"plugin create successful");
                        GWLOG(LOG_INFO,"Calling start on \"%s\":", contexts[index].shared_object_name);
                        result = (*(contexts[index].start))(contexts[index].plugin_ctx);
                        if (0 == result) {
                                GWLOG(LOG_INFO,"Plugin start successful.");
                        } else {
                                GWLOG(LOG_ERR,"Plugin start failed \"%s\":",
                                       contexts[index].shared_object_name);
                                GWLOG(LOG_ERR,"Are the authorization files correct?");
                        }
                  } else {
                        GWLOG(LOG_ERR,"Plugin failed to create");
                  }
        }

        /* give the plugins a chance to startup */
        sleep(WAIT_TO_PRINT_INSTRUCTIONS);

        GWLOG(LOG_INFO,"Exported functions complete, use <control C> to kill loader.\n");

        /* wait on condition variable */
        pthread_mutex_lock(&g_abort_lock);
        if (false == g_abort_signaled) {
                result = pthread_cond_wait(&g_abort_cv, &g_abort_lock);
        }
        pthread_mutex_unlock(&g_abort_lock);

        /* stop and destroy the plugins */
        for (index = 0; index < nfiles; index++) {
                  GWLOG(LOG_INFO,"Calling stop on \"%s\":", contexts[index].shared_object_name);
                  (*(contexts[index].stop))(contexts[index].plugin_ctx);

                  GWLOG(LOG_INFO,"Calling destroy on \"%s\":", contexts[index].shared_object_name);
                  (*(contexts[index].destroy))(contexts[index].plugin_ctx);

                  dlclose(contexts[index].handle);
        }

        return 0;
}
